"""
custom_chatbot/tasks.py
────────────────────────
Celery tasks for the PSIRT vulnerability scan pipeline.

This is picked up automatically by Nautobot's Celery app — nautobot/core/celery/__init__.py
calls app.autodiscover_tasks() at startup, which scans every app in INSTALLED_APPS for a
`tasks.py` module. Since custom_chatbot is already a registered Django app inside Nautobot's
process, no additional wiring, worker, or broker setup is needed: Nautobot's existing
`nautobot-server celery worker` process (and `celery beat`, if running) will pick these up
the next time it (re)starts.

Replaces the manual workflow of:
    nohup python run_scan.py --dnac noida --ssh-user X --ssh-pass Y --wait > scan.log 2>&1 &

with either an on-demand call:
    from custom_chatbot.tasks import run_psirt_scan_task
    run_psirt_scan_task.delay(dnac_id="noida", ssh_username="...", ssh_password="...")

or a recurring schedule set up via django-celery-beat (Nautobot Admin → Celery Beat →
Periodic Tasks — no code change needed, since CELERY_BEAT_SCHEDULER is already the
DB-backed NautobotDatabaseScheduler).
"""

import logging
import os
import sys

from celery import shared_task

logger = logging.getLogger("psirt_celery")

# Same sys.path pattern already used in psirt_native_views.py — makes the
# vulnerebility_management package (run_scan, config, dnac.dnacenter, psirt.*)
# importable from inside the Celery worker process.
#
# vulnerebility_management is an OPTIONAL sibling package living at
# <repo_root>/vulnerebility_management (one level up from custom_chatbot/),
# not nested inside custom_chatbot. If it isn't deployed on this host, these
# tasks are still registered with Celery (so autodiscover_tasks() doesn't
# error), but calling them raises a clear RuntimeError instead of an opaque
# ModuleNotFoundError buried in Celery's traceback.
_REPO_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_VM_ROOT = os.path.join(_REPO_ROOT, "vulnerebility_management")
PSIRT_VM_AVAILABLE = os.path.isdir(_VM_ROOT)
if _VM_ROOT not in sys.path:
    sys.path.insert(0, _VM_ROOT)
if not PSIRT_VM_AVAILABLE:
    logger.warning(
        "vulnerebility_management not found at %s -- PSIRT Celery tasks are "
        "registered but will raise RuntimeError if invoked.", _VM_ROOT,
    )


def _require_psirt_vm() -> None:
    if not PSIRT_VM_AVAILABLE:
        raise RuntimeError(
            f"vulnerebility_management is not deployed at {_VM_ROOT} on this "
            f"host -- PSIRT scan tasks are unavailable until it's installed "
            f"alongside custom_chatbot."
        )


# ---------------------------------------------------------------------------
# Kill switch — deployed but intentionally inert until turned on.
#
# The tasks below are safe to have registered with Celery (autodiscover_tasks()
# just imports this module; it doesn't run anything), and nothing in this repo
# currently calls .delay()/.apply_async() on them or schedules them via Celery
# Beat. This flag is a second, explicit safeguard so a scan can never fire —
# manually or via a beat schedule someone sets up later — until you're ready.
#
# To enable: flip the line below to True, OR set the env var
# PSIRT_CELERY_ENABLED=1 for the Celery worker process. No file changes needed
# for the env-var route, so it's the safer option if you don't want to touch
# code again when you're ready to go live.
# ---------------------------------------------------------------------------
PSIRT_CELERY_ENABLED = os.environ.get("PSIRT_CELERY_ENABLED", "0") == "1"


def _require_celery_enabled() -> None:
    if not PSIRT_CELERY_ENABLED:
        raise RuntimeError(
            "PSIRT Celery tasks are currently disabled (PSIRT_CELERY_ENABLED "
            "is not set). Set the env var PSIRT_CELERY_ENABLED=1 for the "
            "Celery worker process, or flip PSIRT_CELERY_ENABLED=True in "
            "custom_chatbot/tasks.py, to allow these tasks to run."
        )


@shared_task(
    bind=True,
    name="custom_chatbot.psirt_scan",
    # A scan can run long (each device x advisory pair makes multiple LLM
    # calls); give it real headroom rather than Celery's default task timeout.
    soft_time_limit=60 * 60 * 3,   # 3h soft limit -> raises SoftTimeLimitExceeded, logged, DB left in last-known state
    time_limit=60 * 60 * 3 + 300,  # hard kill 5 min after that if it didn't clean up
)
def run_psirt_scan_task(self, dnac_id=None, ssh_username="", ssh_password="", ssh_port=22):
    """
    Celery wrapper around vulnerebility_management.run_scan.run_scan() for a
    single DNAC instance (or the legacy single-DNAC config when dnac_id=None).

    Runs synchronously *within the Celery worker process* — from the caller's
    point of view this is fire-and-forget via .delay()/.apply_async(), which
    is the equivalent of the `--wait` flag in the CLI script (the task doesn't
    return / mark itself SUCCESS until the scan pipeline actually finishes).
    """
    _require_celery_enabled()
    _require_psirt_vm()
    from run_scan import run_scan  # local import: only resolvable after sys.path patch above

    logger.info("[PSIRT CELERY] Starting scan task %s for dnac_id=%s", self.request.id, dnac_id)
    result = run_scan(
        dnac_id=dnac_id,
        wait=True,
        ssh_username=ssh_username,
        ssh_password=ssh_password,
        ssh_port=ssh_port,
    )
    logger.info("[PSIRT CELERY] Scan task %s finished: %s", self.request.id, result)

    if result.get("status") == "error":
        # Surface failures in Celery's own result backend / Nautobot's task
        # log view, instead of silently returning an "ok"-shaped task result
        # for a scan that actually failed.
        raise RuntimeError(f"PSIRT scan failed for dnac_id={dnac_id}: {result.get('error')}")

    return result


@shared_task(
    bind=True,
    name="custom_chatbot.psirt_scan_all",
    soft_time_limit=60 * 60 * 8,
    time_limit=60 * 60 * 8 + 300,
)
def run_psirt_scan_all_task(self, ssh_username="", ssh_password="", ssh_port=22):
    """
    Celery wrapper around vulnerebility_management.run_scan.run_scan_all() —
    runs the scan for every DNAC instance in config.DNAC_INSTANCES, one after
    another. Long-running; this is the task to put on a nightly/weekly beat
    schedule if you want every site scanned automatically rather than
    triggering one DNAC at a time.
    """
    _require_celery_enabled()
    _require_psirt_vm()
    from run_scan import run_scan_all  # local import: only resolvable after sys.path patch above

    logger.info("[PSIRT CELERY] Starting scan-all task %s", self.request.id)
    results = run_scan_all(
        wait=True,
        ssh_username=ssh_username,
        ssh_password=ssh_password,
        ssh_port=ssh_port,
    )
    logger.info("[PSIRT CELERY] Scan-all task %s finished: %d dnac instance(s)", self.request.id, len(results))

    failed = [r for r in results if r.get("status") == "error"]
    if failed:
        raise RuntimeError(
            f"PSIRT scan-all: {len(failed)}/{len(results)} DNAC instance(s) failed: "
            f"{[(r['dnac_id'], r['error']) for r in failed]}"
        )

    return results
