from django.urls import path
from .views import ChatbotView, chat_status, DnacInstancesView
from . import psirt_native_views as psirt

app_name = "custom_chatbot"

urlpatterns = [
    # Existing chatbot endpoints
    path('chat/', ChatbotView.as_view(), name='chatbot'),
    path('chat_status/', chat_status, name='chat_status'),
    path('dnac-instances/', DnacInstancesView.as_view(), name='dnac_instances'),

    # PSIRT Chatbot (native Django port of psirt_chatbot.py) endpoints
    path('psirt/api/chat/', psirt.psirt_chat, name='psirt_chat'),
    path('psirt/api/history/', psirt.psirt_history, name='psirt_history'),
    path('psirt/api/clear/', psirt.psirt_clear, name='psirt_clear'),
    path('psirt/api/applicability_summary/', psirt.psirt_applicability_summary, name='psirt_applicability_summary'),
    path('psirt/api/device_advisories/', psirt.psirt_device_advisories, name='psirt_device_advisories'),
    path('psirt/api/diagnose/', psirt.psirt_diagnose, name='psirt_diagnose'),
    path('psirt/api/trigger_scan/', psirt.psirt_trigger_scan, name='psirt_trigger_scan'),
    path('psirt/api/status/', psirt.psirt_status, name='psirt_status'),
    path('psirt/api/assess/', psirt.psirt_assess, name='psirt_assess'),
    path('psirt/api/job/<str:job_id>/', psirt.psirt_job_status, name='psirt_job_status'),
    path('psirt/api/job/<str:job_id>/export/', psirt.psirt_job_export, name='psirt_job_export'),
    path('psirt/api/jobs/', psirt.psirt_jobs_list, name='psirt_jobs_list'),
    path('psirt/api/dnac/assess-all/', psirt.psirt_dnac_assess_all, name='psirt_dnac_assess_all'),
    path('psirt/api/dnac/test/', psirt.psirt_dnac_test, name='psirt_dnac_test'),
    path('psirt/api/dnac/devices/', psirt.psirt_dnac_devices, name='psirt_dnac_devices'),
    path('psirt/api/dnac/advisories/', psirt.psirt_dnac_advisories, name='psirt_dnac_advisories'),
    path('psirt/api/dnac/advisory/<str:advisory_id>/devices/', psirt.psirt_dnac_advisory_devices, name='psirt_dnac_advisory_devices'),
    path('psirt/api/generate_remediation/', psirt.psirt_generate_remediation, name='psirt_generate_remediation'),
]