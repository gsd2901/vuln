import logging
import os
import sys

from django.apps import AppConfig

logger = logging.getLogger(__name__)


class CustomChatbotConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'custom_chatbot'

    def ready(self):
        """
        vulnerebility_management (the PSIRT vulnerability-scanning toolkit) is
        an OPTIONAL sibling package, not a required part of custom_chatbot —
        it lives at <repo_root>/vulnerebility_management, one level up from
        this app, rather than nested inside it. That split lets it be dropped
        or swapped independently of custom_chatbot.

        This makes `import vulnerebility_management...` resolve as a plain
        top-level package import if (and only if) that sibling directory is
        actually present on disk. If it's missing, custom_chatbot itself
        still loads fine — every caller (views.py, services/*.py,
        psirt_native_views.py, tasks.py) wraps its own
        `import vulnerebility_management...` in try/except and degrades to a
        "PSIRT features unavailable" state rather than crashing at import
        time. This method is the single place that decides whether the
        package is reachable at all; nothing else should be adding
        vulnerebility_management's location to sys.path.
        """
        repo_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        vm_path = os.path.join(repo_root, "vulnerebility_management")

        if os.path.isdir(vm_path):
            if repo_root not in sys.path:
                sys.path.insert(0, repo_root)
            logger.info("vulnerebility_management found at %s — PSIRT features enabled.", vm_path)
        else:
            logger.warning(
                "vulnerebility_management not found at %s — PSIRT features "
                "(chat vuln lookups, /psirt/* endpoints, PSIRT Applicability "
                "Manager) will be unavailable. This is expected if it hasn't "
                "been deployed alongside custom_chatbot on this host.",
                vm_path,
            )
