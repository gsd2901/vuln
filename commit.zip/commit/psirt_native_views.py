"""
psirt_native_views.py
──────────────────────
Native Django port of the standalone psirt_chatbot.py Flask app (formerly
vulnerebility_management/psirt_chatbot.py). Ported 1:1 route-for-route so the
"PSIRT Chatbot" Gen AI sidebar page runs entirely inside the Django/gunicorn
process — no separate Flask server, no separate port to manage or open on the
firewall.

Key differences from the original Flask file (required for correctness under
gunicorn's multi-worker model — the original's `jobs = {}` in-memory dict and
Flask `session` would NOT behave correctly across multiple gunicorn workers):

  * In-memory `jobs` dict            → django.core.cache.cache (assumes Redis
                                        backend, which Nautobot requires for
                                        Celery/RQ anyway — job state is now
                                        visible to whichever worker handles a
                                        given poll request).
  * Flask `session["history"]`       → Django `request.session["history"]`
                                        (Django's session backend is already
                                        shared across workers by design).
  * Flask jsonify/request.get_json   → Django JsonResponse / json.loads(request.body).
  * @app.route("/api/job/<id>/export") writing to /tmp and send_file
                                      → JsonResponse with Content-Disposition
                                        header, no temp file needed.
  * CSRF: Django requires a token on POSTs. The ported template sends it via
    the standard 'X-CSRFToken' header (see psirt_chatbot.html).

Everything else — the GPT prompts, the 3-layer applicability logic, the DNAC
Command Runner / SSH fallback collection flow, the ad-hoc (user-typed, not
config-file) DNAC credentials handling — is preserved exactly as written in
the original file, since this page is explicitly designed to let an operator
type in ANY DNAC's host/username/password at runtime rather than only the
pre-configured DNAC_INSTANCES in config.py.
"""

from __future__ import annotations

import json
import logging
import os
import re
import threading
import time
from datetime import datetime

import httpx
import requests
from django.core.cache import cache
from django.http import HttpResponse, JsonResponse
from django.views.decorators.http import require_GET, require_POST

try:
    from netmiko import ConnectHandler, NetmikoAuthenticationException, NetmikoTimeoutException
    _NETMIKO_AVAILABLE = True
except ImportError:
    _NETMIKO_AVAILABLE = False

try:
    from langchain_openai import AzureChatOpenAI
    _LANGCHAIN_AVAILABLE = True
except ImportError:
    _LANGCHAIN_AVAILABLE = False

try:
    import chromadb
    _chroma_client = chromadb.PersistentClient(
        path=os.environ.get("CHROMA_DB_PATH", "./psirt_chroma_db"))
    _advisory_collection = _chroma_client.get_or_create_collection(
        name="advisory_profiles", metadata={"hnsw:space": "cosine"})
    CHROMA_AVAILABLE = True
except ImportError:
    CHROMA_AVAILABLE = False
    _advisory_collection = None

logger = logging.getLogger("psirt_chatbot_native")

# Make the vulnerebility_management package importable (RAGLangChainAgent,
# psirt.db_queries, run_scan, config, dnac.dnacenter all live there).
#
# vulnerebility_management is an OPTIONAL sibling package, not nested inside
# custom_chatbot -- it lives at <repo_root>/vulnerebility_management, one
# level up from this file's directory. custom_chatbot/apps.py.ready() is
# responsible for detecting whether it's present and adding <repo_root> to
# sys.path if so; this insert is purely for the flat, non-dotted import style
# used throughout vulnerebility_management's own modules (e.g. `import
# psirt.db_queries`, `from dnac.dnacenter import DNAC`, `from run_scan import
# run_scan`), which expects vulnerebility_management/ ITSELF on sys.path, not
# just its parent. Safe to insert even if the directory doesn't exist --
# sys.path entries that don't resolve to anything are simply never matched;
# the actual "is PSIRT available" check happens at each call site where these
# modules are imported (mostly inside the view functions below, not here at
# module level), so a missing package surfaces as a per-endpoint error rather
# than breaking custom_chatbot's own import.
import sys
_REPO_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_VM_ROOT = os.path.join(_REPO_ROOT, "vulnerebility_management")
PSIRT_VM_AVAILABLE = os.path.isdir(_VM_ROOT)
if _VM_ROOT not in sys.path:
    sys.path.insert(0, _VM_ROOT)
if not PSIRT_VM_AVAILABLE:
    logger.warning(
        "vulnerebility_management not found at %s -- PSIRT-dependent endpoints "
        "in this file will return errors when called, but the module itself "
        "still loads.", _VM_ROOT,
    )

# ── Azure OpenAI (advisory extraction + applicability analysis) ──────────────
AZURE_OPENAI_API_KEY    = "5kRpMIyDt06ImaRoayI76KuQuO9Cdt9s32YEh7lCZ9BK5sEIqZDbJQQJ99CAAC77bzfXJ3w3AAABACOGLOOn"
AZURE_OPENAI_ENDPOINT   = "https://git-nw-openai-llm-prod.openai.azure.com/"
AZURE_OPENAI_DEPLOYMENT = "gpt-5.4"

_proxy_url = os.environ.get("https_proxy") or os.environ.get("HTTPS_PROXY", "")
if _proxy_url and not _proxy_url.startswith(("http://", "https://")):
    _proxy_url = "http://" + _proxy_url

_azure_http_client = httpx.Client(
    verify=False,
    proxy=_proxy_url if _proxy_url else None,
    timeout=httpx.Timeout(60.0, connect=15.0),
) if _LANGCHAIN_AVAILABLE else None

openai_client = AzureChatOpenAI(
    azure_deployment=AZURE_OPENAI_DEPLOYMENT,
    api_version="2025-04-01-preview",
    azure_endpoint=AZURE_OPENAI_ENDPOINT,
    http_client=_azure_http_client,
    temperature=0,
    api_key=AZURE_OPENAI_API_KEY,
    max_retries=3,
) if _LANGCHAIN_AVAILABLE else None

_no_proxy_session = requests.Session()
_no_proxy_session.verify = False
if _proxy_url:
    _no_proxy_session.proxies = {"http": _proxy_url, "https": _proxy_url}

_cisco_advisory_cache: dict = {}  # advisory_id -> full text (per-process perf cache only)

# ── Job store: Redis-backed cache instead of an in-memory dict ──────────────
# NOTE: assumes Nautobot's CACHES is Redis-backed (required for Celery/RQ in
# any real deployment). Verify on the server if jobs seem to "disappear"
# between polls -- that would mean CACHES is actually per-process LocMemCache.
_JOB_TTL = 60 * 60 * 4  # 4 hours


def _job_key(job_id: str) -> str:
    return f"psirt_job:{job_id}"


def _get_job(job_id: str) -> dict | None:
    return cache.get(_job_key(job_id))


def _set_job(job_id: str, job: dict) -> None:
    cache.set(_job_key(job_id), job, timeout=_JOB_TTL)


def _job_index_key() -> str:
    return "psirt_job_index"


def _register_job(job_id: str) -> None:
    ids = cache.get(_job_index_key()) or []
    if job_id not in ids:
        ids.append(job_id)
        cache.set(_job_index_key(), ids[-200:], timeout=_JOB_TTL)  # keep last 200


# ── Feature -> verification commands ──────────────────────────────────────────
FEATURE_COMMANDS = {
    "snmp":           ["show running-config | include snmp-server community",
                       "show running-config | include snmp-server group",
                       "show snmp user", "show snmp community",
                       "show running-config | section snmp-server"],
    "secure boot":    ["show version", "show platform integrity",
                       "show software authenticity running",
                       "show platform sudi certificate", "show rom-monitor",
                       "show platform integrity sign nonce 12345"],
    "tls":            ["show running-config | include ip http",
                       "show running-config | include ip http secure-server",
                       "show running-config | section line vty",
                       "show running-config | include transport input",
                       "show running-config | include ssl",
                       "show ip http server status", "show ip http secure-status"],
    "ssl":            ["show running-config | include ip http",
                       "show ip http server status", "show ip http secure-status",
                       "show running-config | include ssl"],
    "privilege escalation": ["show running-config | include privilege",
                              "show running-config | section username",
                              "show running-config | include aaa",
                              "show privilege", "tclsh",
                              "show running-config | include tclsh"],
    "privesc":        ["show running-config | include privilege",
                       "show running-config | section username",
                       "show privilege", "tclsh",
                       "show running-config | include tclsh"],
    "bgp":            ["show running-config | include router bgp", "show bgp summary"],
    "ospf":           ["show running-config | include router ospf", "show ip ospf"],
    "ssh":            ["show running-config | include ip ssh", "show ip ssh"],
    "http":           ["show running-config | include ip http",
                       "show ip http server status", "show ip http secure-status"],
    "nat":            ["show running-config | include ip nat", "show ip nat translations"],
    "ipsec":          ["show running-config | include crypto map", "show crypto session"],
    "ikev2":          ["show running-config | include crypto ikev2",
                       "show crypto ikev2 sa",
                       "show running-config | section crypto ikev2"],
    "mpls":           ["show running-config | include mpls", "show mpls interfaces"],
    "ntp":            ["show running-config | include ntp server", "show ntp status"],
    "aaa":            ["show running-config | include aaa", "show aaa servers"],
    "tacacs":         ["show running-config | include tacacs",
                       "show running-config | section aaa", "show aaa servers"],
    "netconf":        ["show running-config | include netconf", "show netconf-yang sessions"],
    "restconf":       ["show running-config | include restconf"],
    "bootp":          ["show running-config | include ip bootp",
                       "show running-config | include no ip bootp server"],
    "nbar":           ["show running-config | include ip nbar",
                       "show running-config | section policy-map",
                       "show ip nbar protocol-discovery"],
    "default":        ["show version", "show running-config | include version"],
}

FEATURE_ALIASES = {
    "transport layer security": "tls", "secure sockets layer": "ssl",
    "privilege": "privilege escalation", "privilege escalation": "privilege escalation",
    "privesc": "privilege escalation", "cli": "privilege escalation",
    "command line interface": "privilege escalation", "command injection": "http",
    "web ui": "http", "web management": "http", "boot": "secure boot",
    "secure boot bypass": "secure boot", "rommon": "secure boot",
    "ikev2": "ikev2", "ike": "ikev2", "tacacs+": "tacacs", "tacacs": "tacacs",
    "bootp": "bootp", "nbar": "nbar",
}

ALWAYS_RUN = ["show version"]

DNAC_DEVICE_TYPE_MAP = {
    "Cisco Catalyst 9300 Series Switches":    "cisco_xe",
    "Cisco Catalyst 9200 Series Switches":    "cisco_xe",
    "Cisco Catalyst 9400 Series Switches":    "cisco_xe",
    "Cisco Catalyst 9500 Series Switches":    "cisco_xe",
    "Cisco Catalyst 9600 Series Switches":    "cisco_xe",
    "Cisco ASR 1000 Series Routers":          "cisco_xe",
    "Cisco ISR 4000 Series":                  "cisco_xe",
    "Cisco Nexus 9000 Series Switches":       "cisco_nxos",
    "Cisco Nexus 7000 Series Switches":       "cisco_nxos",
    "Cisco Nexus 5000 Series Switches":       "cisco_nxos",
    "Cisco ASR 9000 Series Aggregation Services Routers": "cisco_xr",
    "Cisco NCS 5500 Series":                  "cisco_xr",
}

# ── RAG agent (lazy-loaded once per worker process) ──────────────────────────
_agent = None


def get_agent():
    global _agent
    if _agent is None:
        try:
            from rag_langchain_agent import RAGLangChainAgent
        except Exception:
            try:
                from vulnerebility_management.rag_langchain_agent import RAGLangChainAgent
            except Exception as exc:
                logger.error("Could not import RAGLangChainAgent: %s", exc)
                return None
        try:
            _agent = RAGLangChainAgent(auto_load_data=True)
            logger.info("RAGLangChainAgent loaded successfully.")
        except Exception as exc:
            logger.error("RAGLangChainAgent init failed: %s", exc)
    return _agent


# ── PSIRT DB helpers ──────────────────────────────────────────────────────────

def _get_applicability_summary(dnac_id=None):
    try:
        from psirt.db_queries import get_summary_counts, get_applicable_advisories_for_dnac
        counts     = get_summary_counts(dnac_id=dnac_id)
        applicable = get_applicable_advisories_for_dnac(
            dnac_id=dnac_id, verdicts=["AFFECTED", "NEEDS_REVIEW"])
        return {"counts": counts, "applicable": applicable}
    except Exception as exc:
        logger.debug("Applicability summary unavailable: %s", exc)
        return None


def _get_device_advisories(device_id, dnac_id=None):
    try:
        from psirt.db_queries import get_applicable_advisories_for_device
        return get_applicable_advisories_for_device(device_id, dnac_id)
    except Exception:
        return []


def _psirt_available():
    try:
        import psirt.db_queries  # noqa
        return True
    except Exception:
        return False


# ── Session helpers (Django session replaces Flask session) ─────────────────

def _session_history(request):
    if "history" not in request.session:
        request.session["history"] = []
    return request.session["history"]


def _append_history(request, role, content):
    hist = _session_history(request)
    hist.append({"role": role, "content": content, "ts": datetime.utcnow().isoformat()})
    request.session["history"] = hist[-40:]
    request.session.modified = True


# ═══════════════════════════════════════════════════════════════════════════
# ── ChromaDB advisory profile cache helpers ───────────────────────────────────
# ═══════════════════════════════════════════════════════════════════════════

def get_advisory_profile_from_cache(advisory_id: str):
    if not CHROMA_AVAILABLE or not advisory_id:
        return None
    try:
        results = _advisory_collection.get(ids=[advisory_id], include=["metadatas"])
        if results and results["ids"]:
            raw = results["metadatas"][0].get("profile_json", "")
            if raw:
                return json.loads(raw)
    except Exception:
        pass
    return None


def save_advisory_profile_to_cache(advisory_id: str, profile: dict) -> None:
    if not CHROMA_AVAILABLE or not advisory_id or not profile:
        return
    try:
        summary_doc = (
            f"Advisory: {advisory_id} | CVE: {profile.get('cve', 'N/A')} | "
            f"Feature: {profile.get('vulnerable_feature', 'N/A')} | "
            f"Platforms: {', '.join(profile.get('affected_platforms', []))}"
        )
        _advisory_collection.upsert(
            ids=[advisory_id],
            documents=[summary_doc],
            metadatas=[{
                "advisory_id":  advisory_id,
                "cve":          profile.get("cve", ""),
                "feature":      profile.get("vulnerable_feature", ""),
                "profile_json": json.dumps(profile),
            }]
        )
    except Exception:
        pass


# ── Fetch full Cisco advisory text ────────────────────────────────────────────

def fetch_cisco_advisory_text(advisory_id: str) -> str:
    if advisory_id in _cisco_advisory_cache:
        return _cisco_advisory_cache[advisory_id]

    json_url = f"https://sec.cloudapps.cisco.com/security/center/content/CiscoSecurityAdvisory/{advisory_id}/json"
    html_url = f"https://sec.cloudapps.cisco.com/security/center/content/CiscoSecurityAdvisory/{advisory_id}"
    headers  = {"User-Agent": "Mozilla/5.0"}

    def _get(url, **kw):
        return _no_proxy_session.get(url, **kw)

    try:
        resp = _get(json_url, timeout=15, headers=headers)
        if resp.status_code == 200:
            data  = resp.json()
            parts = []
            for field in ("summary", "affectedProducts", "vulnerableProducts",
                          "indicatorsOfCompromise", "workarounds",
                          "fixedSoftware", "softwareVersions"):
                val = data.get(field, "")
                if val:
                    clean = re.sub(r"<[^>]+>", " ", str(val))
                    clean = re.sub(r"[ \t]{2,}", " ", clean).strip()
                    parts.append(f"=== {field} ===\n{clean}")
            text = "\n\n".join(parts)
            if text:
                _cisco_advisory_cache[advisory_id] = text
                return text
    except Exception:
        pass

    try:
        resp = _get(html_url, timeout=15, headers=headers)
        resp.raise_for_status()
        html = resp.text
        target_sections = [
            "Summary", "Affected Products", "Vulnerable Products",
            "Products Confirmed Not Vulnerable", "Indicators of Compromise",
            "Workarounds", "Fixed Software", "Software Versions"
        ]
        section_pattern = re.compile(
            r'<(?:h[123]|div[^>]*)[^>]*>\s*(' +
            '|'.join(re.escape(s) for s in target_sections) +
            r')\s*</(?:h[123]|div)>(.*?)(?=<(?:h[123]|div[^>]*)[^>]*>\s*(?:' +
            '|'.join(re.escape(s) for s in target_sections) +
            r')|$)',
            re.IGNORECASE | re.DOTALL
        )
        parts = []
        for m in section_pattern.finditer(html):
            heading = m.group(1).strip()
            clean   = re.sub(r"<[^>]+>", " ", m.group(2))
            clean   = re.sub(r"[ \t]{2,}", " ", clean)
            clean   = re.sub(r"\n{3,}", "\n\n", clean).strip()
            if clean:
                parts.append(f"=== {heading} ===\n{clean}")
        text = "\n\n".join(parts) if parts else re.sub(r"<[^>]+>", " ", html)[:30000]
        _cisco_advisory_cache[advisory_id] = text
        return text
    except Exception:
        _cisco_advisory_cache[advisory_id] = ""
        return ""


# ── Extract advisory profile via GPT ─────────────────────────────────────────

def extract_advisory_profile(advisory_text: str, advisory_id: str = "", force_refresh: bool = False) -> dict:
    if advisory_id and not force_refresh:
        cached = get_advisory_profile_from_cache(advisory_id)
        if cached and (cached.get("affected_versions") or cached.get("fixed_releases")):
            return cached

    if not openai_client:
        raise RuntimeError("AzureChatOpenAI not available")

    prompt = f"""Extract structured info from this Cisco PSIRT advisory. Return ONLY valid JSON.

ADVISORY:
{advisory_text}

Return JSON:
{{
  "advisory_id": "...",
  "cve": "CVE-XXXX-XXXXX",
  "title": "...",
  "vulnerable_feature": "main feature name in lowercase (e.g. snmp, bgp, ssh, secure boot)",
  "affected_platforms": ["list of platform families, e.g. IOS XE, IOS, NX-OS"],
  "affected_versions": ["e.g. '17.9.x before 17.9.5', '16.12.x before 16.12.10'"],
  "fixed_releases": {{"train": "first_fixed_version"}},
  "fixed_in": "earliest recommended fixed release",
  "impact": "brief impact description",
  "workaround": "verbatim operator-actionable guidance from the advisory's Workarounds AND/OR Mitigations section, else null",
  "verification_commands": ["exact IOS/IOS-XE show commands from the advisory"]
}}

CRITICAL:
- For affected_versions: parse every row in the Fixed Software table.
- For verification_commands: extract ONLY CLI commands (show, debug, etc). No prose.
- Never return empty affected_versions if a Fixed Software section exists.
- For workaround: Cisco advisories often write "There are no workarounds that address this
  vulnerability. However, there is a mitigation." followed by concrete mitigation steps/commands.
  Do NOT return null in that case — extract the mitigation guidance (including any example CLI
  config shown) into the workaround field verbatim, since it is still actionable operator guidance
  short of upgrading. Only return null if the advisory has NEITHER a workaround NOR a mitigation
  section with actionable guidance."""

    last_exc = None
    for attempt in range(3):
        try:
            resp = openai_client.invoke([{"role": "user", "content": prompt}])
            raw  = resp.content.replace("```json", "").replace("```", "").strip()
            profile = json.loads(raw)
            break
        except Exception as e:
            last_exc = e
            time.sleep(2 ** attempt)
    else:
        raise last_exc

    cache_key = advisory_id or profile.get("advisory_id", "")
    if cache_key:
        save_advisory_profile_to_cache(cache_key, profile)
    return profile


# ── 3-layer applicability analysis ────────────────────────────────────────────

def analyse_applicability(advisory_profile: dict, device: dict, command_outputs: dict) -> dict:
    if not openai_client:
        raise RuntimeError("AzureChatOpenAI not available")

    outputs_text = "\n".join(f"$ {cmd}\n{out}" for cmd, out in command_outputs.items())

    prompt = f"""You are a Cisco PSIRT applicability engine. Run a 3-layer check. Return ONLY valid JSON.

ADVISORY PROFILE:
{json.dumps(advisory_profile, indent=2)}

DEVICE:
Hostname: {device.get('hostname', device.get('host'))}
Platform/Model: {device.get('platform', 'Unknown')}
Software Version: {device.get('version', 'Unknown')}

COMMAND OUTPUTS:
{outputs_text}

Return JSON:
{{
  "verdict": "AFFECTED" | "NOT_AFFECTED" | "NEEDS_REVIEW",
  "layer1": {{"result": "PASS"|"FAIL"|"UNKNOWN", "detail": "..."}},
  "layer2": {{"result": "PASS"|"FAIL"|"UNKNOWN", "detail": "..."}},
  "layer3": {{"result": "PASS"|"FAIL"|"UNKNOWN", "detail": "..."}},
  "summary": "2-3 sentence explanation",
  "action": "recommended next step for operator",
  "evidence": "key facts from output that led to verdict"
}}

Rules:
- PASS = device IS in affected scope; FAIL = NOT in scope
- AFFECTED = all 3 PASS; NOT_AFFECTED = any layer clearly FAIL
- NEEDS_REVIEW = genuinely insufficient data only

CRITICAL Layer 2: If fixed_releases empty/null → all versions vulnerable → Layer 2 PASS.
If populated: device >= first_fixed → NOT_AFFECTED; device < first_fixed → PASS.
Train not in fixed_releases → NOT_AFFECTED.

CRITICAL Layer 3: privilege escalation/cli features always PASS on IOS XE.
For secure boot: PASS if show platform integrity has Boot Loader Hash.
For tls: PASS if HTTPS server enabled."""

    last_exc = None
    for attempt in range(3):
        try:
            resp = openai_client.invoke([{"role": "user", "content": prompt}])
            raw  = resp.content.replace("```json", "").replace("```", "").strip()
            return json.loads(raw)
        except Exception as e:
            last_exc = e
            time.sleep(2 ** attempt)
    raise last_exc


# ── Tier-1 remediation: verbatim from the advisory, NEVER LLM-generated ───────
#
# This is pure extraction -- it just reads fields that extract_advisory_profile()
# already pulled out of the Cisco advisory text (fixed_in / fixed_releases /
# workaround) and packages them for display. No model call happens here, so
# there is zero hallucination risk: whatever is shown came from the vendor's
# own advisory. If the advisory has no workaround, that's reported as-is
# rather than inventing one.
#
# Device-specific, LLM-synthesized commands (Tier 2) are a deliberately
# separate, opt-in step -- see generate_device_specific_remediation() below --
# and are never merged into this dict.

def build_remediation_tier1(advisory_profile: dict) -> dict:
    fixed_releases = advisory_profile.get("fixed_releases") or {}
    workaround     = (advisory_profile.get("workaround") or "").strip()
    fixed_in       = (advisory_profile.get("fixed_in") or "").strip()

    return {
        "source":            "advisory_verbatim",
        "fixed_in":          fixed_in or None,
        "fixed_releases":    fixed_releases or None,
        "workaround":        workaround or None,
        "has_workaround":    bool(workaround),
        "has_fixed_release": bool(fixed_releases or fixed_in),
    }


# ── Tier-2 remediation: opt-in, device-specific, LLM-synthesized ─────────────
#
# Only called when an operator explicitly requests it for a specific
# advisory/device pair (never run automatically as part of a scan). Takes the
# advisory's own (often vendor-generic) workaround prose plus this device's
# actual observed command output, and asks the model to draft concrete CLI
# commands. The result is tagged source="llm_synthesized" and must be shown
# to the operator with that provenance -- it is a draft to review, not
# vendor guidance.

def generate_device_specific_remediation(advisory_profile: dict, device: dict, command_outputs: dict) -> dict:
    if not openai_client:
        raise RuntimeError("AzureChatOpenAI not available")

    workaround = (advisory_profile.get("workaround") or "").strip()
    fixed_in   = (advisory_profile.get("fixed_in") or "").strip()
    outputs_text = "\n".join(f"$ {cmd}\n{out}" for cmd, out in (command_outputs or {}).items())

    prompt = f"""You are drafting a DEVICE-SPECIFIC remediation for a Cisco PSIRT advisory.
You must ONLY translate the vendor's own guidance below into concrete CLI for
THIS device's observed configuration. Do not invent a mitigation that isn't
implied by the vendor guidance, and do not assume facts not shown in the
device output. If the vendor guidance is too vague to safely translate into
commands for this device, say so instead of guessing. Return ONLY valid JSON.

VENDOR FIX / UPGRADE PATH: {fixed_in or "not specified"}
VENDOR WORKAROUND GUIDANCE (verbatim from the advisory): {workaround or "none provided"}

DEVICE:
Hostname: {device.get('hostname', device.get('host'))}
Platform: {device.get('platform', 'Unknown')}
Software Version: {device.get('version') or device.get('dnac_version', 'Unknown')}

DEVICE'S CURRENT OBSERVED CONFIG / COMMAND OUTPUT:
{outputs_text or "(none collected)"}

Return JSON:
{{
  "can_draft_commands": true | false,
  "commands": ["exact CLI commands for this device, empty list if can_draft_commands is false"],
  "rollback": ["commands to revert the above, if applicable"],
  "rationale": "1-2 sentences: how this translates the vendor's guidance for this device's specific observed state",
  "caveats": "anything the operator should double check before applying, or why commands could not be safely drafted"
}}"""

    last_exc = None
    for attempt in range(3):
        try:
            resp = openai_client.invoke([{"role": "user", "content": prompt}])
            raw  = resp.content.replace("```json", "").replace("```", "").strip()
            drafted = json.loads(raw)
            break
        except Exception as e:
            last_exc = e
            time.sleep(2 ** attempt)
    else:
        raise last_exc

    return {
        "source":     "llm_synthesized",
        "disclaimer": "AI-drafted based on this advisory's vendor guidance and this device's "
                       "observed configuration. Review before applying -- this is not vendor guidance itself.",
        **drafted,
    }


# ── Version-only verdict (when command collection fails) ──────────────────────

def _version_only_verdict(profile: dict, device_version: str, platform: str) -> str:
    def parse_ver(v):
        v = re.sub(r'[a-zA-Z]', '', v or "")
        parts = re.split(r'[.\-]', v)
        result = []
        for p in parts:
            try:
                result.append(int(p))
            except ValueError:
                pass
        return tuple(result)

    def ver_train(v):
        m = re.match(r'(\d+\.\d+)', v or "")
        return m.group(1) if m else ""

    if not device_version or device_version.strip().lower() in ("unknown", "n/a", ""):
        device_version = ""
    if not platform or platform.strip().lower() in ("unknown", "n/a", ""):
        platform = ""

    affected_platforms = [p.lower() for p in (profile.get("affected_platforms") or [])]
    if affected_platforms and platform:
        plat_lower = platform.lower()
        IOS_XE_PREFIXES = ("c9", "c8", "c38", "c36", "c35", "c45", "c65",
                           "asr1", "isr4", "csr1", "cat9", "cat8", "ws-c")
        IOS_PREFIXES    = ("c29", "c37", "c26", "c28", "c18", "c19", "ws-c29", "ws-c37")
        NXOS_PREFIXES   = ("n9k", "n7k", "n5k", "n3k", "n2k", "nexus")
        plat_clean = plat_lower.replace(" ", "").replace(",", "")
        device_os = None
        if any(plat_clean.startswith(px) for px in IOS_XE_PREFIXES):
            device_os = "ios xe"
        elif any(plat_clean.startswith(px) for px in IOS_PREFIXES):
            device_os = "ios"
        elif any(plat_clean.startswith(px) for px in NXOS_PREFIXES):
            device_os = "nx-os"
        l1_pass = (
            any(ap in plat_lower or plat_lower in ap for ap in affected_platforms)
            or (device_os and any(device_os in ap or ap in device_os for ap in affected_platforms))
        )
        if not l1_pass:
            return "NOT_AFFECTED"

    fixed_releases = profile.get("fixed_releases") or {}
    if not fixed_releases:
        if not device_version and not platform:
            return "NEEDS_REVIEW"
        return "AFFECTED"
    if not device_version:
        return "NEEDS_REVIEW"

    device_train = ver_train(device_version)
    if not device_train:
        return "NEEDS_REVIEW"

    matched_first_fixed = None
    for train_key, first_fixed in fixed_releases.items():
        if ver_train(train_key.replace(".x", "")) == device_train:
            matched_first_fixed = first_fixed
            break

    if matched_first_fixed is None:
        return "NOT_AFFECTED"

    dev_parsed   = parse_ver(device_version)
    fixed_parsed = parse_ver(matched_first_fixed)
    if not dev_parsed or not fixed_parsed:
        return "NEEDS_REVIEW"
    return "NOT_AFFECTED" if dev_parsed >= fixed_parsed else "AFFECTED"


# ── DNAC Command Runner ───────────────────────────────────────────────────────

def dnac_run_commands(host: str, token: str, device_uuid: str,
                      commands: list, verify_ssl: bool,
                      poll_interval: int = 3, max_wait: int = 120) -> dict:
    headers = {"X-Auth-Token": token, "Content-Type": "application/json"}
    payload = {"commands": commands, "deviceUuids": [device_uuid]}
    url = f"https://{host}/dna/intent/api/v1/network-device-poller/cli/read-request"
    resp = requests.post(url, headers=headers, json=payload, verify=verify_ssl, timeout=30)
    resp.raise_for_status()

    task_id = resp.json().get("response", {}).get("taskId")
    if not task_id:
        raise RuntimeError("DNAC Command Runner did not return a taskId")

    task_url = f"https://{host}/dna/intent/api/v1/task/{task_id}"
    elapsed  = 0
    file_id  = None
    while elapsed < max_wait:
        time.sleep(poll_interval)
        elapsed += poll_interval
        t = requests.get(task_url, headers=headers, verify=verify_ssl, timeout=15).json()
        task_data = t.get("response", {})
        if task_data.get("isError"):
            raise RuntimeError(f"Command Runner task error: {task_data.get('failureReason', task_data.get('progress', 'unknown'))}")
        progress  = task_data.get("progress", "")
        completed = bool(task_data.get("endTime"))
        if not completed:
            try:
                prog_json = json.loads(progress)
                if prog_json.get("fileId"):
                    completed = True
            except Exception:
                pass
        if completed:
            try:
                file_id = json.loads(progress).get("fileId")
            except Exception:
                file_id = progress.strip() if progress.strip() else None
            break

    if not file_id:
        raise RuntimeError("Command Runner task did not complete in time")

    file_resp = requests.get(
        f"https://{host}/dna/intent/api/v1/file/{file_id}",
        headers=headers, verify=verify_ssl, timeout=30)
    file_resp.raise_for_status()

    outputs = {}
    for entry in file_resp.json():
        for status_key in ("SUCCESS", "FAILURE", "success", "failure"):
            for cmd, out in entry.get("commandResponses", {}).get(status_key, {}).items():
                outputs[cmd] = out
    return outputs


_DNAC_JS_ERROR_MARKER   = "Failed to execute JavaScript"
_DNAC_AUTH_ERROR_MARKER = "Authentication failed during the login attempt"


def dnac_collect(dnac_host: str, token: str, device_uuid: str,
                 commands: list, verify_ssl: bool) -> dict:
    try:
        outputs = dnac_run_commands(dnac_host, token, device_uuid, commands, verify_ssl)
        for marker, label in [
            (_DNAC_JS_ERROR_MARKER,   "DNAC JS template error ($finaMap)"),
            (_DNAC_AUTH_ERROR_MARKER, "DNAC authentication error on device"),
        ]:
            failed = [cmd for cmd, out in outputs.items() if marker in str(out)]
            if failed and len(failed) == len(outputs):
                return {"status": "error",
                        "error": f"{label} — SSH fallback needed. Sample: {outputs[failed[0]][:200]}"}
            for cmd in failed:
                outputs.pop(cmd)
        return {"status": "success", "outputs": outputs}
    except requests.exceptions.HTTPError as e:
        code = e.response.status_code if e.response is not None else 0
        if code == 403:
            return {"status": "error",
                    "error": "DNAC Command Runner returned 403 — check Network Automation license"}
        return {"status": "error", "error": f"DNAC HTTP {code}: {e}"}
    except Exception as e:
        return {"status": "error", "error": str(e)}


# ── SSH fallback ──────────────────────────────────────────────────────────────

def ssh_collect(ssh_cfg: dict, commands: list) -> dict:
    if not _NETMIKO_AVAILABLE:
        return {"status": "error", "error": "netmiko not installed"}
    try:
        conn    = ConnectHandler(**ssh_cfg)
        outputs = {}
        for cmd in commands:
            try:
                outputs[cmd] = conn.send_command(cmd, read_timeout=30)
            except Exception as e:
                outputs[cmd] = f"[ERROR running command: {e}]"
        conn.disconnect()
        return {"status": "success", "outputs": outputs}
    except NetmikoAuthenticationException:
        return {"status": "error", "error": "SSH authentication failed — check credentials"}
    except NetmikoTimeoutException:
        return {"status": "error", "error": "SSH timed out — check host/port/reachability"}
    except Exception as e:
        return {"status": "error", "error": str(e)}


# ── DNAC API helpers ──────────────────────────────────────────────────────────

def _dnac_device_type(family: str, series: str) -> str:
    for key, dtype in DNAC_DEVICE_TYPE_MAP.items():
        if key.lower() in (series or "").lower() or key.lower() in (family or "").lower():
            return dtype
    combined = f"{family} {series}".lower()
    if "nxos" in combined or "nexus" in combined:
        return "cisco_nxos"
    if "xr" in combined or "asr 9" in combined or "ncs" in combined:
        return "cisco_xr"
    return "cisco_xe"


def dnac_get_token(host: str, username: str, password: str, verify_ssl: bool) -> str:
    resp = requests.post(
        f"https://{host}/dna/system/api/v1/auth/token",
        auth=(username, password), verify=verify_ssl, timeout=15)
    resp.raise_for_status()
    return resp.json()["Token"]


def dnac_get_devices(host: str, token: str, verify_ssl: bool) -> list:
    headers = {"X-Auth-Token": token, "Content-Type": "application/json"}
    devices, offset, limit = [], 1, 500
    while True:
        resp = requests.get(
            f"https://{host}/dna/intent/api/v1/network-device?offset={offset}&limit={limit}",
            headers=headers, verify=verify_ssl, timeout=30)
        resp.raise_for_status()
        page = resp.json().get("response", [])
        if not page:
            break
        devices.extend(page)
        if len(page) < limit:
            break
        offset += limit
    return devices


def dnac_get_advisories(host: str, token: str, verify_ssl: bool) -> list:
    headers = {"X-Auth-Token": token, "Content-Type": "application/json"}
    resp = requests.get(
        f"https://{host}/dna/intent/api/v1/security-advisory/advisory",
        headers=headers, verify=verify_ssl, timeout=30)
    resp.raise_for_status()
    return resp.json().get("response", [])


def dnac_get_device_by_id(host: str, token: str, device_id: str, verify_ssl: bool) -> dict:
    headers = {"X-Auth-Token": token, "Content-Type": "application/json"}
    resp = requests.get(
        f"https://{host}/dna/intent/api/v1/network-device/{device_id}",
        headers=headers, verify=verify_ssl, timeout=15)
    resp.raise_for_status()
    return resp.json().get("response", {})


def dnac_get_advisory_affected_devices(host: str, token: str, advisory_id: str, verify_ssl: bool) -> list:
    headers = {"X-Auth-Token": token, "Content-Type": "application/json"}
    resp = requests.get(
        f"https://{host}/dna/intent/api/v1/security-advisory/advisory/{advisory_id}/device",
        headers=headers, verify=verify_ssl, timeout=30)
    resp.raise_for_status()
    return resp.json().get("response", [])


# ── DB persistence helper (shared by both job runners) ────────────────────────

def _db_persist_result(advisory_id: str, device_id: str, dnac_id, result: dict) -> None:
    if not advisory_id or not device_id:
        return
    try:
        from psirt.db_queries import update_applicability_result, upsert_applicability_pending
    except Exception:
        return

    def _layer_str(val) -> str:
        if isinstance(val, dict):
            return val.get("result", "")
        return str(val) if val else ""

    try:
        upsert_applicability_pending(
            advisory_id       = advisory_id,
            device_id         = device_id,
            hostname          = result.get("hostname", ""),
            management_ip     = result.get("host", ""),
            platform          = result.get("platform", ""),
            software_version  = result.get("version") or result.get("dnac_version", ""),
            dnac_id           = dnac_id,
            scan_triggered_at = result.get("timestamp", datetime.utcnow().isoformat()),
        )
        update_applicability_result(
            advisory_id        = advisory_id,
            device_id          = device_id,
            dnac_id            = dnac_id,
            verdict            = result.get("verdict", "NEEDS_REVIEW"),
            summary            = result.get("summary", ""),
            evidence           = result.get("evidence", ""),
            layer1             = _layer_str(result.get("layer1", "")),
            layer2             = _layer_str(result.get("layer2", "")),
            layer3             = _layer_str(result.get("layer3", "")),
            layer4             = _layer_str(result.get("layer4", "")),
            collection_method  = result.get("collection_method", ""),
            action             = result.get("action", ""),
            mitigation         = result.get("mitigation"),
            needs_review_reason= result.get("needs_review_reason", ""),
            remediation        = result.get("remediation"),
        )
        logger.debug("[DB] Persisted %s x %s -> %s", advisory_id, device_id, result.get("verdict"))
    except Exception as exc:
        logger.debug("[DB] Persist failed for %s x %s: %s", advisory_id, device_id, exc)


# ── Single-advisory job runner ────────────────────────────────────────────────

def run_job(job_id: str, advisory_text: str, devices: list):
    job = _get_job(job_id) or {}
    job["status"]     = "running"
    job["started_at"] = datetime.utcnow().isoformat()
    _set_job(job_id, job)

    try:
        job.setdefault("log", []).append("Extracting advisory profile…")
        profile = extract_advisory_profile(advisory_text, advisory_id="")
        job["advisory_profile"] = profile
        job["log"].append(f"Advisory parsed: {profile.get('cve')} — feature: {profile.get('vulnerable_feature')}")
        _set_job(job_id, job)
    except Exception as e:
        job["status"] = "failed"
        job["error"]  = f"Failed to parse advisory: {e}"
        _set_job(job_id, job)
        return

    advisory_cmds = profile.get("verification_commands") or []
    feature_key   = (profile.get("vulnerable_feature") or "").lower()
    commands = list(set(ALWAYS_RUN + advisory_cmds)) if advisory_cmds else list(set(
        ALWAYS_RUN + FEATURE_COMMANDS.get(feature_key, FEATURE_COMMANDS["default"])))
    job["log"].append(f"Will run {len(commands)} commands per device.")
    _set_job(job_id, job)

    results = []
    for i, device in enumerate(devices):
        hostname = device.get("hostname") or device.get("host")
        job["log"].append(f"[{i+1}/{len(devices)}] Collecting from {hostname}…")

        device_result = {
            "hostname":  hostname,
            "host":      device.get("host"),
            "platform":  device.get("platform", "Unknown"),
            "version":   device.get("version", "Unknown"),
            "timestamp": datetime.utcnow().isoformat(),
            # Tier-1 remediation: extracted verbatim from the advisory, not LLM-generated.
            "remediation": build_remediation_tier1(profile),
        }

        dnac_id   = device.get("dnac_id", "")
        dnac_host = device.get("dnac_host", "")
        dnac_user = device.get("dnac_username", "")
        dnac_pass = device.get("dnac_password", "")
        verify_ssl = device.get("dnac_verify_ssl", False)

        if dnac_id and dnac_host and dnac_user and dnac_pass:
            try:
                token  = dnac_get_token(dnac_host, dnac_user, dnac_pass, verify_ssl)
                result = dnac_collect(dnac_host, token, dnac_id, commands, verify_ssl)
            except Exception as e:
                result = {"status": "error", "error": str(e)}
            method = "dnac_command_runner"
        else:
            ssh_cfg = {
                "host":         device["host"],
                "port":         int(device.get("port", 22)),
                "username":     device.get("username", ""),
                "password":     device.get("password", ""),
                "device_type":  device.get("device_type", "cisco_ios"),
                "timeout":      30,
                "auth_timeout": 20,
            }
            result = ssh_collect(ssh_cfg, commands)
            method = "ssh"

        device_result["collection_method"] = method
        if result["status"] == "error":
            device_result["verdict"] = "NEEDS_REVIEW"
            device_result["summary"] = f"Collection failed ({method}): {result['error']}"
            device_result["needs_review_reason"] = "collection_failed"
            job["log"].append(f"  ✗ {result['error']}")
        else:
            device_result["command_outputs"] = result["outputs"]
            job["log"].append("  ✓ Collected — analysing…")
            try:
                analysis = analyse_applicability(profile, device, result["outputs"])
                device_result.update(analysis)
                job["log"].append(f"  → Verdict: {analysis.get('verdict')}")
            except Exception as e:
                device_result["verdict"] = "NEEDS_REVIEW"
                device_result["summary"] = f"Analysis failed: {e}"
                device_result["needs_review_reason"] = "insufficient_data"

        _adv_id  = profile.get("advisory_id") or profile.get("cve") or ""
        _dev_id  = device.get("dnac_id") or device.get("host", hostname)
        _dnac_id = device.get("dnac_host") or None
        _db_persist_result(_adv_id, _dev_id, _dnac_id, device_result)

        results.append(device_result)
        job["results"]  = results
        job["progress"] = round((i + 1) / len(devices) * 100)
        _set_job(job_id, job)

    counts = {"AFFECTED": 0, "NOT_AFFECTED": 0, "NEEDS_REVIEW": 0}
    for r in results:
        counts[r.get("verdict", "NEEDS_REVIEW")] = counts.get(r.get("verdict", "NEEDS_REVIEW"), 0) + 1
    job["status"]       = "done"
    job["finished_at"]  = datetime.utcnow().isoformat()
    job["summary_counts"] = counts
    _set_job(job_id, job)


# ── Bulk DNAC job runner ──────────────────────────────────────────────────────

def run_dnac_bulk_job(job_id: str, dnac_host: str, dnac_user: str, dnac_pass: str,
                      verify_ssl: bool, advisory_ids_filter=None,
                      ssh_username: str = "", ssh_password: str = "",
                      force_refresh: bool = False):
    job = _get_job(job_id) or {}
    job["status"]     = "running"
    job["started_at"] = datetime.utcnow().isoformat()
    _set_job(job_id, job)
    try:
        _run_dnac_bulk_job_inner(job_id, job, dnac_host, dnac_user, dnac_pass,
                                 verify_ssl, advisory_ids_filter, ssh_username, ssh_password,
                                 force_refresh=force_refresh)
    except Exception as e:
        job["status"] = "failed"
        job["error"]  = f"Unexpected error: {e}"
        job.setdefault("log", []).append(f"✗ Job crashed: {e}")
        _set_job(job_id, job)


def _run_dnac_bulk_job_inner(job_id, job, dnac_host, dnac_user, dnac_pass,
                              verify_ssl, advisory_ids_filter,
                              ssh_username="", ssh_password="",
                              force_refresh=False):
    try:
        job["log"].append("Authenticating to DNAC…")
        token = dnac_get_token(dnac_host, dnac_user, dnac_pass, verify_ssl)
        token_issued_at = time.time()
        job["log"].append("DNAC authentication successful.")
        _set_job(job_id, job)
    except Exception as e:
        job["status"] = "failed"
        job["error"]  = f"DNAC auth failed: {e}"
        _set_job(job_id, job)
        return

    token_state = {"token": token, "issued_at": token_issued_at}

    def fresh_token():
        if time.time() - token_state["issued_at"] > 1500:
            try:
                token_state["token"] = dnac_get_token(dnac_host, dnac_user, dnac_pass, verify_ssl)
                token_state["issued_at"] = time.time()
                job["log"].append("  ↻ DNAC token refreshed.")
            except Exception as _te:
                job["log"].append(f"  ⚠ Token refresh failed: {_te}")
        return token_state["token"]

    try:
        job["log"].append("Fetching advisories from DNAC…")
        raw_advisories = dnac_get_advisories(dnac_host, token_state["token"], verify_ssl)
        job["log"].append(f"Found {len(raw_advisories)} advisories in DNAC.")
        _set_job(job_id, job)
    except Exception as e:
        job["status"] = "failed"
        job["error"]  = f"Failed to fetch advisories: {e}"
        _set_job(job_id, job)
        return

    pairs = []
    for adv in raw_advisories:
        advisory_id = adv.get("advisoryId", "")
        if not advisory_id:
            continue
        if advisory_ids_filter and advisory_id not in advisory_ids_filter:
            continue
        try:
            affected = dnac_get_advisory_affected_devices(dnac_host, token_state["token"], advisory_id, verify_ssl)
            if affected:
                job["log"].append(f"Advisory {advisory_id}: {len(affected)} impacted device(s).")
                for dev in affected:
                    if isinstance(dev, str):
                        uuid = dev
                        dev  = None
                        try:
                            dev = dnac_get_device_by_id(dnac_host, token_state["token"], uuid, verify_ssl)
                        except requests.exceptions.HTTPError as _he:
                            if _he.response is not None and _he.response.status_code not in (403, 404):
                                job["log"].append(f"  ⚠ UUID {uuid}: HTTP error {_he}")
                        except Exception as _e:
                            job["log"].append(f"  ⚠ UUID {uuid}: lookup failed ({_e})")

                        if not dev:
                            try:
                                _h = {"X-Auth-Token": token_state["token"], "Content-Type": "application/json"}
                                _r = requests.get(
                                    f"https://{dnac_host}/dna/intent/api/v1/security-devices/{uuid}",
                                    headers=_h, verify=verify_ssl, timeout=15)
                                if _r.status_code == 200:
                                    dev = _r.json().get("response", {})
                                    if dev:
                                        dev["family"] = dev.get("deviceType", "ASA/FTD")
                            except Exception:
                                pass

                        if not dev:
                            dev = {"id": uuid, "hostname": uuid, "managementIpAddress": "",
                                   "softwareVersion": "", "platformId": "", "_uuid_only": True}
                        elif not dev.get("managementIpAddress") and not dev.get("platformId"):
                            dev["_uuid_only"] = True

                    if ssh_username and "username" not in dev:
                        dev = dict(dev)
                        dev["username"] = ssh_username
                        dev["password"] = ssh_password
                    pairs.append((adv, dev))
            else:
                job["log"].append(f"Advisory {advisory_id}: 0 impacted devices — skipping.")
        except Exception as e:
            job["log"].append(f"Advisory {advisory_id}: could not fetch devices ({e}) — skipping.")
        _set_job(job_id, job)

    if not pairs:
        job["status"] = "done"
        job["log"].append("No advisory-device pairs found in DNAC.")
        job["summary_counts"] = {"AFFECTED": 0, "NOT_AFFECTED": 0, "NEEDS_REVIEW": 0}
        _set_job(job_id, job)
        return

    job["log"].append(f"Total pairs to assess: {len(pairs)}")
    job["total_pairs"] = len(pairs)
    _set_job(job_id, job)

    _uuid_type_cache: dict = {}
    for adv_meta, dev_meta in pairs:
        _uuid = dev_meta.get("id", "")
        if not _uuid or _uuid in _uuid_type_cache:
            continue
        _aid = adv_meta.get("advisoryId", "").lower()
        if "asa" in _aid or "ftd" in _aid:
            _uuid_type_cache[_uuid] = "asa_ftd"
        elif dev_meta.get("family") or dev_meta.get("platformId"):
            _uuid_type_cache[_uuid] = "ios"

    results = []
    for i, (adv, dev) in enumerate(pairs):
        advisory_id = adv.get("advisoryId", "")
        hostname    = dev.get("hostname") or dev.get("managementIpAddress", "unknown")
        device_uuid = dev.get("id", "")
        token       = fresh_token()

        job["log"].append(f"[{i+1}/{len(pairs)}] {advisory_id} × {hostname}…")
        job["progress"] = round((i + 1) / len(pairs) * 100)
        _set_job(job_id, job)

        pair_result = {
            "advisory_id":      advisory_id,
            "cves":             adv.get("cves", []),
            "sir":              adv.get("sir", ""),
            "cvss":             adv.get("cvssBaseScore", ""),
            "publication_url":  adv.get("publicationUrl", ""),
            "hostname":         hostname,
            "host":             dev.get("managementIpAddress", ""),
            "platform":         dev.get("platformId", dev.get("series", "")),
            "dnac_version":     dev.get("softwareVersion", ""),
            "dnac_family":      dev.get("family", ""),
            "dnac_reachability": dev.get("reachabilityStatus", ""),
            "timestamp":        datetime.utcnow().isoformat(),
            "dnac_impacted":    True,
        }

        cached_profile = None if force_refresh else get_advisory_profile_from_cache(advisory_id)
        if cached_profile:
            job["log"].append("  ✓ Profile from ChromaDB cache.")
            profile = cached_profile
        else:
            if force_refresh:
                job["log"].append("  ↻ Force refresh — ignoring cached profile, re-extracting from advisory text.")
            dnac_summary = (
                f"Advisory ID: {advisory_id}\n"
                f"CVE(s): {', '.join(adv.get('cves', [])) or adv.get('cveId', 'N/A')}\n"
                f"Security Impact Rating: {adv.get('sir', 'N/A')}\n"
                f"CVSS Base Score: {adv.get('cvssBaseScore', 'N/A')}\n"
                f"Publication URL: {adv.get('publicationUrl', 'N/A')}\n"
                f"Detection Type: {adv.get('defaultDetectionType', 'N/A')}\n"
            )
            cisco_full = fetch_cisco_advisory_text(advisory_id)
            advisory_text = (dnac_summary + "\n\n--- Full Cisco Advisory ---\n" + cisco_full
                             if cisco_full else dnac_summary)
            try:
                profile = extract_advisory_profile(advisory_text, advisory_id=advisory_id, force_refresh=force_refresh)
            except Exception as e:
                err_str = f"{type(e).__name__}: {e}"
                job["log"].append(f"  ✗ GPT unavailable — {err_str}")
                profile = {
                    "advisory_id": advisory_id,
                    "cve": (adv.get("cves") or [adv.get("cveId", "N/A")])[0],
                    "title": advisory_id,
                    "vulnerable_feature": adv.get("defaultDetectionType", "unknown").lower(),
                    "affected_platforms": [], "affected_versions": [], "fixed_releases": {},
                    "fixed_in": "", "impact": f"Parsing failed: {err_str}",
                    "workaround": None, "verification_commands": [],
                }
                v = _version_only_verdict(profile, pair_result.get("dnac_version", ""),
                                          pair_result.get("platform", ""))
                pair_result["verdict"] = v if v in ("AFFECTED", "NOT_AFFECTED") else "NEEDS_REVIEW"
                pair_result["summary"] = f"GPT unavailable. Version-only → {pair_result['verdict']}."
                pair_result["remediation"] = build_remediation_tier1(profile)
                results.append(pair_result)
                job["results"] = results
                _set_job(job_id, job)
                continue

        pair_result["advisory_profile"] = profile
        pair_result["remediation"] = build_remediation_tier1(profile)

        advisory_cmds = profile.get("verification_commands") or []
        feature_key   = (profile.get("vulnerable_feature") or "").lower()
        commands = list(set(ALWAYS_RUN + advisory_cmds)) if advisory_cmds else list(set(
            ALWAYS_RUN + FEATURE_COMMANDS.get(feature_key, FEATURE_COMMANDS["default"])))

        collection_method = "dnac_command_runner"
        collect_result = (dnac_collect(dnac_host, token, device_uuid, commands, verify_ssl)
                          if device_uuid else
                          {"status": "error", "error": "No DNAC device UUID"})

        if collect_result["status"] == "error":
            dev_host = dev.get("managementIpAddress") or dev.get("host", "")
            dev_user = dev.get("username", "")
            dev_pass = dev.get("password", "")

            if not dev_host and device_uuid:
                try:
                    d2 = dnac_get_device_by_id(dnac_host, fresh_token(), device_uuid, verify_ssl)
                    if d2:
                        dev_host = d2.get("managementIpAddress", "")
                        if d2.get("hostname"):
                            pair_result["hostname"] = d2["hostname"]
                        if d2.get("platformId"):
                            pair_result["platform"] = d2["platformId"]
                        if d2.get("softwareVersion"):
                            pair_result["dnac_version"] = d2["softwareVersion"]
                except Exception:
                    pass

            dnac_err = collect_result["error"]
            if dev_host and dev_user and dev_pass:
                job["log"].append(f"  ⚠ DNAC CR failed ({dnac_err}) — retrying SSH…")
                ssh_cfg = {
                    "host":         dev_host,
                    "port":         int(dev.get("port", 22)),
                    "username":     dev_user,
                    "password":     dev_pass,
                    "device_type":  dev.get("device_type") or _dnac_device_type(
                                        dev.get("family", ""), dev.get("series", "")),
                    "timeout":      30,
                    "auth_timeout": 20,
                }
                collect_result    = ssh_collect(ssh_cfg, commands)
                collection_method = "ssh_fallback"
                if collect_result["status"] == "error":
                    job["log"].append(f"  ✗ SSH also failed: {collect_result['error']}")
                else:
                    job["log"].append("  ✓ SSH succeeded.")
            else:
                job["log"].append(f"  ✗ DNAC failed ({dnac_err}) — no SSH fallback available.")

        pair_result["collection_method"] = collection_method

        if collect_result["status"] == "error":
            pair_result["collection_status"] = "failed"
            pair_result["collection_error"]  = collect_result["error"]
            device_version = pair_result.get("dnac_version", "")
            fixed_releases = profile.get("fixed_releases") or {}
            version_verdict = _version_only_verdict(profile, device_version, pair_result.get("platform", ""))

            if version_verdict == "AFFECTED":
                reason = ("No fixed release published yet." if not fixed_releases
                          else "Device version is below the first fixed release.")
                pair_result["verdict"] = "AFFECTED"
                pair_result["summary"] = (f"Collection failed ({collect_result['error']}). "
                                          f"Version-only → AFFECTED. {reason}")
                pair_result["evidence"] = f"fixed_releases={fixed_releases}, device_version={device_version}"
                pair_result["needs_review_reason"] = ""
            elif version_verdict == "NOT_AFFECTED":
                pair_result["verdict"] = "NOT_AFFECTED"
                pair_result["summary"] = (f"Collection failed ({collect_result['error']}). "
                                          f"Version-only: {device_version} >= first fixed → NOT_AFFECTED.")
                pair_result["evidence"] = f"fixed_releases={fixed_releases}, device_version={device_version}"
                pair_result["needs_review_reason"] = ""
            else:
                adv_platforms = [p.lower() for p in (profile.get("affected_platforms") or [])]
                dev_family    = (dev.get("family", "") or "").lower()
                adv_covers_asa = any(x in " ".join(adv_platforms)
                                     for x in ("asa", "ftd", "firewall", "firepower", "secure firewall"))
                is_asa_ftd = (
                    any(x in dev_family for x in ("asa", "ftd", "firepower", "firewall", "security"))
                    or "asa" in advisory_id.lower() or "ftd" in advisory_id.lower()
                    or _uuid_type_cache.get(device_uuid) == "asa_ftd"
                )
                if is_asa_ftd and adv_covers_asa and not fixed_releases:
                    pair_result["verdict"] = "AFFECTED"
                    pair_result["summary"] = "ASA/FTD device — advisory covers ASA/FTD, no fix published → AFFECTED."
                    pair_result["needs_review_reason"] = ""
                elif is_asa_ftd and adv_covers_asa:
                    pair_result["verdict"] = "NEEDS_REVIEW"
                    pair_result["summary"] = "ASA/FTD device — no version data to compare. Manual review required."
                    pair_result["needs_review_reason"] = "insufficient_data"
                else:
                    pair_result["verdict"] = "NOT_AFFECTED"
                    pair_result["summary"] = "Collection failed and insufficient version data → NOT_AFFECTED."
                    pair_result["needs_review_reason"] = ""
        else:
            pair_result["collection_status"] = "success"
            pair_result["command_outputs"]   = collect_result["outputs"]
            job["log"].append("  ✓ Commands collected — analysing…")
            try:
                analysis = analyse_applicability(
                    profile, {"hostname": hostname, "platform": pair_result["platform"],
                              "version": pair_result["dnac_version"]},
                    collect_result["outputs"])
                pair_result.update(analysis)
                verdict  = analysis.get("verdict", "NEEDS_REVIEW")
                fp_label = " ← FALSE POSITIVE" if verdict == "NOT_AFFECTED" else ""
                job["log"].append(f"  → Verdict: {verdict}{fp_label}")
                pair_result["needs_review_reason"] = "insufficient_data" if verdict == "NEEDS_REVIEW" else ""
            except Exception as e:
                pair_result["verdict"] = "NEEDS_REVIEW"
                pair_result["summary"] = f"GPT analysis failed: {e}"
                pair_result["needs_review_reason"] = "insufficient_data"

        _db_persist_result(
            advisory_id = advisory_id,
            device_id   = device_uuid or hostname,
            dnac_id     = None,
            result      = {**pair_result,
                           "host":     pair_result.get("host", ""),
                           "version":  pair_result.get("dnac_version", ""),
                           "platform": pair_result.get("platform", "")},
        )

        results.append(pair_result)
        job["results"] = results
        _set_job(job_id, job)

    counts = {"AFFECTED": 0, "NOT_AFFECTED": 0, "NEEDS_REVIEW": 0}
    for r in results:
        v = r.get("verdict", "NEEDS_REVIEW")
        counts[v] = counts.get(v, 0) + 1
    job["status"]        = "done"
    job["finished_at"]   = datetime.utcnow().isoformat()
    job["summary_counts"] = counts
    job["log"].append(f"Done. Confirmed: {counts['AFFECTED']} | "
                      f"False Positives: {counts['NOT_AFFECTED']} | "
                      f"Needs Review: {counts['NEEDS_REVIEW']}")
    _set_job(job_id, job)


# ═══════════════════════════════════════════════════════════════════════════
# ── Views ──────────────────────────────────────────────────────────────────
# ═══════════════════════════════════════════════════════════════════════════

def _json_body(request) -> dict:
    if not request.body:
        return {}
    try:
        return json.loads(request.body)
    except Exception:
        return {}


@require_POST
def psirt_chat(request):
    data     = _json_body(request)
    user_msg = (data.get("message") or "").strip()
    if not user_msg:
        return JsonResponse({"error": "Empty message"}, status=400)

    _append_history(request, "user", user_msg)
    agent = get_agent()
    if agent is None:
        reply = "⚠️ Agent could not be initialised. Check server logs."
    else:
        try:
            reply = agent.ask(user_msg)
        except Exception as exc:
            logger.error("Agent error: %s", exc, exc_info=True)
            reply = f"⚠️ Error processing your request: {exc}"

    _append_history(request, "assistant", reply)
    return JsonResponse({"reply": reply})


@require_GET
def psirt_history(request):
    return JsonResponse(_session_history(request), safe=False)


@require_POST
def psirt_clear(request):
    request.session.pop("history", None)
    return JsonResponse({"status": "cleared"})


@require_GET
def psirt_applicability_summary(request):
    dnac_id = request.GET.get("dnac_id") or None
    summary = _get_applicability_summary(dnac_id)
    if summary is None:
        return JsonResponse({"error": "PSIRT module unavailable"}, status=503)
    return JsonResponse(summary)


@require_GET
def psirt_device_advisories(request):
    device_id = request.GET.get("device_id", "").strip()
    dnac_id   = request.GET.get("dnac_id") or None
    if not device_id:
        return JsonResponse({"error": "device_id required"}, status=400)
    rows = _get_device_advisories(device_id, dnac_id)
    return JsonResponse({"device_id": device_id, "dnac_id": dnac_id, "advisories": rows})


@require_GET
def psirt_diagnose(request):
    dnac_id = request.GET.get("dnac_id") or None
    try:
        from psirt.db_queries import get_verdict_breakdown, get_needs_review_detail
        breakdown = get_verdict_breakdown(dnac_id=dnac_id)
        nr_detail = get_needs_review_detail(dnac_id=dnac_id)

        methods = {}
        for r in breakdown:
            m = r.get("collection_method") or "unknown"
            methods[m] = methods.get(m, 0) + 1

        nr_reasons = {}
        for r in breakdown:
            if r.get("verdict") == "NEEDS_REVIEW":
                reason = r.get("needs_review_reason") or "unknown"
                nr_reasons[reason] = nr_reasons.get(reason, 0) + 1

        return JsonResponse({
            "dnac_id":              dnac_id,
            "total_checked":        len(breakdown),
            "collection_methods":   methods,
            "needs_review_count":   len(nr_detail),
            "needs_review_reasons": nr_reasons,
            "needs_review_detail":  nr_detail,
            "breakdown":            breakdown,
        })
    except Exception as exc:
        return JsonResponse({"error": str(exc)}, status=500)


@require_POST
def psirt_trigger_scan(request):
    data         = _json_body(request)
    dnac_id      = data.get("dnac_id")      or None
    ssh_username = data.get("ssh_username") or ""
    ssh_password = data.get("ssh_password") or ""
    ssh_port     = int(data.get("ssh_port") or 22)

    try:
        from run_scan import run_scan as _run_scan
        result      = _run_scan(dnac_id=dnac_id, wait=False,
                                ssh_username=ssh_username,
                                ssh_password=ssh_password,
                                ssh_port=ssh_port)
        status_code = 200 if result["status"] == "ok" else 500
        return JsonResponse(result, status=status_code)
    except Exception as exc:
        logger.error("trigger_scan error: %s", exc, exc_info=True)
        return JsonResponse({"status": "error", "error": str(exc)}, status=500)


@require_GET
def psirt_status(request):
    agent = get_agent()
    return JsonResponse({
        "agent_ready":  agent is not None,
        "psirt_module": _psirt_available(),
        "timestamp":    datetime.utcnow().isoformat(),
    })


@require_POST
def psirt_assess(request):
    """Start a single-advisory assessment job."""
    data          = _json_body(request)
    advisory_text = data.get("advisory_text", "").strip()
    devices       = data.get("devices", [])
    if not advisory_text:
        return JsonResponse({"error": "advisory_text is required"}, status=400)
    if not devices:
        return JsonResponse({"error": "at least one device is required"}, status=400)

    job_id = datetime.utcnow().strftime("%Y%m%d_%H%M%S_%f")
    job = {
        "job_id": job_id, "status": "queued", "progress": 0,
        "log": [], "results": [], "advisory_profile": {},
        "summary_counts": {}, "created_at": datetime.utcnow().isoformat(),
    }
    _set_job(job_id, job)
    _register_job(job_id)
    threading.Thread(target=run_job, args=(job_id, advisory_text, devices), daemon=True).start()
    return JsonResponse({"job_id": job_id})


@require_GET
def psirt_job_status(request, job_id):
    job = _get_job(job_id)
    if not job:
        return JsonResponse({"error": "Job not found"}, status=404)
    return JsonResponse(job)


@require_GET
def psirt_job_export(request, job_id):
    job = _get_job(job_id)
    if not job:
        return JsonResponse({"error": "Job not found"}, status=404)
    if job.get("job_type") == "dnac_bulk":
        export = {
            "export_meta": {"tool": "PSIRT Applicability Manager", "job_id": job_id,
                            "job_type": "dnac_bulk", "exported_at": datetime.utcnow().isoformat()},
            "summary": job.get("summary_counts", {}),
            "total_pairs": job.get("total_pairs", len(job.get("results", []))),
            "pairs": job.get("results", []),
        }
    else:
        export = {
            "export_meta": {"tool": "PSIRT Applicability Manager", "job_id": job_id,
                            "exported_at": datetime.utcnow().isoformat()},
            "advisory": job.get("advisory_profile", {}),
            "summary":  job.get("summary_counts", {}),
            "devices":  job.get("results", []),
        }
    response = HttpResponse(json.dumps(export, indent=2), content_type="application/json")
    response["Content-Disposition"] = f'attachment; filename="psirt_results_{job_id}.json"'
    return response


@require_GET
def psirt_jobs_list(request):
    ids = cache.get(_job_index_key()) or []
    summary = []
    for jid in ids:
        j = _get_job(jid)
        if not j:
            continue
        summary.append({
            "job_id": jid, "status": j["status"], "progress": j["progress"],
            "device_count": len(j.get("results", [])), "summary_counts": j.get("summary_counts", {}),
            "created_at": j.get("created_at"),
        })
    return JsonResponse(sorted(summary, key=lambda x: x["created_at"], reverse=True), safe=False)


@require_POST
def psirt_dnac_assess_all(request):
    data         = _json_body(request)
    host         = (data.get("host") or "").strip()
    username     = (data.get("username") or "").strip()
    password     = data.get("password", "")
    ssh_username = (data.get("ssh_username") or username).strip()
    ssh_password = data.get("ssh_password") or password
    verify_ssl   = bool(data.get("verify_ssl", False))
    advisory_ids_filter = data.get("advisory_ids", None)
    # Only meaningful (and only ever sent by the UI) when advisory_ids_filter is a
    # specific selection -- forces re-extraction for just those advisories,
    # bypassing (and then overwriting) any stale ChromaDB cache entry for them.
    force_refresh = bool(data.get("force_refresh", False))

    if not host or not username or not password:
        return JsonResponse({"error": "host, username, and password are required"}, status=400)

    job_id = "bulk_" + datetime.utcnow().strftime("%Y%m%d_%H%M%S_%f")
    job = {
        "job_id": job_id, "job_type": "dnac_bulk", "status": "queued", "progress": 0,
        "log": [], "results": [], "summary_counts": {}, "created_at": datetime.utcnow().isoformat(),
    }
    _set_job(job_id, job)
    _register_job(job_id)
    threading.Thread(
        target=run_dnac_bulk_job,
        args=(job_id, host, username, password, verify_ssl, advisory_ids_filter,
              ssh_username, ssh_password),
        kwargs={"force_refresh": force_refresh},
        daemon=True).start()
    return JsonResponse({"job_id": job_id})


@require_POST
def psirt_dnac_test(request):
    data       = _json_body(request)
    host       = (data.get("host") or "").strip()
    username   = (data.get("username") or "").strip()
    password   = data.get("password", "")
    verify_ssl = bool(data.get("verify_ssl", False))
    if not host or not username or not password:
        return JsonResponse({"error": "host, username, and password are required"}, status=400)
    try:
        dnac_get_token(host, username, password, verify_ssl)
        return JsonResponse({"status": "ok", "message": f"Connected to DNAC at {host}"})
    except requests.exceptions.ConnectionError:
        return JsonResponse({"error": f"Cannot reach DNAC at {host}"}, status=502)
    except requests.exceptions.HTTPError as e:
        status = e.response.status_code if e.response is not None else 0
        return JsonResponse({"error": f"DNAC returned HTTP {status}"}, status=502)
    except Exception as e:
        return JsonResponse({"error": str(e)}, status=500)


@require_POST
def psirt_dnac_devices(request):
    data         = _json_body(request)
    host         = (data.get("host") or "").strip()
    username     = (data.get("username") or "").strip()
    password     = data.get("password", "")
    verify_ssl   = bool(data.get("verify_ssl", False))
    ssh_username = (data.get("ssh_username") or username).strip()
    ssh_password = data.get("ssh_password") or password
    if not host or not username or not password:
        return JsonResponse({"error": "host, username, and password are required"}, status=400)
    try:
        token       = dnac_get_token(host, username, password, verify_ssl)
        raw_devices = dnac_get_devices(host, token, verify_ssl)
    except Exception as e:
        return JsonResponse({"error": str(e)}, status=502)

    formatted = []
    for d in raw_devices:
        if not d.get("managementIpAddress"):
            continue
        formatted.append({
            "host":          d.get("managementIpAddress", ""),
            "hostname":      d.get("hostname", d.get("managementIpAddress", "")),
            "port":          22,
            "username":      ssh_username,
            "password":      ssh_password,
            "device_type":   _dnac_device_type(d.get("family", ""), d.get("series", "")),
            "platform":      d.get("platformId", d.get("series", "")),
            "dnac_id":       d.get("id", ""),
            "dnac_host":     host,
            "dnac_username": username,
            "dnac_password": password,
            "dnac_verify_ssl": verify_ssl,
            "dnac_family":   d.get("family", ""),
            "dnac_series":   d.get("series", ""),
            "dnac_version":  d.get("softwareVersion", ""),
            "dnac_role":     d.get("role", ""),
            "dnac_reachability": d.get("reachabilityStatus", ""),
        })
    return JsonResponse({"count": len(formatted), "devices": formatted})


@require_POST
def psirt_dnac_advisories(request):
    data             = _json_body(request)
    host             = (data.get("host") or "").strip()
    username         = (data.get("username") or "").strip()
    password         = data.get("password", "")
    verify_ssl       = bool(data.get("verify_ssl", False))
    include_affected = bool(data.get("include_affected_devices", False))
    if not host or not username or not password:
        return JsonResponse({"error": "host, username, and password are required"}, status=400)
    try:
        token          = dnac_get_token(host, username, password, verify_ssl)
        raw_advisories = dnac_get_advisories(host, token, verify_ssl)
    except requests.exceptions.HTTPError as e:
        status = e.response.status_code if e.response is not None else 0
        if status == 403:
            return JsonResponse({"error": "DNAC 403 — Security Advisories API requires Network Security license"}, status=403)
        return JsonResponse({"error": f"DNAC HTTP {status}"}, status=502)
    except Exception as e:
        return JsonResponse({"error": str(e)}, status=500)

    formatted = []
    for adv in raw_advisories:
        advisory_id      = adv.get("advisoryId", "")
        affected_devices = []
        if include_affected and advisory_id:
            try:
                affected_devices = [
                    {"hostname": d.get("hostname", ""), "managementIp": d.get("managementIpAddress", ""),
                     "platformId": d.get("platformId", ""), "softwareVersion": d.get("softwareVersion", "")}
                    for d in dnac_get_advisory_affected_devices(host, token, advisory_id, verify_ssl)
                ]
            except Exception:
                pass
        formatted.append({
            "advisoryId":    advisory_id,
            "cveId":         adv.get("cveId") or adv.get("cves", [None])[0],
            "cves":          adv.get("cves", []),
            "publicationUrl": adv.get("publicationUrl", ""),
            "sir":           adv.get("sir", ""),
            "cvssBaseScore": adv.get("cvssBaseScore", ""),
            "defaultDetectionType": adv.get("defaultDetectionType", ""),
            "affectedDeviceCount":  adv.get("affectedDeviceCount", len(affected_devices)),
            "affectedDevices": affected_devices,
            "advisoryText": (
                f"Advisory ID: {advisory_id}\n"
                f"CVE: {', '.join(adv.get('cves', [])) or adv.get('cveId', 'N/A')}\n"
                f"CVSS Base Score: {adv.get('cvssBaseScore', 'N/A')}\n"
                f"Security Impact Rating: {adv.get('sir', 'N/A')}\n"
                f"Publication URL: {adv.get('publicationUrl', 'N/A')}\n"
            ),
        })
    return JsonResponse({"count": len(formatted), "advisories": formatted})


@require_POST
def psirt_dnac_advisory_devices(request, advisory_id):
    data         = _json_body(request)
    host         = (data.get("host") or "").strip()
    username     = (data.get("username") or "").strip()
    password     = data.get("password", "")
    verify_ssl   = bool(data.get("verify_ssl", False))
    ssh_username = (data.get("ssh_username") or username).strip()
    ssh_password = data.get("ssh_password") or password
    if not host or not username or not password:
        return JsonResponse({"error": "host, username, and password are required"}, status=400)
    try:
        token = dnac_get_token(host, username, password, verify_ssl)
        raw   = dnac_get_advisory_affected_devices(host, token, advisory_id, verify_ssl)
    except Exception as e:
        return JsonResponse({"error": str(e)}, status=502)

    formatted = [
        {
            "host":          d.get("managementIpAddress", ""),
            "hostname":      d.get("hostname", d.get("managementIpAddress", "")),
            "port":          22,
            "username":      ssh_username,
            "password":      ssh_password,
            "device_type":   _dnac_device_type(d.get("family", ""), d.get("series", "")),
            "platform":      d.get("platformId", d.get("series", "")),
            "dnac_id":       d.get("id", ""),
            "dnac_host":     host,
            "dnac_username": username,
            "dnac_password": password,
            "dnac_verify_ssl": verify_ssl,
            "dnac_version":  d.get("softwareVersion", ""),
            "dnac_reachability": d.get("reachabilityStatus", ""),
        }
        for d in raw if d.get("managementIpAddress")
    ]
    return JsonResponse({"count": len(formatted), "devices": formatted})


@require_POST
def psirt_generate_remediation(request):
    """
    Tier-2 remediation: opt-in only, never called automatically during a scan.

    Takes the advisory_profile and device/command_outputs the frontend already
    has in memory from a completed job (job.results[i]) and asks the model to
    translate the advisory's own workaround guidance into device-specific CLI.
    Always returns source="llm_synthesized" plus a disclaimer -- this is a
    draft for the operator to review, not vendor guidance itself. Tier-1
    (verbatim advisory workaround/fixed_in) is computed separately, for free,
    with no LLM call -- see build_remediation_tier1().
    """
    data = _json_body(request)
    advisory_profile = data.get("advisory_profile") or {}
    device           = data.get("device") or {}
    command_outputs  = data.get("command_outputs") or {}

    if not advisory_profile:
        return JsonResponse({"error": "advisory_profile is required"}, status=400)

    try:
        result = generate_device_specific_remediation(advisory_profile, device, command_outputs)
        return JsonResponse(result)
    except Exception as exc:
        logger.error("generate_device_specific_remediation failed: %s", exc, exc_info=True)
        return JsonResponse({"error": str(exc)}, status=500)
