"""
views.py – AI Chatbot API views for ServiceNow, Nautobot, SolarWinds and RAG pipelines.

All sensitive values (credentials, tokens, URLs) must be supplied via environment
variables.  See the inline ENV comments for the full list.
"""

# ---------------------------------------------------------------------------
# Standard library
# ---------------------------------------------------------------------------
import asyncio
import json
import logging
import os
import time
import re
import sys
import time
import urllib.parse
import tabulate as tabulate_lib
import uuid
from typing import Any, Dict, List, Optional, TypedDict

# ---------------------------------------------------------------------------
# Third-party – environment
# ---------------------------------------------------------------------------
from dotenv import load_dotenv

load_dotenv()  # Must be called before any os.getenv/os.environ access

# ---------------------------------------------------------------------------
# Third-party – Django
# ---------------------------------------------------------------------------
from django.conf import settings
from django.core.cache import cache
from django.http import HttpResponse, JsonResponse, StreamingHttpResponse
from django.views.decorators.csrf import csrf_exempt

# ---------------------------------------------------------------------------
# Third-party – DRF
# ---------------------------------------------------------------------------
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView

# ---------------------------------------------------------------------------
# Third-party – LangChain / LangGraph
# ---------------------------------------------------------------------------
from langchain_core.messages import AIMessage, HumanMessage, SystemMessage, ToolMessage
from langchain_core.output_parsers import StrOutputParser
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.tools import tool
from langchain_openai import ChatOpenAI
from langgraph.graph import END, StateGraph
from pydantic import BaseModel, Field, SecretStr
from langchain_openai import AzureChatOpenAI
import httpx

# ---------------------------------------------------------------------------
# Third-party – MCP adapters (optional – degrade gracefully if absent)
# ---------------------------------------------------------------------------
try:
    from langchain_mcp_adapters.tools import load_mcp_tools
except ImportError:
    load_mcp_tools = None

try:
    from mcp import ClientSession, StdioServerParameters
    from mcp.client.stdio import stdio_client
except ImportError:
    ClientSession = None
    StdioServerParameters = None
    stdio_client = None

try:
    from mcp.client.streamable_http import streamablehttp_client
except ImportError:
    streamablehttp_client = None

# ---------------------------------------------------------------------------
# Third-party – misc
# ---------------------------------------------------------------------------
import numpy as np
import orionsdk
import urllib.parse
from langchain_community.vectorstores.pgvector import PGVector

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Local
# ---------------------------------------------------------------------------
from .models import Conversation
from .nautobot_prompt import build_nautobot_system_prompt
# from .rag_pipeline import RAGPipeline
# try:
#     from .rag_agent_project.rag_langchain_agent import run_rag_langchain_agent
# except Exception:
#     from .rag_agent_project.rag_langchain_agent import run_rag_langchain_agent
from .servicenow_prompt import build_servicenow_system_prompt
from .services.solarwinds_service import SolarWindsService, parse_alert_string

# ---------------------------------------------------------------------------
# Vulnerability Management RAG agent
#
# vulnerebility_management is an OPTIONAL sibling package (see
# custom_chatbot/apps.py.ready(), which adds <repo_root> to sys.path only if
# it's actually present on disk) -- no longer nested inside custom_chatbot,
# so this uses the absolute dotted import instead of the old
# `from .vulnerebility_management...` relative import, which can never
# succeed post-move.
# ---------------------------------------------------------------------------
try:
    from vulnerebility_management.rag_langchain_agent import run_rag_langchain_agent
    VM_RAG_AVAILABLE = True
    logger.info("run_rag_langchain_agent imported successfully")
except Exception as _vm_import_err:
    logger.error("Could not import run_rag_langchain_agent: %s", _vm_import_err)
    VM_RAG_AVAILABLE = False
    def run_rag_langchain_agent(query: str) -> str:  # type: ignore[misc]
        return "Vulnerability management service is currently unavailable."
from .ssh_connect import async_run_ssh_command

# DNAC instances config — used by DnacInstancesView
try:
    from vulnerebility_management.config import DNAC_INSTANCES as _VM_DNAC_INSTANCES
except Exception as _dnac_cfg_err:
    logger.warning("Could not import DNAC_INSTANCES from VM config: %s", _dnac_cfg_err)
    _VM_DNAC_INSTANCES = {}

# ---------------------------------------------------------------------------
# Logging
# ---------------------------------------------------------------------------
logging.basicConfig(
    filename="application.log",
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)
logger = logging.getLogger(__name__)
file_handler = logging.FileHandler("app_25_may_3.log")
logger.addHandler(file_handler)

# ---------------------------------------------------------------------------
# Environment / configuration
# ---------------------------------------------------------------------------
# ENV: SOLARWINDS_HOST, NAUTOBOT_SOLARWINDS_USERNAME, NAUTOBOT_SOLARWINDS_PASSWORD
# ENV: OPENROUTER_API_KEY
# ENV: DB_USER, DB_PASSWORD, DB_HOST, DB_PORT, DB_NAME
# ENV: NAUTOBOT_MCP_URL, NAUTOBOT_URL, NAUTOBOT_TOKEN
# ENV: SSH_HOST, SSH_USER, SSH_PASSWORD

# SOLARWINDS_HOST = os.environ.get("SOLARWINDS_HOST", "https://172.21.17.46:17774")
# _SW_USERNAME = os.environ.get("NAUTOBOT_SOLARWINDS_USERNAME")
# _SW_PASSWORD = os.environ.get("NAUTOBOT_SOLARWINDS_PASSWORD")

DB_URL = (
    "postgresql+psycopg2://"
    f"{os.getenv('DB_USER')}:{os.getenv('DB_PASSWORD')}"
    f"@{os.getenv('DB_HOST')}:{os.getenv('DB_PORT')}"
    f"/{os.getenv('DB_NAME')}"
)

# ---------------------------------------------------------------------------
# LLM client (module-level singleton)
# ---------------------------------------------------------------------------
# llm = ChatOpenAI(
#     model="openai/gpt-4.1",
#     base_url="https://openrouter.ai/api/v1",
#     api_key=os.environ.get("OPENROUTER_API_KEY"),
# )
llm = AzureChatOpenAI(azure_deployment="gpt-5.4",
    api_version="2025-04-01-preview",
    azure_endpoint="https://git-nw-openai-llm-prod.openai.azure.com/",
    http_client=httpx.Client(verify=False),
    temperature=0,
    api_key=os.getenv("AZURE_OPENAI_API_KEY"))

# ---------------------------------------------------------------------------
# SolarWinds SWIS client (module-level singleton)
# ---------------------------------------------------------------------------
# swis = orionsdk.SwisClient("172.21.17.46", _SW_USERNAME, _SW_PASSWORD)

# ---------------------------------------------------------------------------
# RAG pipeline (module-level singleton)
# ---------------------------------------------------------------------------
_docs_path = os.path.join(settings.BASE_DIR, "nautobot/media/documents")
# logger.info("RAG docs path: %s", _docs_path)

# pipeline = RAGPipeline(
#     docs_path=_docs_path,
#     collection_name="rag_docs",
#     db_connection_string=DB_URL,
# )

# ---------------------------------------------------------------------------
# ServiceNow MCP server parameters
# ---------------------------------------------------------------------------
if StdioServerParameters is None:
    servicenow_server_params = None
else:
    servicenow_server_params = StdioServerParameters(
        command="python",
        args=["custom_chatbot/servicenow_server.py"],
    )

# ---------------------------------------------------------------------------
# SolarWinds entity relationship map
# ---------------------------------------------------------------------------
# ENTITY_RELATIONSHIPS: Dict[str, Dict[str, str]] = {
#     "Interfaces": {"Nodes": "Interfaces.NodeID = Nodes.NodeID"},
#     "Alerts": {"Nodes": "Alerts.EntityUri = Nodes.Uri"},
#     "Events": {"Nodes": "Events.NodeID = Nodes.NodeID"},
#     "Volumes": {"Nodes": "Volumes.NodeID = Nodes.NodeID"},
# }

# ---------------------------------------------------------------------------
# SWQL generation helpers
# ---------------------------------------------------------------------------

# _complex_query_prompt = ChatPromptTemplate.from_messages([
#     (
#         "system",
#         "You are a SWQL expert that writes advanced SWQL queries using SELECT, JOIN, "
#         "WHERE, ORDER BY, and aggregations.",
#     ),
#     (
#         "user",
#         """User request: {user_request}

# Available entities: {entity_list}
# Available fields: {available_fields}
# Known relationships (as joinable ON clauses):
# {relationships}

# Generate a valid SWQL query with proper:
# - SELECT fields (relevant ones)
# - JOINs if needed (using relationship mappings)
# - WHERE clauses (if user specifies filtering)
# - ORDER BY and LIMIT (if user asks for sorted/top results)

# Respond with the FULL SWQL QUERY ONLY, nothing else.
# """,
#     ),
# ])


# def fetch_available_fields(entity_name: str) -> List[str]:
#     """Return all property names for a SolarWinds entity via metadata query."""
#     metadata_query = f"SELECT Name FROM Metadata.Property WHERE EntityName = '{entity_name}'"
#     try:
#         result = swis.query(metadata_query)
#         return [row["Name"] for row in result["results"]]
#     except Exception:
#         logger.exception("Failed to fetch fields for entity '%s'", entity_name)
#         return []


# @tool
# def generate_advanced_swql(user_request: str) -> str:
#     """Use the LLM to generate a complex SWQL query with JOINs, ORDER BY, and filtering."""
#     try:
#         entity_list = list(ENTITY_RELATIONSHIPS.keys())
#         all_fields: List[str] = []
#         for entity in entity_list:
#             fields = fetch_available_fields(entity)
#             all_fields.extend(f"{entity}.{field}" for field in fields)

#         relationship_str = "\n".join(
#             f"{src}.{dst}: {join}"
#             for src, rels in ENTITY_RELATIONSHIPS.items()
#             for dst, join in rels.items()
#         )

#         query_prompt = _complex_query_prompt.format_messages(
#             user_request=user_request,
#             entity_list=", ".join(entity_list),
#             available_fields=", ".join(all_fields),
#             relationships=relationship_str,
#         )

#         response = llm.invoke(query_prompt)
#         logger.info("SWQL generated for request: %s", user_request)
#         return response.content.strip()

#     except Exception:
#         logger.exception("Failed to generate SWQL for request: %s", user_request)
#         return f"Failed to generate query for: {user_request}"


# @tool
# def run_swql_query(swql_query: str) -> str:
#     """Execute a SWQL query against SolarWinds and return the first 5 results."""
#     try:
#         result = swis.query(swql_query)
#         rows = result["results"]
#         if not rows:
#             return "No results found."
#         return str(rows[:5])
#     except Exception as exc:
#         logger.exception("Error executing SWQL query")
#         return f"Error executing SWQL: {exc}"


# solarwinds_tools = [generate_advanced_swql, run_swql_query]

# ---------------------------------------------------------------------------
# Status stream view
# ---------------------------------------------------------------------------

@csrf_exempt
def chat_status(request):
    """SSE endpoint that streams the current chatbot processing status."""
    start_time = time.time()
    # logger.info("chat_status stream initiated")

    def event_stream():
        duration = 20  # seconds
        interval = 0.3
        check_status = "Ready"

        try:
            for _ in range(int(duration / interval) + 1):
                elapsed = time.time() - start_time
                if elapsed >= duration or check_status == "Done":
                    break

                active_statuses = {
                    "Retriving Results from API",
                    "Querying ServiceNow",
                    "Querying API",
                    "Retriving ServiceNow results",
                    "Processing Data",
                    "Retriving Result",
                    "Updating Response",
                }
                if check_status not in active_statuses:
                    check_status = "Ready"

                yield f"data: {json.dumps({'status': check_status})}\n\n"
                time.sleep(interval)

            if check_status == "Done":
                yield "event: complete\ndata: {}\n\n"

        except GeneratorExit:
            logger.info("chat_status: client disconnected")
        except Exception:
            logger.exception("chat_status stream error")

    response = StreamingHttpResponse(event_stream(), content_type="text/event-stream")
    response["Cache-Control"] = "no-cache"
    return response


# ---------------------------------------------------------------------------
# ServiceNow helpers
# ---------------------------------------------------------------------------

def classify_tool(query: str) -> str:
    """Route a query to the appropriate ServiceNow tool name."""
    q = query.lower()
    if any(kw in q for kw in ["resolve", "close", "fix", "reopened", "resolved", "get", "show", "status", "details", "incident"]):
        return "get_incident"
    if "list" in q:
        return "list_incidents"
    if "update" in q:
        return "add_comment"
    return "unknown"


# def process_incident(
#     node_id: int,
#     node_name: str,
#     incident_description: Optional[str] = None,
# ) -> Dict[str, Any]:
#     """
#     Run SolarWinds health check for a node and return structured results.

#     Args:
#         node_id: SolarWinds node ID.
#         node_name: Human-readable node name.
#         incident_description: Optional raw incident text for additional context.

#     Returns:
#         Dict with 'status', 'health_data', and 'formatted_analysis' keys.
#     """
#     additional_info = parse_alert_string(incident_description) if incident_description else None
#     service = SolarWindsService()
#     result = service.check_and_analyze(
#         node_id=node_id,
#         node_name=node_name,
#         additional_info=additional_info,
#     )

#     if "error" in result:
#         return {"status": "error", "message": result["error"]}

#     return {
#         "status": "success",
#         "health_data": result,
#         "formatted_analysis": service.format_health_analysis_for_display(result),
#     }


# async def run_agent(query: str, incident_history: Optional[List] = None) -> Dict[str, Any]:
#     """
#     Invoke the ServiceNow MCP agent and return a structured result dict.

#     Handles routing for incident retrieval, resolution analysis, and SSH
#     interface summaries depending on query content and conversation state.
#     """
#     if incident_history is None:
#         incident_history = []

#     if not all([load_mcp_tools, ClientSession, stdio_client, servicenow_server_params]):
#         logger.error("ServiceNow MCP dependencies are not fully available")
#         return {"result": "ServiceNow MCP tools are not configured in this runtime."}

#     async with stdio_client(servicenow_server_params) as (read, write):
#         async with ClientSession(read, write) as session:
#             try:
#                 await session.initialize()
#                 tools = await load_mcp_tools(session)

#                 available_tool_names = [t.name for t in tools]
#                 system_prompt = build_servicenow_system_prompt(available_tool_names)
#                 agent = _create_agent(llm, tools, system_prompt=system_prompt)

#                 summaries: Dict = {}
#                 incidents: List = []
#                 error_msgs: List = []

#                 if len(incident_history) == 0:
#                     agent_response = await agent.ainvoke(
#                         {"messages": [HumanMessage(content=query)]}
#                     )
#                     final_message = _extract_final_message(agent_response)
#                     # logger.info("ServiceNow agent response received")

#                     tool_messages = [
#                         msg for msg in agent_response["messages"]
#                         if isinstance(msg, ToolMessage)
#                     ]
#                     called_tools = [
#                         msg.name for msg in tool_messages if getattr(msg, "name", None)
#                     ]
#                     # logger.info("ServiceNow tools called: %s", called_tools)

#                     for msg in tool_messages:
#                         try:
#                             raw = msg.content[0]["text"]
#                             data = json.loads(raw)
#                             if data.get("incidents"):
#                                 incidents.extend(data["incidents"])
#                             else:
#                                 error_msgs.append(data.get("message", ""))
#                         except (KeyError, IndexError, json.JSONDecodeError):
#                             logger.warning("Could not parse tool message content")
#                 else:
#                     final_message = ""

#                 # --- Resolution path ---
#                 if any(kw in query.lower() for kw in ["resolve", "close", "fix", "reopened", "resolved"]):
#                     if not incidents:
#                         return {"result": "No incidents found to analyze."}

#                     incident_description = incidents[0]["description"]
#                     description_prompt = ChatPromptTemplate.from_template(
#                         "Extract Node ID: and Node name: from this incident description:\n"
#                         "Description: {incident_description}.\n"
#                         "Return ONLY: Node ID: {{node_id}}, Node Name: {{node_name}}."
#                     )
#                     node_details_response = await llm.ainvoke(
#                         description_prompt.format(incident_description=incident_description)
#                     )
#                     matches = re.findall(
#                         r"Node ID: (.*?), Node Name: (.*?)\.",
#                         node_details_response.content,
#                     )
#                     if not matches:
#                         return {"result": "Could not extract node details from incident description."}

#                     node_id, node_name = matches[0]
#                     # logger.info("Extracted node ID=%s name=%s from incident", node_id, node_name)

#                     result = process_incident(
#                         node_id=int(node_id),
#                         node_name=node_name,
#                         incident_description=incident_description,
#                     )
#                     if result["status"] == "error":
#                         return {"result": f"Error retrieving node health: {result['message']}"}

#                     health_analysis = result.get("formatted_analysis", "")
#                     metrics = parse_health_metrics(health_analysis)

#                     tabular_response: List[Dict] = [
#                         {"Incident Details": "Node Information", "Value": f"Node ID: {node_id}, Node Name: {node_name}"}
#                     ]
#                     if result.get("health_data", {}).get("server_ip"):
#                         tabular_response.append({
#                             "Incident Details": "Server IP",
#                             "Value": result["health_data"]["server_ip"],
#                         })

#                     for metric, status in metrics.items():
#                         if not status or status == "is" or len(status) > 50:
#                             continue
#                         tabular_response.append({"Incident Details": metric, "Value": status})

#                     recommendation_prompt = ChatPromptTemplate.from_template(
#                         "Based on the following SolarWinds health report, provide a concise recommendation "
#                         "for resolving the issues with node {node_name} (ID: {node_id}).\n"
#                         "Return ONLY a JSON object:\n"
#                         '{{"Issue": "brief description", "Recommendation": "precise resolution steps"}}\n\n'
#                         "Health Report:\n{health_analysis}"
#                     )
#                     recommendation = await llm.ainvoke(
#                         recommendation_prompt.format(
#                             node_name=node_name,
#                             node_id=node_id,
#                             health_analysis=health_analysis,
#                         )
#                     )
#                     content_response = (
#                         recommendation.content.replace("```json", "").replace("```", "").strip()
#                     )
#                     try:
#                         rec_data = json.loads(content_response)
#                         if rec_data.get("Issue"):
#                             tabular_response.append(
#                                 {"Incident Details": "Issue Summary", "Value": rec_data["Issue"]}
#                             )
#                         if rec_data.get("Recommendation"):
#                             tabular_response.append(
#                                 {"Incident Details": "Recommendation", "Value": rec_data["Recommendation"]}
#                             )
#                     except json.JSONDecodeError:
#                         # logger.warning("Could not parse LLM recommendation JSON")
#                         tabular_response.append({
#                             "Incident Details": "Analysis",
#                             "Value": "Analysis in progress. Please check back for recommendations.",
#                         })

#                     return {"result": tabular_response}

#                 # --- Standard incident list path ---
#                 if len(incident_history) == 0 and "resolve" not in query.lower():
#                     if not incidents:
#                         return {"result": final_message or "No matching incidents were found."}

#                     incident_summary_prompt = ChatPromptTemplate.from_template(
#                         "Summarize this incident in one sentence:\n"
#                         "- Number: {number}\n- Priority: {priority}\n- Status: {state}\n"
#                         "- Short Description: {short_description}\n- Created: {created_on}"
#                     )
#                     for incident in incidents:
#                         summary = await llm.ainvoke(
#                             incident_summary_prompt.format(
#                                 number=incident["number"],
#                                 priority=incident["priority"],
#                                 state=incident["state"],
#                                 short_description=incident["short_description"],
#                                 created_on=incident["created_on"],
#                             )
#                         )
#                         summaries[incident["number"]] = summary.content

#                     response = {"result": summaries}
#                     if "location" in query.lower():
#                         response["incidents"] = incidents
#                         response["needs_resolution_confirmation"] = True
#                     return response

#                 # --- SSH interface summary path ---
#                 if len(incident_history) > 0 and "yes" in query.lower():
#                     ssh_host = os.environ.get("SSH_HOST", "")
#                     ssh_user = os.environ.get("SSH_USER", "")
#                     ssh_password = os.environ.get("SSH_PASSWORD", "")

#                     ssh_output = await async_run_ssh_command(
#                         host=ssh_host,
#                         user=ssh_user,
#                         password=ssh_password,
#                         command="ip a",
#                     )
#                     raw_output = ssh_output.split("\n", 1)[1] if "[sudo] password for" in ssh_output else ssh_output
#                     ansi_escape = re.compile(r"\x1B(?:[@-Z\\-_]|\[[0-?]*[ -/]*[@-~])")
#                     cleaned_output = "\n".join(
#                         line.rstrip()
#                         for line in ansi_escape.sub("", raw_output).splitlines()
#                         if line.strip()
#                     )
#                     summary_response = await llm.ainvoke(
#                         f"Analyze this network interface configuration:\n{cleaned_output}\n\n"
#                         "Provide a summary with: interface names/states, IPv4/IPv6 addresses, "
#                         "and any special configurations. Max 50 words."
#                     )
#                     summaries["result"] = summary_response.content
#                     return summaries

#             except Exception:
#                 # logger.exception("Error in ServiceNow agent run")
#                 return {"result": "error"}


# ---------------------------------------------------------------------------
# Nautobot MCP helpers
# ---------------------------------------------------------------------------

async def _wait_for_mcp_http(url: str, timeout: float = 20.0) -> bool:
    """
    Poll the MCP HTTP endpoint until it accepts TCP connections.

    Any valid HTTP response (including 4xx) signals the server is ready.
    Returns False if the timeout expires without a successful connection.
    """
    parsed = urllib.parse.urlparse(url)
    probe_url = f"{parsed.scheme}://{parsed.netloc}/"
    loop = asyncio.get_event_loop()
    deadline = loop.time() + timeout

    while loop.time() < deadline:
        try:
            reader, writer = await asyncio.open_connection(
                parsed.hostname, parsed.port or 3001
            )
            request = f"GET {probe_url} HTTP/1.0\r\nHost: {parsed.netloc}\r\n\r\n"
            writer.write(request.encode())
            await writer.drain()
            response_line = await asyncio.wait_for(reader.readline(), timeout=3.0)
            writer.close()
            await writer.wait_closed()
            if response_line.startswith(b"HTTP/"):
                return True
        except (ConnectionRefusedError, OSError):
            pass
        except Exception:
            return True  # Partial/malformed response still means the server is alive
        await asyncio.sleep(0.5)

    return False


def _unwrap_exception_group(exc: BaseException) -> BaseException:
    """Extract the first real exception from a Python 3.11+ ExceptionGroup."""
    if hasattr(exc, "exceptions") and exc.exceptions:
        return exc.exceptions[0]
    return exc


def _extract_final_message(agent_response: Dict) -> str:
    """Normalise the final LangGraph agent message to a plain string."""
    content = agent_response["messages"][-1].content
    if isinstance(content, list):
        content = "".join(
            block.get("text", "") if isinstance(block, dict) else str(block)
            for block in content
        ).strip()
    return content


def _create_agent(llm_instance, tools_list, system_prompt: str, **kwargs):
    """
    Thin wrapper around the project's create_agent import so that
    the import lives in one place and is easy to swap.
    """
    
    from langchain.agents import create_agent  # local import avoids circular issues
    return create_agent(llm_instance, tools_list, system_prompt=system_prompt, **kwargs)

# ---------------------------------------------------------------------------
# Nautobot MCP helpers
# ---------------------------------------------------------------------------
def markdown_table_to_ascii(text: str) -> str:
    """
    Finds markdown tables in agent response and converts them
    to plain ASCII tables safe for any text-based frontend.
    """
    # Match a markdown table block (header + divider + rows)
    table_pattern = re.compile(
        r'(\|.+\|\n\|[-| :]+\|\n(?:\|.+\|\n?)+)',
        re.MULTILINE
    )

    def convert_table(match):
        raw = match.group(1).strip()
        lines = [line.strip() for line in raw.splitlines()]

        # Parse header
        headers = [h.strip() for h in lines[0].strip('|').split('|')]

        # Parse rows (skip the divider line at index 1)
        rows = []
        for line in lines[2:]:
            row = [cell.strip() for cell in line.strip('|').split('|')]
            rows.append(row)

        return tabulate_lib.tabulate(rows, headers=headers, tablefmt="grid")

    return table_pattern.sub(convert_table, text)

async def _check_mcp_server_running(url: str, timeout: float = 3.0) -> bool:
    """
    Perform a single quick TCP probe to check if the MCP server is already
    running at the given URL.
 
    Unlike _wait_for_mcp_http (which polls for up to N seconds while waiting
    for a server to start), this function makes ONE attempt with a short
    timeout and returns immediately.
 
    Returns True if the server responds to an HTTP request, False otherwise.
    """
    parsed = urllib.parse.urlparse(url)
    host = parsed.hostname
    port = parsed.port or 3001
 
    try:
        reader, writer = await asyncio.wait_for(
            asyncio.open_connection(host, port),
            timeout=timeout,
        )
        # Send a minimal HTTP/1.0 request so the server has something to respond to
        probe_url = f"{parsed.scheme}://{parsed.netloc}/"
        request = f"GET {probe_url} HTTP/1.0\r\nHost: {parsed.netloc}\r\n\r\n"
        writer.write(request.encode())
        await writer.drain()
 
        response_line = await asyncio.wait_for(reader.readline(), timeout=timeout)
        writer.close()
        await writer.wait_closed()
 
        # Any valid HTTP response (even 4xx) means the server is up
        return response_line.startswith(b"HTTP/")
 
    except (ConnectionRefusedError, OSError):
        # Port is closed — server is definitely not running
        return False
    except asyncio.TimeoutError:
        # Server did not respond in time — treat as not running
        return False
    except Exception:
        # A partial / malformed response still means something is listening
        return True


 
async def run_nautobot_agent(query: str, lc_messages: Optional[List] = None) -> Dict[str, Any]:
    """
    Connect to an already-running Nautobot FastMCP server over HTTP transport
    and run a ReAct agent against the query.
 
    The MCP server is expected to be running independently before this
    function is called.  If the server is not reachable, the function logs
    a clear message and returns an error result immediately.
    """
    if lc_messages is None:
        lc_messages = []
 
    # ------------------------------------------------------------------
    # 1. Guard: make sure the required MCP Python libraries are installed
    # ------------------------------------------------------------------
    if not all([load_mcp_tools, ClientSession, streamablehttp_client]):
        logger.error("Nautobot MCP dependencies are not fully available")
        return {"result": "Nautobot MCP tools are not configured in this runtime."}
 
    # ------------------------------------------------------------------
    # 2. Resolve the MCP server URL and build the list of fallback URLs
    # ------------------------------------------------------------------
    configured_mcp_url = os.getenv("NAUTOBOT_MCP_URL", "http://127.0.0.1:3001/mcp")
 
    mcp_url_candidates = [configured_mcp_url]
    if not configured_mcp_url.endswith("/mcp"):
        mcp_url_candidates.append(configured_mcp_url.rstrip("/") + "/mcp")
    # for fallback in ("http://127.0.0.1:3001/mcp", "http://127.0.0.1:3002/mcp"):
    #     if fallback not in mcp_url_candidates:
    #         mcp_url_candidates.append(fallback)
 
    # ------------------------------------------------------------------
    # 3. Pre-flight check: verify the MCP server is actually reachable
    #    before we attempt any MCP client operations.
    # ------------------------------------------------------------------
    server_is_up = await _check_mcp_server_running(configured_mcp_url)
    logger.info(f"MCP URL is ::: {server_is_up}")
    if not server_is_up:
        message = (
            f"Nautobot MCP server is not running at {configured_mcp_url}. "
            "Please start the MCP server before sending queries."
        )
        logger.error(message)
        print(message)   # visible in stdout / container logs as well
        return {"result": "Nautobot MCP server is not running. Please start the server and try again."}
 
    logger.info("Nautobot MCP server confirmed running at %s", configured_mcp_url)
 
    # ------------------------------------------------------------------
    # 4. Connect the MCP client, load tools, build the agent, run it
    # ------------------------------------------------------------------
    errors_by_url: Dict[str, str] = {}
 
    for mcp_url in mcp_url_candidates:
        last_error = None
 
        for attempt in range(3):
            try:
                async with streamablehttp_client(mcp_url) as (read, write, _):
                    async with ClientSession(read, write) as session:
                        await session.initialize()
 
                        # --- Load tools exposed by the MCP server ---
                        tools = await load_mcp_tools(session)
                        available_tool_names = [t.name for t in tools]
                        logger.info(
                            "Loaded Nautobot MCP tools from %s: %s",
                            mcp_url,
                            available_tool_names,
                        )
 
                        # --- Build the ReAct agent with a Nautobot-aware prompt ---
                        system_prompt = build_nautobot_system_prompt(available_tool_names)
                        logger.info(f"System prompt is {system_prompt}")
                        agent = _create_agent(llm, tools, system_prompt=system_prompt,debug=True)
                        trimmed_history=lc_messages[-4:]
 
                        # --- Prepend conversation history and invoke ---
                        messages_with_history = trimmed_history + [HumanMessage(content=query)]
                        logger.info(
                            "Invoking Nautobot agent with %d  trimmed history message(s)",
                            len(trimmed_history),
                        )
                        start_time = time.time()
                        agent_response = await agent.ainvoke(
                            {"messages": messages_with_history}
                        )
                        end_time = time.time()
                        # ⏱️ Calculate total time in seconds
                        time_taken = end_time - start_time
                        # print(f"total time taken for response is {time_taken}")
                        logger.info("Agent execution time: %.4f seconds", time_taken)
                        for msg in agent_response["messages"]:
                            logger.info("Message type: %s",type(msg).__name__)
                            logger.info("Message Content: %s",getattr(msg, "content",None))
 
                        # --- Extract the final text reply ---
                        final_message = _extract_final_message(agent_response)
                        final_response = markdown_table_to_ascii(final_message)
 
                        # --- Log which MCP tools were actually called ---
                        called_tools = [
                            msg.name
                            for msg in agent_response["messages"]
                            if isinstance(msg, ToolMessage) and getattr(msg, "name", None)
                        ]
                        logger.info("Nautobot tools called: %s", called_tools)
                        return {"result": final_response}
 
            except Exception as conn_err:
                real_err = _unwrap_exception_group(conn_err)
                last_error = real_err
                logger.warning(
                    "Attempt %d/3 failed for %s: %s: %s. Retrying in 2 s …",
                    attempt + 1,
                    mcp_url,
                    type(real_err).__name__,
                    real_err,
                )
                await asyncio.sleep(2)
 
        errors_by_url[mcp_url] = f"{type(last_error).__name__}: {last_error}"
 
    # All URL candidates and all retries exhausted
    logger.error(
        "Unable to connect to Nautobot MCP after trying all URL candidates: %s",
        errors_by_url,
    )
    return {"result": "error"}

# ---------------------------------------------------------------------------
# LangGraph state & nodes
# ---------------------------------------------------------------------------

class NautobotState(TypedDict):
    query: str
    parsed_query: Optional[Dict[str, str]]
    result: Optional[Any]
    error: Optional[str]
    current_tool: Optional[str]
    tool_choice: Optional[str]
    session_id: Optional[str]
    requested_tool: Optional[str]  # explicit tool selection from frontend ("nautobot" | "vulnerability_management")


# NOTE: These module-level lists are used by service_now_tools to carry
# transient conversation state.  In a multi-worker production deployment
# consider moving this to a per-session cache (e.g. Redis).
_incident_history: List = []
_needs_resolution_confirmation: bool = False


# def service_now_tools(state: NautobotState) -> Dict:
#     """LangGraph node: invoke the ServiceNow agent synchronously."""
#     global _incident_history, _needs_resolution_confirmation

#     # logger.info("ServiceNow node invoked for session: %s", state.get("session_id"))
#     result = asyncio.run(run_agent(state["query"], _incident_history))

#     if "needs_resolution_confirmation" in result:
#         _needs_resolution_confirmation = True
#         _incident_history = result["incidents"]
#     else:
#         _needs_resolution_confirmation = False
#         _incident_history = []

#     return {"result": result["result"], "current_tool": "servicenow"}


def _extract_dnac_id_from_query(query: str) -> Optional[str]:
    """Parse optional DNAC logical id from free text (e.g. VM wizard: 'impacted devices for dnac default')."""
    if not query or not isinstance(query, str):
        return None
    q = query.strip().lower()
    patterns = (
        r"\bfor\s+dnac\s+(\S+)",
        r"\bdnac_id\s*=\s*(\S+)",
        r"\bdnac_id\s*:\s*(\S+)",
        r"\busing\s+dnac\s+(\S+)",
    )
    for pat in patterns:
        m = re.search(pat, q)
        if m:
            token = m.group(1).strip().strip("\"'.,);")
            return token or None
    return None


def route_query(query: str) -> str:
    """Map a user query to one of the registered LangGraph route labels."""
    q = query.lower()
    return_val = ""
    if any(kw in q for kw in ["incident", "priority"]):
        return_val = "servicenow"
    elif any(kw in q for kw in ["vulnerability", "advisory", "dnac", "cisco", "security", "cve", "patch", "psirt"]):
        return_val = "vulnerability_management"
    elif any(kw in q for kw in ["nautobot", "device", "interface", "vlan", "prefix", "rack", "location"]):
        return_val =  "nautobot"
    elif any(kw in q for kw in ["alert", "solarwinds", "node"]):
        return_val =  "solarwinds"
    elif "engineer" in q:
        return_val =  "engineer_console"
    else :
        return_val =  "nautobot"
    # return_val =  "vulnerability_management"

    logger.info(f"Router val is {return_val} query is {q}")
    return return_val


def router(state: NautobotState) -> str:
    """Conditional edge: determine the next node and optionally clear history.

    Priority:
      1. requested_tool from frontend (explicit user selection)
      2. keyword-based route_query fallback
    """
    current_tool = state.get("current_tool")

    # Honour explicit tool selection from the frontend
    requested = (state.get("requested_tool") or "").strip().lower()
    _TOOL_ALIASES = {
        "vulnerability_management": "vulnerability_management",
        "vulnerability": "vulnerability_management",
        "nautobot": "nautobot",
    }
    if requested in _TOOL_ALIASES:
        new_route = _TOOL_ALIASES[requested]
    else:
        new_route = route_query(state["query"])

    if current_tool and current_tool != new_route:
        logger.info(
            "Tool switch detected (session=%s): %s → %s – clearing history",
            state["session_id"],
            current_tool,
            new_route,
        )
        Conversation.objects.filter(session_id=state["session_id"]).delete()

    logger.info("Router resolved: requested_tool=%s → route=%s", requested or "none", new_route)
    return new_route


# ---------------------------------------------------------------------------
# NautobotLangGraphTool
# ---------------------------------------------------------------------------

_TOOL_USED_TO_ROUTE: Dict[str, str] = {
    "nautobot":               "nautobot",
    "nautobot_mcp":           "nautobot",   # legacy DB values
    # "servicenow":             "servicenow",
    # "solarwinds":             "solarwinds",
    # "engineer_console":       "engineer_console",
    "vulnerability_management": "vulnerability_management",
}


class NautobotLangGraphTool:
    """
    Orchestrates multi-agent routing across ServiceNow, Nautobot, SolarWinds
    and a local RAG pipeline using a LangGraph StateGraph.
    """

    def __init__(self, llm_instance):
        self._llm = llm_instance
        self.workflow = self._build_workflow()

    # ------------------------------------------------------------------
    # Workflow construction
    # ------------------------------------------------------------------

    def _build_workflow(self):
        workflow = StateGraph(NautobotState)
        workflow.add_node("start", self._start_node)
        workflow.add_node("parse", self._parse_node)
        # workflow.add_node("service_now_callback", service_now_tools)
        workflow.add_node("nautobot_callback", self._nautobot_node)
        # workflow.add_node("solarwinds_callback", self._solarwinds_node)
        # workflow.add_node("engineer_console_callback", self._engineer_console_node)
        workflow.add_node("vulnerability_management_callback", self._vulnerability_management_node)
        workflow.add_node("history_updater", self._update_history_node)

        workflow.set_entry_point("start")
        workflow.add_conditional_edges(
            "start",
            router,
            {
                "chatbot":                "parse",
                # "servicenow":             "service_now_callback",
                "nautobot":               "nautobot_callback",
                # "solarwinds":             "solarwinds_callback",
                # "engineer_console":       "engineer_console_callback",
                "vulnerability_management": "vulnerability_management_callback",
            },
        )
        for node in (
            "parse",
            # "service_now_callback",
            "nautobot_callback",
            # "solarwinds_callback",
            # "engineer_console_callback",
            "vulnerability_management_callback",
        ):
            workflow.add_edge(node, "history_updater")
        workflow.add_edge("history_updater", END)
        return workflow.compile()

    # ------------------------------------------------------------------
    # History helpers
    # ------------------------------------------------------------------

    def _get_chat_history(self, session_id: str) -> List[Dict]:
        return [
            {"role": m.role, "content": m.content, "tool_used": m.tool_used}
            for m in Conversation.objects.filter(session_id=session_id).order_by("created_at")
        ]

    def _save_to_history(
        self,
        session_id: str,
        role: str,
        content: Any,
        tool_used: Optional[str] = None,
    ) -> None:
        if not isinstance(content, str):
            content = json.dumps(content, default=str)
        Conversation.objects.create(
            session_id=session_id,
            role=role,
            content=content,
            tool_used=tool_used,
        )

    def _convert_to_lc_messages(
        self, history: List[Dict], tool_filter: Optional[str] = None
    ) -> List:
        lc_messages = []
        for msg in history:
            role = msg["role"]
            if role == "system":
                lc_messages.append(SystemMessage(content=msg["content"]))
                continue
            if tool_filter and msg.get("tool_used") and msg["tool_used"] != tool_filter:
                continue
            if role == "user":
                lc_messages.append(HumanMessage(content=msg["content"]))
            elif role == "assistant":
                lc_messages.append(AIMessage(content=msg["content"]))
        return lc_messages

    # ------------------------------------------------------------------
    # Graph nodes
    # ------------------------------------------------------------------

    def _start_node(self, state: NautobotState) -> Dict:
        session_id = state.get("session_id") or str(uuid.uuid4())
        last_msg = (
            Conversation.objects.filter(session_id=session_id, role="assistant")
            .order_by("-created_at")
            .first()
        )
        raw_tool = last_msg.tool_used if last_msg else None
        last_tool = _TOOL_USED_TO_ROUTE.get(raw_tool) if raw_tool else None

        logger.info(
            "_start_node: session=%s raw_tool=%s resolved_route=%s",
            session_id,
            raw_tool,
            last_tool,
        )
        return {
            "query": state["query"],
            "session_id": session_id,
            "tool_choice": None,
            "current_tool": last_tool,
            "requested_tool": state.get("requested_tool"),
        }

    def _parse_node(self, state: NautobotState) -> Dict:
        """Chatbot fallback: run a local Nautobot query tool."""
        try:
            history = self._get_chat_history(state["session_id"])
            lc_messages = self._convert_to_lc_messages(history)

            from .nautobot_querytool import nautobot_query_tool  # local import

            agent = _create_agent(
                self._llm,
                [nautobot_query_tool],
                system_prompt="You are a network inventory specialist. Use tools to query Nautobot.",
            )
            result = agent.invoke(
                {"messages": lc_messages + [HumanMessage(content=state["query"])]}
            )
            return {"result": _extract_final_message(result), "tool_choice": None}

        except Exception:
            logger.exception("Error in _parse_node")
            return {"result": "Sorry, I encountered an error processing your Nautobot query.", "tool_choice": None}

    # def _solarwinds_node(self, state: NautobotState) -> Dict:
    #     """LangGraph node: run a SolarWinds SWQL agent."""
    #     history = self._get_chat_history(state["session_id"])
    #     lc_messages = self._convert_to_lc_messages(history)
    #     agent = _create_agent(
    #         self._llm,
    #         solarwinds_tools,
    #         system_prompt=(
    #             "You are an intelligent agent that helps users get data from SolarWinds using SWQL. "
    #             "Use tools to generate queries and get results."
    #         ),
    #     )
    #     result = agent.invoke(
    #         {"messages": lc_messages + [HumanMessage(content=state["query"])]}
    #     )
    #     return {"result": result["messages"][-1].content, "current_tool": "solarwinds"}

    # def _contextualize_query(self, query: str, lc_messages: List) -> str:
    #     """
    #     Rewrite ambiguous short queries into self-contained ones using recent history.
    #     Returns the original query unchanged when no rewrite is needed.
    #     """
    #     ambiguous_pronouns = [
    #         "them", "it", "those", "these", "that", "same", "previous",
    #         "above", "list all", "show all", "get all", "all of",
    #     ]
    #     is_ambiguous = (
    #         any(p in query.lower() for p in ambiguous_pronouns)
    #         and len(query.split()) < 12
    #     )
    #     if not is_ambiguous or not lc_messages:
    #         return query

    #     history_text = "\n".join(
    #         f"{'User' if isinstance(m, HumanMessage) else 'Assistant'}: {m.content}"
    #         for m in lc_messages[-6:]
    #     )
    #     contextualize_prompt = (
    #         "You are a query rewriter for a network management chatbot.\n\n"
    #         "Given the conversation history and the user's latest message, rewrite the "
    #         "latest message into a fully self-contained query that includes all necessary "
    #         "context (device type, location, filters etc.) inferred from history.\n\n"
    #         "Rules:\n"
    #         "- If already self-contained, return it exactly as-is.\n"
    #         "- Never add information not implied by history.\n"
    #         "- Return ONLY the rewritten query, no explanation.\n\n"
    #         f"Conversation history:\n{history_text}\n\n"
    #         f"Latest user message: {query}\n\nRewritten query:"
    #     )
    #     response = self._llm.invoke(contextualize_prompt)
    #     rewritten = response.content.strip().strip('"').strip("'")
    #     logger.info("Query contextualized: '%s' → '%s'", query, rewritten)
    #     return rewritten

    def _nautobot_node(self, state: NautobotState) -> Dict:
        """LangGraph node: run the Nautobot MCP agent."""
        session_id = state["session_id"]
        history = self._get_chat_history(session_id)
        lc_messages = self._convert_to_lc_messages(history, tool_filter="nautobot")
        logger.info(
            "_nautobot_node: session=%s history_len=%d lc_messages=%d",
            session_id,
            len(history),
            len(lc_messages),
        )

        # contextualized_query = self._contextualize_query(state["query"], lc_messages)
        # logger.info("_nautobot_node: final query='%s'", contextualized_query)

        # result = asyncio.run(run_nautobot_agent(contextualized_query, lc_messages=lc_messages))
        result = asyncio.run(run_nautobot_agent(state["query"], lc_messages=lc_messages))
        return {"result": result["result"], "current_tool": "nautobot", "tool_choice": "nautobot"}

    # def _engineer_console_node(self, state: NautobotState) -> Dict:
    #     """LangGraph node: answer via RAG pipeline."""
    #     pipeline.setup_vectorstore()
    #     pipeline.setup_qa_chain()
    #     response = pipeline.query(state["query"])
    #     # logger.info("Engineer console response received for session: %s", state.get("session_id"))
    #     return {"result": response["result"]}

    def _vulnerability_management_node(self, state: NautobotState) -> Dict:
        """LangGraph node: handle vulnerability management queries with direct calls (no HTTP)."""
        session_id = state["session_id"]
        query = state["query"].lower()
        raw_query = state.get("query") or ""
        logger.info(f"_vulnerability_management_node query is {query}")
        # Route Cisco advisory/CVE/workaround questions to the standalone RAG advisory agent.
        logger.info(
                "_vulnerability_management_node: session=%s action=rag_advisory_query",
                session_id,
            )
        try:
            rag_response = run_rag_langchain_agent(raw_query)
            return {
                "result": rag_response,
                "current_tool": "vulnerability_management",
                "tool_choice": "vulnerability_management",
            }
        except Exception as rag_exc:
            logger.error(
                "_vulnerability_management_node: RAG advisory query failed for session=%s error=%s",
                session_id,
                rag_exc,
            )
            return {
                "result": {
                    "type": "service_error",
                    "message": "Advisory knowledge-base query failed. Please retry.",
                    "error_type": "rag_query_error",
                    "action": "show_service_error",
                    "retry_available": True,
                },
                "current_tool": "vulnerability_management",
                "tool_choice": "vulnerability_management",
            }

    def _update_history_node(self, state: NautobotState) -> Dict:
        """Persist user + assistant turns to the Conversation model."""
        try:
            # logger.info(
            #     "_update_history_node: session=%s tool_choice=%s result_type=%s",
            #     state["session_id"],
            #     state.get("tool_choice"),
            #     type(state.get("result")).__name__,
            # )
            self._save_to_history(state["session_id"], "user", state["query"], tool_used=None)
            self._save_to_history(
                state["session_id"], "assistant", state["result"], tool_used=state.get("tool_choice")
            )

            message_count = Conversation.objects.filter(session_id=state["session_id"]).count()
            if message_count > 30:
                self._summarize_history(state["session_id"])

            return {
                "result": state["result"],
                "session_id": state["session_id"],
                "status": "history_updated",
            }

        except Exception:
            logger.exception(
                "_update_history_node FAILED for session=%s", state.get("session_id")
            )
            return {
                "result": state["result"],
                "session_id": state["session_id"],
                "status": "history_update_failed",
            }

    def _summarize_history(self, session_id: str) -> bool:
        """
        Condense long conversation histories into a system-message summary.

        Keeps the 4 most recent messages (2 full turns) intact for immediate
        context continuity.  Returns True on success.
        """
        try:
            messages = Conversation.objects.filter(session_id=session_id).order_by("created_at")
            if messages.count() <= 30:
                return False

            history_text = "\n".join(
                f"{m.role.upper()}: {m.content}"
                for m in messages
                if m.role in ("user", "assistant")
            )
            summary_prompt = ChatPromptTemplate.from_messages([
                (
                    "system",
                    "You are a conversation summarizer for a network management chatbot. "
                    "Create a concise technical summary preserving ALL of the following:\n"
                    "- Every location/site name mentioned (e.g. AMS01, AMER, LON01)\n"
                    "- Every device name or hostname\n"
                    "- Every count or number referenced (e.g. '15 devices')\n"
                    "- Every VLAN, prefix, rack, or circuit ID\n"
                    "- The outcome of each user request\n"
                    "Do NOT paraphrase entity names — copy them exactly.",
                ),
                ("human", "Conversation History:\n{history}\n\nSummary (3-5 bullet points):"),
            ])
            summary = (summary_prompt | self._llm | StrOutputParser()).invoke(
                {"history": history_text}
            )

            last_four_ids = [
                m.id for m in messages.order_by("-created_at")[:4]
            ]
            Conversation.objects.filter(session_id=session_id).exclude(
                id__in=last_four_ids
            ).delete()
            Conversation.objects.create(
                session_id=session_id,
                role="system",
                content=f"### Conversation Summary ###\n{summary}",
                tool_used="history_summarizer",
            )
            logger.info("History summarized for session: %s", session_id)
            return True

        except Exception:
            logger.exception("Failed to summarize history for session: %s", session_id)
            return False

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def query(
        self,
        query: str,
        session_id: Optional[str] = None,
        requested_tool: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Execute a user query through the full LangGraph workflow.

        Args:
            query: The user's message.
            session_id: Optional session identifier for conversation history.
            requested_tool: Explicit tool selection from the frontend.
                            Accepted values: "nautobot", "vulnerability_management".
                            When provided, overrides keyword-based routing.
        """
        _session_id = session_id or str(uuid.uuid4())
        try:
            result = self.workflow.invoke({
                "query": query,
                "session_id": _session_id,
                "requested_tool": requested_tool,
            })
            return {
                "result": result["result"],
                "session_id": result["session_id"],
                "tool_used": result.get("tool_choice", "unknown"),
            }
        except Exception:
            logger.exception("Error in NautobotLangGraphTool.query")
            return {
                "result": "Sorry, I encountered an error processing your request.",
                "session_id": _session_id,
                "tool_used": "error",
            }


# ---------------------------------------------------------------------------
# Module-level tool instance
# ---------------------------------------------------------------------------
langgraph_tool = NautobotLangGraphTool(llm)


# ---------------------------------------------------------------------------
# DnacInstancesView — returns DNAC list from config for the chatbot frontend
# ---------------------------------------------------------------------------

class DnacInstancesView(APIView):
    """
    GET /chatbot/dnac-instances/

    Returns the configured DNAC instances so the chat widget can show
    a selection chip for each one when Vulnerability Management is chosen.
    """
    permission_classes = [IsAuthenticated]

    def get(self, request):
        instances = []
        for dnac_id, cfg in _VM_DNAC_INSTANCES.items():
            if dnac_id == "default":
                continue
            instances.append({
                "id":   dnac_id,
                "host": cfg.get("host", ""),
                "port": cfg.get("port", 443),
            })
        return Response({"dnac_instances": instances})


# ---------------------------------------------------------------------------
# ChatbotView (main DRF endpoint)
# ---------------------------------------------------------------------------

class ChatbotView(APIView):
    """
    POST /chatbot/

    Accepts a JSON body with 'message' and optional 'session_id'.
    Returns the agent response, session_id, tool_used, and processing_time.
    """

    permission_classes = [IsAuthenticated]

    def post(self, request):
        global _needs_resolution_confirmation

        start_time = time.time()
        session_id = request.data.get("session_id") or str(uuid.uuid4())

        try:
            user_message = request.data.get("message", "").strip()
            # Optional explicit tool selection: "nautobot" | "vulnerability_management"
            requested_tool = (request.data.get("tool") or "").strip().lower() or None
            # Optional DNAC id pre-selected by the user in the chat widget
            dnac_id = (request.data.get("dnac_id") or "").strip().lower() or None
            logger.info(
                "Received message for session %s | requested_tool=%s | dnac_id=%s",
                session_id,
                requested_tool or "none",
                dnac_id or "none",
            )

            # If the VM tool is active and a DNAC was pre-selected, inject it into the
            # query so the RAG agent doesn't have to ask the user which DNAC to use.
            if requested_tool == "vulnerability_management" and dnac_id:
                if f"dnac {dnac_id}" not in user_message.lower():
                    user_message = f"{user_message} for dnac {dnac_id}"
                    logger.info("Injected dnac_id into query: '%s'", user_message)

            if not user_message:
                logger.warning("Empty message received for session %s", session_id)
                return Response(
                    {"error": "Message cannot be empty", "session_id": session_id},
                    status=400,
                )

            # Intercept resolution confirmation flow
            if _needs_resolution_confirmation:
                if "yes" in user_message.lower():
                    user_message = "yes , please provide resolution for incident"
                elif "no" in user_message.lower():
                    _needs_resolution_confirmation = False
                    return Response({"response": "Okay, please ask your next query.", "session_id": session_id})

            try:
                response = langgraph_tool.query(
                    query=user_message,
                    session_id=session_id,
                    requested_tool=requested_tool,
                )
                # logger.info(
                #     "Request processed in %.2f s | session=%s | tool=%s",
                #     time.time() - start_time,
                #     session_id,
                #     response.get("tool_used", "unknown"),
                # )
                return Response({
                    "response": response["result"],
                    "session_id": response["session_id"],
                    "tool_used": response.get("tool_used", "unknown"),
                    "processing_time": f"{time.time() - start_time:.2f}s",
                })

            except Exception:
                logger.exception(
                    "AI processing error | session=%s", session_id
                )
                return Response(
                    {
                        "response": "Please retry your query. If the problem persists, contact support.",
                        "session_id": session_id,
                    },
                    status=500,
                )

        except Exception:
            logger.exception("System error in ChatbotView.post")
            return Response(
                {
                    "error": "Our system encountered an unexpected error.",
                    "session_id": session_id,
                    "support_reference": f"ERR-{uuid.uuid4().hex[:8]}",
                },
                status=500,
            )


# ---------------------------------------------------------------------------
# SolarWinds utility views
# ---------------------------------------------------------------------------

# def _parse_node_id(raw: Optional[str]) -> Optional[int]:
#     """Convert a query-string node_id to int, or return None on failure."""
#     if raw is None:
#         return None
#     try:
#         return int(raw)
#     except ValueError:
#         return None


# @csrf_exempt
# def solarwinds_health_check(request):
#     """
#     GET  /solarwinds/health/?node_id=<id>&node_name=<name>
#     POST /solarwinds/health/  (JSON body: node_id, node_name, alert_string)

#     Returns a JSON health analysis for the specified node.
#     """
#     if request.method == "GET":
#         raw_node_id = request.GET.get("node_id")
#         node_name = request.GET.get("node_name")

#         if not raw_node_id and not node_name:
#             return JsonResponse({"error": "Either node_id or node_name is required"}, status=400)

#         node_id = _parse_node_id(raw_node_id)
#         if raw_node_id and node_id is None:
#             return JsonResponse({"error": "node_id must be an integer"}, status=400)

#         result = SolarWindsService().check_and_analyze(node_id=node_id, node_name=node_name)
#         if "error" in result:
#             return JsonResponse({"error": result["error"]}, status=500)
#         return JsonResponse(result, safe=False, json_dumps_params={"default": str})

#     if request.method == "POST":
#         try:
#             data = json.loads(request.body)
#         except json.JSONDecodeError:
#             return JsonResponse({"error": "Invalid JSON in request body"}, status=400)

#         node_id = data.get("node_id")
#         node_name = data.get("node_name")
#         additional_info = None

#         alert_string = data.get("alert_string")
#         if alert_string:
#             parsed_alert = parse_alert_string(alert_string)
#             node_id = node_id or parsed_alert.get("node_id")
#             node_name = node_name or parsed_alert.get("node_name")
#             additional_info = parsed_alert

#         if not node_id and not node_name:
#             return JsonResponse(
#                 {"error": "Either node_id, node_name, or an alert_string with node info is required"},
#                 status=400,
#             )

#         if isinstance(node_id, str):
#             node_id = _parse_node_id(node_id)
#             if node_id is None:
#                 return JsonResponse({"error": "node_id must be an integer"}, status=400)

#         result = SolarWindsService().check_and_analyze(
#             node_id=node_id, node_name=node_name, additional_info=additional_info
#         )
#         if "error" in result:
#             return JsonResponse({"error": result["error"]}, status=500)
#         return JsonResponse(result, safe=False, json_dumps_params={"default": str})

#     return JsonResponse({"error": "Method not allowed"}, status=405)


# @csrf_exempt
# def solarwinds_health_report(request):
#     """
#     GET /solarwinds/report/?node_id=<id>&node_name=<name>&format=<json|markdown|html>

#     Returns a health report in the requested format (default: json).
#     """
#     if request.method != "GET":
#         return JsonResponse({"error": "Method not allowed"}, status=405)

#     raw_node_id = request.GET.get("node_id")
#     node_name = request.GET.get("node_name")
#     report_format = request.GET.get("format", "json")

#     if not raw_node_id and not node_name:
#         return JsonResponse({"error": "Either node_id or node_name is required"}, status=400)

#     node_id = _parse_node_id(raw_node_id)
#     if raw_node_id and node_id is None:
#         return JsonResponse({"error": "node_id must be an integer"}, status=400)

#     service = SolarWindsService()
#     result = service.check_and_analyze(node_id=node_id, node_name=node_name)
#     if "error" in result:
#         return JsonResponse({"error": result["error"]}, status=500)

#     if report_format == "markdown":
#         return HttpResponse(
#             service.format_health_analysis_for_display(result),
#             content_type="text/markdown",
#         )
#     if report_format == "html":
#         import markdown as md_lib
#         return HttpResponse(
#             md_lib.markdown(service.format_health_analysis_for_display(result)),
#             content_type="text/html",
#         )
#     return JsonResponse(result, safe=False, json_dumps_params={"default": str})


# @csrf_exempt
# def parse_solarwinds_alert(request):
#     """
#     POST /solarwinds/parse-alert/

#     Body: {"alert_string": "<raw alert text>"}
#     Returns the parsed alert as JSON.
#     """
#     if request.method != "POST":
#         return JsonResponse({"error": "Method not allowed"}, status=405)

#     try:
#         data = json.loads(request.body)
#     except json.JSONDecodeError:
#         return JsonResponse({"error": "Invalid JSON in request body"}, status=400)

#     alert_string = data.get("alert_string")
#     if not alert_string:
#         return JsonResponse({"error": "alert_string is required"}, status=400)

#     return JsonResponse(parse_alert_string(alert_string))


# @csrf_exempt
# def get_solarwinds_nodes(request):
#     """
#     GET /solarwinds/nodes/

#     Returns the list of available SolarWinds nodes.
#     """
#     if request.method != "GET":
#         return JsonResponse({"error": "Method not allowed"}, status=405)

#     service = SolarWindsService()
#     health_check = service._create_health_check()

#     if not health_check.connect():
#         return JsonResponse({"error": "Failed to connect to SolarWinds server"}, status=500)

#     nodes = health_check.get_available_nodes()
#     if isinstance(nodes, str) and nodes.startswith("Error:"):
#         return JsonResponse({"error": nodes}, status=500)

#     return JsonResponse({"nodes": nodes}, safe=False, json_dumps_params={"default": str})


# ---------------------------------------------------------------------------
# Health metrics parser
# ---------------------------------------------------------------------------

# _METRIC_DEFAULTS: Dict[str, str] = {
#     "CPU Utilization":       "Unknown",
#     "Memory Utilization":    "Unknown",
#     "Disk Utilization":      "Unknown",
#     "Interface Utilization": "Unknown",
#     "Response Time":         "Unknown",
#     "Packet Loss":           "Unknown",
#     "Latency":               "Unknown",
# }


# def parse_health_metrics(health_analysis: Optional[str]) -> Dict[str, str]:
#     """
#     Parse a formatted SolarWinds health analysis string into a metrics dict.

#     Args:
#         health_analysis: Markdown-formatted health report text.

#     Returns:
#         Dict mapping metric names to their status strings.
#     """
#     if not health_analysis:
#         return dict(_METRIC_DEFAULTS)

#     metrics: Dict[str, str] = {}
#     current_section: Optional[str] = None

#     for line in health_analysis.splitlines():
#         line = line.strip()
#         if not line:
#             continue
#         if line.startswith("###"):
#             current_section = line.replace("#", "").strip()
#             continue
#         if current_section in ("System Metrics:", "Performance Metrics:") and line.startswith("-"):
#             parts = line.lstrip("-").strip().split(":", 1)
#             if len(parts) == 2:
#                 metric_name = parts[0].strip()
#                 status_text = parts[1].strip()
#                 status = status_text.split("(")[0].strip() if "(" in status_text else status_text
#                 metrics[metric_name] = status

#     result = dict(_METRIC_DEFAULTS)
#     # Exact-name matches first
#     for metric in list(result):
#         if metric in metrics:
#             result[metric] = metrics[metric]
#     # Partial-match fallback
#     for metric in list(result):
#         if result[metric] == "Unknown":
#             for found_metric, value in metrics.items():
#                 if metric.lower() in found_metric.lower():
#                     result[metric] = value
#                     break

#     return result
