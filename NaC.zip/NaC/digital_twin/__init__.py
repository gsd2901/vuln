#digital_twin/__init__.py
"""App declaration for welcome_wizard."""

from nautobot.apps import NautobotAppConfig

__version__ = "1.0.0"

class DigitalTwin(NautobotAppConfig):
    name = "digital_twin"
    verbose_name = "Digital Twin"
    description = "Digital Twin for Nautobot."
    author = "Sameer Dudeja"
    author_email = "s-sameer@hcltech.com"
    base_url = "digital-twin"
    required_settings = []
    default_settings = {}
    min_version = "1.0.0"
    max_version = "3.0.0"
    caching_config = {}

    def ready(self):
        """Callback when this app is loaded."""
        super().ready()



config = DigitalTwin  # pylint:disable=invalid-name