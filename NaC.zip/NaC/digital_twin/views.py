import os
import json
import logging
import subprocess
import yaml
import ipaddress
import uuid
import paramiko
import requests
import tempfile
import re
import time
import shutil
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple, Any
from concurrent.futures import ThreadPoolExecutor, TimeoutError as FuturesTimeoutError

from django.http import JsonResponse, HttpResponse
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_POST
from django.conf import settings
from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from django.core.cache import cache
from django.db import transaction
from django.core.exceptions import ValidationError
from django.utils import timezone
from django.db.models import Q

# Configure logging
logger = logging.getLogger(__name__)

# Constants
DEFAULT_TIMEOUT = 30  # Consistent 30-second timeout for all operations
COMMAND_TIMEOUT = 300
FILE_TRANSFER_TIMEOUT = 60
CACHE_TIMEOUT = 3600
HEALTH_CACHE_TIMEOUT = 30  # Consistent 30-second cache timeout
DEFAULT_API_PORT = 8080
DEPLOYMENT_TIMEOUT = 300
POLL_INTERVAL = 2

class RemoteContainerlabManager:
    """
    Manages connections and operations with remote Containerlab servers
    """
    
    def __init__(self):
        self.servers = self._load_server_config()
        self.connection_pool = {}
        self.executor = ThreadPoolExecutor(max_workers=5)
        
        # Timeout settings
        self.connect_timeout = DEFAULT_TIMEOUT
        self.command_timeout = COMMAND_TIMEOUT
        self.file_transfer_timeout = FILE_TRANSFER_TIMEOUT
    
    def _load_server_config(self) -> Dict:
        """Load remote server configuration from Django settings"""
        return getattr(settings, 'DIGITAL_TWIN_REMOTE_SERVERS', {
            'default': {
                'name': 'Local Server',
                'host': 'localhost',
                'type': 'local',
                'enabled': True
            },
            'local_api': {
                'name': 'Local Containerlab API',
                'host': 'localhost',
                'type': 'api',
                'enabled': True,
                'api_config': {
                    'endpoint': 'http://localhost:8080',
                    'enabled': True,
                    'port': 8080,
                    'timeout': 300
                },
                'working_directory': '/tmp/nautobot_labs'
            }
        })
    
    def get_available_servers(self) -> List[Dict]:
        """Get list of available and healthy remote servers"""
        available_servers = []
        
        for server_id, config in self.servers.items():
            if not config.get('enabled', True):
                continue
                
            # Check server health
            health_status = self._check_server_health(server_id)
            
            server_info = {
                'id': server_id,
                'name': config.get('name', server_id.title()),
                'host': config.get('host'),
                'type': config.get('type', 'remote'),
                'status': health_status['status'],
                'last_check': health_status['timestamp'],
                'cpu_usage': health_status.get('cpu_usage'),
                'memory_usage': health_status.get('memory_usage'),
                'active_labs': health_status.get('active_labs', 0)
            }
            
            available_servers.append(server_info)
        
        return available_servers
    
    def _check_server_health(self, server_id: str) -> Dict:
        """Check health status of a remote server"""
        cache_key = f"server_health_{server_id}"
        cached_health = cache.get(cache_key)
        
        if cached_health:
            return cached_health
        
        config = self.servers.get(server_id)
        if not config:
            return {'status': 'unknown', 'timestamp': timezone.now().isoformat()}
        
        if config.get('type') == 'local':
            health = self._check_local_health()
        elif config.get('type') == 'hybrid':
            # For hybrid servers, try API first, then fall back to SSH
            api_config = config.get('api_config', {})
            if api_config.get('enabled', False):
                try:
                    health = self._check_api_health(config)
                except Exception as api_error:
                    logger.warning(f"API health check failed for hybrid server {server_id}, falling back to SSH: {api_error}")
                    health = self._check_ssh_health(config)
            else:
                health = self._check_ssh_health(config)
        else:
            # Try API first, fallback to SSH
            api_config = config.get('api_config', {})
            if api_config.get('enabled', False):
                health = self._check_api_health(config)
            else:
                health = self._check_ssh_health(config)
        
        # Cache health status
        cache.set(cache_key, health, HEALTH_CACHE_TIMEOUT)
        
        return health
    
    def _check_local_health(self) -> Dict:
        """Check local server health"""
        try:
            result = subprocess.run(['clab', 'version'], 
                                  capture_output=True, text=True, timeout=30)
            
            if result.returncode == 0:
                return {
                    'status': 'healthy',
                    'timestamp': timezone.now().isoformat(),
                    'version': result.stdout.strip(),
                    'active_labs': self._get_local_active_labs()
                }
            else:
                return {
                    'status': 'unhealthy',
                    'timestamp': timezone.now().isoformat(),
                    'error': 'Containerlab not available'
                }
        except Exception as e:
            return {
                'status': 'error',
                'timestamp': timezone.now().isoformat(),
                'error': str(e)
            }
    
    def _check_api_health(self, config: Dict) -> Dict:
        """Check remote server health via API"""
        try:
            api_config = config.get('api_config', {})
            endpoint = api_config.get('endpoint')
            
            if not endpoint:
                return {
                    'status': 'error',
                    'timestamp': timezone.now().isoformat(),
                    'error': 'No API endpoint configured'
                }
            
            response = requests.get(f"{endpoint}/health", timeout=30)
            
            if response.status_code == 200:
                data = response.json()
                resources = data.get('resources', {})
                
                return {
                    'status': 'healthy',
                    'timestamp': timezone.now().isoformat(),
                    'active_labs': data.get('active_labs', 0),
                    'version': data.get('version', 'Unknown'),
                    'cpu_usage': resources.get('cpu_percent'),
                    'memory_usage': resources.get('memory_percent'),
                    'memory_used_gb': resources.get('memory_used_gb'),
                    'memory_total_gb': resources.get('memory_total_gb'),
                    'disk_usage': resources.get('disk_percent')
                }
            else:
                return {
                    'status': 'unhealthy',
                    'timestamp': timezone.now().isoformat(),
                    'error': f'API returned {response.status_code}'
                }
        except Exception as e:
            logger.warning(f"API health check failed for {config.get('host')}: {e}")
            return {
                'status': 'error',
                'timestamp': timezone.now().isoformat(),
                'error': str(e)
            }
    
    def _check_ssh_health(self, config: Dict) -> Dict:
        """Check remote server health via SSH"""
        try:
            ssh_config = config.get('ssh_config', {})
            
            ssh = paramiko.SSHClient()
            ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            
            ssh.connect(
                hostname=config.get('host'),
                username=ssh_config.get('username'),
                password=ssh_config.get('password'),
                key_filename=ssh_config.get('key_file'),
                timeout=self.connect_timeout
            )
            
            stdin, stdout, stderr = ssh.exec_command('clab version')
            exit_code = stdout.channel.recv_exit_status()
            
            ssh.close()
            
            if exit_code == 0:
                return {
                    'status': 'healthy',
                    'timestamp': timezone.now().isoformat(),
                    'version': stdout.read().decode().strip()
                }
            else:
                return {
                    'status': 'unhealthy',
                    'timestamp': timezone.now().isoformat(),
                    'error': 'Containerlab not available'
                }
        except Exception as e:
            return {
                'status': 'error',
                'timestamp': timezone.now().isoformat(),
                'error': str(e)
            }
    
    def deploy_lab(self, server_id: str, lab_name: str, yaml_content: str, 
                   progress_callback=None) -> Dict:
        """Deploy lab to specified remote server"""
        
        config = self.servers.get(server_id)
        if not config:
            raise ValueError(f"Server {server_id} not found")
        
        if not config.get('enabled', True):
            raise ValueError(f"Server {server_id} is disabled")
        
        deployment_id = str(uuid.uuid4())
        
        try:
            if progress_callback:
                progress_callback(10, "Preparing deployment...")
            
            if config.get('type') == 'local':
                result = self._deploy_local_lab(lab_name, yaml_content, progress_callback)
            elif config.get('type') == 'hybrid':
                # For hybrid servers, try API first, then fall back to SSH
                api_config = config.get('api_config', {})
                if api_config.get('enabled', False):
                    try:
                        result = self._deploy_api_lab(config, lab_name, yaml_content, 
                                                    deployment_id, progress_callback)
                    except Exception as api_error:
                        logger.warning(f"API deployment failed for hybrid server, trying SSH: {api_error}")
                        result = self._deploy_ssh_lab(config, lab_name, yaml_content, 
                                                    deployment_id, progress_callback)
                else:
                    result = self._deploy_ssh_lab(config, lab_name, yaml_content, 
                                                deployment_id, progress_callback)
            else:
                api_config = config.get('api_config', {})
                if api_config.get('enabled', False):
                    try:
                        result = self._deploy_api_lab(config, lab_name, yaml_content, 
                                                    deployment_id, progress_callback)
                    except Exception as api_error:
                        logger.warning(f"API deployment failed, trying SSH: {api_error}")
                        result = self._deploy_ssh_lab(config, lab_name, yaml_content, 
                                                    deployment_id, progress_callback)
                else:
                    result = self._deploy_ssh_lab(config, lab_name, yaml_content, 
                                                deployment_id, progress_callback)
            
            return {
                'success': True,
                'deployment_id': deployment_id,
                'server_id': server_id,
                **result
            }
            
        except Exception as e:
            logger.error(f"Lab deployment failed on {server_id}: {str(e)}")
            return {
                'success': False,
                'deployment_id': deployment_id,
                'server_id': server_id,
                'error': str(e)
            }
    
    def deploy_lab_with_configs(self, server_id: str, lab_name: str, yaml_content: str, 
                               device_configs: dict, progress_callback=None) -> Dict:
        """Deploy lab with integrated device configurations"""
        
        config = self.servers.get(server_id)
        if not config:
            raise ValueError(f"Server {server_id} not found")
        
        if not config.get('enabled', True):
            raise ValueError(f"Server {server_id} is disabled")
        
        deployment_id = str(uuid.uuid4())
        
        try:
            if progress_callback:
                progress_callback(10, f"Preparing enhanced deployment with {len(device_configs)} configurations...")
            
            if config.get('type') == 'local':
                # Use enhanced_app.py API for local deployment to ensure consistent error handling
                result = self._deploy_enhanced_api_lab(config, lab_name, yaml_content, 
                                                     device_configs, deployment_id, progress_callback)
            elif config.get('type') == 'hybrid':
                # For hybrid servers, try enhanced API first, then fall back to standard API, then SSH
                api_config = config.get('api_config', {})
                if api_config.get('enabled', False):
                    try:
                        result = self._deploy_enhanced_api_lab(config, lab_name, yaml_content, 
                                                             device_configs, deployment_id, progress_callback)
                    except Exception as api_error:
                        logger.warning(f"Enhanced API deployment failed for hybrid server, falling back to standard: {api_error}")
                        try:
                            result = self._deploy_api_lab(config, lab_name, yaml_content, deployment_id, progress_callback)
                        except Exception as standard_api_error:
                            logger.warning(f"Standard API deployment failed for hybrid server, falling back to SSH: {standard_api_error}")
                            result = self._deploy_ssh_lab(config, lab_name, yaml_content, deployment_id, progress_callback)
                else:
                    result = self._deploy_ssh_lab(config, lab_name, yaml_content, deployment_id, progress_callback)
            else:
                api_config = config.get('api_config', {})
                if api_config.get('enabled', False):
                    try:
                        result = self._deploy_enhanced_api_lab(config, lab_name, yaml_content, 
                                                             device_configs, deployment_id, progress_callback)
                    except Exception as api_error:
                        logger.warning(f"Enhanced API deployment failed, falling back to standard: {api_error}")
                        result = self._deploy_api_lab(config, lab_name, yaml_content, deployment_id, progress_callback)
                else:
                    result = self._deploy_ssh_lab(config, lab_name, yaml_content, deployment_id, progress_callback)
            
            return {
                'success': result.get('success', True) and not result.get('has_error', False),
                'deployment_id': deployment_id,
                'server_id': server_id,
                'configurations_applied': len(device_configs),
                'has_error': result.get('has_error', False),
                'error': result.get('error'),
                'message': result.get('message'),
                'logs': result.get('logs'),
                **result
            }
            
        except Exception as e:
            logger.error(f"Error deploying lab with configurations: {e}")
            return {
                'success': False,
                'has_error': True,
                'error': str(e),
                'message': f"Deployment failed: {str(e)}"
            }
    
    def _deploy_enhanced_api_lab(self, config: Dict, lab_name: str, yaml_content: str, 
                                device_configs: dict, deployment_id: str, progress_callback=None) -> Dict:
        """Deploy lab using enhanced API endpoint with configuration integration and improved error handling"""
        
        try:
            api_config = config.get('api_config', {})
            endpoint = f"http://{config['host']}:{api_config.get('port', DEFAULT_API_PORT)}"
            
            if progress_callback:
                progress_callback(20, "Sending enhanced deployment request...")
            
            logger.info(f"Enhanced API deployment to {endpoint}")
            logger.info(f"Device configurations: {len(device_configs)} devices")
            
            response = requests.post(
                f"{endpoint}/deploy-with-configs",
                json={
                    'lab_name': lab_name,
                    'yaml_content': yaml_content,
                    'device_configs': device_configs,
                    'deployment_id': deployment_id
                },
                timeout=DEFAULT_TIMEOUT
            )
            
            if response.status_code == 200:
                result = response.json()
                logger.info(f"Enhanced deployment accepted: {result}")
                
                if progress_callback:
                    progress_callback(40, "Enhanced deployment started, monitoring progress...")
                
                # Enhanced polling with error detection
                poll_result = self._poll_api_deployment(endpoint, deployment_id, progress_callback)
                
                # Check for has_error flag in the final result
                if poll_result.get('has_error') or poll_result.get('return_code', 0) != 0:
                    error_msg = poll_result.get('error', poll_result.get('message', 'Enhanced deployment failed'))
                    logger.error(f"Enhanced deployment failed: {error_msg}")
                    raise Exception(error_msg)
                    
                return poll_result
            else:
                raise Exception(f"Enhanced API deployment failed: {response.status_code} - {response.text}")
                
        except Exception as e:
            logger.error(f"Enhanced API deployment error: {e}")
            raise
    
    def _deploy_api_lab(self, config: Dict, lab_name: str, yaml_content: str,
                       deployment_id: str, progress_callback=None) -> Dict:
        """Deploy lab via REST API"""
        
        api_config = config.get('api_config', {})
        endpoint = api_config.get('endpoint')
        
        if not endpoint:
            raise Exception('No API endpoint configured')
        
        if progress_callback:
            progress_callback(30, "Uploading configuration to remote server...")
        
        payload = {
            'lab_name': lab_name,
            'yaml_content': yaml_content,
            'deployment_id': deployment_id
        }
        
        headers = {'Content-Type': 'application/json'}
        timeout = api_config.get('timeout', COMMAND_TIMEOUT)
        
        response = requests.post(f"{endpoint}/deploy", 
                               json=payload, headers=headers, 
                               timeout=timeout)
        
        if response.status_code != 200:
            raise Exception(f"API deployment failed: {response.status_code} - {response.text}")
        
        result_data = response.json()
        
        if result_data.get('status') != 'accepted':
            raise Exception(f"API deployment rejected: {result_data.get('error', 'Unknown error')}")
        
        return self._poll_api_deployment(endpoint, deployment_id, progress_callback)
    
    def _poll_api_deployment(self, endpoint: str, deployment_id: str, 
                           progress_callback=None) -> Dict:
        """Poll API for deployment status with enhanced error detection"""
        
        start_time = timezone.now().timestamp()
        
        while timezone.now().timestamp() - start_time < DEPLOYMENT_TIMEOUT:
            try:
                response = requests.get(f"{endpoint}/deployment/{deployment_id}/status", 
                                      timeout=10)
                
                if response.status_code == 200:
                    status_data = response.json()
                    logger.info(f"Deployment {deployment_id} status: {status_data}")
                    
                    if progress_callback:
                        progress_callback(
                            status_data.get('progress', 50),
                            status_data.get('message', 'Deploying...')
                        )
                    
                    # Enhanced completion checking - look for has_error flag
                    if status_data.get('status') == 'completed' and not status_data.get('has_error', False):
                        return {
                            'message': status_data.get('message', 'Deployment completed'),
                            'logs': status_data.get('logs', ''),
                            'return_code': 0,
                            'has_error': False
                        }
                    elif status_data.get('status') == 'failed' or status_data.get('has_error', False):
                        return {
                            'message': status_data.get('error', status_data.get('message', 'Deployment failed')),
                            'logs': status_data.get('logs', ''),
                            'return_code': 1,
                            'has_error': True,
                            'error': status_data.get('error', status_data.get('message', 'Deployment failed'))
                        }
                    
                    # Continue polling for running status
                    if status_data.get('status') in ['running', 'accepted']:
                        time.sleep(POLL_INTERVAL)
                        continue
                    
                    # Unknown status - assume failure
                    logger.warning(f"Unknown deployment status: {status_data.get('status')}")
                    return {
                        'message': f"Unknown deployment status: {status_data.get('status')}",
                        'logs': status_data.get('logs', ''),
                        'return_code': 1,
                        'has_error': True,
                        'error': f"Unknown deployment status: {status_data.get('status')}"
                    }
                
                time.sleep(POLL_INTERVAL)
                
            except requests.RequestException as e:
                logger.warning(f"Status polling failed: {e}")
                time.sleep(5)
        
        # Timeout
        return {
            'message': f"Deployment timeout after {DEPLOYMENT_TIMEOUT} seconds",
            'logs': '',
            'return_code': 1,
            'has_error': True,
            'error': f"Deployment timeout after {DEPLOYMENT_TIMEOUT} seconds"
        }
    
    def _deploy_ssh_lab(self, config: Dict, lab_name: str, yaml_content: str,
                       deployment_id: str, progress_callback=None) -> Dict:
        """Deploy lab via SSH"""
        
        ssh_config = config.get('ssh_config', {})
        
        if progress_callback:
            progress_callback(20, "Connecting to remote server...")
        
        ssh = paramiko.SSHClient()
        ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        
        ssh.connect(
            hostname=config.get('host'),
            username=ssh_config.get('username'),
            password=ssh_config.get('password'),
            key_filename=ssh_config.get('key_file'),
            timeout=self.connect_timeout
        )
        
        try:
            if progress_callback:
                progress_callback(30, "Uploading YAML configuration...")
            
            working_dir = config.get('working_directory', '/tmp')
            remote_yaml_path = f"{working_dir}/temp_labs/{lab_name}_{deployment_id}.clab.yml"
            
            ssh.exec_command(f'mkdir -p {working_dir}/temp_labs')
            
            sftp = ssh.open_sftp()
            with sftp.open(remote_yaml_path, 'w') as remote_file:
                remote_file.write(yaml_content)
            sftp.close()
            
            if progress_callback:
                progress_callback(50, "Starting remote Containerlab deployment...")
            
            cmd = f'cd {working_dir} && clab deploy -t {remote_yaml_path} --reconfigure'
            stdin, stdout, stderr = ssh.exec_command(cmd)
            
            output_lines = []
            progress = 50
            
            while True:
                line = stdout.readline()
                if not line:
                    break
                
                output_lines.append(line.strip())
                
                if progress_callback:
                    if 'Creating' in line:
                        progress = min(progress + 5, 80)
                    elif 'Starting' in line:
                        progress = min(progress + 3, 90)
                    elif 'deployment' in line.lower() and 'complete' in line.lower():
                        progress = 95
                    
                    progress_callback(progress, line.strip())
            
            exit_code = stdout.channel.recv_exit_status()
            
            if exit_code == 0:
                if progress_callback:
                    progress_callback(100, "Remote deployment completed successfully!")
                
                return {
                    'message': f'Lab "{lab_name}" deployed successfully on remote server',
                    'logs': '\n'.join(output_lines),
                    'return_code': exit_code,
                    'remote_host': config.get('host')
                }
            else:
                stderr_output = stderr.read().decode()
                raise Exception(f"Remote deployment failed: {stderr_output}")
                
        finally:
            try:
                ssh.exec_command(f'rm -f {remote_yaml_path}')
            except:
                pass
            ssh.close()
    
    def _deploy_local_lab(self, lab_name: str, yaml_content: str, 
                         progress_callback=None) -> Dict:
        """Deploy lab locally"""
        
        if progress_callback:
            progress_callback(20, "Preparing local deployment...")
        
        plugin_settings = settings.PLUGINS_CONFIG.get('nautobot_containerlab', {})
        lab_dir = plugin_settings.get('lab_directory', '/tmp/nautobot_labs')
        clab_binary = plugin_settings.get('containerlab_binary_path', 'clab')
        timeout = plugin_settings.get('lab_timeout_seconds', 1800)

        os.makedirs(lab_dir, exist_ok=True)
        topo_file = os.path.join(lab_dir, f"{lab_name}.clab.yml")

        with open(topo_file, 'w', encoding='utf-8') as f:
            f.write(yaml_content)

        logs = []
        logs.append(f"Starting Containerlab deployment for lab: {lab_name}")
        
        if progress_callback:
            progress_callback(30, "Cleaning up existing lab...")

        try:
            cleanup_cmd = [clab_binary, "destroy", "-t", topo_file, "--cleanup"]
            cleanup_result = subprocess.run(
                cleanup_cmd,
                capture_output=True,
                text=True,
                timeout=COMMAND_TIMEOUT,
                cwd=lab_dir,
            )
            
            if cleanup_result.returncode == 0:
                logs.append("Existing lab cleaned up successfully")
            else:
                if "no containers found" not in cleanup_result.stderr.lower():
                    logs.append(f"Cleanup warnings: {cleanup_result.stderr}")

            if progress_callback:
                progress_callback(50, "Deploying new lab...")

            deploy_cmd = [clab_binary, "deploy", "-t", topo_file]
            deploy_result = subprocess.run(
                deploy_cmd,
                capture_output=True,
                text=True,
                timeout=timeout,
                cwd=lab_dir,
            )
            
            if deploy_result.returncode == 0:
                logs.append("🎉 Lab deployed successfully!")
                logs.append("Deployment Output:")
                logs.append(deploy_result.stdout)
                
                if progress_callback:
                    progress_callback(100, "Local deployment completed successfully!")
                
                return {
                    'message': f'Lab "{lab_name}" deployed successfully',
                    'logs': '\n'.join(logs),
                    'return_code': 0
                }
            else:
                logs.append(f"❌ Lab deployment failed!")
                logs.append(f"Error: {deploy_result.stderr}")
                raise Exception('\n'.join(logs))

        except subprocess.TimeoutExpired:
            error_msg = f"⏱️ Lab deployment timed out after {timeout} seconds"
            logs.append(error_msg)
            raise Exception('\n'.join(logs))
        
        except FileNotFoundError:
            error_msg = f"❌ Containerlab binary not found at: {clab_binary}"
            logs.append(error_msg)
            raise Exception('\n'.join(logs))
    
    def _get_local_active_labs(self) -> int:
        """Get number of active local labs"""
        try:
            result = subprocess.run(['clab', 'inspect', '--all'], 
                                  capture_output=True, text=True, timeout=10)
            if result.returncode == 0:
                lines = result.stdout.strip().split('\n')
                return len([line for line in lines if 'running' in line.lower()])
            return 0
        except:
            return 0
    
    def get_active_labs(self, server_id: str) -> Dict:
        """Get list of active labs on a specific server"""
        config = self.servers.get(server_id)
        if not config:
            return {'success': False, 'error': f'Server {server_id} not found'}
        
        try:
            if config.get('type') == 'local':
                return self._get_local_active_labs_detailed(server_id)
            elif config.get('type') == 'hybrid':
                # For hybrid servers, try API first, then fall back to SSH
                api_config = config.get('api_config', {})
                if api_config.get('enabled', False):
                    try:
                        return self._get_api_active_labs(config, server_id)
                    except Exception as api_error:
                        logger.warning(f"API active labs failed for hybrid server {server_id}, falling back to SSH: {api_error}")
                        return self._get_ssh_active_labs(config, server_id)
                else:
                    return self._get_ssh_active_labs(config, server_id)
            else:
                api_config = config.get('api_config', {})
                if api_config.get('enabled', False):
                    return self._get_api_active_labs(config, server_id)
                else:
                    return self._get_ssh_active_labs(config, server_id)
        except Exception as e:
            logger.error(f"Error getting active labs from {server_id}: {e}")
            return {'success': False, 'error': str(e)}
    
    def _get_local_active_labs_detailed(self, server_id: str) -> Dict:
        """Get detailed list of local active labs"""
        try:
            result = subprocess.run(['clab', 'inspect', '--all', '--format', 'json'], 
                                  capture_output=True, text=True, timeout=DEFAULT_TIMEOUT)
            if result.returncode == 0 and result.stdout.strip():
                inspect_data = json.loads(result.stdout)
                
                labs = {}
                for container_name, container_info in inspect_data.items():
                    lab_name = container_info.get('lab-name', 'unknown')
                    if lab_name not in labs:
                        labs[lab_name] = {
                            'name': lab_name,
                            'server_id': server_id,  # Add server_id for local labs
                            'containers': [],
                            'running_count': 0,
                            'total_count': 0
                        }
                    
                    container_status = container_info.get('state', 'unknown')
                    labs[lab_name]['containers'].append({
                        'name': container_name,
                        'state': container_status,  # Use 'state' to match frontend expectation
                        'status': container_status,  # Keep 'status' for backward compatibility
                        'image': container_info.get('image', 'unknown'),
                        'kind': container_info.get('kind', 'unknown')
                    })
                    
                    labs[lab_name]['total_count'] += 1
                    if container_status.lower() == 'running':
                        labs[lab_name]['running_count'] += 1
                
                return {
                    'success': True,
                    'labs': list(labs.values()),
                    'total_count': len(labs)
                }
            else:
                return {'success': True, 'labs': [], 'total_count': 0}
        except Exception as e:
            logger.error(f"Error getting local active labs: {e}")
            return {'success': False, 'error': str(e)}
    
    def _get_api_active_labs(self, config: Dict, server_id: str) -> Dict:
        """Get active labs via API"""
        try:
            api_config = config.get('api_config', {})
            endpoint = api_config.get('endpoint')
            
            if not endpoint:
                return {'success': False, 'error': 'No API endpoint configured'}
            
            response = requests.get(f"{endpoint}/labs", timeout=DEFAULT_TIMEOUT)
            
            if response.status_code == 200:
                data = response.json()
                if data.get('status') == 'success':
                    # Add server_id to each lab
                    labs = data.get('labs', [])
                    for lab in labs:
                        lab['server_id'] = server_id
                    
                    return {
                        'success': True,
                        'labs': labs,
                        'total_count': data.get('total_count', 0)
                    }
                else:
                    return {
                        'success': False,
                        'error': data.get('error', 'Unknown error from API')
                    }
            else:
                return {
                    'success': False,
                    'error': f'API returned {response.status_code}: {response.text}'
                }
        except Exception as e:
            logger.error(f"Error getting API active labs: {e}")
            return {'success': False, 'error': str(e)}
    
    def _get_ssh_active_labs(self, config: Dict, server_id: str) -> Dict:
        """Get active labs via SSH"""
        try:
            ssh_config = config.get('ssh_config', {})
            
            ssh = paramiko.SSHClient()
            ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            
            ssh.connect(
                hostname=config.get('host'),
                username=ssh_config.get('username'),
                password=ssh_config.get('password'),
                key_filename=ssh_config.get('key_file'),
                timeout=self.connect_timeout
            )
            
            stdin, stdout, stderr = ssh.exec_command('clab inspect --all --format json')
            exit_code = stdout.channel.recv_exit_status()
            
            if exit_code == 0:
                output = stdout.read().decode().strip()
                if output:
                    inspect_data = json.loads(output)
                    
                    labs = {}
                    for container_name, container_info in inspect_data.items():
                        lab_name = container_info.get('lab-name', 'unknown')
                        if lab_name not in labs:
                            labs[lab_name] = {
                                'name': lab_name,
                                'server_id': server_id,  # Add server_id for SSH labs
                                'containers': [],
                                'running_count': 0,
                                'total_count': 0
                            }
                        
                        container_status = container_info.get('state', 'unknown')
                        labs[lab_name]['containers'].append({
                            'name': container_name,
                            'status': container_status,
                            'image': container_info.get('image', 'unknown'),
                            'kind': container_info.get('kind', 'unknown')
                        })
                        
                        labs[lab_name]['total_count'] += 1
                        if container_status.lower() == 'running':
                            labs[lab_name]['running_count'] += 1
                    
                    ssh.close()
                    return {
                        'success': True,
                        'labs': list(labs.values()),
                        'total_count': len(labs)
                    }
                else:
                    ssh.close()
                    return {'success': True, 'labs': [], 'total_count': 0}
            else:
                error_output = stderr.read().decode()
                ssh.close()
                return {'success': False, 'error': f'Command failed: {error_output}'}
                
        except Exception as e:
            logger.error(f"Error getting SSH active labs: {e}")
            return {'success': False, 'error': str(e)}
    
    def stop_lab(self, server_id: str, lab_name: str) -> Dict:
        """Stop a specific lab on a server"""
        config = self.servers.get(server_id)
        if not config:
            return {'success': False, 'error': f'Server {server_id} not found'}
        
        try:
            if config.get('type') == 'local':
                return self._stop_local_lab(lab_name)
            elif config.get('type') == 'hybrid':
                # For hybrid servers, try API first, then fall back to SSH
                api_config = config.get('api_config', {})
                if api_config.get('enabled', False):
                    try:
                        return self._stop_api_lab(config, lab_name)
                    except Exception as api_error:
                        logger.warning(f"API stop lab failed for hybrid server {server_id}, falling back to SSH: {api_error}")
                        return self._stop_ssh_lab(config, lab_name)
                else:
                    return self._stop_ssh_lab(config, lab_name)
            else:
                api_config = config.get('api_config', {})
                if api_config.get('enabled', False):
                    return self._stop_api_lab(config, lab_name)
                else:
                    return self._stop_ssh_lab(config, lab_name)
        except Exception as e:
            logger.error(f"Error stopping lab {lab_name} on {server_id}: {e}")
            return {'success': False, 'error': str(e)}
    
    def _stop_local_lab(self, lab_name: str) -> Dict:
        """Stop a local lab"""
        try:
            result = subprocess.run(
                ['clab', 'destroy', '--name', lab_name, '--cleanup'],
                capture_output=True,
                text=True,
                timeout=COMMAND_TIMEOUT
            )
            
            if result.returncode == 0:
                return {
                    'success': True,
                    'message': f'Lab {lab_name} stopped successfully',
                    'logs': result.stdout
                }
            else:
                return {
                    'success': False,
                    'error': f'Failed to stop lab: {result.stderr}',
                    'logs': result.stdout
                }
        except Exception as e:
            logger.error(f"Error stopping local lab {lab_name}: {e}")
            return {'success': False, 'error': str(e)}
    
    def _stop_api_lab(self, config: Dict, lab_name: str) -> Dict:
        """Stop lab via API"""
        try:
            api_config = config.get('api_config', {})
            endpoint = api_config.get('endpoint')
            
            if not endpoint:
                return {'success': False, 'error': 'No API endpoint configured'}
            
            response = requests.post(f"{endpoint}/labs/{lab_name}/stop", timeout=COMMAND_TIMEOUT)
            
            if response.status_code == 200:
                data = response.json()
                if data.get('status') == 'success':
                    return {
                        'success': True,
                        'message': data.get('message', f'Lab {lab_name} stopped successfully'),
                        'logs': data.get('logs', '')
                    }
                else:
                    return {
                        'success': False,
                        'error': data.get('error', 'Unknown error from API')
                    }
            else:
                return {
                    'success': False,
                    'error': f'API returned {response.status_code}: {response.text}'
                }
        except Exception as e:
            logger.error(f"Error stopping API lab {lab_name}: {e}")
            return {'success': False, 'error': str(e)}
    
    def _stop_ssh_lab(self, config: Dict, lab_name: str) -> Dict:
        """Stop lab via SSH"""
        try:
            ssh_config = config.get('ssh_config', {})
            
            ssh = paramiko.SSHClient()
            ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            
            ssh.connect(
                hostname=config.get('host'),
                username=ssh_config.get('username'),
                password=ssh_config.get('password'),
                key_filename=ssh_config.get('key_file'),
                timeout=self.connect_timeout
            )
            
            stdin, stdout, stderr = ssh.exec_command(f'clab destroy --name {lab_name} --cleanup')
            exit_code = stdout.channel.recv_exit_status()
            
            if exit_code == 0:
                logs = stdout.read().decode()
                ssh.close()
                return {
                    'success': True,
                    'message': f'Lab {lab_name} stopped successfully',
                    'logs': logs
                }
            else:
                error_output = stderr.read().decode()
                ssh.close()
                return {'success': False, 'error': f'Failed to stop lab: {error_output}'}
                
        except Exception as e:
            logger.error(f"Error stopping SSH lab {lab_name}: {e}")
            return {'success': False, 'error': str(e)}
    
    def get_lab_logs(self, server_id: str, lab_name: str) -> Dict:
        """Get logs for a specific lab"""
        config = self.servers.get(server_id)
        if not config:
            return {'success': False, 'error': f'Server {server_id} not found'}
        
        try:
            if config.get('type') == 'local':
                return self._get_local_lab_logs(lab_name)
            elif config.get('type') == 'hybrid':
                # For hybrid servers, try API first, then fall back to SSH
                api_config = config.get('api_config', {})
                if api_config.get('enabled', False):
                    try:
                        return self._get_api_lab_logs(config, lab_name)
                    except Exception as api_error:
                        logger.warning(f"API get lab logs failed for hybrid server {server_id}, falling back to SSH: {api_error}")
                        return self._get_ssh_lab_logs(config, lab_name)
                else:
                    return self._get_ssh_lab_logs(config, lab_name)
            else:
                api_config = config.get('api_config', {})
                if api_config.get('enabled', False):
                    return self._get_api_lab_logs(config, lab_name)
                else:
                    return self._get_ssh_lab_logs(config, lab_name)
        except Exception as e:
            logger.error(f"Error getting logs for lab {lab_name} on {server_id}: {e}")
            return {'success': False, 'error': str(e)}
    
    def _get_local_lab_logs(self, lab_name: str) -> Dict:
        """Get logs for local lab containers"""
        try:
            result = subprocess.run(['clab', 'inspect', '--name', lab_name, '--format', 'json'], 
                                  capture_output=True, text=True, timeout=DEFAULT_TIMEOUT)
            
            if result.returncode != 0:
                return {'success': False, 'error': f'Lab {lab_name} not found'}
            
            inspect_data = json.loads(result.stdout) if result.stdout.strip() else {}
            
            container_logs = {}
            for container_name in inspect_data.keys():
                try:
                    log_result = subprocess.run(
                        ['docker', 'logs', '--tail', '100', container_name],
                        capture_output=True,
                        text=True,
                        timeout=DEFAULT_TIMEOUT
                    )
                    container_logs[container_name] = {
                        'stdout': log_result.stdout,
                        'stderr': log_result.stderr
                    }
                except Exception as e:
                    container_logs[container_name] = {
                        'error': f'Failed to get logs: {str(e)}'
                    }
            
            return {
                'success': True,
                'lab_name': lab_name,
                'container_logs': container_logs
            }
            
        except Exception as e:
            logger.error(f"Error getting local lab logs {lab_name}: {e}")
            return {'success': False, 'error': str(e)}
    
    def _get_api_lab_logs(self, config: Dict, lab_name: str) -> Dict:
        """Get lab logs via API"""
        try:
            api_config = config.get('api_config', {})
            endpoint = api_config.get('endpoint')
            
            if not endpoint:
                return {'success': False, 'error': 'No API endpoint configured'}
            
            response = requests.get(f"{endpoint}/labs/{lab_name}/logs", timeout=60)
            
            if response.status_code == 200:
                data = response.json()
                if data.get('status') == 'success':
                    return {
                        'success': True,
                        'lab_name': data.get('lab_name', lab_name),
                        'container_logs': data.get('container_logs', {})
                    }
                else:
                    return {
                        'success': False,
                        'error': data.get('error', 'Unknown error from API')
                    }
            else:
                return {
                    'success': False,
                    'error': f'API returned {response.status_code}: {response.text}'
                }
        except Exception as e:
            logger.error(f"Error getting API lab logs {lab_name}: {e}")
            return {'success': False, 'error': str(e)}
    
    def _get_ssh_lab_logs(self, config: Dict, lab_name: str) -> Dict:
        """Get lab logs via SSH"""
        try:
            ssh_config = config.get('ssh_config', {})
            
            ssh = paramiko.SSHClient()
            ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            
            ssh.connect(
                hostname=config.get('host'),
                username=ssh_config.get('username'),
                password=ssh_config.get('password'),
                key_filename=ssh_config.get('key_file'),
                timeout=self.connect_timeout
            )
            
            stdin, stdout, stderr = ssh.exec_command(f'clab inspect --name {lab_name} --format json')
            exit_code = stdout.channel.recv_exit_status()
            
            if exit_code != 0:
                ssh.close()
                return {'success': False, 'error': f'Lab {lab_name} not found'}
            
            output = stdout.read().decode().strip()
            if output:
                inspect_data = json.loads(output)
                
                container_logs = {}
                for container_name in inspect_data.keys():
                    try:
                        stdin, stdout, stderr = ssh.exec_command(f'docker logs --tail 100 {container_name}')
                        stdout.channel.recv_exit_status()
                        
                        container_logs[container_name] = {
                            'stdout': stdout.read().decode(),
                            'stderr': stderr.read().decode()
                        }
                    except Exception as e:
                        container_logs[container_name] = {
                            'error': f'Failed to get logs: {str(e)}'
                        }
                
                ssh.close()
                return {
                    'success': True,
                    'lab_name': lab_name,
                    'container_logs': container_logs
                }
            else:
                ssh.close()
                return {'success': False, 'error': f'No containers found for lab {lab_name}'}
                
        except Exception as e:
            logger.error(f"Error getting SSH lab logs {lab_name}: {e}")
            return {'success': False, 'error': str(e)}

    # Terminal/Device CLI Methods
    def _execute_local_device_command(self, lab_name: str, device_name: str, command: str) -> Dict:
        """Execute command on device in local lab"""
        try:
            # First check if the lab and device exist and get device info
            result = subprocess.run(['clab', 'inspect', '--name', lab_name, '--format', 'json'], 
                                  capture_output=True, text=True, timeout=DEFAULT_TIMEOUT)
            
            if result.returncode != 0:
                return {'success': False, 'error': f'Lab {lab_name} not found'}
            
            inspect_data = json.loads(result.stdout) if result.stdout.strip() else {}
            
            # The structure is: {lab_name: [array_of_devices]}
            lab_devices = inspect_data.get(lab_name, [])
            device_info = None
            
            # Find the device in the array
            for device in lab_devices:
                if device.get('name') == device_name:
                    device_info = device
                    break
            
            if not device_info:
                return {'success': False, 'error': f'Device {device_name} not found in lab {lab_name}'}
            
            # Get device image and determine proper shell
            image = device_info.get('image', '')
            shell_info = self._determine_shell_type(image, device_name)
            shell_type = shell_info.get('type', 'generic')
            shell_command = shell_info.get('shell', 'sh')
            
            # Execute command using appropriate shell
            if shell_type in ['frr', 'cisco', 'arista']:
                # For network devices, use vtysh to execute commands
                if shell_command == 'vtysh':
                    if shell_type == 'frr':
                        # For FRR devices, use -E flag to suppress config file reading and redirect stderr
                        docker_cmd = ['docker', 'exec', device_name, 'vtysh', '-E', '-c', command]
                    else:
                        docker_cmd = ['docker', 'exec', device_name, 'vtysh', '-c', command]
                else:
                    # Fallback to sh for other shell commands
                    docker_cmd = ['docker', 'exec', device_name, 'sh', '-c', command]
            elif shell_type == 'juniper':
                # For Juniper devices, use the cli command
                docker_cmd = ['docker', 'exec', device_name, 'cli', '-c', command]
            elif shell_type == 'linux':
                # For Linux devices, use bash
                docker_cmd = ['docker', 'exec', device_name, 'bash', '-c', command]
            else:
                # Generic/fallback case
                docker_cmd = ['docker', 'exec', device_name, 'sh', '-c', command]
                
            logger.info(f"Executing command on {device_name} (type: {shell_type}, shell: {shell_command}): {docker_cmd}")
            exec_result = subprocess.run(docker_cmd, capture_output=True, text=True, timeout=30)
            
            return {
                'success': True,
                'output': exec_result.stdout,
                'error': exec_result.stderr,
                'return_code': exec_result.returncode,
                'device_name': device_name,
                'command': command,
                'shell_type': shell_type,
                'shell_command': shell_command
            }
            
        except Exception as e:
            logger.error(f"Error executing local device command: {e}")
            return {'success': False, 'error': str(e)}

    def _execute_api_device_command(self, config: Dict, lab_name: str, device_name: str, command: str) -> Dict:
        """Execute command on device via API"""
        try:
            # Get endpoint from api_config section
            api_config = config.get('api_config', {})
            endpoint = api_config.get('endpoint')
            
            if not endpoint:
                # Fallback: construct endpoint from host and port
                host = config.get('host', 'localhost')
                port = api_config.get('port', DEFAULT_API_PORT)
                endpoint = f"http://{host}:{port}"
            
            headers = {'Content-Type': 'application/json'}
            
            # Use the digital-twin specific endpoint with path parameters
            # The lab_type is typically 'clab' for containerlab
            lab_type = 'clab'
            url = f"{endpoint}/digital-twin/device-exec/{lab_type}/{lab_name}/{device_name}/"
            
            payload = {
                'command': command
            }
            
            logger.info(f"Making API request to: {url}")
            response = requests.post(url, json=payload, headers=headers, timeout=30)
            
            if response.status_code == 200:
                return response.json()
            else:
                logger.error(f"API request failed with status {response.status_code}: {response.text}")
                return {'success': False, 'error': f'API request failed: {response.status_code}'}
                
        except Exception as e:
            logger.error(f"Error executing API device command: {e}")
            return {'success': False, 'error': str(e)}

    def _execute_ssh_device_command(self, config: Dict, lab_name: str, device_name: str, command: str) -> Dict:
        """Execute command on device via SSH"""
        try:
            ssh_config = config.get('ssh_config', {})
            
            ssh = paramiko.SSHClient()
            ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            
            ssh.connect(
                hostname=config.get('host'),
                username=ssh_config.get('username'),
                password=ssh_config.get('password'),
                key_filename=ssh_config.get('key_file'),
                timeout=self.connect_timeout
            )
            
            # First, get device info to determine proper shell
            inspect_cmd = f'clab inspect --name {lab_name} --format json'
            stdin, stdout, stderr = ssh.exec_command(inspect_cmd)
            inspect_output = stdout.read().decode()
            
            if inspect_output.strip():
                inspect_data = json.loads(inspect_output)
                lab_devices = inspect_data.get(lab_name, [])
                device_info = None
                
                for device in lab_devices:
                    if device.get('name') == device_name:
                        device_info = device
                        break
                
                if device_info:
                    image = device_info.get('image', '')
                    shell_info = self._determine_shell_type(image, device_name)
                    shell_type = shell_info.get('type', 'generic')
                    shell_command = shell_info.get('shell', 'sh')
                    
                    # Execute command using appropriate shell
                    if shell_type in ['frr', 'cisco', 'arista']:
                        if shell_command == 'vtysh':
                            if shell_type == 'frr':
                                # For FRR devices, use -E flag to suppress config file reading
                                docker_cmd = f'docker exec {device_name} vtysh -E -c "{command}"'
                            else:
                                docker_cmd = f'docker exec {device_name} vtysh -c "{command}"'
                        else:
                            docker_cmd = f'docker exec {device_name} sh -c "{command}"'
                    elif shell_type == 'juniper':
                        docker_cmd = f'docker exec {device_name} cli -c "{command}"'
                    elif shell_type == 'linux':
                        docker_cmd = f'docker exec {device_name} bash -c "{command}"'
                    else:
                        docker_cmd = f'docker exec {device_name} sh -c "{command}"'
                else:
                    # Fallback if device not found
                    docker_cmd = f'docker exec {device_name} sh -c "{command}"'
                    shell_type = 'generic'
                    shell_command = 'sh'
            else:
                # Fallback if inspect fails
                docker_cmd = f'docker exec {device_name} sh -c "{command}"'
                shell_type = 'generic'
                shell_command = 'sh'
            
            logger.info(f"Executing SSH command on {device_name} (type: {shell_type}, shell: {shell_command}): {docker_cmd}")
            stdin, stdout, stderr = ssh.exec_command(docker_cmd)
            
            output = stdout.read().decode()
            error = stderr.read().decode()
            exit_code = stdout.channel.recv_exit_status()
            
            ssh.close()
            
            return {
                'success': True,
                'output': output,
                'error': error,
                'return_code': exit_code,
                'device_name': device_name,
                'command': command,
                'shell_type': shell_type,
                'shell_command': shell_command
            }
            
        except Exception as e:
            logger.error(f"Error executing SSH device command: {e}")
            return {'success': False, 'error': str(e)}

    def _get_local_device_shell_info(self, lab_name: str, device_name: str) -> Dict:
        """Get shell information for local device"""
        try:
            # Get device type from containerlab inspect
            result = subprocess.run(['clab', 'inspect', '--name', lab_name, '--format', 'json'], 
                                  capture_output=True, text=True, timeout=DEFAULT_TIMEOUT)
            
            if result.returncode != 0:
                return {'success': False, 'error': f'Lab {lab_name} not found'}
            
            inspect_data = json.loads(result.stdout) if result.stdout.strip() else {}
            
            # The structure is: {lab_name: [array_of_devices]}
            lab_devices = inspect_data.get(lab_name, [])
            device_info = None
            
            # Find the device in the array
            for device in lab_devices:
                if device.get('name') == device_name:
                    device_info = device
                    break
            
            if not device_info:
                return {'success': False, 'error': f'Device {device_name} not found in lab {lab_name}'}
            image = device_info.get('image', '')
            
            # Determine shell type based on image
            shell_info = self._determine_shell_type(image, device_name)
            
            return {
                'success': True,
                'device_name': device_name,
                'image': image,
                'shell_info': shell_info
            }
            
        except Exception as e:
            logger.error(f"Error getting local device shell info: {e}")
            return {'success': False, 'error': str(e)}

    def _get_api_device_shell_info(self, config: Dict, lab_name: str, device_name: str) -> Dict:
        """Get shell information for device via API"""
        try:
            logger.info(f"🔍 _get_api_device_shell_info called with config: {config}")
            
            # Get endpoint from api_config section
            api_config = config.get('api_config', {})
            logger.info(f"🔍 api_config: {api_config}")
            
            endpoint = api_config.get('endpoint')
            logger.info(f"🔍 endpoint from api_config: {endpoint}")
            
            if not endpoint:
                # Fallback: construct endpoint from host and port
                host = config.get('host', 'localhost')
                port = api_config.get('port', DEFAULT_API_PORT)
                endpoint = f"http://{host}:{port}"
                logger.info(f"🔍 constructed endpoint: {endpoint}")
            
            headers = {'Content-Type': 'application/json'}
            
            # Use the digital-twin specific endpoint with path parameters
            # The lab_type is typically 'clab' for containerlab
            lab_type = 'clab'
            url = f"{endpoint}/digital-twin/device-shell-info/{lab_type}/{lab_name}/{device_name}/"
            
            logger.info(f"🔍 Making API request to: {url}")
            response = requests.get(url, headers=headers, timeout=10)
            
            if response.status_code == 200:
                return response.json()
            else:
                logger.error(f"🔍 API request failed with status {response.status_code}: {response.text}")
                return {'success': False, 'error': f'API request failed: {response.status_code}'}
                
        except Exception as e:
            logger.error(f"Error getting API device shell info: {e}")
            return {'success': False, 'error': str(e)}

    def _get_ssh_device_shell_info(self, config: Dict, lab_name: str, device_name: str) -> Dict:
        """Get shell information for device via SSH"""
        try:
            ssh_config = config.get('ssh_config', {})
            
            ssh = paramiko.SSHClient()
            ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            
            ssh.connect(
                hostname=config.get('host'),
                username=ssh_config.get('username'),
                password=ssh_config.get('password'),
                key_filename=ssh_config.get('key_file'),
                timeout=self.connect_timeout
            )
            
            # Get device info from remote server
            cmd = f'clab inspect --name {lab_name} --format json'
            stdin, stdout, stderr = ssh.exec_command(cmd)
            exit_code = stdout.channel.recv_exit_status()
            
            if exit_code != 0:
                ssh.close()
                return {'success': False, 'error': f'Lab {lab_name} not found on remote server'}
            
            output = stdout.read().decode().strip()
            if output:
                inspect_data = json.loads(output)
                if device_name in inspect_data:
                    device_info = inspect_data[device_name]
                    image = device_info.get('image', '')
                    shell_info = self._determine_shell_type(image, device_name)
                    
                    ssh.close()
                    return {
                        'success': True,
                        'device_name': device_name,
                        'image': image,
                        'shell_info': shell_info
                    }
            
            ssh.close()
            return {'success': False, 'error': f'Device {device_name} not found in lab {lab_name}'}
            
        except Exception as e:
            logger.error(f"Error getting SSH device shell info: {e}")
            return {'success': False, 'error': str(e)}

    def _get_local_device_commands(self, lab_name: str, device_name: str) -> Dict:
        """Get available commands for local device"""
        try:
            shell_info = self._get_local_device_shell_info(lab_name, device_name)
            if not shell_info.get('success'):
                return shell_info
            
            shell_type = shell_info.get('shell_info', {}).get('type', 'generic')
            commands = self._get_commands_for_shell_type(shell_type)
            
            return {
                'success': True,
                'device_name': device_name,
                'shell_type': shell_type,
                'commands': commands
            }
            
        except Exception as e:
            logger.error(f"Error getting local device commands: {e}")
            return {'success': False, 'error': str(e)}

    def _get_api_device_commands(self, config: Dict, lab_name: str, device_name: str) -> Dict:
        """Get available commands for device via API"""
        try:
            # Get endpoint from api_config section
            api_config = config.get('api_config', {})
            endpoint = api_config.get('endpoint')
            
            if not endpoint:
                # Fallback: construct endpoint from host and port
                host = config.get('host', 'localhost')
                port = api_config.get('port', DEFAULT_API_PORT)
                endpoint = f"http://{host}:{port}"
            
            headers = {'Content-Type': 'application/json'}
            
            # Use the digital-twin specific endpoint with path parameters
            # The lab_type is typically 'clab' for containerlab
            lab_type = 'clab'
            url = f"{endpoint}/digital-twin/device-commands/{lab_type}/{lab_name}/{device_name}/"
            
            logger.info(f"Making API request to: {url}")
            response = requests.get(url, headers=headers, timeout=10)
            
            if response.status_code == 200:
                return response.json()
            else:
                logger.error(f"API request failed with status {response.status_code}: {response.text}")
                return {'success': False, 'error': f'API request failed: {response.status_code}'}
                
        except Exception as e:
            logger.error(f"Error getting API device commands: {e}")
            return {'success': False, 'error': str(e)}

    def _get_ssh_device_commands(self, config: Dict, lab_name: str, device_name: str) -> Dict:
        """Get available commands for device via SSH"""
        try:
            shell_info = self._get_ssh_device_shell_info(config, lab_name, device_name)
            if not shell_info.get('success'):
                return shell_info
            
            shell_type = shell_info.get('shell_info', {}).get('type', 'generic')
            commands = self._get_commands_for_shell_type(shell_type)
            
            return {
                'success': True,
                'device_name': device_name,
                'shell_type': shell_type,
                'commands': commands
            }
            
        except Exception as e:
            logger.error(f"Error getting SSH device commands: {e}")
            return {'success': False, 'error': str(e)}

    def _determine_shell_type(self, image: str, device_name: str) -> Dict:
        """Determine shell type based on image and device name"""
        image_lower = image.lower()
        device_lower = device_name.lower()
        
        logger.info(f"Determining shell type for device {device_name} with image: {image} (lowercase: {image_lower})")
        
        # Cisco devices
        if any(x in image_lower for x in ['cisco', 'ios', 'nx-os', 'ios-xe']):
            return {
                'type': 'cisco',
                'shell': 'vtysh',
                'description': 'Cisco IOS/IOU shell',
                'prompt': f'{device_name}#',
                'help_command': '?'
            }
        
        # FRRouting devices - Check this BEFORE Linux to avoid conflicts
        elif any(x in image_lower for x in ['frr', 'frouting', 'quagga']) or 'frrouting' in image_lower:
            result = {
                'type': 'frr',
                'shell': 'vtysh',
                'description': 'FRRouting shell',
                'prompt': f'{device_name}#',
                'help_command': '?'
            }
            logger.info(f"Shell type determined for {device_name}: {result}")
            return result
        
        # Arista devices
        elif any(x in image_lower for x in ['arista', 'eos']):
            return {
                'type': 'arista',
                'shell': 'Cli',
                'description': 'Arista EOS shell',
                'prompt': f'{device_name}#',
                'help_command': '?'
            }
        
        # Juniper devices
        elif any(x in image_lower for x in ['juniper', 'junos']):
            return {
                'type': 'juniper',
                'shell': 'cli',
                'description': 'Juniper JunOS shell',
                'prompt': f'{device_name}>',
                'help_command': '?'
            }
        
        # Linux/Generic devices - Check this AFTER FRR to avoid conflicts
        elif any(x in image_lower for x in ['linux', 'ubuntu', 'debian', 'centos']):
            return {
                'type': 'linux',
                'shell': 'bash',
                'description': 'Linux shell',
                'prompt': f'{device_name}$',
                'help_command': '--help'
            }
        
        # Generic/Unknown
        else:
            result = {
                'type': 'generic',
                'shell': 'sh',
                'description': 'Generic shell',
                'prompt': f'{device_name}#',
                'help_command': '--help'
            }
            logger.info(f"Shell type determined for {device_name}: {result}")
            return result

    def _get_commands_for_shell_type(self, shell_type: str) -> Dict:
        """Get available commands for a specific shell type"""
        commands = {
            'cisco': {
                'show_commands': [
                    'show version', 'show interfaces', 'show ip interface brief',
                    'show running-config', 'show startup-config', 'show ip route',
                    'show protocols', 'show processes', 'show memory'
                ],
                'config_commands': [
                    'configure terminal', 'interface', 'ip address', 'no shutdown',
                    'router ospf', 'network', 'exit', 'end'
                ],
                'troubleshooting': [
                    'ping', 'traceroute', 'show logging', 'debug'
                ]
            },
            'frr': {
                'show_commands': [
                    'show version', 'show interface', 'show ip interface',
                    'show running-config', 'show ip route', 'show ip ospf',
                    'show ip bgp', 'show ip bgp summary'
                ],
                'config_commands': [
                    'configure terminal', 'interface', 'ip address', 'no shutdown',
                    'router ospf', 'network', 'exit', 'end'
                ],
                'troubleshooting': [
                    'ping', 'traceroute', 'show logging'
                ]
            },
            'arista': {
                'show_commands': [
                    'show version', 'show interfaces', 'show ip interface brief',
                    'show running-config', 'show ip route', 'show protocols'
                ],
                'config_commands': [
                    'configure', 'interface', 'ip address', 'no shutdown',
                    'router ospf', 'network', 'exit', 'end'
                ],
                'troubleshooting': [
                    'ping', 'traceroute', 'show logging'
                ]
            },
            'juniper': {
                'show_commands': [
                    'show version', 'show interfaces', 'show route',
                    'show configuration', 'show protocols'
                ],
                'config_commands': [
                    'configure', 'set', 'delete', 'commit', 'exit'
                ],
                'troubleshooting': [
                    'ping', 'traceroute', 'show log'
                ]
            },
            'linux': {
                'system_commands': [
                    'uname -a', 'cat /proc/version', 'ip addr show',
                    'ip route show', 'ps aux', 'netstat -tuln'
                ],
                'network_commands': [
                    'ping', 'traceroute', 'nslookup', 'dig'
                ],
                'file_commands': [
                    'ls -la', 'cat', 'grep', 'find'
                ]
            },
            'generic': {
                'basic_commands': [
                    'uname -a', 'ps aux', 'netstat -tuln', 'ping', 'ls -la'
                ]
            }
        }
        
        return commands.get(shell_type, commands['generic'])

    def cleanup(self):
        """Cleanup resources"""
        if hasattr(self, 'executor'):
            self.executor.shutdown(wait=False)


# Global remote lab manager instance
remote_lab_manager = RemoteContainerlabManager()


def create_error_response(error_message: str, status_code: int = 500) -> JsonResponse:
    """Create standardized error response"""
    return JsonResponse({
        'success': False,
        'error': error_message
    }, status=status_code)


def validate_and_correct_ip(ip_string, for_containerlab_mgmt=False):
    """Validate and auto-correct IP addresses"""
    if not ip_string:
        return None, None
    
    try:
        ip_string = ip_string.strip().replace(' ', '')
        
        if for_containerlab_mgmt:
            return None, "Management IP assignment removed - Containerlab will auto-assign"
        else:
            if '/' not in ip_string and '.' in ip_string:
                ip_string += '/24'
            
            network = ipaddress.IPv4Network(ip_string, strict=False)
            return str(network), None
            
    except (ipaddress.AddressValueError, ValueError) as e:
        return None, f"Invalid IP address format: {str(e)}"


def auto_create_interface(device, interface_name, interface_type='1000base-t'):
    """Auto-create missing interfaces when referenced in connections"""
    try:
        from nautobot.dcim.models import Interface
        
        existing_interface = Interface.objects.filter(
            device=device, 
            name=interface_name
        ).first()
        
        if existing_interface:
            return existing_interface, None
        
        if device.platform:
            platform_name = device.platform.name.lower()
            if 'cisco' in platform_name:
                if interface_name.lower().startswith('gi'):
                    interface_type = '1000base-t'
                elif interface_name.lower().startswith('te'):
                    interface_type = '10gbase-t'
            elif 'arista' in platform_name:
                if 'ethernet' in interface_name.lower():
                    interface_type = '10gbase-t'
        
        new_interface = Interface.objects.create(
            device=device,
            name=interface_name,
            type=interface_type,
            enabled=True,
            description=f"Auto-created for Containerlab connection"
        )
        
        logger.info(f"Auto-created interface {interface_name} on device {device.name}")
        return new_interface, None
        
    except Exception as e:
        error_msg = f"Failed to auto-create interface {interface_name}: {str(e)}"
        logger.error(error_msg)
        return None, error_msg


def auto_create_cable(interface_a, interface_b, cable_type='cat6'):
    """Auto-create cables when connections are established"""
    try:
        from nautobot.dcim.models import Cable
        
        existing_cable = Cable.objects.filter(
            termination_a_id=interface_a.id,
            termination_b_id=interface_b.id
        ).first() or Cable.objects.filter(
            termination_a_id=interface_b.id,
            termination_b_id=interface_a.id
        ).first()
        
        if existing_cable:
            return existing_cable, None
        
        new_cable = Cable.objects.create(
            termination_a=interface_a,
            termination_b=interface_b,
            type=cable_type,
            status='connected',
            length=1,
            length_unit='m'
        )
        
        logger.info(f"Auto-created cable between {interface_a.device.name}:{interface_a.name} and {interface_b.device.name}:{interface_b.name}")
        return new_cable, None
        
    except Exception as e:
        error_msg = f"Failed to auto-create cable: {str(e)}"
        logger.error(error_msg)
        return None, error_msg


def map_device_type_to_containerlab(device_model):
    """Map real device types to containerlab kinds"""
    if not device_model:
        return 'linux'
    
    model = device_model.lower()
    
    mappings = {
        'veos': 'arista_ceos',
        'arista': 'arista_ceos', 
        'dcs': 'arista_ceos',
        'csr1000v': 'cisco_csr1000v',
        'nexus': 'cisco_n9kv',
        'n9kv': 'cisco_n9kv',
        'c9300': 'linux',
        'vmx': 'juniper_vmx',
        'srlinux': 'nokia_srl',
        'nokia': 'nokia_srl'
    }
    
    for key, value in mappings.items():
        if key in model:
            return value
    
    return 'linux'


def get_default_image_for_kind(clab_kind):
    """Get default container image for containerlab kind"""
    image_map = {
        'arista_veos': 'aristanetworks/veos:latest',
        'arista_ceos': 'ceos:4.34.1F',
        'cisco_csr1000v': 'cisco/csr1000v:17.03.06',
        'cisco_n9kv': 'cisco/n9kv:10.2.3',
        'juniper_vmx': 'vrnetlab/juniper_vmx:20.2R1.10',
        'nokia_srl': 'ghcr.io/nokia/srlinux:latest',
        'linux': 'frrouting/frr:latest'
    }
    return image_map.get(clab_kind, 'ubuntu:20.04')


def integrate_startup_configs_in_yaml(yaml_content: str, device_configs: dict, server_id: str) -> str:
    """Integrate device configurations as startup-config in YAML using enhanced system with proper bind mounts"""
    try:
        yaml_obj = yaml.safe_load(yaml_content)
        
        if 'topology' not in yaml_obj:
            yaml_obj['topology'] = {}
        if 'nodes' not in yaml_obj['topology']:
            yaml_obj['topology']['nodes'] = {}
        
        # Use consistent config directory path
        remote_config_dir = '/tmp/nautobot_configs_remote_clab_uh_pshke'
        
        # Ensure remote config directory exists
        os.makedirs(remote_config_dir, exist_ok=True)
        os.chmod(remote_config_dir, 0o755)
        
        config_files_created = []
        
        for device_name, config_content in device_configs.items():
            if device_name in yaml_obj['topology']['nodes']:
                node_ref = yaml_obj['topology']['nodes'][device_name]
                image_str = str(node_ref.get('image', '')).lower()
                kind_str = str(node_ref.get('kind', '')).lower()
                
                # Create config file
                config_filename = f"{device_name}.cfg"
                config_path = os.path.join(remote_config_dir, config_filename)
                
                with open(config_path, 'w', encoding='utf-8') as f:
                    f.write(config_content)
                os.chmod(config_path, 0o644)
                
                # Handle different device types with proper bind mounts
                if 'frr' in image_str or 'frrouting' in image_str or kind_str == 'linux':
                    # For FRR containers, mount a config directory instead of individual files
                    # This avoids issues with direct file mounting that may fail
                    
                    # Create a device-specific config directory
                    device_config_dir = os.path.join(remote_config_dir, f"{device_name}_frr_configs")
                    os.makedirs(device_config_dir, exist_ok=True)
                    
                    # Copy the main FRR config to the mounted directory
                    device_frr_conf = os.path.join(device_config_dir, 'frr.conf')
                    shutil.copy2(config_path, device_frr_conf)
                    os.chmod(device_frr_conf, 0o644)
                    
                    # Create vtysh.conf in the same directory
                    device_vtysh_conf = os.path.join(device_config_dir, 'vtysh.conf')
                    with open(device_vtysh_conf, 'w') as f:
                        f.write('service integrated-vtysh-config\n')
                    os.chmod(device_vtysh_conf, 0o644)
                    
                    # Create daemons file to ensure all daemons are enabled
                    device_daemons_conf = os.path.join(device_config_dir, 'daemons')
                    with open(device_daemons_conf, 'w') as f:
                        f.write("""# This file tells the frr package which daemons to start.
zebra=yes
bgpd=yes
ospfd=yes
ospf6d=yes
ripd=yes
ripngd=yes
isisd=yes
pimd=yes
ldpd=yes
nhrpd=yes
eigrpd=yes
babeld=yes
sharpd=yes
staticd=yes
pbrd=yes
bfdd=yes
fabricd=yes
vrrpd=yes

# The watchfrr daemon is always started.
watchfrr_enable=yes

# This is the maximum number of FIB entries that this instance will read
# from the kernel.
MAX_FIB_SIZE=1000000

# Uncomment the next line to pass options to the frr daemons
# DAEMON_OPTS=""

# The list of daemons to watch is automatically generated by the init script.
watchfrr_options="-d -F traditional --daemon -A 127.0.0.1 -r /usr/lib/frr/watchfrr_nb restart %s"
""")
                    os.chmod(device_daemons_conf, 0o644)
                    
                    # Set up directory bind mount
                    binds = node_ref.get('binds', []) or []
                    
                    # Remove any existing FRR-related bind mounts to avoid conflicts
                    binds = [b for b in binds if not any(frr_path in b for frr_path in [
                        ':/etc/frr/frr.conf', ':/etc/frr/startup.conf', ':/etc/frr/vtysh.conf', 
                        ':/etc/frr/vtysh_custom.conf', ':/tmp/frr_configs'
                    ])]
                    
                    # Mount the config directory to /tmp/frr_configs in the container
                    config_dir_mount = f"{device_config_dir}:/tmp/frr_configs:ro"
                    binds.append(config_dir_mount)
                    node_ref['binds'] = binds
                    
                    # Add exec commands to copy configs and properly reload FRR
                    exec_commands = [
                        # Copy the config files to their proper locations
                        "cp /tmp/frr_configs/frr.conf /etc/frr/frr.conf",
                        "cp /tmp/frr_configs/vtysh.conf /etc/frr/vtysh.conf",
                        "cp /tmp/frr_configs/daemons /etc/frr/daemons",
                        # Set proper permissions
                        "chown frr:frr /etc/frr/frr.conf /etc/frr/vtysh.conf /etc/frr/daemons",
                        "chmod 640 /etc/frr/frr.conf /etc/frr/vtysh.conf",
                        "chmod 644 /etc/frr/daemons",
                        # Stop all FRR daemons cleanly
                        "pkill -f 'zebra' || true",
                        "pkill -f 'staticd' || true", 
                        "pkill -f 'ospfd' || true",
                        "pkill -f 'bgpd' || true",
                        # Wait for processes to stop
                        "sleep 2",
                        # Start zebra first (it's required by other daemons)
                        "/usr/lib/frr/zebra -d -A 127.0.0.1 -s 90000000",
                        # Wait for zebra to initialize
                        "sleep 1",
                        # Start other daemons
                        "/usr/lib/frr/staticd -d -A 127.0.0.1",
                        "/usr/lib/frr/ospfd -d -A 127.0.0.1",
                        # Wait for daemons to start
                        "sleep 2",
                        # Apply configuration using vtysh
                        "vtysh -f /etc/frr/frr.conf",
                        # Save configuration to memory
                        "vtysh -c 'write memory'"
                    ]
                    
                    # Remove any existing exec commands and add our new ones
                    node_ref['exec'] = exec_commands
                    
                    logger.info(f"✅ Set up FRR config directory mount for {device_name}: {config_dir_mount}")
                    logger.info(f"✅ Added improved exec commands for {device_name} to copy configs and properly restart FRR")
                    logger.info(f"📁 Config files in directory: frr.conf, vtysh.conf, daemons")
                    
                elif 'cisco' in image_str or 'csr' in image_str:
                    # For Cisco containers, use startup-config
                    yaml_obj['topology']['nodes'][device_name]['startup-config'] = config_path
                    logger.info(f"Set up Cisco startup-config for {device_name}: {config_path}")
                    
                elif 'arista' in image_str or 'ceos' in image_str:
                    # For Arista containers, use startup-config
                    yaml_obj['topology']['nodes'][device_name]['startup-config'] = config_path
                    logger.info(f"Set up Arista startup-config for {device_name}: {config_path}")
                    
                else:
                    # Generic approach - try startup-config first
                    yaml_obj['topology']['nodes'][device_name]['startup-config'] = config_path
                    logger.info(f"Set up generic startup-config for {device_name}: {config_path}")
                
                config_files_created.append(config_path)
        
        logger.info(f"Created {len(config_files_created)} configuration files in {remote_config_dir}")
        
        return yaml.dump(yaml_obj, default_flow_style=False, sort_keys=False)
        
    except Exception as e:
        logger.error(f"Error integrating startup configs: {e}")
        return yaml_content

@login_required
def digital_twin_view(request):
    """Main Digital Twin plugin view with remote server support"""
    try:
        available_servers = remote_lab_manager.get_available_servers()
        
        context = {
            'title': 'Digital Twin - Network Topology Visualization',
            'available_servers': available_servers,
            'has_remote_servers': len([s for s in available_servers if s['type'] != 'local']) > 0
        }
        
        return render(request, 'digital_twin/digital_twin.html', context)
    
    except Exception as e:
        logger.error(f"Error in digital_twin_view: {e}")
        return render(request, 'digital_twin/digital_twin.html', {
            'title': 'Digital Twin - Network Topology Visualization',
            'error': str(e),
            'available_servers': [],
            'has_remote_servers': False
        })


@login_required 
def get_remote_servers_view(request):
    """API endpoint to get available remote Containerlab servers"""
    if request.method != 'GET':
        return create_error_response('Method not allowed', 405)
    
    try:
        servers = remote_lab_manager.get_available_servers()
        
        return JsonResponse({
            'success': True,
            'servers': servers,
            'total': len(servers)
        })
        
    except Exception as e:
        logger.error(f"Error fetching remote servers: {e}")
        return create_error_response(str(e))


@csrf_exempt
@require_POST
def save_yaml(request):
    try:
        data = json.loads(request.body)
        content = data.get('content')
        
        if not content:
            return create_error_response('No content provided', 400)
        
        try:
            yaml_obj = yaml.safe_load(content)
            corrections = []
            
            if 'topology' in yaml_obj and 'links' in yaml_obj['topology']:
                for link in yaml_obj['topology']['links']:
                    if 'endpoints' in link:
                        if len(link['endpoints']) == 2:
                            for i, endpoint in enumerate(link['endpoints']):
                                if ':' not in str(endpoint):
                                    link['endpoints'][i] = f"{endpoint}:eth0"
                                    corrections.append(f"Added default interface to endpoint: {endpoint}")
            
            if 'topology' in yaml_obj and 'nodes' in yaml_obj['topology']:
                for node_name, node_config in yaml_obj['topology']['nodes'].items():
                    if 'mgmt-ipv4' in node_config:
                        del node_config['mgmt-ipv4']
                        corrections.append(f"Removed mgmt-ipv4 for {node_name} - Containerlab will auto-assign")
            
            if 'topology' in yaml_obj and 'mgmt' in yaml_obj['topology']:
                del yaml_obj['topology']['mgmt']
                corrections.append("Removed mgmt section - Containerlab will handle management network")
            
            if corrections:
                content = yaml.dump(yaml_obj, default_flow_style=False, indent=2)
                
        except yaml.YAMLError as e:
            return create_error_response(f'Invalid YAML format: {str(e)}', 400)
        
        base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        full_path = os.path.join(base_dir, 'config.yml')
        
        with open(full_path, 'w', encoding='utf-8') as f:
            f.write(content)
        
        response_data = {
            'success': True,
            'message': 'File saved successfully',
            'path': full_path
        }
        
        if 'corrections' in locals() and corrections:
            response_data['corrections'] = corrections
            response_data['message'] += f' (with {len(corrections)} auto-corrections)'
        
        return JsonResponse(response_data)
    
    except json.JSONDecodeError:
        return create_error_response('Invalid JSON in request body', 400)
    except Exception as e:
        logger.error(f"Error saving YAML file: {str(e)}")
        return create_error_response(str(e))


@csrf_exempt
@require_POST
def simulate_lab(request):
    """Enhanced simulate_lab with remote server support"""
    try:
        data = json.loads(request.body)
        lab_name = data.get('lab_name', f'lab-{int(timezone.now().timestamp())}')
        topology_yaml = data.get('topology_yaml')
        server_id = data.get('server_id', 'default')

        if not topology_yaml:
            return create_error_response('topology_yaml missing', 400)

        try:
            yaml_obj = yaml.safe_load(topology_yaml)
            nodes = yaml_obj.get('topology', {}).get('nodes', {})
            links = yaml_obj.get('topology', {}).get('links', [])
            
            if not nodes:
                return create_error_response(
                    'No nodes found in topology. Please add nodes in the Digital Twin UI first.', 
                    400
                )
            
            corrections_made = []
            for i, link in enumerate(links):
                if 'endpoints' in link and len(link['endpoints']) == 2:
                    for j, endpoint in enumerate(link['endpoints']):
                        if ':' not in str(endpoint):
                            link['endpoints'][j] = f"{endpoint}:eth0"
                            corrections_made.append(f"Added default interface to endpoint in link {i+1}")
            
            for node_name, node_config in nodes.items():
                if 'mgmt-ipv4' in node_config:
                    del node_config['mgmt-ipv4']
                    corrections_made.append(f"Removed mgmt-ipv4 for {node_name} - Containerlab will auto-assign")
            
            if 'mgmt' in yaml_obj.get('topology', {}):
                del yaml_obj['topology']['mgmt']
                corrections_made.append("Removed mgmt section - Containerlab will handle management network")
            
            for link in links:
                if 'endpoints' in link:
                    for endpoint in link['endpoints']:
                        device_name, interface_name = endpoint.split(':', 1)
                        if device_name not in nodes:
                            return create_error_response(
                                f'Device "{device_name}" referenced in connection but not found in nodes',
                                400
                            )
            
            if corrections_made:
                topology_yaml = yaml.dump(yaml_obj, default_flow_style=False, indent=2)
                
        except yaml.YAMLError as e:
            return create_error_response(f'Invalid YAML: {str(e)}', 400)

        logger.info(f"Lab simulation requested: {lab_name} on server {server_id}")
        
        progress_data = {'progress': 0, 'message': 'Starting deployment...'}
        
        def progress_callback(progress, message):
            progress_data['progress'] = progress
            progress_data['message'] = message
        
        result = remote_lab_manager.deploy_lab(
            server_id=server_id,
            lab_name=lab_name,
            yaml_content=topology_yaml,
            progress_callback=progress_callback
        )
        
        if result['success']:
            logger.info(f"Lab {lab_name} deployed successfully on {server_id}")
            return JsonResponse({
                'success': True,
                'message': result.get('message', f'Lab "{lab_name}" deployed successfully'),
                'logs': result.get('logs', ''),
                'deployment_id': result.get('deployment_id'),
                'server_id': result.get('server_id'),
                'lab_name': lab_name
            })
        else:
            logger.error(f"Lab deployment failed: {result.get('error')}")
            return JsonResponse({
                'success': False,
                'error': result.get('error', 'Unknown deployment error'),
                'logs': result.get('logs', ''),
                'deployment_id': result.get('deployment_id'),
                'server_id': result.get('server_id')
            })

    except json.JSONDecodeError:
        return create_error_response('Invalid JSON in request body', 400)
    except Exception as e:
        logger.error(f"Error during simulation: {str(e)}")
        return create_error_response(f'Server error: {str(e)}')


def get_device_configurations(request):
    """Get device configurations from Nautobot"""
    try:
        from nautobot.dcim.models import Device
        
        configurations = {}
        devices = Device.objects.select_related('platform').all()
        
        for device in devices:
            config_data = {
                'hostname': device.name,
                'platform': device.platform.name if device.platform else 'unknown',
                'interfaces': [],
                'management_ip': str(device.primary_ip4.address) if device.primary_ip4 else None
            }
            
            for interface in device.interfaces.all():
                if_config = {
                    'name': interface.name,
                    'enabled': interface.enabled,
                    'type': interface.type,
                    'mtu': interface.mtu if interface.mtu else 1500,
                    'ip_addresses': []
                }
                
                for ip_address in interface.ip_addresses.all():
                    if_config['ip_addresses'].append({
                        'address': str(ip_address.address),
                        'family': ip_address.address.version
                    })
                
                config_data['interfaces'].append(if_config)
            
            configurations[device.name] = config_data
        
        return JsonResponse(configurations)
        
    except Exception as e:
        logger.error(f"Error getting device configurations: {str(e)}")
        return create_error_response(f'Failed to get device configurations: {str(e)}')


@csrf_exempt
def discover_topology_from_dcim(request):
    """Discover complete topology from Nautobot DCIM data"""
    try:
        from nautobot.dcim.models import Device, Interface, Cable
        
        devices = Device.objects.select_related(
            'location', 'platform', 'device_type', 'role'
        ).prefetch_related(
            'interfaces', 'primary_ip4'
        ).all()
        
        topology_data = {
            'nodes': {},
            'connections': [],
            'locations': {},
            'device_configs': {},
            'metadata': {
                'discovered_at': timezone.now().isoformat(),
                'total_devices': devices.count(),
                'total_connections': 0
            }
        }
        
        auto_corrections = []
        
        for device in devices:
            node_data = {
                'name': device.name,
                'location': device.location.name if device.location else 'Unknown',
                'role': device.role.name if device.role else 'Unknown',
                'platform': device.platform.name if device.platform else 'Unknown',
                'device_type': device.device_type.model,
                'interfaces': [],
                'custom_fields': device.custom_field_data or {}
            }
            
            clab_kind = device.custom_field_data.get('clab_kind') if device.custom_field_data else None
            clab_image = device.custom_field_data.get('clab_image') if device.custom_field_data else None
            
            if not clab_kind:
                clab_kind = map_device_type_to_containerlab(device.device_type.model)
            if not clab_image:
                clab_image = get_default_image_for_kind(clab_kind)
            
            node_data.update({
                'clab_kind': clab_kind,
                'clab_image': clab_image,
                'suggested_kind': clab_kind,
                'suggested_image': clab_image,
                'status': device.status.name if device.status else 'Unknown',
                'serial': device.serial or '',
                'asset_tag': device.asset_tag or '',
                'interface_count': 0,
                'interface_types': [],
                'has_custom_fields': bool(clab_kind and clab_image),
                'connections': []
            })
            
            processed_connections = set()
            interfaces = []
            interface_types = set()
            
            for interface in device.interfaces.all():
                interface_data = {
                    'name': interface.name,
                    'type': interface.type,
                    'enabled': interface.enabled,
                    'mtu': interface.mtu,
                    'description': interface.description or '',
                    'ip_addresses': []
                }
                
                try:
                    for ip_address in interface.ip_addresses.all():
                        interface_data['ip_addresses'].append(str(ip_address.address))
                except:
                    pass
                
                interfaces.append(interface_data)
                interface_types.add(interface.type)
                
                cables = Cable.objects.filter(
                    termination_a_id=interface.id
                ) | Cable.objects.filter(
                    termination_b_id=interface.id
                )
                
                for cable in cables:
                    try:
                        if cable.termination_a_id == interface.id:
                            connected_interface_id = cable.termination_b_id
                        else:
                            connected_interface_id = cable.termination_a_id
                        
                        connected_interface = Interface.objects.get(id=connected_interface_id)
                        
                        if connected_interface.device.name != device.name:
                            connection_id = tuple(sorted([
                                f"{device.name}:{interface.name}",
                                f"{connected_interface.device.name}:{connected_interface.name}"
                            ]))
                            
                            if connection_id not in processed_connections:
                                connection = {
                                    'source_device': device.name,
                                    'source_interface': interface.name,
                                    'target_device': connected_interface.device.name,
                                    'target_interface': connected_interface.name,
                                    'cable_id': str(cable.id),
                                    'cable_type': cable.type if cable.type else 'Unknown',
                                    'cable_length': f"{cable.length}{cable.length_unit}" if cable.length else 'Unknown',
                                    'cable_status': cable.status.name if cable.status else 'Unknown',
                                    'a_interface_type': interface.type,
                                    'b_interface_type': connected_interface.type
                                }
                                topology_data['connections'].append(connection)
                                processed_connections.add(connection_id)
                                
                    except Exception as e:
                        logger.warning(f"Error processing cable connection: {e}")
                        continue
            
            node_data['interfaces'] = interfaces
            node_data['interface_count'] = len(interfaces)
            node_data['interface_types'] = list(interface_types)
            
            topology_data['nodes'][device.name] = node_data
            
            location_name = node_data['location']
            if location_name not in topology_data['locations']:
                topology_data['locations'][location_name] = []
            topology_data['locations'][location_name].append(device.name)
        
        topology_data['metadata']['total_connections'] = len(topology_data['connections'])
        topology_data['metadata']['total_locations'] = len(topology_data['locations'])
        
        if auto_corrections:
            topology_data['auto_corrections'] = auto_corrections
            logger.info(f"Applied {len(auto_corrections)} auto-corrections during topology discovery")
        
        logger.info(f"Discovery complete: {len(topology_data['nodes'])} devices, "
                   f"{len(topology_data['connections'])} connections, "
                   f"{len(topology_data['locations'])} locations")
        
        return JsonResponse({
            'success': True,
            'message': f'Discovered {len(topology_data["nodes"])} devices and {len(topology_data["connections"])} connections',
            **topology_data
        })
        
    except Exception as e:
        logger.error(f"Error discovering topology: {str(e)}")
        return create_error_response(f'Failed to discover topology: {str(e)}')


@csrf_exempt
def get_dcim_devices(request):
    """Get devices from Nautobot DCIM with enhanced data"""
    try:
        from nautobot.dcim.models import Device, Cable, Interface
        
        devices = Device.objects.select_related(
            'device_type', 'platform', 'location', 'role'
        ).prefetch_related('interfaces').all()
        
        device_list = []
        connections_list = []
        auto_corrections = []
        processed_connections = set()
        
        for device in devices:
            interfaces = device.interfaces.all()
            interface_count = interfaces.count()
            interface_types = list(set([iface.type for iface in interfaces if iface.type]))
            
            custom_fields = device.custom_field_data or {}
            clab_kind = custom_fields.get('clab_kind')
            clab_image = custom_fields.get('clab_image')
            
            suggested_kind = clab_kind or map_device_type_to_containerlab(device.device_type.model)
            suggested_image = clab_image or get_default_image_for_kind(suggested_kind)
            
            device_connections = []
            for interface in interfaces:
                cables = Cable.objects.filter(
                    termination_a_id=interface.id
                ) | Cable.objects.filter(
                    termination_b_id=interface.id
                )
                
                for cable in cables:
                    try:
                        if cable.termination_a_id == interface.id:
                            connected_interface_id = cable.termination_b_id
                        else:
                            connected_interface_id = cable.termination_a_id
                        
                        connected_interface = Interface.objects.get(id=connected_interface_id)
                        
                        if connected_interface.device.name != device.name:
                            connection_id = tuple(sorted([
                                f"{device.name}:{interface.name}",
                                f"{connected_interface.device.name}:{connected_interface.name}"
                            ]))
                            
                            if connection_id not in processed_connections:
                                connection_data = {
                                    'source_device': device.name,
                                    'source_interface': interface.name,
                                    'target_device': connected_interface.device.name,
                                    'target_interface': connected_interface.name,
                                    'cable_id': str(cable.id)
                                }
                                connections_list.append(connection_data)
                                device_connections.append(connection_data)
                                processed_connections.add(connection_id)
                                
                    except Exception as e:
                        logger.warning(f"Error processing connection for {device.name}: {e}")
                        continue
            
            device_data = {
                'id': str(device.id),
                'name': device.name,
                'model': device.device_type.model if device.device_type else 'Unknown',
                'platform': device.platform.name if device.platform else 'Unknown',
                'location': device.location.name if device.location else 'Unknown',
                'role': device.role.name if device.role else 'Unknown',
                'interface_count': interface_count,
                'interface_types': interface_types[:3],
                'suggested_kind': suggested_kind,
                'suggested_image': suggested_image,
                'has_custom_fields': bool(clab_kind and clab_image),
                'status': device.status.name if device.status else 'Unknown',
                'connections': device_connections
            }
            
            device_list.append(device_data)
        
        response_data = {
            'success': True, 
            'devices': device_list,
            'connections': connections_list,
            'total': len(device_list)
        }
        
        if auto_corrections:
            response_data['auto_corrections'] = auto_corrections
        
        logger.info(f"Loaded {len(device_list)} devices with {len(connections_list)} total connections")
        
        return JsonResponse(response_data)
        
    except Exception as e:
        logger.error(f"Error fetching DCIM devices: {str(e)}")
        return create_error_response(str(e))


@csrf_exempt 
def get_device_details(request, device_id):
    """Get detailed information about a specific device"""
    try:
        from nautobot.dcim.models import Device, Interface
        
        device = Device.objects.select_related(
            'device_type', 'platform', 'location', 'role'
        ).prefetch_related('interfaces').get(id=device_id)
        
        interfaces = []
        missing_interfaces = []
        
        for interface in device.interfaces.all():
            interface_data = {
                'name': interface.name,
                'type': interface.type,
                'enabled': interface.enabled,
                'mtu': interface.mtu,
                'description': interface.description or '',
                'ip_addresses': []
            }
            
            try:
                for ip_address in interface.ip_addresses.all():
                    corrected_ip, error = validate_and_correct_ip(str(ip_address.address), for_containerlab_mgmt=False)
                    if corrected_ip:
                        interface_data['ip_addresses'].append(corrected_ip)
                    elif error:
                        interface_data['ip_addresses'].append(f"INVALID: {ip_address.address}")
            except:
                pass
                
            interfaces.append(interface_data)
        
        if len(interfaces) < 2:
            common_interfaces = ['eth0', 'eth1', 'GigabitEthernet0/0', 'GigabitEthernet0/1']
            existing_names = [iface['name'] for iface in interfaces]
            missing_interfaces = [name for name in common_interfaces if name not in existing_names][:2]
        
        device_details = {
            'id': str(device.id),
            'name': device.name,
            'model': device.device_type.model if device.device_type else 'Unknown',
            'manufacturer': device.device_type.manufacturer.name if device.device_type and device.device_type.manufacturer else 'Unknown',
            'platform': device.platform.name if device.platform else 'Unknown',
            'location': device.location.name if device.location else 'Unknown',
            'role': device.role.name if device.role else 'Unknown',
            'status': device.status.name if device.status else 'Unknown',
            'serial': device.serial or 'N/A',
            'interfaces': interfaces,
            'interface_count': len(interfaces),
            'missing_interface_suggestions': missing_interfaces,
            'custom_fields': device.custom_field_data or {},
            'containerlab_ready': bool(
                device.custom_field_data and 
                device.custom_field_data.get('clab_kind') and 
                device.custom_field_data.get('clab_image')
            )
        }
        
        return JsonResponse({
            'success': True,
            'device': device_details
        })
        
    except Device.DoesNotExist:
        return create_error_response('Device not found', 404)
    except Exception as e:
        return create_error_response(str(e))


@csrf_exempt
@require_POST
def create_missing_interfaces(request):
    """Create missing interfaces for a device based on connection requirements"""
    try:
        data = json.loads(request.body)
        device_id = data.get('device_id')
        interface_names = data.get('interface_names', [])
        
        if not device_id or not interface_names:
            return create_error_response('device_id and interface_names are required', 400)
        
        from nautobot.dcim.models import Device
        device = Device.objects.get(id=device_id)
        
        created_interfaces = []
        errors = []
        
        for interface_name in interface_names:
            interface, error = auto_create_interface(device, interface_name)
            if interface:
                created_interfaces.append({
                    'name': interface.name,
                    'type': interface.type,
                    'id': str(interface.id)
                })
            else:
                errors.append(error)
        
        return JsonResponse({
            'success': len(created_interfaces) > 0,
            'created_interfaces': created_interfaces,
            'errors': errors,
            'message': f"Created {len(created_interfaces)} interfaces on {device.name}"
        })
        
    except Device.DoesNotExist:
        return create_error_response('Device not found', 404)
    except Exception as e:
        logger.error(f"Error creating interfaces: {str(e)}")
        return create_error_response(str(e))


@csrf_exempt
@require_POST
def create_connection_cable(request):
    """Create cable between two interfaces"""
    try:
        data = json.loads(request.body)
        source_device_id = data.get('source_device_id')
        source_interface_name = data.get('source_interface_name')
        target_device_id = data.get('target_device_id')
        target_interface_name = data.get('target_interface_name')
        cable_type = data.get('cable_type', 'cat6')
        
        if not all([source_device_id, source_interface_name, target_device_id, target_interface_name]):
            return create_error_response('Missing required connection parameters', 400)
        
        from nautobot.dcim.models import Device, Interface
        
        source_device = Device.objects.get(id=source_device_id)
        target_device = Device.objects.get(id=target_device_id)
        
        source_interface, source_error = auto_create_interface(source_device, source_interface_name)
        target_interface, target_error = auto_create_interface(target_device, target_interface_name)
        
        errors = []
        if source_error:
            errors.append(f"Source interface error: {source_error}")
        if target_error:
            errors.append(f"Target interface error: {target_error}")
        
        if not source_interface or not target_interface:
            return JsonResponse({
                'success': False,
                'error': 'Failed to create or find required interfaces',
                'details': errors
            }, status=400)
        
        cable, cable_error = auto_create_cable(source_interface, target_interface, cable_type)
        
        if cable:
            return JsonResponse({
                'success': True,
                'message': f"Created cable between {source_device.name}:{source_interface_name} and {target_device.name}:{target_interface_name}",
                'cable_id': str(cable.id),
                'created_interfaces': []
            })
        else:
            return create_error_response(f"Failed to create cable: {cable_error}", 400)
        
    except Device.DoesNotExist:
        return create_error_response('One or both devices not found', 404)
    except Exception as e:
        logger.error(f"Error creating connection cable: {str(e)}")
        return create_error_response(str(e))


# Remote server endpoints
@login_required
def server_health_view(request, server_id):
    """API endpoint to check specific server health"""
    if request.method != 'GET':
        return create_error_response('Method not allowed', 405)
    
    try:
        health = remote_lab_manager._check_server_health(server_id)
        
        return JsonResponse({
            'success': True,
            'server_id': server_id,
            **health
        })
        
    except Exception as e:
        logger.error(f"Error checking server health: {e}")
        return create_error_response(str(e))


@login_required
def get_lab_status_view(request, server_id, lab_name):
    """API endpoint to get lab status from remote server"""
    if request.method != 'GET':
        return create_error_response('Method not allowed', 405)
    
    try:
        return JsonResponse({
            'success': True,
            'lab_name': lab_name,
            'server_id': server_id,
            'status': 'running',
            'timestamp': timezone.now().isoformat()
        })
        
    except Exception as e:
        logger.error(f"Error getting lab status: {e}")
        return create_error_response(str(e))


@login_required
def get_deployment_status_view(request, deployment_id):
    """API endpoint to get deployment status"""
    if request.method != 'GET':
        return create_error_response('Method not allowed', 405)
    
    try:
        return JsonResponse({
            'success': True,
            'deployment_id': deployment_id,
            'status': 'completed',
            'progress': 100,
            'message': 'Deployment completed successfully'
        })
        
    except Exception as e:
        logger.error(f"Error getting deployment status: {e}")
        return create_error_response(str(e))


@login_required
def get_deployment_logs_view(request, deployment_id):
    """API endpoint to get deployment logs"""
    if request.method != 'GET':
        return create_error_response('Method not allowed', 405)
    
    try:
        return JsonResponse({
            'success': True,
            'deployment_id': deployment_id,
            'logs': 'Deployment logs would be stored and retrieved here...'
        })
        
    except Exception as e:
        logger.error(f"Error getting deployment logs: {e}")
        return create_error_response(str(e))


@login_required
def export_topology_view(request):
    """API endpoint to export topology as YAML file"""
    if request.method != 'POST':
        return create_error_response('Method not allowed', 405)
    
    try:
        data = json.loads(request.body)
        yaml_content = data.get('content', '')
        filename = data.get('filename', 'topology.clab.yml')
        
        if not yaml_content:
            return create_error_response('No YAML content to export')
        
        try:
            yaml.safe_load(yaml_content)
        except yaml.YAMLError as e:
            return create_error_response(f'Invalid YAML: {str(e)}')
        
        response = HttpResponse(yaml_content, content_type='text/yaml')
        response['Content-Disposition'] = f'attachment; filename="{filename}"'
        
        return response
        
    except json.JSONDecodeError:
        return create_error_response('Invalid JSON data', 400)
    except Exception as e:
        logger.error(f"Error exporting topology: {e}")
        return create_error_response(str(e))


@login_required
def get_active_labs_view(request, server_id):
    """API endpoint to get active labs on a specific server"""
    if request.method != 'GET':
        return create_error_response('Method not allowed', 405)
    
    try:
        result = remote_lab_manager.get_active_labs(server_id)
        return JsonResponse(result)
        
    except Exception as e:
        logger.error(f"Error getting active labs for server {server_id}: {e}")
        return create_error_response(str(e))


@csrf_exempt
@require_POST
def stop_lab_view(request, server_id, lab_name):
    """API endpoint to stop a specific lab on a server"""
    try:
        result = remote_lab_manager.stop_lab(server_id, lab_name)
        status_code = 200 if result['success'] else 500
        return JsonResponse(result, status=status_code)
        
    except Exception as e:
        logger.error(f"Error stopping lab {lab_name} on server {server_id}: {e}")
        return create_error_response(str(e))


@login_required
def get_lab_logs_view(request, server_id, lab_name):
    """API endpoint to get logs for a specific lab"""
    if request.method != 'GET':
        return create_error_response('Method not allowed', 405)
    
    try:
        result = remote_lab_manager.get_lab_logs(server_id, lab_name)
        return JsonResponse(result)
        
    except Exception as e:
        logger.error(f"Error getting logs for lab {lab_name} on server {server_id}: {e}")
        return create_error_response(str(e))


# Configuration management endpoints
@csrf_exempt
def get_all_device_configs_for_deployment(request):
    """Get all saved device configurations for deployment integration"""
    logger.info("Getting all device configurations for deployment")
    
    try:
        server_id = request.GET.get('server_id', 'local')
        all_configs = {}
        
        yaml_content = request.GET.get('yaml_content', '')
        if yaml_content:
            try:
                yaml_obj = yaml.safe_load(yaml_content)
                
                if yaml_obj and 'topology' in yaml_obj and 'nodes' in yaml_obj['topology']:
                    for device_name in yaml_obj['topology']['nodes'].keys():
                        cache_key = f"device_config_{device_name}_{server_id}"
                        cached_config = cache.get(cache_key)
                        
                        if cached_config and cached_config.get('configuration'):
                            all_configs[device_name] = {
                                'configuration': cached_config['configuration'],
                                'timestamp': cached_config.get('timestamp'),
                                'status': cached_config.get('status', 'saved')
                            }
                            
            except Exception as e:
                logger.warning(f"Could not parse YAML to extract device names: {e}")
        
        return JsonResponse({
            'status': 'success',
            'configurations': all_configs,
            'total_configs': len(all_configs),
            'server_id': server_id
        })
        
    except Exception as e:
        logger.error(f"Error getting device configurations for deployment: {e}")
        return JsonResponse({
            'status': 'error',
            'error': str(e)
        }, status=500)


@csrf_exempt
@require_POST  
def deploy_with_configurations(request):
    """Deploy lab with integrated device configurations"""
    logger.info("Deploying lab with integrated configurations")
    
    try:
        data = json.loads(request.body)
        server_id = data.get('server_id', 'local')
        lab_name = data.get('lab_name')
        yaml_content = data.get('yaml_content')
        
        if not all([lab_name, yaml_content]):
            return JsonResponse({
                'status': 'error',
                'error': 'Lab name and YAML content are required'
            }, status=400)
        
        device_configs = {}
        
        try:
            yaml_obj = yaml.safe_load(yaml_content)
            
            if yaml_obj and 'topology' in yaml_obj and 'nodes' in yaml_obj['topology']:
                for device_name in yaml_obj['topology']['nodes'].keys():
                    cache_key = f"device_config_{device_name}_{server_id}"
                    cached_config = cache.get(cache_key)
                    
                    if cached_config and cached_config.get('configuration'):
                        device_configs[device_name] = cached_config['configuration']
                        logger.info(f"Found configuration for device {device_name}")
                        
        except Exception as e:
            logger.warning(f"Could not extract device configurations: {e}")
        
        if device_configs:
            yaml_content = integrate_startup_configs_in_yaml(yaml_content, device_configs, server_id)
            logger.info(f"Integrated {len(device_configs)} configurations into YAML")
        
        result = remote_lab_manager.deploy_lab_with_configs(server_id, lab_name, yaml_content, device_configs)
        
        # Ensure proper error handling in response
        if result.get('success', False) and not result.get('has_error', False):
            return JsonResponse({
                'status': 'success',
                'message': f'Lab deployed with {len(device_configs)} device configurations',
                'configurations_applied': len(device_configs),
                'deployment_result': result
            })
        else:
            return JsonResponse({
                'status': 'error',
                'error': result.get('error', 'Deployment failed'),
                'message': result.get('message', 'Deployment failed'),
                'logs': result.get('logs'),
                'deployment_result': result
            }, status=500)
        
    except json.JSONDecodeError:
        return JsonResponse({
            'status': 'error',
            'error': 'Invalid JSON in request body'
        }, status=400)
    except Exception as e:
        logger.error(f"Error deploying lab with configurations: {e}")
        return JsonResponse({
            'status': 'error',
            'error': str(e)
        }, status=500)


@csrf_exempt
@require_POST
def save_device_config_live(request):
    """Save device configuration for deployment-time integration"""
    logger.info("Saving device configuration for live deployment")
    
    try:
        data = json.loads(request.body)
        device_name = data.get('device_name')
        configuration = data.get('configuration', '')
        server_id = data.get('server_id', 'local')
        
        if not device_name:
            return JsonResponse({
                'status': 'error',
                'error': 'Device name is required'
            }, status=400)
            
        if not configuration.strip():
            return JsonResponse({
                'status': 'error', 
                'error': 'Configuration content is required'
            }, status=400)
        
        cache_key = f"device_config_{device_name}_{server_id}"
        
        cache.set(cache_key, {
            'device_name': device_name,
            'configuration': configuration,
            'server_id': server_id,
            'timestamp': timezone.now().isoformat(),
            'status': 'saved'
        }, timeout=CACHE_TIMEOUT)
        
        logger.info(f"Configuration saved for device {device_name} on server {server_id}")
        
        return JsonResponse({
            'status': 'success',
            'message': f'Configuration saved for device {device_name}',
            'device_name': device_name,
            'config_size': len(configuration),
            'server_id': server_id
        })
        
    except json.JSONDecodeError:
        return JsonResponse({
            'status': 'error',
            'error': 'Invalid JSON in request body'
        }, status=400)
    except Exception as e:
        logger.error(f"Error saving device configuration: {e}")
        return JsonResponse({
            'status': 'error',
            'error': str(e)
        }, status=500)


@csrf_exempt
def get_device_config_live(request, device_name):
    """Get current configuration from device (for live editing)"""
    logger.info(f"Getting live configuration for device {device_name}")
    
    try:
        server_id = request.GET.get('server_id', 'local')
        
        cache_key = f"device_config_{device_name}_{server_id}"
        cached_config = cache.get(cache_key)
        
        if cached_config:
            return JsonResponse({
                'status': 'success',
                'device_name': device_name,
                'configuration': cached_config['configuration'],
                'has_config': True,
                'source': 'cached',
                'timestamp': cached_config.get('timestamp'),
                'server_id': server_id
            })
        
        if server_id != 'local':
            manager = RemoteContainerlabManager()
            server_config = manager._load_server_config().get('servers', {}).get(server_id)
            
            if server_config:
                try:
                    endpoint = f"http://{server_config['host']}:{server_config.get('port', DEFAULT_API_PORT)}"
                    response = requests.get(
                        f"{endpoint}/get-device-config/{device_name}",
                        timeout=DEFAULT_TIMEOUT
                    )
                    
                    if response.status_code == 200:
                        result = response.json()
                        if result.get('status') == 'success':
                            return JsonResponse(result)
                            
                except Exception as e:
                    logger.warning(f"Could not get live config from remote server: {e}")
        
        return JsonResponse({
            'status': 'success',
            'device_name': device_name,
            'configuration': '',
            'has_config': False,
            'source': 'empty',
            'server_id': server_id
        })
        
    except Exception as e:
        logger.error(f"Error getting device configuration: {e}")
        return JsonResponse({
            'status': 'error',
            'error': str(e)
        }, status=500)


@csrf_exempt
@require_POST
def apply_device_config_live(request, device_name):
    """Apply configuration to running containerlab device"""
    logger.info(f"Applying live configuration to device {device_name}")
    
    try:
        data = json.loads(request.body)
        configuration = data.get('configuration', '')
        server_id = data.get('server_id', 'local')
        lab_name = data.get('lab_name')
        
        if not configuration.strip():
            return JsonResponse({
                'status': 'error',
                'error': 'Configuration content is required'
            }, status=400)
            
        if not lab_name:
            return JsonResponse({
                'status': 'error',
                'error': 'Lab name is required for live configuration'
            }, status=400)
        
        if server_id != 'local':
            manager = RemoteContainerlabManager()
            server_config = manager._load_server_config().get('servers', {}).get(server_id)
            
            if not server_config:
                return JsonResponse({
                    'status': 'error',
                    'error': f'Server {server_id} not found'
                }, status=404)
            
            try:
                endpoint = f"http://{server_config['host']}:{server_config.get('port', DEFAULT_API_PORT)}"
                response = requests.post(
                    f"{endpoint}/apply-config/{lab_name}/{device_name}",
                    json={
                        'configuration': configuration
                    },
                    timeout=60
                )
                
                if response.status_code == 200:
                    result = response.json()
                    cache_key = f"device_config_{device_name}_{server_id}"
                    cache.set(cache_key, {
                        'device_name': device_name,
                        'configuration': configuration,
                        'server_id': server_id,
                        'timestamp': timezone.now().isoformat(),
                        'status': 'applied'
                    }, timeout=CACHE_TIMEOUT)
                    
                    return JsonResponse(result)
                else:
                    return JsonResponse({
                        'status': 'error',
                        'error': f'Remote server error: {response.text}'
                    }, status=response.status_code)
                    
            except Exception as e:
                logger.error(f"Error applying config to remote server: {e}")
                return JsonResponse({
                    'status': 'error',
                    'error': f'Failed to apply config to remote server: {str(e)}'
                }, status=500)
        else:
            return JsonResponse({
                'status': 'error',
                'error': 'Local live configuration application not implemented'
            }, status=501)
        
    except json.JSONDecodeError:
        return JsonResponse({
            'status': 'error',
            'error': 'Invalid JSON in request body'
        }, status=400)
    except Exception as e:
        logger.error(f"Error applying device configuration: {e}")
        return JsonResponse({
            'status': 'error',
            'error': str(e)
        }, status=500)


@csrf_exempt
@require_POST
def validate_device_config(request):
    """Validate device configuration content"""
    logger.info("Validating device configuration")
    
    try:
        data = json.loads(request.body)
        configuration = data.get('configuration', '')
        device_kind = data.get('device_kind', '')
        
        if not configuration.strip():
            return JsonResponse({
                'status': 'warning',
                'message': 'No configuration to validate',
                'validation_results': []
            })
        
        validation_results = []
        config_lines = configuration.split('\n')
        non_empty_lines = [line for line in config_lines if line.strip()]
        
        validation_results.append({
            'type': 'info',
            'message': f'Configuration has {len(config_lines)} total lines, {len(non_empty_lines)} non-empty lines'
        })
        
        if 'cisco' in device_kind.lower():
            if not any('hostname' in line.lower() for line in non_empty_lines):
                validation_results.append({
                    'type': 'warning',
                    'message': 'No hostname configuration found'
                })
            if not any('interface' in line.lower() for line in non_empty_lines):
                validation_results.append({
                    'type': 'warning', 
                    'message': 'No interface configuration found'
                })
        elif 'arista' in device_kind.lower():
            if not any('hostname' in line.lower() for line in non_empty_lines):
                validation_results.append({
                    'type': 'warning',
                    'message': 'No hostname configuration found'
                })
        elif 'nokia' in device_kind.lower():
            if not any('hostname' in line.lower() for line in non_empty_lines):
                validation_results.append({
                    'type': 'warning',
                    'message': 'No hostname configuration found'
                })
        
        if len(non_empty_lines) < 5:
            validation_results.append({
                'type': 'warning',
                'message': 'Configuration seems very short - ensure all necessary settings are included'
            })
        
        has_errors = any(result['type'] == 'error' for result in validation_results)
        has_warnings = any(result['type'] == 'warning' for result in validation_results)
        
        if has_errors:
            status = 'error'
            message = 'Configuration has errors that must be fixed'
        elif has_warnings:
            status = 'warning'
            message = 'Configuration has warnings but can be deployed'
        else:
            status = 'success'
            message = 'Configuration validation passed'
        
        return JsonResponse({
            'status': status,
            'message': message,
            'validation_results': validation_results,
            'line_count': len(config_lines),
            'non_empty_lines': len(non_empty_lines)
        })
        
    except json.JSONDecodeError:
        return JsonResponse({
            'status': 'error',
            'error': 'Invalid JSON in request body'
        }, status=400)
    except Exception as e:
        logger.error(f"Error validating device configuration: {e}")
        return JsonResponse({
            'status': 'error',
            'error': str(e)
        }, status=500)


@csrf_exempt
def debug_config_files(request):
    """Debug endpoint to check configuration files status"""
    try:
        remote_config_dir = '/tmp/nautobot_configs_remote_clab_uh_pshke'
        upload_folder = '/home/ubuntu/sameer/containerlab-api/config_uploads'
        
        debug_info = {
            'remote_config_dir': remote_config_dir,
            'upload_folder': upload_folder,
            'remote_dir_exists': os.path.exists(remote_config_dir),
            'upload_dir_exists': os.path.exists(upload_folder),
            'remote_dir_permissions': None,
            'remote_files': [],
            'upload_files': [],
            'timestamp': timezone.now().isoformat()
        }
        
        # Check remote directory
        if debug_info['remote_dir_exists']:
            try:
                stat_info = os.stat(remote_config_dir)
                debug_info['remote_dir_permissions'] = oct(stat_info.st_mode)[-3:]
                debug_info['remote_files'] = os.listdir(remote_config_dir)
            except Exception as e:
                debug_info['remote_dir_error'] = str(e)
        
        # Check upload directory
        if debug_info['upload_dir_exists']:
            try:
                debug_info['upload_files'] = os.listdir(upload_folder)
            except Exception as e:
                debug_info['upload_dir_error'] = str(e)
        
        return JsonResponse({
            'status': 'success',
            'debug_info': debug_info
        })
        
    except Exception as e:
        logger.error(f"Debug config files error: {e}")
        return JsonResponse({
            'status': 'error',
            'error': str(e)
        }, status=500)

@csrf_exempt
def debug_deployment_status(request, deployment_id):
    """Debug specific deployment with detailed information"""
    try:
        # Get deployment status from the remote server API
        remote_manager = RemoteContainerlabManager()
        servers = remote_manager.get_available_servers()
        
        debug_info = {
            'deployment_id': deployment_id,
            'available_servers': len(servers),
            'timestamp': timezone.now().isoformat()
        }
        
        # Try to get status from each server's API
        for server in servers:
            if server['type'] == 'api':
                try:
                    endpoint = f"http://{server['host']}:{server['port']}/deployment/{deployment_id}/status"
                    response = requests.get(endpoint, timeout=10)
                    if response.status_code == 200:
                        debug_info[f'server_{server["id"]}_status'] = response.json()
                    else:
                        debug_info[f'server_{server["id"]}_error'] = f"HTTP {response.status_code}"
                except Exception as e:
                    debug_info[f'server_{server["id"]}_error'] = str(e)
        
        return JsonResponse({
            'status': 'success',
            'debug_info': debug_info
        })
        
    except Exception as e:
        logger.error(f"Debug deployment status error: {e}")
        return JsonResponse({
            'status': 'error',
            'error': str(e)
        }, status=500)

@csrf_exempt
def debug_ui_test(request):
    """Serve a simple HTML page for testing UI components"""
    html_content = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nautobot Digital Twin UI Debug</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            background-color: #f5f5f5;
        }
        .container {
            max-width: 800px;
            margin: 0 auto;
            background-color: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .status-card {
            border: 1px solid #ddd;
            border-radius: 4px;
            padding: 15px;
            margin: 10px 0;
        }
        .status-success {
            border-color: #28a745;
            background-color: #d4edda;
        }
        .status-error {
            border-color: #dc3545;
            background-color: #f8d7da;
        }
        .status-running {
            border-color: #007bff;
            background-color: #d1ecf1;
        }
        .progress-bar {
            width: 100%;
            height: 20px;
            background-color: #e9ecef;
            border-radius: 10px;
            overflow: hidden;
            margin: 10px 0;
        }
        .progress-fill {
            height: 100%;
            background-color: #007bff;
            transition: width 0.3s ease;
        }
        .loader {
            border: 4px solid #f3f3f3;
            border-top: 4px solid #3498db;
            border-radius: 50%;
            width: 30px;
            height: 30px;
            animation: spin 1s linear infinite;
            display: inline-block;
            margin-right: 10px;
        }
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        .btn {
            padding: 10px 20px;
            margin: 5px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 14px;
        }
        .btn-primary {
            background-color: #007bff;
            color: white;
        }
        .btn-danger {
            background-color: #dc3545;
            color: white;
        }
        .debug-info {
            background-color: #f8f9fa;
            border: 1px solid #dee2e6;
            border-radius: 4px;
            padding: 15px;
            margin: 10px 0;
            font-family: monospace;
            font-size: 12px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>🔧 Nautobot Digital Twin UI Debug</h1>
        
        <h2>Status Testing</h2>
        <div class="status-card status-success">
            <h3>✅ Success Status</h3>
            <p>This should show when deployment completes successfully</p>
            <div class="progress-bar">
                <div class="progress-fill" style="width: 100%;"></div>
            </div>
        </div>
        
        <div class="status-card status-error">
            <h3>❌ Error Status</h3>
            <p>This should show when deployment fails</p>
            <div class="progress-bar">
                <div class="progress-fill" style="width: 75%; background-color: #dc3545;"></div>
            </div>
        </div>
        
        <div class="status-card status-running">
            <h3><div class="loader"></div>Running Status</h3>
            <p>This should show during deployment with proper loader animation</p>
            <div class="progress-bar">
                <div class="progress-fill" style="width: 45%;"></div>
            </div>
        </div>
        
        <h2>API Testing</h2>
        <button class="btn btn-primary" onclick="testConfigFiles()">Test Config Files Debug</button>
        <button class="btn btn-primary" onclick="testRemoteServers()">Test Remote Servers</button>
        <button class="btn btn-danger" onclick="clearDebugInfo()">Clear Debug Info</button>
        
        <div id="debug-output" class="debug-info" style="display: none;">
            <h4>Debug Output:</h4>
            <pre id="debug-content"></pre>
        </div>
        
        <h2>Loader Animation Test</h2>
        <p>The loader should spin smoothly without issues:</p>
        <div class="loader"></div>
        <div class="loader"></div>
        <div class="loader"></div>
    </div>

    <script>
        function showDebugInfo(data) {
            const output = document.getElementById('debug-output');
            const content = document.getElementById('debug-content');
            content.textContent = JSON.stringify(data, null, 2);
            output.style.display = 'block';
        }

        function clearDebugInfo() {
            const output = document.getElementById('debug-output');
            output.style.display = 'none';
        }

        async function testConfigFiles() {
            try {
                const response = await fetch('/plugins/digital-twin/debug/config-files/');
                const data = await response.json();
                showDebugInfo(data);
            } catch (error) {
                showDebugInfo({error: error.message});
            }
        }

        async function testRemoteServers() {
            try {
                const response = await fetch('/plugins/digital-twin/remote-servers/');
                const data = await response.json();
                showDebugInfo(data);
            } catch (error) {
                showDebugInfo({error: error.message});
            }
        }

        // Auto-refresh progress bars for demo
        setInterval(() => {
            const progressBars = document.querySelectorAll('.progress-fill');
            progressBars.forEach((bar, index) => {
                if (index === 2) { // Running status bar
                    const currentWidth = parseInt(bar.style.width) || 45;
                    const newWidth = (currentWidth + 1) % 100;
                    bar.style.width = newWidth + '%';
                }
            });
        }, 1000);
    </script>
</body>
</html>
"""
    return HttpResponse(html_content, content_type='text/html')

@csrf_exempt
def get_device_config_templates(request):
    """Get available configuration templates for device types"""
    logger.info("Getting device configuration templates")
    
    try:
        device_kind = request.GET.get('device_kind', '')
        
        templates = {
            'cisco_iosv': {
                'name': 'Cisco IOS Basic',
                'description': 'Basic Cisco IOS router configuration',
                'category': 'cisco'
            },
            'cisco_csr1000v': {
                'name': 'Cisco CSR1000v',
                'description': 'Cisco CSR1000v virtual router configuration',
                'category': 'cisco'
            },
            'arista_eos': {
                'name': 'Arista EOS Basic',
                'description': 'Basic Arista EOS switch configuration',
                'category': 'arista'
            },
            'nokia_srlinux': {
                'name': 'Nokia SR Linux',
                'description': 'Nokia SR Linux basic configuration',
                'category': 'nokia'
            },
            'juniper_vmx': {
                'name': 'Juniper vMX',
                'description': 'Juniper vMX virtual router configuration',
                'category': 'juniper'
            },
            'default': {
                'name': 'Generic Device',
                'description': 'Generic device configuration template',
                'category': 'generic'
            }
        }
        
        if device_kind:
            filtered_templates = {}
            device_vendor = device_kind.split('_')[0].lower()
            
            if device_kind in templates:
                filtered_templates[device_kind] = templates[device_kind]
            
            for key, template in templates.items():
                if key != device_kind and device_vendor in key:
                    filtered_templates[key] = template
            
            for key, template in templates.items():
                if key not in filtered_templates and key != 'default':
                    filtered_templates[key] = template
            
            filtered_templates['default'] = templates['default']
            templates = filtered_templates
        
        return JsonResponse({
            'status': 'success',
            'templates': templates,
            'device_kind': device_kind
        })
        
    except Exception as e:
        logger.error(f"Error getting device configuration templates: {e}")
        return JsonResponse({
            'status': 'error',
            'error': str(e)
        }, status=500)


@csrf_exempt
@require_POST
def get_devices_from_yaml(request):
    """Extract device names from YAML topology for configuration management"""
    logger.info("Extracting devices from YAML for configuration management")
    
    try:
        data = json.loads(request.body)
        yaml_content = data.get('yaml_content', '')
        server_id = data.get('server_id', 'local')
        
        if not yaml_content.strip():
            return JsonResponse({
                'status': 'error',
                'error': 'YAML content is required'
            }, status=400)
        
        # Parse YAML
        try:
            yaml_obj = yaml.safe_load(yaml_content)
        except yaml.YAMLError as e:
            return JsonResponse({
                'status': 'error',
                'error': f'Invalid YAML format: {str(e)}'
            }, status=400)
        
        if not yaml_obj or 'topology' not in yaml_obj or 'nodes' not in yaml_obj['topology']:
            return JsonResponse({
                'status': 'error',
                'error': 'YAML must contain topology.nodes section'
            }, status=400)
        
        devices = []
        for device_name, device_config in yaml_obj['topology']['nodes'].items():
            # Check if device already has a saved configuration
            cache_key = f"device_config_{device_name}_{server_id}"
            cached_config = cache.get(cache_key)
            
            has_config = bool(cached_config and cached_config.get('configuration'))
            has_startup_config = 'startup-config' in device_config
            
            devices.append({
                'name': device_name,
                'kind': device_config.get('kind', 'unknown'),
                'image': device_config.get('image', 'unknown'),
                'has_saved_config': has_config,
                'has_startup_config': has_startup_config,
                'startup_config_file': device_config.get('startup-config') if has_startup_config else None,
                'config_size': len(cached_config.get('configuration', '')) if cached_config else 0
            })
        
        logger.info(f"Extracted {len(devices)} devices from YAML")
        
        return JsonResponse({
            'status': 'success',
            'devices': devices,
            'total_devices': len(devices),
            'server_id': server_id
        })
        
    except json.JSONDecodeError:
        return JsonResponse({
            'status': 'error',
            'error': 'Invalid JSON in request body'
        }, status=400)
    except Exception as e:
        logger.error(f"Error extracting devices from YAML: {e}")
        return JsonResponse({
            'status': 'error',
            'error': str(e)
        }, status=500)


@csrf_exempt
@require_POST
def validate_yaml(request):
    """Validate YAML topology structure"""
    logger.info("Validating YAML topology")
    
    try:
        data = json.loads(request.body)
        yaml_content = data.get('yaml_content', '')
        
        if not yaml_content.strip():
            return JsonResponse({
                'status': 'error',
                'error': 'YAML content is required'
            }, status=400)
        
        # Parse YAML
        try:
            yaml_obj = yaml.safe_load(yaml_content)
        except yaml.YAMLError as e:
            return JsonResponse({
                'status': 'error',
                'error': f'Invalid YAML syntax: {str(e)}',
                'is_valid': False
            })
        
        # Validation checks
        warnings = []
        errors = []
        
        # Check basic structure
        if not yaml_obj:
            errors.append('YAML is empty')
        elif not isinstance(yaml_obj, dict):
            errors.append('YAML root must be an object')
        else:
            # Check required sections
            if 'name' not in yaml_obj:
                warnings.append('Missing "name" field')
            
            if 'topology' not in yaml_obj:
                errors.append('Missing "topology" section')
            elif not isinstance(yaml_obj['topology'], dict):
                errors.append('topology must be an object')
            else:
                topology = yaml_obj['topology']
                
                # Check nodes
                if 'nodes' not in topology:
                    errors.append('Missing "topology.nodes" section')
                elif not isinstance(topology['nodes'], dict):
                    errors.append('topology.nodes must be an object')
                elif len(topology['nodes']) == 0:
                    warnings.append('No nodes defined in topology')
                else:
                    # Validate each node
                    for node_name, node_config in topology['nodes'].items():
                        if not isinstance(node_config, dict):
                            errors.append(f'Node "{node_name}" configuration must be an object')
                            continue
                        
                        if 'kind' not in node_config:
                            warnings.append(f'Node "{node_name}" missing "kind" field')
                        
                        if 'image' not in node_config:
                            warnings.append(f'Node "{node_name}" missing "image" field')
                
                # Check links (optional)
                if 'links' in topology:
                    if not isinstance(topology['links'], list):
                        errors.append('topology.links must be an array')
                    else:
                        for i, link in enumerate(topology['links']):
                            if not isinstance(link, dict):
                                errors.append(f'Link {i+1} must be an object')
                                continue
                            
                            if 'endpoints' not in link:
                                errors.append(f'Link {i+1} missing "endpoints" field')
                            elif not isinstance(link['endpoints'], list) or len(link['endpoints']) != 2:
                                errors.append(f'Link {i+1} endpoints must be an array of 2 items')
        
        is_valid = len(errors) == 0
        
        return JsonResponse({
            'status': 'success',
            'is_valid': is_valid,
            'errors': errors,
            'warnings': warnings,
            'node_count': len(yaml_obj.get('topology', {}).get('nodes', {})) if yaml_obj else 0,
            'link_count': len(yaml_obj.get('topology', {}).get('links', [])) if yaml_obj else 0
        })
        
    except json.JSONDecodeError:
        return JsonResponse({
            'status': 'error',
            'error': 'Invalid JSON in request body'
        }, status=400)
    except Exception as e:
        logger.error(f"Error validating YAML: {e}")
        return JsonResponse({
            'status': 'error',
            'error': str(e)
        }, status=500)


@csrf_exempt
def get_dcim_filter_options(request):
    """Get available filter options from Nautobot DCIM"""
    try:
        from nautobot.dcim.models import Device, Location, Rack, Platform, DeviceType
        from nautobot.extras.models import Status, Role
        
        # Get all available filter options
        filter_options = {
            'locations': [],
            'sites': [],
            'racks': [],
            'platforms': [],
            'roles': [],
            'device_types': [],
            'statuses': []
        }
        
        # Get locations
        locations = Location.objects.values_list('name', flat=True).distinct().order_by('name')
        filter_options['locations'] = list(locations)
        
        # Get sites (now using locations)
        sites = Location.objects.values_list('name', flat=True).distinct().order_by('name')
        filter_options['sites'] = list(sites)
        
        # Get racks
        racks = Rack.objects.values_list('name', flat=True).distinct().order_by('name')
        filter_options['racks'] = list(racks)
        
        # Get platforms
        platforms = Platform.objects.values_list('name', flat=True).distinct().order_by('name')
        filter_options['platforms'] = list(platforms)
        
        # Get device roles
        roles = Role.objects.filter(content_types__model='device').values_list('name', flat=True).distinct().order_by('name')
        filter_options['roles'] = list(roles)
        
        # Get device types
        device_types = DeviceType.objects.values_list('model', flat=True).distinct().order_by('model')
        filter_options['device_types'] = list(device_types)
        
        # Get statuses
        statuses = Status.objects.values_list('name', flat=True).distinct().order_by('name')
        filter_options['statuses'] = list(statuses)
        
        return JsonResponse({
            'success': True,
            'filter_options': filter_options
        })
        
    except Exception as e:
        logger.error(f"Error fetching filter options: {str(e)}")
        return create_error_response(str(e))


@csrf_exempt
def get_filtered_dcim_devices(request):
    """Get filtered devices from Nautobot DCIM based on filter criteria"""
    try:
        from nautobot.dcim.models import Device, Cable, Interface, Location, Rack
        
        # Get filter parameters from request
        filters = request.GET.dict()
        
        # Start with all devices
        devices = Device.objects.select_related(
            'device_type', 'platform', 'location', 'role', 'rack'
        ).prefetch_related('interfaces').all()
        
        # Apply filters
        if filters.get('location'):
            devices = devices.filter(location__name=filters['location'])
        
        if filters.get('site'):
            devices = devices.filter(location__name=filters['site'])
        
        if filters.get('rack'):
            devices = devices.filter(rack__name=filters['rack'])
        
        if filters.get('platform'):
            devices = devices.filter(platform__name=filters['platform'])
        
        if filters.get('role'):
            devices = devices.filter(role__name=filters['role'])
        
        if filters.get('device_type'):
            devices = devices.filter(device_type__model=filters['device_type'])
        
        if filters.get('status'):
            devices = devices.filter(status__name=filters['status'])
        
        if filters.get('search'):
            search_term = filters['search']
            devices = devices.filter(
                Q(name__icontains=search_term) |
                Q(serial__icontains=search_term) |
                Q(asset_tag__icontains=search_term)
            )
        
        device_list = []
        connections_list = []
        auto_corrections = []
        processed_connections = set()
        
        for device in devices:
            interfaces = device.interfaces.all()
            interface_count = interfaces.count()
            interface_types = list(set([iface.type for iface in interfaces if iface.type]))
            
            custom_fields = device.custom_field_data or {}
            clab_kind = custom_fields.get('clab_kind')
            clab_image = custom_fields.get('clab_image')
            
            suggested_kind = clab_kind or map_device_type_to_containerlab(device.device_type.model)
            suggested_image = clab_image or get_default_image_for_kind(suggested_kind)
            
            device_connections = []
            for interface in interfaces:
                cables = Cable.objects.filter(
                    termination_a_id=interface.id
                ) | Cable.objects.filter(
                    termination_b_id=interface.id
                )
                
                for cable in cables:
                    try:
                        if cable.termination_a_id == interface.id:
                            connected_interface_id = cable.termination_b_id
                        else:
                            connected_interface_id = cable.termination_a_id
                        
                        connected_interface = Interface.objects.get(id=connected_interface_id)
                        
                        if connected_interface.device.name != device.name:
                            connection_id = tuple(sorted([
                                f"{device.name}:{interface.name}",
                                f"{connected_interface.device.name}:{connected_interface.name}"
                            ]))
                            
                            if connection_id not in processed_connections:
                                connection_data = {
                                    'source_device': device.name,
                                    'source_interface': interface.name,
                                    'target_device': connected_interface.device.name,
                                    'target_interface': connected_interface.name,
                                    'cable_id': str(cable.id)
                                }
                                connections_list.append(connection_data)
                                device_connections.append(connection_data)
                                processed_connections.add(connection_id)
                                
                    except Exception as e:
                        logger.warning(f"Error processing connection for {device.name}: {e}")
                        continue
            
            device_data = {
                'id': str(device.id),
                'name': device.name,
                'model': device.device_type.model if device.device_type else 'Unknown',
                'platform': device.platform.name if device.platform else 'Unknown',
                'location': device.location.name if device.location else 'Unknown',
                'site': device.location.name if device.location else 'Unknown',
                'rack': device.rack.name if device.rack else 'Unknown',
                'role': device.role.name if device.role else 'Unknown',
                'interface_count': interface_count,
                'interface_types': interface_types[:3],
                'suggested_kind': suggested_kind,
                'suggested_image': suggested_image,
                'has_custom_fields': bool(clab_kind and clab_image),
                'status': device.status.name if device.status else 'Unknown',
                'connections': device_connections
            }
            
            device_list.append(device_data)
        
        response_data = {
            'success': True, 
            'devices': device_list,
            'connections': connections_list,
            'total': len(device_list),
            'filters_applied': filters
        }
        
        if auto_corrections:
            response_data['auto_corrections'] = auto_corrections
        
        logger.info(f"Filtered devices: {len(device_list)} devices with {len(connections_list)} connections")
        
        return JsonResponse(response_data)
        
    except Exception as e:
        logger.error(f"Error fetching filtered DCIM devices: {str(e)}")
        return create_error_response(str(e))


@csrf_exempt
def discover_filtered_topology_from_dcim(request):
    """Discover topology from Nautobot DCIM data with filtering"""
    try:
        from nautobot.dcim.models import Device, Interface, Cable
        
        # Get filter parameters from request
        filters = request.GET.dict()
        
        # Start with all devices
        devices = Device.objects.select_related(
            'location', 'platform', 'device_type', 'role', 'rack'
        ).prefetch_related(
            'interfaces', 'primary_ip4'
        ).all()
        
        # Apply filters
        if filters.get('location'):
            devices = devices.filter(location__name=filters['location'])
        
        if filters.get('site'):
            devices = devices.filter(location__name=filters['site'])
        
        if filters.get('rack'):
            devices = devices.filter(rack__name=filters['rack'])
        
        if filters.get('platform'):
            devices = devices.filter(platform__name=filters['platform'])
        
        if filters.get('role'):
            devices = devices.filter(role__name=filters['role'])
        
        if filters.get('device_type'):
            devices = devices.filter(device_type__model=filters['device_type'])
        
        if filters.get('status'):
            devices = devices.filter(status__name=filters['status'])
        
        if filters.get('search'):
            search_term = filters['search']
            devices = devices.filter(
                Q(name__icontains=search_term) |
                Q(serial__icontains=search_term) |
                Q(asset_tag__icontains=search_term)
            )
        
        topology_data = {
            'nodes': {},
            'connections': [],
            'locations': {},
            'device_configs': {},
            'metadata': {
                'discovered_at': timezone.now().isoformat(),
                'total_devices': devices.count(),
                'total_connections': 0,
                'filters_applied': filters
            }
        }
        
        auto_corrections = []
        
        for device in devices:
            node_data = {
                'name': device.name,
                'location': device.location.name if device.location else 'Unknown',
                'site': device.location.name if device.location else 'Unknown',
                'rack': device.rack.name if device.rack else 'Unknown',
                'role': device.role.name if device.role else 'Unknown',
                'platform': device.platform.name if device.platform else 'Unknown',
                'device_type': device.device_type.model,
                'interfaces': [],
                'custom_fields': device.custom_field_data or {}
            }
            
            clab_kind = device.custom_field_data.get('clab_kind') if device.custom_field_data else None
            clab_image = device.custom_field_data.get('clab_image') if device.custom_field_data else None
            
            if not clab_kind:
                clab_kind = map_device_type_to_containerlab(device.device_type.model)
            if not clab_image:
                clab_image = get_default_image_for_kind(clab_kind)
            
            node_data.update({
                'clab_kind': clab_kind,
                'clab_image': clab_image,
                'suggested_kind': clab_kind,
                'suggested_image': clab_image,
                'status': device.status.name if device.status else 'Unknown',
                'serial': device.serial or '',
                'asset_tag': device.asset_tag or '',
                'interface_count': 0,
                'interface_types': [],
                'has_custom_fields': bool(clab_kind and clab_image),
                'connections': []
            })
            
            processed_connections = set()
            interfaces = []
            interface_types = set()
            
            for interface in device.interfaces.all():
                interface_data = {
                    'name': interface.name,
                    'type': interface.type,
                    'enabled': interface.enabled,
                    'mtu': interface.mtu,
                    'description': interface.description or '',
                    'ip_addresses': []
                }
                
                try:
                    for ip_address in interface.ip_addresses.all():
                        interface_data['ip_addresses'].append(str(ip_address.address))
                except:
                    pass
                
                interfaces.append(interface_data)
                interface_types.add(interface.type)
                
                cables = Cable.objects.filter(
                    termination_a_id=interface.id
                ) | Cable.objects.filter(
                    termination_b_id=interface.id
                )
                
                for cable in cables:
                    try:
                        if cable.termination_a_id == interface.id:
                            connected_interface_id = cable.termination_b_id
                        else:
                            connected_interface_id = cable.termination_a_id
                        
                        connected_interface = Interface.objects.get(id=connected_interface_id)
                        
                        if connected_interface.device.name != device.name:
                            connection_id = tuple(sorted([
                                f"{device.name}:{interface.name}",
                                f"{connected_interface.device.name}:{connected_interface.name}"
                            ]))
                            
                            if connection_id not in processed_connections:
                                connection = {
                                    'source_device': device.name,
                                    'source_interface': interface.name,
                                    'target_device': connected_interface.device.name,
                                    'target_interface': connected_interface.name,
                                    'cable_id': str(cable.id),
                                    'cable_type': cable.type if cable.type else 'Unknown',
                                    'cable_length': f"{cable.length}{cable.length_unit}" if cable.length else 'Unknown',
                                    'cable_status': cable.status.name if cable.status else 'Unknown',
                                    'a_interface_type': interface.type,
                                    'b_interface_type': connected_interface.type
                                }
                                topology_data['connections'].append(connection)
                                processed_connections.add(connection_id)
                                
                    except Exception as e:
                        logger.warning(f"Error processing cable connection: {e}")
                        continue
            
            node_data['interfaces'] = interfaces
            node_data['interface_count'] = len(interfaces)
            node_data['interface_types'] = list(interface_types)
            
            topology_data['nodes'][device.name] = node_data
            
            location_name = node_data['location']
            if location_name not in topology_data['locations']:
                topology_data['locations'][location_name] = []
            topology_data['locations'][location_name].append(device.name)
        
        topology_data['metadata']['total_connections'] = len(topology_data['connections'])
        topology_data['metadata']['total_locations'] = len(topology_data['locations'])
        
        if auto_corrections:
            topology_data['auto_corrections'] = auto_corrections
            logger.info(f"Applied {len(auto_corrections)} auto-corrections during topology discovery")
        
        logger.info(f"Filtered discovery complete: {len(topology_data['nodes'])} devices, "
                   f"{len(topology_data['connections'])} connections, "
                   f"{len(topology_data['locations'])} locations")
        
        return JsonResponse({
            'success': True,
            'message': f'Discovered {len(topology_data["nodes"])} devices and {len(topology_data["connections"])} connections',
            **topology_data
        })
        
    except Exception as e:
        logger.error(f"Error discovering filtered topology: {str(e)}")
        return create_error_response(f'Failed to discover topology: {str(e)}')

@csrf_exempt
@require_POST
def execute_device_command(request):
    """Execute a command on a specific device in a lab"""
    try:
        data = json.loads(request.body)
        server_id = data.get('server_id')
        lab_name = data.get('lab_name')
        device_name = data.get('device_name')
        command = data.get('command')
        
        if not all([server_id, lab_name, device_name, command]):
            return JsonResponse({
                'success': False,
                'error': 'Missing required parameters: server_id, lab_name, device_name, command'
            }, status=400)
        
        # Get server configuration
        manager = RemoteContainerlabManager()
        
        # Get the actual server configuration from the internal config
        server_config = manager.servers.get(server_id)
        if not server_config:
            return JsonResponse({
                'success': False,
                'error': f'Server {server_id} not found'
            }, status=404)
        
        # Check if server is enabled
        if not server_config.get('enabled', True):
            return JsonResponse({
                'success': False,
                'error': f'Server {server_id} is disabled'
            }, status=400)
        
        # Execute command based on server type
        # For local_api, treat it as local since containerlab API doesn't have exec endpoint
        if server_config.get('type') in ['local', 'api'] and server_id in ['local', 'local_api']:
            result = manager._execute_local_device_command(lab_name, device_name, command)
        elif server_config.get('type') == 'api':
            result = manager._execute_api_device_command(server_config, lab_name, device_name, command)
        elif server_config.get('type') == 'ssh':
            result = manager._execute_ssh_device_command(server_config, lab_name, device_name, command)
        elif server_config.get('type') == 'hybrid':
            # For hybrid servers, try API first, then fall back to SSH
            try:
                result = manager._execute_api_device_command(server_config, lab_name, device_name, command)
            except Exception as api_error:
                try:
                    result = manager._execute_ssh_device_command(server_config, lab_name, device_name, command)
                except Exception as ssh_error:
                    return JsonResponse({
                        'success': False,
                        'error': f'Both API and SSH failed for hybrid server. API error: {api_error}, SSH error: {ssh_error}'
                    }, status=400)
        else:
            return JsonResponse({
                'success': False,
                'error': f'Unsupported server type: {server_config.get("type")}'
            }, status=400)
        
        return JsonResponse(result)
        
    except Exception as e:
        logger.error(f"Error executing device command: {e}")
        return JsonResponse({
            'success': False,
            'error': str(e)
        }, status=500)

@csrf_exempt
def get_device_shell_info(request, server_id, lab_name, device_name):
    """Get information about available shells/CLI for a device"""
    try:
        # Get server configuration
        manager = RemoteContainerlabManager()
        
        # Debug logging
        logger.info(f"🔍 Getting device shell info for server_id={server_id}, lab_name={lab_name}, device_name={device_name}")
        logger.info(f"🔍 Available servers: {list(manager.servers.keys())}")
        
        # Get the actual server configuration from the internal config
        server_config = manager.servers.get(server_id)
        logger.info(f"🔍 Server config for {server_id}: {server_config}")
        
        if not server_config:
            return JsonResponse({
                'success': False,
                'error': f'Server {server_id} not found'
            }, status=404)
        
        # Check if server is enabled
        if not server_config.get('enabled', True):
            return JsonResponse({
                'success': False,
                'error': f'Server {server_id} is disabled'
            }, status=400)
        
        logger.info(f"🔍 Server type: {server_config.get('type')}")
        
        # Get device shell information
        # For local_api, treat it as local since containerlab API doesn't have device-shell-info
        if server_config.get('type') in ['local', 'api'] and server_id in ['local', 'local_api']:
            result = manager._get_local_device_shell_info(lab_name, device_name)
        elif server_config.get('type') == 'api':
            result = manager._get_api_device_shell_info(server_config, lab_name, device_name)
        elif server_config.get('type') == 'ssh':
            result = manager._get_ssh_device_shell_info(server_config, lab_name, device_name)
        elif server_config.get('type') == 'hybrid':
            # For hybrid servers, try API first, then fall back to SSH
            try:
                logger.info(f"🔍 Trying API first for hybrid server")
                result = manager._get_api_device_shell_info(server_config, lab_name, device_name)
            except Exception as api_error:
                logger.error(f"🔍 API failed for hybrid server: {api_error}")
                try:
                    logger.info(f"🔍 Falling back to SSH for hybrid server")
                    result = manager._get_ssh_device_shell_info(server_config, lab_name, device_name)
                except Exception as ssh_error:
                    logger.error(f"🔍 SSH also failed for hybrid server: {ssh_error}")
                    return JsonResponse({
                        'success': False,
                        'error': f'Both API and SSH failed for hybrid server. API error: {api_error}, SSH error: {ssh_error}'
                    }, status=400)
        else:
            return JsonResponse({
                'success': False,
                'error': f'Unsupported server type: {server_config.get("type")}'
            }, status=400)
        
        logger.info(f"🔍 Result: {result}")
        return JsonResponse(result)
        
    except Exception as e:
        logger.error(f"Error getting device shell info: {e}")
        return JsonResponse({
            'success': False,
            'error': str(e)
        }, status=500)

@csrf_exempt
def get_device_available_commands(request, server_id, lab_name, device_name):
    """Get available commands for a specific device type"""
    try:
        # Get server configuration
        manager = RemoteContainerlabManager()
        
        # Get the actual server configuration from the internal config
        server_config = manager.servers.get(server_id)
        if not server_config:
            return JsonResponse({
                'success': False,
                'error': f'Server {server_id} not found'
            }, status=404)
        
        # Check if server is enabled
        if not server_config.get('enabled', True):
            return JsonResponse({
                'success': False,
                'error': f'Server {server_id} is disabled'
            }, status=400)
        
        # Get device type and available commands
        # For local_api, treat it as local since containerlab API doesn't have device-commands
        if server_config.get('type') in ['local', 'api'] and server_id in ['local', 'local_api']:
            result = manager._get_local_device_commands(lab_name, device_name)
        elif server_config.get('type') == 'api':
            result = manager._get_api_device_commands(server_config, lab_name, device_name)
        elif server_config.get('type') == 'ssh':
            result = manager._get_ssh_device_commands(server_config, lab_name, device_name)
        elif server_config.get('type') == 'hybrid':
            # For hybrid servers, try API first, then fall back to SSH
            try:
                result = manager._get_api_device_commands(server_config, lab_name, device_name)
            except Exception as api_error:
                try:
                    result = manager._get_ssh_device_commands(server_config, lab_name, device_name)
                except Exception as ssh_error:
                    return JsonResponse({
                        'success': False,
                        'error': f'Both API and SSH failed for hybrid server. API error: {api_error}, SSH error: {ssh_error}'
                    }, status=400)
        else:
            return JsonResponse({
                'success': False,
                'error': f'Unsupported server type: {server_config.get("type")}'
            }, status=400)
        
        return JsonResponse(result)
        
    except Exception as e:
        logger.error(f"Error getting device commands: {e}")
        return JsonResponse({
            'success': False,
            'error': str(e)
        }, status=500)
