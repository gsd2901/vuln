"""
Digital Twin URLs - Complete with Remote Server Support
"""

from django.urls import path
from . import views

app_name = 'digital_twin'

urlpatterns = [
    # Main interface
    path('', views.digital_twin_view, name='digital_twin'),
    
    # Topology operations
    path('discover-topology/', views.discover_topology_from_dcim, name='discover_topology'),
    path('discover-filtered-topology/', views.discover_filtered_topology_from_dcim, name='discover_filtered_topology'),
    path('devices/', views.get_dcim_devices, name='get_dcim_devices'),
    path('filtered-devices/', views.get_filtered_dcim_devices, name='get_filtered_dcim_devices'),
    path('filter-options/', views.get_dcim_filter_options, name='get_dcim_filter_options'),
    
    # YAML operations
    path('save-yaml/', views.save_yaml, name='save_yaml'),
    path('export-topology/', views.export_topology_view, name='export_topology'),
    
    # Lab simulation - Enhanced for remote
    path('simulate-lab/', views.simulate_lab, name='simulate_lab'),
    
    # Remote server management (NEW)
    path('remote-servers/', views.get_remote_servers_view, name='get_remote_servers'),
    path('server-health/<str:server_id>/', views.server_health_view, name='server_health'),
    path('lab-status/<str:server_id>/<str:lab_name>/', views.get_lab_status_view, name='get_lab_status'),
    
    # Lab management (NEW)
    path('servers/<str:server_id>/labs/', views.get_active_labs_view, name='get_active_labs'),
    path('servers/<str:server_id>/labs/<str:lab_name>/stop/', views.stop_lab_view, name='stop_lab'),
    path('servers/<str:server_id>/labs/<str:lab_name>/logs/', views.get_lab_logs_view, name='get_lab_logs'),
    
    # Deployment tracking (NEW)
    path('deployment-status/<str:deployment_id>/', views.get_deployment_status_view, name='get_deployment_status'),
    path('deployment-logs/<str:deployment_id>/', views.get_deployment_logs_view, name='get_deployment_logs'),
    
    # Device management (existing)
    path('device-details/<uuid:device_id>/', views.get_device_details, name='get_device_details'),
    path('create-interfaces/', views.create_missing_interfaces, name='create_missing_interfaces'),
    path('create-cable/', views.create_connection_cable, name='create_connection_cable'),
    
    # Device configurations (existing)
    path('device-configs/', views.get_device_configurations, name='get_device_configurations'),
    
    # Configuration file upload (NEW - Device-centric)
    # path('upload-device-config/', views.upload_device_configuration, name='upload_device_configuration'),
    path('get-devices-from-yaml/', views.get_devices_from_yaml, name='get_devices_from_yaml'),
    path('validate-yaml/', views.validate_yaml, name='validate_yaml'),
    # path('uploaded-configs/<str:deployment_id>/', views.get_uploaded_configurations, name='get_uploaded_configurations'),
    # path('preview-config/<str:deployment_id>/<str:node_name>/', views.preview_configuration, name='preview_configuration'),
    
    # Live configuration management (NEW - Device Details Modal Integration)
    path('save-device-config-live/', views.save_device_config_live, name='save_device_config_live'),
    path('get-device-config-live/<str:device_name>/', views.get_device_config_live, name='get_device_config_live'),
    path('apply-device-config-live/<str:device_name>/', views.apply_device_config_live, name='apply_device_config_live'),
    path('validate-device-config/', views.validate_device_config, name='validate_device_config'),
    path('get-device-config-templates/', views.get_device_config_templates, name='get_device_config_templates'),
    
    # Enhanced deployment with configuration integration (NEW - Phase 2)
    path('get-all-device-configs-for-deployment/', views.get_all_device_configs_for_deployment, name='get_all_device_configs_for_deployment'),
    path('deploy-with-configurations/', views.deploy_with_configurations, name='deploy_with_configurations'),
    
    # Debug endpoints (NEW - For troubleshooting)
    path('debug/config-files/', views.debug_config_files, name='debug_config_files'),
    path('debug/deployment/<str:deployment_id>/', views.debug_deployment_status, name='debug_deployment_status'),
    path('debug/ui-test/', views.debug_ui_test, name='debug_ui_test'),
    
    # Terminal/Device CLI endpoints (NEW)
    path('execute-device-command/', views.execute_device_command, name='execute_device_command'),
    path('device-shell-info/<str:server_id>/<str:lab_name>/<str:device_name>/', views.get_device_shell_info, name='get_device_shell_info'),
    path('device-commands/<str:server_id>/<str:lab_name>/<str:device_name>/', views.get_device_available_commands, name='get_device_available_commands'),
]
