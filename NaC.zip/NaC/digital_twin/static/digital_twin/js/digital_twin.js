// Global variables
let globalEditor = null;
let pendingConnection = null;
let currentTopologyData = null;
let filteredLocations = [];
let nodePositions = new Map();

// Enhanced Utility Classes
class DOMUtils {
    static showModal(modalElement) {
        if (modalElement) {
            modalElement.style.display = 'flex';
            modalElement.style.alignItems = 'center';
            modalElement.style.justifyContent = 'center';
            document.body.classList.add('modal-open');
        }
    }

    static hideModal(modalElement) {
        if (modalElement) {
            modalElement.style.display = 'none';
            document.body.classList.remove('modal-open');
        }
    }

    static clearContainer(container) {
        if (container) {
            while (container.firstChild) {
                container.removeChild(container.firstChild);
            }
        }
    }

    static showElement(element) {
        if (element) element.style.display = 'block';
    }

    static hideElement(element) {
        if (element) element.style.display = 'none';
    }
}

class YAMLOperations {
    static parseYAML(content) {
        try {
            return { success: true, data: jsyaml.load(content) };
        } catch (e) {
            return { success: false, error: e.message };
        }
    }

    static validateYAML(content) {
        const result = this.parseYAML(content);
        return result.success;
    }

    static generateFromTopologyData(topologyData) {
        // REMOVED: mgmt section - Containerlab will auto-assign management IPs
        const yamlData = {
            name: `dcim-topology-${Date.now()}`,
            topology: {
                nodes: {},
                links: []
            }
        };

        // Process nodes - REMOVED: mgmt-ipv4 assignment
        Object.entries(topologyData.nodes || {}).forEach(([deviceName, deviceData]) => {
            yamlData.topology.nodes[deviceName] = {
                kind: deviceData.clab_kind,
                image: deviceData.clab_image
            };
            // REMOVED: mgmt-ipv4 field - Containerlab will auto-assign management IPs

            if (deviceData.location || deviceData.role || deviceData.platform) {
                yamlData.topology.nodes[deviceName].labels = {};
                if (deviceData.location) yamlData.topology.nodes[deviceName].labels.location = deviceData.location;
                if (deviceData.role) yamlData.topology.nodes[deviceName].labels.role = deviceData.role;
                if (deviceData.platform) yamlData.topology.nodes[deviceName].labels.platform = deviceData.platform;
            }
        });

        // Process connections - Fixed Containerlab format
        (topologyData.connections || []).forEach(connection => {
            const endpoint1 = `${connection.source_device}:${connection.source_interface}`;
            const endpoint2 = `${connection.target_device}:${connection.target_interface}`;

            // Prevent duplicate connections
            const exists = yamlData.topology.links.some(link =>
                (link.endpoints[0] === endpoint1 && link.endpoints[1] === endpoint2) ||
                (link.endpoints[0] === endpoint2 && link.endpoints[1] === endpoint1)
            );

            if (!exists) {
                yamlData.topology.links.push({
                    endpoints: [endpoint1, endpoint2]
                });
            }
        });

        return jsyaml.dump(yamlData, { indent: 2 });
    }
}

class StatusManager {
    static updateStatus(nodeCount, connectionCount, locationCount, status = 'Ready') {
        const elements = {
            'node-count': nodeCount,
            'connection-count': connectionCount,
            'location-count': locationCount,
            'topology-status': status
        };

        Object.entries(elements).forEach(([id, value]) => {
            const element = document.getElementById(id);
            if (element) element.textContent = value;
        });
    }

    static showProgress(title, description) {
        console.log('📊 Showing progress modal:', title);

        const titleElement = document.getElementById('progress-title');
        const descElement = document.getElementById('progress-description');
        const progressModal = document.getElementById('progress-modal');
        const progressFill = document.getElementById('progress-fill');
        const progressText = document.getElementById('progress-text');

        console.log('🔍 Modal elements check:');
        console.log('  - Title element:', titleElement ? 'Found' : 'Not found');
        console.log('  - Description element:', descElement ? 'Found' : 'Not found');
        console.log('  - Progress modal:', progressModal ? 'Found' : 'Not found');
        console.log('  - Progress fill:', progressFill ? 'Found' : 'Not found');
        console.log('  - Progress text:', progressText ? 'Found' : 'Not found');

        if (titleElement) titleElement.textContent = title;
        if (descElement) descElement.textContent = description;

        // Reset progress to 0 with enhanced styling
        if (progressFill) {
            // Clear any existing styles first
            progressFill.style.removeProperty('width');

            // Set initial state with proper CSS
            progressFill.style.setProperty('width', '0%', 'important');
            progressFill.style.setProperty('background', 'var(--hcl-gradient)', 'important');
            progressFill.style.setProperty('height', '100%', 'important');
            progressFill.style.setProperty('display', 'block', 'important');
            progressFill.style.setProperty('transition', 'width 0.5s ease', 'important');

            console.log('🔄 Reset progress fill to 0% with enhanced styling');

            // Force reflow to ensure styles are applied
            progressFill.offsetHeight;
        }
        if (progressText) {
            progressText.textContent = 'Starting...';
            console.log('🔄 Reset progress text');
        }

        if (progressModal) {
            // Ensure modal is properly styled for display
            progressModal.style.setProperty('display', 'flex', 'important');
            progressModal.style.setProperty('align-items', 'center', 'important');
            progressModal.style.setProperty('justify-content', 'center', 'important');
            progressModal.style.setProperty('z-index', '10000', 'important');

            DOMUtils.showModal(progressModal);
            console.log('✅ Progress modal displayed with display:', progressModal.style.display);

            // Additional check after a brief delay
            setTimeout(() => {
                const modalStyle = window.getComputedStyle(progressModal);
                console.log('📊 Modal final state:', {
                    display: modalStyle.display,
                    visibility: modalStyle.visibility,
                    opacity: modalStyle.opacity,
                    zIndex: modalStyle.zIndex
                });
            }, 100);
        } else {
            console.error('❌ Progress modal element not found');
            // Try to find the modal in the DOM
            setTimeout(() => {
                const retryModal = document.getElementById('progress-modal');
                if (retryModal) {
                    console.log('🔄 Found progress modal on retry, showing it...');
                    StatusManager.showProgress(title, description);
                } else {
                    console.error('❌ Progress modal still not found after retry');
                }
            }, 100);
        }
    }

    static hideProgress() {
        console.log('📊 Hiding progress modal');

        const progressModal = document.getElementById('progress-modal');
        if (progressModal) {
            DOMUtils.hideModal(progressModal);
            console.log('✅ Progress modal hidden');
        } else {
            console.error('❌ Progress modal element not found');
        }
    }

    static updateProgress(percentage, message) {
        console.log('📈 Updating progress:', percentage + '%', message);

        // Ensure percentage is a valid number
        const validPercentage = Math.max(0, Math.min(100, Number(percentage) || 0));

        const progressFill = document.getElementById('progress-fill');
        const progressText = document.getElementById('progress-text');
        const progressModal = document.getElementById('progress-modal');

        // Check if modal is visible first
        if (progressModal && progressModal.style.display === 'none') {
            console.warn('⚠️ Progress modal is not visible, showing it first');
            StatusManager.showProgress('Processing...', 'Operation in progress...');
        }

        if (progressFill) {
            console.log('🎯 Setting progress width to:', validPercentage + '%');
            console.log('🎯 Current width before update:', progressFill.style.width);

            // Check if element is actually visible and has dimensions
            const rect = progressFill.getBoundingClientRect();
            console.log('🎯 Element dimensions:', rect.width, 'x', rect.height);

            // Force a reflow to ensure the element is properly rendered
            progressFill.offsetHeight;

            // Clear any existing styles that might interfere
            progressFill.style.removeProperty('width');

            // Set width with important flag and ensure proper CSS
            progressFill.style.setProperty('width', validPercentage + '%', 'important');
            progressFill.style.setProperty('transition', 'width 0.5s ease', 'important');
            progressFill.style.setProperty('background', 'var(--hcl-gradient)', 'important');
            progressFill.style.setProperty('height', '100%', 'important');
            progressFill.style.setProperty('display', 'block', 'important');

            // Force another reflow to apply the changes
            setTimeout(() => {
                progressFill.offsetHeight;
                const computedStyle = window.getComputedStyle(progressFill);
                console.log('🎯 Width after update:', progressFill.style.width);
                console.log('🎯 Computed width:', computedStyle.width);
                console.log('🎯 Element display:', computedStyle.display);
                console.log('🎯 Element visibility:', computedStyle.visibility);
                console.log('🎯 Element background:', computedStyle.background);
                console.log('🎯 Parent element:', progressFill.parentElement);

                // Additional check for parent visibility
                if (progressFill.parentElement) {
                    const parentStyle = window.getComputedStyle(progressFill.parentElement);
                    console.log('🎯 Parent display:', parentStyle.display);
                    console.log('🎯 Parent visibility:', parentStyle.visibility);
                }
            }, 50); // Increased timeout for better reliability
        } else {
            console.error('❌ Progress fill element not found');
            // Try to find it again after a short delay
            setTimeout(() => {
                const retryFill = document.getElementById('progress-fill');
                if (retryFill) {
                    console.log('🔄 Found progress-fill on retry, updating...');
                    StatusManager.updateProgress(validPercentage, message);
                } else {
                    console.error('❌ Progress fill still not found after retry');
                }
            }, 100);
        }

        if (progressText) {
            progressText.textContent = message || `${validPercentage}% complete`;
            console.log('📝 Updated progress text to:', progressText.textContent);
        } else {
            console.error('❌ Progress text element not found');
            // Try to find it again after a short delay
            setTimeout(() => {
                const retryText = document.getElementById('progress-text');
                if (retryText) {
                    retryText.textContent = message || `${validPercentage}% complete`;
                    console.log('🔄 Updated progress text on retry');
                }
            }, 100);
        }

        // Additional debugging: check if modal is actually visible
        if (progressModal) {
            const modalStyle = window.getComputedStyle(progressModal);
            console.log('📊 Modal display state:', {
                display: modalStyle.display,
                visibility: modalStyle.visibility,
                opacity: modalStyle.opacity,
                zIndex: modalStyle.zIndex
            });
        }
    }

    static setProgressError(errorMessage) {
        console.log('❌ Setting progress error:', errorMessage);

        const progressFill = document.getElementById('progress-fill');
        const progressText = document.getElementById('progress-text');
        const progressModal = document.getElementById('progress-modal');

        if (progressFill) {
            progressFill.style.background = 'linear-gradient(90deg, #dc3545, #c82333)';
            progressFill.style.width = '100%';
        }

        if (progressText) {
            progressText.textContent = errorMessage;
            progressText.style.color = '#dc3545';
        }

        // Add error styling to the modal
        if (progressModal) {
            progressModal.classList.add('progress-error');
        }

        // Auto-hide progress modal after showing error for 3 seconds
        setTimeout(() => {
            this.hideProgress();
        }, 3000);
    }

    static resetProgress() {
        const progressFill = document.getElementById('progress-fill');
        const progressText = document.getElementById('progress-text');

        if (progressFill) {
            progressFill.style.background = 'var(--hcl-gradient)';
            progressFill.style.width = '0%';
        }

        if (progressText) {
            progressText.style.color = '';
            progressText.textContent = 'Initializing...';
        }
    }
}




class DeviceConfig {
    static deviceImages = {
        'arista_veos': ['aristanetworks/veos:latest', 'aristanetworks/veos:4.29.2F'],
        'arista_ceos': [
            'ceos:4.34.1F',
            'ceos:4.32.0F',
            'arista/ceos:latest'
        ],
        'cisco_csr1000v': ['cisco/csr1000v:17.03.06', 'vrnetlab/cisco_csr1000v:latest'],
        'cisco_n9kv': ['cisco/n9kv:10.2.3', 'vrnetlab/cisco_n9kv:latest'],
        'cisco_xrd': ['cisco/xrd:latest', 'ios-xrd:7.8.1'],
        'nokia_srl': ['ghcr.io/nokia/srlinux:latest', 'nokia/srlinux:23.10.1'],
        'juniper_vmx': ['vrnetlab/juniper_vmx:20.2R1.10', 'juniper/vmx:latest'],
        'juniper_vqfx': ['vrnetlab/juniper_vqfx:20.2R1.10', 'juniper/vqfx:latest'],
        'linux': ['frrouting/frr:latest', 'ubuntu:20.04', 'alpine:latest'],
        'ubuntu': ['ubuntu:20.04', 'ubuntu:22.04', 'ubuntu:latest'],
        'alpine': ['alpine:3.18', 'alpine:latest']
    };

    static mapDeviceTypeToContainerlab(deviceModel) {
        if (!deviceModel) return 'linux';
        const model = deviceModel.toLowerCase();

        const mappings = {
            'veos': 'arista_veos',
            'dcs': 'arista_ceos',
            'arista': 'arista_ceos',
            'csr1000v': 'cisco_csr1000v',
            'nexus': 'cisco_n9kv',
            'n9kv': 'cisco_n9kv',
            'c9300': 'linux',
            'vmx': 'juniper_vmx',
            'vqfx': 'juniper_vqfx',
            'srlinux': 'nokia_srl',
            'nokia': 'nokia_srl'
        };

        for (const [key, value] of Object.entries(mappings)) {
            if (model.includes(key)) return value;
        }
        return 'linux';
    }
}

class ModalManager {
    constructor() {
        this.modals = new Map();
        this.setupEventListeners();
    }

    register(modalId, modal) {
        this.modals.set(modalId, modal);
    }

    show(modalId) {
        const modal = this.modals.get(modalId);
        if (modal) DOMUtils.showModal(modal);
    }

    hide(modalId) {
        const modal = this.modals.get(modalId);
        if (modal) DOMUtils.hideModal(modal);
    }

    setupEventListeners() {
        window.addEventListener('click', (event) => {
            this.modals.forEach((modal, modalId) => {
                if (event.target === modal) {
                    this.hide(modalId);
                    if (modalId === 'connection-modal') {
                        pendingConnection = null;
                    }
                }
            });
        });
    }
}

class EventManager {
    constructor() {
        this.handlers = new Map();
    }

    addHandler(element, event, handler) {
        if (!element) return;

        const key = `${element.id || 'anonymous'}-${event}`;

        if (this.handlers.has(key)) {
            const oldHandler = this.handlers.get(key);
            element.removeEventListener(event, oldHandler);
        }

        element.addEventListener(event, handler);
        this.handlers.set(key, handler);
    }

    removeAllHandlers() {
        this.handlers.clear();
    }
}
class NodeManager {
    constructor(editor) {
        this.editor = editor;
    }

    addNode(nodeName, nodeConfig) {
        const result = YAMLOperations.parseYAML(this.editor.getValue());
        if (!result.success) {
            throw new Error(result.error);
        }

        const yamlObj = result.data;
        this.ensureTopologyStructure(yamlObj);

        yamlObj.topology.nodes[nodeName] = nodeConfig;

        const updatedYaml = jsyaml.dump(yamlObj);
        this.editor.setValue(updatedYaml);
        this.editor.clearSelection();

        return updatedYaml;
    }

    addNodeFromDcim(deviceData) {
        const nodeConfig = {
            kind: deviceData.suggested_kind,
            image: deviceData.suggested_image
        };
        // REMOVED: mgmt-ipv4 assignment - Containerlab will auto-assign management IPs

        return this.addNode(deviceData.name, nodeConfig);
    }

    ensureTopologyStructure(yamlObj) {
        if (!yamlObj.topology) yamlObj.topology = {};
        if (!yamlObj.topology.nodes) yamlObj.topology.nodes = {};
        if (!yamlObj.topology.links) yamlObj.topology.links = [];
    }
}

class ConnectionManager {
    constructor(editor) {
        this.editor = editor;
    }

    createConnection(sourceName, targetName, sourceInterface, targetInterface) {
        const result = YAMLOperations.parseYAML(this.editor.getValue());
        if (!result.success) {
            throw new Error(result.error);
        }

        const yamlObj = result.data;
        this.ensureTopologyStructure(yamlObj);

        // Check for existing connection
        const endpoint1 = `${sourceName}:${sourceInterface}`;
        const endpoint2 = `${targetName}:${targetInterface}`;

        const exists = yamlObj.topology.links.some(link =>
            link.endpoints &&
            ((link.endpoints[0] === endpoint1 && link.endpoints[1] === endpoint2) ||
                (link.endpoints[0] === endpoint2 && link.endpoints[1] === endpoint1))
        );

        if (exists) {
            throw new Error('Connection already exists between these interfaces');
        }

        // Add new connection with proper Containerlab format
        yamlObj.topology.links.push({
            endpoints: [endpoint1, endpoint2]
        });

        const updatedYaml = jsyaml.dump(yamlObj);
        this.editor.setValue(updatedYaml);
        this.editor.clearSelection();

        return updatedYaml;
    }

    ensureTopologyStructure(yamlObj) {
        if (!yamlObj.topology) yamlObj.topology = {};
        if (!yamlObj.topology.links) yamlObj.topology.links = [];
    }
}

// Utility Functions
function getCookie(name) {
    let cookieValue = null;
    if (document.cookie && document.cookie !== '') {
        const cookies = document.cookie.split(';');
        for (let i = 0; i < cookies.length; i++) {
            let cookie = cookies[i].trim();
            if (cookie.substring(0, name.length + 1) === (name + '=')) {
                cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                break;
            }
        }
    }
    return cookieValue;
}

function getNodeIcon(kind) {
    if (!kind) return 'fas fa-question-circle';
    const k = kind.toLowerCase();
    if (k.includes('nokia')) return 'fas fa-network-wired';
    if (k.includes('cisco')) return 'fas fa-server';
    if (k.includes('juniper')) return 'fas fa-sitemap';
    if (k.includes('arista')) return 'fas fa-project-diagram';
    if (/linux|ubuntu|alpine/.test(k)) return 'fab fa-linux';
    return 'fas fa-cube';
}

function getDeviceColor(kind) {
    const colorMap = {
        'arista_veos': '#f39c12',
        'arista_ceos': '#e67e22',
        'cisco_csr1000v': '#3498db',
        'cisco_n9kv': '#2980b9',
        'nokia_srl': '#9b59b6',
        'juniper_vmx': '#27ae60',
        'linux': '#95a5a6'
    };
    return colorMap[kind] || '#34495e';
}

function resizeEditor() {
    if (globalEditor) {
        globalEditor.resize();
    }
}

// Main Application Class
class TopologyEditor {
    constructor() {
        this.modalManager = new ModalManager();
        this.eventManager = new EventManager();
        this.remoteLabManager = new RemoteLabManager();
        this.dcimFilterManager = new DCIMFilterManager();
        this.terminalManager = new TerminalManager();
        this.nodeManager = null;
        this.connectionManager = null;
        this.nodeElements = {};
        this.dragState = new Map();
        this.isLoadingDCIM = false;
        this.isSimulating = false;
        this.init();
    }

    async init() {
        this.initializeEditor();
        this.setupModals();
        this.setupEventListeners();
        this.loadInitialTopology();
        await this.remoteLabManager.initialize();
        await this.dcimFilterManager.initialize();
        this.terminalManager.initialize();

        // Make terminal manager globally available for container actions
        window.terminalManager = this.terminalManager;

        // Initialize connection status
        this.initializeConnectionStatus();
    }

    setupModals() {
        const modals = [
            'add-node-modal',
            'connection-modal',
            'device-details-modal',
            'progress-modal',
            'result-modal',
            'settings-modal'
        ];

        modals.forEach(modalId => {
            const modal = document.getElementById(modalId);
            if (modal) {
                this.modalManager.register(modalId, modal);
            }
        });

        // Initialize Add Node Modal to default state
        this.initializeAddNodeModal();
    }

    initializeAddNodeModal() {
        // Ensure the modal starts with existing device selected by default
        const sourceExisting = document.getElementById('source-existing');
        const sourceCustom = document.getElementById('source-custom');

        if (sourceExisting && sourceCustom) {
            sourceExisting.checked = true;
            sourceCustom.checked = false;

            // Initialize sections visibility
            this.showExistingDeviceSection();
        }
    }

    initializeEditor() {
        try {
            globalEditor = ace.edit("yaml-editor");

            // FIXED: Disable web workers to resolve CSP issue
            globalEditor.setOption("useWorker", false);

            // Modern Light Theme Configuration
            globalEditor.setTheme("ace/theme/crimson_editor");
            globalEditor.session.setMode("ace/mode/yaml");

            globalEditor.setHighlightActiveLine(true);
            globalEditor.setShowPrintMargin(false);
            globalEditor.renderer.setShowGutter(true);

            // Light theme specific styling
            globalEditor.setOptions({
                fontSize: "14px",
                fontFamily: "'JetBrains Mono', 'Fira Code', 'SF Mono', 'Monaco', 'Inconsolata', 'Roboto Mono', monospace",
                highlightActiveLine: true,
                highlightSelectedWord: true,
                cursorStyle: "smooth",
                selectionStyle: "text"
            });

            // ✅ CRITICAL: Disable bracket matching that creates the problematic markers
            globalEditor.setBehavioursEnabled(false);
            globalEditor.setOption("highlightSelectedWord", false);

            // ✅ Alternative: If you want to keep bracket matching but fix positioning
            globalEditor.renderer.setScrollMargin(0, 0, 0, 0);
            globalEditor.renderer.setPadding(0);

            // ✅ Force clean font metrics calculation
            globalEditor.setOptions({
                fontFamily: "Monaco, Menlo, 'Ubuntu Mono', monospace",
                fontSize: "14px",
                showLineNumbers: true,
                wrap: false
            });

            setTimeout(() => {
                globalEditor.resize();
                globalEditor.renderer.updateFull();
            }, 100);

            this.nodeManager = new NodeManager(globalEditor);
            this.connectionManager = new ConnectionManager(globalEditor);

            window.addEventListener('resize', resizeEditor);
            resizeEditor();

            globalEditor.getSession().on('change', () => {
                try {
                    const yamlContent = globalEditor.getValue();
                    this.updateVisualization(yamlContent);
                    this.updateStatusFromYAML(yamlContent);
                } catch (e) {
                    console.error("YAML parsing error:", e);
                }
            });
        } catch (error) {
            console.error("Error initializing editor:", error);
        }
    }

    setupEventListeners() {
        this.setupModalEvents();
        this.setupButtonEvents();
        this.setupDeviceToggle();
        this.setupTopologyControls();
        this.setupEditorToggle();
        this.setupRemoteServerEvents();

    }

    // FIXED: Editor Toggle with proper floating button management
    setupEditorToggle() {
        const toggleEditorBtn = document.getElementById('toggle-editor');


        if (toggleEditorBtn) {
            this.eventManager.addHandler(toggleEditorBtn, 'click', (e) => {
                // e.preventDefault();
                // e.stopPropagation();
                console.log('🔄 Toggle editor clicked');
                this.toggleEditorPanel();
            });
        }

        // Floating toggle button is unnecessary - using toolbar button only
    }

    setupRemoteServerEvents() {
        console.log('🎛️ Setting up remote server events...');

        // Server refresh button
        const refreshServersBtn = document.getElementById('refresh-servers-btn');
        if (refreshServersBtn) {
            this.eventManager.addHandler(refreshServersBtn, 'click', async (e) => {
                e.preventDefault();
                console.log('🔄 Refreshing server list...');
                await this.remoteLabManager.refreshServerHealth();
            });
        }
    }

    // Removed createFloatingToggleButton - using toolbar button only

    analyzeConnections(yamlObj) {
        if (!yamlObj.topology || !yamlObj.topology.links) return [];

        const connectionMap = new Map();
        const analyzedConnections = [];

        // First pass: group connections by device pairs
        yamlObj.topology.links.forEach((link, idx) => {
            if (!link.endpoints || link.endpoints.length !== 2) return;

            const [sourceNode, sourceInterface] = link.endpoints[0].split(':');
            const [targetNode, targetInterface] = link.endpoints[1].split(':');

            // Create a consistent key for device pairs (alphabetical order)
            const devicePair = [sourceNode, targetNode].sort().join('↔');

            if (!connectionMap.has(devicePair)) {
                connectionMap.set(devicePair, []);
            }

            connectionMap.get(devicePair).push({
                index: idx,
                sourceNode,
                sourceInterface,
                targetNode,
                targetInterface,
                originalLink: link
            });
        });

        // Second pass: analyze connection types
        connectionMap.forEach((connections, devicePair) => {
            if (connections.length === 1) {
                // Single connection
                analyzedConnections.push({
                    ...connections[0],
                    type: 'single',
                    color: '#2fe5bf',
                    offset: 0
                });
            } else if (connections.length === 2) {
                // Bidirectional connection
                connections.forEach((conn, idx) => {
                    analyzedConnections.push({
                        ...conn,
                        type: 'bidirectional',
                        color: '#ff6b6b', // Different color for bidirectional
                        offset: idx === 0 ? -6 : 6, // Offset lines
                        bidirectionalPair: true
                    });
                });
            } else {
                // Multiple connections (more than 2)
                connections.forEach((conn, idx) => {
                    const colors = ['#2fe5bf', '#ff6b6b', '#ffd93d', '#6bcf7f', '#a64ac9'];
                    analyzedConnections.push({
                        ...conn,
                        type: 'multiple',
                        color: colors[idx % colors.length],
                        offset: (idx - (connections.length - 1) / 2) * 8
                    });
                });
            }
        });

        return analyzedConnections;
    }


    toggleEditorPanel() {
        console.log('🔄 Toggling editor panel...');

        const editorPanel = document.querySelector('.editor-panel');
        const visualizationPanel = document.querySelector('.visualization-panel');
        const mainToggleBtn = document.getElementById('toggle-editor');


        const isCollapsed = editorPanel.classList.contains('collapsed');
        console.log('📊 Current state - collapsed:', isCollapsed);

        if (isCollapsed) {
            // Show editor
            console.log('👁️ Showing editor panel');
            editorPanel.classList.remove('collapsed');
            visualizationPanel.classList.remove('fullscreen');

            // Update button text/icon
            if (mainToggleBtn) {
                const icon = mainToggleBtn.querySelector('i');
                if (icon) icon.className = 'fas fa-columns';
                mainToggleBtn.title = 'Hide Editor Panel';
            }

            // Resize editor after panel is shown
            setTimeout(() => {
                resizeEditor();
                console.log('📏 Editor resized');
            }, 300);
        } else {
            // Hide editor
            console.log('👁️‍🗨️ Hiding editor panel');
            editorPanel.classList.add('collapsed');
            visualizationPanel.classList.add('fullscreen');

            // Update button text/icon
            if (mainToggleBtn) {
                const icon = mainToggleBtn.querySelector('i');
                if (icon) icon.className = 'fas fa-expand-arrows-alt';
                mainToggleBtn.title = 'Show Editor Panel';
            }
        }

        // Force reflow to ensure classes are applied
        editorPanel.offsetHeight;
        visualizationPanel.offsetHeight;

        // Update connections after animation
        setTimeout(() => {
            this.updateConnections();
            console.log('🔗 Connections updated');
        }, 300);
    }


    setupModalEvents() {
        const nodeKindSelect = document.getElementById('node-kind');
        if (nodeKindSelect) {
            this.eventManager.addHandler(nodeKindSelect, 'change', () => {
                this.updateImageDropdown(nodeKindSelect.value);
            });
        }

        const addBtn = document.querySelector('.add-btn');
        if (addBtn) {
            this.eventManager.addHandler(addBtn, 'click', () => {
                this.modalManager.show('add-node-modal');
                // FIXED: Don't reset form immediately
                setTimeout(() => {
                    this.resetAddNodeForm();
                }, 100);
            });
        }

        document.querySelectorAll('.close-modal').forEach(closeBtn => {
            this.eventManager.addHandler(closeBtn, 'click', (e) => {
                const modal = e.target.closest('.modal');
                if (modal) {
                    this.modalManager.hide(modal.id);
                }
            });
        });

        const cancelNodeBtn = document.getElementById('cancel-node-btn');
        if (cancelNodeBtn) {
            this.eventManager.addHandler(cancelNodeBtn, 'click', () => {
                this.modalManager.hide('add-node-modal');
            });
        }

        const addNodeConfirmBtn = document.getElementById('add-node-confirm-btn');
        if (addNodeConfirmBtn) {
            this.eventManager.addHandler(addNodeConfirmBtn, 'click', () => {
                this.handleAddNode();
            });
        }

        const cancelConnectionBtn = document.getElementById('cancel-connection-btn');
        if (cancelConnectionBtn) {
            this.eventManager.addHandler(cancelConnectionBtn, 'click', () => {
                this.modalManager.hide('connection-modal');
                pendingConnection = null;
            });
        }

        const createConnectionBtn = document.getElementById('create-connection-btn');
        if (createConnectionBtn) {
            this.eventManager.addHandler(createConnectionBtn, 'click', () => {
                this.handleCreateConnection();
            });
        }

        const copyLogsBtn = document.getElementById('copy-logs-btn');
        const resultOkBtn = document.getElementById('result-ok-btn');

        if (copyLogsBtn) {
            this.eventManager.addHandler(copyLogsBtn, 'click', () => {
                this.copyLogsToClipboard();
            });
        }

        if (resultOkBtn) {
            this.eventManager.addHandler(resultOkBtn, 'click', () => {
                this.modalManager.hide('result-modal');
            });
        }
    }

    setupButtonEvents() {
        const buttonMappings = [
            { selector: '.copy-btn', handler: () => this.saveYaml() },
            { selector: '.validate-btn', handler: () => this.validateYaml() },
            { selector: '.fullscreen-btn', handler: () => this.toggleFullscreen() },
            { selector: '.simulate-btn', handler: () => this.simulateLab() },
            { selector: '#auto-layout-btn', handler: () => this.autoLayoutTopology() },
            { selector: '#reset-zoom-btn', handler: () => this.resetZoom() },
            { selector: '#center-topology-btn', handler: () => this.centerTopology() },
            { selector: '#export-topology-btn', handler: () => this.exportTopology() },
            { selector: '#zoom-in', handler: () => this.zoomIn() },
            { selector: '#zoom-out', handler: () => this.zoomOut() },
            { selector: '#help-btn', handler: () => this.showHelp() },
            { selector: '#settings-btn', handler: () => this.showSettings() }
        ];

        buttonMappings.forEach(({ selector, handler }) => {
            const element = document.querySelector(selector);
            if (element) {
                this.eventManager.addHandler(element, 'click', handler);
            }
        });
    }

    setupTopologyControls() {
        console.log('🗺️ Setting up topology controls...');

        const loadDcimTopologyBtn = document.getElementById('load-dcim-topology');
        const showDeviceConfigsBtn = document.getElementById('show-device-configs');
        const autoLayoutBtn = document.getElementById('auto-layout-btn');
        const resetZoomBtn = document.getElementById('reset-zoom-btn');
        const centerTopologyBtn = document.getElementById('center-topology-btn');
        const exportTopologyBtn = document.getElementById('export-topology-btn');
        const zoomInBtn = document.getElementById('zoom-in');
        const zoomOutBtn = document.getElementById('zoom-out');

        console.log('📍 Load DCIM button found:', !!loadDcimTopologyBtn);

        // ✅ FIXED: Load DCIM topology with debouncing and loading state
        if (loadDcimTopologyBtn) {
            // Remove any existing event listeners first
            loadDcimTopologyBtn.replaceWith(loadDcimTopologyBtn.cloneNode(true));
            const newLoadDcimBtn = document.getElementById('load-dcim-topology');

            this.eventManager.addHandler(newLoadDcimBtn, 'click', (e) => {
                e.preventDefault();
                e.stopPropagation();
                e.stopImmediatePropagation(); // ✅ Prevent any other handlers

                console.log('🔄 Load DCIM topology clicked');

                // ✅ Check if already loading
                if (this.isLoadingDCIM) {
                    console.log('⚠️ DCIM load already in progress, ignoring click');
                    return;
                }

                this.loadDCIMTopology();
            });
        }

        // Show device configurations
        if (showDeviceConfigsBtn) {
            this.eventManager.addHandler(showDeviceConfigsBtn, 'click', (e) => {
                e.preventDefault();
                e.stopPropagation();
                console.log('⚙️ Show device configs clicked');
                this.showDeviceConfigurations();
            });
        }

        // Auto layout topology
        if (autoLayoutBtn) {
            this.eventManager.addHandler(autoLayoutBtn, 'click', (e) => {
                e.preventDefault();
                e.stopPropagation();
                console.log('🎯 Auto layout clicked');
                this.autoLayoutTopology();
            });
        }

        // Reset zoom
        if (resetZoomBtn) {
            this.eventManager.addHandler(resetZoomBtn, 'click', (e) => {
                e.preventDefault();
                e.stopPropagation();
                console.log('🔍 Reset zoom clicked');
                this.resetZoom();
            });
        }

        // Center topology
        if (centerTopologyBtn) {
            this.eventManager.addHandler(centerTopologyBtn, 'click', (e) => {
                e.preventDefault();
                e.stopPropagation();
                console.log('🎯 Center topology clicked');
                this.centerTopology();
            });
        }

        // Export topology
        if (exportTopologyBtn) {
            this.eventManager.addHandler(exportTopologyBtn, 'click', (e) => {
                e.preventDefault();
                e.stopPropagation();
                console.log('📤 Export topology clicked');
                this.exportTopology();
            });
        }

        // Zoom in
        if (zoomInBtn) {
            this.eventManager.addHandler(zoomInBtn, 'click', (e) => {
                e.preventDefault();
                e.stopPropagation();
                console.log('🔍+ Zoom in clicked');
                this.zoomIn();
            });
        }

        // Zoom out
        if (zoomOutBtn) {
            this.eventManager.addHandler(zoomOutBtn, 'click', (e) => {
                e.preventDefault();
                e.stopPropagation();
                console.log('🔍- Zoom out clicked');
                this.zoomOut();
            });
        }
    }



    setupDeviceToggle() {
        // Setup radio button handlers for device source selection
        const sourceExisting = document.getElementById('source-existing');
        const sourceCustom = document.getElementById('source-custom');

        if (sourceExisting && sourceCustom) {
            this.eventManager.addHandler(sourceExisting, 'change', (event) => {
                if (event.target.checked) {
                    this.showExistingDeviceSection();
                }
            });

            this.eventManager.addHandler(sourceCustom, 'change', (event) => {
                if (event.target.checked) {
                    this.showCustomDeviceSection();
                }
            });
        }

        // Setup DCIM device selection handler
        const dcimDeviceSelect = document.getElementById('dcim-device');
        if (dcimDeviceSelect) {
            this.eventManager.addHandler(dcimDeviceSelect, 'change', (event) => {
                if (event.target.value) {
                    try {
                        const device = JSON.parse(event.target.value);
                        this.populateDeviceFields(device);
                        this.showDevicePreview(device);
                        this.autoPopulateNodeName(device.name);
                    } catch (e) {
                        console.error('❌ Error parsing device data:', e);
                        this.hideDevicePreview();
                        this.clearNodeNameAutoFill();
                    }
                } else {
                    this.hideDevicePreview();
                    this.clearNodeNameAutoFill();
                }
            });
        }

        // Setup reset node name button
        const resetNodeNameBtn = document.getElementById('reset-node-name');
        if (resetNodeNameBtn) {
            this.eventManager.addHandler(resetNodeNameBtn, 'click', () => {
                this.resetNodeNameToDevice();
            });
        }

        // Setup node name input to track user changes
        const nodeNameInput = document.getElementById('node-name');
        if (nodeNameInput) {
            this.eventManager.addHandler(nodeNameInput, 'input', () => {
                this.handleNodeNameChange();
            });
        }
    }

    showExistingDeviceSection() {
        const existingSection = document.getElementById('existing-device-section');
        const customSection = document.getElementById('custom-device-section');
        const previewSection = document.getElementById('device-info-preview');

        DOMUtils.showElement(existingSection);
        DOMUtils.hideElement(customSection);
        DOMUtils.hideElement(previewSection);

        // Load DCIM devices if not already loaded
        const dcimSelect = document.getElementById('dcim-device');
        if (dcimSelect && dcimSelect.options.length <= 1) {
            this.loadDcimDevices();
        }

        // Clear any custom device selections
        this.clearCustomDeviceFields();
        this.clearNodeNameAutoFill();
    }

    showCustomDeviceSection() {
        const existingSection = document.getElementById('existing-device-section');
        const customSection = document.getElementById('custom-device-section');
        const previewSection = document.getElementById('device-info-preview');

        DOMUtils.hideElement(existingSection);
        DOMUtils.showElement(customSection);
        DOMUtils.hideElement(previewSection);

        // Clear any existing device selections
        this.clearExistingDeviceFields();
        this.clearNodeNameAutoFill();
    }

    autoPopulateNodeName(deviceName) {
        const nodeNameInput = document.getElementById('node-name');
        const autoFillIndicator = document.getElementById('auto-fill-indicator');
        const resetBtn = document.getElementById('reset-node-name');

        if (nodeNameInput && deviceName) {
            // Store original device name for reset functionality
            nodeNameInput.dataset.originalDeviceName = deviceName;

            // Only auto-populate if field is empty or contains previous auto-fill
            if (!nodeNameInput.value || nodeNameInput.dataset.autoFilled === 'true') {
                nodeNameInput.value = deviceName;
                nodeNameInput.dataset.autoFilled = 'true';

                // Show auto-fill indicator and reset button
                if (autoFillIndicator) DOMUtils.showElement(autoFillIndicator);
                if (resetBtn) DOMUtils.showElement(resetBtn);

                // Add visual indicator to input
                nodeNameInput.style.background = '#f8fff8';
            }
        }
    }

    clearNodeNameAutoFill() {
        const nodeNameInput = document.getElementById('node-name');
        const autoFillIndicator = document.getElementById('auto-fill-indicator');
        const resetBtn = document.getElementById('reset-node-name');

        if (nodeNameInput) {
            nodeNameInput.dataset.autoFilled = 'false';
            nodeNameInput.dataset.originalDeviceName = '';
            nodeNameInput.style.background = '';
        }

        if (autoFillIndicator) DOMUtils.hideElement(autoFillIndicator);
        if (resetBtn) DOMUtils.hideElement(resetBtn);
    }

    resetNodeNameToDevice() {
        const nodeNameInput = document.getElementById('node-name');
        if (nodeNameInput && nodeNameInput.dataset.originalDeviceName) {
            nodeNameInput.value = nodeNameInput.dataset.originalDeviceName;
            nodeNameInput.dataset.autoFilled = 'true';
            nodeNameInput.style.background = '#f8fff8';
        }
    }

    handleNodeNameChange() {
        const nodeNameInput = document.getElementById('node-name');
        const autoFillIndicator = document.getElementById('auto-fill-indicator');

        if (nodeNameInput) {
            // If user is typing and it's different from auto-filled value, mark as user-modified
            if (nodeNameInput.dataset.autoFilled === 'true' &&
                nodeNameInput.value !== nodeNameInput.dataset.originalDeviceName) {
                nodeNameInput.dataset.autoFilled = 'false';
                nodeNameInput.style.background = '';
                if (autoFillIndicator) DOMUtils.hideElement(autoFillIndicator);
            }
        }
    }

    clearExistingDeviceFields() {
        const dcimSelect = document.getElementById('dcim-device');
        if (dcimSelect) {
            dcimSelect.value = '';
        }
        this.hideDevicePreview();
    }

    clearCustomDeviceFields() {
        const nodeKindSelect = document.getElementById('node-kind');
        const nodeImageSelect = document.getElementById('node-image');

        if (nodeKindSelect) nodeKindSelect.value = '';
        if (nodeImageSelect) nodeImageSelect.value = '';
    }

    loadInitialTopology() {
        // REMOVED: mgmt section - Containerlab will auto-assign management IPs
        const initialYaml = `name: digital_twin_topology
topology:
  nodes: {}
  links: []`;

        if (globalEditor) {
            globalEditor.setValue(initialYaml);
            globalEditor.clearSelection();
            globalEditor.focus();
            this.updateVisualization(initialYaml);
        }
    }

    loadDCIMTopology() {
        // ✅ Check if already loading
        if (this.isLoadingDCIM) {
            console.log('⚠️ DCIM loading already in progress');
            return;
        }

        console.log('📊 Loading DCIM topology...');

        // ✅ Set loading state
        this.isLoadingDCIM = true;

        // ✅ Disable the button
        const loadBtn = document.getElementById('load-dcim-topology');
        if (loadBtn) {
            loadBtn.disabled = true;
            loadBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Loading...';
        }

        StatusManager.resetProgress();
        StatusManager.showProgress('Loading DCIM Topology', 'Discovering devices and connections from Nautobot...');

        let progress = 0;
        const progressMessages = [
            'Connecting to Nautobot database...',
            'Retrieving device information...',
            'Discovering cable connections...',
            'Processing interface data...',
            'Building topology structure...',
            'Finalizing data...'
        ];
        let messageIndex = 0;

        // Progress simulation for DCIM loading
        const progressInterval = setInterval(() => {
            const increment = Math.random() * 10 + 5;
            progress = Math.min(progress + increment, 85);

            const newMessageIndex = Math.floor((progress / 85) * (progressMessages.length - 1));
            if (newMessageIndex !== messageIndex && newMessageIndex < progressMessages.length) {
                messageIndex = newMessageIndex;
            }

            StatusManager.updateProgress(progress, progressMessages[messageIndex]);
        }, 600);

        fetch('/plugins/digital-twin/discover-topology/', {
            method: 'GET',
            headers: {
                'X-CSRFToken': getCookie('csrftoken'),
                'Accept': 'application/json'
            }
        })
            .then(response => {
                console.log('📡 DCIM API response received, status:', response.status);

                if (!response.ok) {
                    throw new Error(`HTTP ${response.status}: ${response.statusText}`);
                }
                return response.json();
            })
            .then(data => {
                console.log('✅ DCIM data loaded successfully');

                clearInterval(progressInterval);
                StatusManager.updateProgress(100, 'Topology loaded successfully!');

                setTimeout(() => {
                    StatusManager.hideProgress();

                    if (data.nodes && Object.keys(data.nodes).length > 0) {
                        currentTopologyData = data;
                        this.generateYAMLFromTopology(data);

                        const nodeCount = Object.keys(data.nodes).length;
                        const connectionCount = data.connections.length;
                        const locationCount = Object.keys(data.locations).length;
                        StatusManager.updateStatus(nodeCount, connectionCount, locationCount, 'DCIM Loaded');

                        this.showResultModal(
                            true,
                            `Successfully loaded ${nodeCount} devices and ${connectionCount} connections from ${locationCount} locations`,
                            null
                        );
                    } else {
                        this.showResultModal(
                            false,
                            'No devices found in DCIM or devices lack required Containerlab configuration',
                            null
                        );
                    }
                }, 1000);
            })
            .catch(error => {
                console.error('❌ DCIM loading failed:', error);

                clearInterval(progressInterval);
                StatusManager.setProgressError('Failed to load DCIM data');

                setTimeout(() => {
                    StatusManager.hideProgress();
                    this.showResultModal(
                        false,
                        `Failed to load DCIM topology: ${error.message}`,
                        null
                    );
                }, 2000);
            })
            .finally(() => {
                // ✅ Reset loading state
                this.isLoadingDCIM = false;

                // ✅ Re-enable the button
                const loadBtn = document.getElementById('load-dcim-topology');
                if (loadBtn) {
                    loadBtn.disabled = false;
                    loadBtn.innerHTML = '<i class="fas fa-database"></i> Load DCIM';
                }

                console.log('🔄 DCIM loading process completed');
            });
    }

    generateYAMLFromTopology(topologyData) {
        const yaml = YAMLOperations.generateFromTopologyData(topologyData);
        globalEditor.setValue(yaml);
        globalEditor.clearSelection();
        this.updateVisualization(yaml);

        // Auto-check for existing configurations after topology is generated
        if (window.deviceConfigurationManager) {
            setTimeout(() => window.deviceConfigurationManager.autoCheckAndUpdateYamlConfigs(), 2000);
        }
    }





    forceConnectionUpdate() {
        console.log('🔄 Force updating connections with current node positions');

        // Store current node positions first
        this.storeNodePositions();

        // Clear and redraw connections
        const connectionsContainer = document.getElementById('connections-container');
        if (connectionsContainer) {
            DOMUtils.clearContainer(connectionsContainer);
        }

        // Redraw with current positions
        try {
            const yamlContent = globalEditor.getValue();
            const yamlObj = jsyaml.load(yamlContent);

            if (yamlObj && yamlObj.topology && yamlObj.topology.links) {
                this.renderConnections(yamlObj);
            }

            console.log('✅ Connections force updated successfully');
        } catch (e) {
            console.error("❌ Error in force connection update:", e);
        }
    }



    showDeviceConfigurations() {
        if (!currentTopologyData) {
            alert('Please load DCIM topology first');
            return;
        }

        let configContent = '<h3>Device Configurations</h3>';
        Object.entries(currentTopologyData.nodes).forEach(([deviceName, deviceData]) => {
            configContent += `
                <div class="device-config-item" style="border:2px solid white">
                    <h4>${deviceName}</h4>
                    <p><strong>Type:</strong> ${deviceData.device_type}</p>
                    <p><strong>Platform:</strong> ${deviceData.platform}</p>
                    <p><strong>Location:</strong> ${deviceData.location}</p>
                    <p><strong>Interfaces:</strong> ${deviceData.interfaces.length}</p>
                    <p><strong>Containerlab Kind:</strong> ${deviceData.clab_kind}</p>
                </div>
            `;
        });

        const detailsContent = document.getElementById('device-details-content');
        if (detailsContent) {
            detailsContent.innerHTML = configContent;
            this.modalManager.show('device-details-modal');
        }
    }

    getConnectionCount() {
        try {
            const yamlContent = globalEditor.getValue();
            const yamlObj = jsyaml.load(yamlContent);
            return yamlObj.topology && yamlObj.topology.links ? yamlObj.topology.links.length : 0;
        } catch (e) {
            return 0;
        }
    }


    showDevicePreview(device) {
        console.log('🔍 Showing device preview for:', device?.name);

        const preview = document.getElementById('device-info-preview');
        if (!preview) {
            console.warn('Device info preview container not found');
            return;
        }

        if (!device) {
            DOMUtils.hideElement(preview);
            return;
        }

        // Update all preview elements with null checks - REMOVED: management IP display
        const elements = {
            'preview-device-name': device.name || 'Unknown Device',
            'preview-device-status': device.status || 'Active',
            'preview-device-model': device.model || 'Unknown',
            'preview-device-platform': device.platform || 'Unknown',
            'preview-device-location': device.location || 'Unknown',
            'preview-device-interfaces': `${device.interface_count || 0} interfaces${device.interface_types && device.interface_types.length > 0
                ? ` (${device.interface_types.slice(0, 3).join(', ')})`
                : ''
                }`
        };
        // REMOVED: 'preview-device-ip' - Management IP display removed

        // Update each element safely
        Object.entries(elements).forEach(([id, text]) => {
            const element = document.getElementById(id);
            if (element) {
                element.textContent = text;
            } else {
                console.warn(`Element with ID '${id}' not found`);
            }
        });

        // Update status color
        const statusElement = document.getElementById('preview-device-status');
        if (statusElement) {
            statusElement.className = `device-status-badge ${device.status === 'Active' ? 'active' : 'inactive'}`;
        }

        // Show potential connections if available
        const previewBody = document.querySelector('.device-card-body');
        if (previewBody && currentTopologyData && currentTopologyData.connections) {
            // Remove existing connections display
            const existingConnections = previewBody.querySelector('.connections-section');
            if (existingConnections) {
                existingConnections.remove();
            }

            const potentialConnections = currentTopologyData.connections.filter(conn =>
                conn.source_device === device.name || conn.target_device === device.name
            );

            if (potentialConnections.length > 0) {
                const connectionsHtml = potentialConnections.slice(0, 5).map(conn => `
                <div class="connection-preview">
                    <small>${conn.source_device}:${conn.source_interface} ↔ ${conn.target_device}:${conn.target_interface}</small>
                </div>
            `).join('');

                const connectionsSection = document.createElement('div');
                connectionsSection.className = 'connections-section';
                connectionsSection.innerHTML = `
                <div class="preview-row">
                    <span class="preview-label">Available Connections:</span>
                    <div class="connections-list">${connectionsHtml}</div>
                    ${potentialConnections.length > 5 ?
                        `<small class="text-muted">... and ${potentialConnections.length - 5} more</small>` :
                        ''
                    }
                </div>
            `;

                previewBody.appendChild(connectionsSection);
            }
        }

        // Show the preview
        DOMUtils.showElement(preview);
    }


    hideDevicePreview() {
        const preview = document.getElementById('device-info-preview');
        if (preview) {
            DOMUtils.hideElement(preview);
        }
    }

    // Reset form to initial state
    resetAddNodeForm() {
        console.log('🔄 Resetting add node form...');

        const nodeNameInput = document.getElementById('node-name');
        const nodeKindSelect = document.getElementById('node-kind');
        const nodeImageSelect = document.getElementById('node-image');
        const sourceExisting = document.getElementById('source-existing');
        const sourceCustom = document.getElementById('source-custom');

        // Reset form fields
        if (nodeNameInput) {
            nodeNameInput.value = '';
            nodeNameInput.style.background = '';
            nodeNameInput.dataset.autoFilled = 'false';
            nodeNameInput.dataset.originalDeviceName = '';
        }
        if (nodeKindSelect) nodeKindSelect.value = '';
        if (nodeImageSelect) nodeImageSelect.innerHTML = '<option value="">Select Image</option>';

        // Reset radio buttons to default (existing device)
        if (sourceExisting) sourceExisting.checked = true;
        if (sourceCustom) sourceCustom.checked = false;

        // Clear auto-fill indicators
        this.clearNodeNameAutoFill();

        // Clear device selections
        this.clearExistingDeviceFields();
        this.clearCustomDeviceFields();

        // Show existing device section by default
        this.showExistingDeviceSection();

        console.log('✅ Form reset complete');
    }

    updateImageDropdown(selectedKind, selectedImage = '') {
        const nodeImageSelect = document.getElementById('node-image');
        if (!nodeImageSelect) return;

        nodeImageSelect.innerHTML = '<option value="">Select Image</option>';

        if (selectedKind && DeviceConfig.deviceImages[selectedKind]) {
            DeviceConfig.deviceImages[selectedKind].forEach((image, index) => {
                const option = document.createElement('option');
                option.value = image;
                option.textContent = image;
                if (selectedImage && image === selectedImage) {
                    option.selected = true;
                } else if (!selectedImage && index === 0) {
                    option.selected = true;
                }
                nodeImageSelect.appendChild(option);
            });
        }
    }

    // REMOVED: validateIPAddress - Management IP validation no longer needed
    // Containerlab will handle IP assignment automatically

    async handleAddNode() {
        try {
            // Check which device source is selected
            const sourceExisting = document.getElementById('source-existing');
            const useExisting = sourceExisting ? sourceExisting.checked : false;

            const autoConnectCheckbox = document.getElementById('auto-discover-connections');
            const autoConnect = autoConnectCheckbox ? autoConnectCheckbox.checked : true;

            let nodeNameToConnect = null;
            let hasExistingConfig = false;

            if (useExisting) {
                const dcimDeviceSelect = document.getElementById('dcim-device');

                if (!dcimDeviceSelect || !dcimDeviceSelect.value) {
                    this.showResultModal(
                        false,
                        'Please select a DCIM device from the dropdown',
                        null
                    );
                    return;
                }

                try {
                    const deviceData = JSON.parse(dcimDeviceSelect.value);

                    if (!deviceData.name) {
                        throw new Error('Device data missing required "name" field');
                    }

                    if (!deviceData.suggested_kind) {
                        deviceData.suggested_kind = 'linux';
                    }

                    if (!deviceData.suggested_image) {
                        deviceData.suggested_image = 'ubuntu:latest';
                    }

                    nodeNameToConnect = deviceData.name;

                    // Check for existing configuration before adding node
                    hasExistingConfig = await this.checkForExistingConfig(nodeNameToConnect);

                    const updatedYaml = this.nodeManager.addNodeFromDcim(deviceData);
                    this.updateVisualization(updatedYaml);

                    // Auto-integrate configuration if it exists
                    if (hasExistingConfig) {
                        await this.integrateStartupConfig(nodeNameToConnect);
                    }

                } catch (parseError) {
                    console.error('❌ Error parsing device data:', parseError);
                    this.showResultModal(
                        false,
                        `Invalid device data format. Please try selecting the device again.\n\nError: ${parseError.message}`,
                        null
                    );
                    return;
                }

            } else {
                // Manual node creation
                const nodeNameInput = document.getElementById('node-name');
                const nodeKindSelect = document.getElementById('node-kind');
                const nodeImageSelect = document.getElementById('node-image');

                const nodeName = nodeNameInput?.value.trim() || '';
                const nodeKind = nodeKindSelect?.value || '';
                const nodeImage = nodeImageSelect?.value || '';

                if (!nodeName || !nodeKind || !nodeImage) {
                    this.showResultModal(
                        false,
                        'Please fill in Name, Device Type, and Container Image',
                        null
                    );
                    return;
                }

                nodeNameToConnect = nodeName;

                // Check for existing configuration before adding node
                hasExistingConfig = await this.checkForExistingConfig(nodeNameToConnect);

                const nodeConfig = {
                    kind: nodeKind,
                    image: nodeImage
                };

                const updatedYaml = this.nodeManager.addNode(nodeName, nodeConfig);
                this.updateVisualization(updatedYaml);

                // Auto-integrate configuration if it exists
                if (hasExistingConfig) {
                    await this.integrateStartupConfig(nodeNameToConnect);
                }
            }

            // Show success message with config status
            let successMessage = `Node "${nodeNameToConnect}" added successfully.`;
            if (hasExistingConfig) {
                successMessage += `\n✅ Existing configuration automatically integrated with startup-config.`;
            }

            // Auto-connect logic
            if (autoConnect && nodeNameToConnect) {
                setTimeout(() => {
                    this.autoConnectNewNode(nodeNameToConnect);
                }, 500);
            } else if (nodeNameToConnect) {
                this.showResultModal(
                    true,
                    successMessage,
                    null
                );
            }

            this.modalManager.hide('add-node-modal');
            console.log('✅ Node added successfully:', nodeNameToConnect, hasExistingConfig ? 'with existing config' : 'without config');

        } catch (e) {
            console.error("❌ Error adding node:", e);
            this.showResultModal(
                false,
                `Error adding node: ${e.message}`,
                null
            );
        }
    }

    async checkForExistingConfig(deviceName) {
        try {
            const serverSelector = document.getElementById('server-selector');
            const serverId = serverSelector ? serverSelector.value : 'local';

            const response = await fetch(`/plugins/digital-twin/get-device-config-live/${deviceName}/?server_id=${serverId}`, {
                method: 'GET',
                headers: {
                    'X-CSRFToken': getCookie('csrftoken')
                }
            });

            if (response.ok) {
                const result = await response.json();
                return result.status === 'success' && result.has_config && result.configuration && result.configuration.trim();
            }
            return false;
        } catch (error) {
            console.warn(`⚠️ Could not check existing config for ${deviceName}:`, error);
            return false;
        }
    }

    async integrateStartupConfig(deviceName) {
        try {
            if (!globalEditor) {
                console.warn('⚠️ Global editor not available for startup-config integration');
                return;
            }

            const yamlContent = globalEditor.getValue();
            if (!yamlContent.trim()) {
                console.warn('⚠️ No YAML content available for startup-config integration');
                return;
            }

            // Parse the YAML
            const yamlObj = jsyaml.load(yamlContent);

            if (!yamlObj || !yamlObj.topology || !yamlObj.topology.nodes || !yamlObj.topology.nodes[deviceName]) {
                console.warn(`⚠️ Device ${deviceName} not found in YAML topology for startup-config integration`);
                return;
            }

            // Add startup-config to the device
            const configFilename = `${deviceName}.cfg`;
            yamlObj.topology.nodes[deviceName]['startup-config'] = configFilename;

            // Update the editor with the modified YAML
            const updatedYaml = jsyaml.dump(yamlObj, {
                indent: 2,
                lineWidth: -1,
                noRefs: true,
                sortKeys: false
            });

            globalEditor.setValue(updatedYaml);
            globalEditor.clearSelection();

            console.log(`✅ Auto-integrated startup-config for device: ${deviceName} -> ${configFilename}`);

        } catch (error) {
            console.error('❌ Error integrating startup-config:', error);
        }
    }



    handleCreateConnection() {
        const sourceInterfaceInput = document.getElementById('source-interface');
        const targetInterfaceInput = document.getElementById('target-interface');

        const sourceInterface = sourceInterfaceInput?.value.trim() || '';
        const targetInterface = targetInterfaceInput?.value.trim() || '';

        if (!sourceInterface || !targetInterface) {
            this.showResultModal(
                false,
                'Please specify both interfaces',
                null
            );
            return;
        }

        if (pendingConnection) {
            try {
                const updatedYaml = this.connectionManager.createConnection(
                    pendingConnection.source,
                    pendingConnection.target,
                    sourceInterface,
                    targetInterface
                );
                this.updateVisualization(updatedYaml);
                this.modalManager.hide('connection-modal');
                pendingConnection = null;

                this.showResultModal(
                    true,
                    `Connection created successfully between ${pendingConnection.source} and ${pendingConnection.target}`,
                    null
                );
            } catch (e) {
                console.error("Error creating connection:", e);
                this.showResultModal(
                    false,
                    `Error creating connection: ${e.message}`,
                    null
                );
            }
        }
    }

    showConnectionModal(sourceName, targetName) {
        const sourceNodeInput = document.getElementById('source-node');
        const targetNodeInput = document.getElementById('target-node');
        const sourceInterfaceInput = document.getElementById('source-interface');
        const targetInterfaceInput = document.getElementById('target-interface');

        if (sourceNodeInput) sourceNodeInput.value = sourceName;
        if (targetNodeInput) targetNodeInput.value = targetName;
        if (sourceInterfaceInput) sourceInterfaceInput.value = 'eth0';
        if (targetInterfaceInput) targetInterfaceInput.value = 'eth0';

        pendingConnection = { source: sourceName, target: targetName };
        this.modalManager.show('connection-modal');
    }

    loadDcimDevices() {
        const select = document.getElementById('dcim-device');
        if (!select) return;

        console.log('🔄 Loading DCIM devices...');

        // Store current selection to preserve it
        const currentSelection = select.value;

        select.innerHTML = '<option value="">Loading devices...</option>';

        fetch('/plugins/digital-twin/devices/', {
            method: 'GET',
            headers: {
                'X-CSRFToken': getCookie('csrftoken'),
                'Accept': 'application/json'
            }
        })
            .then(response => {
                if (!response.ok) {
                    throw new Error(`HTTP ${response.status}: ${response.statusText}`);
                }
                return response.json();
            })
            .then(data => {
                if (data.success && data.devices) {
                    // Clear and rebuild dropdown
                    select.innerHTML = '<option value="">Choose from inventory...</option>';

                    // Store connection data WITHOUT triggering other events
                    if (data.connections && !currentTopologyData) {
                        currentTopologyData = {
                            connections: data.connections,
                            nodes: {}
                        };

                        // Build nodes map quietly - REMOVED: mgmt_ip assignment
                        data.devices.forEach(device => {
                            currentTopologyData.nodes[device.name] = {
                                name: device.name,
                                location: device.location,
                                platform: device.platform,
                                clab_kind: device.suggested_kind,
                                clab_image: device.suggested_image
                                // REMOVED: mgmt_ip - Containerlab will auto-assign
                            };
                        });
                    }

                    // Add device options with proper JSON formatting
                    data.devices.forEach(device => {
                        const option = document.createElement('option');

                        // REMOVED: mgmt_ip from device data - Containerlab will auto-assign
                        const deviceData = {
                            name: device.name || '',
                            model: device.model || 'Unknown',
                            platform: device.platform || 'Unknown',
                            location: device.location || 'Unknown',
                            suggested_kind: device.suggested_kind || 'linux',
                            suggested_image: device.suggested_image || 'ubuntu:latest',
                            status: device.status || 'Active',
                            has_custom_fields: device.has_custom_fields || false,
                            interface_count: device.interface_count || 0,
                            interface_types: device.interface_types || [],
                            connections: device.connections || []
                        };

                        option.value = JSON.stringify(deviceData);

                        const customFieldIndicator = deviceData.has_custom_fields ? '✓' : '○';
                        const connectionIndicator = deviceData.connections.length > 0 ? `🔗${deviceData.connections.length}` : '';
                        option.textContent = `${customFieldIndicator} ${deviceData.name} (${deviceData.model}) - ${deviceData.location} ${connectionIndicator}`;

                        select.appendChild(option);
                    });

                    // Restore selection if it still exists
                    if (currentSelection) {
                        const options = Array.from(select.options);
                        const matchingOption = options.find(opt => {
                            if (opt.value) {
                                try {
                                    const optionData = JSON.parse(opt.value);
                                    return optionData.name === currentSelection || opt.value === currentSelection;
                                } catch (e) {
                                    return false;
                                }
                            }
                            return false;
                        });

                        if (matchingOption) {
                            select.value = matchingOption.value;
                            const changeEvent = new Event('change', { bubbles: true });
                            select.dispatchEvent(changeEvent);
                        }
                    }

                    console.log(`✅ Loaded ${data.devices.length} devices`);
                } else {
                    select.innerHTML = '<option value="">No devices found</option>';
                    this.showResultModal(
                        false,
                        'No devices found in Nautobot. Please ensure devices are configured with proper custom fields.',
                        null
                    );
                }
            })
            .catch(error => {
                console.error('❌ Error loading DCIM devices:', error);
                select.innerHTML = '<option value="">Error loading devices</option>';
                this.showResultModal(
                    false,
                    `Failed to load devices from Nautobot: ${error.message}`,
                    null
                );
            });
    }


    populateDeviceDropdown(devices) {
        console.log('📋 Populating device dropdown with', devices.length, 'devices');

        const deviceSelect = document.getElementById('dcim-device');

        if (!deviceSelect) {
            console.error('❌ Device select element not found');
            return;
        }

        // Clear existing options
        deviceSelect.innerHTML = '<option value="">Select a device...</option>';

        // Add device options
        devices.forEach(device => {
            const option = document.createElement('option');
            option.value = device.name;
            option.textContent = `${device.name} (${device.model})`;
            option.dataset.deviceData = JSON.stringify(device);
            deviceSelect.appendChild(option);
        });

        // Add change event listener for device preview
        deviceSelect.addEventListener('change', (event) => {
            const selectedOption = event.target.selectedOptions[0];

            if (selectedOption && selectedOption.dataset.deviceData) {
                try {
                    const deviceData = JSON.parse(selectedOption.dataset.deviceData);
                    // FIXED: Only pass device data, not the container
                    this.showDevicePreview(deviceData);
                } catch (error) {
                    console.error('❌ Error parsing device data:', error);
                    // Use result modal instead of silent failure
                    this.showResultModal(
                        false,
                        `Error loading device preview: ${error.message}`,
                        null
                    );
                }
            } else {
                // Clear preview by calling with null
                this.showDevicePreview(null);
            }
        });

        console.log('✅ Device dropdown populated successfully');
    }



    populateDeviceFields(device) {
        const nodeNameInput = document.getElementById('node-name');
        const nodeKindSelect = document.getElementById('node-kind');
        // REMOVED: nodeMgmtIpInput - Management IP input removed

        if (nodeNameInput) nodeNameInput.value = device.name;
        if (nodeKindSelect) nodeKindSelect.value = device.suggested_kind;
        this.updateImageDropdown(device.suggested_kind, device.suggested_image);

        // REMOVED: Management IP population - Containerlab will auto-assign
    }

    updateVisualization(yamlContent) {
        try {
            const yamlObj = jsyaml.load(yamlContent);
            const gridContainer = document.getElementById('grid-container');
            const connectionsContainer = document.getElementById('connections-container');

            if (!gridContainer || !connectionsContainer) return;

            // Store current positions before clearing
            this.storeNodePositions();

            DOMUtils.clearContainer(gridContainer);
            DOMUtils.clearContainer(connectionsContainer);

            if (yamlObj && yamlObj.topology && yamlObj.topology.nodes) {
                this.renderNodes(yamlObj, gridContainer);

                // Delay connection rendering to ensure nodes are positioned
                setTimeout(() => {
                    this.renderConnections(yamlObj);
                    this.restoreNodePositions();
                    this.setupInteractions();
                }, 100);
            }
        } catch (e) {
            console.error("Error updating visualization:", e);
            this.showResultModal(
                false,
                `Error updating topology visualization: ${e.message}`,
                null
            );
        }
    }

    storeNodePositions() {
        const nodes = document.querySelectorAll('.node');
        nodes.forEach(node => {
            const nodeName = node.getAttribute('data-name');
            if (nodeName) {
                const rect = node.getBoundingClientRect();
                const container = document.getElementById('grid-container');
                if (container) {
                    const containerRect = container.getBoundingClientRect();
                    const currentPosition = nodePositions.get(nodeName) || {};

                    // Store both current position and original position
                    nodePositions.set(nodeName, {
                        x: rect.left - containerRect.left,
                        y: rect.top - containerRect.top,
                        dragX: parseFloat(node.getAttribute('data-x')) || 0,
                        dragY: parseFloat(node.getAttribute('data-y')) || 0,
                        // Store original position if not already stored
                        originalX: currentPosition.originalX !== undefined ? currentPosition.originalX : parseFloat(node.style.left),
                        originalY: currentPosition.originalY !== undefined ? currentPosition.originalY : parseFloat(node.style.top)
                    });
                }
            }
        });
    }

    restoreNodePositions() {
        const nodes = document.querySelectorAll('.node');
        nodes.forEach(node => {
            const nodeName = node.getAttribute('data-name');
            const storedPosition = nodePositions.get(nodeName);

            if (storedPosition) {
                // Apply stored drag offsets
                node.style.transform = `translate(${storedPosition.dragX}px, ${storedPosition.dragY}px)`;
                node.setAttribute('data-x', storedPosition.dragX);
                node.setAttribute('data-y', storedPosition.dragY);
            }
        });

        // Update connections after position restoration
        setTimeout(() => this.updateConnections(), 100);
    }

    renderNodes(yamlObj, gridContainer) {
        const nodes = yamlObj.topology.nodes;
        const nodeElements = {};

        let nodesByLocation = {};
        if (currentTopologyData && currentTopologyData.locations) {
            nodesByLocation = currentTopologyData.locations;
        } else {
            nodesByLocation = { 'Default': Object.keys(nodes) };
        }

        let yOffset = 50;
        const locationSpacing = 200;

        Object.entries(nodesByLocation).forEach(([locationName, deviceNames]) => {
            if (Object.keys(nodesByLocation).length > 1) {
                const locationHeader = document.createElement('div');
                locationHeader.className = 'location-header';
                locationHeader.textContent = locationName;
                locationHeader.style.cssText = `
                    position: absolute;
                    left: 20px;
                    top: ${yOffset}px;
                    font-weight: bold;
                    color: #e0e0e0;
                    background: rgba(0,0,0,0.5);
                    padding: 5px 15px;
                    border-radius: 5px;
                    border-left: 4px solid #2fe5bf;
                    z-index: 0;
                `;
                gridContainer.appendChild(locationHeader);
                yOffset += 40;
            }

            let xOffset = 50;
            deviceNames.forEach(deviceName => {
                if (nodes[deviceName]) {
                    const nodeEl = this.createDeviceNode(deviceName, nodes[deviceName], xOffset, yOffset);
                    gridContainer.appendChild(nodeEl);
                    nodeElements[deviceName] = nodeEl;
                    xOffset += 180;

                    if (xOffset > 700) {
                        xOffset = 50;
                        yOffset += 120;
                    }
                }
            });

            yOffset += locationSpacing;
        });

        this.nodeElements = nodeElements;
    }

    createDeviceNode(deviceName, deviceData, x, y) {
        const node = document.createElement('div');
        node.className = 'node';
        node.id = `node-${deviceName}`;
        node.setAttribute('data-name', deviceName);
        node.setAttribute('data-kind', deviceData.kind || 'unknown');

        node.style.cssText = `
        position: absolute;
        left: ${x}px;
        top: ${y}px;
        width: 140px;
        height: 100px;
        border: 2px solid ${getDeviceColor(deviceData.kind)};
        border-radius: 8px;
        background: linear-gradient(135deg, #2c3e50 0%, #34495e 100%);
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        cursor: move;
        box-shadow: 0 4px 8px rgba(0,0,0,0.3);
        transition: all 0.3s ease;
        z-index: 10;
    `;

        const nodeIcon = getNodeIcon(deviceData.kind);

        node.innerHTML = `
        <i class="${nodeIcon}" style="font-size: 24px; color: ${getDeviceColor(deviceData.kind)}; margin-bottom: 8px;"></i>
        <div class="node-label" style="font-size: 12px; font-weight: bold; color: #ecf0f1; text-align: center; margin-bottom: 4px;">${deviceName}</div>
        <div class="node-kind" style="font-size: 10px; color: #bdc3c7; text-align: center;">${deviceData.kind || 'unknown'}</div>
        <div class="connection-handle" data-node="${deviceName}" style="
            position: absolute;
            top: 50%;
            right: -8px;
            width: 16px;
            height: 16px;
            background: #2fe5bf;
            border-radius: 50%;
            cursor: crosshair;
            border: 2px solid #fff;
            z-index: 20;
            transform: translateY(-50%);
        "></div>
    `;

        node.addEventListener('mouseenter', () => {
            if (!this.dragState.get(deviceName)) {
                node.style.transform = (node.style.transform || '') + ' translateY(-2px)';
                node.style.boxShadow = '0 6px 12px rgba(0,0,0,0.4)';
            }
        });

        node.addEventListener('mouseleave', () => {
            if (!this.dragState.get(deviceName)) {
                const currentTransform = node.style.transform.replace(' translateY(-2px)', '');
                node.style.transform = currentTransform;
                node.style.boxShadow = '0 4px 8px rgba(0,0,0,0.3)';
            }
        });

        node.addEventListener('dblclick', () => {
            this.showDeviceDetails(deviceName, deviceData);
        });

        return node;
    }


    showDeviceDetails(deviceName, deviceData) {
        // Set device name in modal header
        const deviceNameElement = document.getElementById('device-details-name');
        if (deviceNameElement) {
            deviceNameElement.textContent = deviceName;
        }

        // Populate Information tab content
        this.populateDeviceInfoTab(deviceName, deviceData);

        // Initialize configuration management for this device
        if (!this.deviceConfigManager) {
            this.deviceConfigManager = new DeviceConfigurationManager();
        }
        this.deviceConfigManager.initializeForDevice(deviceName, deviceData);

        // Setup tab switching functionality
        this.setupDeviceDetailsTabs();

        // Show the modal
        this.modalManager.show('device-details-modal');
    }

    populateDeviceInfoTab(deviceName, deviceData) {
        let content = `
            <div class="device-info-container">
                <!-- Device Header Section -->
                <div class="device-info-header">
                    <div class="device-info-title">
                        <div class="device-icon">
                            <i class="fas fa-server"></i>
                        </div>
                        <div class="device-title-content">
                            <h3 class="device-name">${deviceName}</h3>
                            <div class="device-meta">
                                <span class="device-kind-badge">${deviceData.kind}</span>
                                <span class="device-status-badge online">
                                    <i class="fas fa-circle"></i> Online
                                </span>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Device Information Grid -->
                <div class="device-info-sections">
                    <!-- Basic Information Section -->
                    <div class="info-section">
                        <div class="section-header">
                            <i class="fas fa-info-circle"></i>
                            <h4>Basic Information</h4>
                        </div>
                        <div class="info-grid">
                            <div class="info-item">
                                <div class="info-label">
                                    <i class="fas fa-docker"></i>
                                    Container Image
                                </div>
                                <div class="info-value">${deviceData.image || 'Not specified'}</div>
                            </div>
                            <div class="info-item">
                                <div class="info-label">
                                    <i class="fas fa-network-wired"></i>
                                    Device Type
                                </div>
                                <div class="info-value">${deviceData.kind}</div>
                            </div>
                        </div>
                    </div>
        `;

        // Add DCIM information if available
        if (currentTopologyData && currentTopologyData.nodes[deviceName]) {
            const dcimData = currentTopologyData.nodes[deviceName];
            content += `
                    <!-- DCIM Information Section -->
                    <div class="info-section">
                        <div class="section-header">
                            <i class="fas fa-database"></i>
                            <h4>DCIM Information</h4>
                        </div>
                        <div class="info-grid">
                            <div class="info-item">
                                <div class="info-label">
                                    <i class="fas fa-map-marker-alt"></i>
                                    Location
                                </div>
                                <div class="info-value">${dcimData.location || 'Not specified'}</div>
                            </div>
                            <div class="info-item">
                                <div class="info-label">
                                    <i class="fas fa-tag"></i>
                                    Device Type
                                </div>
                                <div class="info-value">${dcimData.device_type || 'Unknown'}</div>
                            </div>
                            <div class="info-item">
                                <div class="info-label">
                                    <i class="fas fa-microchip"></i>
                                    Platform
                                </div>
                                <div class="info-value">${dcimData.platform || 'Not specified'}</div>
                            </div>
                            <div class="info-item">
                                <div class="info-label">
                                    <i class="fas fa-ethernet"></i>
                                    Interfaces
                                </div>
                                <div class="info-value">
                                    <span class="interface-count">${dcimData.interfaces ? dcimData.interfaces.length : 0}</span>
                                    <span class="interface-label">ports</span>
                                </div>
                            </div>
                        </div>
                    </div>
            `;
        }


        const detailsContent = document.getElementById('device-details-content');
        if (detailsContent) {
            detailsContent.innerHTML = content;

            // Update connection count
            this.updateDeviceConnectionCount(deviceName);
        }
    }

    updateDeviceConnectionCount(deviceName) {
        if (this.currentYamlData && this.currentYamlData.topology && this.currentYamlData.topology.links) {
            const connectionCount = this.currentYamlData.topology.links.filter(link =>
                link.endpoints[0].node === deviceName || link.endpoints[1].node === deviceName
            ).length;

            const countElement = document.getElementById(`device-connection-count-${deviceName}`);
            if (countElement) {
                countElement.textContent = connectionCount;
                countElement.className = 'connection-count';
            }
        }
    }

    setupDeviceDetailsTabs() {
        const tabButtons = document.querySelectorAll('.device-details-tabs .tab-btn');
        const tabPanes = document.querySelectorAll('.tab-pane');
        const tabFooters = document.querySelectorAll('.tab-footer');

        tabButtons.forEach(button => {
            button.addEventListener('click', (e) => {
                const targetTab = e.currentTarget.getAttribute('data-tab');

                // Update active tab button
                tabButtons.forEach(btn => btn.classList.remove('active'));
                e.currentTarget.classList.add('active');

                // Update active tab pane
                tabPanes.forEach(pane => pane.classList.remove('active'));
                const targetPane = document.getElementById(`${targetTab}-tab`);
                if (targetPane) {
                    targetPane.classList.add('active');
                }

                // Update visible footer
                tabFooters.forEach(footer => footer.style.display = 'none');
                const targetFooter = document.getElementById(`${targetTab}-tab-footer`);
                if (targetFooter) {
                    targetFooter.style.display = 'flex';
                }
            });
        });
    }

    renderConnections(yamlObj) {
        if (!yamlObj.topology.links) return;

        const analyzedConnections = this.analyzeConnections(yamlObj);

        analyzedConnections.forEach((connection) => {
            const sourceNodeEl = this.nodeElements[connection.sourceNode];
            const targetNodeEl = this.nodeElements[connection.targetNode];

            if (sourceNodeEl && targetNodeEl) {
                this.createConnectionLine(sourceNodeEl, targetNodeEl, connection);
            }
        });
    }

    createConnectionLine(sourceNode, targetNode, connectionData) {
        const connectionsContainer = document.getElementById('connections-container');
        if (!connectionsContainer) return;

        // Get node centers for edge-to-edge connections
        const sourceRect = sourceNode.getBoundingClientRect();
        const targetRect = targetNode.getBoundingClientRect();
        const containerRect = connectionsContainer.getBoundingClientRect();

        // Calculate node centers
        const sourceCenterX = sourceRect.left + sourceRect.width / 2 - containerRect.left;
        const sourceCenterY = sourceRect.top + sourceRect.height / 2 - containerRect.top;
        const targetCenterX = targetRect.left + targetRect.width / 2 - containerRect.left;
        const targetCenterY = targetRect.top + targetRect.height / 2 - containerRect.top;

        // Calculate edge points
        const angle = Math.atan2(targetCenterY - sourceCenterY, targetCenterX - sourceCenterX);

        // Node dimensions
        const nodeWidth = 140;
        const nodeHeight = 100;

        // Calculate edge intersection points
        const sourceEdgeX = sourceCenterX + Math.cos(angle) * (nodeWidth / 2);
        const sourceEdgeY = sourceCenterY + Math.sin(angle) * (nodeHeight / 2);
        const targetEdgeX = targetCenterX - Math.cos(angle) * (nodeWidth / 2);
        const targetEdgeY = targetCenterY - Math.sin(angle) * (nodeHeight / 2);

        // Apply offset for multiple connections
        const offset = connectionData.offset || 0;
        const perpAngle = angle + Math.PI / 2;
        const offsetSourceX = sourceEdgeX + Math.cos(perpAngle) * offset;
        const offsetSourceY = sourceEdgeY + Math.sin(perpAngle) * offset;
        const offsetTargetX = targetEdgeX + Math.cos(perpAngle) * offset;
        const offsetTargetY = targetEdgeY + Math.sin(perpAngle) * offset;

        const svgNS = "http://www.w3.org/2000/svg";
        const svg = document.createElementNS(svgNS, "svg");
        svg.setAttribute("class", "connection");
        svg.setAttribute("data-index", connectionData.index);
        svg.setAttribute("data-type", connectionData.type || 'single');
        svg.style.cssText = `
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        pointer-events: none;
        z-index: 1;
    `;

        const line = document.createElementNS(svgNS, "line");
        line.setAttribute("x1", offsetSourceX);
        line.setAttribute("y1", offsetSourceY);
        line.setAttribute("x2", offsetTargetX);
        line.setAttribute("y2", offsetTargetY);
        line.setAttribute("stroke", connectionData.color || "#2fe5bf");
        line.setAttribute("stroke-width", connectionData.type === 'bidirectional' ? "3" : "2");

        // Different line styles for different connection types
        if (connectionData.type === 'bidirectional') {
            line.setAttribute("stroke-dasharray", "8,4");
        } else if (connectionData.type === 'multiple') {
            line.setAttribute("stroke-dasharray", "5,3");
        } else {
            line.setAttribute("stroke-dasharray", "5,5");
        }

        svg.appendChild(line);

        // Add connection labels with improved positioning
        if (connectionData.sourceInterface && connectionData.targetInterface) {
            const midX = (offsetSourceX + offsetTargetX) / 2;
            const midY = (offsetSourceY + offsetTargetY) / 2;

            // Enhanced label positioning to avoid overlap
            const labelOffset = connectionData.type === 'bidirectional' ? 20 : 15;
            const labelAngle = connectionData.bidirectionalPair ? angle : angle + Math.PI / 2;
            const labelX = midX + Math.cos(labelAngle) * labelOffset;
            const labelY = midY + Math.sin(labelAngle) * labelOffset;

            // Connection type indicator
            let connectionIcon = '';
            if (connectionData.type === 'bidirectional') {
                connectionIcon = '⟷ ';
            } else if (connectionData.type === 'multiple') {
                connectionIcon = '≡ ';
            } else {
                connectionIcon = '↔ ';
            }

            const labelText = `${connectionIcon}${connectionData.sourceInterface}↔${connectionData.targetInterface}`;

            const text = document.createElementNS(svgNS, "text");
            text.setAttribute("x", labelX);
            text.setAttribute("y", labelY);
            text.setAttribute("text-anchor", "middle");
            text.setAttribute("fill", "#e0e0e0");
            text.setAttribute("font-size", "10");
            text.setAttribute("font-family", "monospace");
            text.setAttribute("font-weight", connectionData.type === 'bidirectional' ? "bold" : "normal");
            text.textContent = labelText;

            const textBg = document.createElementNS(svgNS, "rect");
            const textLength = labelText.length * 6;
            textBg.setAttribute("x", labelX - textLength / 2);
            textBg.setAttribute("y", labelY - 12);
            textBg.setAttribute("width", textLength);
            textBg.setAttribute("height", "18");
            textBg.setAttribute("fill", connectionData.type === 'bidirectional' ?
                "rgba(255, 107, 107, 0.9)" : "rgba(30, 36, 48, 0.9)");
            textBg.setAttribute("rx", "3");

            svg.appendChild(textBg);
            svg.appendChild(text);
        }

        connectionsContainer.appendChild(svg);
    }


    setupInteractions() {
        if (typeof interact !== 'undefined') {
            this.setupDraggable();
            this.setupConnectionHandles();
        }
    }

    setupDraggable() {
        interact('.node').draggable({
            inertia: true,
            modifiers: [
                interact.modifiers.restrictRect({
                    restriction: 'parent',
                    endOnly: true
                })
            ],
            autoScroll: true,
            listeners: {
                start: (event) => {
                    const nodeName = event.target.getAttribute('data-name');
                    this.dragState.set(nodeName, true);
                    event.target.style.cursor = 'grabbing';
                },
                move: this.dragMoveListener.bind(this),
                end: (event) => {
                    const nodeName = event.target.getAttribute('data-name');
                    this.dragState.set(nodeName, false);
                    event.target.style.cursor = 'grab';

                    // Store final position
                    const x = parseFloat(event.target.getAttribute('data-x')) || 0;
                    const y = parseFloat(event.target.getAttribute('data-y')) || 0;
                    nodePositions.set(nodeName, {
                        dragX: x,
                        dragY: y
                    });
                }
            }
        });
    }

    setupConnectionHandles() {
        let startNode = null;
        let tempLine = null;

        interact('.connection-handle').draggable({
            listeners: {
                start: (event) => {
                    startNode = event.target.closest('.node');
                    if (!startNode) return;

                    tempLine = document.createElement('div');
                    tempLine.className = 'temp-connection-line';
                    tempLine.style.cssText = `
                    position: absolute;
                    height: 3px;
                    background: linear-gradient(304deg, #572ac2, #4080f5);
                    transform-origin: left center;
                    pointer-events: none;
                    z-index: 1000;
                    border-radius: 2px;
                    box-shadow: 0 0 8px rgba(47, 229, 191, 0.5);
                `;
                    document.getElementById('connections-container').appendChild(tempLine);

                    // ✅ Start from edge center instead of bottom corner
                    const startRect = startNode.getBoundingClientRect();
                    const containerRect = document.getElementById('connections-container').getBoundingClientRect();
                    tempLine.style.left = `${startRect.left + startRect.width / 2 - containerRect.left}px`;
                    tempLine.style.top = `${startRect.top + startRect.height / 2 - containerRect.top}px`;
                },
                move: (event) => {
                    if (!tempLine || !startNode) return;

                    const startRect = startNode.getBoundingClientRect();
                    const containerRect = document.getElementById('connections-container').getBoundingClientRect();
                    const startX = startRect.left + startRect.width / 2 - containerRect.left;
                    const startY = startRect.top + startRect.height / 2 - containerRect.top;

                    const dx = event.clientX - containerRect.left - startX;
                    const dy = event.clientY - containerRect.top - startY;
                    const length = Math.sqrt(dx * dx + dy * dy);
                    const angle = Math.atan2(dy, dx) * 180 / Math.PI;

                    tempLine.style.width = `${length}px`;
                    tempLine.style.transform = `rotate(${angle}deg)`;
                },
                end: (event) => {
                    if (tempLine) {
                        tempLine.remove();
                        tempLine = null;
                    }

                    const elemBelow = document.elementFromPoint(event.clientX, event.clientY);
                    const targetNode = elemBelow ? elemBelow.closest('.node') : null;

                    if (targetNode && targetNode !== startNode) {
                        this.showConnectionModal(
                            startNode.getAttribute('data-name'),
                            targetNode.getAttribute('data-name')
                        );
                    }
                    startNode = null;
                }
            }
        });
    }


    dragMoveListener(event) {
        const target = event.target;
        const x = (parseFloat(target.getAttribute('data-x')) || 0) + event.dx;
        const y = (parseFloat(target.getAttribute('data-y')) || 0) + event.dy;

        target.style.transform = `translate(${x}px, ${y}px)`;
        target.setAttribute('data-x', x);
        target.setAttribute('data-y', y);

        // Update connections during drag
        this.updateConnections();
    }

    updateConnections() {
        try {
            const yamlContent = globalEditor.getValue();
            const yamlObj = jsyaml.load(yamlContent);

            if (!yamlObj.topology || !yamlObj.topology.links) return;

            const connectionsContainer = document.getElementById('connections-container');
            if (!connectionsContainer) return;

            DOMUtils.clearContainer(connectionsContainer);

            // Use the enhanced rendering with connection analysis
            this.renderConnections(yamlObj);

            console.log('🔗 Connections updated with enhanced rendering');
        } catch (e) {
            console.error("Error updating connections:", e);
        }
    }


    updateStatusFromYAML(yamlContent) {
        try {
            const yamlObj = jsyaml.load(yamlContent);
            const nodeCount = yamlObj.topology && yamlObj.topology.nodes ?
                Object.keys(yamlObj.topology.nodes).length : 0;
            const connectionCount = yamlObj.topology && yamlObj.topology.links ?
                yamlObj.topology.links.length : 0;

            const locationCount = currentTopologyData ?
                Object.keys(currentTopologyData.locations || {}).length : 1;

            StatusManager.updateStatus(nodeCount, connectionCount, locationCount);
        } catch (e) {
            // Invalid YAML, don't update status
        }
    }

    // Layout Functions
    autoLayoutTopology() {
        const nodes = document.querySelectorAll('.node');
        if (nodes.length === 0) return;

        const gridContainer = document.getElementById('grid-container');
        if (!gridContainer) return;

        const containerWidth = gridContainer.offsetWidth - 200;
        const containerHeight = gridContainer.offsetHeight - 200;
        const cols = Math.ceil(Math.sqrt(nodes.length));
        const cellWidth = containerWidth / cols;
        const cellHeight = containerHeight / Math.ceil(nodes.length / cols);

        nodes.forEach((node, index) => {
            const col = index % cols;
            const row = Math.floor(index / cols);
            const newX = 100 + col * cellWidth;
            const newY = 100 + row * cellHeight;

            node.style.left = `${newX}px`;
            node.style.top = `${newY}px`;
            node.style.transition = 'all 0.5s ease';

            // Reset transform and store new position
            node.style.transform = 'translate(0px, 0px)';
            node.setAttribute('data-x', 0);
            node.setAttribute('data-y', 0);

            const nodeName = node.getAttribute('data-name');
            nodePositions.set(nodeName, { dragX: 0, dragY: 0 });
        });

        setTimeout(() => {
            this.updateConnections();
            nodes.forEach(node => {
                node.style.transition = '';
            });
        }, 500);
    }

    resetZoom() {
        const gridContainer = document.getElementById('grid-container');
        if (gridContainer) {
            gridContainer.style.transform = 'scale(1) translate(0, 0)';
        }
    }

    zoomIn() {
        const gridContainer = document.getElementById('grid-container');
        if (!gridContainer) return;

        const currentTransform = gridContainer.style.transform || 'scale(1)';
        const currentScale = parseFloat(currentTransform.match(/scale\(([^)]+)\)/)?.[1] || 1);
        const newScale = Math.min(currentScale * 1.2, 3);

        gridContainer.style.transform = currentTransform.replace(/scale\([^)]+\)/, `scale(${newScale})`);
    }

    zoomOut() {
        const gridContainer = document.getElementById('grid-container');
        if (!gridContainer) return;

        const currentTransform = gridContainer.style.transform || 'scale(1)';
        const currentScale = parseFloat(currentTransform.match(/scale\(([^)]+)\)/)?.[1] || 1);
        const newScale = Math.max(currentScale / 1.2, 0.3);

        gridContainer.style.transform = currentTransform.replace(/scale\([^)]+\)/, `scale(${newScale})`);
    }

    centerTopology() {
        const nodes = document.querySelectorAll('.node');
        if (nodes.length === 0) return;

        const gridContainer = document.getElementById('grid-container');
        if (!gridContainer) return;

        let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;

        nodes.forEach(node => {
            const rect = node.getBoundingClientRect();
            const containerRect = gridContainer.getBoundingClientRect();
            const x = rect.left - containerRect.left;
            const y = rect.top - containerRect.top;
            minX = Math.min(minX, x);
            minY = Math.min(minY, y);
            maxX = Math.max(maxX, x + node.offsetWidth);
            maxY = Math.max(maxY, y + node.offsetHeight);
        });

        const centerX = (minX + maxX) / 2;
        const centerY = (minY + maxY) / 2;
        const containerCenterX = gridContainer.offsetWidth / 2;
        const containerCenterY = gridContainer.offsetHeight / 2;
        const translateX = containerCenterX - centerX;
        const translateY = containerCenterY - centerY;

        gridContainer.style.transform = `translate(${translateX}px, ${translateY}px)`;
        gridContainer.style.transition = 'transform 0.5s ease';

        setTimeout(() => {
            gridContainer.style.transition = '';
        }, 500);
    }

    // Action Functions
    saveYaml() {
        if (!globalEditor) return;

        const yamlContent = globalEditor.getValue();
        fetch('/plugins/digital-twin/save-yaml/', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRFToken': getCookie('csrftoken')
            },
            body: JSON.stringify({ content: yamlContent })
        })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    this.showResultModal(true, 'YAML configuration saved successfully', null);
                } else {
                    this.showResultModal(false, `Save failed: ${data.error}`, null);
                }
            })
            .catch(error => {
                this.showResultModal(false, `Save error: ${error.message}`, null);
            });
    }

    validateYaml() {
        if (!globalEditor) return;

        try {
            const yamlContent = globalEditor.getValue();
            const yamlObj = jsyaml.load(yamlContent);

            let warnings = [];
            if (!yamlObj.topology || !yamlObj.topology.nodes || Object.keys(yamlObj.topology.nodes).length === 0) {
                warnings.push('No nodes defined in topology');
            }

            if (!yamlObj.name) {
                warnings.push('No lab name specified');
            }

            if (warnings.length > 0) {
                this.showResultModal(true, `YAML is valid but has warnings:\n• ${warnings.join('\n• ')}`, null);
            } else {
                this.showResultModal(true, 'YAML configuration is valid and ready for deployment', null);
            }
        } catch (e) {
            this.showResultModal(false, `YAML validation failed: ${e.message}`, null);
        }
    }

    toggleFullscreen() {
        const container = document.querySelector('.container');
        const btn = document.querySelector('.fullscreen-btn');
        if (!container || !btn) return;

        const icon = btn.querySelector('i');

        if (!document.fullscreenElement) {
            container.requestFullscreen().then(() => {
                if (icon) icon.className = 'fas fa-compress';
                resizeEditor();
            });
        } else {
            document.exitFullscreen().then(() => {
                if (icon) icon.className = 'fas fa-expand';
                resizeEditor();
            });
        }
    }

    async simulateLab() {
        if (this.isSimulating) {
            console.log('⚠️ Simulation already in progress, ignoring click');
            return;
        }

        try {
            this.isSimulating = true;
            const yamlContent = globalEditor.getValue().trim();

            if (!yamlContent) {
                this.showResultModal(false, 'No YAML configuration found. Please generate or paste a valid Containerlab topology.', null);
                return;
            }

            // Validate YAML
            const parseResult = YAMLOperations.parseYAML(yamlContent);
            if (!parseResult.success) {
                this.showResultModal(false, `Invalid YAML configuration: ${parseResult.error}`, null);
                return;
            }

            const yamlObj = parseResult.data;
            if (!yamlObj.topology || !yamlObj.topology.nodes || Object.keys(yamlObj.topology.nodes).length === 0) {
                this.showResultModal(false, 'No nodes found in topology. Cannot deploy an empty lab.', null);
                return;
            }

            const labName = yamlObj.name || `lab-${Date.now()}`;
            console.log('🚀 Starting lab simulation:', labName);

            // Show progress modal
            StatusManager.showProgress('Deploying Containerlab Topology', `Deploying "${labName}" to ${this.remoteLabManager.getSelectedServerInfo()?.name || 'selected server'}...`);
            StatusManager.updateProgress(5, 'Preparing deployment...');

            try {
                // Always use enhanced deployment with configuration integration
                console.log('🔧 Using unified enhanced deployment with configuration integration');
                StatusManager.updateProgress(10, 'Checking for device configurations...');

                // Use enhanced deployment with configuration integration (unified path)
                const result = await this.deployWithIntegratedConfigurations(
                    labName,
                    yamlContent,
                    (progress, message) => {
                        StatusManager.updateProgress(progress, message);
                    }
                );

                StatusManager.hideProgress();

                // Check for success and ensure no errors occurred
                if (result.success && !result.has_error) {
                    const serverInfo = this.remoteLabManager.getSelectedServerInfo();
                    const successTitle = result.attempts > 1
                        ? `🎉 Lab Deployed Successfully! (After ${result.attempts} attempts)`
                        : '🎉 Lab Deployed Successfully!';

                    let deploymentInfo = `
                                            <div class="deployment-success">
                                                <h4 class="success-title">${successTitle}</h4>
                                                <div class="deployment-details">
                                                    <div class="details-row">
                                                        <div class="details-label">Lab Name:</div>
                                                        <div class="details-value">${labName}</div>
                                                    </div>
                                                    <div class="details-row">
                                                        <div class="details-label">Server:</div>
                                                        <div class="details-value">${serverInfo?.name} (${serverInfo?.host})</div>
                                                    </div>
                                                    <div class="details-row">
                                                        <div class="details-label">Deployment ID:</div>
                                                        <div class="details-value">${result.deployment_id}</div>
                                                    </div>`;

                    // Add configuration information if available
                    if (result.configurations_applied !== undefined) {
                        deploymentInfo += `
                                                    <div class="details-row">
                                                        <div class="details-label">Device Configurations:</div>
                                                        <div class="details-value">${result.configurations_applied} configurations applied</div>
                                                    </div>`;
                    }

                    // Add retry information if there were multiple attempts
                    if (result.attempts > 1) {
                        deploymentInfo += `
                                                    <div class="details-row">
                                                        <div class="details-label">Deployment Attempts:</div>
                                                        <div class="details-value">${result.attempts} (resolved container conflicts)</div>
                                                    </div>`;
                    }

                    deploymentInfo += `
                                                    <div class="details-row">
                                                        <div class="details-label">Status:</div>
                                                        <div class="details-value">${result.message}</div>
                                                    </div>
                                                </div>
                                            </div>
                        `;

                    this.showResultModal(true, deploymentInfo, result.logs);
                    console.log('✅ Lab simulation completed successfully');
                } else {
                    // Handle error cases - check for has_error flag or success = false
                    const errorMessage = result.error || result.message || 'Unknown deployment error';
                    console.log('❌ Deployment failed or has errors:', errorMessage);

                    // Create enhanced error message with retry information
                    let enhancedMessage = errorMessage;
                    if (result.attempts && result.attempts > 1) {
                        enhancedMessage = `Deployment succeeded after ${result.attempts} attempts.\nInitial failure was resolved automatically.`;
                    }

                    // Create error object with logs for proper display
                    const error = new Error(enhancedMessage);
                    error.logs = result.logs;
                    error.attempts = result.attempts;
                    throw error;
                }

            } catch (deployError) {
                StatusManager.hideProgress();
                console.error('❌ Lab deployment failed:', deployError);

                // Create enhanced error message with retry information
                let errorTitle = 'Deployment Failed';
                let errorMessage = deployError.message;

                if (deployError.attempts && deployError.attempts > 1) {
                    errorTitle = `Deployment Failed After ${deployError.attempts} Attempts`;
                    errorMessage = `${deployError.message}\n\nThe system attempted to resolve container conflicts by retrying ${deployError.attempts} times, but the deployment ultimately failed.`;
                } else if (deployError.isContainerConflict) {
                    errorTitle = 'Container Conflict Error';
                    errorMessage = `${deployError.message}\n\nThis error typically occurs when containers from a previous deployment are still running. The system attempted to clean up automatically but was unsuccessful.`;
                }

                this.showResultModal(
                    false,
                    errorMessage,
                    deployError.logs || null,
                    errorTitle
                );
            }

        } catch (error) {
            StatusManager.hideProgress();
            console.error('❌ Lab simulation error:', error);
            this.showResultModal(false, `Simulation error: ${error.message}`, null);
        } finally {
            this.isSimulating = false;
        }
    }




    getProgressMessage(progress) {
        if (progress < 20) return 'Validating topology configuration...';
        if (progress < 40) return 'Preparing container images...';
        if (progress < 60) return 'Creating network topology...';
        if (progress < 80) return 'Starting containerlab deployment...';
        if (progress < 95) return 'Configuring network connections...';
        return 'Finalizing deployment...';
    }

    // Removed checkForSavedConfigurations - now using unified deployment path

    async deployWithIntegratedConfigurations(labName, yamlContent, progressCallback) {
        /**Deploy lab using unified enhanced deployment with configuration integration*/
        const maxRetries = 2;
        let currentAttempt = 1;
        let lastError = null;

        while (currentAttempt <= maxRetries) {
            try {
                const serverSelector = document.getElementById('server-selector');
                const serverId = serverSelector ? serverSelector.value : 'local';

                if (progressCallback) {
                    if (currentAttempt === 1) {
                        progressCallback(20, 'Preparing deployment with configuration integration...');
                    } else {
                        progressCallback(20, `Retrying deployment (attempt ${currentAttempt}/${maxRetries}) - resolving container conflicts...`);
                    }
                }

                // Use the unified deployment endpoint
                const response = await fetch('/plugins/digital-twin/deploy-with-configurations/', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRFToken': getCookie('csrftoken')
                    },
                    body: JSON.stringify({
                        server_id: serverId,
                        lab_name: labName,
                        yaml_content: yamlContent
                    })
                });

                if (!response.ok) {
                    throw new Error(`HTTP ${response.status}: ${response.statusText}`);
                }

                const result = await response.json();

                if (result.status === 'success') {
                    if (progressCallback) {
                        progressCallback(50, `Configurations integrated (${result.configurations_applied || 0} devices), starting deployment...`);
                    }

                    const deploymentResult = result.deployment_result;

                    // If we have a deployment_id, poll for status
                    if (deploymentResult && deploymentResult.deployment_id) {
                        const finalResult = await this.pollDeploymentStatus(
                            deploymentResult.deployment_id,
                            progressCallback
                        );

                        if (finalResult.success && !finalResult.has_error) {
                            return {
                                success: true,
                                message: result.message,
                                configurations_applied: result.configurations_applied,
                                deployment_result: deploymentResult,
                                deployment_id: deploymentResult.deployment_id,
                                logs: finalResult.logs,
                                has_error: false,
                                attempts: currentAttempt
                            };
                        } else {
                            // Enhanced deployment failed during execution
                            const error = new Error(finalResult.error || finalResult.message || 'Enhanced deployment failed during execution');
                            error.logs = finalResult.logs;
                            error.isContainerConflict = this.isContainerConflictError(finalResult.error || finalResult.message);
                            throw error;
                        }
                    } else {
                        // No deployment ID - return the result directly
                        if (progressCallback) {
                            progressCallback(100, 'Deployment completed!');
                        }

                        return {
                            success: !deploymentResult?.has_error,
                            message: result.message,
                            configurations_applied: result.configurations_applied,
                            deployment_result: deploymentResult,
                            logs: deploymentResult?.logs,
                            has_error: deploymentResult?.has_error || false,
                            attempts: currentAttempt
                        };
                    }
                } else {
                    const error = new Error(result.error || 'Enhanced deployment failed');
                    error.logs = result.logs;
                    error.isContainerConflict = this.isContainerConflictError(result.error);
                    throw error;
                }

            } catch (error) {
                console.error(`❌ Enhanced deployment failed (attempt ${currentAttempt}/${maxRetries}):`, error);
                lastError = error;

                // Check if this is a container conflict error and we can retry
                if (currentAttempt < maxRetries && this.isContainerConflictError(error.message)) {
                    console.log(`🔄 Container conflict detected, retrying in 3 seconds...`);
                    if (progressCallback) {
                        progressCallback(25, `Container conflict detected, preparing retry ${currentAttempt + 1}/${maxRetries}...`);
                    }

                    // Wait before retry
                    await new Promise(resolve => setTimeout(resolve, 3000));
                    currentAttempt++;
                    continue;
                } else {
                    // No more retries or non-retryable error
                    throw error;
                }
            }
        }

        // If we get here, all retries failed
        throw lastError || new Error('All deployment attempts failed');
    }

    isContainerConflictError(errorMessage) {
        if (!errorMessage) return false;
        const conflictKeywords = [
            'already in use',
            'container name',
            'already exist',
            'Conflict',
            'containers already exist'
        ];
        return conflictKeywords.some(keyword =>
            errorMessage.toLowerCase().includes(keyword.toLowerCase())
        );
    }


    async pollDeploymentStatus(deploymentId, progressCallback) {
        console.log('📊 Polling deployment status for:', deploymentId);
        let overallStatus = "";
        const maxAttempts = 12; // 10 minutes at 5-second intervals
        let attempts = 0;

        while (attempts < maxAttempts && overallStatus !== 'completed' && overallStatus !== 'failed') {
            try {
                // Create AbortController for 30-second timeout
                const controller = new AbortController();
                const timeoutId = setTimeout(() => controller.abort(), 30000);

                const response = await fetch(`/plugins/digital-twin/deployment-status/${deploymentId}/`, {
                    signal: controller.signal
                });
                
                clearTimeout(timeoutId);
                
                if (!response.ok) {
                    throw new Error(`Status check failed: ${response.status}`);
                }

                const status = await response.json();
                console.log('📊 Deployment status:', status);

                // Update progress if callback provided
                if (progressCallback && status.progress !== undefined) {
                    progressCallback(status.progress, status.message || 'Deployment in progress...');
                }

                // Check for completion (success or failure)
                if (status.status === 'completed') {
                    overallStatus = 'completed';
                    return {
                        success: !status.has_error,
                        message: status.message,
                        logs: status.logs,
                        has_error: status.has_error
                    };
                } else if (status.status === 'failed' || status.has_error) {
                    overallStatus = 'failed';
                    return {
                        success: false,
                        error: status.error || status.message,
                        message: status.message,
                        logs: status.logs,
                        has_error: true
                    };
                }

                // Continue polling for running status
                if (status.status === 'running' || status.status === 'accepted') {
                    overallStatus = 'running';
                    await new Promise(resolve => setTimeout(resolve, 5000)); // Wait 5 seconds
                    attempts++;
                    continue;
                }

                // Unknown status - assume failure
                return {
                    success: false,
                    error: `Unknown deployment status: ${status.status}`,
                    message: status.message,
                    logs: status.logs,
                    has_error: true
                };

            } catch (error) {
                console.error('❌ Status polling error:', error);
                attempts++;

                if (attempts >= maxAttempts) {
                    return {
                        success: false,
                        error: `Status polling failed after ${maxAttempts} attempts: ${error.message}`
                    };
                }

                // Wait before retrying
                await new Promise(resolve => setTimeout(resolve, 5000));
            }
        }

        // Timeout
        return {
            success: false,
            error: 'Deployment status polling timed out after 5 minutes'
        };
    }

    exportTopology() {
        if (!globalEditor) return;

        const yamlContent = globalEditor.getValue();
        const blob = new Blob([yamlContent], { type: 'text/yaml' });
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'topology.clab.yml';
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        window.URL.revokeObjectURL(url);
    }

    copyLogsToClipboard() {
        const logContent = document.getElementById('log-content');
        if (logContent && navigator.clipboard) {
            navigator.clipboard.writeText(logContent.textContent).then(() => {
                const btn = document.getElementById('copy-logs-btn');
                if (btn) {
                    const originalText = btn.innerHTML;
                    btn.innerHTML = '<i class="fas fa-check"></i> Copied!';
                    setTimeout(() => {
                        btn.innerHTML = originalText;
                    }, 2000);
                }
            });
        }
    }

    showResultModal(success, message, logs, customTitle = null) {
        console.log('📊 Showing result modal:', success ? 'Success' : 'Error');

        const icon = document.getElementById('result-icon');
        const title = document.getElementById('result-title-text');
        const messageDiv = document.getElementById('result-message');
        const logSection = document.getElementById('log-section');
        const logContent = document.getElementById('log-content');

        if (success) {
            if (icon) {
                icon.className = 'fas fa-check-circle result-icon';
                icon.style.color = '#27ae60';
            }
            if (title) title.textContent = customTitle || 'Success';

            if (messageDiv) {
                messageDiv.className = 'result-message success';
            }
        } else {
            if (icon) {
                icon.className = 'fas fa-times-circle result-icon';
                icon.style.color = '#e74c3c';
            }
            if (title) title.textContent = customTitle || 'Error';

            if (messageDiv) {
                messageDiv.className = 'result-message error';
            }

            // REMOVED: Enhanced error message formatting for invalid IP addresses
            // Management IP validation no longer needed
        }

        if (messageDiv) {
            // messageDiv.style.whiteSpace = 'pre-wrap';

            // Check if message contains HTML by looking for HTML tags
            if (message && (message.includes('<') && message.includes('>'))) {
                // Render as HTML for deployment success messages and other formatted content
                messageDiv.innerHTML = message;
            } else {
                // Use textContent for plain text messages to prevent XSS
                messageDiv.textContent = message;
            }
        }

        // Handle logs section
        if (logs && logSection && logContent) {
            logContent.textContent = logs;
            DOMUtils.showElement(logSection);
            console.log('📊 Logs section displayed');
        } else if (logSection) {
            DOMUtils.hideElement(logSection);
        }

        // Show the result modal
        this.modalManager.show('result-modal');
        console.log('✅ Result modal displayed');
    }


    autoConnectNewNode(newNodeName) {
        console.log('🔗 Attempting auto-connection for:', newNodeName);

        if (!currentTopologyData) {
            console.log('⚠️ No DCIM topology data loaded');
            this.showResultModal(
                false,
                `Auto-connection requires DCIM data. Please click "Load DCIM" first to discover existing connections.`,
                null
            );
            return;
        }

        if (!currentTopologyData.connections || currentTopologyData.connections.length === 0) {
            console.log('⚠️ No connections found in DCIM data');
            this.showResultModal(
                true,
                `Node "${newNodeName}" added successfully. No auto-connections found in DCIM data.`,
                null
            );
            return;
        }

        const yamlContent = globalEditor.getValue();
        const yamlObj = jsyaml.load(yamlContent);
        const existingNodes = Object.keys(yamlObj.topology.nodes || {});

        console.log('📋 Existing nodes:', existingNodes);
        console.log('🔍 Looking for connections involving:', newNodeName);

        let autoConnections = [];

        // Find connections involving the new node
        currentTopologyData.connections.forEach(connection => {
            console.log('🔍 Checking connection:', connection.source_device, '↔', connection.target_device);

            if (connection.source_device === newNodeName &&
                existingNodes.includes(connection.target_device)) {

                autoConnections.push({
                    source: connection.source_device,
                    source_interface: connection.source_interface,
                    target: connection.target_device,
                    target_interface: connection.target_interface
                });
            }

            if (connection.target_device === newNodeName &&
                existingNodes.includes(connection.source_device)) {

                autoConnections.push({
                    source: connection.source_device,
                    source_interface: connection.source_interface,
                    target: connection.target_device,
                    target_interface: connection.target_interface
                });
            }
        });

        console.log('✅ Auto connections found:', autoConnections.length);

        // Add discovered connections
        if (autoConnections.length > 0) {
            yamlObj.topology.links = yamlObj.topology.links || [];

            let addedCount = 0;
            autoConnections.forEach(conn => {
                const endpoint1 = `${conn.source}:${conn.source_interface}`;
                const endpoint2 = `${conn.target}:${conn.target_interface}`;

                // Check if connection already exists
                const exists = yamlObj.topology.links.some(link =>
                    (link.endpoints[0] === endpoint1 && link.endpoints[1] === endpoint2) ||
                    (link.endpoints[0] === endpoint2 && link.endpoints[1] === endpoint1)
                );

                if (!exists) {
                    yamlObj.topology.links.push({
                        endpoints: [endpoint1, endpoint2]
                    });
                    addedCount++;
                }
            });

            // Update editor with new connections
            if (addedCount > 0) {
                const updatedYaml = jsyaml.dump(yamlObj);
                globalEditor.setValue(updatedYaml);
                globalEditor.clearSelection();
                this.updateVisualization(updatedYaml);

                this.showResultModal(
                    true,
                    `Node "${newNodeName}" added successfully with ${addedCount} auto-discovered connection(s).`,
                    null
                );
            } else {
                this.showResultModal(
                    true,
                    `Node "${newNodeName}" added successfully. All connections already exist.`,
                    null
                );
            }
        } else {
            this.showResultModal(
                true,
                `Node "${newNodeName}" added successfully. No auto-connections found.`,
                null
            );
        }
    }

    showHelp() {
        console.log('❓ Help button clicked');
        // Create a simple help modal
        const helpModal = document.createElement('div');
        helpModal.className = 'modal';
        helpModal.id = 'help-modal';
        helpModal.innerHTML = `
            <div class="modal-content">
                <div class="modal-header">
                    <h2><i class="fas fa-question-circle"></i> Digital Twin Help</h2>
                    <button class="close-btn" title="Close" type="button">&times;</button>
                </div>
                <div class="modal-body">
                    <div class="help-section">
                        <h4><i class="fas fa-project-diagram"></i> Topology Management</h4>
                        <ul>
                            <li><strong>Add Node:</strong> Click "Add Node" to create new network devices</li>
                            <li><strong>Load DCIM:</strong> Import existing devices from your DCIM system</li>
                            <li><strong>Auto Layout:</strong> Automatically arrange nodes in a grid pattern</li>
                            <li><strong>Export:</strong> Download your topology as a YAML file</li>
                        </ul>
                    </div>
                    <div class="help-section">
                        <h4><i class="fas fa-code"></i> YAML Editor</h4>
                        <ul>
                            <li><strong>Edit:</strong> Modify YAML directly in the editor panel</li>
                            <li><strong>Validate:</strong> Check YAML syntax and structure</li>
                            <li><strong>Toggle:</strong> Show/hide the editor panel as needed</li>
                        </ul>
                    </div>
                    <div class="help-section">
                        <h4><i class="fas fa-server"></i> Lab Deployment</h4>
                        <ul>
                            <li><strong>Deploy:</strong> Deploy your topology to Containerlab</li>
                            <li><strong>Monitor:</strong> View running labs and container status</li>
                            <li><strong>Terminal:</strong> Access device command line interfaces</li>
                        </ul>
                    </div>
                </div>
                <div class="modal-footer">
                    <button class="btn btn-primary" onclick="document.getElementById('help-modal').remove()">Got it!</button>
                </div>
            </div>
        `;

        // Add to page
        document.body.appendChild(helpModal);

        // Setup close functionality
        const closeBtn = helpModal.querySelector('.close-btn');
        closeBtn.addEventListener('click', () => helpModal.remove());

        // Close on outside click
        helpModal.addEventListener('click', (e) => {
            if (e.target === helpModal) helpModal.remove();
        });

        // Show modal
        helpModal.style.display = 'flex';
    }

    showSettings() {
        console.log('⚙️ Settings button clicked');

        // Get the existing settings modal from HTML
        const settingsModal = document.getElementById('settings-modal');
        if (!settingsModal) {
            console.error('Settings modal not found in HTML');
            return;
        }

        // Setup close functionality
        const closeBtn = settingsModal.querySelector('.close-btn');
        const cancelBtn = settingsModal.querySelector('#settings-cancel-btn');
        const saveBtn = settingsModal.querySelector('#settings-save-btn');

        // Remove existing event listeners to prevent duplicates
        closeBtn.replaceWith(closeBtn.cloneNode(true));
        cancelBtn.replaceWith(cancelBtn.cloneNode(true));
        saveBtn.replaceWith(saveBtn.cloneNode(true));

        // Get fresh references after cloning
        const newCloseBtn = settingsModal.querySelector('.close-btn');
        const newCancelBtn = settingsModal.querySelector('#settings-cancel-btn');
        const newSaveBtn = settingsModal.querySelector('#settings-save-btn');

        // Add event listeners
        newCloseBtn.addEventListener('click', () => this.hideSettings());
        newCancelBtn.addEventListener('click', () => this.hideSettings());
        newSaveBtn.addEventListener('click', () => this.saveSettings());

        // Close on outside click
        settingsModal.addEventListener('click', (e) => {
            if (e.target === settingsModal) this.hideSettings();
        });

        // Load current settings
        this.loadSettings();

        // Show modal
        settingsModal.style.display = 'flex';
    }

    hideSettings() {
        const settingsModal = document.getElementById('settings-modal');
        if (settingsModal) {
            settingsModal.style.display = 'none';
        }
    }

    saveSettings() {
        console.log('💾 Saving settings...');

        // Get form values
        const theme = document.getElementById('theme-select').value;
        const autoSave = document.getElementById('auto-save').checked;
        const confirmDelete = document.getElementById('confirm-delete').checked;
        const defaultServer = document.getElementById('default-server').value;

        // Save to localStorage
        const settings = {
            theme: theme,
            autoSave: autoSave,
            confirmDelete: confirmDelete,
            defaultServer: defaultServer,
            lastSaved: new Date().toISOString()
        };

        try {
            localStorage.setItem('digitalTwinSettings', JSON.stringify(settings));
            console.log('✅ Settings saved successfully');

            // Apply theme immediately if changed
            if (theme !== 'auto') {
                document.body.className = `theme-${theme}`;
            }

            // Show success message
            this.showServerStatusMessage('Settings saved successfully!', 'success');

            // Hide modal
            this.hideSettings();
        } catch (error) {
            console.error('❌ Failed to save settings:', error);
            this.showServerStatusMessage('Failed to save settings. Please try again.', 'error');
        }
    }

    loadSettings() {
        console.log('📖 Loading settings...');

        try {
            const savedSettings = localStorage.getItem('digitalTwinSettings');
            if (savedSettings) {
                const settings = JSON.parse(savedSettings);

                // Apply saved values to form
                if (settings.theme) {
                    document.getElementById('theme-select').value = settings.theme;
                }
                if (settings.autoSave !== undefined) {
                    document.getElementById('auto-save').checked = settings.autoSave;
                }
                if (settings.confirmDelete !== undefined) {
                    document.getElementById('confirm-delete').checked = settings.confirmDelete;
                }
                if (settings.defaultServer) {
                    document.getElementById('default-server').value = settings.defaultServer;
                }

                // Apply theme
                if (settings.theme && settings.theme !== 'auto') {
                    document.body.className = `theme-${settings.theme}`;
                }

                console.log('✅ Settings loaded successfully');
            } else {
                console.log('ℹ️ No saved settings found, using defaults');
            }
        } catch (error) {
            console.error('❌ Failed to load settings:', error);
        }
    }

    initializeConnectionStatus() {
        const connectionIndicator = document.getElementById('connectionIndicator');
        const connectionStatus = document.getElementById('connectionStatus');

        if (connectionIndicator && connectionStatus) {
            // Set initial status
            this.updateConnectionStatus('Connected', true);

            // Simulate connection monitoring (you can replace this with real connection logic)
            setInterval(() => {
                // For demo purposes, randomly change status
                // In production, this would check actual connection health
                const isOnline = Math.random() > 0.1; // 90% chance of being online
                this.updateConnectionStatus(
                    isOnline ? 'Connected' : 'Disconnected',
                    isOnline
                );
            }, 30000); // Check every 30 seconds
        }
    }

    updateConnectionStatus(status, isOnline = true) {
        const connectionIndicator = document.getElementById('connectionIndicator');
        const connectionStatus = document.getElementById('connectionStatus');

        if (connectionIndicator && connectionStatus) {
            connectionStatus.innerText = status;
            connectionIndicator.className = `status-indicator ${isOnline ? '' : 'offline'}`;
        }
    }

}


class RemoteLabManager {
    constructor() {
        this.availableServers = [];
        this.selectedServerId = 'default';
        this.deploymentStatus = new Map();
        this.healthCheckInterval = null;
    }

    async initialize() {
        console.log('🔄 Initializing Remote Lab Manager...');
        await this.loadAvailableServers();
        this.setupServerHealthMonitoring();
        this.setupServerSelectionUI();
    }

    async loadAvailableServers() {
        try {
            console.log('📊 Loading available remote servers...');

            // Create AbortController for 30-second timeout
            const controller = new AbortController();
            const timeoutId = setTimeout(() => controller.abort(), 30000);

            const response = await fetch('/plugins/digital-twin/remote-servers/', {
                method: 'GET',
                headers: {
                    'X-CSRFToken': getCookie('csrftoken'),
                    'Accept': 'application/json'
                },
                signal: controller.signal
            });

            clearTimeout(timeoutId);

            if (!response.ok) {
                throw new Error(`HTTP ${response.status}: ${response.statusText}`);
            }

            const data = await response.json();

            if (data.success) {
                this.availableServers = data.servers || [];
                this.showServerStatusMessage('Servers loaded successfully', 'success');
                this.availableServers.forEach(server => {
                    console.log(`   - ${server.id}: ${server.name} (${server.type}) - Status: ${server.status}`);
                });
                this.updateServerSelectionUI();
            } else {
                console.error('❌ Failed to load servers:', data.error);
                this.availableServers = [];
                this.showServerStatusMessage('Failed to load servers', 'error');
            }
        } catch (error) {
            if (error.name === 'AbortError') {
                console.warn('⚠️ Server status request timed out after 5 seconds');
                this.showServerStatusMessage('Server status request timed out', 'warning');
            } else {
                console.error('❌ Error loading servers:', error);
            }
            this.availableServers = [];
        }
    }

    setupServerSelectionUI() {
        console.log('🎛️ Setting up server selection UI...');

        const serverSelector = document.getElementById('server-selector');
        const serverInfo = document.getElementById('server-info');

        if (!serverSelector) {
            console.error('❌ Server selector element not found');
            return;
        }

        // Clear existing options
        serverSelector.innerHTML = '';

        // Add server options
        this.availableServers.forEach(server => {
            const option = document.createElement('option');
            option.value = server.id;

            let statusIndicator = '';
            switch (server.status) {
                case 'healthy':
                    statusIndicator = '🟢';
                    break;
                case 'unhealthy':
                    statusIndicator = '🟡';
                    option.disabled = true;
                    break;
                case 'error':
                    statusIndicator = '🔴';
                    option.disabled = true;
                    break;
                default:
                    statusIndicator = '⚪';
                    option.disabled = true;
            }

            // Enhanced server info in dropdown with type indicator
            let serverText = `${statusIndicator} ${server.name}`;

            // Add server type indicator
            if (server.type) {
                const typeEmoji = {
                    'local': '🏠',
                    'api': '🌐',
                    'hybrid': '🔗',
                    'ssh': '🔐'
                };
                const typeIcon = typeEmoji[server.type] || '❓';
                serverText += ` ${typeIcon}`;
            }

            // Add host info if not localhost
            if (server.host && server.host !== 'localhost') {
                serverText += ` - ${server.host}`;
            } else if (server.host === 'localhost') {
                serverText += ` - localhost`;
            }

            // Add resource usage if available
            if (server.cpu_usage !== undefined && server.memory_usage !== undefined) {
                serverText += ` (CPU: ${server.cpu_usage}%, MEM: ${server.memory_usage}%)`;
            }

            // Add active labs count
            if (server.active_labs > 0) {
                serverText += ` [${server.active_labs} labs]`;
            }

            option.textContent = serverText;

            serverSelector.appendChild(option);
        });

        // Set default selection - prefer remote servers
        if (this.availableServers.length > 0) {
            // First try to find a healthy remote server (not local)
            let defaultServer = this.availableServers.find(s => s.status === 'healthy' && s.type !== 'local');

            // If no healthy remote server, fall back to any healthy server
            if (!defaultServer) {
                defaultServer = this.availableServers.find(s => s.status === 'healthy');
            }

            if (defaultServer) {
                this.selectedServerId = defaultServer.id;
                serverSelector.value = defaultServer.id;
            }
        }

        // Add change event listener
        serverSelector.addEventListener('change', (event) => {
            this.selectedServerId = event.target.value;
            this.updateServerInfo();
            console.log('🎯 Server selection changed to:', this.selectedServerId);

            // Update lab manager with new server selection
            if (window.labManager) {
                window.labManager.updateMainServerSelector();
            }
        });

        this.updateServerInfo();
    }

    updateServerInfo() {
        const serverInfo = document.getElementById('server-info');
        if (!serverInfo) return;

        const selectedServer = this.availableServers.find(s => s.id === this.selectedServerId);

        if (!selectedServer) {
            serverInfo.innerHTML = '<span class="text-muted">No server selected</span>';
            return;
        }

        let statusColor = '';
        switch (selectedServer.status) {
            case 'healthy':
                statusColor = 'text-success';
                break;
            case 'unhealthy':
                statusColor = 'text-warning';
                break;
            case 'error':
                statusColor = 'text-danger';
                break;
            default:
                statusColor = 'text-muted';
        }

        let infoHtml = `
            <div class="server-info-card">
                <div class="server-info-header">
                    <strong>${selectedServer.name}</strong>
                    <span class="server-status ${statusColor}">${selectedServer.status.toUpperCase()}</span>
                </div>
                <div class="server-info-details">
                    <div class="info-row">
                        <span class="info-label">Host:</span>
                        <span class="info-value">${selectedServer.host}</span>
                    </div>
                    <div class="info-row">
                        <span class="info-label">Type:</span>
                        <span class="info-value">${selectedServer.type}</span>
                    </div>
                    <div class="info-row">
                        <span class="info-label">Active Labs:</span>
                        <span class="info-value">${selectedServer.active_labs || 0}</span>
                    </div>
                    <div class="info-row">
                        <span class="info-label">Last Check:</span>
                        <span class="info-value">${new Date(selectedServer.last_check).toLocaleTimeString()}</span>
                    </div>
                </div>
            </div>
        `;

        serverInfo.innerHTML = infoHtml;
    }

    updateServerSelectionUI() {
        const serverSelector = document.getElementById('server-selector');
        if (!serverSelector) return;

        // Store current selection
        const currentSelection = serverSelector.value;

        // Clear and rebuild
        serverSelector.innerHTML = '';

        this.availableServers.forEach(server => {
            const option = document.createElement('option');
            option.value = server.id;

            let statusIndicator = '';
            switch (server.status) {
                case 'healthy':
                    statusIndicator = '🟢';
                    break;
                case 'unhealthy':
                    statusIndicator = '🟡';
                    option.disabled = true;
                    break;
                case 'error':
                    statusIndicator = '🔴';
                    option.disabled = true;
                    break;
                default:
                    statusIndicator = '⚪';
                    option.disabled = true;
            }

            // Enhanced server info in dropdown
            let serverText = `${statusIndicator} ${server.name}`;

            // Add host info if not localhost
            if (server.host && server.host !== 'localhost') {
                serverText += ` - ${server.host}`;
            }

            // Add resource usage if available
            if (server.cpu_usage !== undefined && server.memory_usage !== undefined) {
                serverText += ` (CPU: ${server.cpu_usage}%, MEM: ${server.memory_usage}%)`;
            }

            // Add active labs count
            if (server.active_labs > 0) {
                serverText += ` [${server.active_labs} labs]`;
            }

            option.textContent = serverText;

            serverSelector.appendChild(option);
        });

        // Restore selection if possible
        if (currentSelection && [...serverSelector.options].some(opt => opt.value === currentSelection)) {
            serverSelector.value = currentSelection;
        } else if (this.availableServers.length > 0) {
            // Prefer remote servers as default
            let defaultServer = this.availableServers.find(s => s.status === 'healthy' && s.type !== 'local');

            if (!defaultServer) {
                defaultServer = this.availableServers.find(s => s.status === 'healthy');
            }

            if (defaultServer) {
                serverSelector.value = defaultServer.id;
                this.selectedServerId = defaultServer.id;
            }
        }

        this.updateServerInfo();

        // Update lab manager with new server data
        if (window.labManager) {
            window.labManager.availableServers = this.availableServers;
            window.labManager.updateMainServerSelector();
        }
    }

    setupServerHealthMonitoring() {
        console.log('🏥 Setting up server health monitoring...');

        // Check server health every 30 seconds for consistent timeout
        this.healthCheckInterval = setInterval(async () => {
            await this.refreshServerHealth();
        }, 30000);
    }

    async refreshServerHealth() {
        try {
            console.log('🔄 Refreshing server health status...');

            // Show loading state
            const refreshBtn = document.getElementById('refresh-servers-btn');
            if (refreshBtn) {
                const originalText = refreshBtn.innerHTML;
                refreshBtn.innerHTML = '🔄 Checking...';
                refreshBtn.disabled = true;

                // Re-enable after a delay
                setTimeout(() => {
                    refreshBtn.innerHTML = originalText;
                    refreshBtn.disabled = false;
                }, 3000);
            }

            await this.loadAvailableServers();

        } catch (error) {
            console.error('❌ Error refreshing server health:', error);
            this.showServerStatusMessage('Failed to refresh server health', 'error');
        }
    }

    showServerStatusMessage(message, type = 'info') {
        const notification = document.createElement('div');
        notification.className = type === 'success' ? 'success-notification' : 'error-notification';
        notification.innerHTML = `
            <i class="fas ${type === 'success' ? 'fa-check-circle' : 'fa-exclamation-circle'}"></i>
            <span>${message}</span>
        `;

        document.body.appendChild(notification);

        setTimeout(() => {
            if (notification.parentNode) {
                notification.parentNode.removeChild(notification);
            }
        }, 3000);
    }

    async deployToRemoteServer(labName, yamlContent, progressCallback) {
        console.log('🚀 Deploying to remote server:', this.selectedServerId);

        const selectedServer = this.availableServers.find(s => s.id === this.selectedServerId);
        if (!selectedServer) {
            throw new Error('No server selected for deployment');
        }

        if (selectedServer.status !== 'healthy') {
            throw new Error(`Selected server is ${selectedServer.status} and cannot accept deployments`);
        }

        try {
            const response = await fetch('/plugins/digital-twin/simulate-lab/', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRFToken': getCookie('csrftoken')
                },
                body: JSON.stringify({
                    lab_name: labName,
                    topology_yaml: yamlContent,
                    server_id: this.selectedServerId
                })
            });

            if (!response.ok) {
                throw new Error(`HTTP ${response.status}: ${response.statusText}`);
            }

            const result = await response.json();
            console.log(result);


            if (result.success && result.deployment_id) {
                // Poll deployment status for enhanced error detection
                const finalResult = await this.pollDeploymentStatus(
                    result.deployment_id,
                    progressCallback
                );

                // Store deployment info
                this.deploymentStatus.set(labName, {
                    server_id: this.selectedServerId,
                    deployment_id: result.deployment_id,
                    status: finalResult.success ? 'deployed' : 'failed',
                    deployed_at: new Date().toISOString()
                });

                if (finalResult.success) {
                    console.log('✅ Remote deployment successful:', labName);
                    return {
                        success: true,
                        message: finalResult.message || result.message,
                        deployment_id: result.deployment_id,
                        logs: finalResult.logs
                    };
                } else {
                    // Deployment failed - throw error with details
                    const errorMsg = finalResult.error || finalResult.message || 'Remote deployment failed';
                    const error = new Error(errorMsg);
                    error.logs = finalResult.logs;
                    throw error;
                }
            } else {
                throw new Error(result.error || 'Remote deployment failed');
            }
        } catch (error) {
            console.error('❌ Remote deployment error:', error);
            throw error;
        }
    }

    async pollDeploymentStatus(deploymentId, progressCallback) {
        console.log('📊 Polling deployment status for:', deploymentId);

        const maxAttempts = 6; // 5 minutes at 5-second intervals
        let attempts = 0;

        while (attempts < maxAttempts) {
            try {
                // Create AbortController for 30-second timeout
                const controller = new AbortController();
                const timeoutId = setTimeout(() => controller.abort(), 30000);

                const response = await fetch(`/plugins/digital-twin/deployment-status/${deploymentId}/`, {
                    signal: controller.signal
                });
                
                clearTimeout(timeoutId);
                
                if (!response.ok) {
                    throw new Error(`Status check failed: ${response.status}`);
                }

                const status = await response.json();
                console.log('📊 Deployment status:', status);

                // Update progress if callback provided
                if (progressCallback && status.progress !== undefined) {
                    progressCallback(status.progress, status.message || 'Deployment in progress...');
                }

                // Check for completion (success or failure)
                if (status.status === 'completed') {
                    return {
                        success: true,
                        message: status.message,
                        logs: status.logs
                    };
                } else if (status.status === 'failed' || status.has_error) {
                    return {
                        success: false,
                        error: status.error || status.message,
                        message: status.message,
                        logs: status.logs
                    };
                }

                // Continue polling for running status
                if (status.status === 'running' || status.status === 'accepted') {
                    await new Promise(resolve => setTimeout(resolve, 5000)); // Wait 5 seconds
                    attempts++;
                    continue;
                }

                // Unknown status - assume failure
                return {
                    success: false,
                    error: `Unknown deployment status: ${status.status}`,
                    message: status.message,
                    logs: status.logs
                };

            } catch (error) {
                console.error('❌ Status polling error:', error);
                attempts++;

                if (attempts >= maxAttempts) {
                    return {
                        success: false,
                        error: `Status polling failed after ${maxAttempts} attempts: ${error.message}`
                    };
                }

                // Wait before retrying
                await new Promise(resolve => setTimeout(resolve, 5000));
            }
        }

        // Timeout
        return {
            success: false,
            error: 'Deployment status polling timed out after 5 minutes'
        };
    }

    getSelectedServerInfo() {
        return this.availableServers.find(s => s.id === this.selectedServerId);
    }

    isRemoteServer() {
        const selectedServer = this.getSelectedServerInfo();
        return selectedServer && selectedServer.type !== 'local';
    }

    cleanup() {
        if (this.healthCheckInterval) {
            clearInterval(this.healthCheckInterval);
            this.healthCheckInterval = null;
        }
    }
}

class LabManager {
    constructor() {
        this.availableServers = [];
        this.activeLabsCache = new Map();
        this.currentServerSelection = null;
        this.selectedLab = null;
        this.selectedServerId = null;
        this.modals = {
            labManagement: null
        };
    }

    async initialize() {
        console.log('🔬 Initializing Lab Management...');

        // Initialize modals
        this.modals.labManagement = document.getElementById('lab-management-modal');

        if (!this.modals.labManagement) {
            console.error('❌ Lab management modal not found');
            return;
        }

        // Setup event listeners
        this.setupEventListeners();

        // Load initial data
        await this.loadAvailableServers();

        console.log('✅ Lab Management initialized');
    }

    setupEventListeners() {
        // View Labs button
        const viewLabsBtn = document.getElementById('view-labs-btn');
        if (viewLabsBtn) {
            viewLabsBtn.addEventListener('click', () => this.showLabManagementModal());
        }

        // Lab Management Modal Events
        const labServerSelector = document.getElementById('lab-server-selector');
        if (labServerSelector) {
            labServerSelector.addEventListener('change', (e) => {
                console.log('🎛️ Lab server selector changed:', e.target.value);
                this.currentServerSelection = e.target.value;
                if (this.currentServerSelection) {
                    this.loadActiveLabs(this.currentServerSelection);
                } else {
                    // Clear labs display if no server is selected
                    this.clearLabsDisplay();
                }
            });
        }

        const refreshLabsBtn = document.getElementById('refresh-labs-btn');
        if (refreshLabsBtn) {
            refreshLabsBtn.addEventListener('click', () => {
                console.log('🔄 Refresh labs button clicked');
                if (this.currentServerSelection) {
                    this.loadActiveLabs(this.currentServerSelection, true);
                } else {
                    console.warn('⚠️ No server selected for refresh');
                }
            });
        }

        // Modal close buttons
        const closeLabMgmtBtn = document.getElementById('close-lab-management-btn');
        if (closeLabMgmtBtn) {
            closeLabMgmtBtn.addEventListener('click', () => this.hideLabManagementModal());
        }

        // Lab action buttons (integrated into main modal now)
        const stopLabBtn = document.getElementById('stop-lab-btn');
        if (stopLabBtn) {
            stopLabBtn.addEventListener('click', () => {
                if (this.selectedLab && this.selectedServerId) {
                    this.stopCurrentLab();
                }
            });
        }



        const refreshLabDetailsBtn = document.getElementById('refresh-lab-details-btn');
        if (refreshLabDetailsBtn) {
            refreshLabDetailsBtn.addEventListener('click', () => {
                if (this.selectedLab && this.selectedServerId) {
                    this.refreshCurrentLabDetails();
                }
            });
        }

        const hideLogsBtn = document.getElementById('hide-logs-btn');
        if (hideLogsBtn) {
            hideLogsBtn.addEventListener('click', () => {
                this.hideLabLogs();
            });
        }

        // Lab Details Modal Events - REMOVED: Now integrated into main modal above

        // Close modals when clicking outside
        window.addEventListener('click', (e) => {
            if (e.target === this.modals.labManagement) {
                this.hideLabManagementModal();
            }
        });

        // Close buttons (×)
        document.querySelectorAll('.close-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const modal = e.target.closest('.modal');
                if (modal) {
                    DOMUtils.hideModal(modal);
                }
            });
        });
    }

    async loadAvailableServers() {
        try {
            // Create AbortController for 30-second timeout
            const controller = new AbortController();
            const timeoutId = setTimeout(() => controller.abort(), 30000);

            const response = await fetch('/plugins/digital-twin/remote-servers/', {
                signal: controller.signal
            });
            
            clearTimeout(timeoutId);
            
            const data = await response.json();

            if (data.success) {
                this.availableServers = data.servers || [];
                this.populateServerDropdowns();

                // Update main server selector with resource info
                this.updateMainServerSelector();
            } else {
                console.error('Failed to load servers:', data.error);
            }
        } catch (error) {
            if (error.name === 'AbortError') {
                console.warn('⚠️ Server status request timed out after 5 seconds');
            } else {
                console.error('Error loading servers:', error);
            }
        }
    }

    populateServerDropdowns() {
        const labServerSelector = document.getElementById('lab-server-selector');
        if (!labServerSelector) return;

        // Clear existing options
        labServerSelector.innerHTML = '<option value="">Select Server</option>';

        // Add server options
        this.availableServers.forEach(server => {
            const option = document.createElement('option');
            option.value = server.id;

            let serverInfo = server.name;
            if (server.active_labs > 0) {
                serverInfo += ` (${server.active_labs} labs)`;
            }

            option.textContent = serverInfo;

            if (server.status === 'healthy') {
                option.style.color = '#27ae60';
            } else {
                option.style.color = '#e74c3c';
            }

            labServerSelector.appendChild(option);
        });
    }

    updateMainServerSelector() {
        const serverSelector = document.getElementById('server-selector');
        const serverInfoDisplay = document.getElementById('server-info-display');
        const serverStatusIndicator = document.getElementById('server-status-indicator');
        const serverResourceInfo = document.getElementById('server-resource-info');

        if (!serverSelector || !serverInfoDisplay) return;

        // Update current selection info
        const selectedServerId = serverSelector.value;
        const selectedServer = this.availableServers.find(s => s.id === selectedServerId);

        if (selectedServer && serverStatusIndicator && serverResourceInfo) {
            // Show server info
            serverInfoDisplay.style.display = 'flex';

            // Update status indicator
            serverStatusIndicator.className = `server-status-indicator ${selectedServer.status}`;

            // Update resource info
            let resourceText = '';
            if (selectedServer.cpu_usage !== undefined && selectedServer.cpu_usage !== null) {
                resourceText += `CPU: ${selectedServer.cpu_usage}%`;
            }
            if (selectedServer.memory_usage !== undefined && selectedServer.memory_usage !== null) {
                if (resourceText) resourceText += ' | ';
                resourceText += `RAM: ${selectedServer.memory_usage}%`;
            }
            if (selectedServer.active_labs > 0) {
                if (resourceText) resourceText += ' | ';
                resourceText += `${selectedServer.active_labs} labs`;
            }

            serverResourceInfo.textContent = resourceText || 'No resource data';
        } else {
            serverInfoDisplay.style.display = 'none';
        }
    }

    showLabManagementModal() {
        console.log('🎪 Opening Lab Management Modal');

        if (!this.modals.labManagement) return;

        // Populate server dropdown
        this.populateServerDropdowns();

        // Show modal
        DOMUtils.showModal(this.modals.labManagement);

        // Reset to placeholder state
        this.showLabPlaceholder();

        // Auto-select current server if available and load labs
        const mainServerSelector = document.getElementById('server-selector');
        const labServerSelector = document.getElementById('lab-server-selector');

        if (mainServerSelector && labServerSelector && mainServerSelector.value) {
            console.log('🎯 Auto-selecting server:', mainServerSelector.value);
            labServerSelector.value = mainServerSelector.value;
            this.currentServerSelection = mainServerSelector.value;
            // Immediately load labs for the selected server
            this.loadActiveLabs(this.currentServerSelection);
        } else {
            // Clear labs display if no server is selected
            this.clearLabsDisplay();
        }
    }

    hideLabManagementModal() {
        if (this.modals.labManagement) {
            DOMUtils.hideModal(this.modals.labManagement);
        }
    }

    async loadActiveLabs(serverId, forceRefresh = false) {

        const labsLoading = document.getElementById('labs-loading');
        const noLabsMessage = document.getElementById('no-labs-message');
        const labsList = document.getElementById('labs-list');

        if (!labsLoading || !noLabsMessage || !labsList) {
            console.error('❌ Required elements not found for loading labs');
            return;
        }

        labsLoading.style.display = 'flex';
        noLabsMessage.style.display = 'none';
        labsList.innerHTML = '';

        this.showLabPlaceholder();

        try {
            if (!forceRefresh && this.activeLabsCache.has(serverId)) {
                const cachedData = this.activeLabsCache.get(serverId);
                const now = Date.now();

                if (now - cachedData.timestamp < 30000) {
                    this.displayActiveLabs(cachedData.labs);
                    labsLoading.style.display = 'none';
                    return;
                }
            }

            const response = await fetch(`/plugins/digital-twin/servers/${serverId}/labs/`);
            const data = await response.json();

            labsLoading.style.display = 'none';

            if (data.success) {
                const labs = data.labs || [];

                this.activeLabsCache.set(serverId, {
                    labs: labs,
                    timestamp: Date.now()
                });

                this.displayActiveLabs(labs);
            } else {
                console.error('Failed to load active labs:', data.error);
                this.showError('Failed to load labs: ' + data.error);
            }
        } catch (error) {
            console.error('Error loading active labs:', error);
            labsLoading.style.display = 'none';
            this.showError('Error loading labs: ' + error.message);
        }
    }

    displayActiveLabs(labs) {

        const labsLoading = document.getElementById('labs-loading');
        const noLabsMessage = document.getElementById('no-labs-message');
        const labsList = document.getElementById('labs-list');

        if (labsLoading) labsLoading.style.display = 'none';

        // Clear current selection
        this.selectedLab = null;
        this.selectedServerId = document.getElementById('lab-server-selector')?.value;
        this.showLabPlaceholder();

        // Debug: Log detailed lab information
        if (labs && labs.length > 0) {
            labs.forEach(lab => {
                console.log(`🔍 Lab: ${lab.name}, Containers:`, lab.containers);
                if (lab.containers) {
                    lab.containers.forEach(container => {
                        console.log(`  📦 Container: ${container.name}, State: ${container.state}, Status: ${container.status}`);
                    });
                }
            });
        }

        if (!labs || labs.length === 0) {
            if (noLabsMessage) noLabsMessage.style.display = 'flex';
            if (labsList) labsList.innerHTML = '';
            return;
        }

        if (noLabsMessage) noLabsMessage.style.display = 'none';

        if (labsList) {
            labsList.innerHTML = '';
            labs.forEach(lab => {
                const labItem = this.createLabListItem(lab);
                labsList.appendChild(labItem);
            });
        }
    }

    createLabListItem(lab) {
        const labItem = document.createElement('div');
        labItem.className = 'lab-list-item';
        labItem.setAttribute('data-lab-name', lab.name);

       // Determine lab status
        const runningCount = lab.running_count || 0;
        const totalCount = lab.total_count || 0;
        let status = 'stopped';

        if (runningCount === totalCount && totalCount > 0) {
            status = 'running';
        } else if (runningCount > 0) {
            status = 'partial';
        }

        // Calculate lab uptime from containers if available
        const labUptimeDisplay = lab && Array.isArray(lab.containers) && lab.containers.length > 0
            ? this.calculateLabUptime(lab.containers)
            : '-';

        labItem.innerHTML = `
    <div class="lab-card">
        <div class="lab-header">
            <div class="kv-pair">
                <span class="value-primary">${lab.name}</span>
            </div>
            <div class="status-badge ${status}">${status.charAt(0).toUpperCase() + status.slice(1)}</div>
        </div>
        
        <div class="lab-body">
            <div class="kv-pair">
                <span class="label">
                    <i class="fas fa-cube"></i>
                    Total Containers:
                </span>
                <span class="value">${totalCount}</span>
            </div>
            
            <div class="kv-pair">
                <span class="label">
                    <i class="fas fa-play-circle"></i>
                    Running:
                </span>
                <span class="value-highlight">${runningCount}</span>
            </div>
            
            <div class="kv-pair">
                <span class="label">
                    <i class="fas fa-clock"></i>
                    Uptime:
                </span>
                <span class="value">${labUptimeDisplay}</span>
            </div>
        </div>
        
        
    </div>
`;



        // Add click handler to select and show lab details
        labItem.addEventListener('click', () => {
            console.log('🎯 Lab item clicked:', lab.name);
            this.selectLab(lab, labItem);
        });

        return labItem;
    }

    selectLab(lab, labItemElement) {
        console.log('🎯 Selecting lab:', lab.name);
        console.log('🎯 Lab data:', lab);
        console.log('🎯 Lab server_id:', lab.server_id);

        // Update selection state
        this.selectedLab = lab;
        this.selectedServerId = document.getElementById('lab-server-selector')?.value;

        // Update UI selection state
        const allLabItems = document.querySelectorAll('.lab-list-item');
        allLabItems.forEach(item => item.classList.remove('selected'));
        if (labItemElement) {
            labItemElement.classList.add('selected');
        }

        // Show lab details in content area
        this.showLabDetailsInContent(lab);
    }

    showLabPlaceholder() {
        const placeholder = document.getElementById('lab-details-placeholder');
        const content = document.getElementById('lab-details-content');

        if (placeholder) placeholder.style.display = 'flex';
        if (content) content.style.display = 'none';

        // Clear any selected lab state
        this.selectedLab = null;
        this.selectedServerId = null;
    }

    showLabDetailsInContent(lab) {
        console.log('📋 Showing lab details in content area for:', lab.name);

        // Hide placeholder and show content
        const placeholder = document.getElementById('lab-details-placeholder');
        const content = document.getElementById('lab-details-content');

        if (placeholder) placeholder.style.display = 'none';
        if (content) content.style.display = 'flex';

        // Update lab title and status
        const labNameElement = document.getElementById('selected-lab-name');
        const labStatusElement = document.getElementById('selected-lab-status');

        if (labNameElement) {
            // Ensure lab name is properly displayed, fallback to 'Unknown Lab' if undefined
            const displayName = lab.name || lab.clab_name || 'Unknown Lab';
            labNameElement.textContent = displayName;
            console.log('📋 Setting lab name to:', displayName);
        }

        if (labStatusElement) {
            const runningCount = lab.running_count || 0;
            const totalCount = lab.total_count || 0;
            let status = 'stopped';

            if (runningCount === totalCount && totalCount > 0) {
                status = 'running';
            } else if (runningCount > 0) {
                status = 'partial';
            }

            labStatusElement.textContent = status.charAt(0).toUpperCase() + status.slice(1);
            labStatusElement.className = `lab-status-badge ${status}`;
        }

        // Update statistics
        this.updateLabStatistics(lab);

        // Update containers grid
        this.updateContainersGrid(lab.containers || []);

        // Hide logs section initially
        this.hideLabLogs();
    }

    updateLabStatistics(lab) {
        const totalContainers = document.getElementById('lab-total-containers');
        const runningContainers = document.getElementById('lab-running-containers');
        const uptimeElement = document.getElementById('lab-uptime');

        if (totalContainers) totalContainers.textContent = lab.total_count || 0;
        if (runningContainers) runningContainers.textContent = lab.running_count || 0;

        // Calculate lab uptime from container start times
        if (uptimeElement && lab.containers && lab.containers.length > 0) {
            const uptime = this.calculateLabUptime(lab.containers);
            uptimeElement.textContent = uptime;
        } else if (uptimeElement) {
            uptimeElement.textContent = '-';
        }
    }

    calculateLabUptime(containers) {
        if (!containers || containers.length === 0) return '-';

        // Find the earliest start time among all containers
        let earliestStart = null;

        containers.forEach(container => {
            const startTime = container.start_time || container.created_at || container.uptime;
            if (startTime) {
                try {
                    const start = new Date(startTime);
                    if (!earliestStart || start < earliestStart) {
                        earliestStart = start;
                    }
                } catch (e) {
                    // Ignore invalid dates
                }
            }
        });

        if (earliestStart) {
            const now = new Date();
            const diffMs = now - earliestStart;
            const diffSeconds = Math.floor(diffMs / 1000);
            return this.formatUptimeFromSeconds(diffSeconds);
        }

        return '-';
    }

    hideLabLogs() {
        const logsSection = document.getElementById('logs-section');
        if (logsSection) {
            logsSection.style.display = 'none';
        }
    }

    clearLabsDisplay() {
        const labsList = document.getElementById('labs-list');
        const labsLoading = document.getElementById('labs-loading');
        const noLabsMessage = document.getElementById('no-labs-message');

        if (labsList) labsList.innerHTML = '';
        if (labsLoading) labsLoading.style.display = 'none';
        if (noLabsMessage) noLabsMessage.style.display = 'none';

        this.selectedLab = null;
        this.showLabPlaceholder();
    }

    updateLabStatusInfo(lab) {
        const labStatusInfo = document.getElementById('lab-status-info');
        if (!labStatusInfo) return;

        let statusClass = 'stopped';
        let statusText = 'Stopped';

        if (lab.running_count === lab.total_count && lab.total_count > 0) {
            statusClass = 'running';
            statusText = 'All containers running';
        } else if (lab.running_count > 0) {
            statusClass = 'partial';
            statusText = `${lab.running_count} of ${lab.total_count} containers running`;
        } else {
            statusText = 'All containers stopped';
        }

        labStatusInfo.innerHTML = `
            <div class="lab-status-overview">
                <h4>${lab.name}</h4>
                <div class="lab-status ${statusClass}">${statusText}</div>
                <div class="lab-stats-summary">
                    <span><strong>Total Containers:</strong> ${lab.total_count}</span>
                    <span><strong>Running:</strong> ${lab.running_count}</span>
                    <span><strong>Stopped:</strong> ${lab.total_count - lab.running_count}</span>
                </div>
            </div>
        `;
    }

    updateContainersGrid(containers) {
        const containersGrid = document.getElementById('containers-grid');
        if (!containersGrid) return;

        containersGrid.innerHTML = '';

        if (!containers || containers.length === 0) {
            const emptyMessage = document.createElement('div');
            emptyMessage.className = 'empty-state';
            emptyMessage.style.gridColumn = '1 / -1';
            emptyMessage.style.textAlign = 'center';
            emptyMessage.style.padding = '40px 20px';
            emptyMessage.innerHTML = `
                <div class="empty-icon">
                    <i class="fas fa-cube"></i>
                </div>
                <h4 class="empty-title">NO CONTAINERS</h4>
                <p class="empty-description">This lab has no active containers</p>
            `;
            containersGrid.appendChild(emptyMessage);
            return;
        }

        containers.forEach(container => {
            const containerCard = document.createElement('div');
            containerCard.className = 'container-card';

            // Determine container status for styling
            const status = container.state?.toLowerCase() || container.status?.toLowerCase() || 'unknown';
            const statusDisplay = container.state || container.status || 'Unknown';
            const statusIcon = status === 'running' ? 'fa-play-circle' : 'fa-stop-circle';

            // Get uptime if available from enhanced API
            const uptime = container.uptime || container.start_time || 'N/A';
            const uptimeDisplay = uptime !== 'N/A' ? this.formatUptime(uptime) : 'N/A';

            containerCard.innerHTML = `
                <div class="container-header">
                    <div class="container-name">${container.name || 'Unknown Container'}</div>
                </div>
                <div class="container-details">
                    <div class="detail-row">
                        <span class="detail-label">IMAGE:</span>
                        <span class="detail-value">${container.image || 'N/A'}</span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">KIND:</span>
                        <span class="detail-value">${(container.kind || 'N/A').toUpperCase()}</span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">IPv4:</span>
                        <span class="detail-value">${container.ipv4_address || 'N/A'}</span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">UPTIME:</span>
                        <span class="detail-value">${uptimeDisplay}</span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">STATUS:</span>
                        <div class="container-status ${status}">
                            <i class="fas ${statusIcon}"></i>
                            <span>${statusDisplay.toUpperCase()}</span>
                        </div>
                    </div>
                    </div>

                </div>
                <div class="container-actions">
                    <button class="container-action-btn terminal-btn" data-container="${container.name}" title="Open Terminal">
                        <i class="fas fa-terminal"></i>
                        <span>TERMINAL</span>
                    </button>
                    <button class="container-action-btn logs-btn" data-container="${container.name}" title="View Logs">
                        <i class="fas fa-file-alt"></i>
                        <span>LOGS</span>
                    </button>
                    <button class="container-action-btn stop-btn" data-container="${container.name}" title="Stop Container">
                        <i class="fas fa-stop"></i>
                        <span>STOP</span>
                    </button>
                </div>
            `;

            // Add event listeners for container action buttons
            const terminalBtn = containerCard.querySelector('.terminal-btn');
            const logsBtn = containerCard.querySelector('.logs-btn');
            const stopBtn = containerCard.querySelector('.stop-btn');

            terminalBtn.addEventListener('click', () => {
                this.openContainerTerminal(container.name);
            });

            logsBtn.addEventListener('click', () => {
                this.viewContainerLogs(container.name);
            });

            stopBtn.addEventListener('click', () => {
                this.stopContainer(container.name);
            });

            containersGrid.appendChild(containerCard);
        });
    }

    formatUptime(uptime) {
        if (!uptime || uptime === 'N/A') return 'N/A';

        // Handle different uptime formats
        if (typeof uptime === 'string') {
            // If it's already formatted, return as is
            if (uptime.includes('d') || uptime.includes('h') || uptime.includes('m')) {
                return uptime;
            }
            // Try to parse as timestamp
            try {
                const startTime = new Date(uptime);
                const now = new Date();
                const diffMs = now - startTime;
                const diffSeconds = Math.floor(diffMs / 1000);
                return this.formatUptimeFromSeconds(diffSeconds);
            } catch (e) {
                return uptime;
            }
        } else if (typeof uptime === 'number') {
            return this.formatUptimeFromSeconds(uptime);
        }

        return 'N/A';
    }

    formatUptimeFromSeconds(seconds) {
        const days = Math.floor(seconds / 86400);
        const hours = Math.floor((seconds % 86400) / 3600);
        const minutes = Math.floor((seconds % 3600) / 60);

        if (days > 0) {
            return `${days}d ${hours}h ${minutes}m`;
        } else if (hours > 0) {
            return `${hours}h ${minutes}m`;
        } else {
            return `${minutes}m`;
        }
    }

    async openContainerTerminal(containerName) {
        if (!this.selectedLab) {
            console.warn('⚠️ No lab selected for terminal access');
            return;
        }

        try {
            // Get the server ID from the lab's server configuration
            const serverId = this.selectedLab.server_id || this.selectedServerId;
            
            console.log('🔍 Opening terminal for container:', containerName);
            console.log('🔍 Selected lab:', this.selectedLab);
            console.log('🔍 Lab server_id:', this.selectedLab.server_id);
            console.log('🔍 Selected server ID:', this.selectedServerId);
            console.log('🔍 Using server ID:', serverId);
            
            if (!serverId) {
                console.warn('⚠️ No server ID available for terminal access');
                alert('Server configuration not available. Please refresh the page.');
                return;
            }

            // Use the existing terminal manager to open terminal for this container
            if (window.terminalManager) {
                await window.terminalManager.openTerminal(serverId, this.selectedLab.name, containerName);
            } else {
                console.error('Terminal manager not available');
                alert('Terminal functionality not available. Please refresh the page.');
            }
        } catch (error) {
            console.error('Error opening terminal:', error);
            alert(`Error opening terminal: ${error.message}`);
        }
    }

    async viewContainerLogs(containerName) {
        if (!this.selectedLab) {
            console.warn('⚠️ No lab selected for viewing logs');
            return;
        }

        try {
            // Get the server ID from the lab's server configuration
            const serverId = this.selectedLab.server_id || this.selectedServerId;
            
            if (!serverId) {
                console.warn('⚠️ No server ID available for viewing logs');
                alert('Server configuration not available. Please refresh the page.');
                return;
            }

            const response = await fetch(`/plugins/digital-twin/servers/${serverId}/labs/${this.selectedLab.name}/logs/`);
            const data = await response.json();

            if (data.success && data.container_logs) {
                // Show logs in a dedicated container logs section
                this.showContainerLogs(containerName, data.container_logs[containerName] || {});
            } else {
                alert(`Failed to load logs: ${data.error || 'Unknown error'}`);
            }
        } catch (error) {
            console.error('Error loading container logs:', error);
            alert(`Error loading logs: ${error.message}`);
        }
    }

    showContainerLogs(containerName, logs) {
        // Create or update container logs section
        let containerLogsSection = document.getElementById('container-logs-section');
        if (!containerLogsSection) {
            containerLogsSection = document.createElement('div');
            containerLogsSection.id = 'container-logs-section';
            containerLogsSection.className = 'container-logs-section';

            // Insert after containers section
            const containersSection = document.querySelector('.containers-section');
            if (containersSection) {
                containersSection.parentNode.insertBefore(containerLogsSection, containersSection.nextSibling);
            }
        }

        containerLogsSection.innerHTML = `
            <div class="section-header container-logs-header">
                <h3 class="section-title">
                    <i class="fas fa-terminal"></i>
                    CONTAINER LOGS - ${containerName.toUpperCase()}
                </h3>
                <button class="hide-container-logs-btn" id="hide-container-logs-btn">
                    <i class="fas fa-times"></i>
                    <span>HIDE LOGS</span>
                </button>
            </div>
            <div class="container-logs-container" id="container-logs-container">
                ${this.formatContainerLogs(logs)}
            </div>
        `;

        // Add event listener for hide button
        const hideBtn = containerLogsSection.querySelector('#hide-container-logs-btn');
        hideBtn.addEventListener('click', () => {
            containerLogsSection.remove();
        });

        // Show the section
        containerLogsSection.style.display = 'block';
    }

    formatContainerLogs(logs) {
        if (!logs || (logs.error && !logs.stdout && !logs.stderr)) {
            return '<div class="text-muted">No logs available for this container</div>';
        }

        let logsHtml = '';

        if (logs.error) {
            logsHtml += `<div class="text-danger"><strong>ERROR:</strong> ${logs.error}</div>`;
        }

        if (logs.stdout) {
            logsHtml += `<div class="log-section"><strong>STDOUT:</strong><pre class="log-content">${logs.stdout}</pre></div>`;
        }

        if (logs.stderr) {
            logsHtml += `<div class="log-section"><strong>STDERR:</strong><pre class="log-content">${logs.stderr}</pre></div>`;
        }

        return logsHtml;
    }

    async stopContainer(containerName) {
        if (!this.selectedLab || !this.selectedServerId) {
            console.warn('⚠️ No lab selected for stopping container');
            return;
        }

        if (!confirm(`Are you sure you want to stop container "${containerName}"?`)) {
            return;
        }

        try {
            // For now, we'll stop the entire lab since individual container stop isn't implemented
            // In the future, this could be enhanced to stop individual containers
            alert('Individual container stop is not yet implemented. Stopping the entire lab instead.');
            await this.stopCurrentLab();
        } catch (error) {
            console.error('Error stopping container:', error);
            alert(`Error stopping container: ${error.message}`);
        }
    }

    // Method removed - lab details now integrated into main modal

    async stopCurrentLab() {
        if (!this.selectedLab || !this.selectedServerId) {
            console.warn('⚠️ No lab selected for stopping');
            return;
        }

        const lab = this.selectedLab;
        const serverId = this.selectedServerId;

        // Show confirmation
        if (!confirm(`Are you sure you want to stop lab "${lab.name}"? This will stop all containers in the lab.`)) {
            return;
        }

        try {
            StatusManager.showProgress('Stopping Lab', `Stopping lab "${lab.name}"...`);

            const response = await fetch(`/plugins/digital-twin/servers/${serverId}/labs/${lab.name}/stop/`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRFToken': getCookie('csrftoken')
                }
            });

            const data = await response.json();

            if (data.success) {
                StatusManager.hideProgress();
                alert(`Lab "${lab.name}" stopped successfully!`);

                // Refresh lab details
                this.refreshCurrentLabDetails();

                // Clear cache to force refresh
                this.activeLabsCache.delete(serverId);

                // Refresh main lab list
                this.loadActiveLabs(serverId, true);

            } else {
                StatusManager.setProgressError('Failed to stop lab: ' + data.error);
                setTimeout(() => StatusManager.hideProgress(), 3000);
            }
        } catch (error) {
            console.error('Error stopping lab:', error);
            StatusManager.setProgressError('Error stopping lab: ' + error.message);
            setTimeout(() => StatusManager.hideProgress(), 3000);
        }
    }

    async viewCurrentLabLogs() {
        if (!this.selectedLab || !this.selectedServerId) {
            console.warn('⚠️ No lab selected for viewing logs');
            return;
        }

        const lab = this.selectedLab;
        const serverId = this.selectedServerId;
        const logsSection = document.getElementById('logs-section');
        const labLogsContainer = document.getElementById('lab-logs-container');

        if (!logsSection || !labLogsContainer) return;

        // Show logs section
        logsSection.style.display = 'block';
        labLogsContainer.innerHTML = '<div class="loading-state"><i class="fas fa-spinner fa-spin"></i> Loading logs...</div>';

        try {
            const response = await fetch(`/plugins/digital-twin/servers/${serverId}/labs/${lab.name}/logs/`);
            const data = await response.json();

            if (data.success) {
                this.displayLabLogs(data.container_logs || {});
            } else {
                labLogsContainer.innerHTML = `<div class="text-danger">Failed to load logs: ${data.error}</div>`;
            }
        } catch (error) {
            console.error('Error loading lab logs:', error);
            labLogsContainer.innerHTML = `<div class="text-danger">Error loading logs: ${error.message}</div>`;
        }
    }

    displayLabLogs(containerLogs) {
        const labLogsContainer = document.getElementById('lab-logs-container');
        if (!labLogsContainer) return;

        if (!containerLogs || Object.keys(containerLogs).length === 0) {
            labLogsContainer.innerHTML = '<div class="text-muted">No logs available</div>';
            return;
        }

        let logsHtml = '';

        Object.entries(containerLogs).forEach(([containerName, logs]) => {
            logsHtml += `
                <div class="container-logs">
                    <div class="container-logs-header">${containerName}</div>
                    <div class="container-logs-content">`;

            if (logs.error) {
                logsHtml += `<div class="text-danger">${logs.error}</div>`;
            } else {
                if (logs.stdout) {
                    logsHtml += `<strong>STDOUT:</strong>\n${logs.stdout}\n\n`;
                }
                if (logs.stderr) {
                    logsHtml += `<strong>STDERR:</strong>\n${logs.stderr}`;
                }
            }

            logsHtml += `</div></div>`;
        });

        labLogsContainer.innerHTML = logsHtml;
    }

    async refreshCurrentLabDetails() {
        if (!this.selectedLab || !this.selectedServerId) {
            console.warn('⚠️ No lab selected for refresh');
            return;
        }

        console.log('🔄 Refreshing current lab details');

        try {
            // Reload labs to get fresh data
            await this.loadActiveLabs(this.selectedServerId, true);

            // Find the updated lab data
            const cachedData = this.activeLabsCache.get(this.selectedServerId);
            if (cachedData && cachedData.labs) {
                const updatedLab = cachedData.labs.find(lab => lab.name === this.selectedLab.name);
                if (updatedLab) {
                    // Update the selected lab and refresh display
                    this.selectedLab = updatedLab;
                    this.showLabDetailsInContent(updatedLab);

                    // Update the sidebar selection to reflect the refreshed data
                    const labItems = document.querySelectorAll('.lab-list-item');
                    labItems.forEach(item => {
                        if (item.getAttribute('data-lab-name') === updatedLab.name) {
                            item.classList.add('selected');
                        } else {
                            item.classList.remove('selected');
                        }
                    });
                } else {
                    console.warn('⚠️ Lab no longer exists:', this.selectedLab.name);
                    this.showLabPlaceholder();
                    this.selectedLab = null;
                }
            }
        } catch (error) {
            console.error('❌ Error refreshing lab details:', error);
            this.showError(`Failed to refresh lab details: ${error.message}`);
        }
    }

    showError(message) {
        console.error('❌ LabManager Error:', message);

        // Show error in the labs list area
        const labsList = document.getElementById('labs-list');
        const labsLoading = document.getElementById('labs-loading');
        const noLabsMessage = document.getElementById('no-labs-message');

        if (labsLoading) labsLoading.style.display = 'none';
        if (noLabsMessage) noLabsMessage.style.display = 'none';

        if (labsList) {
            labsList.innerHTML = `
                <div class="empty-state" style="color: #e74c3c;">
                    <i class="fas fa-exclamation-triangle"></i>
                    <p>${message}</p>
                </div>
            `;
        }
    }

    cleanup() {
        // Clear any cached data
        this.activeLabsCache.clear();
        this.selectedLab = null;
        this.selectedServerId = null;

        // Reset UI to initial state
        this.showLabPlaceholder();
        this.clearLabsDisplay();

        console.log('🧹 LabManager cleanup completed');
    }

    async openDeviceTerminal(lab) {
        try {
            if (!this.selectedServerId) {
                alert('Please select a server first');
                return;
            }

            // Get containers for the lab
            const containers = lab.containers || [];
            if (containers.length === 0) {
                alert('No devices found in this lab');
                return;
            }

            // Create device selection modal
            const deviceSelectionModal = document.createElement('div');
            deviceSelectionModal.className = 'modal fade';
            deviceSelectionModal.innerHTML = `
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title">
                                <i class="fas fa-terminal"></i>
                                Select Device for Terminal
                            </h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <p>Select a device to open terminal access:</p>
                            <div class="device-list">
                                ${containers.map(container => {
                const state = container.state || container.status || 'unknown';
                const isRunning = state === 'running';
                return `
                                        <div class="device-item ${isRunning ? 'running' : 'not-running'}" data-device="${container.name}">
                                            <i class="fas fa-server"></i>
                                            <span class="device-name">${container.name}</span>
                                            <span class="device-status ${state}">${state}</span>
                                        </div>
                                    `;
            }).join('')}
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        </div>
                    </div>
                </div>
            `;

            // Add modal to page
            document.body.appendChild(deviceSelectionModal);

            // Setup device selection
            const deviceItems = deviceSelectionModal.querySelectorAll('.device-item');
            deviceItems.forEach(item => {
                item.addEventListener('click', () => {
                    const deviceName = item.getAttribute('data-device');
                    const container = containers.find(c => c.name === deviceName);

                    if (container) {
                        // Check both 'state' and 'status' properties for running status
                        const isRunning = container.state === 'running' || container.status === 'running';

                        if (isRunning) {
                            // Open terminal for this device
                            window.topologyEditor.terminalManager.openTerminal(
                                this.selectedServerId,
                                lab.name,
                                deviceName
                            );
                            // Hide modal using Bootstrap 5 native API
                            const modal = bootstrap.Modal.getInstance(deviceSelectionModal);
                            if (modal) {
                                modal.hide();
                            }
                        } else {
                            const currentState = container.state || container.status || 'unknown';
                            alert(`Device ${deviceName} is not running (current state: ${currentState})`);
                        }
                    } else {
                        alert(`Device ${deviceName} not found in lab`);
                    }
                });
            });

            // Show modal using Bootstrap 5 native API
            const modal = new bootstrap.Modal(deviceSelectionModal);
            modal.show();

            // Cleanup modal when hidden
            deviceSelectionModal.addEventListener('hidden.bs.modal', () => {
                document.body.removeChild(deviceSelectionModal);
            });

        } catch (error) {
            console.error('Error opening device terminal:', error);
            alert(`Failed to open terminal: ${error.message}`);
        }
    }
}

// Initialize application
document.addEventListener('DOMContentLoaded', async function () {
    try {
        window.topologyEditor = new TopologyEditor();
        window.labManager = new LabManager();
        window.configUploadManager = new ConfigurationUploadManager();

        // Initialize lab manager after topology editor
        await window.labManager.initialize();

        // Initialize configuration upload manager
        window.configUploadManager.initialize();

        console.log('Digital Twin application initialized successfully');
    } catch (error) {
        console.error('Failed to initialize Digital Twin application:', error);
        console.error('Stack trace:', error.stack);
    }
});

// Device Configuration Manager Class
class ConfigurationUploadManager {
    constructor() {
        this.modal = null;
        this.editorModal = null;
        this.previewModal = null;
        this.devices = [];
        this.deviceConfigs = {};
        this.currentDeploymentId = null;
        this.currentDevice = null;

        console.log('Device Configuration Manager initialized');
    }

    initialize() {
        try {
            // Get modal elements
            this.modal = document.getElementById('config-upload-modal');
            this.editorModal = document.getElementById('config-editor-modal');
            this.previewModal = document.getElementById('config-preview-modal');

            if (!this.modal) {
                console.error('Configuration manager modal not found');
                return;
            }

            this.setupEventListeners();

            console.log('Device Configuration Manager setup complete');
        } catch (error) {
            console.error('Error initializing Device Configuration Manager:', error);
        }
    }

    setupEventListeners() {
        // Upload button in toolbar (now "Manage Configs")
        const uploadBtn = document.getElementById('upload-configs-btn');
        if (uploadBtn) {
            uploadBtn.addEventListener('click', () => this.showConfigManagerModal());
        }

        // Main modal controls
        const closeBtn = document.getElementById('config-upload-close-btn');
        const cancelBtn = document.getElementById('config-cancel-btn');
        const refreshBtn = document.getElementById('refresh-devices-btn');

        if (closeBtn) closeBtn.addEventListener('click', () => this.hideConfigManagerModal());
        if (cancelBtn) cancelBtn.addEventListener('click', () => this.hideConfigManagerModal());
        if (refreshBtn) refreshBtn.addEventListener('click', () => this.refreshDevices());

        // Editor modal controls
        const editorCloseBtn = document.getElementById('config-editor-close-btn');
        const editorCancelBtn = document.getElementById('config-editor-cancel-btn');
        const saveConfigBtn = document.getElementById('save-device-config-btn');
        const loadSampleBtn = document.getElementById('load-sample-config');
        const clearConfigBtn = document.getElementById('clear-config');

        if (editorCloseBtn) editorCloseBtn.addEventListener('click', () => this.hideEditorModal());
        if (editorCancelBtn) editorCancelBtn.addEventListener('click', () => this.hideEditorModal());
        if (saveConfigBtn) saveConfigBtn.addEventListener('click', () => this.saveDeviceConfiguration());
        if (loadSampleBtn) loadSampleBtn.addEventListener('click', () => this.loadSampleConfiguration());
        if (clearConfigBtn) clearConfigBtn.addEventListener('click', () => this.clearConfiguration());

        // Preview modal controls
        const previewCloseBtn = document.getElementById('config-preview-close-btn');
        const previewOkBtn = document.getElementById('config-preview-ok-btn');

        if (previewCloseBtn) previewCloseBtn.addEventListener('click', () => this.hidePreviewModal());
        if (previewOkBtn) previewOkBtn.addEventListener('click', () => this.hidePreviewModal());

        // Modal backdrop clicks
        if (this.modal) {
            this.modal.addEventListener('click', (e) => {
                if (e.target === this.modal) this.hideConfigManagerModal();
            });
        }

        if (this.editorModal) {
            this.editorModal.addEventListener('click', (e) => {
                if (e.target === this.editorModal) this.hideEditorModal();
            });
        }

        if (this.previewModal) {
            this.previewModal.addEventListener('click', (e) => {
                if (e.target === this.previewModal) this.hidePreviewModal();
            });
        }
    }

    async showConfigManagerModal() {
        console.log('🚀 Opening Device Configuration Manager...');

        if (!this.modal) {
            console.error('❌ Modal not found!');
            return;
        }

        // Generate deployment ID
        this.currentDeploymentId = 'config_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);

        console.log('🆔 Generated deployment ID:', this.currentDeploymentId);

        // Show modal
        this.modal.style.display = 'flex';
        document.body.style.overflow = 'hidden';

        console.log('✅ Modal displayed, loading devices...');

        // Load devices from current YAML
        await this.loadDevicesFromYAML();

        console.log('🏁 Device Configuration Manager setup complete');
    }

    hideConfigManagerModal() {
        if (!this.modal) return;

        this.modal.style.display = 'none';
        document.body.style.overflow = '';

        console.log('Device Configuration Manager closed');
    }

    showEditorModal(device) {
        if (!this.editorModal || !device) return;

        this.currentDevice = device;

        // Ensure device has proper structure - handle both object and string cases
        const deviceObj = typeof device === 'string'
            ? this.devices.find(d => d.name === device) || { name: device, kind: 'Unknown', image: 'Not specified' }
            : device;

        // Update editor modal title and device info
        const title = document.getElementById('config-editor-title');
        const deviceName = document.getElementById('editor-device-name');
        const deviceKind = document.getElementById('editor-device-kind');
        const deviceImage = document.getElementById('editor-device-image');
        const configEditor = document.getElementById('config-content-editor');

        if (title) title.textContent = `CONFIGURE ${deviceObj.name.toUpperCase()}`;
        if (deviceName) deviceName.textContent = deviceObj.name;
        if (deviceKind) deviceKind.textContent = deviceObj.kind || 'Unknown';
        if (deviceImage) deviceImage.textContent = deviceObj.image || 'Not specified';

        // Load existing configuration if any
        if (configEditor) {
            const existingConfig = this.deviceConfigs[deviceObj.name];
            // Handle both string and object formats
            if (typeof existingConfig === 'object' && existingConfig.configuration) {
                configEditor.value = existingConfig.configuration;
            } else if (typeof existingConfig === 'string') {
                configEditor.value = existingConfig;
            } else {
                configEditor.value = '';
            }
        }

        // Show editor modal
        this.editorModal.style.display = 'flex';
        document.body.style.overflow = 'hidden';

        // Focus on textarea
        if (configEditor) {
            setTimeout(() => configEditor.focus(), 100);
        }

        console.log('Configuration editor opened for device:', deviceObj.name);
    }

    hideEditorModal(force = false) {
        if (!this.editorModal) return;

        // Check for unsaved changes unless forced
        if (!force && this.hasUnsavedChanges()) {
            const confirmed = confirm('You have unsaved changes. Are you sure you want to close without saving?');
            if (!confirmed) return;
        }

        // Clear the editor content
        const configEditor = document.getElementById('config-content-editor');
        if (configEditor) {
            configEditor.value = '';
        }

        this.editorModal.style.display = 'none';
        document.body.style.overflow = '';
        this.currentDevice = null;

        console.log('Configuration editor closed');
    }

    hasUnsavedChanges() {
        if (!this.currentDevice) return false;

        const configEditor = document.getElementById('config-content-editor');
        if (!configEditor) return false;

        const deviceObj = typeof this.currentDevice === 'string'
            ? this.devices.find(d => d.name === this.currentDevice) || { name: this.currentDevice }
            : this.currentDevice;

        const currentContent = configEditor.value.trim();
        const savedContent = this.deviceConfigs[deviceObj.name] || '';

        return currentContent !== savedContent;
    }

    showPreviewModal() {
        if (!this.previewModal) return;

        this.previewModal.style.display = 'flex';
        document.body.style.overflow = 'hidden';
    }

    hidePreviewModal() {
        if (!this.previewModal) return;

        this.previewModal.style.display = 'none';
        document.body.style.overflow = '';
    }

    async loadDevicesFromYAML() {
        try {
            // Show loading progress
            this.showProgress('Loading devices from topology...');

            // Get current YAML content from global editor
            if (!globalEditor) {
                console.warn('YAML editor not available');
                this.hideProgress();
                this.showNoDevicesMessage();
                return;
            }

            const yamlContent = globalEditor.getValue();
            if (!yamlContent.trim()) {
                console.warn('No YAML content available');
                this.hideProgress();
                this.showNoDevicesMessage();
                return;
            }

            // Get selected server
            const serverSelector = document.getElementById('server-selector');
            const serverId = serverSelector ? serverSelector.value : 'local';

            console.log('🔍 Extracting devices from YAML...', { serverId, yamlLength: yamlContent.length });

            // Call API to extract devices
            const response = await fetch('/plugins/digital-twin/get-devices-from-yaml/', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRFToken': getCookie('csrftoken')
                },
                body: JSON.stringify({
                    yaml_content: yamlContent,
                    server_id: serverId
                })
            });

            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }

            const result = await response.json();

            if (result.status === 'success') {
                this.devices = result.devices || [];
                console.log('✅ Loaded devices:', this.devices);

                // Force refresh configuration status for each device
                await this.refreshAllDeviceConfigurations();

                this.hideProgress();
                this.displayDevices();
                this.updateDeviceStats();
            } else {
                throw new Error(result.error || 'Failed to extract devices');
            }

        } catch (error) {
            console.error('Error loading devices from YAML:', error);
            this.hideProgress();
            this.showError(`Failed to load devices from topology: ${error.message}`);
            this.showNoDevicesMessage();
        }
    }

    async refreshDevices() {
        await this.loadDevicesFromYAML();
    }

    async refreshAllDeviceConfigurations() {
        if (!this.devices || this.devices.length === 0) {
            console.log('🔄 No devices to refresh configurations for');
            return;
        }

        console.log('🔄 Refreshing configuration status for all devices...');
        this.showProgress('Syncing device configurations...');

        const serverSelector = document.getElementById('server-selector');
        const serverId = serverSelector ? serverSelector.value : 'local';

        try {
            // Clear existing device configs
            this.deviceConfigs = {};

            // Update each device's configuration status
            const promises = this.devices.map(async (device) => {
                try {
                    const response = await fetch(`/plugins/digital-twin/get-device-config-live/${device.name}/?server_id=${serverId}`, {
                        method: 'GET',
                        headers: {
                            'X-CSRFToken': getCookie('csrftoken')
                        }
                    });

                    if (response.ok) {
                        const result = await response.json();
                        if (result.status === 'success') {
                            const hasConfig = !!(result.configuration && result.configuration.trim());

                            // Update device object
                            device.has_saved_config = hasConfig;
                            device.config_size = result.configuration ? result.configuration.length : 0;
                            device.config_timestamp = result.timestamp;
                            device.config_source = result.source;

                            // Update deviceConfigs for UI display
                            if (hasConfig) {
                                this.deviceConfigs[device.name] = {
                                    configuration: result.configuration,
                                    timestamp: result.timestamp,
                                    size: result.configuration.length,
                                    source: result.source
                                };
                            }

                            console.log(`✅ Updated config status for ${device.name}: ${hasConfig ? 'HAS CONFIG' : 'NO CONFIG'} (${result.source})`);
                            return { device: device.name, hasConfig, size: device.config_size };
                        }
                    }

                    // If request failed, mark as no config
                    device.has_saved_config = false;
                    device.config_size = 0;
                    return { device: device.name, hasConfig: false, size: 0 };

                } catch (error) {
                    console.warn(`⚠️ Could not refresh config status for ${device.name}:`, error);
                    device.has_saved_config = false;
                    device.config_size = 0;
                    return { device: device.name, hasConfig: false, size: 0, error: error.message };
                }
            });

            const results = await Promise.all(promises);

            // Update UI
            this.displayDevices();
            this.updateDeviceStats();

            // Show summary
            const configuredCount = results.filter(r => r.hasConfig).length;
            const totalSize = results.reduce((sum, r) => sum + (r.size || 0), 0);

            this.hideProgress();
            // this.showSuccess(`Configuration sync completed: ${configuredCount}/${this.devices.length} devices configured (${this.formatFileSize(totalSize)} total)`);

            console.log('✅ Configuration status refresh completed', {
                total: this.devices.length,
                configured: configuredCount,
                totalSize: this.formatFileSize(totalSize)
            });

        } catch (error) {
            this.hideProgress();
            this.showError(`Failed to sync configurations: ${error.message}`);
            console.error('❌ Error refreshing device configurations:', error);
        }
    }

    displayDevices() {
        const devicesGrid = document.getElementById('devices-grid');
        const noDevicesMessage = document.getElementById('no-devices-message');

        if (!devicesGrid) return;

        // Clear existing content
        devicesGrid.innerHTML = '';

        if (this.devices.length === 0) {
            this.showNoDevicesMessage();
            return;
        }

        // Hide no devices message
        if (noDevicesMessage) {
            noDevicesMessage.style.display = 'none';
        }

        // Create device cards
        this.devices.forEach(device => {
            const deviceCard = this.createDeviceCard(device);
            devicesGrid.appendChild(deviceCard);
        });
    }

    createDeviceCard(device) {
        const hasConfig = this.deviceConfigs[device.name];
        const cardElement = document.createElement('div');
        cardElement.className = `device-card ${hasConfig ? 'configured' : ''}`;

        cardElement.innerHTML = `
            <div class="device-header">
                <h4 class="device-name">${device.name}</h4>
                <span class="device-status ${hasConfig ? 'configured' : 'unconfigured'}">
                    ${hasConfig ? 'Configured' : 'No Config'}
                </span>
            </div>
            <div class="device-details">
                <div class="device-details-row">
                    <span>Type:</span>
                    <span>${device.kind || 'Unknown'}</span>
                </div>
                <div class="device-details-row">
                    <span>Image:</span>
                    <span>${device.image ? device.image.split('/').pop() : 'Not set'}</span>
                </div>
                <div class="device-details-row">
                    <span>Startup Config:</span>
                    <span>${device.has_startup_config ? 'Yes' : 'No'}</span>
                </div>
            </div>
            <div class="device-actions">
                <button class="device-action-btn primary configure-btn" data-device="${device.name}">
                    <i class="fas fa-edit"></i>
                    ${hasConfig ? 'Edit Config' : 'Add Config'}
                </button>
                ${hasConfig ? `
                    <button class="device-action-btn preview-btn" data-device="${device.name}">
                        <i class="fas fa-eye"></i>
                        Preview
                    </button>
                    <button class="device-action-btn remove-btn" data-device="${device.name}">
                        <i class="fas fa-trash"></i>
                        Remove
                    </button>
                ` : ''}
            </div>
        `;

        // Add event listeners
        const configureBtn = cardElement.querySelector('.configure-btn');
        const previewBtn = cardElement.querySelector('.preview-btn');
        const removeBtn = cardElement.querySelector('.remove-btn');

        if (configureBtn) {
            configureBtn.addEventListener('click', () => this.showEditorModal(device));
        }

        if (previewBtn) {
            previewBtn.addEventListener('click', () => this.previewDeviceConfiguration(device));
        }

        if (removeBtn) {
            removeBtn.addEventListener('click', () => this.removeDeviceConfiguration(device));
        }

        return cardElement;
    }

    showNoDevicesMessage() {
        const devicesGrid = document.getElementById('devices-grid');
        const noDevicesMessage = document.getElementById('no-devices-message');

        console.log('📝 Showing no devices message', { devicesGrid: !!devicesGrid, noDevicesMessage: !!noDevicesMessage });

        if (devicesGrid) {
            devicesGrid.innerHTML = '';
        }

        if (noDevicesMessage) {
            noDevicesMessage.style.display = 'block';
        }
    }

    displayDevices() {
        const devicesGrid = document.getElementById('devices-grid');
        const noDevicesMessage = document.getElementById('no-devices-message');

        console.log('🏗️ Displaying devices', {
            devicesCount: this.devices.length,
            devicesGrid: !!devicesGrid,
            noDevicesMessage: !!noDevicesMessage,
            devices: this.devices
        });

        if (!devicesGrid) {
            console.error('❌ Devices grid element not found!');
            return;
        }

        // Clear existing content
        devicesGrid.innerHTML = '';

        if (this.devices.length === 0) {
            this.showNoDevicesMessage();
            return;
        }

        // Hide no devices message
        if (noDevicesMessage) {
            noDevicesMessage.style.display = 'none';
        }

        // Create device cards
        this.devices.forEach(device => {
            const deviceCard = this.createDeviceCard(device);
            devicesGrid.appendChild(deviceCard);
        });

        console.log('✅ Device cards created and added to grid');
    }

    updateDeviceStats() {
        const totalDevicesEl = document.getElementById('total-devices');
        const configuredDevicesEl = document.getElementById('configured-devices');

        const totalDevices = this.devices.length;
        const configuredDevices = Object.keys(this.deviceConfigs).length;

        if (totalDevicesEl) totalDevicesEl.textContent = totalDevices;
        if (configuredDevicesEl) configuredDevicesEl.textContent = configuredDevices;
    }

    async saveDeviceConfiguration() {
        if (!this.currentDevice) return;

        const configEditor = document.getElementById('config-content-editor');
        if (!configEditor) return;

        const configContent = configEditor.value.trim();

        if (!configContent) {
            this.showError('Please enter configuration content');
            return;
        }

        // Ensure device has proper structure
        const deviceObj = typeof this.currentDevice === 'string'
            ? this.devices.find(d => d.name === this.currentDevice) || { name: this.currentDevice }
            : this.currentDevice;

        try {
            // Show progress with better UX
            this.showProgress('Saving configuration...');

            // Disable save button to prevent double-clicks
            const saveBtn = document.getElementById('save-device-config-btn');
            if (saveBtn) {
                saveBtn.disabled = true;
                saveBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Saving...';
            }

            // Get selected server
            const serverSelector = document.getElementById('server-selector');
            const serverId = serverSelector ? serverSelector.value : 'local';

            // Use same API endpoint as device details modal for consistency
            const response = await fetch('/plugins/digital-twin/save-device-config-live/', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRFToken': getCookie('csrftoken')
                },
                body: JSON.stringify({
                    device_name: deviceObj.name,
                    configuration: configContent,
                    server_id: serverId
                })
            });

            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }

            const result = await response.json();

            if (result.status === 'success') {
                // Store configuration locally
                this.deviceConfigs[deviceObj.name] = configContent;

                this.hideProgress();
                this.hideEditorModal(true); // Force close since we just saved

                // Refresh device display
                this.displayDevices();
                this.updateDeviceStats();

                console.log('Configuration saved successfully:', result);
            } else {
                throw new Error(result.error || 'Failed to save configuration');
            }

        } catch (error) {
            console.error('Error saving configuration:', error);
            this.hideProgress();
            this.showError(`Failed to save configuration: ${error.message}`);
        } finally {
            // Re-enable save button
            const saveBtn = document.getElementById('save-device-config-btn');
            if (saveBtn) {
                saveBtn.disabled = false;
                saveBtn.innerHTML = '<i class="fas fa-save"></i> Save Configuration';
            }
        }
    }

    loadSampleConfiguration() {
        if (!this.currentDevice) return;

        const configEditor = document.getElementById('config-content-editor');
        if (!configEditor) return;

        // Ensure device has proper structure
        const deviceObj = typeof this.currentDevice === 'string'
            ? this.devices.find(d => d.name === this.currentDevice) || { name: this.currentDevice, kind: 'Unknown' }
            : this.currentDevice;

        // Load sample configuration based on device kind
        const deviceKind = deviceObj.kind?.toLowerCase() || '';
        let sampleConfig = '';

        if (deviceKind.includes('router') || deviceKind.includes('cisco')) {
            sampleConfig = `! Sample Cisco Router Configuration
! ${deviceObj.name}
!
version 15.2
service timestamps debug datetime msec
service timestamps log datetime msec
!
hostname ${deviceObj.name}
!
enable secret 5 $1$D4k2$8JxbF3a8z9K7l6Nm5Pq8w1
!
interface GigabitEthernet0/0
 description WAN Connection
 ip address 192.168.1.1 255.255.255.0
 duplex auto
 speed auto
 no shutdown
!
interface GigabitEthernet0/1
 description LAN Connection
 ip address 10.0.1.1 255.255.255.0
 duplex auto
 speed auto
 no shutdown
!
router ospf 1
 log-adjacency-changes
 network 10.0.1.0 0.0.0.255 area 0
!
ip route 0.0.0.0 0.0.0.0 192.168.1.254
!
end`;
        } else if (deviceKind.includes('switch')) {
            sampleConfig = `! Sample Cisco Switch Configuration
! ${deviceObj.name}
!
version 12.2
!
hostname ${deviceObj.name}
!
enable secret 5 $1$D4k2$8JxbF3a8z9K7l6Nm5Pq8w1
!
vlan 10
 name USERS
!
vlan 20
 name SERVERS
!
interface FastEthernet0/1
 description User Port
 switchport access vlan 10
 switchport mode access
 spanning-tree portfast
!
interface GigabitEthernet0/1
 description Uplink
 switchport mode trunk
 switchport trunk allowed vlan 10,20
!
end`;
        } else if (deviceKind.includes('linux') || deviceKind.includes('ubuntu')) {
            sampleConfig = `# Sample Linux Configuration
# ${deviceObj.name}

# Network Configuration
auto eth0
iface eth0 inet static
address 192.168.1.100
netmask 255.255.255.0
gateway 192.168.1.1
dns-nameservers 8.8.8.8 8.8.4.4

# SSH Configuration
Port 22
PermitRootLogin no
PasswordAuthentication yes
PubkeyAuthentication yes

# System Configuration
echo "${deviceObj.name}" > /etc/hostname
systemctl enable ssh
systemctl start ssh

# End of Configuration`;
        } else {
            sampleConfig = `# Sample Configuration for ${deviceObj.name}
# Device Type: ${deviceObj.kind}

# Basic Configuration
hostname ${deviceObj.name}

# Interface Configuration
# Add your interface configurations here

# Routing Configuration
# Add your routing configurations here

# End of Configuration`;
        }

        configEditor.value = sampleConfig;
        configEditor.focus();

        console.log('Sample configuration loaded for device:', deviceObj.name);
    }

    clearConfiguration() {
        const configEditor = document.getElementById('config-content-editor');
        if (configEditor) {
            configEditor.value = '';
            configEditor.focus();
        }
    }

    async previewDeviceConfiguration(device) {
        // Ensure device has proper structure
        const deviceObj = typeof device === 'string'
            ? this.devices.find(d => d.name === device) || { name: device }
            : device;

        const configContent = this.deviceConfigs[deviceObj.name];
        if (!configContent) {
            this.showError('No configuration found for this device');
            return;
        }

        this.showConfigurationPreview({
            node_name: deviceObj.name,
            content: configContent,
            size: configContent.length,
            lines: configContent.split('\n').length
        });
    }

    async removeDeviceConfiguration(device) {
        // Ensure device has proper structure
        const deviceObj = typeof device === 'string'
            ? this.devices.find(d => d.name === device) || { name: device }
            : device;

        if (confirm(`Remove configuration for ${deviceObj.name}?`)) {
            delete this.deviceConfigs[deviceObj.name];

            // Refresh device display
            this.displayDevices();
            this.updateDeviceStats();

            console.log('Configuration removed for device:', deviceObj.name);
        }
    }

    showProgress(message) {
        const progressSection = document.getElementById('upload-progress');
        const progressText = document.getElementById('upload-progress-text');

        if (progressSection) progressSection.style.display = 'block';
        if (progressText) progressText.textContent = message;
    }

    hideProgress() {
        const progressSection = document.getElementById('upload-progress');
        if (progressSection) progressSection.style.display = 'none';
    }

    showSuccess(message) {
        if (window.topologyEditor && window.topologyEditor.showResultModal) {
            window.topologyEditor.showResultModal(true, 'Success', message);
        } else {
            alert(message);
        }
    }

    showError(message) {
        console.error('Device Configuration Manager error:', message);
        if (window.topologyEditor && window.topologyEditor.showResultModal) {
            window.topologyEditor.showResultModal(false, 'Error', message);
        } else {
            alert(message);
        }
    }

    showConfigurationPreview(configData) {
        const previewTitle = document.getElementById('config-preview-title');
        const previewNodeName = document.getElementById('preview-node-name');
        const previewFileSize = document.getElementById('preview-file-size');
        const previewLineCount = document.getElementById('preview-line-count');
        const previewContent = document.getElementById('config-preview-content');

        if (previewTitle) previewTitle.textContent = `CONFIGURATION PREVIEW - ${configData.node_name}`;
        if (previewNodeName) previewNodeName.textContent = configData.node_name;
        if (previewFileSize) previewFileSize.textContent = this.formatFileSize(configData.size);
        if (previewLineCount) previewLineCount.textContent = configData.lines;
        if (previewContent) previewContent.textContent = configData.content;

        this.showPreviewModal();
    }

    formatFileSize(bytes) {
        if (bytes === 0) return '0 Bytes';
        const k = 1024;
        const sizes = ['Bytes', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    }

    cleanup() {
        // Clean up resources
        this.devices = [];
        this.deviceConfigs = {};
        console.log('Device Configuration Manager cleaned up');
    }

    // Integration with deployment - called before lab deployment
    async getConfiguredDevicesForDeployment() {
        return {
            deployment_id: this.currentDeploymentId,
            configured_devices: Object.keys(this.deviceConfigs),
            total_configs: Object.keys(this.deviceConfigs).length
        };
    }

    // Debug function to test device loading
    async testDeviceLoading() {
        console.log('🧪 Testing device loading...');

        // Test global editor availability
        console.log('📝 Global editor:', globalEditor ? 'Available' : 'Not available');
        if (globalEditor) {
            const yamlContent = globalEditor.getValue();
            console.log('📄 YAML content length:', yamlContent.length);
            console.log('📄 YAML content preview:', yamlContent.substring(0, 200) + '...');
        }

        // Test modal elements
        console.log('🏗️ Modal elements:');
        console.log('  - devices-grid:', !!document.getElementById('devices-grid'));
        console.log('  - no-devices-message:', !!document.getElementById('no-devices-message'));
        console.log('  - total-devices:', !!document.getElementById('total-devices'));
        console.log('  - configured-devices:', !!document.getElementById('configured-devices'));

        // Test server selector
        const serverSelector = document.getElementById('server-selector');
        console.log('🖥️ Server selector:', serverSelector ? serverSelector.value : 'Not found');

        // Test API call manually
        try {
            if (globalEditor) {
                const yamlContent = globalEditor.getValue();
                if (yamlContent.trim()) {
                    console.log('🌐 Testing API call...');
                    const response = await fetch('/plugins/digital-twin/get-devices-from-yaml/', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'X-CSRFToken': getCookie('csrftoken')
                        },
                        body: JSON.stringify({
                            yaml_content: yamlContent,
                            server_id: serverSelector ? serverSelector.value : 'local'
                        })
                    });

                    console.log('📡 API Response status:', response.status);
                    const result = await response.json();
                    console.log('📡 API Response data:', result);
                } else {
                    console.log('⚠️ No YAML content to test with');
                }
            }
        } catch (error) {
            console.error('❌ API test failed:', error);
        }

        console.log('🏁 Device loading test complete');
    }
}

// Device Configuration Manager for Device Details Modal
class DeviceConfigurationManager {
    constructor() {
        this.currentDevice = null;
        this.currentDeviceData = null;
        this.configEditor = null;
        this.isInitialized = false;
        this.configTemplates = {};
        this.deviceConfiguration = '';
        this.hasUnsavedChanges = false;

        // Configuration templates for different device types
        this.initializeTemplates();
    }

    initializeTemplates() {
        this.configTemplates = {
            'cisco_iosv': {
                name: 'Cisco IOS Basic',
                content: `!
    ! Basic Cisco IOS Configuration
    !
    version 15.7
    service timestamps debug datetime msec
    service timestamps log datetime msec
    no service password-encryption
    !
    hostname {{device_name}}
    !
    boot-start-marker
    boot-end-marker
    !
    enable secret 5 $1$gkJ8$3E7QX0KYX0.T3QNbZQF9B1
    !
    no aaa new-model
    !
    interface GigabitEthernet0/0
     ip address dhcp
     duplex auto
     speed auto
     media-type rj45
     no shutdown
    !
    ip forward-protocol nd
    !
    no ip http server
    no ip http secure-server
    !
    control-plane
    !
    line con 0
    line aux 0
    line vty 0 4
     login
     transport input none
    !
    end`
            },
            'arista_eos': {
                name: 'Arista EOS Basic',
                content: `!
    ! Basic Arista EOS Configuration
    !
    hostname {{device_name}}
    !
    interface Management1
       ip address dhcp
       no shutdown
    !
    interface Ethernet1
       no shutdown
    !
    interface Ethernet2  
       no shutdown
    !
    management api http-commands
       protocol http
       no shutdown
    !
    end`
            },
            'nokia_srlinux': {
                name: 'Nokia SR Linux Basic',
                content: `# Basic Nokia SR Linux Configuration
    # Generated for {{device_name}}
    
    
    # System configuration
    set /system/hostname {{device_name}}
    
    
    # Management interface
    set /interface mgmt0/admin-state enable
    set /interface mgmt0/subinterface 0/admin-state enable
    set /interface mgmt0/subinterface 0/ipv4/dhcp-client
    
    
    # Data interfaces
    set /interface ethernet-1/1/admin-state enable
    set /interface ethernet-1/2/admin-state enable
    
    
    # Network instance
    set /network-instance default/admin-state enable
    set /network-instance default/type default
    
    
    commit save`
            },
            'juniper_vmx': {
                name: 'Juniper vMX Basic',
                content: `# Basic Juniper vMX Configuration
    # Generated for {{device_name}}
    
    
    system {
        host-name {{device_name}};
        root-authentication {
            encrypted-password "$6$GXgH.b0K$HnMvLYBvHNZEKGsDuPN19/";
        }
        services {
            ssh;
            netconf {
                ssh;
            }
        }
    }
    
    
    interfaces {
        fxp0 {
            unit 0 {
                family inet {
                    dhcp;
                }
            }
        }
        ge-0/0/0 {
            unit 0 {
                family inet;
            }
        }
        ge-0/0/1 {
            unit 0 {
                family inet;
            }
        }
    }`
            },
            'frr_linux': {
                name: 'FRRouting Linux Basic',
                content: `# FRRouting Configuration for {{device_name}}
    # frr version 8.5
    frr version 8.5
    frr defaults traditional
    hostname {{device_name}}
    service integrated-vtysh-config
    
    # Logging configuration
    log syslog informational
    
    # Basic interface configuration
    interface eth0
     description Management Interface
     ip address dhcp
    
    interface eth1
     description Data Interface 1
     no shutdown
    
    interface eth2
     description Data Interface 2
     no shutdown
    
    # Enable IP forwarding
    ip forwarding
    
    # OSPF Configuration (basic)
    router ospf
     ospf router-id 1.1.1.1
     passive-interface eth0
     # Add networks as needed:
     # network 192.168.1.0/24 area 0
    
    # BGP Configuration (commented out - uncomment and modify as needed)
    # router bgp 65001
    #  bgp router-id 1.1.1.1
    #  neighbor 192.168.1.2 remote-as 65002
    #  neighbor 192.168.1.2 description Peer_Router
    #  address-family ipv4 unicast
    #   network 10.0.0.0/8
    #   neighbor 192.168.1.2 activate
    
    # Access control
    line vty
     exec-timeout 0 0
    
    # End of configuration`
            },
            'default': {
                name: 'Generic Device',
                content: `# Configuration for {{device_name}}
    # Device type: {{device_kind}}
    # 
    # Add your device configuration here
    #
    # This is a generic template - please customize
    # according to your device type and requirements.
    `
            }   
        };
    }


    async initializeForDevice(deviceName, deviceData) {
        this.currentDevice = deviceName;
        this.currentDeviceData = deviceData;

        console.log('🔧 Initializing configuration manager for device:', deviceName);

        // Update modal title and device info for improved UI
        this.updateDeviceInfo(deviceName, deviceData);

        // Initialize status bar
        this.updateStatusBar('loading', 'Loading configuration...');

        // Load configuration status
        await this.loadConfigurationStatus();

        // Setup configuration tab elements
        this.setupConfigurationTab();

        // Load existing configuration if available
        await this.loadDeviceConfiguration();

        // Setup improved event listeners
        this.setupImprovedEventListeners();

        this.updateStatusBar('ready', 'Configuration editor ready');
        this.isInitialized = true;
        
        // Start in normal mode
        this.switchToNormalMode();
    }

    updateDeviceInfo(deviceName, deviceData) {
        // Update modal title and device info
        const titleElement = document.getElementById('config-editor-title');
        const deviceNameElement = document.getElementById('editor-device-name');
        const deviceKindElement = document.getElementById('editor-device-kind');
        const deviceImageElement = document.getElementById('editor-device-image');
        const serverInfoElement = document.getElementById('editor-server-info');

        if (titleElement) titleElement.textContent = `Device Configuration - ${deviceName}`;
        if (deviceNameElement) deviceNameElement.textContent = deviceName;
        if (deviceKindElement) deviceKindElement.textContent = deviceData.kind || 'Unknown';
        if (deviceImageElement) deviceImageElement.textContent = deviceData.image || 'Not set';

        // Update server info
        const serverSelector = document.getElementById('server-selector');
        const serverId = serverSelector ? serverSelector.value : 'local';
        if (serverInfoElement) {
            serverInfoElement.textContent = serverId === 'local' ? 'Local' : `Remote (${serverId})`;
        }
    }

    updateStatusBar(status, message) {
        const statusIcon = document.getElementById('config-status-icon');
        const statusText = document.getElementById('config-status-text');

        if (!statusIcon || !statusText) return;

        // Update icon based on status
        statusIcon.className = 'fas';
        switch (status) {
            case 'loading':
                statusIcon.classList.add('fa-circle-notch', 'fa-spin');
                statusIcon.style.color = 'var(--primary-color)';
                break;
            case 'success':
                statusIcon.classList.add('fa-check-circle');
                statusIcon.style.color = 'var(--success-color)';
                break;
            case 'error':
                statusIcon.classList.add('fa-exclamation-triangle');
                statusIcon.style.color = 'var(--error-color)';
                break;
            case 'ready':
                statusIcon.classList.add('fa-edit');
                statusIcon.style.color = 'var(--primary-color)';
                break;
            default:
                statusIcon.classList.add('fa-info-circle');
                statusIcon.style.color = 'var(--info-color)';
        }

        statusText.textContent = message;
    }

    setupImprovedEventListeners() {
        // Validate button
        const validateBtn = document.getElementById('validate-config-btn');
        if (validateBtn) {
            validateBtn.addEventListener('click', () => this.validateConfiguration());
        }

        // Refresh button
        const refreshBtn = document.getElementById('refresh-config-btn');
        if (refreshBtn) {
            refreshBtn.addEventListener('click', () => this.refreshConfiguration());
        }

        // Apply to YAML button
        const applyBtn = document.getElementById('apply-config-btn');
        if (applyBtn) {
            applyBtn.addEventListener('click', () => this.applyToYAML());
        }

        // Template selector
        const templateSelect = document.getElementById('config-template-select');
        const loadTemplateBtn = document.getElementById('load-template-btn');
        if (templateSelect && loadTemplateBtn) {
            loadTemplateBtn.addEventListener('click', () => this.loadSelectedTemplate());
        }

        // Configuration size tracking
        const configEditor = document.getElementById('config-content-editor');
        const sizeInfo = document.getElementById('config-size-info');
        if (configEditor && sizeInfo) {
            const updateSize = () => {
                const size = configEditor.value.length;
                sizeInfo.textContent = `${size} characters`;
                this.updateSaveButtonState();

                // Show/hide apply button based on whether config exists and has content
                const applyBtn = document.getElementById('apply-config-btn');
                if (applyBtn) {
                    applyBtn.style.display = size > 0 ? 'inline-flex' : 'none';
                }
            };

            configEditor.addEventListener('input', updateSize);
            updateSize(); // Initial call
        }
    }

    async refreshConfiguration() {
        this.updateStatusBar('loading', 'Refreshing configuration...');
        try {
            await this.loadDeviceConfiguration();
            this.updateStatusBar('success', 'Configuration refreshed successfully');
        } catch (error) {
            console.error('❌ Failed to refresh configuration:', error);
            this.updateStatusBar('error', 'Failed to refresh configuration');
        }
    }

    async applyToYAML() {
        try {
            this.updateYamlWithStartupConfig();
            this.showValidationResult('success', 'Configuration applied to YAML successfully');

            // Hide the apply button since it's now applied
            const applyBtn = document.getElementById('apply-config-btn');
            if (applyBtn) {
                applyBtn.style.display = 'none';
            }
        } catch (error) {
            console.error('❌ Failed to apply to YAML:', error);
            this.showValidationResult('error', 'Failed to apply configuration to YAML');
        }
    }

    async loadConfigurationStatus() {
        const statusIndicator = document.getElementById('config-status-indicator');
        if (!statusIndicator) return;

        try {
            // Get current server selection
            const serverSelector = document.getElementById('server-selector');
            const serverId = serverSelector ? serverSelector.value : 'local';

            const response = await fetch(`/plugins/digital-twin/get-device-config-live/${this.currentDevice}/?server_id=${serverId}`, {
                method: 'GET',
                headers: {
                    'X-CSRFToken': getCookie('csrftoken')
                }
            });

            const result = await response.json();

            if (result.status === 'success' && result.has_config) {
                statusIndicator.className = 'config-status-indicator configured';
                statusIndicator.innerHTML = '<i class="fas fa-check-circle"></i> Device is configured';
            } else {
                statusIndicator.className = 'config-status-indicator unconfigured';
                statusIndicator.innerHTML = '<i class="fas fa-exclamation-triangle"></i> No configuration found';
            }
        } catch (error) {
            console.error('Error loading configuration status:', error);
            statusIndicator.className = 'config-status-indicator unconfigured';
            statusIndicator.innerHTML = '<i class="fas fa-exclamation-triangle"></i> Status unknown';
        }
    }

    setupConfigurationTab() {
        // Populate template selector
        this.populateTemplateSelector();

        // Initialize ACE editor
        this.initializeConfigEditor();

        // Setup event listeners
        this.setupEventListeners();
    }

    populateTemplateSelector() {
        const templateSelector = document.getElementById('config-template-selector');
        if (!templateSelector) return;

        // Clear existing options
        templateSelector.innerHTML = '<option value="">Select a template...</option>';

        // Get device-specific template if available
        const deviceKind = this.currentDeviceData?.kind || '';
        let availableTemplates = [];

        // Add device-specific template first
        for (const [key, template] of Object.entries(this.configTemplates)) {
            if (key !== 'default' && deviceKind.includes(key.split('_')[0])) {
                availableTemplates.push({ key, template, priority: 1 });
            }
        }

        // Add other templates
        for (const [key, template] of Object.entries(this.configTemplates)) {
            if (!availableTemplates.find(t => t.key === key) && key !== 'default') {
                availableTemplates.push({ key, template, priority: 2 });
            }
        }

        // Add default template last
        availableTemplates.push({ key: 'default', template: this.configTemplates.default, priority: 3 });

        // Sort by priority and add to selector
        availableTemplates.sort((a, b) => a.priority - b.priority);

        availableTemplates.forEach(({ key, template }) => {
            const option = document.createElement('option');
            option.value = key;
            option.textContent = template.name;
            templateSelector.appendChild(option);
        });
    }

    initializeConfigEditor() {
        // Initialize ACE editor for configuration editing
        const editorContainer = document.getElementById('device-config-editor');
        if (!editorContainer) return;

        // Load ACE editor if not already loaded
        if (typeof ace === 'undefined') {
            // Load ACE editor dynamically
            this.loadAceEditor().then(() => {
                this.createEditor(editorContainer);
            });
        } else {
            this.createEditor(editorContainer);
        }
    }

    async loadAceEditor() {
        return new Promise((resolve, reject) => {
            const script = document.createElement('script');
            script.src = 'https://cdnjs.cloudflare.com/ajax/libs/ace/1.4.12/ace.js';
            script.onload = () => {
                // Load additional modes
                const modeScript = document.createElement('script');
                modeScript.src = 'https://cdnjs.cloudflare.com/ajax/libs/ace/1.4.12/mode-text.min.js';
                modeScript.onload = resolve;
                modeScript.onerror = reject;
                document.head.appendChild(modeScript);
            };
            script.onerror = reject;
            document.head.appendChild(script);
        });
    }

    createEditor(container) {
        try {
            this.configEditor = ace.edit(container);
            this.configEditor.setTheme('ace/theme/monokai');
            this.configEditor.session.setMode('ace/mode/text');
            this.configEditor.setOptions({
                fontSize: '14px',
                wrap: true,
                showPrintMargin: false,
                showGutter: true,
                highlightActiveLine: true
            });

            // Set placeholder text
            this.configEditor.setValue('# No configuration loaded\n# Select a template or upload a configuration file\n');
            this.configEditor.clearSelection();

            // Track changes
            this.configEditor.on('change', () => {
                this.hasUnsavedChanges = true;
                this.updateSaveButtonState();
            });

            console.log('✅ ACE editor initialized for device configuration');
        } catch (error) {
            console.error('❌ Failed to initialize ACE editor:', error);
            // Fallback to textarea
            this.fallbackToTextarea(container);
        }
    }

    fallbackToTextarea(container) {
        container.innerHTML = '<textarea id="config-textarea" class="config-textarea" placeholder="Enter device configuration here..."></textarea>';
        const textarea = document.getElementById('config-textarea');
        if (textarea) {
            textarea.addEventListener('input', () => {
                this.hasUnsavedChanges = true;
                this.updateSaveButtonState();
            });
        }
    }

    setupEventListeners() {
        // Template selector
        const templateSelector = document.getElementById('config-template-selector');
        const loadTemplateBtn = document.getElementById('load-template-btn');

        if (loadTemplateBtn) {
            loadTemplateBtn.addEventListener('click', () => {
                this.loadSelectedTemplate();
            });
        }

        // Editor controls
        const clearBtn = document.getElementById('clear-config-btn');
        const validateBtn = document.getElementById('validate-config-btn');

        if (clearBtn) {
            clearBtn.addEventListener('click', () => {
                this.clearConfiguration();
            });
        }

        if (validateBtn) {
            validateBtn.addEventListener('click', () => {
                this.validateConfiguration();
            });
        }

        // File upload
        const uploadBtn = document.getElementById('upload-config-file-btn');
        const fileInput = document.getElementById('config-file-input');

        if (uploadBtn && fileInput) {
            uploadBtn.addEventListener('click', () => {
                fileInput.click();
            });

            fileInput.addEventListener('change', (e) => {
                this.handleFileUpload(e.target.files);
            });
        }

        // Footer buttons
        const saveBtn = document.getElementById('save-config-btn');
        const cancelBtn = document.getElementById('cancel-config-btn');
        const closeOnlyBtn = document.getElementById('config-close-only-btn');

        if (saveBtn) {
            saveBtn.addEventListener('click', () => {
                this.saveConfiguration();
            });
        }

        if (cancelBtn) {
            cancelBtn.addEventListener('click', () => {
                this.cancelChanges();
            });
        }

        if (closeOnlyBtn) {
            closeOnlyBtn.addEventListener('click', () => {
                this.hideEditorModal();
            });
        }
    }

    loadSelectedTemplate() {
        const templateSelector = document.getElementById('config-template-selector');
        if (!templateSelector || !templateSelector.value) return;

        const template = this.configTemplates[templateSelector.value];
        if (!template) return;

        let configContent = template.content;

        // Replace placeholders
        configContent = configContent.replace(/\{\{device_name\}\}/g, this.currentDevice);
        configContent = configContent.replace(/\{\{device_kind\}\}/g, this.currentDeviceData?.kind || 'unknown');

        // Set content in editor
        if (this.configEditor) {
            this.configEditor.setValue(configContent);
            this.configEditor.clearSelection();
        } else {
            const textarea = document.getElementById('config-textarea');
            if (textarea) {
                textarea.value = configContent;
            }
        }

        this.hasUnsavedChanges = true;
        this.updateSaveButtonState();
        this.switchToNormalMode(); // Switch to normal mode when loading template

        console.log('📋 Loaded template:', template.name);
    }



    async handleFileUpload(files) {
        if (!files || files.length === 0) return;

        const file = files[0];
        console.log('📁 Uploading configuration file:', file.name);

        try {
            const content = await this.readFile(file);

            // Set content in editor
            if (this.configEditor) {
                this.configEditor.setValue(content);
                this.configEditor.clearSelection();
            } else {
                const textarea = document.getElementById('config-textarea');
                if (textarea) {
                    textarea.value = content;
                }
            }

            this.hasUnsavedChanges = true;
            this.updateSaveButtonState();
            this.switchToNormalMode(); // Switch to normal mode when uploading file

            console.log('✅ Configuration file loaded successfully');
        } catch (error) {
            console.error('❌ Failed to read configuration file:', error);
            alert('Failed to read configuration file. Please try again.');
        }
    }

    readFile(file) {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.onload = (e) => resolve(e.target.result);
            reader.onerror = reject;
            reader.readAsText(file);
        });
    }

    clearConfiguration() {
        if (!confirm('Are you sure you want to clear the configuration?')) return;

        if (this.configEditor) {
            this.configEditor.setValue('');
        } else {
            const textarea = document.getElementById('config-textarea');
            if (textarea) {
                textarea.value = '';
            }
        }

        this.hasUnsavedChanges = true;
        this.updateSaveButtonState();
        this.switchToNormalMode(); // Switch to normal mode when clearing
    }

    async validateConfiguration() {
        const config = this.getCurrentConfiguration();
        if (!config.trim()) {
            this.showValidationResult('warning', 'No configuration to validate');
            return;
        }

        try {
            const response = await fetch('/plugins/digital-twin/validate-device-config/', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRFToken': getCookie('csrftoken')
                },
                body: JSON.stringify({
                    configuration: config,
                    device_kind: this.currentDeviceData?.kind || ''
                })
            });

            const result = await response.json();

            if (result.status === 'success') {
                this.showValidationResult('success', result.message);
            } else if (result.status === 'warning') {
                this.showValidationResult('warning', result.message);
            } else {
                this.showValidationResult('error', result.message);
            }

        } catch (error) {
            console.error('Error validating configuration:', error);
            this.showValidationResult('error', 'Validation failed - please try again');
        }
    }

    showValidationResult(type, message) {
        const validationStatus = document.getElementById('config-validation-status');
        if (!validationStatus) return;

        validationStatus.className = `config-validation-status ${type}`;
        validationStatus.innerHTML = `
            <i class="fas fa-${type === 'success' ? 'check-circle' : 'exclamation-triangle'}"></i>
            ${message}
        `;

        validationStatus.style.display = 'block';

        // Hide after 3 seconds
        setTimeout(() => {
            validationStatus.style.display = 'none';
        }, 3000);
    }

    getCurrentConfiguration() {
        if (this.configEditor) {
            return this.configEditor.getValue();
        } else {
            const textarea = document.getElementById('config-textarea');
            return textarea ? textarea.value : '';
        }
    }

    async loadDeviceConfiguration() {
        console.log('📋 Loading configuration for device:', this.currentDevice);

        try {
            // Get current server selection
            const serverSelector = document.getElementById('server-selector');
            const serverId = serverSelector ? serverSelector.value : 'local';

            const response = await fetch(`/plugins/digital-twin/get-device-config-live/${this.currentDevice}/?server_id=${serverId}`, {
                method: 'GET',
                headers: {
                    'X-CSRFToken': getCookie('csrftoken')
                }
            });

            const result = await response.json();

            if (result.status === 'success' && result.configuration) {
                // Load configuration into editor
                if (this.configEditor) {
                    this.configEditor.setValue(result.configuration);
                    this.configEditor.clearSelection();
                } else {
                    const textarea = document.getElementById('config-textarea');
                    if (textarea) {
                        textarea.value = result.configuration;
                    }
                }

                this.hasUnsavedChanges = false;
                this.updateSaveButtonState();

                console.log('✅ Configuration loaded successfully');
            }

        } catch (error) {
            console.error('❌ Failed to load configuration:', error);
        }
    }

    async saveConfiguration() {
        const config = this.getCurrentConfiguration();
        if (!config.trim()) {
            alert('No configuration to save');
            return;
        }

        try {
            // Show progress indication
            const saveBtn = document.getElementById('save-config-btn');
            if (saveBtn) {
                saveBtn.disabled = true;
                saveBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Saving...';
            }

            // Get current server selection
            const serverSelector = document.getElementById('server-selector');
            const serverId = serverSelector ? serverSelector.value : 'local';

            console.log('💾 Saving configuration for device:', this.currentDevice);

            const response = await fetch('/plugins/digital-twin/save-device-config-live/', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRFToken': getCookie('csrftoken')
                },
                body: JSON.stringify({
                    device_name: this.currentDevice,
                    configuration: config,
                    server_id: serverId
                })
            });

            const result = await response.json();

            if (result.status === 'success') {
                this.hasUnsavedChanges = false;
                this.updateSaveButtonState();

                // Show success message
                this.showValidationResult('success', result.message);

                // Update configuration status
                await this.loadConfigurationStatus();

                // Update YAML editor to include startup-config
                this.updateYamlWithStartupConfig();

                console.log('✅ Configuration saved successfully');
                
                // Switch to close-only mode after successful save
                this.switchToCloseOnlyMode();
            } else {
                throw new Error(result.error || 'Failed to save configuration');
            }

        } catch (error) {
            console.error('❌ Failed to save configuration:', error);
            alert('Failed to save configuration: ' + error.message);
        } finally {
            // Re-enable save button
            const saveBtn = document.getElementById('save-config-btn');
            if (saveBtn) {
                saveBtn.disabled = false;
                saveBtn.innerHTML = '<i class="fas fa-save"></i> Save Configuration';
            }
        }
    }

    async applyConfiguration() {
        if (!confirm('Apply configuration to running device? This may disrupt connectivity.')) return;

        const config = this.getCurrentConfiguration();
        if (!config.trim()) {
            alert('No configuration to apply');
            return;
        }

        try {
            // Get current server selection and lab information
            const serverSelector = document.getElementById('server-selector');
            const serverId = serverSelector ? serverSelector.value : 'local';

            // We need to determine the lab name - this would typically come from context
            // For now, we'll use a placeholder that the user would need to provide
            const labName = prompt('Enter the lab name to apply configuration to:');
            if (!labName) {
                return; // User cancelled
            }

            console.log('⚡ Applying configuration to running device:', this.currentDevice);

            const response = await fetch(`/plugins/digital-twin/apply-device-config-live/${this.currentDevice}/`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRFToken': getCookie('csrftoken')
                },
                body: JSON.stringify({
                    configuration: config,
                    server_id: serverId,
                    lab_name: labName
                })
            });

            const result = await response.json();

            if (result.status === 'success') {
                this.showValidationResult('success', 'Configuration applied successfully');
                console.log('✅ Configuration applied successfully');
            } else {
                throw new Error(result.error || 'Failed to apply configuration');
            }

        } catch (error) {
            console.error('❌ Failed to apply configuration:', error);
            alert('Failed to apply configuration: ' + error.message);
        }
    }

    cancelChanges() {
        if (this.hasUnsavedChanges && !confirm('Discard unsaved changes?')) return;

        // Reset to last saved state or empty
        this.loadDeviceConfiguration();
        this.hasUnsavedChanges = false;
        this.updateSaveButtonState();

        // Update status bar
        this.updateStatusBar('ready', 'Changes cancelled - editor ready');

        // Hide apply button
        const applyBtn = document.getElementById('apply-config-btn');
        if (applyBtn) {
            applyBtn.style.display = 'none';
        }

        // Update size info
        const configEditor = document.getElementById('config-content-editor');
        const sizeInfo = document.getElementById('config-size-info');
        if (configEditor && sizeInfo) {
            sizeInfo.textContent = `${configEditor.value.length} characters`;
        }

        console.log('✅ Configuration changes cancelled');
    }

    updateSaveButtonState() {
        const saveBtn = document.getElementById('save-config-btn');
        if (saveBtn) {
            saveBtn.disabled = !this.hasUnsavedChanges;
        }
        
        // Switch back to normal mode if user makes changes
        if (this.hasUnsavedChanges) {
            this.switchToNormalMode();
        }
    }

    switchToCloseOnlyMode() {
        const saveBtn = document.getElementById('save-config-btn');
        const cancelBtn = document.getElementById('cancel-config-btn');
        const closeOnlyBtn = document.getElementById('config-close-only-btn');
        
        if (saveBtn) saveBtn.style.display = 'none';
        if (cancelBtn) cancelBtn.style.display = 'none';
        if (closeOnlyBtn) closeOnlyBtn.style.display = 'inline-flex';
        
        this.hasUnsavedChanges = false;
        console.log('🔄 Switched to close-only mode');
    }

    switchToNormalMode() {
        const saveBtn = document.getElementById('save-config-btn');
        const cancelBtn = document.getElementById('cancel-config-btn');
        const closeOnlyBtn = document.getElementById('config-close-only-btn');
        
        if (saveBtn) saveBtn.style.display = 'inline-flex';
        if (cancelBtn) cancelBtn.style.display = 'inline-flex';
        if (closeOnlyBtn) closeOnlyBtn.style.display = 'none';
        
        console.log('🔄 Switched to normal mode');
    }

    updateYamlWithStartupConfig() {
        try {
            if (!this.currentDevice || !globalEditor) {
                return;
            }

            const yamlContent = globalEditor.getValue();
            if (!yamlContent.trim()) {
                return;
            }

            // Parse the YAML
            const yamlObj = jsyaml.load(yamlContent);

            if (!yamlObj || !yamlObj.topology || !yamlObj.topology.nodes) {
                return;
            }

            // Find the device in the YAML and add startup-config
            const deviceName = this.currentDevice;
            if (yamlObj.topology.nodes[deviceName]) {
                // Use device name directly for config filename (containerlab standard)
                const configFilename = `${deviceName}.cfg`;
                yamlObj.topology.nodes[deviceName]['startup-config'] = configFilename;

                // Update the editor with the modified YAML
                const updatedYaml = jsyaml.dump(yamlObj, {
                    indent: 2,
                    lineWidth: -1,
                    noRefs: true,
                    sortKeys: false
                });

                globalEditor.setValue(updatedYaml);

                console.log(`✅ Added startup-config to YAML for device: ${deviceName} -> ${configFilename}`);

                // Show success message
                this.showValidationResult('info', `Added startup-config: ${configFilename} to YAML`);
            } else {
                console.warn(`⚠️ Device ${deviceName} not found in YAML topology`);
            }

        } catch (error) {
            console.error('❌ Error updating YAML with startup-config:', error);
        }
    }

    async autoCheckAndUpdateYamlConfigs() {
        try {
            if (!globalEditor) {
                return;
            }

            const yamlContent = globalEditor.getValue();
            if (!yamlContent.trim()) {
                return;
            }

            // Parse the YAML
            const yamlObj = jsyaml.load(yamlContent);

            if (!yamlObj || !yamlObj.topology || !yamlObj.topology.nodes) {
                return;
            }

            const serverSelector = document.getElementById('server-selector');
            const serverId = serverSelector ? serverSelector.value : 'local';

            let yamlUpdated = false;
            let configsFound = 0;

            // Check each node for existing configurations
            for (const deviceName of Object.keys(yamlObj.topology.nodes)) {
                // Check if device already has startup-config
                if (yamlObj.topology.nodes[deviceName]['startup-config']) {
                    continue;
                }

                // Check if configuration exists in cache
                const cache_key = `device_config_${deviceName}_${serverId}`;
                try {
                    const response = await fetch(`/plugins/digital-twin/get-device-config-live/${deviceName}/?server_id=${serverId}`);
                    if (response.ok) {
                        const result = await response.json();
                        if (result.status === 'success' && result.configuration && result.configuration.trim()) {
                            // Configuration exists, add startup-config to YAML
                            const configFilename = `${deviceName}.cfg`;
                            yamlObj.topology.nodes[deviceName]['startup-config'] = configFilename;
                            yamlUpdated = true;
                            configsFound++;
                            console.log(`✅ Found existing config for ${deviceName}, added startup-config`);
                        }
                    }
                } catch (error) {
                    console.warn(`⚠️ Could not check config for ${deviceName}:`, error);
                }
            }

            // Update YAML editor if configurations were found
            if (yamlUpdated) {
                const updatedYaml = jsyaml.dump(yamlObj, {
                    indent: 2,
                    lineWidth: -1,
                    noRefs: true,
                    sortKeys: false
                });

                globalEditor.setValue(updatedYaml);

                // Show success message
                StatusManager.showSuccess(`Auto-added startup-config for ${configsFound} device(s) with existing configurations`);
                console.log(`✅ Auto-updated YAML with ${configsFound} startup-config entries`);
            }

        } catch (error) {
            console.error('❌ Error auto-checking configs:', error);
        }
    }

    cleanup() {
        if (this.configEditor) {
            this.configEditor.destroy();
            this.configEditor = null;
        }
        this.currentDevice = null;
        this.currentDeviceData = null;
        this.isInitialized = false;
    }
}

window.addEventListener('beforeunload', function () {
    if (window.topologyEditor && window.topologyEditor.eventManager) {
        window.topologyEditor.eventManager.removeAllHandlers();
    }
    if (window.labManager) {
        window.labManager.cleanup();
    }
    if (window.configUploadManager) {
        window.configUploadManager.cleanup();
    }
    if (window.topologyEditor && window.topologyEditor.deviceConfigManager) {
        window.topologyEditor.deviceConfigManager.cleanup();
    }
});

class DCIMFilterManager {
    constructor() {
        this.filterOptions = {};
        this.activeFilters = {};
        this.filterModal = null;
        this.isInitialized = false;
        this.eventManager = new EventManager();
        
        // UI state management elements
        this.loadingContainer = null;
        this.messageContainer = null;
        this.mainContent = null;
        this.loadingText = null;
        this.loadingProgress = null;
        this.messageIcon = null;
        this.messageTitle = null;
        this.messageText = null;
        this.retryButton = null;
    }

    async initialize() {
        console.log('🔍 Initializing DCIM Filter Manager...');

        this.filterModal = document.getElementById('dcim-filter-modal');
        if (!this.filterModal) {
            console.error('❌ Filter modal not found');
            return;
        }

        // Cache UI elements for state management
        this.loadingContainer = document.getElementById('filter-loading-container');
        this.messageContainer = document.getElementById('filter-message-container');
        this.mainContent = document.getElementById('filter-main-content');
        this.loadingText = document.getElementById('filter-loading-text');
        this.loadingProgress = document.getElementById('filter-loading-progress');
        this.messageIcon = document.getElementById('filter-message-icon');
        this.messageTitle = document.getElementById('filter-message-title');
        this.messageText = document.getElementById('filter-message-text');
        this.retryButton = document.getElementById('retry-filter-btn');

        await this.loadFilterOptions();
        this.setupEventListeners();
        this.isInitialized = true;

        console.log('✅ DCIM Filter Manager initialized');
    }

    async loadFilterOptions() {
        try {
            console.log('📡 Loading filter options...');

            const response = await fetch('/plugins/digital-twin/filter-options/', {
                method: 'GET',
                headers: {
                    'X-CSRFToken': getCookie('csrftoken'),
                    'Accept': 'application/json'
                }
            });

            if (!response.ok) {
                throw new Error(`HTTP ${response.status}: ${response.statusText}`);
            }

            const data = await response.json();
            this.filterOptions = data.filter_options;

            this.populateFilterDropdowns();
            console.log('✅ Filter options loaded:', this.filterOptions);

        } catch (error) {
            console.error('❌ Error loading filter options:', error);
            this.showError('Failed to load filter options: ' + error.message);
        }
    }

    populateFilterDropdowns() {
        const filterMappings = {
            'location-filter': 'locations',
            'site-filter': 'sites',
            'rack-filter': 'racks',
            'platform-filter': 'platforms',
            'role-filter': 'roles',
            'device-type-filter': 'device_types',
            'status-filter': 'statuses'
        };

        for (const [selectId, optionKey] of Object.entries(filterMappings)) {
            const select = document.getElementById(selectId);
            if (select && this.filterOptions[optionKey]) {
                // Clear existing options except the first one
                select.innerHTML = `<option value="">All ${optionKey.charAt(0).toUpperCase() + optionKey.slice(1)}</option>`;

                // Add new options
                this.filterOptions[optionKey].forEach(option => {
                    const optionElement = document.createElement('option');
                    optionElement.value = option;
                    optionElement.textContent = option;
                    select.appendChild(optionElement);
                });
            }
        }
    }

    setupEventListeners() {
        // Filter button
        const filterBtn = document.getElementById('dcim-filter-btn');
        if (filterBtn) {
            this.eventManager.addHandler(filterBtn, 'click', () => this.showFilterModal());
        }

        // Modal close button
        const closeBtn = document.getElementById('dcim-filter-close-btn');
        if (closeBtn) {
            this.eventManager.addHandler(closeBtn, 'click', () => this.hideFilterModal());
        }

        // Filter inputs
        const filterInputs = [
            'device-search', 'location-filter', 'site-filter', 'rack-filter',
            'platform-filter', 'role-filter', 'device-type-filter', 'status-filter'
        ];

        filterInputs.forEach(inputId => {
            const input = document.getElementById(inputId);
            if (input) {
                this.eventManager.addHandler(input, 'change', () => this.updateActiveFilters());
                if (input.type === 'text') {
                    this.eventManager.addHandler(input, 'input', () => this.updateActiveFilters());
                }
            }
        });

        // Action buttons
        const clearBtn = document.getElementById('clear-filters-btn');
        if (clearBtn) {
            this.eventManager.addHandler(clearBtn, 'click', () => this.clearAllFilters());
        }



        const loadTopologyBtn = document.getElementById('load-filtered-topology-btn');
        if (loadTopologyBtn) {
            this.eventManager.addHandler(loadTopologyBtn, 'click', () => this.loadFilteredTopology());
        }

        // Setup retry button event listener
        if (this.retryButton) {
            this.eventManager.addHandler(this.retryButton, 'click', () => {
                this.showMainContent();
            });
        }
    }

    showFilterModal() {
        if (this.filterModal) {
            DOMUtils.showModal(this.filterModal);
            this.updateActiveFilters();
            
            // Ensure we show the main content by default
            this.showMainContent();
        }
    }

    hideFilterModal() {
        if (this.filterModal) {
            DOMUtils.hideModal(this.filterModal);
        }
    }

    // UI State Management Methods
    showLoadingState(message = 'Loading devices...', progress = '') {
        if (this.loadingContainer && this.messageContainer && this.mainContent) {
            // Hide message and main content
            this.messageContainer.style.display = 'none';
            this.mainContent.style.display = 'none';
            
            // Update loading text and progress
            if (this.loadingText) this.loadingText.textContent = message;
            if (this.loadingProgress) this.loadingProgress.textContent = progress;
            
            // Show loading container
            this.loadingContainer.style.display = 'flex';
            
            // Disable footer buttons
            this.setFooterButtonsState(false);
        }
    }

    showMessageState(type = 'warning', title = 'No devices found', message = 'No devices match the current filter criteria.', showRetry = false) {
        if (this.messageContainer && this.loadingContainer && this.mainContent) {
            // Hide loading and main content
            this.loadingContainer.style.display = 'none';
            this.mainContent.style.display = 'none';
            
            // Update message content
            if (this.messageIcon) {
                this.messageIcon.className = `message-icon ${type}`;
                const iconClass = type === 'error' ? 'fa-exclamation-circle' : 
                                type === 'success' ? 'fa-check-circle' : 'fa-exclamation-triangle';
                this.messageIcon.innerHTML = `<i class="fas ${iconClass}"></i>`;
            }
            
            if (this.messageTitle) this.messageTitle.textContent = title;
            if (this.messageText) this.messageText.textContent = message;
            
            // Show/hide retry button
            if (this.retryButton) {
                this.retryButton.style.display = showRetry ? 'inline-block' : 'none';
            }
            
            // Show message container
            this.messageContainer.style.display = 'flex';
            
            // Enable footer buttons
            this.setFooterButtonsState(true);
        }
    }

    showMainContent() {
        if (this.mainContent && this.loadingContainer && this.messageContainer) {
            // Hide loading and message containers
            this.loadingContainer.style.display = 'none';
            this.messageContainer.style.display = 'none';
            
            // Show main content
            this.mainContent.style.display = 'block';
            
            // Enable footer buttons
            this.setFooterButtonsState(true);
        }
    }

    setFooterButtonsState(enabled) {
        const loadButton = document.getElementById('load-filtered-topology-btn');
        const clearButton = document.getElementById('clear-filters-btn');
        
        if (loadButton) {
            loadButton.disabled = !enabled;
            if (enabled) {
                loadButton.innerHTML = '<i class="fas fa-project-diagram"></i> Load Filtered Topology';
            } else {
                loadButton.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Loading...';
            }
        }
        
        if (clearButton) clearButton.disabled = !enabled;
    }

    updateActiveFilters() {
        this.activeFilters = {};

        // Get search term
        const searchInput = document.getElementById('device-search');
        if (searchInput && searchInput.value.trim()) {
            this.activeFilters.search = searchInput.value.trim();
        }

        // Get dropdown values
        const filterMappings = {
            'location-filter': 'location',
            'site-filter': 'site',
            'rack-filter': 'rack',
            'platform-filter': 'platform',
            'role-filter': 'role',
            'device-type-filter': 'device_type',
            'status-filter': 'status'
        };

        for (const [selectId, filterKey] of Object.entries(filterMappings)) {
            const select = document.getElementById(selectId);
            if (select && select.value) {
                this.activeFilters[filterKey] = select.value;
            }
        }

        this.updateFilterSummary();
    }

    updateFilterSummary() {
        const summaryDiv = document.getElementById('filter-summary');
        const activeFiltersList = document.getElementById('active-filters-list');

        if (!summaryDiv || !activeFiltersList) return;

        const activeFilterCount = Object.keys(this.activeFilters).length;

        if (activeFilterCount > 0) {
            summaryDiv.style.display = 'block';
            activeFiltersList.innerHTML = '';

            for (const [key, value] of Object.entries(this.activeFilters)) {
                const filterTag = document.createElement('span');
                filterTag.className = 'filter-tag';
                filterTag.innerHTML = `
                    ${key}: ${value}
                    <span class="remove-filter" onclick="window.topologyEditor.dcimFilterManager.removeFilter('${key}')">
                        <i class="fas fa-times"></i>
                    </span>
                `;
                activeFiltersList.appendChild(filterTag);
            }
        } else {
            summaryDiv.style.display = 'none';
        }
    }

    removeFilter(filterKey) {
        delete this.activeFilters[filterKey];

        // Clear corresponding input
        const filterMappings = {
            'location': 'location-filter',
            'site': 'site-filter',
            'rack': 'rack-filter',
            'platform': 'platform-filter',
            'role': 'role-filter',
            'device_type': 'device-type-filter',
            'status': 'status-filter'
        };

        if (filterKey === 'search') {
            const searchInput = document.getElementById('device-search');
            if (searchInput) searchInput.value = '';
        } else if (filterMappings[filterKey]) {
            const select = document.getElementById(filterMappings[filterKey]);
            if (select) select.value = '';
        }

        this.updateFilterSummary();
    }

    clearAllFilters() {
        this.activeFilters = {};

        // Clear all inputs
        const inputs = [
            'device-search', 'location-filter', 'site-filter', 'rack-filter',
            'platform-filter', 'role-filter', 'device-type-filter', 'status-filter'
        ];

        inputs.forEach(inputId => {
            const input = document.getElementById(inputId);
            if (input) {
                input.value = '';
            }
        });

        this.updateFilterSummary();
    }



    async loadFilteredTopology() {
        try {
            console.log('🔄 Loading filtered topology...');

            // Update active filters first
            this.updateActiveFilters();
            
            // Show loading state
            this.showLoadingState('Loading filtered topology...', 'Searching DCIM database...');

            const queryParams = new URLSearchParams(this.activeFilters);
            const url = `/plugins/digital-twin/discover-filtered-topology/?${queryParams.toString()}`;

            // Add progress update
            if (this.loadingProgress) {
                this.loadingProgress.textContent = 'Connecting to DCIM API...';
            }

            const response = await fetch(url, {
                method: 'GET',
                headers: {
                    'X-CSRFToken': getCookie('csrftoken'),
                    'Accept': 'application/json'
                }
            });

            // Update progress
            if (this.loadingProgress) {
                this.loadingProgress.textContent = 'Processing response...';
            }

            if (!response.ok) {
                throw new Error(`HTTP ${response.status}: ${response.statusText}`);
            }

            const data = await response.json();

            if (data.success && data.nodes && Object.keys(data.nodes).length > 0) {
                // Update progress
                if (this.loadingProgress) {
                    this.loadingProgress.textContent = 'Generating topology...';
                }

                // Update global topology data
                currentTopologyData = data;

                // Generate YAML from filtered topology
                if (window.topologyEditor) {
                    window.topologyEditor.generateYAMLFromTopology(data);
                }

                const nodeCount = Object.keys(data.nodes).length;
                const connectionCount = data.connections.length;
                const locationCount = Object.keys(data.locations).length;

                StatusManager.updateStatus(nodeCount, connectionCount, locationCount, 'Filtered DCIM Loaded');

                // Show success and close modal
                this.hideFilterModal();
                this.showSuccess(`Successfully loaded ${nodeCount} devices and ${connectionCount} connections from filtered DCIM`);

                console.log(`✅ Loaded filtered topology: ${nodeCount} devices, ${connectionCount} connections`);
            } else {
                // Show no devices found message
                this.showMessageState(
                    'warning',
                    'No devices found',
                    'No devices match the current filter criteria. Try adjusting your filters and search again.',
                    true
                );
                console.log('⚠️ No devices found with current filters');
            }

        } catch (error) {
            console.error('❌ Error loading filtered topology:', error);
            
            // Show error state
            this.showMessageState(
                'error',
                'Error loading topology',
                `Failed to load filtered topology: ${error.message}`,
                true
            );
        }
    }

    showSuccess(message) {
        if (window.topologyEditor && window.topologyEditor.showResultModal) {
            window.topologyEditor.showResultModal(true, message, null);
        }
    }

    showError(message) {
        if (window.topologyEditor && window.topologyEditor.showResultModal) {
            window.topologyEditor.showResultModal(false, message, null);
        }
    }

    getEventManager() {
        return this.eventManager;
    }
}

class TerminalManager {
    constructor() {
        this.currentSession = null;
        this.commandHistory = [];
        this.historyIndex = -1;
        this.terminalElement = null;
        this.outputElement = null;
        this.inputElement = null;
        this.commandQueue = [];
        this.isExecuting = false;
    }

    initialize() {
        this.setupTerminalModal();
        this.setupEventListeners();
    }

    setupTerminalModal() {
        // Get terminal modal elements (now defined in HTML template)
        this.terminalElement = document.getElementById('terminal-modal');
        this.outputElement = document.getElementById('terminal-output');
        this.inputElement = document.getElementById('terminal-input');
        
        // Setup fullscreen functionality
        this.setupFullscreenToggle();
        
        // Setup close button functionality
        const closeBtn = this.terminalElement.querySelector('.close-btn');
        if (closeBtn) {
            closeBtn.addEventListener('click', () => {
                this.hideTerminal();
            });
        }
        
        // Setup close button footer functionality
        const closeBtnFooter = this.terminalElement.querySelector('.close-btn-footer');
        if (closeBtnFooter) {
            closeBtnFooter.addEventListener('click', () => {
                this.hideTerminal();
            });
        }
        
        // Setup disconnect button functionality
        const disconnectBtn = this.terminalElement.querySelector('#terminal-disconnect');
        if (disconnectBtn) {
            disconnectBtn.addEventListener('click', () => {
                this.disconnect();
                this.hideTerminal();
            });
        }
    }

    setupFullscreenToggle() {
        const fullscreenBtn = document.getElementById('terminal-fullscreen-btn');
        if (fullscreenBtn) {
            fullscreenBtn.addEventListener('click', () => {
                this.toggleFullscreen();
            });
        }
    }

    showTerminal() {
        this.terminalElement.style.display = 'flex';
        this.terminalElement.classList.add('show');
    }
    
    hideTerminal() {
        this.terminalElement.classList.remove('show');
        this.terminalElement.style.display = 'none';
    }
    
    toggleFullscreen() {
        const modal = this.terminalElement;
        const fullscreenBtn = document.getElementById('terminal-fullscreen-btn');
        const icon = fullscreenBtn.querySelector('i');
        
        if (modal.classList.contains('fullscreen')) {
            // Exit fullscreen
            modal.classList.remove('fullscreen');
            icon.className = 'fas fa-expand';
            fullscreenBtn.title = 'Toggle Fullscreen';
        } else {
            // Enter fullscreen
            modal.classList.add('fullscreen');
            icon.className = 'fas fa-compress';
            fullscreenBtn.title = 'Exit Fullscreen';
        }
    }

    setupEventListeners() {
        // Terminal input events
        this.inputElement.addEventListener('keydown', (e) => {
            if (e.key === 'Enter') {
                this.executeCommand();
            } else if (e.key === 'ArrowUp') {
                e.preventDefault();
                this.navigateHistory('up');
            } else if (e.key === 'ArrowDown') {
                e.preventDefault();
                this.navigateHistory('down');
            } else if (e.key === 'Tab') {
                e.preventDefault();
                this.autoComplete();
            }
        });

        // Terminal control events
        document.getElementById('clear-terminal').addEventListener('click', () => {
            this.clearOutput();
        });

        document.getElementById('copy-output').addEventListener('click', () => {
            this.copyOutput();
        });

        document.getElementById('command-help').addEventListener('click', () => {
            this.showCommandHelp();
        });

        document.getElementById('terminal-disconnect').addEventListener('click', () => {
            this.disconnect();
        });

        // Modal events - no longer using Bootstrap modal
        // Close functionality is now handled in setupTerminalModal()
    }

    async openTerminal(serverId, labName, deviceName) {
        try {
            this.currentSession = { serverId, labName, deviceName };

            // Get device shell information
            const shellInfo = await this.getDeviceShellInfo(serverId, labName, deviceName);
            if (!shellInfo.success) {
                throw new Error(shellInfo.error);
            }

            // Update modal with device info
            document.getElementById('terminal-device-name').textContent = deviceName;
            document.getElementById('terminal-lab-name').textContent = labName;
            document.getElementById('terminal-shell-type').textContent = shellInfo.shell_info.description;

            // Set prompt
            const prompt = shellInfo.shell_info.prompt;
            document.getElementById('terminal-prompt').textContent = prompt;

            // Update connection status
            this.updateConnectionStatus('Connected', true);

            // Show welcome message
            this.appendOutput(`Connected to ${deviceName} (${shellInfo.shell_info.description})`);
            this.appendOutput(`Type 'help' for available commands or 'exit' to disconnect.\n`);

            // Show terminal modal
            this.showTerminal();

            // Focus input
            setTimeout(() => {
                this.inputElement.focus();
            }, 500);

        } catch (error) {
            console.error('Error opening terminal:', error);
            alert(`Failed to open terminal: ${error.message}`);
        }
    }

    async executeCommand() {
        const command = this.inputElement.value.trim();
        if (!command) return;

        // Add to history
        this.commandHistory.push(command);
        this.historyIndex = this.commandHistory.length;

        // Display command
        this.appendOutput(`$ ${command}`, 'command');

        // Clear input
        this.inputElement.value = '';

        // Execute command
        try {
            this.isExecuting = true;
            const result = await this.sendCommand(command);

            if (result.success) {
                if (result.output) {
                    this.appendOutput(result.output, 'output');
                }
                if (result.error) {
                    this.appendOutput(result.error, 'error');
                }
            } else {
                this.appendOutput(`Error: ${result.error}`, 'error');
            }
        } catch (error) {
            this.appendOutput(`Error: ${error.message}`, 'error');
        } finally {
            this.isExecuting = false;
        }

        // Scroll to bottom
        this.scrollToBottom();
    }

    async sendCommand(command) {
        const { serverId, labName, deviceName } = this.currentSession;

        const response = await fetch(`/plugins/digital-twin/execute-device-command/`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                server_id: serverId,
                lab_name: labName,
                device_name: deviceName,
                command: command
            })
        });

        return await response.json();
    }

    async getDeviceShellInfo(serverId, labName, deviceName) {
        const response = await fetch(`/plugins/digital-twin/device-shell-info/${serverId}/${labName}/${deviceName}/`);
        return await response.json();
    }

    async getDeviceCommands(serverId, labName, deviceName) {
        const response = await fetch(`/plugins/digital-twin/device-commands/${serverId}/${labName}/${deviceName}/`);
        return await response.json();
    }

    appendOutput(text, type = 'output') {
        const line = document.createElement('div');
        line.className = `terminal-line terminal-${type}`;
        line.textContent = text;
        this.outputElement.appendChild(line);
    }

    clearOutput() {
        this.outputElement.innerHTML = '';
    }

    copyOutput() {
        const text = this.outputElement.textContent;
        navigator.clipboard.writeText(text).then(() => {
            // Show temporary success message
            const btn = document.getElementById('copy-output');
            const originalText = btn.innerHTML;
            btn.innerHTML = '<i class="fas fa-check"></i> Copied!';
            setTimeout(() => {
                btn.innerHTML = originalText;
            }, 2000);
        });
    }

    async showCommandHelp() {
        try {
            const { serverId, labName, deviceName } = this.currentSession;
            const commands = await this.getDeviceCommands(serverId, labName, deviceName);

            if (commands.success) {
                this.displayCommandSuggestions(commands.commands);
            } else {
                this.appendOutput(`Error loading commands: ${commands.error}`, 'error');
            }
        } catch (error) {
            this.appendOutput(`Error: ${error.message}`, 'error');
        }
    }

    displayCommandSuggestions(commands) {
        const suggestionsElement = document.getElementById('command-suggestions');
        const categoriesElement = suggestionsElement.querySelector('.suggestion-categories');

        categoriesElement.innerHTML = '';

        Object.entries(commands).forEach(([category, commandList]) => {
            const categoryDiv = document.createElement('div');
            categoryDiv.className = 'suggestion-category';

            const categoryTitle = document.createElement('h6');
            categoryTitle.textContent = category.replace('_', ' ').toUpperCase();
            categoryDiv.appendChild(categoryTitle);

            const commandListDiv = document.createElement('div');
            commandListDiv.className = 'command-list';

            commandList.forEach(cmd => {
                const cmdBtn = document.createElement('button');
                cmdBtn.className = 'btn btn-sm btn-outline-secondary command-suggestion';
                cmdBtn.textContent = cmd;
                cmdBtn.onclick = () => {
                    this.inputElement.value = cmd;
                    this.inputElement.focus();
                    suggestionsElement.style.display = 'none';
                };
                commandListDiv.appendChild(cmdBtn);
            });

            categoryDiv.appendChild(commandListDiv);
            categoriesElement.appendChild(categoryDiv);
        });

        suggestionsElement.style.display = 'block';
    }

    navigateHistory(direction) {
        if (this.commandHistory.length === 0) return;

        if (direction === 'up') {
            if (this.historyIndex > 0) {
                this.historyIndex--;
            }
        } else if (direction === 'down') {
            if (this.historyIndex < this.commandHistory.length - 1) {
                this.historyIndex++;
            } else {
                this.historyIndex = this.commandHistory.length;
                this.inputElement.value = '';
                return;
            }
        }

        if (this.historyIndex >= 0 && this.historyIndex < this.commandHistory.length) {
            this.inputElement.value = this.commandHistory[this.historyIndex];
        }
    }

    autoComplete() {
        // Simple tab completion - could be enhanced with command suggestions
        const currentInput = this.inputElement.value;
        if (currentInput.startsWith('show ')) {
            const suggestions = ['show version', 'show interfaces', 'show ip route', 'show running-config'];
            const matching = suggestions.filter(s => s.startsWith(currentInput));
            if (matching.length === 1) {
                this.inputElement.value = matching[0];
            }
        }
    }

    scrollToBottom() {
        this.outputElement.scrollTop = this.outputElement.scrollHeight;
    }

    disconnect() {
        this.currentSession = null;
        this.commandHistory = [];
        this.historyIndex = -1;
        this.clearOutput();
        document.getElementById('command-suggestions').style.display = 'none';
        this.updateConnectionStatus('Disconnected', false);
        
        // Hide terminal modal
        this.hideTerminal();
    }

    updateConnectionStatus(status, isConnected = true) {
        const statusElement = document.getElementById('terminal-connection-status');
        const statusIcon = document.querySelector('#terminal-connection-status i');
        
        if (statusElement && statusIcon) {
            statusElement.textContent = status;
            statusIcon.className = 'fas fa-circle';
            statusIcon.style.color = isConnected ? '#28a745' : '#dc3545';
        }
    }
}