"""
Create Golden Config ComplianceFeatures + ComplianceRules via the REST API.
Flow (mirrors the UI):
 1. Create a ComplianceFeature  -> just a name.
 2. Create a ComplianceRule     -> feature + platform + match_config + description.
Endpoints are SINGULAR in GC:
 /api/plugins/golden-config/compliance-feature/
 /api/plugins/golden-config/compliance-rule/
API field for "Config To Match" (UI label) is `match_config`.
Usage:
 pip install pynautobot
 export NAUTOBOT_URL="http://127.0.0.1:8000"
 export NAUTOBOT_TOKEN="xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"
 python3 create_compliance_rules.py
Idempotent: existing features/rules are updated (match_config/description) not duplicated.
"""
import os
import sys
import pynautobot
# NAUTOBOT_URL   = os.environ.get("NAUTOBOT_URL",   "http://127.0.0.1:8000")
# NAUTOBOT_TOKEN = os.environ.get("NAUTOBOT_TOKEN", "69d406c932042eec25d8076084fcbba69f8b1c55")
# Platform name(s) exactly as they appear in Nautobot. Add "cisco_ios" if needed.
PLATFORM_NAMES = ["cisco_xe"]
CONFIG_ORDERED = False
CONFIG_TYPE    = "cli"
# (feature_name, match_config, description)
FEATURES = [
   ("username_netmon",              "username netmon",                       "Local monitoring user (privilege 7)"),
   ("username_netops",              "username netops",                       "Local operations user (privilege 15)"),
   ("enable_secret",                "enable secret",                         "Enable secret hash"),
   ("no_ip_domain_lookup",          "no ip domain lookup",                   "Disable DNS lookups"),
   ("no_service_config",            "no service config",                     "Disable auto network config load"),
   ("no_service_pad",               "no service pad",                        "Disable X.25 PAD service"),
   ("no_service_tcp_small_servers", "no service tcp-small-servers",          "Disable TCP small servers"),
   ("no_service_udp_small_servers", "no service udp-small-servers",          "Disable UDP small servers"),
   ("service_nagle",                "service nagle",                         "Enable Nagle congestion control"),
   ("service_tcp_keepalives_in",    "service tcp-keepalives-in",             "TCP keepalives on inbound sessions"),
   ("service_tcp_keepalives_out",   "service tcp-keepalives-out",            "TCP keepalives on outbound sessions"),
   ("service_compress_config",      "service compress-config",               "Compress startup config"),
   ("service_sequence_numbers",     "service sequence-numbers",              "Stamp log messages with sequence numbers"),
   ("service_counters_max_age",     "service counters max age 5",            "Interface counters max age 5 min"),
   ("service_call_home",            "service call-home",                     "Enable Call Home service"),
   ("service_password_encryption",  "service password-encryption",           "Type-7 encrypt plaintext passwords"),
   ("no_ip_source_route",           "no ip source-route",                    "Drop source-routed packets"),
   ("no_service_internal",          "no service internal",                   "Disable internal debug service"),
   ("no_service_dhcp",              "no service dhcp",                        "Disable DHCP server/relay service"),
   ("no_ip_http_server",            "no ip http server",                     "Disable HTTP server"),
   ("no_ip_http_secure_server",     "no ip http secure-server",              "Disable HTTPS server"),
   ("no_ip_bootp_server",           "no ip bootp server",                    "Disable BOOTP server"),
   ("no_service_finger",            "no service finger",                     "Disable finger service"),
   ("acl_vty_restrict",             "ip access-list standard VTY-RESTRICT",  "VTY management source ACL"),
   ("line_vty_0_4",                 "line vty 0 4",                          "VTY lines 0-4 hardening"),
   ("line_vty_5_15",                "line vty 5 15",                         "VTY lines 5-15 hardening"),
   ("line_vty_16_98",               "line vty 16 98",                        "VTY lines 16-98 disabled"),
   ("ip_ssh_version",               "ip ssh version",                        "Force SSH version 2"),
   ("ip_ssh_timeout",               "ip ssh time-out",                       "SSH negotiation timeout"),
   ("ip_ssh_authentication_retries","ip ssh authentication-retries",         "SSH auth retry limit"),
   ("ip_ssh_dh_min_size",           "ip ssh dh min size",                    "SSH DH minimum key size"),
   ("ip_ssh_source_interface",      "ip ssh source-interface",               "SSH source interface"),
   ("ip_domain_name",               "ip domain name",                        "IP domain name (SSH key gen)"),
   ("lldp_run",                     "lldp run",                              "Enable LLDP globally"),
   ("banner_motd",                  "banner motd",                           "MOTD banner"),
   ("banner_exec",                  "banner exec",                           "EXEC banner"),
   ("banner_login",                 "banner login",                          "Login banner"),
   ("line_con_0",                   "line con 0",                            "Console line hardening"),
   ("logging_host",                 "logging host",                          "Syslog destination host(s)"),
   ("logging_buffered",             "logging buffered",                      "Buffered logging size/level"),
   ("logging_snmp_authfail",        "logging snmp-authfail",                 "Log SNMP auth failures"),
   ("logging_source_interface",     "logging source-interface",              "Syslog source interface"),
   ("logging_trap",                 "logging trap",                          "Syslog trap severity"),
   ("no_ip_forward_protocol_udp",   "no ip forward-protocol udp",            "Disable UDP forwarding"),
   ("acl_snmp_restrict",            "ip access-list standard SNMP-RESTRICT",  "SNMP NMS source ACL"),
   ("snmp_server_view",             "snmp-server view",                      "SNMP v3 view definition"),
   ("snmp_server_group",            "snmp-server group",                     "SNMP v3 group -> view/ACL binding"),
   ("clock_timezone",               "clock timezone",                        "Timezone IST 5 30"),
   ("service_timestamps_debug",     "service timestamps debug",              "Timestamp debug messages"),
   ("service_timestamps_log",       "service timestamps log",                "Timestamp log messages"),
   ("no_logging_console",           "no logging console",                    "Suppress console logging"),
   ("no_logging_monitor",           "no logging monitor",                    "Suppress monitor logging"),
   ("ip_tcp_synwait_time",          "ip tcp synwait-time",                   "TCP SYN wait timer"),
   ("memory_reserve_critical",      "memory reserve critical",               "Reserve critical memory"),
   ("acl_ntp_permit",               "ip access-list standard NTP-PERMIT",    "NTP peer source ACL"),
   ("ntp_authentication_key",       "ntp authentication-key",                "NTP MD5 authentication key"),
   ("ntp_authenticate",             "ntp authenticate",                      "Enable NTP authentication"),
   ("ntp_trusted_key",              "ntp trusted-key",                       "NTP trusted key id"),
   ("ntp_access_group",             "ntp access-group",                      "NTP access-group peer restriction"),
   ("ntp_server",                   "ntp server",                            "NTP server(s)"),
   ("ntp_source",                   "ntp source",                            "NTP source interface"),
   ("ip_http_tls_version",          "ip http tls-version",                   "Restrict HTTP server to TLS 1.2"),
]

def main():
   if "PUT-YOUR-TOKEN-HERE" in NAUTOBOT_TOKEN:
       sys.exit("Set NAUTOBOT_TOKEN (env var or edit the file).")
   nb = pynautobot.api(NAUTOBOT_URL, token=NAUTOBOT_TOKEN)
   feat_ep = nb.plugins.golden_config.compliance_feature   # singular endpoint
   rule_ep = nb.plugins.golden_config.compliance_rule      # singular endpoint
   # Resolve platforms.
   platform_ids = []
   for pname in PLATFORM_NAMES:
       p = nb.dcim.platforms.get(name=pname)
       if not p:
           print(f"!! Platform '{pname}' not found - skipping.")
           continue
       platform_ids.append((pname, p.id))
   if not platform_ids:
       sys.exit("No valid platforms - nothing to do.")
   # Pull existing once for in-memory idempotency (no filter-param guessing).
   # Key features by SLUG - that's the field this GC version enforces as unique.
   features_by_slug = {getattr(f, "slug", None) or f.name: f for f in feat_ep.all()}
   rules_by_key = {(r.feature.id, r.platform.id): r for r in rule_ep.all()}
   feat_new = rule_new = rule_upd = 0
   for name, match_cfg, desc in FEATURES:
       # 1) Feature: name + slug (slug == name; both are valid slugs already)
       feature = features_by_slug.get(name)
       if not feature:
           try:
               feature = feat_ep.create(name=name, slug=name)
               feat_new += 1
           except pynautobot.core.query.RequestError:
               # Already exists (created by a prior run) - fetch it by slug.
               feature = feat_ep.get(slug=name)
               if not feature:
                   raise
           features_by_slug[name] = feature
       # 2) Rule per platform
       for pname, pid in platform_ids:
           rule = rules_by_key.get((feature.id, pid))
           if not rule:
               rule_ep.create(
                   feature=feature.id,
                   platform=pid,
                   config_type=CONFIG_TYPE,
                   config_ordered=CONFIG_ORDERED,
                   match_config=match_cfg,
                   description=desc,
               )
               rule_new += 1
           else:
               changed = False
               if getattr(rule, "match_config", None) != match_cfg:
                   rule.match_config = match_cfg; changed = True
               if getattr(rule, "description", "") != desc:
                   rule.description = desc; changed = True
               if rule.config_ordered != CONFIG_ORDERED:
                   rule.config_ordered = CONFIG_ORDERED; changed = True
               if changed:
                   rule.save(); rule_upd += 1
   print(f"Features: +{feat_new} new / {len(FEATURES)} total")
   print(f"Rules   : +{rule_new} new, {rule_upd} updated, across {len(platform_ids)} platform(s)")
   print("Next: Generate Intended Configurations -> Backup -> Perform Compliance.")

if __name__ == "__main__":
   main()