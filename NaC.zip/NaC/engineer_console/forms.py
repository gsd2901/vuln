"""Forms for the Engineer Console plugin."""

from django import forms

from django.contrib.contenttypes.models import ContentType
from nautobot.extras.models import Tag
from .models import TechnicalDocument, DocumentCategory
from nautobot.core.forms import BootstrapMixin
from nautobot.core.forms.forms import CSVModelForm

class DocumentCategoryForm(forms.ModelForm):
    """Form for creating and editing document categories."""
    
    class Meta:
        model = DocumentCategory
        fields = ('name', 'description')
        help_texts = {
            'name': 'Enter a descriptive name for this category',
            'description': 'Optional: Provide a brief description of the types of documents in this category'
        }


class TechnicalDocumentForm(forms.ModelForm):
    tags = forms.ModelMultipleChoiceField(
        queryset=Tag.objects.all(),
        required=False,
        widget=forms.SelectMultiple(attrs={'class': 'form-control'}),
        help_text="Select tags to categorize this document"
    )
    
    class Meta:
        model = TechnicalDocument
        fields = ['title', 'description', 'file', 'category', 'vendor']
        
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        
        # Make fields not required
        self.fields['category'].required = False
        self.fields['vendor'].required = False
        
        # Add help text
        self.fields['title'].help_text = "Enter a descriptive title for the document"
        self.fields['description'].help_text = "Provide a summary of what this document contains"
        self.fields['file'].help_text = "Upload a PDF or Word document (max 10MB)"
        self.fields['category'].help_text = "Select a category for organizing this document"
        self.fields['vendor'].help_text = "Document vendor/publisher"
        
        # Set initial tags if the instance exists
        if self.instance and self.instance.pk:
            # Get current tags for this instance
            from nautobot.extras.models import TaggedItem
            tagged_items = TaggedItem.objects.filter(
                content_type=ContentType.objects.get_for_model(self.instance),
                object_id=self.instance.pk
            )
            self.initial['tags'] = [tagged_item.tag.pk for tagged_item in tagged_items]
            
    def clean_file(self):
        """Validate that the uploaded file is a PDF or Word document."""
        file = self.cleaned_data.get('file', False)
        if file:
            # Get file extension
            file_ext = file.name.split('.')[-1].lower()
            allowed_extensions = ['pdf', 'doc', 'docx']
            
            if file_ext in allowed_extensions:
                if file.size > 10 * 1024 * 1024:  # 10MB limit
                    raise forms.ValidationError("File size cannot exceed 10MB")
                return file
            else:
                raise forms.ValidationError(f"Only PDF and Word documents ({', '.join(allowed_extensions)}) are allowed")
        return file
        
    def save(self, *args, **kwargs):
        # First save the model itself without trying to save tags yet
        instance = super().save(*args, **kwargs)
        
        # Save tags
        from nautobot.extras.models import TaggedItem
        # Get content type for this model
        content_type = ContentType.objects.get_for_model(instance)
        
        # Remove existing tags
        TaggedItem.objects.filter(content_type=content_type, object_id=instance.pk).delete()
        
        # Add new tags
        for tag in self.cleaned_data.get('tags', []):
            TaggedItem.objects.create(
                content_type=content_type,
                object_id=instance.pk,
                tag=tag
            )
        
        return instance
    
class TechnicalDocumentImportForm(BootstrapMixin, CSVModelForm):
    """Form for importing technical documents in bulk via CSV."""
    
    class Meta:
        model = TechnicalDocument
        fields = ['title', 'description', 'category', 'vendor']
    
    category = forms.ModelChoiceField(
        queryset=DocumentCategory.objects.all(),
        required=False,
        to_field_name='name',
        help_text='Document category'
    )

class TechnicalDocumentCSVForm(BootstrapMixin, forms.ModelForm):
    """Form for importing technical documents in bulk."""
    
    class Meta:
        model = TechnicalDocument
        fields = ['title', 'description', 'category', 'vendor']
    
    # Define CSV headers for import template
    csv_headers = ['title', 'description', 'category', 'vendor']
    
    category = forms.ModelChoiceField(
        queryset=DocumentCategory.objects.all(),
        required=False,
        to_field_name='name',
        help_text='Document category name'
    )