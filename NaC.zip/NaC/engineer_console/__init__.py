"""App declaration for Engineer Console plugin."""

from nautobot.apps import NautobotAppConfig

__version__ = "1.0.0"

class EngineerConsoleConfig(NautobotAppConfig):
    name = "engineer_console"
    verbose_name = "Engineer Console"
    description = "Nautobot plugin for accessing Cisco documentation and technical resources."
    author = "Avinash Sharma"
    author_email = "avinash_sharma@hcltech.com"
    base_url = "engineer-console"
    required_settings = []
    default_settings = {}
    min_version = "1.0.0"
    max_version = "3.0.0"
    caching_config = {}

    def ready(self):
        """Callback when this app is loaded."""
        super().ready()
        
        # Import jobs to ensure they're registered with Nautobot
        try:
            from . import jobs
            
            # Explicitly register our jobs with the registry
            from nautobot.extras.registry import registry
            registry["jobs"]["engineer_console.jobs.GenerateNetworkOverviewJob"] = jobs.GenerateNetworkOverviewJob
            registry["jobs"]["engineer_console.jobs.GenerateLocationDocsJob"] = jobs.GenerateLocationDocsJob
            registry["jobs"]["engineer_console.jobs.GenerateDocsJob"] = jobs.GenerateDocsJob
            
            # Register the jobs in the database if they don't exist yet
            from django.apps import apps
            if apps.is_installed('nautobot.extras'):
                from nautobot.extras.models import Job, JobQueue
                
                try:
                    # Try to get an existing queue first
                    default_queue = JobQueue.objects.first()
                    
                    # If no queue exists, create one
                    if default_queue is None:
                        default_queue = JobQueue.objects.create(
                            name="Default", 
                            description="Default job queue"
                        )
                    
                    # Register GenerateNetworkOverviewJob (NEW - single file with topology)
                    overview_job_class = jobs.GenerateNetworkOverviewJob
                    Job.objects.get_or_create(
                        job_class_name='GenerateNetworkOverviewJob',
                        module_name='engineer_console.jobs',
                        defaults={
                            'name': overview_job_class.name,
                            'grouping': overview_job_class.grouping,
                            'description': overview_job_class.description,
                            'installed': True,
                            'enabled': True,
                            'has_sensitive_variables': overview_job_class.has_sensitive_variables,
                            'default_job_queue': default_queue,
                        }
                    )
                    
                    # Register GenerateLocationDocsJob (enhanced detailed job)
                    location_job_class = jobs.GenerateLocationDocsJob
                    Job.objects.get_or_create(
                        job_class_name='GenerateLocationDocsJob',
                        module_name='engineer_console.jobs',
                        defaults={
                            'name': location_job_class.name,
                            'grouping': location_job_class.grouping,
                            'description': location_job_class.description,
                            'installed': True,
                            'enabled': True,
                            'has_sensitive_variables': location_job_class.has_sensitive_variables,
                            'default_job_queue': default_queue,
                        }
                    )
                    
                    # Register GenerateDocsJob (legacy job for backward compatibility)
                    docs_job_class = jobs.GenerateDocsJob
                    Job.objects.get_or_create(
                        job_class_name='GenerateDocsJob',
                        module_name='engineer_console.jobs',
                        defaults={
                            'name': docs_job_class.name,
                            'grouping': docs_job_class.grouping,
                            'description': docs_job_class.description,
                            'installed': True,
                            'enabled': True,
                            'has_sensitive_variables': docs_job_class.has_sensitive_variables,
                            'default_job_queue': default_queue,
                        }
                    )
                    
                    print("✅ Successfully registered all 3 Engineer Console jobs")
                    print("📋 Jobs registered:")
                    print("  1. Generate Network Overview (Single File)")
                    print("  2. Generate Location Documentation (Detailed)")
                    print("  3. Generate Network Documentation (Legacy)")
                    
                except Exception as e:
                    print(f"❌ Error registering Engineer Console job models: {e}")
                    
        except Exception as e:
            print(f"❌ Error loading Engineer Console jobs: {e}")

config = EngineerConsoleConfig