"""Fixed Network Documentation Jobs - Complete replacement with Markdown compatibility and Excel generation

REQUIREMENTS:
- Python 3.6+
- Django/Nautobot environment
- openpyxl (for Excel generation): pip install openpyxl
- If openpyxl is not available, CSV files will be generated instead

FEATURES:
- Comprehensive network documentation in Markdown format
- Professional Excel workbook with multiple worksheets
- Color-coded status indicators in Excel
- Auto-formatted tables and charts
- Both timestamped and latest versions
- Fallback to CSV if Excel library unavailable
"""

import os
import json
import base64
import urllib.parse
from datetime import datetime
from django.conf import settings
from nautobot.extras.jobs import Job, ObjectVar
from django.apps import apps


class GenerateNetworkOverviewJob(Job):
    """Generate a single comprehensive network overview document with standard Markdown."""

    name = "Generate Network Overview (Single File)"
    grouping = "Documentation"
    description = "Generate a single comprehensive network overview with standard Markdown formatting"
    has_sensitive_variables = False

    # Location selection field
    location = ObjectVar(
        model=apps.get_model("dcim", "Location"),
        description="Select location to generate network overview for",
        required=True
    )

    class Meta:
        name = "Generate Network Overview (Single File)"
        description = "Generate single comprehensive network documentation with standard Markdown"
        has_sensitive_variables = False
        approval_required = False

    def run(self, data=None, commit=None, **kwargs):
        try:
            self.logger.info("🚀 Starting network overview generation...")

            # Get selected location
            location = None
            if data and isinstance(data, dict):
                location = data.get('location')
            if not location and kwargs:
                location = kwargs.get('location')
            
            if not location:
                raise ValueError("Location is required. Please select a location when running the job.")

            self.logger.info(f"📍 Generating network overview for location: {location.name}")

            # Extract comprehensive data for the location
            location_data = self.extract_location_data(location)
            
            # Generate timestamped documentation
            timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")
            
            # Create folder structure
            docs_structure = self.create_documentation_structure(location, timestamp)
            
            # Generate single comprehensive document
            self.generate_network_overview_document(location_data, docs_structure)
            
            # Create symlinks
            self.create_symlinks(docs_structure, location)
            
            self.logger.info("✅ Network overview generated successfully!")

            result_message = f"""
Network Overview Generation Completed!

📍 **Location**: {location.name}
📊 **Statistics**:
- Devices: {len(location_data['devices']['devices'])}
- Racks: {len(location_data['racks']['racks'])}
- VLANs: {len(location_data['vlans'])}
- IP Prefixes: {len(location_data['prefixes'])}
- Network Connections: {len(location_data['connections'])}

📄 **Generated Documents**:
- Network Overview: network-overview.md (Markdown Format)
- Excel Workbook: network-documentation.xlsx (Professional Tables & Charts)
- Raw Data: data.json

🔗 **Access**:
- Latest Excel: /plugins/engineer-console/docs/{location.id}/network-documentation.xlsx
- Latest Markdown: /plugins/engineer-console/docs/{location.id}/network-overview.md
- Timestamped: /plugins/engineer-console/docs/{timestamp}/{location.id}/

📊 **Excel Features**:
- Multiple worksheets (Overview, Devices, Racks, VLANs, IP Addressing, Topology)
- Color-coded status indicators
- Auto-sized columns
- Professional formatting
- Ready for analysis and reporting
"""
            return result_message

        except Exception as e:
            self.logger.error(f"❌ Network overview generation failed: {str(e)}")
            import traceback
            self.logger.error(f"Full traceback: {traceback.format_exc()}")
            raise

    def extract_location_data(self, location):
        """Extract comprehensive data for the selected location."""
        self.logger.info(f"📊 Extracting data for location: {location.name}")
        
        from django.apps import apps
        Device = apps.get_model("dcim", "Device")
        Rack = apps.get_model("dcim", "Rack")
        Interface = apps.get_model("dcim", "Interface")
        VLAN = apps.get_model("ipam", "VLAN")
        Prefix = apps.get_model("ipam", "Prefix")
        IPAddress = apps.get_model("ipam", "IPAddress")
        Cable = apps.get_model("dcim", "Cable")
        
        # Get all devices in this location
        devices = Device.objects.filter(location=location).select_related(
            'device_type', 'role', 'platform', 'rack'
        ).prefetch_related('primary_ip4', 'primary_ip6')
        
        # Get all racks in this location
        racks = Rack.objects.filter(location=location).select_related(
            'role', 'tenant'
        ).prefetch_related('devices')
        
        # Get all VLANs associated with this location
        vlans = VLAN.objects.filter(location=location).select_related(
            'tenant', 'role'
        )
        
        # Get all IP prefixes for this location
        prefixes = Prefix.objects.filter(location=location).select_related(
            'tenant', 'role', 'vlan'
        )
        
        # Get network connections (simplified)
        connections = self._extract_network_connections(devices)
        
        # Structure the data for overview
        location_data = {
            'location': {
                'name': location.name,
                'id': str(location.id),
                'description': location.description or '',
                'facility': getattr(location, 'facility', ''),
                'physical_address': getattr(location, 'physical_address', ''),
                'tenant': location.tenant.name if location.tenant else None,
            },
            'devices': self._process_devices_overview(devices),
            'racks': self._process_racks_overview(racks),
            'vlans': self._process_vlans_overview(vlans),
            'prefixes': self._process_prefixes_overview(prefixes),
            'connections': connections,
            'statistics': {
                'total_devices': devices.count(),
                'total_racks': racks.count(),
                'total_vlans': vlans.count(),
                'total_prefixes': prefixes.count(),
                'total_connections': len(connections),
            },
            'topology': self._build_network_topology(devices, connections)
        }
        
        return location_data

    def _extract_network_connections(self, devices):
        """Extract network connections between devices."""
        connections = []
        device_names = [device.name for device in devices]
        
        # Get cables connecting devices in this location
        from django.apps import apps
        Cable = apps.get_model("dcim", "Cable")
        
        cables = Cable.objects.filter(
            _termination_a_device__in=devices
        ).select_related('status')
        
        for cable in cables:
            try:
                if (hasattr(cable, 'termination_a') and hasattr(cable, 'termination_b') and
                    cable.termination_a and cable.termination_b):
                    
                    # Extract device names from terminations
                    a_device = getattr(cable.termination_a, 'device', None)
                    b_device = getattr(cable.termination_b, 'device', None)
                    
                    if a_device and b_device and a_device.name in device_names and b_device.name in device_names:
                        connection = {
                            'from_device': a_device.name,
                            'to_device': b_device.name,
                            'from_interface': getattr(cable.termination_a, 'name', 'Unknown'),
                            'to_interface': getattr(cable.termination_b, 'name', 'Unknown'),
                            'cable_type': cable.type or 'Unknown',
                            'status': cable.status.name if cable.status else 'Unknown'
                        }
                        connections.append(connection)
            except AttributeError:
                continue
        
        return connections

    def _process_devices_overview(self, devices):
        """Process device data for overview with rack position info."""
        processed_devices = []
        device_types = {}
        device_roles = {}
        
        for device in devices:
            # Count by type and role for summary
            device_type = device.device_type.model if device.device_type else 'Unknown'
            device_role = device.role.name if device.role else 'Unknown'
            
            # Try to infer role from device type if role is generic
            if device_role.lower() in ['administrative', 'unknown', 'device']:
                device_role = self._infer_role_from_type(device_type, device.name)
            
            device_types[device_type] = device_types.get(device_type, 0) + 1
            device_roles[device_role] = device_roles.get(device_role, 0) + 1
            
            device_data = {
                'name': device.name,
                'device_type': device_type,
                'manufacturer': device.device_type.manufacturer.name if device.device_type and device.device_type.manufacturer else 'Unknown',
                'device_role': device_role,
                'platform': device.platform.name if device.platform else 'Unknown',
                'rack': device.rack.name if device.rack else 'Not Racked',
                'position': device.position,
                'u_height': getattr(device.device_type, 'u_height', 1) if device.device_type else 1,
                'face': getattr(device, 'face', 'front'),
                'status': device.status.name if device.status else 'Unknown',
                'primary_ip4': str(device.primary_ip4.address) if device.primary_ip4 else None,
                'primary_ip6': str(device.primary_ip6.address) if device.primary_ip6 else None,
                'serial': device.serial or 'N/A',
                'asset_tag': device.asset_tag or 'N/A',
            }
            processed_devices.append(device_data)
        
        return {
            'devices': processed_devices,
            'summary': {
                'by_type': device_types,
                'by_role': device_roles
            }
        }

    def _process_racks_overview(self, racks):
        """Enhanced rack processing with visual layout support."""
        rack_summary = []
        total_u_space = 0
        used_u_space = 0
        
        for rack in racks:
            device_count = rack.devices.count()
            u_height = rack.u_height or 0
            total_u_space += u_height
            
            # Calculate used U space more accurately
            used_u = 0
            for device in rack.devices.all():
                if device.device_type:
                    used_u += getattr(device.device_type, 'u_height', 1)
                else:
                    used_u += 1
            used_u_space += used_u
            
            # Get device positioning details
            devices_in_rack = self._get_rack_device_layout(rack)
            
            rack_data = {
                'name': rack.name,
                'u_height': u_height,
                'device_count': device_count,
                'used_u': used_u,
                'utilization_percent': round((used_u / u_height * 100), 1) if u_height > 0 else 0,
                'status': rack.status.name if rack.status else 'Unknown',
                'devices_layout': devices_in_rack,
                'facility_id': getattr(rack, 'facility_id', ''),
                'role': rack.role.name if rack.role else 'N/A',
            }
            rack_summary.append(rack_data)
        
        return {
            'racks': rack_summary,
            'summary': {
                'total_racks': len(rack_summary),
                'total_u_space': total_u_space,
                'used_u_space': used_u_space,
                'utilization_percent': round((used_u_space / total_u_space * 100), 1) if total_u_space > 0 else 0
            }
        }

    def _get_rack_device_layout(self, rack):
        """Get detailed device positioning within a rack."""
        devices_layout = {}
        
        # Get all devices in this rack with their positions
        devices = rack.devices.all().order_by('position')
        
        for device in devices:
            if device.position:
                devices_layout[device.position] = {
                    'name': device.name,
                    'device_type': device.device_type.model if device.device_type else 'Unknown',
                    'manufacturer': device.device_type.manufacturer.name if device.device_type and device.device_type.manufacturer else 'Unknown',
                    'device_role': device.role.name if device.role else 'Unknown',
                    'status': device.status.name if device.status else 'Unknown',
                    'face': getattr(device, 'face', 'front'),
                    'u_height': getattr(device.device_type, 'u_height', 1) if device.device_type else 1,
                    'primary_ip': str(device.primary_ip4.address) if device.primary_ip4 else str(device.primary_ip6.address) if device.primary_ip6 else 'No IP'
                }
        
        return devices_layout

    def _create_ascii_rack_layout(self, rack_data):
        """Create realistic ASCII art rack layout that looks like actual network racks."""
        rack_name = rack_data['name']
        u_height = rack_data['u_height']
        devices_layout = rack_data['devices_layout']
        utilization = rack_data['utilization_percent']
        
        ascii_parts = []
        
        # Rack header with proper formatting
        header = f"🏗️  RACK: {rack_name}  🏗️"
        ascii_parts.append("╔" + "═" * (len(header) + 4) + "╗")
        ascii_parts.append(f"║  {header}  ║")
        ascii_parts.append(f"║  📊 {u_height}U Total | {utilization}% Used | {len(devices_layout)} Devices  ║")
        ascii_parts.append("╠" + "═" * (len(header) + 4) + "╣")
        
        # Rack visual structure with proper borders
        rack_width = 70
        ascii_parts.append("║" + " " * (rack_width + 2) + "║")
        ascii_parts.append("║  ┌" + "─" * rack_width + "┐  ║")
        
        # Generate rack units from top to bottom (like real racks)
        for u_position in range(u_height, 0, -1):
            device_info = devices_layout.get(u_position)
            
            if device_info:
                # Device present - make it look like real network equipment
                device_name = device_info['name'][:28]
                device_type = device_info['device_type'][:20]
                status_icon = "🟢" if device_info['status'].lower() == 'active' else "🔴"
                mgmt_ip = device_info['primary_ip'][:15] if device_info['primary_ip'] != 'No IP' else ''
                
                # Create device representation with proper spacing
                u_label = f"U{str(u_position).zfill(2)}"
                device_line = f"{device_name:<28} | {device_type:<20} | {mgmt_ip:<15}"
                
                # Rack unit with device
                ascii_parts.append(f"║  │{u_label}│ {status_icon} {device_line[:rack_width-10]} │  ║")
                ascii_parts.append(f"║  │   │{'─' * (rack_width-5)}│  ║")
            else:
                # Empty rack unit
                u_label = f"U{str(u_position).zfill(2)}"
                empty_space = "[ EMPTY RACK UNIT ]".center(rack_width-10)
                ascii_parts.append(f"║  │{u_label}│ ⚫ {empty_space} │  ║")
                ascii_parts.append(f"║  │   │{'┄' * (rack_width-5)}│  ║")
        
        # Rack footer
        ascii_parts.append("║  └" + "─" * rack_width + "┘  ║")
        ascii_parts.append("║" + " " * (rack_width + 2) + "║")
        
        # Legend and status
        ascii_parts.append("╠" + "═" * (len(header) + 4) + "╣")
        ascii_parts.append("║  📋 LEGEND: 🟢 Active | 🔴 Inactive | ⚫ Empty    ║")
        ascii_parts.append("║  💡 TIP: Higher U numbers are at the top         ║")
        ascii_parts.append("╚" + "═" * (len(header) + 4) + "╝")
        
        return '\n'.join(ascii_parts)

    def _create_rack_summary_section(self, racks_data):
        """Create enhanced rack summary section with clean tabular format."""
        if not racks_data or not racks_data.get('racks'):
            return """
### 🏗️ Physical Infrastructure Overview

No racks configured for this location.

**Recommendations:**
- Add rack information to properly document physical infrastructure
- Assign devices to racks for better organization
- Configure rack layouts for visual documentation

"""
        
        content_parts = []
        
        # Infrastructure overview table
        content_parts.append(f"""
### 🏗️ Physical Infrastructure Overview

| **Metric** | **Value** | **Status** |
|------------|-----------|------------|
| 🏗️ **Total Racks** | {racks_data['summary']['total_racks']} | Active |
| 📏 **Total U Space** | {racks_data['summary']['total_u_space']}U | Available |
| 📦 **Used U Space** | {racks_data['summary']['used_u_space']}U | Occupied |
| 📊 **Utilization** | {racks_data['summary']['utilization_percent']}% | {"🟢 Optimal" if racks_data['summary']['utilization_percent'] < 80 else "🟡 High" if racks_data['summary']['utilization_percent'] < 90 else "🔴 Critical"} |

### 🗄️ Rack Summary

| **Rack Name** | **U Height** | **Used/Total U** | **Utilization** | **Device Count** | **Status** |
|---------------|--------------|------------------|-----------------|------------------|------------|
""")
        
        for rack in sorted(racks_data['racks'], key=lambda x: x['name']):
            util_status = "🟢" if rack['utilization_percent'] < 70 else "🟡" if rack['utilization_percent'] < 90 else "🔴"
            status_emoji = "🟢" if rack['status'].lower() == 'active' else "🔴"
            
            content_parts.append(f"| **{rack['name']}** | {rack['u_height']}U | {rack['used_u']}/{rack['u_height']}U | {util_status} {rack['utilization_percent']}% | {rack['device_count']} | {status_emoji} {rack['status']} |")

        # Add detailed rack layouts in clean tabular format
        content_parts.append(f"""

### 🏗️ Detailed Rack Information

""")
        
        for rack in racks_data['racks']:
            content_parts.append(f"""
#### 📋 {rack['name']} - Complete Layout

**Rack Information:**
- **Height:** {rack['u_height']}U
- **Utilization:** {rack['utilization_percent']}% ({rack['used_u']}/{rack['u_height']}U used)
- **Device Count:** {rack['device_count']}
- **Status:** {rack['status']}
- **Available Space:** {rack['u_height'] - rack['used_u']}U remaining

""")
            
            if rack['devices_layout']:
                # Show only devices (not empty positions)
                content_parts.append(f"""**Devices in {rack['name']}:**

| **Device Name** | **U Position** | **Device Type** | **Manufacturer** | **Role** | **Status** | **Management IP** |
|-----------------|----------------|-----------------|------------------|----------|------------|-------------------|
""")
                
                for u_pos in sorted(rack['devices_layout'].keys(), reverse=True):
                    device = rack['devices_layout'][u_pos]
                    status_emoji = "🟢" if device['status'].lower() == 'active' else "🔴"
                    role_emoji = "🌐" if 'router' in device['device_role'].lower() else "🔀" if 'switch' in device['device_role'].lower() else "📟"
                    content_parts.append(f"| {role_emoji} **{device['name']}** | **U{u_pos}** | {device['device_type']} | {device['manufacturer']} | {device['device_role']} | {status_emoji} {device['status']} | `{device['primary_ip']}` |")
                
                # Add space utilization breakdown
                occupied_positions = sorted(rack['devices_layout'].keys())
                if occupied_positions:
                    content_parts.append(f"""

**Space Utilization:**

| **Metric** | **Value** | **Details** |
|------------|-----------|-------------|
| **Occupied Positions** | U{', U'.join(map(str, occupied_positions))} | {len(occupied_positions)} positions used |
| **Largest Free Block** | {self._calculate_largest_free_block(rack['u_height'], occupied_positions)}U | Continuous space available |
| **Fragmentation** | {len(self._get_free_blocks(rack['u_height'], occupied_positions))} blocks | Number of separate free spaces |

""")
                
            else:
                # Rack exists but no devices positioned
                content_parts.append(f"""**Rack Status:** Empty

| **Metric** | **Value** | **Details** |
|------------|-----------|-------------|
| **Available Space** | {rack['u_height']}U | Full rack available |
| **Recommendation** | Add devices | Consider installing equipment or removing rack |
| **Capacity** | 100% | All positions available |

""")
            
            content_parts.append("---\n")  # Separator between racks

        return '\n'.join(content_parts)

    def _calculate_largest_free_block(self, u_height, occupied_positions):
        """Calculate the largest continuous free block in the rack."""
        if not occupied_positions:
            return u_height
        
        free_blocks = self._get_free_blocks(u_height, occupied_positions)
        return max(free_blocks) if free_blocks else 0
    
    def _get_free_blocks(self, u_height, occupied_positions):
        """Get all free blocks in the rack."""
        if not occupied_positions:
            return [u_height]
        
        free_blocks = []
        occupied_set = set(occupied_positions)
        
        current_block = 0
        for u in range(1, u_height + 1):
            if u not in occupied_set:
                current_block += 1
            else:
                if current_block > 0:
                    free_blocks.append(current_block)
                    current_block = 0
        
        if current_block > 0:
            free_blocks.append(current_block)
        
        return free_blocks

    def _process_vlans_overview(self, vlans):
        """Process VLAN data for overview."""
        vlan_summary = []
        
        for vlan in vlans:
            # Get associated prefixes
            try:
                prefixes = [str(prefix.prefix) for prefix in vlan.prefixes.all()]
            except:
                prefixes = []
            
            vlan_data = {
                'vid': vlan.vid,
                'name': vlan.name,
                'role': vlan.role.name if vlan.role else 'N/A',
                'status': vlan.status.name if vlan.status else 'Unknown',
                'description': vlan.description or 'N/A',
                'subnets': prefixes,
                'subnet_count': len(prefixes)
            }
            vlan_summary.append(vlan_data)
        
        return sorted(vlan_summary, key=lambda x: x['vid'])

    def _process_prefixes_overview(self, prefixes):
        """Process IP prefix data for overview."""
        prefix_summary = []
        
        for prefix in prefixes:
            prefix_data = {
                'prefix': str(prefix.prefix),
                'role': prefix.role.name if prefix.role else 'N/A',
                'vlan': f"VLAN {prefix.vlan.vid}" if prefix.vlan else 'N/A',
                'status': prefix.status.name if prefix.status else 'Unknown',
                'is_pool': prefix.is_pool,
                'description': prefix.description or 'N/A'
            }
            prefix_summary.append(prefix_data)
        
        return prefix_summary

    def _build_network_topology(self, devices, connections):
        """Build network topology with both HTML and ASCII formats."""
        # Create simple ASCII topology
        ascii_topology = self._build_ascii_topology(devices, connections)
        
        # Create HTML topology that works in Markdown
        html_topology = self._build_html_topology(devices, connections)
        
        # Create draw.io URL (for external viewing)
        drawio_url = self._create_drawio_url(devices, connections)
        
        # Create simple text-based topology statistics
        device_groups = self._organize_devices_for_topology(devices)
        
        topology_stats = {
            'routers': len(device_groups['routers']),
            'switches': len(device_groups['switches']),
            'other_devices': len(device_groups['others']),
            'total_connections': len(connections),
            'layers': len([g for g in device_groups.values() if g])
        }
        
        return {
            'ascii_diagram': ascii_topology,
            'html_diagram': html_topology,
            'drawio_url': drawio_url,
            'topology_stats': topology_stats,
            'device_layers': device_groups
        }

    def _organize_devices_for_topology(self, devices):
        """Organize devices by role/type for topology."""
        device_groups = {
            'routers': [],
            'switches': [],
            'others': []
        }
        
        for device in devices:
            device_role = device.role.name if device.role else 'Unknown'
            device_type = device.device_type.model if device.device_type else 'Unknown'
            
            # Enhanced role inference
            if device_role.lower() in ['administrative', 'unknown', 'device']:
                device_role = self._infer_role_from_type(device_type, device.name)
            
            device_info = {
                'name': self._get_short_device_name(device.name),
                'full_name': device.name,
                'role': device_role,
                'ip': str(device.primary_ip4.address) if device.primary_ip4 else 'No IP'
            }
            
            role_lower = device_role.lower()
            if any(keyword in role_lower for keyword in ['router', 'border', 'gateway']):
                device_groups['routers'].append(device_info)
            elif any(keyword in role_lower for keyword in ['switch', 'switching']):
                device_groups['switches'].append(device_info)
            else:
                device_groups['others'].append(device_info)
        
        return device_groups

    def _build_ascii_topology(self, devices, connections):
        """Build ASCII art network topology."""
        if not devices:
            return "No devices found"
        
        # Group devices by type for ASCII layout
        routers = []
        switches = []
        others = []
        
        for device in devices:
            device_role = device.role.name if device.role else 'Unknown'
            device_type = device.device_type.model if device.device_type else 'Unknown'
            
            if device_role.lower() in ['administrative', 'unknown', 'device']:
                device_role = self._infer_role_from_type(device_type, device.name)
            
            short_name = self._get_short_device_name(device.name)
            
            if 'router' in device_role.lower():
                routers.append(f"[{short_name}]")
            elif 'switch' in device_role.lower():
                switches.append(f"({short_name})")
            else:
                others.append(f"<{short_name}>")
        
        # Build ASCII layout
        lines = []
        lines.append("Network Topology (ASCII)")
        lines.append("=" * 50)
        
        if routers:
            lines.append("")
            lines.append("ROUTERS:")
            lines.append("  " + "  ".join(routers))
            if switches:
                lines.append("  " + "  ".join(["|" for _ in routers]))
        
        if switches:
            lines.append("")
            lines.append("SWITCHES:")
            lines.append("  " + "  ".join(switches))
            if others:
                lines.append("  " + "  ".join(["|" for _ in switches]))
        
        if others:
            lines.append("")
            lines.append("OTHER DEVICES:")
            lines.append("  " + "  ".join(others))
        
        lines.append("")
        lines.append("Legend: [Router] (Switch) <Other>")
        
        return "\n".join(lines)

    def _build_html_topology(self, devices, connections):
        """Build HTML topology that works in Markdown renderers."""
        if not devices:
            return "<p>No devices found</p>"
        
        # Group devices by role
        device_groups = {'routers': [], 'switches': [], 'others': []}
        
        for device in devices:
            device_role = device.role.name if device.role else 'Unknown'
            device_type = device.device_type.model if device.device_type else 'Unknown'
            
            if device_role.lower() in ['administrative', 'unknown', 'device']:
                device_role = self._infer_role_from_type(device_type, device.name)
            
            short_name = self._get_short_device_name(device.name)
            
            device_info = {
                'name': short_name,
                'full_name': device.name,
                'role': device_role,
                'ip': str(device.primary_ip4.address) if device.primary_ip4 else 'No IP'
            }
            
            if 'router' in device_role.lower():
                device_groups['routers'].append(device_info)
            elif 'switch' in device_role.lower():
                device_groups['switches'].append(device_info)
            else:
                device_groups['others'].append(device_info)
        
        # Build HTML diagram with inline styles
        html_parts = []
        html_parts.append('<div style="background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%); border-radius: 12px; padding: 30px; margin: 20px 0; border: 1px solid #e1e8ed; font-family: Arial, sans-serif;">')
        
        # Add layers
        if device_groups['routers']:
            html_parts.append('<div style="text-align: center; font-weight: bold; color: #333; margin-bottom: 10px; font-size: 14px;">🌐 ROUTERS</div>')
            html_parts.append('<div style="display: flex; justify-content: center; margin: 20px 0; flex-wrap: wrap;">')
            for device in device_groups['routers']:
                html_parts.append(f'''
<div style="background: linear-gradient(135deg, #ff6b6b, #ff5252); color: white; border: 2px solid #ff6b6b; border-radius: 8px; padding: 15px; margin: 10px; text-align: center; min-width: 120px; box-shadow: 0 4px 8px rgba(0,0,0,0.1);">
    <div style="font-weight: bold; font-size: 14px; margin-bottom: 5px;">🌐 {device["name"]}</div>
    <div style="font-size: 12px; opacity: 0.9; margin-bottom: 3px;">{device["role"]}</div>
    <div style="font-size: 11px; opacity: 0.8;">{device["ip"]}</div>
</div>
                ''')
            html_parts.append('</div>')
            
            if device_groups['switches'] or device_groups['others']:
                html_parts.append('<div style="display: flex; justify-content: center; margin: 10px 0;"><span style="font-size: 20px; color: #666;">↓</span></div>')
        
        if device_groups['switches']:
            html_parts.append('<div style="text-align: center; font-weight: bold; color: #333; margin-bottom: 10px; font-size: 14px;">🔀 SWITCHES</div>')
            html_parts.append('<div style="display: flex; justify-content: center; margin: 20px 0; flex-wrap: wrap;">')
            for device in device_groups['switches']:
                html_parts.append(f'''
<div style="background: linear-gradient(135deg, #4ecdc4, #26a69a); color: white; border: 2px solid #4ecdc4; border-radius: 8px; padding: 15px; margin: 10px; text-align: center; min-width: 120px; box-shadow: 0 4px 8px rgba(0,0,0,0.1);">
    <div style="font-weight: bold; font-size: 14px; margin-bottom: 5px;">🔀 {device["name"]}</div>
    <div style="font-size: 12px; opacity: 0.9; margin-bottom: 3px;">{device["role"]}</div>
    <div style="font-size: 11px; opacity: 0.8;">{device["ip"]}</div>
</div>
                ''')
            html_parts.append('</div>')
            
            if device_groups['others']:
                html_parts.append('<div style="display: flex; justify-content: center; margin: 10px 0;"><span style="font-size: 20px; color: #666;">↓</span></div>')
        
        if device_groups['others']:
            html_parts.append('<div style="text-align: center; font-weight: bold; color: #333; margin-bottom: 10px; font-size: 14px;">📟 OTHER DEVICES</div>')
            html_parts.append('<div style="display: flex; justify-content: center; margin: 20px 0; flex-wrap: wrap;">')
            for device in device_groups['others']:
                html_parts.append(f'''
<div style="background: linear-gradient(135deg, #74b9ff, #6c5ce7); color: white; border: 2px solid #74b9ff; border-radius: 8px; padding: 15px; margin: 10px; text-align: center; min-width: 120px; box-shadow: 0 4px 8px rgba(0,0,0,0.1);">
    <div style="font-weight: bold; font-size: 14px; margin-bottom: 5px;">📟 {device["name"]}</div>
    <div style="font-size: 12px; opacity: 0.9; margin-bottom: 3px;">{device["role"]}</div>
    <div style="font-size: 11px; opacity: 0.8;">{device["ip"]}</div>
</div>
                ''')
            html_parts.append('</div>')
        
        # Add connection info
        if connections:
            html_parts.append(f'<div style="text-align: center; margin-top: 20px; color: #666; font-size: 14px;">')
            html_parts.append(f'📊 {len(connections)} physical connections documented')
            html_parts.append('</div>')
        else:
            html_parts.append('<div style="text-align: center; margin-top: 20px; color: #666; font-size: 14px;">')
            html_parts.append('⚠️ Logical layout shown - no physical connections documented')
            html_parts.append('</div>')
        
        html_parts.append('</div>')
        
        return '\n'.join(html_parts)

    def _create_drawio_url(self, devices, connections):
        """Create a basic draw.io URL for external editing."""
        try:
            # Simple XML for draw.io
            xml_content = f"""<?xml version="1.0" encoding="UTF-8"?>
<mxfile>
  <diagram name="Network Topology">
    <mxGraphModel>
      <root>
        <mxCell id="0"/>
        <mxCell id="1" parent="0"/>
        <mxCell id="title" value="Network Topology - {len(devices)} devices" style="text;fontSize=16;" vertex="1" parent="1">
          <mxGeometry x="20" y="20" width="200" height="30" as="geometry"/>
        </mxCell>
      </root>
    </mxGraphModel>
  </diagram>
</mxfile>"""
            
            # Encode for URL
            encoded_xml = base64.b64encode(xml_content.encode('utf-8')).decode('utf-8')
            return f"https://app.diagrams.net/#R{encoded_xml}"
        except:
            return "https://app.diagrams.net/"

    def _infer_role_from_type(self, device_type, device_name):
        """Infer device role from type and name when role is generic."""
        type_and_name = f"{device_type} {device_name}".lower()
        
        # Common patterns to detect roles
        if any(keyword in type_and_name for keyword in ['router', 'border', 'gateway', 'asr', 'isr']):
            return 'Router'
        elif any(keyword in type_and_name for keyword in ['switch', '9300', '2960', '3850', 'catalyst']):
            return 'Switch'  
        elif any(keyword in type_and_name for keyword in ['firewall', 'asa', 'pix', 'fortigate']):
            return 'Firewall'
        elif any(keyword in type_and_name for keyword in ['server', 'host', 'vm']):
            return 'Server'
        elif any(keyword in type_and_name for keyword in ['ap', 'access', 'wireless']):
            return 'Access Point'
        elif any(keyword in type_and_name for keyword in ['load', 'balancer', 'f5', 'bigip']):
            return 'Load Balancer'
        else:
            return 'Network Device'

    def _get_short_device_name(self, device_name):
        """Create shorter, cleaner device names for topology display."""
        # Remove common prefixes/suffixes
        name = device_name
        
        # Common patterns to shorten
        replacements = {
            'Branch1_SDA_BORDER1_P24': 'Border-P24',
            'cisco_switch_9300': 'SW-9300',
            'cisco_switch_9300_QE': 'SW-9300-QE',
            'Branch1': 'BR1',
            'cisco': '',
            'switch': 'SW',
            'router': 'RTR',
            '_': '-'
        }
        
        for old, new in replacements.items():
            name = name.replace(old, new)
        
        # If still too long, truncate intelligently
        if len(name) > 12:
            parts = name.split('-')
            if len(parts) > 1:
                # Keep first and last part if multiple parts
                name = f"{parts[0]}-{parts[-1]}"
            else:
                # Truncate to 12 chars
                name = name[:12]
        
        return name.strip('-')

    def create_documentation_structure(self, location, timestamp):
        """Create folder structure for documentation."""
        base_dir = os.path.join(
            settings.BASE_DIR,
            "nautobot",
            "engineer_console",
            "static",
            "generated_docs"
        )
        
        # Create timestamped folder
        timestamp_dir = os.path.join(base_dir, timestamp, str(location.id))
        os.makedirs(timestamp_dir, exist_ok=True)
        
        # Create latest folder
        latest_dir = os.path.join(base_dir, "latest", str(location.id))
        os.makedirs(latest_dir, exist_ok=True)
        
        docs_structure = {
            'timestamp_dir': timestamp_dir,
            'latest_dir': latest_dir,
            'network_overview': os.path.join(timestamp_dir, 'network-overview.md'),
            'excel_workbook': os.path.join(timestamp_dir, 'network-documentation.xlsx'),
            'data_file': os.path.join(timestamp_dir, 'data.json'),
        }
        
        return docs_structure

    def generate_network_overview_document(self, location_data, docs_structure):
        """Generate single comprehensive network overview document."""
        
        # Save raw data as JSON
        with open(docs_structure['data_file'], 'w') as f:
            json.dump(location_data, f, indent=2, default=str)
        
        # Generate the comprehensive overview
        self.generate_comprehensive_overview(location_data, docs_structure['network_overview'])
        
        # Generate Excel workbook
        self.generate_excel_workbook(location_data, docs_structure)

    def generate_comprehensive_overview(self, location_data, file_path):
        """Generate comprehensive network overview with standard Markdown."""
        location = location_data['location']
        stats = location_data['statistics']
        devices = location_data['devices']
        racks = location_data['racks']
        vlans = location_data['vlans']
        prefixes = location_data['prefixes']
        topology = location_data['topology']
        
        content = f"""# 🌐 Network Overview: {location['name']}

**Generated**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')} | **Location ID**: `{location['id']}`

---

## 📊 Executive Summary

| **Metric** | **Count** | **Details** |
|------------|-----------|-------------|
| 🖥️ **Devices** | **{stats['total_devices']}** | {', '.join([f"{role}: {count}" for role, count in devices['summary']['by_role'].items()])} |
| 🏗️ **Racks** | **{stats['total_racks']}** | {racks['summary']['utilization_percent']}% utilization |
| 🌐 **VLANs** | **{stats['total_vlans']}** | Network segmentation |
| 📡 **IP Prefixes** | **{stats['total_prefixes']}** | Address space management |
| 🔗 **Connections** | **{stats['total_connections']}** | Physical topology |

---

## 🗺️ Network Topology

### 📊 Visual Topology

{topology['html_diagram']}

### 📝 ASCII Topology

```
{topology['ascii_diagram']}
```

### 📈 Topology Statistics

| **Layer** | **Device Count** | **Role** |
|-----------|------------------|----------|
| 🌐 **Core** | **{topology['topology_stats']['routers']}** | Routers & Border devices |
| 🔀 **Distribution** | **{topology['topology_stats']['switches']}** | Switches & Distribution |
| 📟 **Access** | **{topology['topology_stats']['other_devices']}** | Access Points & Others |

**Total Network Layers**: {topology['topology_stats']['layers']} | **Physical Connections**: {topology['topology_stats']['total_connections']}

### 🔧 Topology Features

- **Visual HTML Diagram**: Interactive layered network visualization with device details
- **ASCII Diagram**: Simple text-based network layout for universal compatibility
- **Layer Visualization**: Hierarchical network layout (Core → Distribution → Access)  
- **Device Categorization**: Automatic role detection and grouping
- **External Editor**: [Open in Draw.io]({topology['drawio_url']}) for advanced editing

---

## 🏗️ Physical Infrastructure & Rack Layouts

{self._create_rack_summary_section(racks)}

---

## 🏢 Location Information

| **Attribute** | **Value** |
|---------------|-----------|
| 📍 **Name** | {location['name']} |
| 📝 **Description** | {location['description'] or 'N/A'} |
| 🏗️ **Facility** | {location['facility'] or 'N/A'} |
| 📬 **Address** | {location['physical_address'] or 'N/A'} |
| 👥 **Tenant** | {location['tenant'] or 'N/A'} |

---

## 🖥️ Device Inventory

### Device Distribution by Role

| **Role** | **Count** | **Percentage** | **Visual** |
|----------|-----------|----------------|------------|
"""
        
        # Device roles chart
        for role, count in sorted(devices['summary']['by_role'].items(), key=lambda x: x[1], reverse=True):
            percentage = round((count / stats['total_devices']) * 100, 1)
            bar = "█" * int(percentage // 5)  # Visual bar
            emoji = "🌐" if 'router' in role.lower() else "🔀" if 'switch' in role.lower() else "📟"
            content += f"| {emoji} **{role}** | {count} | {percentage}% | `{bar}` |\n"

        content += f"""

### Device Details

| **Device** | **Type** | **Role** | **Rack** | **Position** | **Management IP** | **Status** |
|------------|----------|----------|----------|--------------|-------------------|------------|
"""
        
        # Device details table
        for device in sorted(devices['devices'], key=lambda x: (x['rack'], x.get('position', 0) or 0)):
            mgmt_ip = device['primary_ip4'] or device['primary_ip6'] or 'N/A'
            status_emoji = "🟢" if device['status'].lower() == 'active' else "🔴"
            role_emoji = "🌐" if 'router' in device['device_role'].lower() else "🔀" if 'switch' in device['device_role'].lower() else "📟"
            
            position = device.get('position', 'N/A')
            rack_info = f"{device['rack']}"
            if position != 'N/A':
                rack_info += f" (U{position})"
            
            content += f"| {role_emoji} **{device['name']}** | {device['device_type']} | {device['device_role']} | {rack_info} | {position} | `{mgmt_ip}` | {status_emoji} {device['status']} |\n"

        content += f"""

---

## 🌐 VLAN Configuration

### VLAN Summary

| **VLAN ID** | **Name** | **Role** | **Subnets** | **Status** | **Description** |
|-------------|----------|----------|-------------|------------|-----------------|
"""
        
        for vlan in vlans:
            subnet_list = ', '.join(vlan['subnets'][:2])  # Show first 2 subnets
            if len(vlan['subnets']) > 2:
                subnet_list += f" (+{len(vlan['subnets'])-2} more)"
            
            status_emoji = "🟢" if vlan['status'].lower() == 'active' else "🔴"
            content += f"| **{vlan['vid']}** | {vlan['name']} | {vlan['role']} | `{subnet_list or 'N/A'}` | {status_emoji} {vlan['status']} | {vlan['description']} |\n"

        content += f"""

---

## 📡 IP Address Management

### IP Prefix Summary

| **Prefix** | **VLAN** | **Role** | **Type** | **Status** | **Description** |
|------------|----------|----------|----------|------------|-----------------|
"""
        
        for prefix in prefixes:
            pool_type = "🏊 Pool" if prefix['is_pool'] else "📍 Network"
            status_emoji = "🟢" if prefix['status'].lower() == 'active' else "🔴"
            content += f"| `{prefix['prefix']}` | {prefix['vlan']} | {prefix['role']} | {pool_type} | {status_emoji} {prefix['status']} | {prefix['description']} |\n"

        content += f"""

---

## 🔗 Network Connectivity

### Connection Status

"""
        
        if location_data['connections']:
            active_connections = len([conn for conn in location_data['connections'] if conn['status'].lower() in ['connected', 'active']])
            connection_health = round((active_connections / len(location_data['connections'])) * 100, 1)
            
            content += f"""| **Metric** | **Value** | **Status** |
|------------|-----------|------------|
| **Total Physical Links** | {len(location_data['connections'])} | 📊 Documented |
| **Active Connections** | {active_connections} | {"🟢 Healthy" if connection_health >= 95 else "🟡 Warning" if connection_health >= 80 else "🔴 Critical"} |
| **Connection Health** | {connection_health}% | {"🟢 Excellent" if connection_health >= 95 else "🟡 Good" if connection_health >= 80 else "🔴 Needs Attention"} |

#### Physical Connection Details

| **From Device** | **Interface** | **To Device** | **Interface** | **Status** | **Cable Type** |
|-----------------|---------------|---------------|---------------|------------|----------------|
"""
            
            # Show connections
            for conn in location_data['connections'][:10]:  # Limit to first 10
                status_emoji = "🟢" if conn['status'].lower() in ['connected', 'active'] else "🔴"
                content += f"| {conn['from_device']} | `{conn['from_interface']}` | {conn['to_device']} | `{conn['to_interface']}` | {status_emoji} {conn['status']} | {conn['cable_type']} |\n"
            
            if len(location_data['connections']) > 10:
                content += f"\n*... and {len(location_data['connections']) - 10} more connections*\n"
        else:
            content += f"""| **Metric** | **Value** | **Status** |
|------------|-----------|------------|
| **Physical Connections** | 0 | ⚠️ Undocumented |
| **Topology Type** | Logical | 📊 Inferred from roles |
| **Recommendation** | Document cables | 🔧 Required |

> 💡 **Note**: The topology above shows a logical layout based on device roles. To see actual physical connections, add cable documentation in Nautobot DCIM.
"""

        content += f"""

---

## 📈 Network Health & Recommendations

### Key Performance Indicators

| **Metric** | **Value** | **Status** | **Action Required** |
|------------|-----------|------------|---------------------|
| 🖥️ **Device Availability** | {stats['total_devices']}/{stats['total_devices']} | 🟢 Operational | None |
| 🏗️ **Rack Utilization** | {racks['summary']['utilization_percent']}% | {"🟢 Optimal" if racks['summary']['utilization_percent'] < 80 else "⚠️ High"} | {"None" if racks['summary']['utilization_percent'] < 80 else "Monitor capacity"} |
| 🌐 **VLAN Usage** | {stats['total_vlans']} VLANs | 🟢 Configured | None |
| 📡 **IP Address Space** | {stats['total_prefixes']} Prefixes | 🟢 Allocated | None |
| 🔗 **Connectivity** | {stats['total_connections']} Links | {"🟢 Connected" if stats['total_connections'] > 0 else "⚠️ Undocumented"} | {"None" if stats['total_connections'] > 0 else "Document connections"} |

### Recommendations

"""
        
        # Intelligent recommendations
        recommendations = []
        
        if racks['summary']['utilization_percent'] > 80:
            recommendations.append("🚨 **High rack utilization detected** - Consider expanding rack space or optimizing device placement")
        
        if stats['total_connections'] == 0:
            recommendations.append("⚠️ **No network connections documented** - Add cable connections in Nautobot DCIM for accurate topology")
        
        if stats['total_vlans'] < 3:
            recommendations.append("💡 **Limited VLAN segmentation** - Consider additional VLANs for security and traffic management")
        
        if stats['total_devices'] > 20 and topology['topology_stats']['routers'] == 0:
            recommendations.append("📊 **No router devices found** - Verify device roles are properly configured")
        
        no_ip_devices = len([d for d in devices['devices'] if d['primary_ip4'] is None and d['primary_ip6'] is None])
        if no_ip_devices > 0:
            recommendations.append(f"🔧 **{no_ip_devices} devices without management IP** - Assign management IPs for better monitoring")
        
        high_util_racks = [r for r in racks['racks'] if r['utilization_percent'] > 80]
        if high_util_racks:
            recommendations.append(f"🏗️ **Rack capacity alert** - {len(high_util_racks)} rack(s) over 80% utilization")
        
        if not recommendations:
            recommendations.append("✅ **Network configuration looks healthy** - Continue regular monitoring and documentation updates")
        
        for i, rec in enumerate(recommendations, 1):
            content += f"{i}. {rec}\n"

        content += f"""

### Next Steps

1. **📊 Regular Monitoring**: Review this dashboard weekly for changes
2. **🔗 Connection Documentation**: Ensure all physical connections are documented  
3. **📡 IP Management**: Verify all devices have proper IP assignments
4. **🔧 Topology Validation**: Periodically validate topology accuracy
5. **🏗️ Rack Management**: Monitor rack utilization and plan for capacity
6. **📈 Capacity Planning**: Monitor rack and VLAN utilization trends

---

## 📚 Documentation Information

| **Attribute** | **Value** |
|---------------|-----------|
| 🕐 **Generated** | {datetime.now().strftime('%Y-%m-%d %H:%M:%S')} |
| 🏢 **Location** | {location['name']} |
| 🔧 **Source** | Nautobot Engineer Console |
| 📋 **Format** | Standard Markdown |
| 🔄 **Automation** | Documentation as Code |
| 📊 **Version** | v3.0 (Markdown Compatible) |

---

*This document was automatically generated using the **Engineer Console** plugin for Nautobot. For the most up-to-date information, re-run the documentation generation job.*

**🔗 Quick Links**: [🏠 Dashboard](/plugins/engineer-console/docs/) | [🔄 Regenerate](/plugins/engineer-console/jobs/) | [🎛️ Draw.io Editor]({topology['drawio_url']})
"""
        
        with open(file_path, 'w') as f:
            f.write(content)

    def generate_excel_workbook(self, location_data, docs_structure):
        """Generate comprehensive Excel workbook with multiple worksheets."""
        try:
            # Try to import openpyxl, if not available, create CSV files instead
            try:
                from openpyxl import Workbook
                from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
                from openpyxl.utils.dataframe import dataframe_to_rows
                excel_available = True
            except ImportError:
                excel_available = False
                self.logger.warning("openpyxl not available, generating CSV files instead")
            
            if excel_available:
                self._generate_excel_with_openpyxl(location_data, docs_structure)
            else:
                self._generate_csv_files(location_data, docs_structure)
                
        except Exception as e:
            self.logger.error(f"Failed to generate Excel/CSV files: {str(e)}")
            # Continue with markdown generation even if Excel fails

    def _generate_excel_with_openpyxl(self, location_data, docs_structure):
        """Generate Excel workbook using openpyxl."""
        try:
            from openpyxl import Workbook
            from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
            from openpyxl.chart import BarChart, PieChart, Reference
            
            wb = Workbook()
            
            # Define styles
            header_font = Font(bold=True, color="FFFFFF")
            header_fill = PatternFill(start_color="366092", end_color="366092", fill_type="solid")
            sub_header_fill = PatternFill(start_color="D9E2F3", end_color="D9E2F3", fill_type="solid")
            border = Border(left=Side(style='thin'), right=Side(style='thin'), 
                           top=Side(style='thin'), bottom=Side(style='thin'))
            center_align = Alignment(horizontal="center", vertical="center")
            
            # Remove default sheet
            wb.remove(wb.active)
            
            # 1. Overview Sheet
            overview_ws = wb.create_sheet("📊 Overview")
            self._create_overview_sheet(overview_ws, location_data, header_font, header_fill, border, center_align)
            
            # 2. Device Inventory Sheet
            devices_ws = wb.create_sheet("🖥️ Device Inventory")
            self._create_devices_sheet(devices_ws, location_data, header_font, header_fill, border)
            
            # 3. Rack Layouts Sheet
            racks_ws = wb.create_sheet("🏗️ Rack Layouts")
            self._create_racks_sheet(racks_ws, location_data, header_font, header_fill, sub_header_fill, border)
            
            # 4. VLAN Configuration Sheet
            vlans_ws = wb.create_sheet("🌐 VLANs")
            self._create_vlans_sheet(vlans_ws, location_data, header_font, header_fill, border)
            
            # 5. IP Addressing Sheet
            ip_ws = wb.create_sheet("📡 IP Addressing")
            self._create_ip_sheet(ip_ws, location_data, header_font, header_fill, border)
            
            # 6. Network Topology Sheet
            topology_ws = wb.create_sheet("🔗 Network Topology")
            self._create_topology_sheet(topology_ws, location_data, header_font, header_fill, border)
            
            # Save the workbook
            wb.save(docs_structure['excel_workbook'])
            self.logger.info(f"Excel workbook saved: {docs_structure['excel_workbook']}")
            
        except ImportError as e:
            self.logger.error(f"Failed to import openpyxl: {e}")
            return
        except Exception as e:
            self.logger.error(f"Failed to generate Excel file: {e}")
            return

    def _create_overview_sheet(self, ws, location_data, header_font, header_fill, border, center_align):
        """Create overview worksheet."""
        location = location_data['location']
        stats = location_data['statistics']
        
        # Title
        ws['A1'] = f"Network Overview: {location['name']}"
        ws['A1'].font = Font(size=16, bold=True)
        ws.merge_cells('A1:F1')
        
        # Location Information
        ws['A3'] = "Location Information"
        ws['A3'].font = header_font
        ws['A3'].fill = header_fill
        ws.merge_cells('A3:B3')
        
        location_info = [
            ["Name", location['name']],
            ["Description", location['description'] or 'N/A'],
            ["Facility", location['facility'] or 'N/A'],
            ["Address", location['physical_address'] or 'N/A'],
            ["Tenant", location['tenant'] or 'N/A']
        ]
        
        for row_idx, (key, value) in enumerate(location_info, start=4):
            ws[f'A{row_idx}'] = key
            ws[f'B{row_idx}'] = value
            ws[f'A{row_idx}'].border = border
            ws[f'B{row_idx}'].border = border
        
        # Infrastructure Summary
        ws['D3'] = "Infrastructure Summary"
        ws['D3'].font = header_font
        ws['D3'].fill = header_fill
        ws.merge_cells('D3:E3')
        
        infrastructure_info = [
            ["Devices", stats['total_devices']],
            ["Racks", stats['total_racks']],
            ["VLANs", stats['total_vlans']],
            ["IP Prefixes", stats['total_prefixes']],
            ["Connections", stats['total_connections']]
        ]
        
        for row_idx, (key, value) in enumerate(infrastructure_info, start=4):
            ws[f'D{row_idx}'] = key
            ws[f'E{row_idx}'] = value
            ws[f'D{row_idx}'].border = border
            ws[f'E{row_idx}'].border = border
        
        # Auto-size columns
        for column in ws.columns:
            max_length = 0
            column_letter = column[0].column_letter
            for cell in column:
                try:
                    if len(str(cell.value)) > max_length:
                        max_length = len(str(cell.value))
                except:
                    pass
            adjusted_width = min(max_length + 2, 50)
            ws.column_dimensions[column_letter].width = adjusted_width

    def _create_devices_sheet(self, ws, location_data, header_font, header_fill, border):
        """Create devices worksheet."""
        # Headers
        headers = ["Device Name", "Type", "Manufacturer", "Role", "Rack", "U Position", 
                  "Status", "Management IP", "Serial", "Platform"]
        
        for col_idx, header in enumerate(headers, start=1):
            cell = ws.cell(row=1, column=col_idx, value=header)
            cell.font = header_font
            cell.fill = header_fill
            cell.border = border
            cell.alignment = Alignment(horizontal="center")
        
        # Device data
        devices = location_data['devices']['devices']
        for row_idx, device in enumerate(devices, start=2):
            data = [
                device['name'],
                device['device_type'],
                device['manufacturer'],
                device['device_role'],
                device['rack'],
                device['position'] or 'N/A',
                device['status'],
                device['primary_ip4'] or device['primary_ip6'] or 'N/A',
                device['serial'],
                device['platform']
            ]
            
            for col_idx, value in enumerate(data, start=1):
                cell = ws.cell(row=row_idx, column=col_idx, value=value)
                cell.border = border
                
                # Color code status
                if col_idx == 7:  # Status column
                    if str(value).lower() == 'active':
                        cell.fill = PatternFill(start_color="C6EFCE", end_color="C6EFCE", fill_type="solid")
                    else:
                        cell.fill = PatternFill(start_color="FFC7CE", end_color="FFC7CE", fill_type="solid")
        
        # Auto-size columns
        for column in ws.columns:
            max_length = 0
            column_letter = column[0].column_letter
            for cell in column:
                try:
                    if len(str(cell.value)) > max_length:
                        max_length = len(str(cell.value))
                except:
                    pass
            adjusted_width = min(max_length + 2, 50)
            ws.column_dimensions[column_letter].width = adjusted_width

    def _create_racks_sheet(self, ws, location_data, header_font, header_fill, sub_header_fill, border):
        """Create racks worksheet."""
        current_row = 1
        
        # Rack Summary
        ws[f'A{current_row}'] = "Rack Summary"
        ws[f'A{current_row}'].font = Font(size=14, bold=True)
        ws.merge_cells(f'A{current_row}:F{current_row}')
        current_row += 2
        
        # Summary headers
        summary_headers = ["Rack Name", "U Height", "Used U", "Utilization %", "Device Count", "Status"]
        for col_idx, header in enumerate(summary_headers, start=1):
            cell = ws.cell(row=current_row, column=col_idx, value=header)
            cell.font = header_font
            cell.fill = header_fill
            cell.border = border
        current_row += 1
        
        # Summary data
        racks = location_data['racks']['racks']
        for rack in racks:
            data = [
                rack['name'],
                rack['u_height'],
                rack['used_u'],
                rack['utilization_percent'],
                rack['device_count'],
                rack['status']
            ]
            
            for col_idx, value in enumerate(data, start=1):
                cell = ws.cell(row=current_row, column=col_idx, value=value)
                cell.border = border
                
                # Color code utilization
                if col_idx == 4:  # Utilization column
                    if value < 70:
                        cell.fill = PatternFill(start_color="C6EFCE", end_color="C6EFCE", fill_type="solid")
                    elif value < 90:
                        cell.fill = PatternFill(start_color="FFEB9C", end_color="FFEB9C", fill_type="solid")
                    else:
                        cell.fill = PatternFill(start_color="FFC7CE", end_color="FFC7CE", fill_type="solid")
            current_row += 1
        
        current_row += 2
        
        # Detailed rack layouts
        for rack in racks:
            if rack['devices_layout']:
                # Rack header
                ws[f'A{current_row}'] = f"{rack['name']} - Device Layout"
                ws[f'A{current_row}'].font = Font(size=12, bold=True)
                ws.merge_cells(f'A{current_row}:G{current_row}')
                current_row += 1
                
                # Device headers
                device_headers = ["U Position", "Device Name", "Type", "Role", "Status", "Management IP", "Face"]
                for col_idx, header in enumerate(device_headers, start=1):
                    cell = ws.cell(row=current_row, column=col_idx, value=header)
                    cell.font = header_font
                    cell.fill = sub_header_fill
                    cell.border = border
                current_row += 1
                
                # Device data
                for u_pos in sorted(rack['devices_layout'].keys(), reverse=True):
                    device = rack['devices_layout'][u_pos]
                    data = [
                        f"U{u_pos}",
                        device['name'],
                        device['device_type'],
                        device['device_role'],
                        device['status'],
                        device['primary_ip'],
                        device['face']
                    ]
                    
                    for col_idx, value in enumerate(data, start=1):
                        cell = ws.cell(row=current_row, column=col_idx, value=value)
                        cell.border = border
                        
                        # Color code status
                        if col_idx == 5:  # Status column
                            if str(value).lower() == 'active':
                                cell.fill = PatternFill(start_color="C6EFCE", end_color="C6EFCE", fill_type="solid")
                            else:
                                cell.fill = PatternFill(start_color="FFC7CE", end_color="FFC7CE", fill_type="solid")
                    current_row += 1
                
                current_row += 1  # Space between racks
        
        # Auto-size columns
        for column in ws.columns:
            max_length = 0
            column_letter = column[0].column_letter
            for cell in column:
                try:
                    if len(str(cell.value)) > max_length:
                        max_length = len(str(cell.value))
                except:
                    pass
            adjusted_width = min(max_length + 2, 30)
            ws.column_dimensions[column_letter].width = adjusted_width

    def _create_vlans_sheet(self, ws, location_data, header_font, header_fill, border):
        """Create VLANs worksheet."""
        headers = ["VLAN ID", "Name", "Role", "Status", "Subnets", "Description"]
        
        for col_idx, header in enumerate(headers, start=1):
            cell = ws.cell(row=1, column=col_idx, value=header)
            cell.font = header_font
            cell.fill = header_fill
            cell.border = border
        
        vlans = location_data['vlans']
        for row_idx, vlan in enumerate(vlans, start=2):
            subnet_list = ', '.join(vlan['subnets'][:3])  # Show first 3 subnets
            if len(vlan['subnets']) > 3:
                subnet_list += f" (+{len(vlan['subnets'])-3} more)"
            
            data = [
                vlan['vid'],
                vlan['name'],
                vlan['role'],
                vlan['status'],
                subnet_list or 'N/A',
                vlan['description']
            ]
            
            for col_idx, value in enumerate(data, start=1):
                cell = ws.cell(row=row_idx, column=col_idx, value=value)
                cell.border = border
                
                # Color code status
                if col_idx == 4:  # Status column
                    if str(value).lower() == 'active':
                        cell.fill = PatternFill(start_color="C6EFCE", end_color="C6EFCE", fill_type="solid")
                    else:
                        cell.fill = PatternFill(start_color="FFC7CE", end_color="FFC7CE", fill_type="solid")
        
        # Auto-size columns
        for column in ws.columns:
            max_length = 0
            column_letter = column[0].column_letter
            for cell in column:
                try:
                    if len(str(cell.value)) > max_length:
                        max_length = len(str(cell.value))
                except:
                    pass
            adjusted_width = min(max_length + 2, 50)
            ws.column_dimensions[column_letter].width = adjusted_width

    def _create_ip_sheet(self, ws, location_data, header_font, header_fill, border):
        """Create IP addressing worksheet."""
        headers = ["Prefix", "VLAN", "Role", "Type", "Status", "Description"]
        
        for col_idx, header in enumerate(headers, start=1):
            cell = ws.cell(row=1, column=col_idx, value=header)
            cell.font = header_font
            cell.fill = header_fill
            cell.border = border
        
        prefixes = location_data['prefixes']
        for row_idx, prefix in enumerate(prefixes, start=2):
            data = [
                prefix['prefix'],
                prefix['vlan'],
                prefix['role'],
                "Pool" if prefix['is_pool'] else "Network",
                prefix['status'],
                prefix['description']
            ]
            
            for col_idx, value in enumerate(data, start=1):
                cell = ws.cell(row=row_idx, column=col_idx, value=value)
                cell.border = border
                
                # Color code status
                if col_idx == 5:  # Status column
                    if str(value).lower() == 'active':
                        cell.fill = PatternFill(start_color="C6EFCE", end_color="C6EFCE", fill_type="solid")
                    else:
                        cell.fill = PatternFill(start_color="FFC7CE", end_color="FFC7CE", fill_type="solid")
        
        # Auto-size columns
        for column in ws.columns:
            max_length = 0
            column_letter = column[0].column_letter
            for cell in column:
                try:
                    if len(str(cell.value)) > max_length:
                        max_length = len(str(cell.value))
                except:
                    pass
            adjusted_width = min(max_length + 2, 40)
            ws.column_dimensions[column_letter].width = adjusted_width

    def _create_topology_sheet(self, ws, location_data, header_font, header_fill, border):
        """Create network topology worksheet."""
        headers = ["From Device", "From Interface", "To Device", "To Interface", "Status", "Cable Type"]
        
        for col_idx, header in enumerate(headers, start=1):
            cell = ws.cell(row=1, column=col_idx, value=header)
            cell.font = header_font
            cell.fill = header_fill
            cell.border = border
        
        connections = location_data['connections']
        if connections:
            for row_idx, conn in enumerate(connections, start=2):
                data = [
                    conn['from_device'],
                    conn['from_interface'],
                    conn['to_device'],
                    conn['to_interface'],
                    conn['status'],
                    conn['cable_type']
                ]
                
                for col_idx, value in enumerate(data, start=1):
                    cell = ws.cell(row=row_idx, column=col_idx, value=value)
                    cell.border = border
                    
                    # Color code status
                    if col_idx == 5:  # Status column
                        if str(value).lower() in ['connected', 'active']:
                            cell.fill = PatternFill(start_color="C6EFCE", end_color="C6EFCE", fill_type="solid")
                        else:
                            cell.fill = PatternFill(start_color="FFC7CE", end_color="FFC7CE", fill_type="solid")
        else:
            ws['A2'] = "No physical connections documented"
            ws.merge_cells('A2:F2')
        
        # Auto-size columns
        for column in ws.columns:
            max_length = 0
            column_letter = column[0].column_letter
            for cell in column:
                try:
                    if len(str(cell.value)) > max_length:
                        max_length = len(str(cell.value))
                except:
                    pass
            adjusted_width = min(max_length + 2, 30)
            ws.column_dimensions[column_letter].width = adjusted_width

    def _generate_csv_files(self, location_data, docs_structure):
        """Generate CSV files if Excel is not available."""
        import csv
        
        base_path = docs_structure['timestamp_dir']
        
        # Devices CSV
        with open(os.path.join(base_path, 'devices.csv'), 'w', newline='', encoding='utf-8') as f:
            writer = csv.writer(f)
            writer.writerow(["Device Name", "Type", "Manufacturer", "Role", "Rack", "U Position", 
                           "Status", "Management IP", "Serial", "Platform"])
            
            for device in location_data['devices']['devices']:
                writer.writerow([
                    device['name'], device['device_type'], device['manufacturer'],
                    device['device_role'], device['rack'], device['position'] or 'N/A',
                    device['status'], device['primary_ip4'] or device['primary_ip6'] or 'N/A',
                    device['serial'], device['platform']
                ])
        
        # Racks CSV
        with open(os.path.join(base_path, 'racks.csv'), 'w', newline='', encoding='utf-8') as f:
            writer = csv.writer(f)
            writer.writerow(["Rack Name", "U Height", "Used U", "Utilization %", "Device Count", "Status"])
            
            for rack in location_data['racks']['racks']:
                writer.writerow([
                    rack['name'], rack['u_height'], rack['used_u'],
                    rack['utilization_percent'], rack['device_count'], rack['status']
                ])
        
        # VLANs CSV
        with open(os.path.join(base_path, 'vlans.csv'), 'w', newline='', encoding='utf-8') as f:
            writer = csv.writer(f)
            writer.writerow(["VLAN ID", "Name", "Role", "Status", "Subnets", "Description"])
            
            for vlan in location_data['vlans']:
                subnet_list = ', '.join(vlan['subnets'][:3])
                if len(vlan['subnets']) > 3:
                    subnet_list += f" (+{len(vlan['subnets'])-3} more)"
                
                writer.writerow([
                    vlan['vid'], vlan['name'], vlan['role'], vlan['status'],
                    subnet_list or 'N/A', vlan['description']
                ])
        
        self.logger.info(f"CSV files generated in: {base_path}")

    def create_symlinks(self, docs_structure, location):
        """Create symlinks for latest documentation."""
        timestamp_dir = docs_structure['timestamp_dir']
        latest_dir = docs_structure['latest_dir']
        
        files_to_link = [
            'network-overview.md',
            'network-documentation.xlsx',
            'data.json'
        ]
        
        for filename in files_to_link:
            source_file = os.path.join(timestamp_dir, filename)
            symlink_path = os.path.join(latest_dir, filename)
            
            # Remove existing symlink if it exists
            if os.path.islink(symlink_path) or os.path.exists(symlink_path):
                try:
                    os.remove(symlink_path)
                except OSError:
                    pass
            
            # Create new symlink
            if os.path.exists(source_file):
                try:
                    os.symlink(source_file, symlink_path)
                except OSError as e:
                    self.logger.warning(f"Failed to create symlink for {filename}: {e}")
        
        self.logger.info(f"Created symlinks in {latest_dir}")
        """Create symlinks for latest documentation."""
        timestamp_dir = docs_structure['timestamp_dir']
        latest_dir = docs_structure['latest_dir']
        
        files_to_link = [
            'network-overview.md',
            'data.json'
        ]
        
        for filename in files_to_link:
            source_file = os.path.join(timestamp_dir, filename)
            symlink_path = os.path.join(latest_dir, filename)
            
            # Remove existing symlink if it exists
            if os.path.islink(symlink_path) or os.path.exists(symlink_path):
                os.remove(symlink_path)
            
            # Create new symlink
            if os.path.exists(source_file):
                os.symlink(source_file, symlink_path)
        
        self.logger.info(f"Created symlinks in {latest_dir}")


# Keep the existing GenerateLocationDocsJob and GenerateDocsJob classes with fixes
class GenerateLocationDocsJob(Job):
    """Generate comprehensive network documentation for a selected location (detailed multi-file)."""

    name = "Generate Location Documentation (Detailed)"
    grouping = "Documentation"
    description = "Generate comprehensive network documentation with multiple detailed files"
    has_sensitive_variables = False

    # Location selection field
    location = ObjectVar(
        model=apps.get_model("dcim", "Location"),
        description="Select location to generate documentation for",
        required=True
    )

    class Meta:
        name = "Generate Location Documentation (Detailed)"
        description = "Generate comprehensive network documentation with multiple detailed files"
        has_sensitive_variables = False
        approval_required = False

    def run(self, data=None, commit=None, **kwargs):
        try:
            self.logger.info("🚀 Starting location documentation generation...")

            # Get selected location - handle case where data is None
            location = None
            if data and isinstance(data, dict):
                location = data.get('location')
            if not location and kwargs:
                location = kwargs.get('location')
            
            if not location:
                raise ValueError("Location is required. Please select a location when running the job.")

            self.logger.info(f"📍 Generating documentation for location: {location.name}")

            # Extract comprehensive data for the location
            location_data = self.extract_location_data(location)
            
            # Generate timestamped documentation
            timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")
            
            # Create organized folder structure
            docs_structure = self.create_documentation_structure(location, timestamp)
            
            # Generate comprehensive documentation
            self.generate_comprehensive_docs(location_data, docs_structure)
            
            # Create symlinks for latest documentation
            self.create_symlinks(docs_structure, location)
            
            self.logger.info("✅ Location documentation generated successfully!")

            result_message = f"""
Location Documentation Generation Completed!

📍 **Location**: {location.name}
📊 **Statistics**:
- Devices: {len(location_data['devices'])}
- Racks: {len(location_data['racks'])}
- VLANs: {len(location_data['vlans'])}
- IP Prefixes: {len(location_data['prefixes'])}
- Interfaces: {len(location_data['interfaces'])}

📁 **Documentation Structure**:
- Main Report: {docs_structure['main_report']}
- Device Inventory: {docs_structure['device_inventory']}
- VLAN Configuration: {docs_structure['vlan_config']}
- Rack Layout: {docs_structure['rack_layout']}
- Network Topology: {docs_structure['network_topology']}

🔗 **Quick Access**:
- Latest Documentation: /static/generated_docs/latest/{location.id}/
- Timestamped Version: /static/generated_docs/{timestamp}/{location.id}/
"""
            return result_message

        except Exception as e:
            self.logger.error(f"❌ Documentation generation failed: {str(e)}")
            import traceback
            self.logger.error(f"Full traceback: {traceback.format_exc()}")
            raise

    def extract_location_data(self, location):
        """Extract comprehensive data for the selected location."""
        self.logger.info(f"📊 Extracting data for location: {location.name}")
        
        from django.apps import apps
        Device = apps.get_model("dcim", "Device")
        Rack = apps.get_model("dcim", "Rack")
        Interface = apps.get_model("dcim", "Interface")
        VLAN = apps.get_model("ipam", "VLAN")
        Prefix = apps.get_model("ipam", "Prefix")
        IPAddress = apps.get_model("ipam", "IPAddress")
        Cable = apps.get_model("dcim", "Cable")
        
        # Get all devices in this location
        devices = Device.objects.filter(location=location).select_related(
            'device_type', 'role', 'platform', 'rack'
        ).prefetch_related('primary_ip4', 'primary_ip6')
        
        # Get all racks in this location
        racks = Rack.objects.filter(location=location).select_related(
            'role', 'tenant'
        ).prefetch_related('devices')
        
        # Get all VLANs associated with this location
        vlans = VLAN.objects.filter(location=location).select_related(
            'tenant', 'role'
        ).prefetch_related('prefixes')
        
        # Get all IP prefixes for this location
        prefixes = Prefix.objects.filter(location=location).select_related(
            'tenant', 'role', 'vlan'
        )
        
        # Get all interfaces for devices in this location
        interfaces = Interface.objects.filter(device__location=location).select_related(
            'device', 'lag', 'untagged_vlan'
        ).prefetch_related('tagged_vlans', 'ip_addresses')
        
        # Get cables connecting devices in this location
        cables = Cable.objects.filter(
            _termination_a_device__location=location
        ).select_related('status')
        
        # Get IP addresses assigned to devices in this location
        ip_addresses = IPAddress.objects.filter(
                interfaces__in=interfaces
            ).select_related('tenant', 'role')

        
        # Structure the data
        location_data = {
            'location': {
                'name': location.name,
                'slug': str(location.id),
                'description': location.description or '',
                'facility': getattr(location, 'facility', ''),
                'physical_address': getattr(location, 'physical_address', ''),
                'tenant': location.tenant.name if location.tenant else None,
            },
            'devices': self._process_devices(devices),
            'racks': self._process_racks(racks),
            'vlans': self._process_vlans(vlans),
            'prefixes': self._process_prefixes(prefixes),
            'interfaces': self._process_interfaces(interfaces),
            'cables': self._process_cables(cables),
            'ip_addresses': self._process_ip_addresses(ip_addresses),
            'statistics': {
                'total_devices': devices.count(),
                'total_racks': racks.count(),
                'total_vlans': vlans.count(),
                'total_prefixes': prefixes.count(),
                'total_interfaces': interfaces.count(),
                'total_cables': cables.count(),
                'total_ip_addresses': ip_addresses.count(),
            }
        }
        
        return location_data
    
    def _process_devices(self, devices):
        """Process device data."""
        processed_devices = []
        for device in devices:
            device_data = {
                'name': device.name,
                'device_type': device.device_type.model if device.device_type else 'Unknown',
                'manufacturer': device.device_type.manufacturer.name if device.device_type and device.device_type.manufacturer else 'Unknown',
                'device_role': device.role.name if device.role else 'Unknown',
                'platform': device.platform.name if device.platform else 'Unknown',
                'rack': device.rack.name if device.rack else 'Not Racked',
                'position': device.position,
                'serial': device.serial or 'N/A',
                'asset_tag': device.asset_tag or 'N/A',
                'status': device.status.name if device.status else 'Unknown',
                'primary_ip4': str(device.primary_ip4.address) if device.primary_ip4 else 'N/A',
                'primary_ip6': str(device.primary_ip6.address) if device.primary_ip6 else 'N/A',
                'tenant': device.tenant.name if device.tenant else 'N/A',
                'comments': device.comments or 'N/A',
            }
            processed_devices.append(device_data)
        
        return processed_devices
    
    def _process_racks(self, racks):
        """Process rack data."""
        processed_racks = []
        for rack in racks:
            rack_data = {
                'name': rack.name,
                'facility_id': getattr(rack, 'facility_id', 'N/A'),
                'tenant': rack.tenant.name if rack.tenant else 'N/A',
                'role': rack.role.name if rack.role else 'N/A',
                'u_height': rack.u_height,
                'desc_units': rack.desc_units,
                'status': rack.status.name if rack.status else 'Unknown',
                'serial': rack.serial or 'N/A',
                'asset_tag': rack.asset_tag or 'N/A',
                'device_count': rack.devices.count(),
                'devices': [device.name for device in rack.devices.all()],
                'comments': rack.comments or 'N/A',
            }
            processed_racks.append(rack_data)
        
        return processed_racks
    
    def _process_vlans(self, vlans):
        """Process VLAN data."""
        processed_vlans = []
        for vlan in vlans:
            # Get associated prefixes
            prefixes = [str(prefix.prefix) for prefix in vlan.prefixes.all()]
            
            vlan_data = {
                'vid': vlan.vid,
                'name': vlan.name,
                'tenant': vlan.tenant.name if vlan.tenant else 'N/A',
                'role': vlan.role.name if vlan.role else 'N/A',
                'status': vlan.status.name if vlan.status else 'Unknown',
                'description': vlan.description or 'N/A',
                'prefixes': prefixes,
                'gateway': prefixes[0].split('/')[0] if prefixes else 'N/A',  # First IP as gateway
            }
            processed_vlans.append(vlan_data)
        
        return processed_vlans
    
    def _process_prefixes(self, prefixes):
        """Process IP prefix data."""
        processed_prefixes = []
        for prefix in prefixes:
            prefix_data = {
                'prefix': str(prefix.prefix),
                'tenant': prefix.tenant.name if prefix.tenant else 'N/A',
                'role': prefix.role.name if prefix.role else 'N/A',
                'vlan': f"VLAN {prefix.vlan.vid} ({prefix.vlan.name})" if prefix.vlan else 'N/A',
                'status': prefix.status.name if prefix.status else 'Unknown',
                'description': prefix.description or 'N/A',
                'is_pool': prefix.is_pool,
            }
            processed_prefixes.append(prefix_data)
        
        return processed_prefixes
    
    def _process_interfaces(self, interfaces):
        """Process interface data."""
        processed_interfaces = []
        for interface in interfaces:
            interface_data = {
                'device': interface.device.name,
                'name': interface.name,
                'type': interface.type or 'Unknown',
                'enabled': interface.enabled,
                'mtu': interface.mtu or 'Default',
                'mac_address': str(interface.mac_address) if interface.mac_address else 'N/A',
                'description': interface.description or 'N/A',
                'lag': interface.lag.name if interface.lag else 'N/A',
                'untagged_vlan': f"VLAN {interface.untagged_vlan.vid}" if interface.untagged_vlan else 'N/A',
                'tagged_vlans': [f"VLAN {vlan.vid}" for vlan in interface.tagged_vlans.all()],
                'ip_addresses': [str(ip.address) for ip in interface.ip_addresses.all()],
            }
            processed_interfaces.append(interface_data)
        
        return processed_interfaces
    
    def _process_cables(self, cables):
        """Process cable connection data."""
        processed_cables = []
        for cable in cables:
            cable_data = {
                'label': cable.label or f"Cable {cable.id}",
                'type': cable.type or 'Unknown',
                'status': cable.status.name if cable.status else 'Unknown',
                'length': cable.length or 'N/A',
                'length_unit': cable.length_unit if cable.length_unit else 'N/A',
                'a_terminations': [str(cable.termination_a)] if cable.termination_a else [],
                'b_terminations': [str(cable.termination_b)] if cable.termination_b else [],
            }
            processed_cables.append(cable_data)
        
        return processed_cables
    
    def _process_ip_addresses(self, ip_addresses):
        """Process IP address data."""
        processed_ips = []
        for ip in ip_addresses:
            ip_data = {
                'address': str(ip.address),
                'status': ip.status.name if ip.status else 'Unknown',
                'role': ip.role.name if ip.role else 'N/A',
                'tenant': ip.tenant.name if ip.tenant else 'N/A',
                'dns_name': ip.dns_name or 'N/A',
                'description': ip.description or 'N/A',
                'assigned_object': ', '.join([f"{iface.device.name}/{iface.name}" for iface in ip.interfaces.all()]) if hasattr(ip, 'interfaces') and ip.interfaces.exists() else 'N/A',
            }
            processed_ips.append(ip_data)
        
        return processed_ips

    def create_documentation_structure(self, location, timestamp):
        """Create organized folder structure for documentation."""
        base_dir = os.path.join(
            settings.BASE_DIR,
            "nautobot",
            "engineer_console",
            "static",
            "generated_docs"
        )
        
        # Create timestamped folder
        timestamp_dir = os.path.join(base_dir, timestamp, str(location.id))
        os.makedirs(timestamp_dir, exist_ok=True)
        
        # Create latest folder
        latest_dir = os.path.join(base_dir, "latest", str(location.id))
        os.makedirs(latest_dir, exist_ok=True)
        
        docs_structure = {
            'timestamp_dir': timestamp_dir,
            'latest_dir': latest_dir,
            'main_report': os.path.join(timestamp_dir, 'main-report.md'),
            'device_inventory': os.path.join(timestamp_dir, 'device-inventory.md'),
            'vlan_config': os.path.join(timestamp_dir, 'vlan-configuration.md'),
            'rack_layout': os.path.join(timestamp_dir, 'rack-layout.md'),
            'network_topology': os.path.join(timestamp_dir, 'network-topology.md'),
            'ip_addressing': os.path.join(timestamp_dir, 'ip-addressing.md'),
            'interface_details': os.path.join(timestamp_dir, 'interface-details.md'),
            'data_file': os.path.join(timestamp_dir, 'data.json'),
        }
        
        return docs_structure

    def generate_comprehensive_docs(self, location_data, docs_structure):
        """Generate comprehensive documentation files."""
        
        # Save raw data as JSON
        with open(docs_structure['data_file'], 'w') as f:
            json.dump(location_data, f, indent=2, default=str)
        
        # Generate main report
        self.generate_main_report(location_data, docs_structure['main_report'])
        
        # Generate device inventory
        self.generate_device_inventory(location_data, docs_structure['device_inventory'])
        
        # Generate VLAN configuration
        self.generate_vlan_configuration(location_data, docs_structure['vlan_config'])
        
        # Generate rack layout
        self.generate_rack_layout(location_data, docs_structure['rack_layout'])
        
        # Generate network topology
        self.generate_network_topology(location_data, docs_structure['network_topology'])
        
        # Generate IP addressing
        self.generate_ip_addressing(location_data, docs_structure['ip_addressing'])
        
        # Generate interface details
        self.generate_interface_details(location_data, docs_structure['interface_details'])
    
    def generate_main_report(self, location_data, file_path):
        """Generate main overview report."""
        location = location_data['location']
        stats = location_data['statistics']
        
        content = f"""# Network Documentation Report
## {location['name']}

**Generated**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

---

## Location Overview

| Attribute | Value |
|-----------|-------|
| **Name** | {location['name']} |
| **Description** | {location['description']} |
| **Facility** | {location['facility']} |
| **Physical Address** | {location['physical_address']} |
| **Tenant** | {location['tenant'] or 'N/A'} |

---

## Infrastructure Summary

| Resource | Count |
|----------|-------|
| **Devices** | {stats['total_devices']} |
| **Racks** | {stats['total_racks']} |
| **VLANs** | {stats['total_vlans']} |
| **IP Prefixes** | {stats['total_prefixes']} |
| **Interfaces** | {stats['total_interfaces']} |
| **Cables** | {stats['total_cables']} |
| **IP Addresses** | {stats['total_ip_addresses']} |

---

## Device Roles Summary

| Role | Count |
|------|-------|
"""
        
        # Count devices by role
        device_roles = {}
        for device in location_data['devices']:
            role = device['device_role']
            device_roles[role] = device_roles.get(role, 0) + 1
        
        for role, count in sorted(device_roles.items()):
            content += f"| {role} | {count} |\n"
        
        content += f"""
---

## Documentation Sections

- [📱 Device Inventory](device-inventory.md) - Complete device listing with specifications
- [🏗️ Rack Layout](rack-layout.md) - Physical rack arrangements and device placement
- [🌐 VLAN Configuration](vlan-configuration.md) - VLAN configuration and subnet assignments
- [🔗 Network Topology](network-topology.md) - Network connections and cable layout
- [📡 IP Addressing](ip-addressing.md) - IP address assignments and subnets
- [🔌 Interface Details](interface-details.md) - Complete interface configurations

---

## Quick Stats

### Most Common Device Types
"""
        
        # Count devices by type
        device_types = {}
        for device in location_data['devices']:
            device_type = device['device_type']
            device_types[device_type] = device_types.get(device_type, 0) + 1
        
        for device_type, count in sorted(device_types.items(), key=lambda x: x[1], reverse=True)[:5]:
            content += f"- **{device_type}**: {count} devices\n"
        
        content += f"""
### VLAN Usage
- **Total VLANs**: {stats['total_vlans']}
- **IP Prefixes**: {stats['total_prefixes']}
- **Assigned IP Addresses**: {stats['total_ip_addresses']}

---

*This documentation was automatically generated from Nautobot on {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}*
"""
        
        with open(file_path, 'w') as f:
            f.write(content)
    
    def generate_vlan_configuration(self, location_data, file_path):
        """Generate VLAN configuration documentation similar to the provided table."""
        content = f"""# VLAN Configuration Table
## {location_data['location']['name']}

**Generated**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

---

## VLAN Summary

| VLAN ID | VLAN Name | Subnet | Gateway | Description |
|---------|-----------|--------|---------|-------------|
"""
        
        for vlan in sorted(location_data['vlans'], key=lambda x: x['vid']):
            # Get the first prefix as the subnet
            subnet = vlan['prefixes'][0] if vlan['prefixes'] else 'N/A'
            
            # Calculate gateway from subnet (first IP)
            gateway = 'N/A'
            if subnet != 'N/A':
                try:
                    import ipaddress
                    network = ipaddress.ip_network(subnet, strict=False)
                    gateway = str(network.network_address + 1)  # Gateway is typically first usable IP
                except:
                    gateway = 'N/A'
            
            content += f"| {vlan['vid']} | {vlan['name']} | {subnet} | {gateway} | {vlan['description']} |\n"
        
        content += f"""
---

*Generated automatically from Nautobot on {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}*
"""
        
        with open(file_path, 'w') as f:
            f.write(content)
    
    def generate_device_inventory(self, location_data, file_path):
        """Generate detailed device inventory."""
        content = f"""# Device Inventory
## {location_data['location']['name']}

**Generated**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

---

## Device Summary

| Device | Type | Role | Rack | Position | Management IP | Status |
|--------|------|------|------|----------|---------------|--------|
"""
        
        for device in sorted(location_data['devices'], key=lambda x: (x['rack'], x['position'] or 0)):
            mgmt_ip = device['primary_ip4'] if device['primary_ip4'] != 'N/A' else device['primary_ip6']
            content += f"| {device['name']} | {device['device_type']} | {device['device_role']} | {device['rack']} | {device['position'] or 'N/A'} | {mgmt_ip} | {device['status']} |\n"
        
        with open(file_path, 'w') as f:
            f.write(content)
    
    def generate_rack_layout(self, location_data, file_path):
        """Generate rack layout documentation."""
        content = f"""# Rack Layout
## {location_data['location']['name']}

**Generated**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

---

## Rack Summary

| Rack | U Height | Device Count | Utilization | Status |
|------|----------|--------------|-------------|--------|
"""
        
        for rack in sorted(location_data['racks'], key=lambda x: x['name']):
            utilization = f"{rack['device_count']}/{rack['u_height']}" if rack['u_height'] else f"{rack['device_count']}/?"
            content += f"| {rack['name']} | {rack['u_height']} | {rack['device_count']} | {utilization} | {rack['status']} |\n"
        
        with open(file_path, 'w') as f:
            f.write(content)
    
    def generate_network_topology(self, location_data, file_path):
        """Generate network topology documentation."""
        content = f"""# Network Topology
## {location_data['location']['name']}

**Generated**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

---

## Cable Connections

| Cable | Type | Status | A-Side | B-Side | Length |
|-------|------|--------|--------|--------|--------|
"""
        
        for cable in location_data['cables']:
            a_side = ', '.join(cable['a_terminations']) if cable['a_terminations'] else 'N/A'
            b_side = ', '.join(cable['b_terminations']) if cable['b_terminations'] else 'N/A'
            length = f"{cable['length']} {cable['length_unit']}" if cable['length'] != 'N/A' else 'N/A'
            content += f"| {cable['label']} | {cable['type']} | {cable['status']} | {a_side} | {b_side} | {length} |\n"
        
        with open(file_path, 'w') as f:
            f.write(content)
    
    def generate_ip_addressing(self, location_data, file_path):
        """Generate IP addressing documentation."""
        content = f"""# IP Addressing
## {location_data['location']['name']}

**Generated**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

---

## IP Address Summary

| IP Address | Interface | Device | Status | Role | DNS Name |
|------------|-----------|---------|--------|------|----------|
"""
        
        for ip in sorted(location_data['ip_addresses'], key=lambda x: x['address']):
            content += f"| {ip['address']} | {ip['assigned_object']} | - | {ip['status']} | {ip['role']} | {ip['dns_name']} |\n"
        
        with open(file_path, 'w') as f:
            f.write(content)
    
    def generate_interface_details(self, location_data, file_path):
        """Generate detailed interface documentation."""
        content = f"""# Interface Details
## {location_data['location']['name']}

**Generated**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

---

## Interface Summary

| Device | Interface | Type | Status | VLAN | IP Addresses |
|--------|-----------|------|--------|------|-------------|
"""
        
        for interface in sorted(location_data['interfaces'], key=lambda x: (x['device'], x['name'])):
            status = 'Up' if interface['enabled'] else 'Down'
            vlan_info = interface['untagged_vlan']
            if interface['tagged_vlans']:
                vlan_info += f" (Tagged: {', '.join(interface['tagged_vlans'])})"
            
            ip_addresses = ', '.join(interface['ip_addresses']) if interface['ip_addresses'] else 'N/A'
            
            content += f"| {interface['device']} | {interface['name']} | {interface['type']} | {status} | {vlan_info} | {ip_addresses} |\n"
        
        with open(file_path, 'w') as f:
            f.write(content)
    
    def create_symlinks(self, docs_structure, location):
        """Create symlinks for latest documentation."""
        timestamp_dir = docs_structure['timestamp_dir']
        latest_dir = docs_structure['latest_dir']
        
        # List of files to symlink
        files_to_link = [
            'main-report.md',
            'device-inventory.md',
            'vlan-configuration.md',
            'rack-layout.md',
            'network-topology.md',
            'ip-addressing.md',
            'interface-details.md',
            'data.json'
        ]
        
        for filename in files_to_link:
            source_file = os.path.join(timestamp_dir, filename)
            symlink_path = os.path.join(latest_dir, filename)
            
            # Remove existing symlink if it exists
            if os.path.islink(symlink_path) or os.path.exists(symlink_path):
                try:
                    os.remove(symlink_path)
                except OSError:
                    pass
            
            # Create new symlink
            if os.path.exists(source_file):
                try:
                    os.symlink(source_file, symlink_path)
                except OSError as e:
                    self.logger.warning(f"Failed to create symlink for {filename}: {e}")
        
        self.logger.info(f"Created symlinks in {latest_dir}")


class GenerateDocsJob(Job):
    """Legacy job for backward compatibility."""
    
    name = "Generate Network Documentation (Legacy)"
    grouping = "Documentation"
    description = "Generate basic network documentation (legacy version)"
    has_sensitive_variables = False

    class Meta:
        name = "Generate Network Documentation (Legacy)"
        description = "Generate basic network documentation (legacy version)"
        has_sensitive_variables = False
        approval_required = False

    def run(self, data=None, commit=None, **kwargs):
        """Legacy documentation generation for all locations."""
        try:
            self.logger.info("🚀 Starting documentation generation...")

            # Import models dynamically
            from django.apps import apps
            Device = apps.get_model("dcim", "Device")
            Location = apps.get_model("dcim", "Location")

            self.logger.info("📊 Extracting data from Nautobot...")

            locations = list(
                Location.objects.all().values("id", "name", "description")
            )
            devices = list(
                Device.objects.all()
                .select_related("location", "device_type", "device_role")
                .values(
                    "id",
                    "name",
                    "location__name",
                    "device_type__model",
                    "device_role__name",
                )
            )

            self.logger.info(
                f"Found {len(locations)} locations and {len(devices)} devices"
            )

            # Markdown generation
            content = f"""# Network Documentation

**Generated**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

## Summary
- **Locations**: {len(locations)}
- **Devices**: {len(devices)}

## Locations
"""

            for location in locations:
                content += f"### {location['name']}\n"
                content += (
                    f"- **Description**: {location.get('description') or 'N/A'}\n\n"
                )

            content += "\n## Devices\n\n"
            content += "| Device | Location | Type | Role |\n"
            content += "|--------|----------|------|------|\n"

            for device in devices[:20]:
                location_name = device.get("location__name", "Unknown")
                device_type = device.get("device_type__model", "Unknown")
                device_role = device.get("device_role__name", "Unknown")
                content += (
                    f"| {device['name']} | {location_name} | {device_type} | {device_role} |\n"
                )

            if len(devices) > 20:
                content += f"\n*... and {len(devices) - 20} more devices*\n"

            content += "\n---\n*Generated automatically from Nautobot data*\n"

            # Output directory setup
            output_dir = os.path.join(
                settings.BASE_DIR,
                "nautobot",
                "engineer_console",
                "static",
                "generated_docs",
            )
            os.makedirs(output_dir, exist_ok=True)

            # Write to timestamped file
            timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")
            filename = f"network-doc-{timestamp}.md"
            output_file = os.path.join(output_dir, filename)

            with open(output_file, "w") as f:
                f.write(content)

            # Create/update symlink: latest.md
            symlink_path = os.path.join(output_dir, "latest.md")
            if os.path.islink(symlink_path) or os.path.exists(symlink_path):
                os.remove(symlink_path)
            os.symlink(output_file, symlink_path)

            self.logger.info("✅ Documentation generated successfully!")

            result_message = f"""
Documentation Generation Completed!

📊 Statistics:
- Locations: {len(locations)}
- Devices: {len(devices)}
- Output File: {output_file}

📄 View Latest Documentation: /static/generated_docs/latest.md
"""
            return result_message

        except Exception as e:
            self.logger.error(f"❌ Documentation generation failed: {str(e)}")
            import traceback
            self.logger.error(f"Full traceback: {traceback.format_exc()}")
            raise