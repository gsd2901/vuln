import yaml
import json
import os
from datetime import datetime
from jinja2 import Environment, FileSystemLoader
from django.conf import settings


class NautobotDocumentationGenerator:
    def __init__(self, config_path):
        with open(config_path, 'r') as f:
            self.config = yaml.safe_load(f)
        
        # Setup Jinja2 environment with Django template directory
        template_dir = os.path.join(settings.BASE_DIR, self.config['templates']['path'])
        self.env = Environment(
            loader=FileSystemLoader(template_dir),
            trim_blocks=True,
            lstrip_blocks=True
        )
        
        # Add custom filters
        self.env.filters['groupby_site'] = self._groupby_site
        self.env.filters['groupby_role'] = self._groupby_role
        self.env.filters['format_ip'] = self._format_ip
        self.env.filters['calculate_utilization'] = self._calculate_utilization
        
        self.output_dir = os.path.join(settings.BASE_DIR, 'engineer_console', self.config['documentation']['output_dir'])
    
    def _groupby_site(self, items):
        """Group items by site"""
        grouped = {}
        for item in items:
            site = item.get('site', 'Unknown')
            if site not in grouped:
                grouped[site] = []
            grouped[site].append(item)
        return grouped
    
    def _groupby_role(self, items):
        """Group items by role"""
        grouped = {}
        for item in items:
            role = item.get('device_role', 'Unknown')
            if role not in grouped:
                grouped[role] = []
            grouped[role].append(item)
        return grouped
    
    def _format_ip(self, ip_address):
        """Format IP address for display"""
        if ip_address and '/' in ip_address:
            return ip_address.split('/')[0]
        return ip_address or 'N/A'
    
    def _calculate_utilization(self, prefix, ip_list):
        """Calculate IP utilization for a prefix"""
        if not prefix or not ip_list:
            return 0
        
        import ipaddress
        try:
            network = ipaddress.ip_network(prefix, strict=False)
            used_ips = len([ip for ip in ip_list if ipaddress.ip_address(ip.split('/')[0]) in network])
            total_ips = network.num_addresses - 2  # Subtract network and broadcast
            return round((used_ips / total_ips) * 100, 2) if total_ips > 0 else 0
        except:
            return 0
    
    def generate_network_topology(self, data):
        """Generate network topology documentation with Mermaid diagrams"""
        template = self.env.get_template('network-topology.j2')
        
        # Generate Mermaid diagram
        mermaid_content = "graph TD\n"
        
        # Add sites and devices
        for site_name, site_data in data['network_topology']['sites'].items():
            site_id = site_name.replace(' ', '_').replace('-', '_')
            mermaid_content += f"    subgraph {site_id}[{site_name}]\n"
            
            for device in site_data['devices']:
                device_id = device['name'].replace(' ', '_').replace('-', '_')
                role = device['role']
                mermaid_content += f"        {device_id}[{device['name']}<br/>{role}]\n"
            
            mermaid_content += "    end\n"
        
        content = template.render(
            topology_data=data['network_topology'],
            mermaid_diagram=mermaid_content,
            sites=data['sites'],
            generation_time=datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            total_sites=len(data['sites']),
            total_devices=len(data['devices'])
        )
        
        return content
    
    def generate_site_overview(self, data):
        """Generate comprehensive site overview"""
        template = self.env.get_template('site-overview.j2')
        
        # Enrich site data with device information
        devices_by_site = self._groupby_site(data['devices'])
        
        enriched_sites = []
        for site in data['sites']:
            site_devices = devices_by_site.get(site['name'], [])
            site['devices'] = site_devices
            site['device_breakdown'] = self._groupby_role(site_devices)
            enriched_sites.append(site)
        
        content = template.render(
            sites=enriched_sites,
            devices_by_site=devices_by_site,
            generation_time=datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            total_sites=len(data['sites']),
            total_devices=len(data['devices'])
        )
        
        return content
    
    def generate_device_inventory(self, data):
        """Generate comprehensive device inventory"""
        template = self.env.get_template('device-inventory.j2')
        
        # Sort devices by site and role
        sorted_devices = sorted(data['devices'], 
                              key=lambda x: (x.get('site', ''), x.get('device_role', ''), x.get('name', '')))
        
        # Generate statistics
        stats = {
            'total_devices': len(data['devices']),
            'total_interfaces': sum(d.get('interface_count', 0) for d in data['devices']),
            'devices_by_role': self._groupby_role(data['devices']),
            'devices_by_site': self._groupby_site(data['devices'])
        }
        
        content = template.render(
            devices=sorted_devices,
            stats=stats,
            generation_time=datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        )
        
        return content
    
    def generate_ip_addressing(self, data):
        """Generate IP addressing documentation"""
        template = self.env.get_template('ip-addressing.j2')
        
        # Process IP data
        ip_data = data['ip_addressing']
        
        # Calculate utilization for each prefix
        for prefix_info in ip_data['prefixes']:
            prefix = prefix_info['prefix']
            relevant_ips = [ip['address'] for ip in ip_data['ip_addresses']]
            prefix_info['utilization'] = self._calculate_utilization(prefix, relevant_ips)
        
        content = template.render(
            ip_data=ip_data,
            vlans=data['vlans'],
            generation_time=datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            total_prefixes=len(ip_data['prefixes']),
            total_ips=len(ip_data['ip_addresses'])
        )
        
        return content
    
    def generate_index(self, data):
        """Generate main index page"""
        # Create a simple index template if it doesn't exist
        index_template = """# Network Documentation

> **Generated**: {{ generation_time }}

## Quick Statistics

- **Sites**: {{ total_sites }}
- **Devices**: {{ total_devices }}
- **IP Prefixes**: {{ total_prefixes }}
- **VLANs**: {{ total_vlans }}

## Documentation Sections

- [Network Topology](network/topology.md)
- [Site Overview](sites/overview.md)
- [Device Inventory](devices/inventory.md)
- [IP Addressing](network/ip-addressing.md)

---
*This documentation is automatically generated from Nautobot data.*
"""
        
        from jinja2 import Template
        template = Template(index_template)
        
        content = template.render(
            generation_time=datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            total_sites=len(data['sites']),
            total_devices=len(data['devices']),
            total_prefixes=len(data['ip_addressing']['prefixes']),
            total_vlans=len(data['vlans'])
        )
        
        return content
    
    def generate_all_documentation(self, data_path):
        """Generate all documentation sections"""
        with open(data_path, 'r') as f:
            data = json.load(f)
        
        # Ensure output directory structure exists
        os.makedirs(self.output_dir, exist_ok=True)
        for subdir in ['sites', 'devices', 'network', 'changes']:
            os.makedirs(os.path.join(self.output_dir, subdir), exist_ok=True)
        
        generators = {
            'network-topology.j2': (self.generate_network_topology, 'network/topology.md'),
            'site-overview.j2': (self.generate_site_overview, 'sites/overview.md'),
            'device-inventory.j2': (self.generate_device_inventory, 'devices/inventory.md'),
            'ip-addressing.j2': (self.generate_ip_addressing, 'network/ip-addressing.md')
        }
        
        # Generate each section
        for section in self.config['documentation']['sections']:
            if section['enabled']:
                template_name = section['template']
                output_file = section['output']
                
                if template_name in generators:
                    generator_func, _ = generators[template_name]
                    print(f"Generating {section['name']}...")
                    
                    try:
                        content = generator_func(data)
                        output_path = os.path.join(self.output_dir, output_file)
                        os.makedirs(os.path.dirname(output_path), exist_ok=True)
                        
                        with open(output_path, 'w') as f:
                            f.write(content)
                        
                        print(f"  ✓ Generated: {output_path}")
                    except Exception as e:
                        print(f"  ✗ Error generating {section['name']}: {str(e)}")
                else:
                    print(f"  ⚠ No generator found for template {template_name}")
        
        # Generate index page
        print("Generating index page...")
        index_content = self.generate_index(data)
        index_path = os.path.join(self.output_dir, 'index.md')
        with open(index_path, 'w') as f:
            f.write(index_content)
        print(f"  ✓ Generated: {index_path}")
        
        print("✅ Documentation generation completed!")
        
        # Return summary for job output
        return {
            'status': 'success',
            'files_generated': len(self.config['documentation']['sections']) + 1,
            'output_directory': self.output_dir,
            'generation_time': datetime.now().isoformat()
        }