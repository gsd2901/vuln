import yaml
import json
from datetime import datetime
from django.apps import apps
from django.contrib.contenttypes.models import ContentType


class NautobotExtractor:
    def __init__(self, config_path):
        with open(config_path, 'r') as f:
            self.config = yaml.safe_load(f)
        
        # Get Nautobot models directly via Django ORM
        self.Device = apps.get_model('dcim', 'Device')
        self.Site = apps.get_model('dcim', 'Site')
        self.Interface = apps.get_model('dcim', 'Interface')
        self.IPAddress = apps.get_model('ipam', 'IPAddress')
        self.VLAN = apps.get_model('ipam', 'VLAN')
        self.Cable = apps.get_model('dcim', 'Cable')
        self.Rack = apps.get_model('dcim', 'Rack')
        self.Prefix = apps.get_model('ipam', 'Prefix')
        
    def extract_sites(self):
        """Extract all sites with enhanced details"""
        sites_data = []
        
        for site in self.Site.objects.all().select_related('region', 'tenant'):
            # Get device counts and statistics
            devices = self.Device.objects.filter(site=site)
            device_count = devices.count()
            rack_count = self.Rack.objects.filter(site=site).count()
            
            # Get device roles breakdown
            device_roles = {}
            for device in devices.select_related('device_role'):
                role = device.device_role.name if device.device_role else 'Unknown'
                device_roles[role] = device_roles.get(role, 0) + 1
            
            site_data = {
                'id': site.id,
                'name': site.name,
                'slug': site.slug,
                'status': site.status.label if site.status else None,
                'region': site.region.name if site.region else None,
                'tenant': site.tenant.name if site.tenant else None,
                'facility': site.facility,
                'asn': site.asn,
                'latitude': float(site.latitude) if site.latitude else None,
                'longitude': float(site.longitude) if site.longitude else None,
                'description': site.description,
                'physical_address': site.physical_address,
                'contact_name': site.contact_name,
                'contact_phone': site.contact_phone,
                'contact_email': site.contact_email,
                'device_count': device_count,
                'rack_count': rack_count,
                'device_roles': device_roles
            }
            sites_data.append(site_data)
            
        return sites_data
    
    def extract_devices(self):
        """Extract all devices with comprehensive details"""
        devices_data = []
        
        devices_queryset = self.Device.objects.all().select_related(
            'device_type', 'device_role', 'site', 'rack', 'tenant', 
            'platform', 'primary_ip4', 'primary_ip6'
        )
        
        for device in devices_queryset:
            # Get interfaces for this device
            interfaces = []
            for interface in device.interfaces.all().select_related('lag', 'untagged_vlan'):
                interface_data = {
                    'name': interface.name,
                    'type': interface.type.label if interface.type else None,
                    'enabled': interface.enabled,
                    'description': interface.description,
                    'mtu': interface.mtu,
                    'mac_address': str(interface.mac_address) if interface.mac_address else None,
                    'lag': interface.lag.name if interface.lag else None,
                    'untagged_vlan': interface.untagged_vlan.vid if interface.untagged_vlan else None,
                    'tagged_vlans': [vlan.vid for vlan in interface.tagged_vlans.all()],
                    'ip_addresses': [str(ip.address) for ip in interface.ip_addresses.all()]
                }
                interfaces.append(interface_data)
            
            device_data = {
                'id': device.id,
                'name': device.name,
                'device_type': device.device_type.model if device.device_type else None,
                'manufacturer': device.device_type.manufacturer.name if device.device_type and device.device_type.manufacturer else None,
                'device_role': device.device_role.name if device.device_role else None,
                'site': device.site.name if device.site else None,
                'site_id': device.site.id if device.site else None,
                'rack': device.rack.name if device.rack else None,
                'position': device.position,
                'face': device.face.label if device.face else None,
                'status': device.status.label if device.status else None,
                'platform': device.platform.name if device.platform else None,
                'primary_ip4': str(device.primary_ip4.address) if device.primary_ip4 else None,
                'primary_ip6': str(device.primary_ip6.address) if device.primary_ip6 else None,
                'tenant': device.tenant.name if device.tenant else None,
                'serial': device.serial,
                'asset_tag': device.asset_tag,
                'comments': device.comments,
                'interfaces': interfaces,
                'interface_count': len(interfaces)
            }
            devices_data.append(device_data)
            
        return devices_data
    
    def extract_ip_addressing(self):
        """Extract IP addressing information"""
        # Get prefixes
        prefixes_data = []
        for prefix in self.Prefix.objects.all().select_related('site', 'tenant', 'vlan', 'role'):
            prefix_data = {
                'prefix': str(prefix.prefix),
                'site': prefix.site.name if prefix.site else None,
                'tenant': prefix.tenant.name if prefix.tenant else None,
                'vlan': prefix.vlan.vid if prefix.vlan else None,
                'role': prefix.role.name if prefix.role else None,
                'status': prefix.status.label if prefix.status else None,
                'description': prefix.description,
                'is_pool': prefix.is_pool
            }
            prefixes_data.append(prefix_data)
        
        # Get IP addresses
        ip_addresses_data = []
        for ip in self.IPAddress.objects.all().select_related('tenant', 'assigned_object'):
            assigned_to = None
            if ip.assigned_object:
                assigned_to = str(ip.assigned_object)
            
            ip_data = {
                'address': str(ip.address),
                'status': ip.status.label if ip.status else None,
                'role': ip.role.name if ip.role else None,
                'tenant': ip.tenant.name if ip.tenant else None,
                'assigned_to': assigned_to,
                'dns_name': ip.dns_name,
                'description': ip.description
            }
            ip_addresses_data.append(ip_data)
        
        return {
            'prefixes': prefixes_data,
            'ip_addresses': ip_addresses_data
        }
    
    def extract_vlans(self):
        """Extract VLAN information"""
        vlans_data = []
        
        for vlan in self.VLAN.objects.all().select_related('site', 'tenant', 'role'):
            vlan_data = {
                'vid': vlan.vid,
                'name': vlan.name,
                'site': vlan.site.name if vlan.site else None,
                'tenant': vlan.tenant.name if vlan.tenant else None,
                'status': vlan.status.label if vlan.status else None,
                'role': vlan.role.name if vlan.role else None,
                'description': vlan.description
            }
            vlans_data.append(vlan_data)
            
        return vlans_data
    
    def extract_network_topology(self):
        """Extract network topology data for diagram generation"""
        topology_data = {
            'sites': {},
            'connections': []
        }
        
        # Group devices by site
        for site in self.Site.objects.all():
            devices = self.Device.objects.filter(site=site)
            topology_data['sites'][site.name] = {
                'devices': [{'name': d.name, 'role': d.device_role.name if d.device_role else 'Unknown'} 
                           for d in devices],
                'device_count': devices.count()
            }
        
        # Get cable connections for topology
        for cable in self.Cable.objects.all():
            if cable.a_terminations and cable.b_terminations:
                connection = {
                    'id': cable.id,
                    'label': cable.label,
                    'type': cable.type.label if cable.type else None,
                    'status': cable.status.label if cable.status else None,
                    'a_side': [str(term) for term in cable.a_terminations],
                    'b_side': [str(term) for term in cable.b_terminations]
                }
                topology_data['connections'].append(connection)
        
        return topology_data
    
    def extract_all_data(self):
        """Extract all network data"""
        print("Extracting data from Nautobot using Django ORM...")
        
        data = {
            'extraction_timestamp': datetime.now().isoformat(),
            'extractor_version': '2.0',
            'sites': self.extract_sites(),
            'devices': self.extract_devices(),
            'ip_addressing': self.extract_ip_addressing(),
            'vlans': self.extract_vlans(),
            'network_topology': self.extract_network_topology()
        }
        
        print(f"Extraction completed:")
        print(f"  - Sites: {len(data['sites'])}")
        print(f"  - Devices: {len(data['devices'])}")
        print(f"  - Prefixes: {len(data['ip_addressing']['prefixes'])}")
        print(f"  - IP Addresses: {len(data['ip_addressing']['ip_addresses'])}")
        print(f"  - VLANs: {len(data['vlans'])}")
        print(f"  - Network Connections: {len(data['network_topology']['connections'])}")
        
        return data
    
    def save_data(self, data, output_file):
        """Save extracted data to file"""
        import os
        os.makedirs(os.path.dirname(output_file), exist_ok=True)
        
        with open(output_file, 'w') as f:
            json.dump(data, f, indent=2, default=str)
        
        print(f"Data saved to: {output_file}")