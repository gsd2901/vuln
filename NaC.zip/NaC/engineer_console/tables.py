from django.db.models import Count
from nautobot.core.tables import BaseTable, ToggleColumn
import django_tables2 as tables  # This was missing
from engineer_console.models import DocumentCategory, TechnicalDocument

class DocumentCategoryTable(BaseTable):
    """Table for listing document categories."""
    
    pk = ToggleColumn()
    name = tables.Column(
        linkify=True
    )
    description = tables.Column()
    document_count = tables.Column(
        accessor=tables.A('documents__count'),
        verbose_name='Documents'
    )
    
    class Meta:
        model = DocumentCategory
        fields = ('pk', 'name', 'description', 'document_count')
        exclude = ('dynamic_groups',)

class TechnicalDocumentTable(BaseTable):
    pk = ToggleColumn()
    title = tables.Column(linkify=True)
    category = tables.Column()
    description = tables.Column()
    created = tables.DateTimeColumn()
    
    file_type = tables.TemplateColumn(
        template_code="""
        {% if record.file.name|slice:"-4:" == '.pdf' %}
            <i class="mdi mdi-file-pdf text-danger"></i> PDF
        {% elif record.file.name|slice:"-4:" == '.doc' or record.file.name|slice:"-5:" == '.docx' %}
            <i class="mdi mdi-file-word text-primary"></i> Word
        {% else %}
            <i class="mdi mdi-file-document"></i> Document
        {% endif %}
        """,
        verbose_name='Type'
    )
    # Action buttons as separate columns
    view = tables.TemplateColumn(
        template_code='<a href="{% url \'plugins:engineer_console:document_viewer\' pk=record.pk %}" class="btn btn-xs btn-primary" target="_blank"><i class="mdi mdi-eye"></i></a>',
        verbose_name='',
        orderable=False
    )
    
    detail = tables.TemplateColumn(
        template_code='<a href="{% url \'plugins:engineer_console:document_detail\' pk=record.pk %}" class="btn btn-xs btn-info"><i class="mdi mdi-information"></i></a>',
        verbose_name='',
        orderable=False
    )
    
    edit = tables.TemplateColumn(
        template_code='<a href="{% url \'plugins:engineer_console:document_edit\' pk=record.pk %}" class="btn btn-xs btn-warning"><i class="mdi mdi-pencil"></i></a>',
        verbose_name='',
        orderable=False
    )
    
    delete = tables.TemplateColumn(
        template_code='<a href="{% url \'plugins:engineer_console:document_delete\' pk=record.pk %}" class="btn btn-xs btn-danger"><i class="mdi mdi-trash-can-outline"></i></a>',
        verbose_name='',
        orderable=False
    )
    
    class Meta:
        model = TechnicalDocument
        fields = ('pk', 'title', 'category', 'description', 'created', 'view', 'detail', 'edit', 'delete')
        exclude = ('dynamic_groups',)  # Explicitly exclude dynamic_groups