"""Views for the Engineer Console plugin."""

from django.shortcuts import get_object_or_404
from django.views.generic import ListView, DetailView,TemplateView
from django.http import FileResponse, Http404
from django.urls import reverse_lazy
from django.contrib.auth.mixins import PermissionRequiredMixin
from .tables import DocumentCategoryTable, TechnicalDocumentTable
from nautobot.core.views import generic

from engineer_console.models import TechnicalDocument, DocumentCategory
from engineer_console.forms import TechnicalDocumentForm, DocumentCategoryForm, TechnicalDocumentCSVForm

from django.db.models import Count

from nautobot.core.views.generic import BulkImportView

class EngineerConsoleView(generic.ObjectListView):
    """Display the list of technical documents available in the Engineer Console."""
    
    queryset = TechnicalDocument.objects.all().select_related('category')
    filterset = None  # Add a filterset if needed
    table = TechnicalDocumentTable  # Add a table if needed
    template_name = 'engineer_console/engineer_console.html'
    
    def get_extra_context(self, request, *args, **kwargs):
        context = super().get_extra_context(request, *args, **kwargs)
        context['categories'] = DocumentCategory.objects.all()
        return context

class DocumentsByCategoryView(generic.ObjectListView):
    """Display documents filtered by category."""
    
    # Define the base queryset attribute (required for Nautobot's permission checks)
    queryset = TechnicalDocument.objects.all().select_related('category')
    filterset = None
    table = TechnicalDocumentTable
    template_name = 'engineer_console/engineer_console.html'
    
    def get(self, request, pk=None, *args, **kwargs):
        """Override get method to store the category ID before processing."""
        self.category_id = pk
        return super().get(request, *args, **kwargs)
    
    def get_queryset(self):
        """Return filtered queryset for the category."""
        queryset = super().get_queryset()
        
        # Filter by category if set
        if hasattr(self, 'category_id') and self.category_id:
            print(f"Filtering by category: {self.category_id}")  # Debug print
            return queryset.filter(category_id=self.category_id)
        
        return queryset
    
    def get_extra_context(self, request, *args, **kwargs):
        """Add category context for the template."""
        context = super().get_extra_context(request, *args, **kwargs)
        
        # Add all categories for the sidebar
        context['categories'] = DocumentCategory.objects.all()
        
        # Get and add the current category
        if hasattr(self, 'category_id') and self.category_id:
            context['current_category'] = get_object_or_404(DocumentCategory, id=self.category_id)
        
        return context

class DocumentDetailView(generic.ObjectView):
    """Display detailed information about a document."""
    
    queryset = TechnicalDocument.objects.all()
    template_name = 'engineer_console/document_detail.html'

class DocumentViewerView(generic.View):  # Using Nautobot's generic View base
    """Serve the actual PDF / Docs document."""
    
    queryset = TechnicalDocument.objects.all()
    
    def get(self, request, *args, **kwargs):
        document = get_object_or_404(self.queryset, pk=kwargs['pk'])
        try:
            file_ext = document.file.name.split('.')[-1].lower()
            
            # Set the appropriate content type based on file extension
            content_types = {
                'pdf': 'application/pdf',
                'doc': 'application/msword',
                'docx': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
            }
            
            content_type = content_types.get(file_ext, 'application/octet-stream')
            
            # For PDFs, we can display them directly in the browser
            if file_ext == 'pdf':
                response = FileResponse(document.file.open('rb'), content_type=content_type)
                return response
            
            # For Word documents, we'll force a download
            else:
                response = FileResponse(document.file.open('rb'), content_type=content_type)
                response['Content-Disposition'] = f'attachment; filename="{document.filename()}"'
                return response
                
        except Exception as e:
            raise Http404(f"Document file not found: {e}")

# New Document Management Views

class DocumentCreateView(PermissionRequiredMixin, generic.ObjectEditView):
    """View for creating a new document."""
    
    permission_required = 'engineer_console.add_technicaldocument'
    model = TechnicalDocument
    queryset = TechnicalDocument.objects.all()
    model_form = TechnicalDocumentForm
    template_name = 'engineer_console/document_form.html'
    default_return_url = 'plugins:engineer_console:engineer_console'

class DocumentUpdateView(PermissionRequiredMixin, generic.ObjectEditView):
    """View for updating an existing document."""
    
    permission_required = 'engineer_console.change_technicaldocument'
    model = TechnicalDocument
    queryset = TechnicalDocument.objects.all()
    model_form = TechnicalDocumentForm
    template_name = 'engineer_console/document_form.html'
    default_return_url = 'plugins:engineer_console:engineer_console'

class DocumentDeleteView(PermissionRequiredMixin, generic.ObjectDeleteView):
    """View for deleting a document."""
    
    permission_required = 'engineer_console.delete_technicaldocument'
    model = TechnicalDocument
    queryset = TechnicalDocument.objects.all()
    default_return_url = 'plugins:engineer_console:engineer_console'

# New Category Management Views
class CategoryListView(PermissionRequiredMixin, generic.ObjectListView):
    permission_required = 'engineer_console.view_documentcategory'
    model = DocumentCategory
    queryset = DocumentCategory.objects.all()
    table = DocumentCategoryTable
    template_name = 'engineer_console/category_list.html'

class CategoryCreateView(PermissionRequiredMixin, generic.ObjectEditView):
    """View for creating a new category."""
    
    permission_required = 'engineer_console.add_documentcategory'
    model = DocumentCategory
    queryset = DocumentCategory.objects.all()
    model_form = DocumentCategoryForm
    template_name = 'engineer_console/category_form.html'
    default_return_url = 'plugins:engineer_console:category_list'

class CategoryUpdateView(PermissionRequiredMixin, generic.ObjectEditView):
    """View for updating an existing category."""
    
    permission_required = 'engineer_console.change_documentcategory'
    model = DocumentCategory
    queryset = DocumentCategory.objects.all()
    model_form = DocumentCategoryForm
    template_name = 'engineer_console/category_form.html'
    default_return_url = 'plugins:engineer_console:category_list'

class CategoryDeleteView(PermissionRequiredMixin, generic.ObjectDeleteView):
    """View for deleting a category."""
    
    permission_required = 'engineer_console.delete_documentcategory'
    model = DocumentCategory
    queryset = DocumentCategory.objects.all()
    default_return_url = 'plugins:engineer_console:category_list'

# Debug view for URLs
def debug_urls(request):
    """View to display all registered URL patterns for debugging."""
    from django.http import HttpResponse
    from django.urls import get_resolver
    
    resolver = get_resolver()
    url_patterns = []
    
    def _get_patterns(patterns, namespace=None, prefix=''):
        for pattern in patterns:
            if hasattr(pattern, 'pattern'):
                if hasattr(pattern, 'name'):
                    url_name = f"{namespace}:{pattern.name}" if namespace else pattern.name
                    if url_name:
                        url_patterns.append(f"URL Name: {url_name}, Pattern: {prefix + str(pattern.pattern)}")
                if hasattr(pattern, 'url_patterns'):
                    _get_patterns(
                        pattern.url_patterns,
                        namespace=pattern.namespace if hasattr(pattern, 'namespace') else namespace,
                        prefix=prefix + str(pattern.pattern)
                    )
    
    _get_patterns(resolver.url_patterns)
    
    # Filter for admin URLs related to your app
    admin_urls = [u for u in url_patterns if 'admin' in u and 'engineer_console' in u]
    plugin_urls = [u for u in url_patterns if 'plugins:engineer_console' in u]
    
    output = "<h2>Admin URLs:</h2>"
    output += "<pre>" + "\n".join(sorted(admin_urls)) + "</pre>"
    output += "<h2>Plugin URLs:</h2>"
    output += "<pre>" + "\n".join(sorted(plugin_urls)) + "</pre>"
    
    return HttpResponse(output)

class DocumentImportView(PermissionRequiredMixin, BulkImportView):
    """View for importing documents in bulk via CSV."""
    
    permission_required = 'engineer_console.add_technicaldocument'
    model_form = TechnicalDocumentCSVForm
    table = TechnicalDocumentTable
    default_return_url = 'plugins:engineer_console:engineer_console'

class UsefulLinksView(TemplateView):
    """Display the list of useful links available in the Engineer Console."""

    template_name = 'engineer_console/useful_links.html'
    

# """Enhanced views for Engineer Console documentation."""

# from django.shortcuts import render, get_object_or_404, redirect
# from django.http import HttpResponse, Http404, JsonResponse
# from django.contrib.auth.decorators import login_required
# from django.conf import settings
# from django.apps import apps
# import os
# import json
# import markdown


# @login_required
# def docs_dashboard(request):
#     """Main documentation dashboard showing all generated docs."""
#     docs_dir = os.path.join(settings.BASE_DIR, 'nautobot', 'engineer_console', 'static', 'generated_docs')
#     latest_dir = os.path.join(docs_dir, 'latest')

#     location_docs = []

#     if os.path.exists(latest_dir):
#         for location_folder in os.listdir(latest_dir):
#             location_path = os.path.join(latest_dir, location_folder)
#             if not os.path.isdir(location_path):
#                 continue

#             data_file = os.path.join(location_path, 'data.json')
#             doc_info = {
#                 'slug': location_folder,
#                 'name': location_folder,
#                 'description': 'No description',
#                 'device_count': 0,
#                 'rack_count': 0,
#                 'vlan_count': 0,
#                 'docs_files': []
#             }

#             if os.path.exists(data_file):
#                 try:
#                     with open(data_file, 'r') as f:
#                         data = json.load(f)
#                         doc_info.update({
#                             'name': data.get('location', {}).get('name', location_folder),
#                             'description': data.get('location', {}).get('description', 'No description'),
#                             'device_count': data.get('statistics', {}).get('total_devices', 0),
#                             'rack_count': data.get('statistics', {}).get('total_racks', 0),
#                             'vlan_count': data.get('statistics', {}).get('total_vlans', 0)
#                         })
#                 except Exception as e:
#                     print(f"⚠️ Error parsing data.json for {location_folder}: {e}")

#             # Find .md files
#             doc_info['docs_files'] = sorted([
#                 file for file in os.listdir(location_path) if file.endswith('.md')
#             ])

#             location_docs.append(doc_info)

#     # Get list of all locations from DCIM for dropdown
#     Location = apps.get_model("dcim", "Location")
#     all_locations = Location.objects.all().order_by("name")

#     context = {
#         'location_docs': location_docs,
#         'all_locations': all_locations,
#         'docs_exist': len(location_docs) > 0
#     }

#     return render(request, 'engineer_console/docs_dashboard.html', context)


# @login_required
# def docs_location(request, location_slug):
#     """Show available documentation files for a location."""
#     docs_dir = os.path.join(settings.BASE_DIR, 'nautobot', 'engineer_console', 'static', 'generated_docs')
#     location_path = os.path.join(docs_dir, 'latest', location_slug)

#     if not os.path.exists(location_path):
#         raise Http404("Documentation for this location not found")

#     # Get data file info
#     data_file = os.path.join(location_path, 'data.json')
#     location_info = {'name': location_slug, 'description': 'No description'}
    
#     if os.path.exists(data_file):
#         try:
#             with open(data_file, 'r') as f:
#                 data = json.load(f)
#                 location_info = data.get('location', location_info)
#         except:
#             pass

#     # Find .md files
#     docs_files = sorted([
#         file for file in os.listdir(location_path) if file.endswith('.md')
#     ])

#     context = {
#         'location_slug': location_slug,
#         'location_info': location_info,
#         'docs_files': docs_files
#     }

#     return render(request, 'engineer_console/docs_location.html', context)


# @login_required
# def docs_preview(request, location_slug, filename):
#     """Preview a specific markdown documentation file for a given location."""
#     docs_dir = os.path.join(settings.BASE_DIR, 'nautobot', 'engineer_console', 'static', 'generated_docs')
#     file_path = os.path.join(docs_dir, 'latest', location_slug, filename)

#     print(f"DEBUG: Looking for file at: {file_path}")  # Debug line
#     print(f"DEBUG: File exists: {os.path.exists(file_path)}")  # Debug line
    
#     if not os.path.exists(file_path):
#         # Try to find the file in case it's a symlink issue
#         alt_path = os.path.realpath(file_path)
#         print(f"DEBUG: Real path: {alt_path}")  # Debug line
#         print(f"DEBUG: Real path exists: {os.path.exists(alt_path)}")  # Debug line
        
#         if not os.path.exists(alt_path):
#             raise Http404(f"Documentation file not found: {filename}")
#         file_path = alt_path

#     try:
#         with open(file_path, 'r', encoding='utf-8') as f:
#             markdown_content = f.read()
        
#         print(f"DEBUG: File content length: {len(markdown_content)}")  # Debug line
        
#         if not markdown_content.strip():
#             return HttpResponse(f"Warning: File {filename} appears to be empty", status=200)
            
#         html_content = markdown.markdown(markdown_content, extensions=['tables', 'fenced_code'])
        
#     except Exception as e:
#         print(f"DEBUG: Error reading file: {e}")  # Debug line
#         return HttpResponse(f"Error reading file: {e}", status=500)

#     # Get location info for context
#     data_file = os.path.join(docs_dir, 'latest', location_slug, 'data.json')
#     location_name = location_slug
    
#     if os.path.exists(data_file):
#         try:
#             with open(data_file, 'r') as f:
#                 data = json.load(f)
#                 location_name = data.get('location', {}).get('name', location_slug)
#         except:
#             pass

#     context = {
#         'location_slug': location_slug,
#         'location_name': location_name,
#         'filename': filename,
#         'html_content': html_content
#     }

#     return render(request, 'engineer_console/docs_preview.html', context)


# @login_required
# def docs_api_data(request, location_slug):
#     """API endpoint to get raw JSON data for a location."""
#     docs_dir = os.path.join(settings.BASE_DIR, 'nautobot', 'engineer_console', 'static', 'generated_docs')
#     data_file = os.path.join(docs_dir, 'latest', location_slug, 'data.json')
    
#     if not os.path.exists(data_file):
#         return JsonResponse({'error': 'Data file not found'}, status=404)
    
#     try:
#         with open(data_file, 'r') as f:
#             data = json.load(f)
#         return JsonResponse(data)
#     except json.JSONDecodeError:
#         return JsonResponse({'error': 'Invalid JSON data'}, status=500)


# @login_required
# def docs_download(request, location_slug, filename):
#     """Download a documentation file."""
#     docs_dir = os.path.join(settings.BASE_DIR, 'nautobot', 'engineer_console', 'static', 'generated_docs')
#     file_path = os.path.join(docs_dir, 'latest', location_slug, filename)
    
#     if not os.path.exists(file_path):
#         raise Http404("File not found")
    
#     with open(file_path, 'rb') as f:
#         response = HttpResponse(f.read(), content_type='application/octet-stream')
#         response['Content-Disposition'] = f'attachment; filename="{filename}"'
#         return response
# Conditional PDF Generation Solution
# This approach tries WeasyPrint first, falls back to ReportLab if WeasyPrint fails
# Add this to your views.py file

"""Enhanced views for Engineer Console documentation with SAFE PDF support."""

from django.shortcuts import render, get_object_or_404, redirect
from django.http import HttpResponse, Http404, JsonResponse
from django.contrib.auth.decorators import login_required
from django.views.decorators.http import require_safe
from django.conf import settings
from django.apps import apps
from django.urls import reverse
import os
import json
import markdown
import io
from datetime import datetime
from bs4 import BeautifulSoup

# DO NOT import WeasyPrint or ReportLab at module level!
# Import them inside functions to prevent server crashes


def get_location_docs_job_url():
    """Get the direct URL for the Generate Location Documentation job."""
    try:
        # Get the Job model
        Job = apps.get_model("extras", "Job")
        
        # Find the GenerateLocationDocsJob
        job = Job.objects.filter(
            name="Generate Location Documentation"
        ).first()
        
        if job:
            # Return the direct job execution URL
            return reverse('extras:job_run', kwargs={'pk': job.pk})
        
        # Fallback to job list if specific job not found
        return reverse('extras:job_list')
        
    except Exception:
        # Fallback to job list if there's any error
        return reverse('extras:job_list')


def get_overview_job_url():
    """Get the direct URL for the Generate Network Overview job."""
    try:
        # Get the Job model
        Job = apps.get_model("extras", "Job")
        
        # Find the GenerateNetworkOverviewJob
        job = Job.objects.filter(
            name="Generate Network Overview (Single File)"
        ).first()
        
        if job:
            # Return the direct job execution URL
            return reverse('extras:job_run', kwargs={'pk': job.pk})
        
        # Fallback to job list if specific job not found
        return reverse('extras:job_list')
        
    except Exception:
        # Fallback to job list if there's any error
        return reverse('extras:job_list')


@login_required
def docs_dashboard(request):
    """Main documentation dashboard showing all generated docs with support for both formats."""
    docs_dir = os.path.join(settings.BASE_DIR, 'nautobot', 'engineer_console', 'static', 'generated_docs')
    latest_dir = os.path.join(docs_dir, 'latest')

    location_docs = []
    total_devices = 0
    total_racks = 0
    total_vlans = 0

    if os.path.exists(latest_dir):
        for location_folder in os.listdir(latest_dir):
            location_path = os.path.join(latest_dir, location_folder)
            if not os.path.isdir(location_path):
                continue

            data_file = os.path.join(location_path, 'data.json')
            doc_info = {
                'slug': location_folder,
                'name': location_folder,
                'description': 'No description',
                'device_count': 0,
                'rack_count': 0,
                'vlan_count': 0,
                'docs_files': [],
                'has_overview': False,
                'has_detailed': False,
                'doc_type': 'unknown'
            }

            if os.path.exists(data_file):
                try:
                    with open(data_file, 'r') as f:
                        data = json.load(f)
                        doc_info.update({
                            'name': data.get('location', {}).get('name', location_folder),
                            'description': data.get('location', {}).get('description', 'No description'),
                            'device_count': data.get('statistics', {}).get('total_devices', 0),
                            'rack_count': data.get('statistics', {}).get('total_racks', 0),
                            'vlan_count': data.get('statistics', {}).get('total_vlans', 0)
                        })
                        
                        # Add to totals
                        total_devices += doc_info['device_count']
                        total_racks += doc_info['rack_count']
                        total_vlans += doc_info['vlan_count']
                except Exception as e:
                    print(f"⚠️ Error parsing data.json for {location_folder}: {e}")

            # Find .md files and determine documentation type
            try:
                all_files = os.listdir(location_path)
                md_files = [file for file in all_files if file.endswith('.md')]
                doc_info['docs_files'] = sorted(md_files)
                
                # Determine documentation type
                if 'network-overview.md' in md_files:
                    doc_info['has_overview'] = True
                    doc_info['doc_type'] = 'overview'
                
                if any(file in md_files for file in ['main-report.md', 'device-inventory.md', 'vlan-configuration.md']):
                    doc_info['has_detailed'] = True
                    if doc_info['doc_type'] == 'overview':
                        doc_info['doc_type'] = 'both'
                    else:
                        doc_info['doc_type'] = 'detailed'
                
            except Exception as e:
                print(f"⚠️ Error reading files for {location_folder}: {e}")
                doc_info['docs_files'] = []

            location_docs.append(doc_info)

    # Sort by name
    location_docs.sort(key=lambda x: x['name'])

    # Get list of all locations from DCIM for dropdown
    try:
        Location = apps.get_model("dcim", "Location")
        all_locations = Location.objects.all().order_by("name")
    except:
        all_locations = []

    # Get job URLs
    detailed_job_url = get_location_docs_job_url()
    overview_job_url = get_overview_job_url()

    context = {
        'location_docs': location_docs,
        'all_locations': all_locations,
        'docs_exist': len(location_docs) > 0,
        'total_devices': total_devices,
        'total_racks': total_racks,
        'total_vlans': total_vlans,
        'documented_locations': len(location_docs),
        'available_locations': len(all_locations) if all_locations else 0,
        'detailed_job_url': detailed_job_url,
        'overview_job_url': overview_job_url,
    }

    return render(request, 'engineer_console/docs_dashboard.html', context)


@login_required
def docs_location(request, location_slug):
    """Show available documentation files for a location."""
    docs_dir = os.path.join(settings.BASE_DIR, 'nautobot', 'engineer_console', 'static', 'generated_docs')
    location_path = os.path.join(docs_dir, 'latest', location_slug)

    if not os.path.exists(location_path):
        raise Http404("Documentation for this location not found")

    # Get data file info
    data_file = os.path.join(location_path, 'data.json')
    location_info = {'name': location_slug, 'description': 'No description'}
    
    if os.path.exists(data_file):
        try:
            with open(data_file, 'r') as f:
                data = json.load(f)
                location_info = data.get('location', location_info)
        except:
            pass

    # Find .md files and categorize them
    all_files = os.listdir(location_path)
    md_files = [file for file in all_files if file.endswith('.md')]
    
    # Categorize files
    overview_files = [f for f in md_files if 'overview' in f.lower()]
    detailed_files = [f for f in md_files if f not in overview_files]
    
    # Determine documentation type
    has_overview = len(overview_files) > 0
    has_detailed = len(detailed_files) > 0
    
    context = {
        'location_slug': location_slug,
        'location_info': location_info,
        'overview_files': sorted(overview_files),
        'detailed_files': sorted(detailed_files),
        'has_overview': has_overview,
        'has_detailed': has_detailed,
        'all_files': sorted(md_files)
    }

    return render(request, 'engineer_console/docs_location.html', context)


@login_required
def docs_preview(request, location_slug, filename):
    """Preview a specific markdown documentation file for a given location."""
    docs_dir = os.path.join(settings.BASE_DIR, 'nautobot', 'engineer_console', 'static', 'generated_docs')
    file_path = os.path.join(docs_dir, 'latest', location_slug, filename)

    print(f"DEBUG: Looking for file at: {file_path}")  # Debug line
    print(f"DEBUG: File exists: {os.path.exists(file_path)}")  # Debug line
    
    if not os.path.exists(file_path):
        # Try to find the file in case it's a symlink issue
        alt_path = os.path.realpath(file_path)
        print(f"DEBUG: Real path: {alt_path}")  # Debug line
        print(f"DEBUG: Real path exists: {os.path.exists(alt_path)}")  # Debug line
        
        if not os.path.exists(alt_path):
            raise Http404(f"Documentation file not found: {filename}")
        file_path = alt_path

    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            markdown_content = f.read()
        
        print(f"DEBUG: File content length: {len(markdown_content)}")  # Debug line
        
        if not markdown_content.strip():
            return HttpResponse(f"Warning: File {filename} appears to be empty", status=200)
        
        # Enhanced markdown rendering with support for Mermaid
        html_content = markdown.markdown(
            markdown_content, 
            extensions=['tables', 'fenced_code', 'toc', 'attr_list']
        )
        
    except Exception as e:
        print(f"DEBUG: Error reading file: {e}")  # Debug line
        return HttpResponse(f"Error reading file: {e}", status=500)

    # Get location info for context
    data_file = os.path.join(docs_dir, 'latest', location_slug, 'data.json')
    location_name = location_slug
    
    if os.path.exists(data_file):
        try:
            with open(data_file, 'r') as f:
                data = json.load(f)
                location_name = data.get('location', {}).get('name', location_slug)
        except:
            pass

    # Determine if this is an overview file
    is_overview = 'overview' in filename.lower()

    context = {
        'location_slug': location_slug,
        'location_name': location_name,
        'filename': filename,
        'html_content': html_content,
        'is_overview': is_overview
    }

    return render(request, 'engineer_console/docs_preview.html', context)


@login_required
def docs_api_data(request, location_slug):
    """API endpoint to get raw JSON data for a location."""
    docs_dir = os.path.join(settings.BASE_DIR, 'nautobot', 'engineer_console', 'static', 'generated_docs')
    data_file = os.path.join(docs_dir, 'latest', location_slug, 'data.json')
    
    if not os.path.exists(data_file):
        return JsonResponse({'error': 'Data file not found'}, status=404)
    
    try:
        with open(data_file, 'r') as f:
            data = json.load(f)
        return JsonResponse(data)
    except json.JSONDecodeError:
        return JsonResponse({'error': 'Invalid JSON data'}, status=500)


@login_required
def docs_download(request, location_slug, filename):
    """Download a documentation file."""
    docs_dir = os.path.join(settings.BASE_DIR, 'nautobot', 'engineer_console', 'static', 'generated_docs')
    file_path = os.path.join(docs_dir, 'latest', location_slug, filename)
    
    if not os.path.exists(file_path):
        raise Http404("File not found")
    
    with open(file_path, 'rb') as f:
        response = HttpResponse(f.read(), content_type='application/octet-stream')
        response['Content-Disposition'] = f'attachment; filename="{filename}"'
        return response

@login_required
@require_safe
def download_location_pdf(request, location_slug, filename):
    """Generate and download comprehensive PDF with SAFE imports."""
    
    # Safe import checking - imports are done INSIDE the function
    weasyprint_available = False
    reportlab_available = False
    
    # Try WeasyPrint with broader exception handling
    try:
        from weasyprint import HTML, CSS
        from weasyprint.text.fonts import FontConfiguration
        weasyprint_available = True
        print("✅ WeasyPrint available for PDF generation")
    except (ImportError, OSError, Exception) as e:
        print(f"⚠️ WeasyPrint not available: {e}")
        weasyprint_available = False
    
    # Try ReportLab
    try:
        from reportlab.lib import colors
        from reportlab.lib.pagesizes import A4
        from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
        from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
        from reportlab.lib.units import inch
        from reportlab.graphics.shapes import Drawing, Rect, String
        reportlab_available = True
        print("✅ ReportLab available for PDF generation")
    except (ImportError, Exception) as e:
        print(f"⚠️ ReportLab not available: {e}")
        reportlab_available = False
    
    # Check if we have any PDF generation capability
    if not weasyprint_available and not reportlab_available:
        return HttpResponse(
            "PDF generation not available. System dependencies missing.\n\n"
            "To install WeasyPrint dependencies on Ubuntu/Debian:\n"
            "sudo apt-get update\n"
            "sudo apt-get install -y libpango-1.0-0 libharfbuzz0b libpangoft2-1.0-0 libfontconfig1 libcairo2 libgdk-pixbuf2.0-0 libglib2.0-0 libgtk-3-0\n"
            "pip install weasyprint\n\n"
            "Or install ReportLab (simpler, no system deps):\n"
            "pip install reportlab\n\n"
            "Try downloading the markdown file instead.",
            content_type="text/plain",
            status=500
        )
    
    try:
        from django.apps import apps
        Location = apps.get_model("dcim", "Location")
        
        # Get location
        try:
            location = Location.objects.get(id=location_slug)
        except (Location.DoesNotExist, ValueError):
            raise Http404("Location not found")
        
        # Find the markdown file
        latest_dir = os.path.join(
            settings.BASE_DIR,
            "nautobot",
            "engineer_console", 
            "static",
            "generated_docs",
            "latest",
            str(location.id)
        )
        
        file_path = os.path.join(latest_dir, filename)
        
        if not os.path.exists(file_path):
            raise Http404("Documentation file not found")
        
        # Read the markdown content
        with open(file_path, 'r', encoding='utf-8') as f:
            markdown_content = f.read()
        
        # Load JSON data for enhanced processing
        data_file = os.path.join(latest_dir, 'data.json')
        location_data = {}
        if os.path.exists(data_file):
            with open(data_file, 'r') as f:
                location_data = json.load(f)
        
        # Choose PDF generation method based on availability
        # Prefer ReportLab since it's more reliable
        if reportlab_available:
            try:
                pdf_buffer = generate_network_pdf_reportlab(markdown_content, location_data, location)
                generator_used = "ReportLab"
            except Exception as e:
                print(f"ReportLab failed: {e}")
                if weasyprint_available:
                    try:
                        pdf_buffer = generate_network_pdf_weasyprint(markdown_content, location_data, location)
                        generator_used = "WeasyPrint (ReportLab fallback)"
                    except Exception as e2:
                        raise Exception(f"Both PDF generators failed. ReportLab: {e}, WeasyPrint: {e2}")
                else:
                    raise e
        elif weasyprint_available:
            try:
                pdf_buffer = generate_network_pdf_weasyprint(markdown_content, location_data, location)
                generator_used = "WeasyPrint"
            except Exception as e:
                raise Exception(f"WeasyPrint failed and ReportLab not available: {e}")
        else:
            raise Exception("No PDF generation library available")
        
        # Create response
        response = HttpResponse(pdf_buffer.getvalue(), content_type='application/pdf')
        pdf_filename = f"network-overview-{location.name.replace(' ', '-')}-{datetime.now().strftime('%Y%m%d')}.pdf"
        response['Content-Disposition'] = f'attachment; filename="{pdf_filename}"'
        response['X-PDF-Generator'] = generator_used
        
        print(f"✅ PDF generated successfully using {generator_used}")
        
        return response
        
    except Exception as e:
        # Return detailed error for debugging
        import logging
        import traceback
        logger = logging.getLogger(__name__)
        logger.error(f"PDF generation failed: {str(e)}")
        logger.error(f"Traceback: {traceback.format_exc()}")
        
        return HttpResponse(
            f"PDF generation failed: {str(e)}\n\n"
            f"Available generators:\n"
            f"• WeasyPrint: {weasyprint_available}\n"
            f"• ReportLab: {reportlab_available}\n\n"
            f"For WeasyPrint on Ubuntu/Debian, install system dependencies:\n"
            f"sudo apt-get install -y libpango-1.0-0 libharfbuzz0b libpangoft2-1.0-0\n\n"
            f"For simpler setup, install ReportLab:\n"
            f"pip install reportlab",
            content_type="text/plain",
            status=500
        )


def generate_network_pdf_weasyprint(markdown_content, location_data, location):
    """Generate PDF using WeasyPrint (imported safely inside function)."""
    from weasyprint import HTML, CSS
    from weasyprint.text.fonts import FontConfiguration
    
    # Convert markdown to HTML
    md = markdown.Markdown(extensions=['tables', 'fenced_code', 'toc'])
    html_content = md.convert(markdown_content)
    
    # Process and enhance the HTML for PDF
    html_content = process_html_for_pdf_weasyprint(html_content, location_data)
    
    # Create complete HTML document
    full_html = create_pdf_html_template_weasyprint(html_content, location)
    
    # Generate PDF
    font_config = FontConfiguration()
    css = get_pdf_css_weasyprint()
    
    html_doc = HTML(string=full_html)
    pdf_buffer = io.BytesIO()
    
    html_doc.write_pdf(
        pdf_buffer,
        stylesheets=[CSS(string=css, font_config=font_config)],
        font_config=font_config
    )
    
    pdf_buffer.seek(0)
    return pdf_buffer


def generate_network_pdf_reportlab(markdown_content, location_data, location):
    """Generate PDF using ReportLab (imported safely inside function)."""
    from reportlab.lib import colors
    from reportlab.lib.pagesizes import A4
    from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.lib.units import inch
    from reportlab.graphics.shapes import Drawing, Rect, String
    
    # Create PDF buffer
    buffer = io.BytesIO()
    
    # Create document
    doc = SimpleDocTemplate(
        buffer,
        pagesize=A4,
        rightMargin=72,
        leftMargin=72,
        topMargin=72,
        bottomMargin=18
    )
    
    # Get styles
    styles = getSampleStyleSheet()
    
    # Custom styles
    title_style = ParagraphStyle(
        'CustomTitle',
        parent=styles['Heading1'],
        fontSize=18,
        spaceAfter=30,
        textColor=colors.HexColor('#2c3e50'),
        alignment=1  # Center
    )
    
    heading_style = ParagraphStyle(
        'CustomHeading',
        parent=styles['Heading2'],
        fontSize=14,
        spaceAfter=12,
        textColor=colors.HexColor('#34495e')
    )
    
    body_style = ParagraphStyle(
        'CustomBody',
        parent=styles['Normal'],
        fontSize=10,
        spaceAfter=12
    )
    
    # Build PDF content
    story = []
    
    # Title page
    story.append(Paragraph(f"Network Overview Report", title_style))
    story.append(Paragraph(f"{location.name}", heading_style))
    story.append(Paragraph(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}", body_style))
    story.append(Paragraph("(Generated using ReportLab PDF engine)", body_style))
    story.append(Spacer(1, 20))
    
    # Executive Summary
    if location_data:
        story.extend(create_executive_summary_reportlab(location_data, styles))
    
    # Network Topology
    story.extend(create_network_topology_section_reportlab(location_data, styles))
    
    # Device Inventory
    story.extend(create_device_inventory_section_reportlab(location_data, styles))
    
    # VLAN Configuration
    story.extend(create_vlan_section_reportlab(location_data, styles))
    
    # Network Health
    story.extend(create_network_health_section_reportlab(location_data, styles))
    
    # Build PDF
    doc.build(story)
    buffer.seek(0)
    return buffer


# WeasyPrint helper functions
def process_html_for_pdf_weasyprint(html_content, location_data):
    """Process HTML content for WeasyPrint."""
    soup = BeautifulSoup(html_content, 'html.parser')
    
    # Replace Draw.io container with enhanced HTML topology
    drawio_containers = soup.find_all('div', class_='drawio-container')
    for container in drawio_containers:
        enhanced_topology = create_enhanced_pdf_topology_weasyprint(location_data)
        topology_soup = BeautifulSoup(enhanced_topology, 'html.parser')
        container.replace_with(topology_soup)
    
    # Enhance tables
    tables = soup.find_all('table')
    for table in tables:
        table['class'] = 'pdf-table'
    
    # Process emoji and icons
    html_str = str(soup)
    html_str = enhance_icons_for_pdf(html_str)
    
    return html_str


def create_enhanced_pdf_topology_weasyprint(location_data):
    """Create enhanced topology visualization for WeasyPrint."""
    if not location_data or 'devices' not in location_data:
        return '<div class="no-topology">No topology data available</div>'
    
    devices = location_data.get('devices', {}).get('devices', [])
    connections = location_data.get('connections', [])
    
    # Group devices by role
    routers = [d for d in devices if 'router' in d.get('device_role', '').lower()]
    switches = [d for d in devices if 'switch' in d.get('device_role', '').lower()]
    others = [d for d in devices if d not in routers and d not in switches]
    
    topology_html = f'''
    <div class="pdf-topology-container">
        <h3>Network Topology Diagram</h3>
        <div class="topology-stats">
            <span class="stat">Routers: {len(routers)}</span>
            <span class="stat">Switches: {len(switches)}</span>
            <span class="stat">Others: {len(others)}</span>
            <span class="stat">Connections: {len(connections)}</span>
        </div>
        <div class="topology-layers">
    '''
    
    # Add device layers
    if routers:
        topology_html += '''
            <div class="topology-layer">
                <h4>Core Layer (Routers)</h4>
                <div class="device-grid">
        '''
        for router in routers:
            name = router.get('name', '')[:20]
            ip = router.get('primary_ip4') or router.get('primary_ip6') or 'No IP'
            topology_html += f'''
                <div class="device-box router-device">
                    <strong>{name}</strong><br>
                    <small>{ip}</small>
                </div>
            '''
        topology_html += '''
                </div>
            </div>
        '''
    
    if switches:
        topology_html += '''
            <div class="topology-layer">
                <h4>Distribution Layer (Switches)</h4>
                <div class="device-grid">
        '''
        for switch in switches:
            name = switch.get('name', '')[:20]
            ip = switch.get('primary_ip4') or switch.get('primary_ip6') or 'No IP'
            topology_html += f'''
                <div class="device-box switch-device">
                    <strong>{name}</strong><br>
                    <small>{ip}</small>
                </div>
            '''
        topology_html += '''
                </div>
            </div>
        '''
    
    topology_html += '''
        </div>
    </div>
    '''
    
    return topology_html


def enhance_icons_for_pdf(html_str):
    """Replace emoji with text for better PDF compatibility."""
    replacements = {
        '🌐': '[Router]',
        '🔀': '[Switch]',
        '📟': '[Device]',
        '🟢': '[Active]',
        '🔴': '[Inactive]',
        '📊': '[Stats]',
        '📈': '[Health]',
        '🏗️': '[Rack]',
        '📡': '[IP]',
        '🔗': '[Connection]',
        '⚠️': '[Warning]',
        '✅': '[OK]',
        '💡': '[Note]',
    }
    
    for emoji, replacement in replacements.items():
        html_str = html_str.replace(emoji, replacement)
    
    return html_str


def create_pdf_html_template_weasyprint(content, location):
    """Create HTML template for WeasyPrint."""
    return f'''
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>Network Overview - {location.name}</title>
    </head>
    <body>
        <div class="pdf-container">
            <div class="pdf-header">
                <h1>Network Overview Report</h1>
                <h2>{location.name}</h2>
                <p>Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}</p>
            </div>
            <div class="pdf-content">{content}</div>
        </div>
    </body>
    </html>
    '''


def get_pdf_css_weasyprint():
    """Get CSS for WeasyPrint."""
    return '''
    @page {
        size: A4;
        margin: 2cm 1.5cm;
    }
    body {
        font-family: Arial, sans-serif;
        font-size: 10px;
        line-height: 1.4;
        color: #333;
    }
    .pdf-header {
        text-align: center;
        margin-bottom: 30px;
        border-bottom: 2px solid #3498db;
        padding-bottom: 20px;
    }
    .pdf-header h1 {
        font-size: 24px;
        color: #2c3e50;
        margin: 0;
    }
    .pdf-header h2 {
        font-size: 18px;
        color: #34495e;
        margin: 10px 0;
    }
    .pdf-topology-container {
        margin: 20px 0;
        border: 1px solid #ddd;
        padding: 20px;
        background: #f8f9fa;
        page-break-inside: avoid;
    }
    .topology-stats {
        text-align: center;
        margin: 10px 0;
    }
    .stat {
        background: white;
        padding: 5px 10px;
        margin: 0 5px;
        border-radius: 4px;
        border: 1px solid #ddd;
        display: inline-block;
    }
    .topology-layer {
        margin: 15px 0;
    }
    .topology-layer h4 {
        color: #34495e;
        border-bottom: 1px solid #ddd;
        padding-bottom: 5px;
    }
    .device-grid {
        display: flex;
        flex-wrap: wrap;
        gap: 10px;
        justify-content: center;
    }
    .device-box {
        border: 2px solid #333;
        border-radius: 6px;
        padding: 10px;
        background: white;
        min-width: 120px;
        text-align: center;
        font-size: 9px;
    }
    .router-device {
        border-color: #ff6b6b;
        background: #ffebee;
    }
    .switch-device {
        border-color: #4ecdc4;
        background: #e0f2f1;
    }
    table {
        width: 100%;
        border-collapse: collapse;
        margin: 15px 0;
        font-size: 9px;
    }
    th, td {
        border: 1px solid #ddd;
        padding: 8px;
        text-align: left;
    }
    th {
        background: #f8f9fa;
        font-weight: bold;
    }
    '''


# ReportLab helper functions (same as before)
def create_executive_summary_reportlab(location_data, styles):
    """Create executive summary using ReportLab."""
    from reportlab.platypus import Paragraph, Table, TableStyle, Spacer
    from reportlab.lib import colors
    from reportlab.lib.units import inch
    
    story = []
    story.append(Paragraph("Executive Summary", styles['Heading1']))
    
    stats = location_data.get('statistics', {})
    summary_data = [
        ['Metric', 'Count'],
        ['Devices', str(stats.get('total_devices', 0))],
        ['Racks', str(stats.get('total_racks', 0))],
        ['VLANs', str(stats.get('total_vlans', 0))],
        ['Connections', str(stats.get('total_connections', 0))]
    ]
    
    summary_table = Table(summary_data, colWidths=[3*inch, 2*inch])
    summary_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.lightgrey),
        ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('GRID', (0, 0), (-1, -1), 1, colors.black)
    ]))
    
    story.append(summary_table)
    story.append(Spacer(1, 20))
    return story


def create_network_topology_section_reportlab(location_data, styles):
    """Create topology section using ReportLab."""
    from reportlab.platypus import Paragraph, Table, TableStyle, Spacer
    from reportlab.lib import colors
    from reportlab.lib.units import inch
    
    story = []
    story.append(Paragraph("Network Topology", styles['Heading1']))
    
    if not location_data or 'devices' not in location_data:
        story.append(Paragraph("No topology data available", styles['Normal']))
        return story
    
    devices = location_data.get('devices', {}).get('devices', [])
    routers = [d for d in devices if 'router' in d.get('device_role', '').lower()]
    switches = [d for d in devices if 'switch' in d.get('device_role', '').lower()]
    others = [d for d in devices if d not in routers and d not in switches]
    
    topology_data = [
        ['Layer', 'Count', 'Example Devices'],
        ['Core (Routers)', str(len(routers)), ', '.join([r.get('name', '')[:15] for r in routers[:3]])],
        ['Distribution (Switches)', str(len(switches)), ', '.join([s.get('name', '')[:15] for s in switches[:3]])],
        ['Access (Others)', str(len(others)), ', '.join([o.get('name', '')[:15] for o in others[:3]])]
    ]
    
    topology_table = Table(topology_data, colWidths=[2*inch, 1*inch, 3*inch])
    topology_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.lightblue),
        ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('GRID', (0, 0), (-1, -1), 1, colors.black)
    ]))
    
    story.append(topology_table)
    story.append(Spacer(1, 20))
    return story


def create_device_inventory_section_reportlab(location_data, styles):
    """Create device inventory using ReportLab."""
    from reportlab.platypus import Paragraph, Table, TableStyle, Spacer
    from reportlab.lib import colors
    from reportlab.lib.units import inch
    
    story = []
    story.append(Paragraph("Device Inventory", styles['Heading1']))
    
    devices = location_data.get('devices', {}).get('devices', [])
    if not devices:
        story.append(Paragraph("No device data available", styles['Normal']))
        return story
    
    device_data = [['Device', 'Type', 'Role', 'Status']]
    for device in devices[:10]:  # First 10 devices
        device_data.append([
            device.get('name', '')[:20],
            device.get('device_type', '')[:15],
            device.get('device_role', '')[:15],
            device.get('status', '')
        ])
    
    if len(devices) > 10:
        device_data.append(['...', f'and {len(devices)-10} more devices', '...', '...'])
    
    device_table = Table(device_data, colWidths=[2*inch, 1.5*inch, 1.5*inch, 1*inch])
    device_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.lightgrey),
        ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('GRID', (0, 0), (-1, -1), 1, colors.black)
    ]))
    
    story.append(device_table)
    story.append(Spacer(1, 20))
    return story


def create_vlan_section_reportlab(location_data, styles):
    """Create VLAN section using ReportLab."""
    from reportlab.platypus import Paragraph, Table, TableStyle, Spacer
    from reportlab.lib import colors
    from reportlab.lib.units import inch
    
    story = []
    story.append(Paragraph("VLAN Configuration", styles['Heading1']))
    
    vlans = location_data.get('vlans', [])
    if not vlans:
        story.append(Paragraph("No VLAN data available", styles['Normal']))
        return story
    
    vlan_data = [['VLAN ID', 'Name', 'Status']]
    for vlan in vlans:
        vlan_data.append([
            str(vlan.get('vid', '')),
            vlan.get('name', '')[:25],
            vlan.get('status', '')
        ])
    
    vlan_table = Table(vlan_data, colWidths=[1*inch, 3*inch, 1*inch])
    vlan_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.lightgrey),
        ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('GRID', (0, 0), (-1, -1), 1, colors.black)
    ]))
    
    story.append(vlan_table)
    story.append(Spacer(1, 20))
    return story


def create_network_health_section_reportlab(location_data, styles):
    """Create network health section using ReportLab."""
    from reportlab.platypus import Paragraph, Table, TableStyle, Spacer
    from reportlab.lib import colors
    from reportlab.lib.units import inch
    
    story = []
    story.append(Paragraph("Network Health", styles['Heading1']))
    
    stats = location_data.get('statistics', {})
    health_data = [
        ['Metric', 'Value', 'Status'],
        ['Total Devices', str(stats.get('total_devices', 0)), 'Operational'],
        ['Total VLANs', str(stats.get('total_vlans', 0)), 'Configured'],
        ['Total Connections', str(stats.get('total_connections', 0)), 
         'Connected' if stats.get('total_connections', 0) > 0 else 'Undocumented']
    ]
    
    health_table = Table(health_data, colWidths=[2*inch, 2*inch, 2*inch])
    health_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.lightgreen),
        ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('GRID', (0, 0), (-1, -1), 1, colors.black)
    ]))
    
    story.append(health_table)
    story.append(Spacer(1, 20))
    
    # Recommendations
    story.append(Paragraph("Recommendations", styles['Heading2']))
    
    recommendations = []
    if stats.get('total_connections', 0) == 0:
        recommendations.append("• Document network connections for accurate topology")
    if stats.get('total_vlans', 0) < 3:
        recommendations.append("• Consider additional VLAN segmentation for security")
    if not recommendations:
        recommendations.append("• Network configuration looks healthy - continue monitoring")
    
    for rec in recommendations:
        story.append(Paragraph(rec, styles['Normal']))
    
    story.append(Spacer(1, 20))
    return story