"""Admin configuration for the Engineer Console plugin."""

from django.contrib import admin
from nautobot.core.admin import NautobotModelAdmin

from .models import DocumentCategory, TechnicalDocument
from .forms import DocumentCategoryForm, TechnicalDocumentForm


@admin.register(DocumentCategory)
class DocumentCategoryAdmin(NautobotModelAdmin):
    """Admin view for DocumentCategory."""
    
    form = DocumentCategoryForm
    list_display = ('name', 'description')
    search_fields = ('name', 'description')


@admin.register(TechnicalDocument)
class TechnicalDocumentAdmin(NautobotModelAdmin):
    """Admin view for TechnicalDocument."""
    
    form = TechnicalDocumentForm
    list_display = ('title', 'category', 'vendor', 'created', 'last_updated')
    list_filter = ('category', 'vendor', 'created', 'last_updated')
    search_fields = ('title', 'description')
    fieldsets = (
        (None, {
            'fields': ('title', 'description', 'file', 'category', 'vendor')
        }),
    )