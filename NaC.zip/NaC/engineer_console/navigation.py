"""Navigation menu items for the Engineer Console plugin."""

from nautobot.core.apps import NavMenuTab, NavMenuGroup, NavMenuItem

menu_items = (
    NavMenuTab(
        name="Engineering Resources",
        weight=850,  # Position it after Integrations tab which has weight 800
        groups=(
            NavMenuGroup(
                name="Documentation",
                weight=100,
                items=(
                    NavMenuItem(
                        link="plugins:engineer_console:engineer_console",
                        name="Engineer Console",
                        permissions=["engineer_console.view_technicaldocument"],
                        weight=100,
                    ),
                    NavMenuItem(
                        link="plugins:engineer_console:category_list",
                        name="Document Category",
                        permissions=["engineer_console.category_list"],
                        weight=200,
                    ),
                ),
            ),
        ),
    ),
)