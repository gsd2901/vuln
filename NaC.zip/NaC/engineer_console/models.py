"""Models for the Engineer Console plugin."""

from django.db import models
from django.core.validators import FileExtensionValidator
from django.urls import reverse
import os

from nautobot.core.models.generics import PrimaryModel

from django.contrib.contenttypes.fields import GenericRelation
from nautobot.extras.models import TaggedItem

from nautobot.extras.utils import extras_features

class DocumentCategory(PrimaryModel):
    """Categories for technical documentation."""
    
    name = models.CharField(max_length=100)
    description = models.TextField(blank=True)
    
    class Meta:
        ordering = ['name']
        verbose_name_plural = "Document Categories"
    
    def __str__(self):
        return self.name
    
    def get_absolute_url(self):
        return reverse('plugins:engineer_console:documents_by_category', args=[self.pk])

class TechnicalDocument(PrimaryModel):
    """Model for storing technical documentation files."""
    
    title = models.CharField(max_length=255)
    description = models.TextField(blank=True)
    file = models.FileField(
        upload_to='documents/',
        validators=[FileExtensionValidator(allowed_extensions=['pdf', 'doc', 'docx'])]
    )
    category = models.ForeignKey(
        DocumentCategory, 
        on_delete=models.SET_NULL,
        null=True, 
        blank=True,
        related_name='documents'
    )
    vendor = models.CharField(max_length=100, blank=True)
    
    # Add tags relation
    tags = GenericRelation(
        to=TaggedItem,
        content_type_field='content_type',
        object_id_field='object_id'
    )
    
    class Meta:
        ordering = ['title']
    
    def __str__(self):
        return self.title
        
    def filename(self):
        return os.path.basename(self.file.name)
    
    def get_absolute_url(self):
        return reverse('plugins:engineer_console:document_detail', args=[self.pk])
    
    def file_type(self):
        """Return the file type based on extension."""
        filename = self.file.name.lower()
        if filename.endswith('.pdf'):
            return 'pdf'
        elif filename.endswith('.doc'):
            return 'doc'
        elif filename.endswith('.docx'):
            return 'docx'
        else:
            return 'other'
    
    def is_pdf(self):
        """Check if the file is a PDF."""
        return self.file.name.lower().endswith('.pdf')
    
    def is_word(self):
        """Check if the file is a Word document."""
        filename = self.file.name.lower()
        return filename.endswith('.doc') or filename.endswith('.docx')
    


@extras_features(
    "custom_fields",
    "custom_links",
    "export_templates",
    "webhooks"
)
class DocumentationRun(models.Model):
    job_result = models.ForeignKey(
        'extras.JobResult',
        on_delete=models.CASCADE,
        related_name='documentation_runs'
    )
    status = models.CharField(
        max_length=20,
        choices=[
            ('running', 'Running'),
            ('completed', 'Completed'),
            ('failed', 'Failed')
        ]
    )
    started_at = models.DateTimeField()
    completed_at = models.DateTimeField(null=True, blank=True)
    files_generated = models.IntegerField(null=True, blank=True)
    output_directory = models.CharField(max_length=500, null=True, blank=True)
    error_message = models.TextField(null=True, blank=True)
    
    class Meta:
        ordering = ['-started_at']