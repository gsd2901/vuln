"""URL patterns for the Engineer Console plugin."""

from django.urls import path, register_converter
import uuid

from . import views

# UUID converter for URL patterns
class UUIDConverter:
    regex = '[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}'
    
    def to_python(self, value):
        return uuid.UUID(value)
    
    def to_url(self, value):
        return str(value)

register_converter(UUIDConverter, 'uuid')

urlpatterns = [
    # Main dashboard
    path('', views.EngineerConsoleView.as_view(), name='engineer_console'),
    path('useful-links', views.UsefulLinksView.as_view(), name='useful_links'),

    
    # Document management views - specific paths first
    path('document/add/', views.DocumentCreateView.as_view(), name='document_add'),
    path('document/<uuid:pk>/edit/', views.DocumentUpdateView.as_view(), name='document_edit'),
    path('document/<uuid:pk>/delete/', views.DocumentDeleteView.as_view(), name='document_delete'),
    path('document/<uuid:pk>/view/', views.DocumentViewerView.as_view(), name='document_viewer'),
    path('document/<uuid:pk>/', views.DocumentDetailView.as_view(), name='document_detail'),
    path('document/import/', views.DocumentImportView.as_view(), name='document_import'),

    # Category management views - specific paths first
    path('category/add/', views.CategoryCreateView.as_view(), name='category_add'),
    path('categories/', views.CategoryListView.as_view(), name='category_list'),
    path('category/<uuid:pk>/edit/', views.CategoryUpdateView.as_view(), name='category_edit'),
    path('category/<uuid:pk>/delete/', views.CategoryDeleteView.as_view(), name='category_delete'),
    path('category/<uuid:pk>/', views.DocumentsByCategoryView.as_view(), name='documents_by_category'),
    
    # Debug URL - remove in production
    path('debug-urls/', views.debug_urls, name='debug_urls'),

    # Documentation URLs - FIXED ORDER AND PATTERNS
    path("docs/", views.docs_dashboard, name="docs_dashboard"),
    
    # API endpoint first to avoid conflicts
    path("docs/api/<str:location_slug>/data/", views.docs_api_data, name="docs_api_data"),
    
    # Download endpoint  
    path("docs/<str:location_slug>/download/<str:filename>", views.docs_download, name="docs_download"),
    
    # File preview - SPECIFIC PATTERN
    path("docs/<str:location_slug>/<str:filename>.md", views.docs_preview, name="docs_preview"),
    
    # Location overview - MUST BE LAST
    path("docs/<str:location_slug>/", views.docs_location, name="docs_location"),

    path('docs/<str:location_slug>/download-pdf/<str:filename>/', 
         views.download_location_pdf, 
         name='docs_download_pdf'),
    
]