from django.contrib import messages
from django.shortcuts import get_object_or_404, redirect, render
from django.views.generic import View

from nautobot.core.views import generic

from .models import ExternalTool
from .connectors.base import get_connector_for_tool


class MerakiDashboardView(generic.View):
    """View for retrieving and displaying Meraki Dashboard information."""
    template_name = 'tool_integration/meraki_dashboard.html'
    
    def get(self, request, pk):
        tool = get_object_or_404(ExternalTool, pk=pk)
        
        # Ensure this is a Meraki tool
        if tool.tool_type != 'meraki':
            messages.error(request, "This tool is not a Meraki integration.")
            return redirect('plugins:tool_integration:externaltool_detail', pk=tool.pk)
            
        # Get the connector for this tool
        connector = get_connector_for_tool(tool)
        
        # Get organizations
        try:
            organizations = connector.get_organizations()
            
            if not organizations:
                messages.warning(request, "No organizations found for this Meraki account.")
                organizations = []
        except Exception as e:
            organizations = []
            messages.error(request, f"Error retrieving organizations: {str(e)}")
        
        context = {
            'tool': tool,
            'organizations': organizations
        }
        
        return render(request, self.template_name, context)


class MerakiNetworksView(generic.View):
    """View for retrieving and displaying Meraki networks for an organization."""
    template_name = 'tool_integration/meraki_networks.html'
    
    def get(self, request, pk, org_id):
        tool = get_object_or_404(ExternalTool, pk=pk)
        
        # Ensure this is a Meraki tool
        if tool.tool_type != 'meraki':
            messages.error(request, "This tool is not a Meraki integration.")
            return redirect('plugins:tool_integration:externaltool_detail', pk=tool.pk)
            
        # Get the connector for this tool
        connector = get_connector_for_tool(tool)
        
        # Get organization details
        try:
            organizations = connector.get_organizations()
            organization = next((org for org in organizations if org['id'] == org_id), None)
            
            if not organization:
                messages.error(request, f"Organization with ID {org_id} not found.")
                return redirect('plugins:tool_integration:meraki_dashboard', pk=tool.pk)
        except Exception as e:
            messages.error(request, f"Error retrieving organization details: {str(e)}")
            return redirect('plugins:tool_integration:meraki_dashboard', pk=tool.pk)
        
        # Get networks for this organization
        try:
            networks = connector.get_networks(org_id)
            
            if not networks:
                messages.warning(request, f"No networks found for organization {organization['name']}.")
                networks = []
        except Exception as e:
            networks = []
            messages.error(request, f"Error retrieving networks: {str(e)}")
        
        context = {
            'tool': tool,
            'organization': organization,
            'networks': networks
        }
        
        return render(request, self.template_name, context)


class MerakiDevicesView(generic.View):
    """View for retrieving and displaying Meraki devices in a network."""
    template_name = 'tool_integration/meraki_devices.html'
    
    def get(self, request, pk, net_id):
        tool = get_object_or_404(ExternalTool, pk=pk)
        
        # Ensure this is a Meraki tool
        if tool.tool_type != 'meraki':
            messages.error(request, "This tool is not a Meraki integration.")
            return redirect('plugins:tool_integration:externaltool_detail', pk=tool.pk)
            
        # Get the connector for this tool
        connector = get_connector_for_tool(tool)
        
        # Get network details - first we need to get all organizations and networks
        try:
            organizations = connector.get_organizations()
            
            # Find the organization that contains this network
            network = None
            organization = None
            
            for org in organizations:
                networks = connector.get_networks(org['id'])
                network_match = next((net for net in networks if net['id'] == net_id), None)
                if network_match:
                    network = network_match
                    organization = org
                    break
            
            if not network:
                messages.error(request, f"Network with ID {net_id} not found.")
                return redirect('plugins:tool_integration:meraki_dashboard', pk=tool.pk)
        except Exception as e:
            messages.error(request, f"Error retrieving network details: {str(e)}")
            return redirect('plugins:tool_integration:meraki_dashboard', pk=tool.pk)
        
        # Get devices for this network
        try:
            devices = connector.get_devices(net_id)
            
            if not devices:
                messages.warning(request, f"No devices found in network {network['name']}.")
                devices = []
        except Exception as e:
            devices = []
            messages.error(request, f"Error retrieving devices: {str(e)}")
        
        context = {
            'tool': tool,
            'organization': organization,
            'network': network,
            'devices': devices
        }
        
        return render(request, self.template_name, context)


class MerakiDeviceDetailView(generic.View):
    """View for retrieving and displaying details of a specific Meraki device."""
    template_name = 'tool_integration/meraki_device_detail.html'
    
    def get(self, request, pk, serial):
        tool = get_object_or_404(ExternalTool, pk=pk)
        
        # Ensure this is a Meraki tool
        if tool.tool_type != 'meraki':
            messages.error(request, "This tool is not a Meraki integration.")
            return redirect('plugins:tool_integration:externaltool_detail', pk=tool.pk)
            
        # Get the connector for this tool
        connector = get_connector_for_tool(tool)
        
        # Get device details
        try:
            device = connector.get_device_status(serial)
            
            if not device:
                messages.error(request, f"Device with serial {serial} not found.")
                return redirect('plugins:tool_integration:meraki_dashboard', pk=tool.pk)
                
            # Get network details
            organizations = connector.get_organizations()
            network = None
            organization = None
            
            for org in organizations:
                networks = connector.get_networks(org['id'])
                network_match = next((net for net in networks if net['id'] == device['networkId']), None)
                if network_match:
                    network = network_match
                    organization = org
                    break
                    
        except Exception as e:
            messages.error(request, f"Error retrieving device details: {str(e)}")
            return redirect('plugins:tool_integration:meraki_dashboard', pk=tool.pk)
        
        context = {
            'tool': tool,
            'organization': organization,
            'network': network,
            'device': device
        }
        
        return render(request, self.template_name, context)


class MerakiUplinkStatusView(generic.View):
    """View for retrieving and displaying Meraki uplink statuses."""
    template_name = 'tool_integration/meraki_uplink_status.html'
    
    def get(self, request, pk, org_id):
        tool = get_object_or_404(ExternalTool, pk=pk)
        
        # Ensure this is a Meraki tool
        if tool.tool_type != 'meraki':
            messages.error(request, "This tool is not a Meraki integration.")
            return redirect('plugins:tool_integration:externaltool_detail', pk=tool.pk)
            
        # Get the connector for this tool
        connector = get_connector_for_tool(tool)
        
        # Get organization details
        try:
            organizations = connector.get_organizations()
            organization = next((org for org in organizations if org['id'] == org_id), None)
            
            if not organization:
                messages.error(request, f"Organization with ID {org_id} not found.")
                return redirect('plugins:tool_integration:meraki_dashboard', pk=tool.pk)
        except Exception as e:
            messages.error(request, f"Error retrieving organization details: {str(e)}")
            return redirect('plugins:tool_integration:meraki_dashboard', pk=tool.pk)
        
        # Get uplink statuses for this organization
        try:
            uplinks = connector.get_uplink_statuses(org_id)
            
            if not uplinks:
                messages.warning(request, f"No uplink status information found for organization {organization['name']}.")
                uplinks = []
        except Exception as e:
            uplinks = []
            messages.error(request, f"Error retrieving uplink statuses: {str(e)}")
        
        context = {
            'tool': tool,
            'organization': organization,
            'uplinks': uplinks
        }
        
        return render(request, self.template_name, context)