from django import forms

from nautobot.core.forms import BootstrapMixin
from .models import ExternalTool, ToolEndpoint

class ExternalToolForm(BootstrapMixin, forms.ModelForm):
    """Form for creating and editing External Tool integrations."""
    
    class Meta:
        model = ExternalTool
        fields = [
            'name', 'tool_type', 'base_url', 'username', 'password', 
            'auth_type', 'enabled', 'description'
        ]
        widgets = {
            'password': forms.PasswordInput(),
            'description': forms.Textarea(attrs={'rows': 3}),
        }
        
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        
        # If we're editing an existing object, don't require password field
        # This allows updating other fields without re-entering the password
        if self.instance.pk:
            self.fields['password'].required = False
            
    def clean_password(self):
        """
        If editing and password field is empty, retain the existing password.
        """
        password = self.cleaned_data.get('password')
        if self.instance.pk and not password:
            return self.instance.password
        return password


class ToolEndpointForm(BootstrapMixin, forms.ModelForm):
    """Form for creating and editing Tool Endpoints."""
    
    class Meta:
        model = ToolEndpoint
        fields = ['tool', 'name', 'endpoint_url', 'description']
        widgets = {
            'description': forms.Textarea(attrs={'rows': 3}),
        }


class ToolConnectionTestForm(BootstrapMixin, forms.Form):
    """Form for testing a connection to an external tool."""
    
    tool = forms.ModelChoiceField(
        queryset=ExternalTool.objects.filter(enabled=True),
        label="Tool to test",
        help_text="Select the external tool to test connection with",
    )