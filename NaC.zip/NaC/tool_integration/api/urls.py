from django.urls import path
from rest_framework.routers import DefaultRouter
from . import views

router = DefaultRouter()
router.register(r'external-tools', views.ExternalToolViewSet, basename='externaltool')
router.register(r'tool-endpoints', views.ToolEndpointViewSet, basename='toolendpoint')

app_name = 'tool_integration-api'

# Start with the router URLs
urlpatterns = router.urls

# Add webhook endpoints
urlpatterns += [
    path('webhooks/servicenow/', views.ServiceNowWebhookView.as_view(), name='servicenow-webhook'),
    path("servicenow/status/", views.servicenow_integration_status, name="servicenow-status"),
    path('webhooks/solarwinds/', views.SolarWindsWebhookView.as_view(), name='solarwinds-webhook'),
]