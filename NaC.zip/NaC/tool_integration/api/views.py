from rest_framework import viewsets, serializers, status  # Make sure to import status from rest_framework
from rest_framework.views import APIView
from rest_framework.response import Response
from django.views.decorators.csrf import csrf_exempt
from django.utils.decorators import method_decorator
import json
import logging
import time
from nautobot.dcim.models import Device
from nautobot.extras.api.serializers import DeviceSerializer
from django.http import JsonResponse
from datetime import timedelta
from django.utils import timezone

import requests
import base64

from tool_integration.models import ExternalTool, ToolEndpoint
from rest_framework.permissions import AllowAny

from tool_integration.mixins import ServiceNowAPIMixin

from naas.utils import F5VIPSNOWDescriptionParser
from naas.models import F5ApprovalRequest

logger = logging.getLogger(__name__)

# Create serializers for your models
class ExternalToolSerializer(serializers.ModelSerializer):
    class Meta:
        model = ExternalTool
        fields = '__all__'  # Or list specific fields

class ToolEndpointSerializer(serializers.ModelSerializer):
    class Meta:
        model = ToolEndpoint
        fields = '__all__'  # Or list specific fields

# Fix your ViewSets by adding queryset and serializer_class
class ExternalToolViewSet(viewsets.ModelViewSet):
    queryset = ExternalTool.objects.all()
    serializer_class = ExternalToolSerializer
    # Add any additional configuration like filterset_class, etc.

class ToolEndpointViewSet(viewsets.ModelViewSet):
    queryset = ToolEndpoint.objects.all()
    serializer_class = ToolEndpointSerializer
    # Add any additional configuration like filterset_class, etc.


@method_decorator(csrf_exempt, name='dispatch')
class ServiceNowWebhookView(APIView, ServiceNowAPIMixin):
    """
    Enhanced webhook endpoint to receive ServiceNow CR notifications and create F5 approval requests
    """
    permission_classes = [AllowAny]
    
    def get(self, request, *args, **kwargs):
        return Response({
            "status": "ready",
            "message": "ServiceNow webhook endpoint ready for F5 integration",
            "supported_operations": ["F5 VIP Creation", "F5 Pool Creation", "F5 VIP Validation", "F5 Pool Modification"],
            "instructions": "Send CR data via POST with description containing F5 configuration details"
        })
    
    def post(self, request, *args, **kwargs):
        try:
            # Enhanced logging for debugging
            logger.info(f"ServiceNow webhook received - Headers: {dict(request.headers)}")
            logger.info(f"Request body: {request.body}")
            
            # Parse the incoming JSON from ServiceNow
            payload = request.data if request.data else {}
            logger.info(f"Parsed payload: {payload}")
            
            # Extract CR information
            cr_number = payload.get('number', payload.get('change_id', payload.get('cr_number')))
            cr_state = payload.get('state', payload.get('status', 'New'))
            description = payload.get('description', payload.get('work_notes', ''))
            short_description = payload.get('short_description', '')
            sys_id = payload.get('sys_id')
            
            # Extract requester info
            requester = payload.get('requested_by', {}).get('name', 'ServiceNow Webhook') if isinstance(payload.get('requested_by'), dict) else payload.get('requester', 'ServiceNow Webhook')
            requester_email = payload.get('requested_by', {}).get('email', '') if isinstance(payload.get('requested_by'), dict) else payload.get('requester_email', 'avinash_sharma@hcltech.com')
            
            # Get approver email
            approver_email = payload.get('approver_email', 'avinash_sharma@chltech.com')
            
            logger.info(f"CR Details - Number: {cr_number}, State: {cr_state}, Requester: {requester}")
            if not cr_number:
                return Response({
                    'status': 'error',
                    'message': 'Missing required field: CR number'
                }, status=400)
            
            # Check if this is an F5-related CR first (based on short description)
            is_f5_related = self._is_f5_related_cr(description, short_description)
            
            if not is_f5_related:
                logger.info(f"CR {cr_number} is not F5-related, skipping")
                return Response({
                    'status': 'ignored',
                    'message': f'CR {cr_number} does not contain F5 configuration requests',
                    'cr_number': cr_number
                })
            
            # If description is missing but it's F5-related, fetch from ServiceNow using the mixin
            if not description and sys_id:
                logger.info(f"Description missing for F5 CR {cr_number}, fetching from ServiceNow API")
                
                # Get ServiceNow tool (try to get the first one, or use settings)
                servicenow_tool = self.get_servicenow_tool()
                
                # Fetch CR details using the mixin
                snow_data = self.fetch_servicenow_change_request(sys_id, tool=servicenow_tool)
                
                if snow_data:
                    description = snow_data.get('description', '')
                    if not requester_email:
                        requester_email = snow_data.get('requester_email', '')
                    if requester == 'ServiceNow Webhook':
                        requester = snow_data.get('requested_by', 'ServiceNow Webhook')
                else:
                    logger.error(f"Could not fetch CR details from ServiceNow for {cr_number}")
            
            # Final check for description
            if not description:
                return Response({
                    'status': 'error', 
                    'message': f'Missing description for F5 CR {cr_number}. Cannot parse F5 configuration without description.',
                    'suggestion': 'Ensure ServiceNow Business Rule includes description field or check ServiceNow API access'
                }, status=400)
            
            logger.info(f"Processing F5 CR {cr_number} with description length: {len(description)}")
            
            # Parse F5 configuration from description
            parsed_data = F5VIPSNOWDescriptionParser.parse_description(description)
            
            if not parsed_data.get('operation'):
                logger.warning(f"Could not determine F5 operation from CR {cr_number}")
                return Response({
                    'status': 'error',
                    'message': f'Could not determine F5 operation type from CR description',
                    'cr_number': cr_number,
                    'parsed_data': parsed_data,
                    'description_preview': description[:200] + '...' if len(description) > 200 else description
                })
            
            # Check if approval request already exists for this CR
            existing_approval = F5ApprovalRequest.objects.filter(cr_number=cr_number).first()
            
            if existing_approval:
                logger.info(f"Approval request already exists for CR {cr_number}")
                return Response({
                    'status': 'exists',
                    'message': f'Approval request already exists for CR {cr_number}',
                    'approval_id': str(existing_approval.id),
                    'approval_status': existing_approval.status
                })
            
            # Create F5 approval request
            approval_request = self._create_f5_approval_request(
                cr_number=cr_number,
                operation=parsed_data['operation'],
                parsed_data=parsed_data,
                requester=requester,
                requester_email=requester_email,
                approver_email=approver_email
            )
            
            logger.info(f"Created F5 approval request {approval_request.id} for CR {cr_number}")
            
            return Response({
                'status': 'success',
                'message': f'F5 approval request created for CR {cr_number}',
                'approval_id': str(approval_request.id),
                'approval_token': str(approval_request.approval_token),
                'operation': approval_request.operation,
                'cr_number': approval_request.cr_number,
                'expires_at': approval_request.expires_at.isoformat(),
                'approval_url': f"/plugins/naas/approve-f5-config/{approval_request.approval_token}/",
                'parsed_configuration': parsed_data
            })
            
        except json.JSONDecodeError as e:
            logger.error(f"JSON decode error: {e}")
            return Response({
                'status': 'error',
                'message': f'Invalid JSON payload: {str(e)}'
            }, status=400)
            
        except Exception as e:
            logger.exception(f"Unexpected error processing ServiceNow webhook: {e}")
            return Response({
                'status': 'error',
                'message': f'Error processing webhook: {str(e)}'
            }, status=500)
    
    def _is_f5_related_cr(self, description, short_description=""):
        """
        Check if the CR is related to F5 configuration
        """
        f5_keywords = [
            'f5', 'vip creation', 'pool creation', 'vip validation',
            'pool modif', 'modify pool', 'pool modification',
            'load balancer', 'big-ip', 'bigip'
        ]
        
        combined_text = f"{description} {short_description}".lower()
        
        return any(keyword in combined_text for keyword in f5_keywords)
    
    def _create_f5_approval_request(self, cr_number, operation, parsed_data, requester, requester_email, approver_email):
        """
        Create F5ApprovalRequest record
        """
        # Set expiration time (24 hours from now, or configure as needed)
        expires_at = timezone.now() + timedelta(hours=24)
        
        # Create the approval request
        approval_request = F5ApprovalRequest.objects.create(
            cr_number=cr_number,
            operation=operation,
            job_parameters=parsed_data,
            requester=requester,
            requester_email=requester_email,
            approver_email=approver_email,
            expires_at=expires_at,
            status='pending'
        )
        
        return approval_request
# Additional utility function to handle CR state changes (if needed)
def handle_cr_state_change(cr_number, new_state):
    """
    Handle CR state changes from ServiceNow
    """
    try:
        approval_requests = F5ApprovalRequest.objects.filter(cr_number=cr_number)
        
        for approval in approval_requests:
            if new_state.lower() in ['cancelled', 'closed', 'withdrawn']:
                if approval.status == 'pending':
                    approval.status = 'expired'
                    approval.save()
                    logger.info(f"Marked approval {approval.id} as expired due to CR state change")
            
            elif new_state.lower() in ['approved', 'implement']:
                # CR is approved, but still need technical approval for F5 config
                logger.info(f"CR {cr_number} approved, F5 approval still required")
        
    except Exception as e:
        logger.error(f"Error handling CR state change: {e}")


# Enhanced view to show ServiceNow integration status
@csrf_exempt
def servicenow_integration_status(request):
    """
    Show ServiceNow integration status and recent webhook activity
    """
    if request.method == 'GET':
        # Get recent webhook-created approvals
        webhook_approvals = F5ApprovalRequest.objects.filter(
            requester__icontains='ServiceNow'
        ).order_by('-created_at')[:10]
        
        stats = {
            'total_webhook_approvals': F5ApprovalRequest.objects.filter(requester__icontains='ServiceNow').count(),
            'pending_webhook_approvals': F5ApprovalRequest.objects.filter(
                requester__icontains='ServiceNow',
                status='pending'
            ).count(),
            'recent_approvals': [
                {
                    'id': str(approval.id),
                    'cr_number': approval.cr_number,
                    'operation': approval.operation,
                    'status': approval.status,
                    'created_at': approval.created_at.isoformat(),
                    'requester': approval.requester
                }
                for approval in webhook_approvals
            ]
        }
        
        return JsonResponse({
            'status': 'success',
            'integration_status': 'active',
            'statistics': stats
        })
    
    return JsonResponse({
        'status': 'error',
        'message': 'Method not allowed'
    }, status=405)


# SolarWinds webhook as APIView
@method_decorator(csrf_exempt, name='dispatch')
class SolarWindsWebhookView(APIView):
    """
    Webhook endpoint to receive SolarWinds alerts and update Nautobot
    """
    authentication_classes = []
    permission_classes = []

    def get_queryset(self):
        return []
    
    def get(self, request, *args, **kwargs):
        return Response({
            "status": "ready",
            "message": "SolarWinds webhook endpoint is ready to receive alerts",
            "instructions": "This endpoint accepts network alerts from SolarWinds via POST",
            "expected_fields": {
                "short_description": "Alert short description",
                "description": "Full alert description containing node information",
                "urgency": "Alert urgency level",
                "impact": "Alert impact level",
                "priority": "Alert priority",
                "category": "Alert category",
                "assignment_group": "Team assigned to the alert",
                "caller_id": "Person or system creating the alert"
            }
        })
    
    def post(self, request, *args, **kwargs):
        try:
            # Define default values for now
            golden_config_status = "successfully checked"
            health_results = {"status": "checked"}
            # Parse the incoming JSON from SolarWinds
            payload = request.data
            logger.info(f"Received webhook from SolarWinds: {payload}")
            
            # Extract data from the payload
            description = payload.get('description', '')
            
            # Parse the description to extract the interface and node details
            interface_name = self.extract_value(description, "Node IP:")
            node_name = self.extract_value(description, "Node Name:")
            interface_type = self.extract_value(description, "Interface Type:")
            full_name = self.extract_value(description, "Full Name (Node+Interface name):")
            status_value = self.extract_value(description, "Status:")
            
            # Extract alert details
            alert_details = self.extract_value(description, "Alert Details:")
            alert_parts = alert_details.split(" ", 1) if alert_details else ["", ""]
            alert_name = alert_parts[0] if len(alert_parts) > 0 else ""
            alert_description = alert_parts[1] if len(alert_parts) > 1 else ""
            
            # Other details from the main payload
            short_description = payload.get('short_description', '')
            urgency = payload.get('urgency', '')
            impact = payload.get('impact', '')
            priority = payload.get('priority', '')
            category = payload.get('category', '')
            assignment_group = payload.get('assignment_group', '')
            caller_id = payload.get('caller_id', '')
            
            if not node_name:
                logger.error("No node name provided in the payload")
                return Response({
                    'status': 'error',
                    'message': 'No node name provided in the payload',
                    'resolution': 'Please include Node Name in the description field'
                }, status=400)
            
            # First, try exact match
            try:
                device = Device.objects.get(name=node_name)
            except Device.DoesNotExist:
                # If exact match fails, try case-insensitive match
                try:
                    device = Device.objects.get(name__iexact=node_name)
                    logger.info(f"Found device with case-insensitive match: {device.name} for input {node_name}")
                    node_name = device.name  # Use the actual device name for further processing
                except Device.DoesNotExist:
                    # Try partial match
                    devices = Device.objects.filter(name__icontains=node_name)
                    if devices.count() == 1:
                        device = devices.first()
                        logger.info(f"Found device with partial match: {device.name} for input {node_name}")
                        node_name = device.name  # Use the actual device name for further processing
                    else:
                        # If we still don't have a match or have multiple matches
                        possible_matches = list(devices.values_list('name', flat=True))
                        logger.error(f"Device {node_name} not found in Nautobot or has multiple matches: {possible_matches}")
                        
                        response_data = {
                            'status': 'error',
                            'message': f'Device "{node_name}" not recognized in Nautobot',
                            'resolution': 'Device not found. Please verify the device exists in Nautobot.'
                        }
                        
                        if possible_matches:
                            response_data['possible_matches'] = possible_matches
                            response_data['resolution'] = 'Multiple possible matches found. Please use the exact device name.'
                        
                        # Return 200 OK with informative error - fixed status code reference
                        return Response(response_data, status=200)
            
            # Update device with alert information using custom fields
            if hasattr(device, 'custom_field_data'):
                device.custom_field_data['interface_name'] = interface_name
                device.custom_field_data['node_name'] = node_name
                device.custom_field_data['interface_type'] = interface_type
                device.custom_field_data['full_name'] = full_name
                device.custom_field_data['interface_status'] = status_value.lower() if status_value else 'unknown'
                device.custom_field_data['alert_name'] = alert_name
                device.custom_field_data['alert_description'] = alert_description
                device.custom_field_data['urgency'] = urgency
                device.custom_field_data['impact'] = impact
                device.custom_field_data['priority'] = priority
                device.custom_field_data['incident_category'] = category
                device.custom_field_data['assignment_group'] = assignment_group
                device.custom_field_data['caller_id'] = caller_id
                device.save()
            
            # Log the successful update
            logger.info(f"Updated device {node_name} with alert information")
            
            # Return a success response with the actions taken
            serializer = DeviceSerializer(device, context={'request': request})
            return Response({
                'status': 'success',
                'message': f'Processed alert for device {node_name}',
                'device': serializer.data,
                'golden_config_status': golden_config_status,
                'health_check_results': health_results
            })
                
        except Exception as e:
            logger.exception("Error processing webhook")
            return Response({
                'status': 'error', 
                'message': f'Error processing webhook: {str(e)}',
                'resolution': 'An unexpected error occurred. Please check your integration setup.'
            }, status=200)  # Return 200 OK with error details - fixed status code reference


    def extract_value(self, text, key_prefix):
        """
        Extract a value from a text string that follows a key prefix.
        Example: If text contains "Node Name: SERV1 Node IP: 172.21.17.105"
        and key_prefix is "Node Name:", this will return "SERV1".
        """
        if not text or not key_prefix:
            return ""

        try:
            # Find the start index of the key
            start_index = text.find(key_prefix)
            if start_index == -1:
                return ""

            # Move the start index to the end of the key
            start_index += len(key_prefix)

            # Find the next key or the end of the string
            next_key_index = len(text)  # Default to the end of the string
            for key in ["Node Name:", "Node IP:", "Full Name", "Status:", "Alert Details:"]:
                if key != key_prefix:
                    key_index = text.find(key, start_index)
                    if key_index != -1 and key_index < next_key_index:
                        next_key_index = key_index

            # Extract and return the value
            return text[start_index:next_key_index].strip()
        except Exception as e:
            logger.error(f"Error extracting value for key {key_prefix}: {str(e)}")
            return ""
    
    def check_golden_config(self, device):
        """
        Run a golden config compliance check on the device
        """
        try:
            # Import nautobot_golden_config if available
            from nautobot_golden_config.models import ConfigCompliance
            from nautobot_golden_config.utilities.helper import get_job_filter_query
            from nautobot_golden_config.jobs import ComplianceJob
            
            # Get the compliance job
            job = ComplianceJob()
            
            # Run compliance job for the specific device
            job_filter_query = get_job_filter_query(device)
            job.run(data={"device_filter": job_filter_query}, commit=True)
            
            logger.info(f"Golden config check completed for {device.name}")
            
            # Return the compliance status
            try:
                compliance = ConfigCompliance.objects.get(device=device)
                return compliance.compliance
            except ConfigCompliance.DoesNotExist:
                return "Unknown"
                
        except ImportError:
            logger.warning("nautobot_golden_config app not installed")
            return "Not available"
        except Exception as e:
            logger.error(f"Error running golden config check: {str(e)}")
            return "Error"
    
    def run_health_check(self, device):
        """
        Run a health check script for the device and return the results
        """
        try:
            # This is where you would implement your health check logic
            # For example, you might use a script to check for connectivity issues
            
            # For now, just return a sample result
            return {
                "status": "warning",
                "latency_ms": 150,
                "packet_loss": "2%",
                "timestamp": "2025-05-06T10:15:30Z",
                "recommendation": "Check interface errors and bandwidth utilization"
            }
        except Exception as e:
            logger.error(f"Error running health check: {str(e)}")
            return {"error": str(e)}