from django.db import models
from django.urls import reverse

from nautobot.core.models.generics import PrimaryModel

class ExternalTool(PrimaryModel):
    """
    Model for storing External Tool integration details.
    """
    TOOL_TYPE_CHOICES = (
        ('servicenow', 'ServiceNow'),
        ('solarwinds', 'SolarWinds'),
        ('meraki', 'Meraki'),
        ('zscaler', 'ZScaler'),
        ('ise', 'ISE'),
        ('dnac', 'DNAC'),
        ('okta', 'Okta'),
        ('azuread', 'Azure AD'),
        ('aws', 'AWS'),
        ('gcp', 'GCP'),
        ('azure', 'Azure'),
        ('jira', 'Jira'),
        ('zendesk', 'Zendesk'),
        ('pagerduty', 'PagerDuty'),
        ('datadog', 'Datadog'),
        ('splunk', 'Splunk'),
        ('newrelic', 'New Relic'),
        ('dynatrace', 'Dynatrace'),
        ('f5', 'F5 BIG-IP'), 
    )
    
    AUTH_TYPE_CHOICES = (
        ('basic', 'Basic Auth'),
        ('oauth', 'OAuth'),
        ('apikey', 'API Key'),
    )
    
    name = models.CharField(
        max_length=100,
        help_text="Name for this tool integration"
    )
    
    tool_type = models.CharField(
        max_length=50,
        choices=TOOL_TYPE_CHOICES,
        help_text="Type of external tool"
    )
    
    base_url = models.URLField(
        help_text="Base URL for the external tool (e.g., https://example.service-now.com)"
    )
    
    username = models.CharField(
        max_length=255,
        help_text="Username for authentication"
    )
    
    # Note: In production, you should use a proper encrypted field or secret storage
    # For this example, using char field, but consider django-encrypted-fields
    password = models.CharField(
        max_length=255,
        help_text="Password or API key (should be encrypted in production)"
    )
    
    auth_type = models.CharField(
        max_length=50,
        default="basic",
        choices=AUTH_TYPE_CHOICES,
        help_text="Authentication mechanism to use"
    )
    
    enabled = models.BooleanField(
        default=True,
        help_text="Whether this integration is active"
    )
    
    description = models.TextField(
        blank=True,
        help_text="Additional notes about this integration"
    )
    
    class Meta:
        ordering = ('name',)
        verbose_name = "External Tool"
        verbose_name_plural = "External Tools"
        
    def __str__(self):
        return f"{self.name} ({self.get_tool_type_display()})"
    
    def get_absolute_url(self):
        return reverse('plugins:tool_integration:externaltool_detail', args=[self.pk])


class ToolEndpoint(PrimaryModel):
    """
    Model for storing endpoint URLs discovered from external tool integrations.
    """
    tool = models.ForeignKey(
        to=ExternalTool,
        on_delete=models.CASCADE,
        related_name='endpoints',
    )
    
    name = models.CharField(
        max_length=100,
        help_text="Descriptive name for this endpoint (e.g., 'Incidents', 'Change Requests')"
    )
    
    endpoint_url = models.URLField(
        help_text="Full URL for this endpoint"
    )
    
    description = models.TextField(
        blank=True,
        help_text="Description of this endpoint's purpose"
    )
    
    class Meta:
        ordering = ('tool', 'name')
        unique_together = ('tool', 'name')
        verbose_name = "Tool Endpoint"
        verbose_name_plural = "Tool Endpoints"
        
    def __str__(self):
        return f"{self.tool}: {self.name}"
    
    def get_absolute_url(self):
        return reverse('plugins:tool_integration:toolendpoint_detail', args=[self.pk])