"""F5 Integration Jobs for Nautobot - Following NAAS Pattern."""

from nautobot.apps.jobs import Job, ObjectVar
from nautobot.ipam.models import IPAddress, Prefix
from nautobot.extras.models import Role, Status
import ipaddress
from netaddr import IPNetwork

from .models import ExternalTool
from .connectors.base import get_connector_for_tool


def ensure_parent_prefix(ip_address_str, status=None, logger=None):
    """
    Ensure a parent prefix exists for the given IP address.
    Creates a /24 prefix for the IP if no parent exists.
    """
    try:
        if logger:
            logger.info(f"Checking parent prefix for {ip_address_str}")
            
        ip = ipaddress.ip_address(ip_address_str)
        
        # Check if a parent prefix already exists
        existing_prefix = Prefix.objects.filter(
            network__net_contains=str(ip)
        ).first()
        
        if existing_prefix:
            if logger:
                logger.info(f"Found existing parent prefix: {existing_prefix.network}")
            return existing_prefix
        
        # Create a /24 prefix for IPv4 addresses
        if ip.version == 4:
            network = ipaddress.ip_network(f"{ip}/24", strict=False)
        else:
            # For IPv6, use /64
            network = ipaddress.ip_network(f"{ip}/64", strict=False)
        
        # Use netaddr for Nautobot compatibility
        netaddr_network = IPNetwork(str(network))
        
        if logger:
            logger.info(f"Creating new prefix: {netaddr_network}")
        
        # Create the prefix
        prefix_data = {
            'network': netaddr_network,
            'description': f'Auto-created for F5 VIP {ip_address_str}'
        }
        
        if status:
            prefix_data['status'] = status
            
        prefix, created = Prefix.objects.get_or_create(
            network=netaddr_network,
            defaults=prefix_data
        )
        
        if logger:
            if created:
                logger.info(f"Successfully created prefix: {netaddr_network}")
            else:
                logger.info(f"Using existing prefix: {netaddr_network}")
        
        return prefix
        
    except Exception as e:
        if logger:
            logger.error(f"Error in ensure_parent_prefix for {ip_address_str}: {str(e)}")
        return None


class F5VipSyncSimpleJob(Job):
    """Simple job to sync F5 VIPs to Nautobot IP addresses."""
    
    # Define tool_id as a job parameter - only show F5 tools
    tool = ObjectVar(
        model=ExternalTool,
        description="Select the F5 tool to sync from",
        label="F5 Tool",
        required=True
    )
    
    def ready(self):
        """Override ready to set F5-only queryset"""
        super().ready()
        # Filter to only show F5 tools
        if hasattr(self, 'tool'):
            self.tool.queryset = ExternalTool.objects.filter(tool_type='f5')
    
    class Meta:
        name = "F5 VIP Sync (Simple)"
        description = "Sync F5 Virtual Servers (VIPs) to Nautobot IP addresses - Basic version"
        has_sensitive_variables = False
        
    def run(self, tool, **kwargs):
        """Run F5 VIP synchronization."""
        self.logger.info("Starting F5 VIP synchronization (Simple)...")
        
        # tool is the selected F5 tool instance
        self.logger.info(f"Using F5 tool: {tool.name}")
        
        # Get F5 connector
        try:
            f5_connector = get_connector_for_tool(tool)
            self.logger.info("F5 connector created successfully")
        except Exception as e:
            error_msg = f"Failed to get F5 connector: {str(e)}"
            self.logger.error(error_msg)
            return error_msg
        
        # Test connection
        try:
            connection_test = f5_connector.test_connection()
            if not connection_test.get('success', False):
                error_msg = connection_test.get('error', 'Unknown connection error')
                self.logger.error(f"F5 connection failed: {error_msg}")
                return f"Connection failed: {error_msg}"
            else:
                self.logger.info("F5 connection successful")
        except Exception as e:
            error_msg = f"Connection test failed: {str(e)}"
            self.logger.error(error_msg)
            return error_msg
        
        # Get F5 virtual servers
        try:
            virtual_servers = f5_connector.get_virtual_servers()
            self.logger.info(f"Found {len(virtual_servers)} virtual servers")
        except Exception as e:
            error_msg = f"Failed to get virtual servers: {str(e)}"
            self.logger.error(error_msg)
            return error_msg
        
        if not virtual_servers:
            msg = "No virtual servers found on F5 device"
            self.logger.warning(msg)
            return msg
        
        # Get or create VIP role
        try:
            vip_role, created = Role.objects.get_or_create(
                name="VIP",
                defaults={'slug': 'vip'}
            )
            if created:
                self.logger.info("Created VIP role")
            else:
                self.logger.info("Using existing VIP role")
        except Exception as e:
            self.logger.warning(f"Could not create VIP role: {str(e)}. Proceeding without role.")
            vip_role = None
        
        # Get active status
        try:
            status = Status.objects.filter(name__icontains='active').first()
            if not status:
                # Try to get any available status
                status = Status.objects.first()
            self.logger.info(f"Using status: {status.name if status else 'None'}")
        except Exception as e:
            self.logger.warning(f"Could not get status: {str(e)}. Proceeding without status.")
            status = None
        
        # Sync virtual servers
        synced_count = 0
        skipped_count = 0
        error_count = 0
        
        for vip in virtual_servers:
            try:
                vip_name = vip.get('name', 'Unknown')
                destination = vip.get('destination', '')
                
                self.logger.info(f"Processing VIP: {vip_name} -> {destination}")
                
                # Parse destination - F5 format is often /Common/IP:PORT
                if ':' in destination:
                    ip_address, port = destination.rsplit(':', 1)
                else:
                    ip_address = destination
                    port = None
                
                # Strip F5 partition prefix (e.g., /Common/ or /Partition/)
                if '/' in ip_address:
                    # Split by '/' and take the last part (the actual IP)
                    ip_address = ip_address.split('/')[-1]
                
                # Skip Any IPv4 destinations
                if ip_address == "0.0.0.0" or ip_address.lower() == "any ipv4":
                    self.logger.info(f"Skipping VIP {vip_name} with 'Any IPv4' destination")
                    skipped_count += 1
                    continue
                
                # Validate IP address format
                if not ip_address or ip_address == "":
                    self.logger.warning(f"Skipping VIP {vip_name} with empty IP address")
                    skipped_count += 1
                    continue
                
                # Ensure parent prefix exists
                try:
                    parent_prefix = ensure_parent_prefix(ip_address, status, self.logger)
                    if parent_prefix:
                        self.logger.info(f"Using parent prefix: {parent_prefix.network}")
                    else:
                        self.logger.warning(f"Could not create parent prefix for {ip_address}")
                except Exception as e:
                    self.logger.error(f"Error ensuring parent prefix for {ip_address}: {str(e)}")
                
                # Create IP address data
                ip_data = {
                    'address': f"{ip_address}/32",
                    'description': f"F5 VIP: {vip_name}"
                }
                
                # Add optional fields if available
                if status:
                    ip_data['status'] = status
                if vip_role:
                    ip_data['role'] = vip_role
                
                # Create or update IP address
                ip_obj, created = IPAddress.objects.get_or_create(
                    address=f"{ip_address}/32",
                    defaults=ip_data
                )
                
                # Update description if it exists but was different
                if not created and ip_obj.description != ip_data['description']:
                    ip_obj.description = ip_data['description']
                    ip_obj.save()
                
                if created:
                    self.logger.info(f"✅ Created VIP: {vip_name} ({ip_address})")
                else:
                    self.logger.info(f"✅ Updated VIP: {vip_name} ({ip_address})")
                
                synced_count += 1
                
            except Exception as e:
                self.logger.error(f"❌ Error syncing VIP {vip.get('name', 'Unknown')}: {str(e)}")
                error_count += 1
        
        # Final result
        result_msg = f"F5 VIP sync completed! ✅ Synced: {synced_count} | ⏭️ Skipped: {skipped_count} | ❌ Errors: {error_count}"
        self.logger.info(result_msg)
        return result_msg


class F5ConnectionTestJob(Job):
    """Simple job to test F5 connection."""
    
    # Define tool as a job parameter - only show F5 tools
    tool = ObjectVar(
        model=ExternalTool,
        description="Select the F5 tool to test",
        label="F5 Tool",
        required=True
    )
    
    def ready(self):
        """Override ready to set F5-only queryset"""
        super().ready()
        # Filter to only show F5 tools
        if hasattr(self, 'tool'):
            self.tool.queryset = ExternalTool.objects.filter(tool_type='f5')
    
    class Meta:
        name = "F5 Connection Test"
        description = "Test connection to F5 device and list virtual servers"
        has_sensitive_variables = False
        
    def run(self, tool, **kwargs):
        """Test F5 connection and show basic info."""
        self.logger.info("Starting F5 connection test...")
        
        # tool is the selected F5 tool instance
        self.logger.info(f"Testing F5 tool: {tool.name} at {tool.base_url}")
        
        # Get F5 connector
        try:
            f5_connector = get_connector_for_tool(tool)
        except Exception as e:
            return f"Failed to get F5 connector: {str(e)}"
        
        # Test connection
        try:
            connection_test = f5_connector.test_connection()
            if connection_test.get('success', False):
                self.logger.info("✅ F5 connection successful!")
            else:
                error = connection_test.get('error', 'Unknown error')
                return f"❌ F5 connection failed: {error}"
        except Exception as e:
            return f"❌ Connection test error: {str(e)}"
        
        # Get basic info
        results = []
        
        # Test virtual servers
        try:
            vips = f5_connector.get_virtual_servers()
            results.append(f"📊 Virtual Servers: {len(vips)}")
            
            # Show first few VIPs
            for i, vip in enumerate(vips[:5]):
                vip_name = vip.get('name', 'Unknown')
                destination = vip.get('destination', 'Unknown')
                results.append(f"   {i+1}. {vip_name} -> {destination}")
            
            if len(vips) > 5:
                results.append(f"   ... and {len(vips) - 5} more")
                
        except Exception as e:
            results.append(f"❌ Could not get virtual servers: {str(e)}")
        
        # Test pools
        try:
            pools = f5_connector.get_pools()
            results.append(f"📊 Pools: {len(pools)}")
        except Exception as e:
            results.append(f"❌ Could not get pools: {str(e)}")
        
        # Test nodes
        try:
            nodes = f5_connector.get_nodes()
            results.append(f"📊 Nodes: {len(nodes)}")
        except Exception as e:
            results.append(f"❌ Could not get nodes: {str(e)}")
        
        result_msg = "✅ F5 Connection Test Results:\n" + "\n".join(results)
        self.logger.info(result_msg)
        return result_msg