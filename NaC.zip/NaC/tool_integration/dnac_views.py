from django.contrib import messages
from django.shortcuts import get_object_or_404, render
from django.views.generic import View

from .models import ExternalTool
from .connectors.base import get_connector_for_tool

import json

class DNACDashboardView(View):
    """View for the DNAC Dashboard."""
    template_name = 'tool_integration/dnac_dashboard.html'
    
    def get(self, request, pk):
        tool = get_object_or_404(ExternalTool, pk=pk)
        
        # Ensure this is a DNAC tool
        if tool.tool_type != 'dnac':
            messages.error(request, "This tool is not a DNAC integration.")
            return render(request, 'tool_integration/error.html', {'tool': tool})
        
        try:
            # Get the connector for this tool
            connector = get_connector_for_tool(tool)
            
            # Get basic information
            sites = connector.get_sites()
            
            context = {
                'tool': tool,
                'sites': sites
            }
            
            return render(request, self.template_name, context)
        
        except Exception as e:
            messages.error(request, f"Error retrieving DNAC data: {str(e)}")
            return render(request, self.template_name, {'tool': tool, 'error': str(e)})


class DNACSitesView(View):
    """View for DNAC Sites."""
    template_name = 'tool_integration/dnac_sites.html'
    
    def get(self, request, pk):
        tool = get_object_or_404(ExternalTool, pk=pk)
        
        # Ensure this is a DNAC tool
        if tool.tool_type != 'dnac':
            messages.error(request, "This tool is not a DNAC integration.")
            return render(request, 'tool_integration/error.html', {'tool': tool})
        
        try:
            # Get the connector for this tool
            connector = get_connector_for_tool(tool)
            
            # Get sites
            sites = connector.get_sites()
            
            context = {
                'tool': tool,
                'sites': sites
            }
            
            return render(request, self.template_name, context)
        
        except Exception as e:
            messages.error(request, f"Error retrieving DNAC sites: {str(e)}")
            return render(request, self.template_name, {'tool': tool, 'error': str(e)})


class DNACDevicesView(View):
    """View for DNAC Network Devices."""
    template_name = 'tool_integration/dnac_devices.html'
    
    def get(self, request, pk, site_id=None):
        tool = get_object_or_404(ExternalTool, pk=pk)
        
        # Ensure this is a DNAC tool
        if tool.tool_type != 'dnac':
            messages.error(request, "This tool is not a DNAC integration.")
            return render(request, 'tool_integration/error.html', {'tool': tool})
        
        try:
            # Get the connector for this tool
            connector = get_connector_for_tool(tool)
            
            # Get devices, optionally filtered by site ID
            devices = connector.get_network_devices(site_id)
            
            context = {
                'tool': tool,
                'devices': devices,
                'site_id': site_id
            }
            
            return render(request, self.template_name, context)
        
        except Exception as e:
            messages.error(request, f"Error retrieving DNAC devices: {str(e)}")
            return render(request, self.template_name, {'tool': tool, 'error': str(e)})


class DNACDeviceDetailView(View):
    """View for DNAC Device Detail."""
    template_name = 'tool_integration/dnac_device_detail.html'
    
    def get(self, request, pk, device_id):
        tool = get_object_or_404(ExternalTool, pk=pk)
        
        # Ensure this is a DNAC tool
        if tool.tool_type != 'dnac':
            messages.error(request, "This tool is not a DNAC integration.")
            return render(request, 'tool_integration/error.html', {'tool': tool})
        
        try:
            # Get the connector for this tool
            connector = get_connector_for_tool(tool)
            
            # Get all devices to find the specific one
            all_devices = connector.get_network_devices()
            device = next((d for d in all_devices if d.get('id') == device_id), None)
            
            if not device:
                messages.error(request, f"Device with ID {device_id} not found.")
                return render(request, 'tool_integration/error.html', {'tool': tool})
            
            # Get device interfaces
            interfaces = connector.get_device_interfaces(device_id)
            
            context = {
                'tool': tool,
                'device': device,
                'interfaces': interfaces
            }
            
            return render(request, self.template_name, context)
        
        except Exception as e:
            messages.error(request, f"Error retrieving DNAC device details: {str(e)}")
            return render(request, self.template_name, {'tool': tool, 'error': str(e)})


class DNACNetworkHealthView(View):
    """View for DNAC Network Health."""
    template_name = 'tool_integration/dnac_network_health.html'
    
    def get(self, request, pk):
        tool = get_object_or_404(ExternalTool, pk=pk)
        
        # Ensure this is a DNAC tool
        if tool.tool_type != 'dnac':
            messages.error(request, "This tool is not a DNAC integration.")
            return render(request, 'tool_integration/error.html', {'tool': tool})
        
        try:
            # Get the connector for this tool
            connector = get_connector_for_tool(tool)
            
            # Get network health
            network_health = connector.get_network_health()
            
            context = {
                'tool': tool,
                'network_health': network_health
            }
            
            return render(request, self.template_name, context)
        
        except Exception as e:
            messages.error(request, f"Error retrieving DNAC network health: {str(e)}")
            return render(request, self.template_name, {'tool': tool, 'error': str(e)})


class DNACClientHealthView(View):
    """View for DNAC Client Health."""
    template_name = 'tool_integration/dnac_client_health.html'
    
    def get(self, request, pk):
        tool = get_object_or_404(ExternalTool, pk=pk)
        
        # Ensure this is a DNAC tool
        if tool.tool_type != 'dnac':
            messages.error(request, "This tool is not a DNAC integration.")
            return render(request, 'tool_integration/error.html', {'tool': tool})
        
        try:
            # Get the connector for this tool
            connector = get_connector_for_tool(tool)
            
            # Get client health
            client_health = connector.get_client_health()
            
            context = {
                'tool': tool,
                'client_health': client_health
            }
            
            return render(request, self.template_name, context)
        
        except Exception as e:
            messages.error(request, f"Error retrieving DNAC client health: {str(e)}")
            return render(request, self.template_name, {'tool': tool, 'error': str(e)})


class DNACIssuesView(View):
    """View for DNAC Issues."""
    template_name = 'tool_integration/dnac_issues.html'
    
    def get(self, request, pk):
        tool = get_object_or_404(ExternalTool, pk=pk)
        
        # Ensure this is a DNAC tool
        if tool.tool_type != 'dnac':
            messages.error(request, "This tool is not a DNAC integration.")
            return render(request, 'tool_integration/error.html', {'tool': tool})
        
        try:
            # Get the connector for this tool
            connector = get_connector_for_tool(tool)
            
            # Get issues
            issues = connector.get_issues()
            
            context = {
                'tool': tool,
                'issues': issues
            }
            
            return render(request, self.template_name, context)
        
        except Exception as e:
            messages.error(request, f"Error retrieving DNAC issues: {str(e)}")
            return render(request, self.template_name, {'tool': tool, 'error': str(e)})


class DNACTopologyView(View):
    """View for DNAC Topology."""
    template_name = 'tool_integration/dnac_topology.html'
    
    def get(self, request, pk, topology_type='physical'):
        tool = get_object_or_404(ExternalTool, pk=pk)
        
        # Ensure this is a DNAC tool
        if tool.tool_type != 'dnac':
            messages.error(request, "This tool is not a DNAC integration.")
            return render(request, 'tool_integration/error.html', {'tool': tool})
        
        try:
            # Get the connector for this tool
            connector = get_connector_for_tool(tool)
            
            # Get the appropriate topology
            if topology_type == 'site':
                topology = connector.get_site_topology()
                topology_title = "Site Topology"
            else:  # Default to physical
                topology = connector.get_physical_topology()
                topology_title = "Physical Topology"
            
            context = {
                'tool': tool,
                'topology': topology,
                'topology_type': topology_type,
                'topology_title': topology_title,
                # Add these lines to ensure JSON data is properly passed to the template
                'topology_nodes_json': json.dumps(topology.get('nodes', [])),
                'topology_links_json': json.dumps(topology.get('links', []))
            }
            
            return render(request, self.template_name, context)
        
        except Exception as e:
            messages.error(request, f"Error retrieving DNAC topology: {str(e)}")
            return render(request, self.template_name, {'tool': tool, 'error': str(e)})