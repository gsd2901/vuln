from django.contrib import messages
from django.shortcuts import get_object_or_404, redirect, render
from django.urls import reverse
from django.views.generic import View, TemplateView

import requests
from nautobot.core.views import generic

from .models import ExternalTool, ToolEndpoint
from .forms import ExternalToolForm, ToolEndpointForm, ToolConnectionTestForm
from .connectors.base import get_connector_for_tool

from .meraki_views import (
    MerakiDashboardView,
    MerakiNetworksView,
    MerakiDevicesView,
    MerakiDeviceDetailView,
    MerakiUplinkStatusView
)

from .velocloud_api import get_edges, get_edge_links,get_edge_status
from datetime import datetime, timedelta
import time
from django.http import JsonResponse
import math

class ExternalToolListView(generic.ObjectListView):
    """View for listing all external tool integrations."""
    queryset = ExternalTool.objects.all()
    table = 'ExternalToolTable'  # Will define this in tables.py
    #filterset = 'ExternalToolFilterSet'  # Will define this in filters.py
    action_buttons = ('add',)


class ExternalToolView(generic.ObjectView):
    """View for viewing a single external tool integration."""
    queryset = ExternalTool.objects.all()
    template_name = 'tool_integration/externaltool.html'


class ExternalToolEditView(generic.ObjectEditView):
    """View for editing an external tool integration."""
    queryset = ExternalTool.objects.all()
    form_class = ExternalToolForm
    model_form = ExternalToolForm


class ExternalToolDeleteView(generic.ObjectDeleteView):
    """View for deleting an external tool integration."""
    queryset = ExternalTool.objects.all()


class ExternalToolBulkImportView(generic.BulkImportView):
    """View for bulk importing external tool integrations."""
    queryset = ExternalTool.objects.all()
    model_form = ExternalToolForm


class ExternalToolBulkDeleteView(generic.BulkDeleteView):
    """View for bulk deleting external tool integrations."""
    queryset = ExternalTool.objects.all()
    table = 'ExternalToolTable'  # Will define this in tables.py


class ToolEndpointListView(generic.ObjectListView):
    """View for listing all tool endpoints."""
    queryset = ToolEndpoint.objects.all()
    table = 'ToolEndpointTable'  # Will define this in tables.py
    filterset = 'ToolEndpointFilterSet'  # Will define this in filters.py
    action_buttons = ('add',)


class ToolEndpointView(generic.ObjectView):
    """View for viewing a single tool endpoint."""
    queryset = ToolEndpoint.objects.all()


class ToolEndpointEditView(generic.ObjectEditView):
    """View for editing a tool endpoint."""
    queryset = ToolEndpoint.objects.all()
    form_class = ToolEndpointForm


class ToolEndpointDeleteView(generic.ObjectDeleteView):
    """View for deleting a tool endpoint."""
    queryset = ToolEndpoint.objects.all()


class ToolEndpointBulkImportView(generic.BulkImportView):
    """View for bulk importing tool endpoints."""
    queryset = ToolEndpoint.objects.all()
    model_form = ToolEndpointForm


class ToolEndpointBulkDeleteView(generic.BulkDeleteView):
    """View for bulk deleting tool endpoints."""
    queryset = ToolEndpoint.objects.all()
    table = 'ToolEndpointTable'  # Will define this in tables.py


class IntegrationDashboardView(TemplateView):
    """View for the integration dashboard."""
    template_name = 'tool_integration/integration_dashboard.html'
    

class IntegrationSetupView(View):
    """View for setting up a specific integration type."""
    template_name = 'tool_integration/integration_setup.html'
    
    def get(self, request, tool_type):
        """Handle GET request - display the integration setup form."""
        # Check if this tool type already exists
        existing_tool = ExternalTool.objects.filter(tool_type=tool_type).first()
        
        if existing_tool:
            # If it exists, redirect to the edit view
            return redirect(
                'plugins:tool_integration:externaltool_detail', 
                pk=existing_tool.pk
            )
        else:
            # Otherwise show the form to create a new one
            form = ExternalToolForm(initial={'tool_type': tool_type})
            
            # If it's a new tool, disable the tool_type field since it's pre-selected
            form.fields['tool_type'].widget.attrs['disabled'] = True
            
            # Get a display name for the tool type
            tool_type_display = dict(ExternalTool.TOOL_TYPE_CHOICES).get(
                tool_type, tool_type.capitalize()
            )
            
            return render(request, self.template_name, {
                'form': form,
                'tool_type': tool_type,
                'tool_type_display': tool_type_display,
            })
    
    def post(self, request, tool_type):
        """Handle POST request - save the integration."""
        # Create a mutable copy of POST data and add tool_type
        post_data = request.POST.copy()
        post_data['tool_type'] = tool_type
        
        # Use the modified data for the form
        form = ExternalToolForm(post_data)
        
        if form.is_valid():
            tool = form.save(commit=False)
            tool.tool_type = tool_type
            tool.save()
            
            messages.success(
                request, 
                f"{tool.name} integration has been successfully created!"
            )
            
            # Redirect to test connection
            return redirect(
                'plugins:tool_integration:test_connection_tool', 
                pk=tool.pk
            )
        
        # Get a display name for the tool type
        tool_type_display = dict(ExternalTool.TOOL_TYPE_CHOICES).get(
            tool_type, tool_type.capitalize()
        )
        
        return render(request, self.template_name, {
            'form': form,
            'tool_type': tool_type,
            'tool_type_display': tool_type_display,
        })


class TestConnectionView(View):
    """View for testing a connection to an external tool."""
    template_name = 'tool_integration/test_connection.html'
    
    def get(self, request, pk=None):
        """GET request handler - display the form."""
        if pk:
            # If a specific tool ID was provided, use that tool
            tool = get_object_or_404(ExternalTool, pk=pk)
            form = ToolConnectionTestForm(initial={'tool': tool})
            form.fields['tool'].widget.attrs['disabled'] = True
        else:
            # Otherwise, show a dropdown to select a tool
            form = ToolConnectionTestForm()
            
        return render(request, self.template_name, {
            'form': form,
            'tool': tool if pk else None,
        })
    
    def post(self, request, pk=None):
        """POST request handler - test the connection."""
        if pk:
            # If a specific tool ID was provided, use that tool
            tool = get_object_or_404(ExternalTool, pk=pk)
        else:
            # Get the tool from the form
            form = ToolConnectionTestForm(request.POST)
            if not form.is_valid():
                messages.error(request, "Invalid form submission.")
                return render(request, self.template_name, {'form': form})
                
            tool = form.cleaned_data['tool']
            
        # Get the connector for this tool
        connector = get_connector_for_tool(tool)
        
        # Test the connection
        connection_result = connector.test_connection()
        
        if connection_result['success']:
            messages.success(request, f"Successfully connected to {tool.name}!")
            
            # Discover endpoints
            endpoints = connector.discover_endpoints()
            
            # Save or update discovered endpoints
            saved_endpoints = []
            for name, endpoint_data in endpoints.items():
                endpoint, created = ToolEndpoint.objects.update_or_create(
                    tool=tool,
                    name=name,
                    defaults={
                        'endpoint_url': endpoint_data['url'],
                        'description': endpoint_data.get('description', ''),
                    }
                )
                saved_endpoints.append(endpoint)
                
            if saved_endpoints:
                messages.success(
                    request, 
                    f"Discovered and saved {len(saved_endpoints)} endpoints."
                )
        else:
            messages.error(
                request, 
                f"Failed to connect to {tool.name}: {connection_result['error']}"
            )
            
        # Render the template with the results
        return render(request, self.template_name, {
            'form': ToolConnectionTestForm(initial={'tool': tool}),
            'tool': tool,
            'connection_result': connection_result,
            'endpoints': tool.endpoints.all() if connection_result['success'] else None,
        })
    
class ServiceNowIncidentsView(generic.View):
    """View for retrieving and displaying ServiceNow incidents."""
    template_name = 'tool_integration/servicenow_incidents.html'
    
    def get(self, request, pk):
        tool = get_object_or_404(ExternalTool, pk=pk)
        
        # Ensure this is a ServiceNow tool
        if tool.tool_type != 'servicenow':
            messages.error(request, "This tool is not a ServiceNow integration.")
            return redirect('plugins:tool_integration:externaltool_detail', pk=tool.pk)
            
        # Set up authentication based on auth type
        auth = None
        if tool.auth_type == 'basic':
            auth = (tool.username, tool.password)
        
        # API endpoint for incidents
        incidents_endpoint = next((e for e in tool.endpoints.all() if e.name == 'Incidents'), None)
        
        if not incidents_endpoint:
            messages.error(request, "No Incidents endpoint configured for this tool.")
            return redirect('plugins:tool_integration:externaltool_detail', pk=tool.pk)
        
        # Make the API request
        try:
            response = requests.get(
                incidents_endpoint.endpoint_url, 
                auth=auth,
                headers={'Content-Type': 'application/json'},
                params={'sysparm_limit': 10}  # Limit to 10 most recent incidents
            )
            response.raise_for_status()
            incidents = response.json().get('result', [])
        except requests.exceptions.RequestException as e:
            incidents = []
            messages.error(request, f"Error retrieving incidents: {str(e)}")
        
        context = {
            'tool': tool,
            'incidents': incidents
        }
        
        return render(request, self.template_name, context)


class ServiceNowChangesView(generic.View):
    """View for retrieving and displaying ServiceNow change requests."""
    template_name = 'tool_integration/servicenow_changes.html'
    
    def get(self, request, pk):
        tool = get_object_or_404(ExternalTool, pk=pk)
        
        # Ensure this is a ServiceNow tool
        if tool.tool_type != 'servicenow':
            messages.error(request, "This tool is not a ServiceNow integration.")
            return redirect('plugins:tool_integration:externaltool_detail', pk=tool.pk)
            
        # Set up authentication based on auth type
        auth = None
        if tool.auth_type == 'basic':
            auth = (tool.username, tool.password)
        
        # API endpoint for changes
        changes_endpoint = next((e for e in tool.endpoints.all() if e.name == 'Change Requests'), None)
        
        if not changes_endpoint:
            messages.error(request, "No Change Requests endpoint configured for this tool.")
            return redirect('plugins:tool_integration:externaltool_detail', pk=tool.pk)
        
        # Make the API request
        try:
            response = requests.get(
                changes_endpoint.endpoint_url, 
                auth=auth,
                headers={'Content-Type': 'application/json'},
                params={'sysparm_limit': 10}  # Limit to 10 most recent changes
            )
            response.raise_for_status()
            changes = response.json().get('result', [])
        except requests.exceptions.RequestException as e:
            changes = []
            messages.error(request, f"Error retrieving changes: {str(e)}")
        
        context = {
            'tool': tool,
            'changes': changes
        }
        
        return render(request, self.template_name, context)

def velo_edge_list_view(request):
    edges = get_edges()
    return render(request, "tool_integration/edges.html", {"edges": edges})



def velo_edge_details(request, edge_id):
    """Renders edge details page with default time range: last 12 hours."""
    now = int(time.time() * 1000)
    end = now - (6 * 60 * 60 * 1000)       # 6 hours before now
    start = end - (1 * 60 * 60 * 1000)    # 1 hours before end

    context = {
        'edge_id': edge_id,
        'start_time_ms': int(start),
        'end_time_ms': int(end)
    }
    return render(request, 'tool_integration/edge_details.html', context)


def aggregate_points(values, target_points):
    # Keep only numeric values (int or float)
    numeric_values = [float(v) for v in values if isinstance(v, (int, float))]
    if len(numeric_values) == 0:
        return []

    if len(numeric_values) <= target_points:
        return numeric_values

    import math
    chunk_size = math.ceil(len(numeric_values) / target_points)
    aggregated = []
    for i in range(0, len(numeric_values), chunk_size):
        chunk = numeric_values[i:i+chunk_size]
        aggregated.append(sum(chunk) / len(chunk))
    return aggregated


def convert_units(values):
    numeric_values = [float(v) for v in values if isinstance(v, (int, float))]
    if len(numeric_values) == 0:
        return values, "Bytes"  # or empty list and default unit

    max_val = max(numeric_values)
    unit = "Bytes"
    converted = numeric_values

    if max_val >= 1024 ** 3:
        unit = "GB"
        converted = [v / (1024 ** 3) for v in numeric_values]
    elif max_val >= 1024 ** 2:
        unit = "MB"
        converted = [v / (1024 ** 2) for v in numeric_values]
    elif max_val >= 1024:
        unit = "KB"
        converted = [v / 1024 for v in numeric_values]

    return converted, unit


def velo_edge_matrics_view(request, edge_id):
    start = int(request.GET.get('start', time.time() * 1000 - 6 * 60 * 60 * 1000))
    end = int(request.GET.get('end', time.time() * 1000))
    target_points = int(request.GET.get('points', 50))

    payload = {
        "edgeId": edge_id,
        "interval": {
            "start": start,
            "end": end
        }
    }

    raw_data = get_edge_links(payload)

    metrics_grouped = {}

    for link_data in raw_data:
        link_name = link_data.get('link', {}).get('displayName') or f"Link {link_data.get('linkId')}"
        for series in link_data.get('series', []):
            metric = series.get('metric')
            start_time = series.get('startTime')
            interval = series.get('tickInterval')
            raw_values = series.get('data', [])

            # Aggregate values
            values = aggregate_points(raw_values, target_points)

            # Convert units
            values, unit = convert_units(values)

            # Calculate timestamps for aggregated points
            timestamps = []
            if len(raw_values) > target_points:
                chunk_size = math.ceil(len(raw_values) / target_points)
                for i in range(0, len(raw_values), chunk_size):
                    timestamps.append(start_time + i * interval * chunk_size)
            else:
                timestamps = [start_time + i * interval for i in range(len(raw_values))]

            # Convert timestamps to ms (assuming start_time is ms, else multiply by 1000)
            timestamps = [int(ts) if ts > 1e12 else int(ts * 1000) for ts in timestamps]

            if metric not in metrics_grouped:
                metrics_grouped[metric] = {
                    "unit": unit,
                    "links": []
                }

            metrics_grouped[metric]["links"].append({
                "linkName": link_name,
                "timestamps": timestamps,
                "values": values
            })

    return JsonResponse({"metrics": metrics_grouped})


def velo_edge_system(request, edge_id):
    now = int(time.time() * 1000)
    end = now
    start = end - (1 * 60 * 60 * 1000)  # last 1 hour by default

    chart_info = [
        ("cpuPct", "CPU Utilization"),
        ("cpuCoreTemp", "CPU Core Temperature (°C)"),
        ("memoryPct", "Memory Utilization"),
        ("flowCount", "Flow Count"),
        ("handoffQueueDrops", "Over Capacity Drops"),
        ("tunnelCount", "Tunnel Count"),
    ]

    context = {
        'edge_id': edge_id,
        'start_time_ms': start,
        'end_time_ms': end,
        'chart_info': chart_info
    }
    return render(request, 'tool_integration/edge_system.html', context)


def velo_edge_system_data(request, edge_id):
    """Return system metrics data for charts with aggregation."""
    try:
        import math

        start = int(request.GET.get('start', time.time() * 1000 - 1 * 60 * 60 * 1000))
        end = int(request.GET.get('end', time.time() * 1000))
        target_points = int(request.GET.get('points', 20))  # desired number of points

        payload = {
            "edgeId": edge_id,
            "interval": {"start": start, "end": end}
        }
        status_data = get_edge_status(payload)  # Call your existing API wrapper

        series = status_data.get("series", [])
        if not series:
            return JsonResponse({"error": "No data returned"}, status=404)

        # Extract timestamps and metric lists
        timestamps = [s["startTime"] for s in series]

        metrics = {
            "cpuPct": {"label": "CPU Utilization (%)", "values": []},
            "cpuCoreTemp": {"label": "CPU Core Temperature (°C)", "values": []},
            "memoryPct": {"label": "Memory Utilization (%)", "values": []},
            "flowCount": {"label": "Flow Count", "values": []},
            "handoffQueueDrops": {"label": "Over Capacity Drops", "values": []},
            "tunnelCount": {"label": "Tunnel Count", "values": []},
        }

        for entry in series:
            for key in metrics.keys():
                metrics[key]["values"].append(entry.get(key, 0))

        # Aggregation logic for all metrics
        if len(timestamps) > target_points:
            chunk_size = math.ceil(len(timestamps) / target_points)
            agg_timestamps = [timestamps[i] for i in range(0, len(timestamps), chunk_size)]
        else:
            agg_timestamps = timestamps

        for key, metric in metrics.items():
            values = metric["values"]
            if len(values) > target_points:
                chunk_size = math.ceil(len(values) / target_points)
                aggregated_values = [
                    sum(values[i:i + chunk_size]) / len(values[i:i + chunk_size])
                    for i in range(0, len(values), chunk_size)
                ]
                metric["values"] = aggregated_values

        return JsonResponse({
            "timestamps": agg_timestamps,
            "metrics": metrics
        })

    except Exception as e:
        return JsonResponse({"error": str(e)}, status=400)