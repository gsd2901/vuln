import os
import requests
import logging

logger = logging.getLogger(__name__)
logging.basicConfig(level=logging.DEBUG)



BASE_URL = os.getenv("VELOCLOUD_BASE_URL")
USERNAME = os.getenv("VELOCLOUD_USERNAME")
PASSWORD = os.getenv("VELOCLOUD_PASSWORD")

session = requests.Session()

def login():
    url = f"{BASE_URL}/login/enterpriseLogin"
    payload = {
        "username": USERNAME,
        "password": PASSWORD
    }
    headers = {
        "Content-Type": "application/x-www-form-urlencoded",
        "User-Agent": "Mozilla/5.0",
        "Referer": BASE_URL
    }

    logger.debug(f"Attempting login with payload: {payload}")
    response = session.post(url, data=payload, headers=headers)

    logger.debug(f"Login response status: {response.status_code}")
    logger.debug(f"Login response headers: {response.headers}")
    logger.debug(f"Login response body: {response.text}")
    logger.debug(f"Session cookies after login: {session.cookies.get_dict()}")

    response.raise_for_status()



def get_edges():
    login()
    url = f"{BASE_URL}/portal/rest/enterprise/getEnterpriseEdges"
    payload = {}
    logger.debug(f"Fetching edges with payload: {payload}")
    response = session.post(url, json=payload)
    logger.debug(f"Edges response status: {response.status_code}")
    logger.debug(f"Edges response body: {response.text}")
    response.raise_for_status()
    return response.json()



def get_edge_links(payload):
    login()
    url = f"{BASE_URL}/portal/rest/metrics/getEdgeLinkSeries"
    logger.debug(f"Fetching QoE for edge with payload: {payload}")
    response = session.post(url, json=payload)
    logger.debug(f"QoE response status: {response.status_code}")
    logger.debug(f"QoE response body: {response.text}")
    response.raise_for_status()
    return response.json()


def get_edge_status(payload):
    login()
    url = f"{BASE_URL}/portal/rest/metrics/getEdgeStatusSeries"
    logger.debug(f"Fetching QoE for edge with payload: {payload}")
    response = session.post(url, json=payload)
    logger.debug(f"QoE response status: {response.status_code}")
    logger.debug(f"QoE response body: {response.text}")
    response.raise_for_status()
    return response.json()




