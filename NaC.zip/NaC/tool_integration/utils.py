import logging
from django.core.exceptions import ObjectDoesNotExist

from .models import ExternalTool, ToolEndpoint
from .connectors.base import get_connector_for_tool

logger = logging.getLogger(__name__)

def get_tool_by_type(tool_type):
    """
    Get an enabled external tool of the specified type.
    
    Args:
        tool_type (str): The type of tool to get (e.g., 'servicenow')
        
    Returns:
        ExternalTool or None: The first enabled tool of the specified type, or None if not found
    """
    try:
        return ExternalTool.objects.filter(tool_type=tool_type, enabled=True).first()
    except Exception as e:
        logger.error(f"Error getting tool by type '{tool_type}': {str(e)}")
        return None

def get_endpoint_url(tool_type, endpoint_name):
    """
    Get the URL for a specific endpoint of a tool type.
    
    Args:
        tool_type (str): The type of tool (e.g., 'servicenow')
        endpoint_name (str): The name of the endpoint (e.g., 'Incidents')
        
    Returns:
        str or None: The endpoint URL, or None if not found
    """
    try:
        tool = get_tool_by_type(tool_type)
        if not tool:
            return None
            
        endpoint = ToolEndpoint.objects.get(tool=tool, name=endpoint_name)
        return endpoint.endpoint_url
    except ObjectDoesNotExist:
        logger.error(f"Endpoint '{endpoint_name}' not found for tool type '{tool_type}'")
        return None
    except Exception as e:
        logger.error(f"Error getting endpoint URL: {str(e)}")
        return None


def get_connector(tool_type):
    """
    Get a connector instance for the specified tool type.
    
    Args:
        tool_type (str): The type of tool to get a connector for
        
    Returns:
        BaseConnector or None: A connector instance, or None if the tool or connector is not found
    """
    tool = get_tool_by_type(tool_type)
    if not tool:
        logger.error(f"No enabled tool found for type '{tool_type}'")
        return None
        
    try:
        return get_connector_for_tool(tool)
    except ValueError as e:
        logger.error(f"Error getting connector: {str(e)}")
        return None
    except Exception as e:
        logger.error(f"Unexpected error getting connector: {str(e)}")
        return None


def make_api_call(tool_type, endpoint_name, method='GET', data=None, params=None, headers=None):
    """
    Make an API call to a specific endpoint of a tool.
    
    Args:
        tool_type (str): The type of tool (e.g., 'servicenow')
        endpoint_name (str): The name of the endpoint (e.g., 'Incidents')
        method (str): HTTP method (GET, POST, etc.)
        data (dict, optional): Data to send in the request body
        params (dict, optional): Query parameters
        headers (dict, optional): Additional headers
        
    Returns:
        dict or None: The response data, or None if the call failed
    """
    connector = get_connector(tool_type)
    if not connector:
        return None
        
    endpoint_url = get_endpoint_url(tool_type, endpoint_name)
    if not endpoint_url:
        return None
        
    # Extract just the path part of the URL
    from urllib.parse import urlparse
    path = urlparse(endpoint_url).path
    
    try:
        return connector.make_request(
            path,
            method=method,
            data=data,
            params=params,
            headers=headers
        )
    except Exception as e:
        logger.error(f"Error making API call to {endpoint_name}: {str(e)}")
        return None


# Example function for ServiceNow integration
def create_servicenow_incident(title, description, urgency='2', impact='2'):
    """
    Create an incident in ServiceNow.
    
    Args:
        title (str): Short description of the incident
        description (str): Detailed description
        urgency (str): Urgency level (1-3)
        impact (str): Impact level (1-3)
        
    Returns:
        dict or None: The created incident data, or None if creation failed
    """
    connector = get_connector('servicenow')
    if not connector:
        return None
        
    return connector.create_incident(
        short_description=title,
        description=description,
        urgency=urgency,
        impact=impact
    )