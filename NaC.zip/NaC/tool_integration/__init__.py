# tool_integration/__init__.py

from nautobot.apps import NautobotAppConfig

__version__ = "1.0.0"

class ToolIntegrationConfig(NautobotAppConfig):
    name = 'tool_integration'
    verbose_name = 'Integration with External Tools'
    description = 'Integration with External Tools like F5, Meraki, ServiceNow, etc.'
    version = '1.0.0'
    author = 'Avinash Sharma'
    author_email = 'avinash_sharma@hcltech.com'
    base_url = 'tool-integration'
    required_settings = []
    default_settings = {
        'script_execution_timeout': 300,
    }
    
    def ready(self):
        """Called when the app is ready."""
        super().ready()
        
        # Direct URL registration for webhooks
        try:
            from django.urls import path
            from nautobot.core.urls import urlpatterns
            from tool_integration.api.views import ServiceNowWebhookView
            from tool_integration.api.views import SolarWindsWebhookView
            
            # Register webhook at the global API level
            urlpatterns.append(
                path('api/plugins/integration-dashboard/webhook/servicenow/', 
                     ServiceNowWebhookView.as_view(), 
                     name='servicenow-direct-webhook')
            )

            urlpatterns.append(
                path('api/plugins/integration-dashboard/webhook/solarwinds/', 
                     SolarWindsWebhookView.as_view(), 
                     name='solarwinds-direct-webhook')
            )
            
            # Log the registration
            import logging
            logger = logging.getLogger(__name__)
            logger.info("Registered ServiceNow and SolarWinds webhook URLs")
            
        except Exception as e:
            import logging
            logger = logging.getLogger(__name__)
            logger.error(f"Failed to register webhook URL: {e}")

        # Import and register F5 jobs (following NAAS pattern)
        try:
            from . import jobs
            
            # Explicitly register F5 jobs with the registry
            from nautobot.extras.registry import registry
            registry["jobs"]["tool_integration.jobs.F5VipSyncSimpleJob"] = jobs.F5VipSyncSimpleJob
            registry["jobs"]["tool_integration.jobs.F5ConnectionTestJob"] = jobs.F5ConnectionTestJob
            
            # Register the jobs in the database if they don't exist yet
            from django.apps import apps
            if apps.is_installed('nautobot.extras'):
                from nautobot.extras.models import Job, JobQueue
                
                try:
                    # Try to get an existing queue first
                    default_queue = JobQueue.objects.first()
                    
                    # If no queue exists, create one
                    if default_queue is None:
                        default_queue = JobQueue.objects.create(
                            name="Default", 
                            description="Default job queue"
                        )
                    
                    # Register F5VipSyncSimpleJob
                    sync_job_class = jobs.F5VipSyncSimpleJob
                    Job.objects.get_or_create(
                        job_class_name='F5VipSyncSimpleJob',
                        module_name='tool_integration.jobs',
                        defaults={
                            'name': sync_job_class.Meta.name,
                            'grouping': 'F5 Integration',
                            'description': sync_job_class.Meta.description,
                            'installed': True,
                            'enabled': True,
                            'has_sensitive_variables': sync_job_class.Meta.has_sensitive_variables,
                            'default_job_queue': default_queue,
                        }
                    )
                    
                    # Register F5ConnectionTestJob
                    test_job_class = jobs.F5ConnectionTestJob
                    Job.objects.get_or_create(
                        job_class_name='F5ConnectionTestJob',
                        module_name='tool_integration.jobs',
                        defaults={
                            'name': test_job_class.Meta.name,
                            'grouping': 'F5 Integration',
                            'description': test_job_class.Meta.description,
                            'installed': True,
                            'enabled': True,
                            'has_sensitive_variables': test_job_class.Meta.has_sensitive_variables,
                            'default_job_queue': default_queue,
                        }
                    )
                    
                    print("Successfully registered all F5 integration jobs")
                    
                except Exception as e:
                    print(f"Error registering F5 job models: {e}")
        except Exception as e:
            print(f"Error loading F5 jobs: {e}")

        # Import connectors to ensure they're registered
        try:
            from . import connectors
        except ImportError:
            pass

config = ToolIntegrationConfig