from nautobot.core.apps import NavMenuTab, NavMenuGroup, NavMenuItem

menu_items = (
    NavMenuTab(
        name="Integrations",
        weight=800,
        groups=(
            NavMenuGroup(
                name="External Tool Integrations",
                weight=100,
                items=(
                    NavMenuItem(
                        link="plugins:tool_integration:externaltool_list",
                        name="Tool Integrations",
                        permissions=["tool_integration.view_externaltool"],
                        weight=100,
                    ),
                    NavMenuItem(
                        link="plugins:tool_integration:toolendpoint_list",
                        name="Tool Endpoints",
                        permissions=["tool_integration.view_toolendpoint"],
                        weight=200,
                    ),
                    NavMenuItem(
                        link="plugins:tool_integration:test_connection",
                        name="Test Connection",
                        permissions=["tool_integration.view_externaltool"],
                        weight=300,
                    ),
                ),
            ),
        ),
    ),
)