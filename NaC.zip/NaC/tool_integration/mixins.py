import requests
import base64
import logging
from .models import ExternalTool

import os
from dotenv import load_dotenv

logger = logging.getLogger(__name__)

class ServiceNowAPIMixin:
    """
    Mixin for ServiceNow API operations that can be used by both views and webhooks
    """
    
    load_dotenv()

    def get_servicenow_tool(self, tool_id=None):
        """
        Get ServiceNow tool instance
        """
        if tool_id:
            try:
                tool = ExternalTool.objects.get(pk=tool_id, tool_type='servicenow')
                return tool
            except ExternalTool.DoesNotExist:
                return None
        else:
            # Get the first ServiceNow tool
            return ExternalTool.objects.filter(tool_type='servicenow').first()
    
    def get_servicenow_auth(self, tool=None):
        """
        Get ServiceNow authentication credentials
        """
        if tool and tool.tool_type == 'servicenow':
            # Use ExternalTool configuration
            instance = tool.base_url.replace('https://', '').replace('http://', '')
            username = tool.username
            password = tool.password
            auth_type = tool.auth_type
        else:
            # Fallback to Django settings
            instance =os.getenv('SERVICENOW_INSTANCE', 'hclpocm1.service-now.com')
            username = os.getenv('SERVICENOW_USERNAME')
            password = os.getenv('SERVICENOW_PASSWORD')
            auth_type = 'basic'
        
        return {
            'instance': instance,
            'username': username,
            'password': password,
            'auth_type': auth_type
        }
    
    def get_servicenow_headers(self, auth_config):
        """
        Get ServiceNow request headers
        """
        headers = {
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        }
        
        if auth_config['auth_type'] == 'basic':
            auth_string = f"{auth_config['username']}:{auth_config['password']}"
            auth_bytes = auth_string.encode('ascii')
            auth_b64 = base64.b64encode(auth_bytes).decode('ascii')
            headers['Authorization'] = f'Basic {auth_b64}'
        
        return headers
    
    def make_servicenow_request(self, endpoint, tool=None, params=None, method='GET'):
        """
        Make a request to ServiceNow API
        """
        try:
            auth_config = self.get_servicenow_auth(tool)
            headers = self.get_servicenow_headers(auth_config)
            
            # Construct full URL
            if endpoint.startswith('http'):
                url = endpoint
            else:
                url = f"https://{auth_config['instance']}/api/now/table/{endpoint}"
            
            logger.info(f"Making ServiceNow API request to: {url}")
            
            # Make the request
            if method.upper() == 'GET':
                response = requests.get(
                    url,
                    headers=headers,
                    params=params or {},
                    timeout=10
                )
            elif method.upper() == 'POST':
                response = requests.post(
                    url,
                    headers=headers,
                    json=params or {},
                    timeout=10
                )
            else:
                raise ValueError(f"Unsupported HTTP method: {method}")
            
            response.raise_for_status()
            return {
                'success': True,
                'data': response.json().get('result', response.json()),
                'status_code': response.status_code
            }
            
        except requests.exceptions.RequestException as e:
            logger.error(f"ServiceNow API error: {e}")
            return {
                'success': False,
                'error': str(e),
                'data': None
            }
        except Exception as e:
            logger.error(f"Unexpected error in ServiceNow request: {e}")
            return {
                'success': False,
                'error': str(e),
                'data': None
            }
    
    def fetch_servicenow_change_request(self, sys_id, tool=None):
        """
        Fetch a specific change request by sys_id
        """
        result = self.make_servicenow_request(
            f"change_request/{sys_id}",
            tool=tool
        )
        
        if result['success'] and result['data']:
            # If result['data'] is a list, get the first item
            cr_data = result['data'][0] if isinstance(result['data'], list) else result['data']
            
            return {
                'description': cr_data.get('description', ''),
                'work_notes': cr_data.get('work_notes', ''),
                'requested_by': cr_data.get('requested_by', {}).get('display_value', 'ServiceNow User'),
                'requester_email': cr_data.get('requested_by', {}).get('email', ''),
                'state': cr_data.get('state', {}).get('display_value', 'New'),
                'priority': cr_data.get('priority', {}).get('display_value', 'Medium'),
                'number': cr_data.get('number', ''),
                'short_description': cr_data.get('short_description', ''),
                'sys_id': cr_data.get('sys_id', sys_id)
            }
        
        return None
    
    def fetch_servicenow_change_requests(self, tool=None, limit=10, filters=None):
        """
        Fetch multiple change requests
        """
        params = {'sysparm_limit': limit}
        if filters:
            params.update(filters)
        
        result = self.make_servicenow_request(
            "change_request",
            tool=tool,
            params=params
        )
        
        if result['success']:
            return result['data']
        
        return []
    
    def fetch_servicenow_incidents(self, tool=None, limit=10, filters=None):
        """
        Fetch incidents from ServiceNow
        """
        params = {'sysparm_limit': limit}
        if filters:
            params.update(filters)
        
        result = self.make_servicenow_request(
            "incident",
            tool=tool,
            params=params
        )
        
        if result['success']:
            return result['data']
        
        return []