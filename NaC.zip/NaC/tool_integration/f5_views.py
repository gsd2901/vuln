from django.contrib import messages
from django.shortcuts import get_object_or_404, redirect, render
from django.views.generic import View

from nautobot.core.views import generic

from .models import ExternalTool
from .connectors.base import get_connector_for_tool


def parse_f5_device_version(device_info):
    """Parse F5 device version from API response in a flexible way."""
    try:
        # F5 API returns nested structure, handle it flexibly
        entries = device_info.get('entries', {})
        
        # Look for version information in any of the nested entries
        for key, value in entries.items():
            if 'nestedStats' in value and 'entries' in value['nestedStats']:
                nested_entries = value['nestedStats']['entries']
                
                # Look for Version key
                if 'Version' in nested_entries:
                    version_info = nested_entries['Version']
                    if 'description' in version_info:
                        return version_info['description']
                
                # Look for Product key as alternative
                if 'Product' in nested_entries:
                    product_info = nested_entries['Product']
                    if 'description' in product_info:
                        return product_info['description']
        
        # Fallback: look for any description field
        for key, value in entries.items():
            if isinstance(value, dict) and 'description' in value:
                return value['description']
                
        return 'Unknown'
        
    except Exception as e:
        return f'Error parsing version: {str(e)}'


def get_f5_statistics(virtual_servers, pools, nodes):
    """Calculate F5 statistics from the data."""
    stats = {
        'total_vips': len(virtual_servers),
        'active_vips': 0,
        'disabled_vips': 0,
        'total_pools': len(pools),
        'active_pools': 0,
        'total_nodes': len(nodes),
        'active_nodes': 0,
        'offline_nodes': 0,
    }
    
    # Count active VIPs
    for vip in virtual_servers:
        if vip.get('enabled', True):
            stats['active_vips'] += 1
        else:
            stats['disabled_vips'] += 1
    
    # Count active pools
    for pool in pools:
        if pool.get('monitor', None) and pool.get('membersReference', {}).get('link', None):
            stats['active_pools'] += 1
    
    # Count node status
    for node in nodes:
        if node.get('session') == 'monitor-enabled':
            stats['active_nodes'] += 1
        elif node.get('session') == 'monitor-disabled':
            stats['offline_nodes'] += 1
    
    return stats


class F5DashboardView(generic.View):
    """View for retrieving and displaying F5 BIG-IP Dashboard information."""
    template_name = 'tool_integration/f5_dashboard.html'
    
    def get(self, request, pk):
        tool = get_object_or_404(ExternalTool, pk=pk)
        
        # Ensure this is an F5 tool
        if tool.tool_type != 'f5':
            messages.error(request, "This tool is not an F5 integration.")
            return redirect('plugins:tool_integration:externaltool_detail', pk=tool.pk)
            
        # Get the connector for this tool
        connector = get_connector_for_tool(tool)
        
        # Initialize default values
        device_info = {}
        virtual_servers = []
        pools = []
        nodes = []
        stats = {}
        connection_status = False
        
        # Get F5 device information
        try:
            # Test connection first
            connection_status = connector.test_connection()
            
            if connection_status:
                device_info = connector.get_device_info()
                virtual_servers = connector.get_virtual_servers()
                pools = connector.get_pools()
                nodes = connector.get_nodes()
                
                # Calculate statistics
                stats = get_f5_statistics(virtual_servers, pools, nodes)
                
                # Add device version to stats
                stats['device_version'] = parse_f5_device_version(device_info)
                stats['hostname'] = tool.base_url
                
                messages.success(request, f"Successfully connected to F5 device at {tool.base_url}")
            else:
                messages.error(request, f"Failed to connect to F5 device at {tool.base_url}")
                
        except Exception as e:
            messages.error(request, f"Error retrieving F5 information: {str(e)}")
            connection_status = False
        
        context = {
            'tool': tool,
            'device_info': device_info,
            'virtual_servers': virtual_servers[:10],  # Show first 10 VIPs
            'pools': pools[:10],  # Show first 10 pools
            'nodes': nodes[:10],  # Show first 10 nodes
            'stats': stats,
            'connection_status': connection_status,
            'total_vips_count': len(virtual_servers),
            'total_pools_count': len(pools),
            'total_nodes_count': len(nodes)
        }
        
        return render(request, self.template_name, context)


class F5VirtualServersView(generic.View):
    """View for retrieving and displaying F5 Virtual Servers (VIPs)."""
    template_name = 'tool_integration/f5_virtual_servers.html'
    
    def get(self, request, pk):
        tool = get_object_or_404(ExternalTool, pk=pk)
        
        # Ensure this is an F5 tool
        if tool.tool_type != 'f5':
            messages.error(request, "This tool is not an F5 integration.")
            return redirect('plugins:tool_integration:externaltool_detail', pk=tool.pk)
            
        # Get the connector for this tool
        connector = get_connector_for_tool(tool)
        
        # Get virtual servers
        try:
            # Test connection first
            if not connector.test_connection():
                messages.error(request, f"Cannot connect to F5 device at {tool.base_url}")
                virtual_servers = []
            else:
                virtual_servers = connector.get_virtual_servers()
                
                if not virtual_servers:
                    messages.warning(request, "No virtual servers found on this F5 device.")
                else:
                    messages.info(request, f"Found {len(virtual_servers)} virtual servers.")
                    
        except Exception as e:
            virtual_servers = []
            messages.error(request, f"Error retrieving virtual servers: {str(e)}")
        
        context = {
            'tool': tool,
            'virtual_servers': virtual_servers
        }
        
        return render(request, self.template_name, context)


class F5VirtualServerDetailView(generic.View):
    """View for retrieving and displaying details of a specific F5 Virtual Server."""
    template_name = 'tool_integration/f5_virtual_server_detail.html'
    
    def get(self, request, pk, vip_name):
        tool = get_object_or_404(ExternalTool, pk=pk)
        
        # Ensure this is an F5 tool
        if tool.tool_type != 'f5':
            messages.error(request, "This tool is not an F5 integration.")
            return redirect('plugins:tool_integration:externaltool_detail', pk=tool.pk)
            
        # Get the connector for this tool
        connector = get_connector_for_tool(tool)
        
        # Get virtual server details
        try:
            virtual_server = connector.get_virtual_server_detail(vip_name)
            
            if not virtual_server:
                messages.error(request, f"Virtual server {vip_name} not found.")
                return redirect('plugins:tool_integration:f5_virtual_servers', pk=tool.pk)
                
            # Get associated pool details if exists
            pool_details = None
            if virtual_server.get('pool'):
                # Remove partition prefix (e.g., /Common/pool_name -> pool_name)
                pool_name = virtual_server['pool'].split('/')[-1]
                pool_details = connector.get_pool_detail(pool_name)
                
        except Exception as e:
            messages.error(request, f"Error retrieving virtual server details: {str(e)}")
            return redirect('plugins:tool_integration:f5_virtual_servers', pk=tool.pk)
        
        context = {
            'tool': tool,
            'virtual_server': virtual_server,
            'pool_details': pool_details,
            'vip_name': vip_name
        }
        
        return render(request, self.template_name, context)


class F5PoolsView(generic.View):
    """View for retrieving and displaying F5 Pools."""
    template_name = 'tool_integration/f5_pools.html'
    
    def get(self, request, pk):
        tool = get_object_or_404(ExternalTool, pk=pk)
        
        # Ensure this is an F5 tool
        if tool.tool_type != 'f5':
            messages.error(request, "This tool is not an F5 integration.")
            return redirect('plugins:tool_integration:externaltool_detail', pk=tool.pk)
            
        # Get the connector for this tool
        connector = get_connector_for_tool(tool)
        
        # Get pools
        try:
            if not connector.test_connection():
                messages.error(request, f"Cannot connect to F5 device at {tool.base_url}")
                pools = []
            else:
                pools = connector.get_pools()
                
                if not pools:
                    messages.warning(request, "No pools found on this F5 device.")
                else:
                    messages.info(request, f"Found {len(pools)} pools.")
                    
        except Exception as e:
            pools = []
            messages.error(request, f"Error retrieving pools: {str(e)}")
        
        context = {
            'tool': tool,
            'pools': pools
        }
        
        return render(request, self.template_name, context)


class F5PoolDetailView(generic.View):
    """View for retrieving and displaying details of a specific F5 Pool."""
    template_name = 'tool_integration/f5_pool_detail.html'
    
    def get(self, request, pk, pool_name):
        tool = get_object_or_404(ExternalTool, pk=pk)
        
        # Ensure this is an F5 tool
        if tool.tool_type != 'f5':
            messages.error(request, "This tool is not an F5 integration.")
            return redirect('plugins:tool_integration:externaltool_detail', pk=tool.pk)
            
        # Get the connector for this tool
        connector = get_connector_for_tool(tool)
        
        # Get pool details
        try:
            pool = connector.get_pool_detail(pool_name)
            
            if not pool:
                messages.error(request, f"Pool {pool_name} not found.")
                return redirect('plugins:tool_integration:f5_pools', pk=tool.pk)
                
            # Get pool members
            pool_members = connector.get_pool_members(pool_name)
                
        except Exception as e:
            messages.error(request, f"Error retrieving pool details: {str(e)}")
            return redirect('plugins:tool_integration:f5_pools', pk=tool.pk)
        
        context = {
            'tool': tool,
            'pool': pool,
            'pool_members': pool_members,
            'pool_name': pool_name
        }
        
        return render(request, self.template_name, context)


class F5NodesView(generic.View):
    """View for retrieving and displaying F5 Nodes."""
    template_name = 'tool_integration/f5_nodes.html'
    
    def get(self, request, pk):
        tool = get_object_or_404(ExternalTool, pk=pk)
        
        # Ensure this is an F5 tool
        if tool.tool_type != 'f5':
            messages.error(request, "This tool is not an F5 integration.")
            return redirect('plugins:tool_integration:externaltool_detail', pk=tool.pk)
            
        # Get the connector for this tool
        connector = get_connector_for_tool(tool)
        
        # Get nodes
        try:
            if not connector.test_connection():
                messages.error(request, f"Cannot connect to F5 device at {tool.base_url}")
                nodes = []
            else:
                nodes = connector.get_nodes()
                
                if not nodes:
                    messages.warning(request, "No nodes found on this F5 device.")
                else:
                    messages.info(request, f"Found {len(nodes)} nodes.")
                    
        except Exception as e:
            nodes = []
            messages.error(request, f"Error retrieving nodes: {str(e)}")
        
        context = {
            'tool': tool,
            'nodes': nodes
        }
        
        return render(request, self.template_name, context)


class F5SyncToNautobotView(generic.View):
    """View for syncing F5 data to Nautobot."""
    template_name = 'tool_integration/f5_sync_result.html'
    
    def post(self, request, pk):
        tool = get_object_or_404(ExternalTool, pk=pk)
        
        # Ensure this is an F5 tool
        if tool.tool_type != 'f5':
            messages.error(request, "This tool is not an F5 integration.")
            return redirect('plugins:tool_integration:externaltool_detail', pk=tool.pk)
        
        try:
            # Import the F5 job classes
            from .jobs import F5SyncJob
            
            # Create job instance
            job = F5SyncJob()
            
            # Run the job
            result = job.run(tool_id=tool.pk, user=request.user)
            messages.success(request, "F5 sync job completed successfully!")
            
            context = {
                'tool': tool,
                'result': result,
                'success': True
            }
            
        except ImportError as e:
            messages.error(request, f"F5 job not found. Please ensure F5 jobs are properly configured: {str(e)}")
            context = {
                'tool': tool,
                'error': f"Job import error: {str(e)}",
                'success': False
            }
            
        except Exception as e:
            messages.error(request, f"F5 sync job failed: {str(e)}")
            
            context = {
                'tool': tool,
                'error': str(e),
                'success': False
            }
        
        return render(request, self.template_name, context)