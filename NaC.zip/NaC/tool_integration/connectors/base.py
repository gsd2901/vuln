import logging
import requests
from abc import ABC, abstractmethod
from urllib.parse import urljoin
from requests.exceptions import RequestException

logger = logging.getLogger(__name__)

class BaseConnector(ABC):
    """Base class for all external tool service connectors."""
    
    def __init__(self, tool):
        """Initialize with an ExternalTool instance."""
        self.tool = tool
        self.base_url = tool.base_url
        self.username = tool.username
        self.password = tool.password
        self.auth_type = tool.auth_type
        self.timeout = 30  # Default timeout in seconds
    
    @abstractmethod
    def test_connection(self):
        """
        Test the connection to the service.
        
        Returns:
            dict: A dictionary containing at least:
                - success (bool): Whether the connection was successful
                - error (str, optional): Error message if connection failed
        """
        pass
    
    @abstractmethod
    def discover_endpoints(self):
        """
        Discover and return available endpoints.
        
        Returns:
            dict: A dictionary mapping endpoint names to dictionaries with:
                - url (str): The full URL for the endpoint
                - description (str, optional): Description of the endpoint
        """
        pass
    
    def get_auth_header(self):
        """Return appropriate auth header based on auth_type."""
        if self.auth_type == 'basic':
            return None  # Will use HTTP Basic Auth
        elif self.auth_type == 'apikey':
            return {'Authorization': f'ApiKey {self.password}'}
        elif self.auth_type == 'oauth':
            # In a real implementation, we would acquire an OAuth token here
            return {'Authorization': f'Bearer {self.password}'}
        
    def make_request(self, endpoint, method='GET', data=None, params=None, headers=None):
        """
        Make an HTTP request to the service.
        
        Args:
            endpoint (str): The endpoint path to request
            method (str): HTTP method (GET, POST, etc.)
            data (dict, optional): Data to send in the request body
            params (dict, optional): Query parameters
            headers (dict, optional): Additional headers
            
        Returns:
            dict or None: The parsed JSON response, or None if the request failed
        """
        url = urljoin(self.base_url, endpoint)
        auth_headers = self.get_auth_header()
        
        # Merge any provided headers with auth headers
        if headers and auth_headers:
            headers.update(auth_headers)
        elif auth_headers:
            headers = auth_headers
        
        auth = None
        if self.auth_type == 'basic':
            auth = (self.username, self.password)
        #import pdb; pdb.set_trace()
        try:
            logger.debug(f"Making {method} request to {url}")
            response = requests.request(
                method,
                url,
                auth=auth,
                headers=headers,
                json=data,
                params=params,
                timeout=self.timeout,
                verify=False,
            )
            response.raise_for_status()
            return response.json()
        except RequestException as e:
            logger.error(f"Request error for {url}: {str(e)}")
            return None


# Dictionary mapping tool_type to connector class
CONNECTOR_CLASSES = {}

def register_connector(tool_type, connector_class):
    """
    Register a connector class for a specific tool type.
    
    Args:
        tool_type (str): The tool_type value to register for
        connector_class (class): The connector class to use for this tool type
    """
    CONNECTOR_CLASSES[tool_type] = connector_class


def get_connector_for_tool(tool):
    """
    Get the appropriate connector instance for an ExternalTool.
    
    Args:
        tool: An ExternalTool instance
        
    Returns:
        BaseConnector: An instance of the appropriate connector class
    """
    connector_class = CONNECTOR_CLASSES.get(tool.tool_type)
    if not connector_class:
        raise ValueError(f"No connector registered for tool type: {tool.tool_type}")
    
    return connector_class(tool)