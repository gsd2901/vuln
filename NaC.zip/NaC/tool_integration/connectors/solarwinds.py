import logging
from urllib.parse import urljoin
from .base import BaseConnector, register_connector

logger = logging.getLogger(__name__)

class SolarWindsConnector(BaseConnector):
    """Connector for SolarWinds."""
    
    def test_connection(self):
        """
        Test connection to SolarWinds instance.
        
        Returns:
            dict: Connection test result with keys:
                - success (bool): Whether the connection was successful
                - error (str, optional): Error message if connection failed
        """
        try:
            # Log the base URL for debugging
            logger.debug(f"SolarWinds base URL: {self.base_url}")
            
            # Try to access a simple SolarWinds query
            response = self.make_request(
                'Query',
                params={'query': 'SELECT TOP 1 NodeID, Caption FROM Orion.Nodes'}
            )
            
            # Log the response for debugging
            logger.debug(f"SolarWinds API response: {response}")
            
            if response is not None:
                return {
                    'success': True,
                    'message': "Successfully connected to SolarWinds API"
                }
            else:
                return {
                    'success': False,
                    'error': "Could not connect to SolarWinds API"
                }
                
        except Exception as e:
            logger.exception("Error testing SolarWinds connection")
            return {
                'success': False,
                'error': str(e)
            }
    
    def discover_endpoints(self):
        """
        Discover SolarWinds endpoints.
        
        Returns:
            dict: A dictionary mapping endpoint names to dictionaries with:
                - url (str): The full URL for the endpoint
                - description (str): Description of the endpoint
        """
        # Return common SolarWinds InformationService endpoints
        base = self.base_url
        return {
            'Query': {
                'url': urljoin(base, 'Query'),
                'description': 'Execute SWQL queries against the SolarWinds database'
            },
            'Invoke': {
                'url': urljoin(base, 'Invoke'),
                'description': 'Invoke SolarWinds verbs'
            },
            'Create': {
                'url': urljoin(base, 'Create'),
                'description': 'Create new objects in SolarWinds'
            },
            'Delete': {
                'url': urljoin(base, 'Delete'),
                'description': 'Delete objects from SolarWinds'
            },
            'Update': {
                'url': urljoin(base, 'Update'),
                'description': 'Update existing objects in SolarWinds'
            }
        }
    
    def get_auth_header(self):
        """
        Override to use the appropriate authentication for SolarWinds Information Service.
        SolarWinds typically uses a token in the header.
        """
        # Check the auth type to determine how to authenticate
        if self.auth_type == 'apikey':
            # For token-based auth
            return {'Authorization': f'Bearer {self.password}'}
        else:
            # Fall back to the default implementation
            return super().get_auth_header()
    
    def query_nodes(self, criteria=None, limit=100):
        """
        Query nodes from SolarWinds with optional filtering criteria.
        
        Args:
            criteria (str, optional): SWQL WHERE clause
            limit (int, optional): Maximum number of results to return
            
        Returns:
            list or None: List of nodes, or None if query failed
        """
        query = f"SELECT TOP {limit} NodeID, Caption, IP_Address, Status, StatusDescription FROM Orion.Nodes"
        
        if criteria:
            query += f" WHERE {criteria}"
            
        response = self.make_request(
            'Query',
            params={'query': query}
        )
        
        if response and 'results' in response:
            return response['results']
        return None
    
    def get_alerts(self, active_only=True, limit=100):
        """
        Get alerts from SolarWinds.
        
        Args:
            active_only (bool): Whether to return only active alerts
            limit (int): Maximum number of results to return
            
        Returns:
            list or None: List of alerts, or None if query failed
        """
        query = f"SELECT TOP {limit} AlertID, AlertName, AlertDescription, Acknowledged, Active FROM Orion.AlertActive"
        
        if active_only:
            query += " WHERE Active = True"
            
        response = self.make_request(
            'Query',
            params={'query': query}
        )
        
        if response and 'results' in response:
            return response['results']
        return None


# Register the SolarWinds connector
register_connector('solarwinds', SolarWindsConnector)