import logging
from urllib.parse import urljoin
from .base import BaseConnector, register_connector

logger = logging.getLogger(__name__)

class ServiceNowConnector(BaseConnector):
    """Connector for ServiceNow."""
    
    def test_connection(self):
        """
        Test connection to ServiceNow instance.
        
        Returns:
            dict: Connection test result with keys:
                - success (bool): Whether the connection was successful
                - error (str, optional): Error message if connection failed
                - version (str, optional): ServiceNow instance version if successful
        """
        try:
            # Try to access the ServiceNow API info endpoint
            response = self.make_request('api/now/table/sys_user?sysparm_limit=1')
            
            if response is not None:
                # Get ServiceNow instance information if available
                instance_info = self.make_request('api/now/ui/ui_properties')
                version = instance_info.get('result', {}).get('version', 'Unknown') if instance_info else 'Unknown'
                
                return {
                    'success': True,
                    'version': version,
                    'message': "Connection successful"
                }
            else:
                return {
                    'success': False,
                    'error': "Could not connect to ServiceNow API"
                }
                
        except Exception as e:
            logger.exception("Error testing ServiceNow connection")
            return {
                'success': False,
                'error': str(e)
            }
    
    def discover_endpoints(self):
        """
        Discover ServiceNow endpoints.
        
        Returns:
            dict: A dictionary mapping endpoint names to dictionaries with:
                - url (str): The full URL for the endpoint
                - description (str): Description of the endpoint
        """
        # Return common ServiceNow endpoints
        base = self.base_url
        return {
            'Incidents': {
                'url': urljoin(base, 'api/now/table/incident'),
                'description': 'Create and manage incidents'
            },
            'Change Requests': {
                'url': urljoin(base, 'api/now/table/change_request'),
                'description': 'Create and manage change requests'
            },
            'Problems': {
                'url': urljoin(base, 'api/now/table/problem'),
                'description': 'Create and manage problems'
            },
            'CMDB Items': {
                'url': urljoin(base, 'api/now/table/cmdb_ci'),
                'description': 'Query and manage CMDB items'
            },
            'Service Catalog': {
                'url': urljoin(base, 'api/now/table/sc_cat_item'),
                'description': 'Access service catalog items'
            },
            'Users': {
                'url': urljoin(base, 'api/now/table/sys_user'),
                'description': 'Query and manage users'
            },
            'Groups': {
                'url': urljoin(base, 'api/now/table/sys_user_group'),
                'description': 'Query and manage user groups'
            },
        }
        
    def get_incident_by_number(self, incident_number):
        """
        Get a specific incident by its number.
        
        Args:
            incident_number (str): The incident number (e.g., 'INC0000001')
            
        Returns:
            dict or None: The incident data, or None if not found
        """
        response = self.make_request(
            'api/now/table/incident',
            params={
                'sysparm_query': f'number={incident_number}',
                'sysparm_limit': 1
            }
        )
        
        if response and response.get('result'):
            return response['result'][0]
        return None
        
    def create_incident(self, short_description, description=None, caller_id=None, 
                       urgency=None, impact=None, category=None):
        """
        Create a new incident in ServiceNow.
        
        Args:
            short_description (str): Short description of the incident
            description (str, optional): Detailed description
            caller_id (str, optional): Caller's sys_id
            urgency (str, optional): Urgency (1-3)
            impact (str, optional): Impact (1-3)
            category (str, optional): Category
            
        Returns:
            dict or None: The created incident data, or None if creation failed
        """
        data = {'short_description': short_description}
        
        if description:
            data['description'] = description
        if caller_id:
            data['caller_id'] = caller_id
        if urgency:
            data['urgency'] = urgency
        if impact:
            data['impact'] = impact
        if category:
            data['category'] = category
            
        response = self.make_request(
            'api/now/table/incident',
            method='POST',
            data=data
        )
        
        if response and response.get('result'):
            return response['result']
        return None


# Register the ServiceNow connector
register_connector('servicenow', ServiceNowConnector)