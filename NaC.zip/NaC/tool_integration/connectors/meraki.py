import logging
from urllib.parse import urljoin
from .base import BaseConnector, register_connector

logger = logging.getLogger(__name__)

class MerakiConnector(BaseConnector):
    """Connector for Cisco Meraki."""
    
    def __init__(self, tool):
        """Initialize with an ExternalTool instance."""
        super().__init__(tool)
        # Set specific headers required for Meraki API
        self.headers = {
            'X-Cisco-Meraki-API-Key': self.password,
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        }
        #import pdb; pdb.set_trace()
    
    def get_auth_header(self):
        """Return Meraki API key header."""
        return self.headers
    
    def make_request(self, endpoint, method='GET', data=None, params=None, headers=None):
        """
        Override to ensure the v1 is properly included in the URL.
        """
        # If the endpoint doesn't start with 'v1/', add it
        if not endpoint.startswith('v1/'):
            endpoint = f'v1/{endpoint}'
        
        # Call the parent's make_request with the modified endpoint
        return super().make_request(endpoint, method, data, params, headers)
    
    def test_connection(self):
        """
        Test connection to Meraki dashboard API.
        
        Returns:
            dict: Connection test result with keys:
                - success (bool): Whether the connection was successful
                - error (str, optional): Error message if connection failed
                - version (str, optional): API version if successful
        """
        
        try:
            logger.debug(f"Using headers: {self.get_auth_header()}")
            # Try to access the Meraki organizations endpoint to verify API access
            response = self.make_request('organizations')
            
            if response is not None:
                return {
                    'success': True,
                    'version': 'v1',  # Meraki API version
                    'message': "Successfully connected to Meraki Dashboard API"
                }
            else:
                return {
                    'success': False,
                    'error': "Could not connect to Meraki API"
                }
                
        except Exception as e:
            logger.exception("Error testing Meraki connection")
            return {
                'success': False,
                'error': str(e)
            }
    
    def discover_endpoints(self):
        """
        Discover Meraki API endpoints.
        
        Returns:
            dict: A dictionary mapping endpoint names to dictionaries with:
                - url (str): The full URL for the endpoint
                - description (str): Description of the endpoint
        """
        # Return common Meraki endpoints
        base = self.base_url
        return {
            'Organizations': {
                'url': urljoin(base, 'organizations'),
                'description': 'List the organizations that the user has privileges on'
            },
            'Networks': {
                'url': urljoin(base, 'organizations/{organizationId}/networks'),
                'description': 'List the networks in an organization'
            },
            'Devices': {
                'url': urljoin(base, 'networks/{networkId}/devices'),
                'description': 'List the devices in a network'
            },
            'Device Status': {
                'url': urljoin(base, 'networks/{networkId}/devices/{serial}/lldp_cdp'),
                'description': 'List LLDP and CDP information for a device'
            },
            'Clients': {
                'url': urljoin(base, 'networks/{networkId}/clients'),
                'description': 'List the clients in a network'
            },
            'Alerts': {
                'url': urljoin(base, 'networks/{networkId}/alerts/settings'),
                'description': 'Return the alert configuration for this network'
            },
            'SSID Settings': {
                'url': urljoin(base, 'networks/{networkId}/wireless/ssids'),
                'description': 'List the SSIDs in a network'
            },
            'VLANs': {
                'url': urljoin(base, 'networks/{networkId}/vlans'),
                'description': 'List the VLANs in a network'
            },
            'Uplink Status': {
                'url': urljoin(base, 'organizations/{organizationId}/uplinks/statuses'),
                'description': 'List the uplink status of every Meraki device in the organization'
            },
        }
        
    def get_organizations(self):
        """
        Get all organizations accessible to the API key.
        
        Returns:
            list or None: List of organizations, or None if the request failed
        """
        return self.make_request('organizations')
        
    def get_networks(self, organization_id):
        """
        Get all networks for an organization.
        
        Args:
            organization_id (str): The organization ID
            
        Returns:
            list or None: List of networks, or None if the request failed
        """
        return self.make_request(f'organizations/{organization_id}/networks')
        
    def get_devices(self, network_id):
        """
        Get all devices in a network.
        
        Args:
            network_id (str): The network ID
            
        Returns:
            list or None: List of devices, or None if the request failed
        """
        return self.make_request(f'networks/{network_id}/devices')
        
    def get_device_status(self, serial):
        """
        Get the status of a specific device.
        
        Args:
            serial (str): The device serial number
            
        Returns:
            dict or None: Device status data, or None if the request failed
        """
        return self.make_request(f'devices/{serial}')
        
    def get_network_clients(self, network_id):
        """
        Get clients for a network.
        
        Args:
            network_id (str): The network ID
            
        Returns:
            list or None: List of clients, or None if the request failed
        """
        return self.make_request(f'networks/{network_id}/clients')
        
    def get_alerts_settings(self, network_id):
        """
        Get alert settings for a network.
        
        Args:
            network_id (str): The network ID
            
        Returns:
            dict or None: Alert settings, or None if the request failed
        """
        return self.make_request(f'networks/{network_id}/alerts/settings')
        
    def get_uplink_statuses(self, organization_id):
        """
        Get the uplink status of all devices in an organization.
        
        Args:
            organization_id (str): The organization ID
            
        Returns:
            list or None: List of uplink statuses, or None if the request failed
        """
        return self.make_request(f'organizations/{organization_id}/uplinks/statuses')


# Register the Meraki connector
register_connector('meraki', MerakiConnector)