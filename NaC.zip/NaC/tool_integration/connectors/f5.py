
import requests
from requests.auth import HTTPBasicAuth
from urllib3.exceptions import InsecureRequestWarning
from typing import Dict, List, Optional
import urllib.parse
from .base import BaseConnector, register_connector


# Disable SSL warnings
requests.packages.urllib3.disable_warnings(category=InsecureRequestWarning)


class F5Connector(BaseConnector):
    """F5 BIG-IP API connector for tool integration."""
    
    def __init__(self, tool):
        """Initialize F5 connector with tool configuration."""
        super().__init__(tool)
        
        # Clean up the base URL - remove trailing slashes and protocols
        base_url = tool.base_url.rstrip('/')
        if base_url.startswith('http://'):
            base_url = base_url.replace('http://', '')
        elif base_url.startswith('https://'):
            base_url = base_url.replace('https://', '')
        
        # Remove any API paths if accidentally included
        if '/mgmt/tm' in base_url:
            base_url = base_url.split('/mgmt/tm')[0]
        if '/xui' in base_url:
            base_url = base_url.split('/xui')[0]
            
        self.host = base_url
        self.auth = HTTPBasicAuth(tool.username, tool.password)
        self.f5_base_url = f"https://{self.host}/mgmt/tm"
        self.timeout = 15  # Increased timeout for F5

    def _make_request(self, endpoint: str) -> Optional[Dict]:
        """Make a request to F5 API with proper error handling."""
        try:
            url = f"{self.f5_base_url}/{endpoint.lstrip('/')}"
            response = requests.get(
                url,
                auth=self.auth,
                verify=False,
                timeout=self.timeout,
                headers={'Content-Type': 'application/json'}
            )
            response.raise_for_status()
            return response.json()
        except requests.exceptions.ConnectTimeout:
            raise Exception(f"Connection timeout to F5 device at {self.host}")
        except requests.exceptions.ConnectionError:
            raise Exception(f"Connection failed to F5 device at {self.host}")
        except requests.exceptions.HTTPError as e:
            if e.response.status_code == 401:
                raise Exception("Authentication failed - check username/password")
            elif e.response.status_code == 403:
                raise Exception("Access forbidden - check user permissions")
            else:
                raise Exception(f"HTTP error {e.response.status_code}: {e.response.text}")
        except Exception as e:
            raise Exception(f"Error connecting to F5: {str(e)}")

    def test_connection(self):
        """Test connection to F5 device."""
        try:
            result = self._make_request("sys/version")
            return {
                'success': result is not None,
                'error': None if result else 'Failed to get system version'
            }
        except Exception as e:
            return {
                'success': False,
                'error': str(e)
            }

    def discover_endpoints(self):
        """Discover and return available F5 endpoints."""
        try:
            # Test connection first
            connection_test = self.test_connection()
            if not connection_test['success']:
                return {}
            
            # Return available F5 API endpoints
            endpoints = {
                'sys_version': {
                    'url': f"{self.f5_base_url}/sys/version",
                    'description': 'System version information'
                },
                'virtual_servers': {
                    'url': f"{self.f5_base_url}/ltm/virtual",
                    'description': 'Virtual servers (VIPs)'
                },
                'pools': {
                    'url': f"{self.f5_base_url}/ltm/pool",
                    'description': 'Load balancer pools'
                },
                'nodes': {
                    'url': f"{self.f5_base_url}/ltm/node",
                    'description': 'Backend nodes'
                },
                'interfaces': {
                    'url': f"{self.f5_base_url}/net/interface",
                    'description': 'Network interfaces'
                },
                'vlans': {
                    'url': f"{self.f5_base_url}/net/vlan",
                    'description': 'VLAN configuration'
                }
            }
            return endpoints
        except Exception:
            return {}

    def get_device_info(self) -> Dict:
        """Get F5 device information."""
        try:
            return self._make_request("sys/version") or {}
        except Exception as e:
            return {'error': str(e)}

    def get_virtual_servers(self) -> List[Dict]:
        """Get all virtual servers from F5."""
        try:
            result = self._make_request("ltm/virtual")
            return result.get('items', []) if result else []
        except Exception:
            return []

    def get_virtual_server_detail(self, vip_name: str) -> Dict:
        """Get detailed information for a specific virtual server."""
        try:
            # URL encode the VIP name to handle special characters
            encoded_name = urllib.parse.quote(vip_name, safe='')
            result = self._make_request(f"ltm/virtual/{encoded_name}")
            return result or {}
        except Exception:
            return {}

    def get_pools(self) -> List[Dict]:
        """Get all pools from F5."""
        try:
            result = self._make_request("ltm/pool")
            return result.get('items', []) if result else []
        except Exception:
            return []

    def get_pool_detail(self, pool_name: str) -> Dict:
        """Get detailed information for a specific pool."""
        try:
            encoded_name = urllib.parse.quote(pool_name, safe='')
            result = self._make_request(f"ltm/pool/{encoded_name}")
            return result or {}
        except Exception:
            return {}

    def get_pool_members(self, pool_name: str) -> List[Dict]:
        """Get members for a specific pool."""
        try:
            encoded_name = urllib.parse.quote(pool_name, safe='')
            result = self._make_request(f"ltm/pool/{encoded_name}/members")
            return result.get('items', []) if result else []
        except Exception:
            return []

    def get_nodes(self) -> List[Dict]:
        """Get all nodes from F5."""
        try:
            result = self._make_request("ltm/node")
            return result.get('items', []) if result else []
        except Exception:
            return []

    def get_interfaces(self) -> List[Dict]:
        """Get network interfaces from F5."""
        try:
            result = self._make_request("net/interface")
            return result.get('items', []) if result else []
        except Exception:
            return []

    def get_vlans(self) -> List[Dict]:
        """Get VLANs from F5."""
        try:
            result = self._make_request("net/vlan")
            return result.get('items', []) if result else []
        except Exception:
            return []

    def get_system_info(self) -> Dict:
        """Get system information."""
        try:
            result = self._make_request("sys/global-settings")
            return result or {}
        except Exception:
            return {}

    def get_device_stats(self) -> Dict:
        """Get device statistics."""
        try:
            result = self._make_request("sys/performance/system")
            return result or {}
        except Exception:
            return {}

    def get_license_info(self) -> Dict:
        """Get license information."""
        try:
            result = self._make_request("sys/license")
            return result or {}
        except Exception:
            return {}

    # Additional helper methods for compatibility
    def get_f5_statistics(self):
        """Get F5 device statistics in a standardized format."""
        try:
            virtual_servers = self.get_virtual_servers()
            pools = self.get_pools()
            nodes = self.get_nodes()
            
            stats = {
                'total_vips': len(virtual_servers),
                'active_vips': len([vip for vip in virtual_servers if vip.get('enabled', True)]),
                'total_pools': len(pools),
                'total_nodes': len(nodes),
                'device_host': self.host
            }
            return stats
        except Exception:
            return {}


# Register the F5 connector
register_connector('f5', F5Connector)