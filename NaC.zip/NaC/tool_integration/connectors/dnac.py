import requests
import urllib3
import time
import logging
from .base import BaseConnector, register_connector

# Set up logger
logger = logging.getLogger(__name__)

# Disable SSL warnings for development
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

class DNACConnector(BaseConnector):
    """
    Connector class for Cisco DNA Center API
    """
    
    def __init__(self, tool):
        """Initialize the connector with the ExternalTool instance"""
        super().__init__(tool)
        self.headers = {
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        }
        self.token = None
    
    def _get_auth_token(self):
        """Get authentication token from DNAC"""
        auth_url = f"{self.base_url}/dna/system/api/v1/auth/token"
        
        try:
            response = requests.post(
                auth_url,
                auth=(self.username, self.password),
                headers=self.headers,
                verify=False  # You may want to make this configurable in production
            )
            response.raise_for_status()
            return response.json()['Token']
        except requests.exceptions.RequestException as e:
            error_message = f"Error authenticating to DNAC: {str(e)}"
            if hasattr(e, 'response') and e.response:
                error_message += f" - {e.response.text}"
            logger.error(error_message)
            raise Exception(error_message)
    
    def make_request(self, endpoint, method='GET', data=None, params=None, headers=None):
        """
        Make a request to the DNAC API with authentication
        
        Args:
            endpoint: API endpoint (should start with /)
            method: HTTP method (GET, POST, etc.)
            data: Request body data
            params: Query parameters
            headers: Additional headers
            
        Returns:
            Response JSON
        """
        # Ensure we have a token
        if not self.token:
            self.token = self._get_auth_token()
            self.headers['X-Auth-Token'] = self.token
        
        # Merge any provided headers with our base headers
        request_headers = self.headers.copy()
        if headers:
            request_headers.update(headers)
        
        try:
            response = super().make_request(
                endpoint,
                method=method,
                data=data,
                params=params,
                headers=request_headers
            )
            
            # If we got None, it might be a 401 (token expired)
            if response is None:
                # Try refreshing the token
                logger.debug("Request failed, trying to refresh token")
                self.token = self._get_auth_token()
                self.headers['X-Auth-Token'] = self.token
                request_headers['X-Auth-Token'] = self.token
                
                # Try the request again
                response = super().make_request(
                    endpoint,
                    method=method,
                    data=data,
                    params=params,
                    headers=request_headers
                )
            
            return response
        except Exception as e:
            logger.error(f"Error making request to {endpoint}: {str(e)}")
            raise Exception(f"Error connecting to DNAC: {str(e)}")
    
    def test_connection(self):
        """
        Test connection to DNAC
        
        Returns:
            dict with success flag and optional error message
        """
        try:
            # Try getting an auth token
            self._get_auth_token()
            return {
                'success': True
            }
        except Exception as e:
            logger.error(f"DNAC connection test failed: {str(e)}")
            return {
                'success': False,
                'error': str(e)
            }
    
    def discover_endpoints(self):
        """
        Discover available endpoints on the DNAC instance
        
        Returns:
            Dictionary of endpoint names and their details
        """
        # Define common endpoints that DNAC supports
        endpoints = {
            'Sites': {
                'url': '/dna/intent/api/v1/site',
                'description': 'Get sites from DNAC'
            },
            'Network Devices': {
                'url': '/dna/intent/api/v1/network-device',
                'description': 'Get network devices from DNAC'
            },
            'Network Health': {
                'url': '/dna/intent/api/v1/network-health',
                'description': 'Get network health information'
            },
            'Client Health': {
                'url': '/dna/intent/api/v1/client-health',
                'description': 'Get client health information'
            },
            'Issues': {
                'url': '/dna/intent/api/v1/issues',
                'description': 'Get network issues from DNAC'
            },
            'Physical Topology': {
                'url': '/dna/intent/api/v1/topology/physical-topology',
                'description': 'Get physical topology information'
            },
            'Site Topology': {
                'url': '/dna/intent/api/v1/topology/site-topology',
                'description': 'Get site topology information'
            }
        }
        
        return endpoints
    
    def get_sites(self):
        """Get all sites from DNAC"""
        endpoint = "/dna/intent/api/v1/site"
        response = self.make_request(endpoint)
        return response.get('response', []) if response else []
    
    def get_network_devices(self, site_id=None):
        """Get network devices from DNAC, optionally filtered by site ID"""
        endpoint = "/dna/intent/api/v1/network-device"
        params = {}
        if site_id:
            params['siteId'] = site_id
        response = self.make_request(endpoint, params=params)
        return response.get('response', []) if response else []
    
    def get_network_health(self):
        """Get network health information from DNAC"""
        endpoint = "/dna/intent/api/v1/network-health"
        params = {
            'timestamp': int(time.time() * 1000)  # Current time in milliseconds
        }
        response = self.make_request(endpoint, params=params)
        return response.get('response', []) if response else []
    
    def get_client_health(self):
        """Get client health information from DNAC"""
        endpoint = "/dna/intent/api/v1/client-health"
        params = {
            'timestamp': int(time.time() * 1000)  # Current time in milliseconds
        }
        response = self.make_request(endpoint, params=params)
        return response.get('response', []) if response else []
    
    def get_issues(self):
        """Get issues from DNAC"""
        endpoint = "/dna/intent/api/v1/issues"
        params = {
            'startTime': int((time.time() - 86400) * 1000),  # 24 hours ago
            'endTime': int(time.time() * 1000)  # Current time
        }
        response = self.make_request(endpoint, params=params)
        return response.get('response', []) if response else []
    
    def get_device_interfaces(self, device_id):
        """Get interfaces for a specific device"""
        endpoint = f"/dna/intent/api/v1/interface/network-device/{device_id}"
        response = self.make_request(endpoint)
        return response.get('response', []) if response else []
    
    def get_physical_topology(self):
        """Get physical topology information"""
        endpoint = "/dna/intent/api/v1/topology/physical-topology"
        response = self.make_request(endpoint)
        return response.get('response', {}) if response else {}
    
    def get_site_topology(self):
        """Get site topology information"""
        endpoint = "/dna/intent/api/v1/topology/site-topology"
        response = self.make_request(endpoint)
        return response.get('response', {}) if response else {}


# Register the DNAC connector
register_connector('dnac', DNACConnector)