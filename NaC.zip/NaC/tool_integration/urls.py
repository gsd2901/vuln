from django.urls import path, include, register_converter
import uuid
from . import views
from .dnac_views import (
    DNACDashboardView,
    DNACSitesView,
    DNACDevicesView,
    DNACDeviceDetailView,
    DNACNetworkHealthView,
    DNACClientHealthView,
    DNACIssuesView,
    DNACTopologyView,
)


from .f5_views import (
    F5DashboardView,
    F5VirtualServersView,
    F5VirtualServerDetailView,
    F5PoolsView,
    F5PoolDetailView,
    F5NodesView,
    F5SyncToNautobotView,
)

from .views import (    
    velo_edge_list_view,
    velo_edge_details,
    velo_edge_matrics_view,
    velo_edge_system,
    velo_edge_system_data
)

class UUIDConverter:
    regex = '[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}'
    
    def to_python(self, value):
        return uuid.UUID(value)
    
    def to_url(self, value):
        return str(value)

register_converter(UUIDConverter, 'uuid')

app_name = 'tool_integration'

urlpatterns = [
    # Include API URLs
    path('api/', include('tool_integration.api.urls')),

    # Dashboard
    path('', views.IntegrationDashboardView.as_view(), name='integration_dashboard'),
    path('setup/<str:tool_type>/', views.IntegrationSetupView.as_view(), name='integration_setup'),

    # External Tool URLs
    path('tools/', views.ExternalToolListView.as_view(), name='externaltool_list'),
    path('tools/add/', views.ExternalToolEditView.as_view(), name='externaltool_add'),
    path('tools/import/', views.ExternalToolBulkImportView.as_view(), name='externaltool_import'),
    path('tools/delete/', views.ExternalToolBulkDeleteView.as_view(), name='externaltool_bulk_delete'),
    path('tools/<uuid:pk>/', views.ExternalToolView.as_view(), name='externaltool_detail'),
    path('tools/<uuid:pk>/edit/', views.ExternalToolEditView.as_view(), name='externaltool_edit'),
    path('tools/<uuid:pk>/delete/', views.ExternalToolDeleteView.as_view(), name='externaltool_delete'),

    # Tool Endpoint URLs
    path('endpoints/', views.ToolEndpointListView.as_view(), name='toolendpoint_list'),
    path('endpoints/add/', views.ToolEndpointEditView.as_view(), name='toolendpoint_add'),
    path('endpoints/import/', views.ToolEndpointBulkImportView.as_view(), name='toolendpoint_import'),
    path('endpoints/delete/', views.ToolEndpointBulkDeleteView.as_view(), name='toolendpoint_bulk_delete'),
    path('endpoints/<uuid:pk>/', views.ToolEndpointView.as_view(), name='toolendpoint_detail'),
    path('endpoints/<uuid:pk>/edit/', views.ToolEndpointEditView.as_view(), name='toolendpoint_edit'),
    path('endpoints/<uuid:pk>/delete/', views.ToolEndpointDeleteView.as_view(), name='toolendpoint_delete'),

    # Test Connection URL
    path('test-connection/', views.TestConnectionView.as_view(), name='test_connection'),
    path('test-connection/<uuid:pk>/', views.TestConnectionView.as_view(), name='test_connection_tool'),

    path('tools/<uuid:pk>/incidents/', views.ServiceNowIncidentsView.as_view(), name='servicenow_incidents'),
    path('tools/<uuid:pk>/changes/', views.ServiceNowChangesView.as_view(), name='servicenow_changes'),

    # Meraki paths
    path('meraki/<uuid:pk>/', views.MerakiDashboardView.as_view(), name='meraki_dashboard'),
    path('meraki/<uuid:pk>/organizations/<str:org_id>/networks/', views.MerakiNetworksView.as_view(), name='meraki_networks'),
    path('meraki/<uuid:pk>/networks/<str:net_id>/devices/', views.MerakiDevicesView.as_view(), name='meraki_devices'),
    path('meraki/<uuid:pk>/devices/<str:serial>/', views.MerakiDeviceDetailView.as_view(), name='meraki_device_detail'),
    path('meraki/<uuid:pk>/organizations/<str:org_id>/uplinks/', views.MerakiUplinkStatusView.as_view(), name='meraki_uplink_status'),

    # DNAC paths
    path('dnac/<uuid:pk>/', DNACDashboardView.as_view(), name='dnac_dashboard'),
    path('dnac/<uuid:pk>/sites/', DNACSitesView.as_view(), name='dnac_sites'),
    path('dnac/<uuid:pk>/devices/', DNACDevicesView.as_view(), name='dnac_devices'),
    path('dnac/<uuid:pk>/devices/<str:site_id>/', DNACDevicesView.as_view(), name='dnac_site_devices'),
    path('dnac/<uuid:pk>/device/<str:device_id>/', DNACDeviceDetailView.as_view(), name='dnac_device_detail'),
    path('dnac/<uuid:pk>/network-health/', DNACNetworkHealthView.as_view(), name='dnac_network_health'),
    path('dnac/<uuid:pk>/client-health/', DNACClientHealthView.as_view(), name='dnac_client_health'),
    path('dnac/<uuid:pk>/issues/', DNACIssuesView.as_view(), name='dnac_issues'),
    path('dnac/<uuid:pk>/topology/<str:topology_type>/', DNACTopologyView.as_view(), name='dnac_topology'),

    # F5 Integration URLs
    path('f5/<uuid:pk>/dashboard/', F5DashboardView.as_view(), name='f5_dashboard'),
    path('f5/<uuid:pk>/virtual-servers/', F5VirtualServersView.as_view(), name='f5_virtual_servers'),
    path('f5/<uuid:pk>/virtual-server/<str:vip_name>/', F5VirtualServerDetailView.as_view(), name='f5_virtual_server_detail'),
    path('f5/<uuid:pk>/pools/', F5PoolsView.as_view(), name='f5_pools'),
    path('f5/<uuid:pk>/pool/<str:pool_name>/', F5PoolDetailView.as_view(), name='f5_pool_detail'),
    path('f5/<uuid:pk>/nodes/', F5NodesView.as_view(), name='f5_nodes'),
    path('f5/<uuid:pk>/sync-to-nautobot/', F5SyncToNautobotView.as_view(), name='f5_sync_to_nautobot'),

    # Velo Cloud Dashboard
    path("velo/edges/", velo_edge_list_view, name="velo_edge_list"),    
    path('velo/edges/<int:edge_id>/details/', velo_edge_details, name='velo_edge_details'),
    path('velo/edges/<int:edge_id>/metrics/', velo_edge_matrics_view, name='velo_edge_matrics_view'),
    path('velo/edges/<int:edge_id>/system/', velo_edge_system, name='velo_edge_system'),
    path('velo/edges/<int:edge_id>/system-data/', velo_edge_system_data, name='velo_edge_system_data'),
]