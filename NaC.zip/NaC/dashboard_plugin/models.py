from django.db import models

# CIO/CTO Dashboard permission
class CIODashboard(models.Model):
    """Permission model for CIO/CTO dashboard access"""
    class Meta:
        managed = False
        default_permissions = ('view',)
        verbose_name = "CIO/CTO Dashboard"
        verbose_name_plural = "CIO/CTO Dashboard"

# SOT View permission
class SOTView(models.Model):
    """Permission model for SOT View access"""
    class Meta:
        managed = False
        default_permissions = ('view',)
        verbose_name = "SOT View"
        verbose_name_plural = "SOT View"

# Workflow permission
class Workflow(models.Model):
    """Permission model for Workflow access"""
    class Meta:
        managed = False
        default_permissions = ('view',)
        verbose_name = "Workflow"
        verbose_name_plural = "Workflow"

# Network Catalog permission
class NetworkCatalog(models.Model):
    """Permission model for Network Catalog access"""
    class Meta:
        managed = False
        default_permissions = ('view',)
        verbose_name = "Network Catalog"
        verbose_name_plural = "Network Catalog"

# Digital Twin permission
class DigitalTwin(models.Model):
    """Permission model for Digital Twin access"""
    class Meta:
        managed = False
        default_permissions = ('view',)
        verbose_name = "Digital Twin"
        verbose_name_plural = "Digital Twin"

# GenAI permission
class GenAI(models.Model):
    """Permission model for GenAI access"""
    class Meta:
        managed = False
        default_permissions = ('view',)
        verbose_name = "GenAI"
        verbose_name_plural = "GenAI"

# Integration permission
class Integration(models.Model):
    """Permission model for Integration access"""
    class Meta:
        managed = False
        default_permissions = ('view',)
        verbose_name = "Integration"
        verbose_name_plural = "Integration"

# Network Health Dashboard permission
class NetworkHealthDashboard(models.Model):
    """Permission model for Network Health Dashboard access"""
    class Meta:
        managed = False
        default_permissions = ('view',)
        verbose_name = "Network Health Dashboard"
        verbose_name_plural = "Network Health Dashboard"

# Admin permission
class AdminAccess(models.Model):
    """Permission model for Admin access"""
    class Meta:
        managed = False
        default_permissions = ('view',)
        verbose_name = "Admin Section"
        verbose_name_plural = "Admin Section"