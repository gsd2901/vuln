"""
probe_one.py
-------------
Probes ALL possible sub-resource slugs against one known real UUID
to find what Nautobot actually supports.
Tries both the exact slug and common variations.
"""
import os
import requests
from dotenv import load_dotenv

load_dotenv()

NAUTOBOT_URL = os.getenv("NAUTOBOT_URL", "http://localhost:8100")
TOKEN = os.getenv("NAUTOBOT_TOKEN", "your-token-here")

HEADERS = {"Authorization": f"Token {TOKEN}"}

# Test against prefix — we know it has ip-addresses underneath
APP = "ipam"
PARENT = "prefixes"
REAL_UUID = "d4ac0c91-d8b1-40ab-8d90-d5514e309093"  # 10.156.1.0/24 from earlier logs

# Broad list of slug variations to try
SLUGS = [
    "ip-addresses", "ip_addresses", "ipaddresses",
    "prefixes", "child-prefixes", "available-ips", "available-prefixes",
    "interfaces", "devices", "vlans", "vrfs",
    "locations", "racks", "circuits", "cables",
    "tags", "notes", "members", "terminations",
    "napalm", "render-config", "config-context",
    "units", "elevation", "paths",
    "available_ips", "available_prefixes",
    "child_prefixes",
]

print(f"Probing /api/{APP}/{PARENT}/{REAL_UUID}/<slug>/\n")
for slug in SLUGS:
    url = f"{NAUTOBOT_URL}/api/{APP}/{PARENT}/{REAL_UUID}/{slug}/"
    resp = requests.get(url, headers=HEADERS, timeout=10, proxies={"http": "", "https": ""})
    marker = "✅" if resp.status_code == 200 else ("⚠️ " if resp.status_code == 400 else "❌")
    print(f"  {marker} [{resp.status_code}] {slug}")