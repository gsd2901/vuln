import bleach

import smtplib
import logging
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from django.template import loader
from naas import constants

logger = logging.getLogger(__name__)

def sanitize_html(input_text, tags=None, attrs=None):
    """
    Sanitize HTML input using bleach.

    Args:
        input_text (str): Raw HTML input.
        tags (list): Allowed HTML tags.
        attrs (dict): Allowed HTML attributes.

    Returns:
        str: Cleaned/sanitized HTML.
    """
    allowed_tags = tags or ['p', 'b', 'i', 'u']
    allowed_attrs = attrs or {}

    return bleach.clean(input_text, tags=allowed_tags, attributes=allowed_attrs, strip=True)


def sanitize_csv_value(value):
    
    if isinstance(value, str):
        # Prevent CSV injection by prefixing dangerous characters with a single quote
        if value.startswith(('=', '+', '-', '@')):
            value = "'" + value
        # Remove any unwanted characters if needed
        value = value.strip()
    return value

def send_email(to_email: str, subject: str, template_name: str, context: dict, action_name:str) -> bool:
    """
    Send an HTML email using a Django template.

    Args:
        to_email (str): Recipient's email address.
        subject (str): Email subject.
        template_name (str): Django template path for the email body.
        context (dict): Template context dictionary.

    Returns:
        bool: True if sent successfully, False otherwise.
    """

    try:
        # Render the HTML template
        html_message = loader.render_to_string(template_name, context)

        # Construct email
        msg = MIMEMultipart("alternative")
        msg["From"] = constants.sender_email
        msg["To"] = to_email
        msg["Subject"] = subject
        msg.attach(MIMEText(html_message, "html"))

        # Connect and send
        server = smtplib.SMTP(constants.smtp_lib_server, constants.smtp_port)
        server.starttls()
        server.login(constants.sender_email, constants.sender_password)
        server.sendmail(constants.sender_email, [to_email], msg.as_string())
        server.quit()

        logger.info(f"{action_name} Email sent to {to_email}")
        return True

    except Exception as e:
        logger.error(f"{action_name} Failed to send email to {to_email}: {e}")
        return False