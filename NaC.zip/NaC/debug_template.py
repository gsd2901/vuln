#!/usr/bin/env python3
import os
import sys
from jinja2 import Environment, FileSystemLoader

# Add Django setup if needed
sys.path.append('/home/ubuntu/nautobot-dev/nautobot')
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'nautobot.settings')

def test_github_integration_template():
    """Test the exact same code path as GitHubIntegration.render_terraform_tfvars"""
    
    # Find the github_integration.py file to get the correct path
    github_integration_path = None
    for root, dirs, files in os.walk('/home/ubuntu/nautobot-dev/nautobot/'):
        if 'github_integration.py' in files:
            github_integration_path = root
            break
    
    if not github_integration_path:
        print("ERROR: github_integration.py not found!")
        return
    
    print(f"Found github_integration.py in: {github_integration_path}")
    
    # Use the same path logic as your GitHubIntegration class
    template_dir = os.path.join(github_integration_path, 'templates', 'terraform')
    print(f"Template directory: {template_dir}")
    print(f"Template directory exists: {os.path.exists(template_dir)}")
    
    if not os.path.exists(template_dir):
        print("ERROR: Template directory does not exist!")
        return
    
    # List files in template directory
    print(f"Files in template directory: {os.listdir(template_dir)}")
    
    # Check if terraform.tfvars.j2 exists
    template_file = os.path.join(template_dir, 'terraform.tfvars.j2')
    print(f"Template file: {template_file}")
    print(f"Template file exists: {os.path.exists(template_file)}")
    
    if not os.path.exists(template_file):
        print("ERROR: terraform.tfvars.j2 does not exist!")
        return
    
    # Read and display template content
    print("\n" + "="*50)
    print("Template content:")
    print("="*50)
    with open(template_file, 'r') as f:
        template_content = f.read()
        print(template_content)
    print("="*50)
    
    try:
        # Setup Jinja2 environment (same as GitHubIntegration)
        jinja_env = Environment(loader=FileSystemLoader(template_dir))
        
        # Create mock VPC request object with all required attributes
        class MockVPCRequest:
            def __init__(self):
                self.vpc_name = 'test-vpc'
                self.aws_region = 'us-east-1'
                self.vpc_cidr = '10.0.0.0/16'
                self.public_subnets = ['10.0.1.0/24', '10.0.2.0/24']
                self.private_subnets = ['10.0.3.0/24', '10.0.4.0/24']
                self.enable_nat_gateway = True
                self.enable_vpn_gateway = False
                self.enable_dns_hostnames = True
                self.enable_dns_support = True
                self.custom_tags = {'Environment': 'dev', 'Project': 'test'}
                self.request_id = '12345'
                
                # Mock template object
                class MockTemplate:
                    def __init__(self):
                        self.template_type = 'standard'
                        self.name = 'Standard VPC Template'
                
                self.template = MockTemplate()
        
        vpc_request = MockVPCRequest()
        
        # Prepare template context (same as GitHubIntegration)
        context = {
            'vpc_name': vpc_request.vpc_name,
            'aws_region': vpc_request.aws_region,
            'vpc_cidr': vpc_request.vpc_cidr,
            'public_subnets': vpc_request.public_subnets or [],
            'private_subnets': vpc_request.private_subnets or [],
            'enable_nat_gateway': vpc_request.enable_nat_gateway,
            'enable_vpn_gateway': vpc_request.enable_vpn_gateway,
            'enable_dns_hostnames': vpc_request.enable_dns_hostnames,
            'enable_dns_support': vpc_request.enable_dns_support,
            'tags': {
                'Name': vpc_request.vpc_name,
                'Environment': vpc_request.custom_tags.get('Environment', 'dev') if vpc_request.custom_tags else 'dev',
                'Terraform': 'true',
                'ManagedBy': 'nautobot',
                'RequestID': str(vpc_request.request_id),
                'Template': vpc_request.template.template_type,
                **(vpc_request.custom_tags or {})
            }
        }
        
        print(f"\nTemplate context: {context}")
        
        # Try to load and render the template
        template = jinja_env.get_template('terraform.tfvars.j2')
        rendered_content = template.render(context)
        
        print("\n" + "="*50)
        print("SUCCESS: Template rendered successfully!")
        print("="*50)
        print("Rendered content:")
        print("-" * 50)
        print(rendered_content)
        print("-" * 50)
        
        return True
        
    except Exception as e:
        print(f"\nERROR: Failed to render template: {e}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == "__main__":
    test_github_integration_template()