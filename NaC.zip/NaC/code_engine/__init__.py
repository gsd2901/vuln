# code_engine/__init__.py
"""App declaration for Code Engine."""

from nautobot.apps import NautobotAppConfig

__version__ = "1.0.0"

class CodeEngineConfig(NautobotAppConfig):
    name = "code_engine"
    verbose_name = "Code Engine"
    description = "To Generate the flow builder."
    author = "Akash Sharma"
    author_email = "sharma-akash@hcltech.com"
    base_url = "code-engine"
    required_settings = []
    default_settings = {}
    min_version = "1.0.0"
    max_version = "3.0.0"
    caching_config = {}

config = CodeEngineConfig