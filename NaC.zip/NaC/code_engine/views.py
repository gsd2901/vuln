import os
import json
import shutil
import subprocess
import traceback
from pathlib import Path

from django.shortcuts import render, redirect, get_object_or_404
from django.http import JsonResponse, HttpResponseBadRequest
from django.conf import settings
from django.views.decorators.csrf import csrf_exempt
from django.urls import reverse
from django.apps import apps
from django.views.decorators.http import require_http_methods
from django.core.serializers.json import DjangoJSONEncoder
import textwrap

from .models import Flow, CommonFunction

# Base scripts folder
SCRIPTS_DIR = os.path.join(settings.BASE_DIR, "scripts_storage", "flows")
COMMON_FUNCTIONS_DIR = os.path.join(settings.BASE_DIR,"scripts_storage", "common_functions")
os.makedirs(SCRIPTS_DIR, exist_ok=True)


def _flow_folder_name(flow_name: str) -> str:
    # make folder-safe name
    safe = "".join(c for c in flow_name if c.isalnum() or c in ("-", "_")).strip()
    return safe or "flow"


def _flow_dir(flow_name: str) -> str:
    return os.path.join(SCRIPTS_DIR, _flow_folder_name(flow_name))


def list_flows(request):
    flows = Flow.objects.all().order_by('-updated_at')
    flows_data = []
    for f in flows:
        folder_exists = bool(f.folder and os.path.exists(f.folder))
        main_exists = os.path.exists(os.path.join(f.folder, "main.py")) if folder_exists else False
        flows_data.append({
            "name": f.name,
            "folder": f.folder,
            "updated_at": f.updated_at,
            "has_files": folder_exists,
            "has_main": main_exists,
        })
    functions = CommonFunction.objects.all().order_by('-updated_at')
    return render(request, 'code_engine/list_flows.html', {'flows': flows_data, 'functions': functions})


def create_flow(request):
    # Render canvas/editor page for new flow
    # The frontend will POST JSON to save_flow_api
    return render(request, "code_engine/create_flow.html", {"edit": False, "canvas_json": "null"})


def edit_flow(request, flow_name):
    # Load flow from DB and pass JSON to frontend so it can pre-populate canvas
    f = get_object_or_404(Flow, name=flow_name)
    canvas_json = f.json_data or None
    return render(request, "code_engine/create_flow.html", {
        "is_edit": True,
        "canvas_json": json.dumps(canvas_json) if canvas_json is not None else "null",
        "flow_name": flow_name
    })

@csrf_exempt
def get_flow_json(request, flow_name):
    """
    Fetch flow JSON by name for editing.
    Automatically injects latest CommonFunction code for referenced nodes.
    """
    import json
    from django.http import JsonResponse
    from code_engine.models import Flow, CommonFunction

    try:
        # ✅ Fetch the flow
        flow = Flow.objects.get(name=flow_name)
        flow_data = flow.json_data or {}

        # ✅ Inject latest code from CommonFunction table
        if "nodes" in flow_data:
            for node in flow_data.get("nodes", []):
                data = node.get("data", {})
                name = data.get("name","")
                common_id = data.get("common_id")
                include_in_common = data.get("include_in_common", False)

                # --- Case 1: Common function by ID ---
                if common_id:
                    try:
                        cf_obj = CommonFunction.objects.get(id=common_id)
                        data["code"] = cf_obj.code or ""
                        node["name"] = name
                    except CommonFunction.DoesNotExist:
                        data["code"] = f"# ⚠️ Common Function not found (id={common_id})"

                # --- Case 2: Common function by name (include_in_common) ---
                elif include_in_common and data.get("name"):
                    try:
                        cf_obj = CommonFunction.objects.get(name=data["name"])
                        data["code"] = cf_obj.code or ""
                        data["common_id"] = cf_obj.id
                    except CommonFunction.DoesNotExist:
                        data["code"] = f"# ⚠️ Common Function '{data.get('name')}' not found"

                node["data"] = data

        return JsonResponse({
            "status": "success",
            "data": flow_data
        })

    except Flow.DoesNotExist:
        return JsonResponse({
            "status": "error",
            "message": f"Flow '{flow_name}' not found"
        }, status=404)

    except Exception as e:
        import traceback
        traceback.print_exc()
        return JsonResponse({
            "status": "error",
            "message": str(e)
        }, status=500)


def _sanitize_fname(name: str) -> str:
    # keep alnum, underscore, hyphen
    return "".join(c for c in name if c.isalnum() or c in ("_", "-")).strip() or "fn"


from django.views.decorators.http import require_http_methods

@require_http_methods(["GET"])
def get_common_functions_api(request):
    """
    Returns a list of common functions for sidebar usage.
    """
    commons = CommonFunction.objects.all().order_by('-updated_at')[:200]
    out = []
    for c in commons:
        out.append({
            "id": c.id,
            "name": c.name,
            "code": c.code,
            "updated_at": c.updated_at.isoformat()
        })
    return JsonResponse({"common": out})

@csrf_exempt
def save_flow_apix(request):
    """
    Save flow JSON to DB and generate runnable Python files.
    Supports node types: start, function, conditional, model.
    Each node can include metadata for inputs/outputs or filters.
    """
    import os, json, re, ast, shutil, sys, textwrap, datetime, subprocess, importlib
    from django.http import JsonResponse
    from django.conf import settings
    from code_engine.models import Flow, CommonFunction

    SAFE_BUILTINS = {
        "sys", "os", "json", "re", "datetime", "math", "logging",
        "pathlib", "textwrap", "typing", "collections", "itertools",
        "functools", "time", "inspect", "base64"
    }
    BLOCKED_LIBS = {
        "subprocess", "shutil", "ctypes", "mmap", "socket", "telnetlib",
        "pickle", "marshal", "signal", "crypt"
    }

    def extract_imports_from_code(code_str):
        libs = set()
        try:
            tree = ast.parse(code_str)
        except Exception:
            return libs
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    libs.add(alias.name.split(".")[0])
            elif isinstance(node, ast.ImportFrom) and node.module:
                libs.add(node.module.split(".")[0])
        return libs

    def ensure_safe_install(libs_set):
        result = {"installed": [], "blocked": [], "failed": [], "already_present": []}
        for lib in sorted(libs_set):
            if not lib or lib in SAFE_BUILTINS:
                result["already_present"].append(lib)
                continue
            if lib in BLOCKED_LIBS:
                result["blocked"].append(lib)
                continue
            try:
                importlib.import_module(lib)
                result["already_present"].append(lib)
            except ImportError:
                print(f"📦 Installing missing library: {lib}")
                proc = subprocess.run([sys.executable, "-m", "pip", "install", lib],
                                      stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
                if proc.returncode == 0:
                    result["installed"].append(lib)
                else:
                    result["failed"].append({"lib": lib, "stderr": proc.stderr})
        return result

    def safe_ident(name):
        return re.sub(r"\W+", "_", (name or "unnamed")).strip("_")

    try:
        payload = json.loads(request.body.decode())
        flow_name = payload.get("flow_name")
        nodes = payload.get("nodes", [])
        connections = payload.get("connections", [])
        parameters = payload.get("parameters", {})

        if not flow_name:
            return JsonResponse({"status": "error", "message": "flow_name is required"}, status=400)

        base_path = os.path.join(settings.BASE_DIR, "scripts_storage")
        flow_dir = os.path.join(base_path, "flows", flow_name)
        common_dir = os.path.join(base_path, "common_functions")
        os.makedirs(flow_dir, exist_ok=True)
        os.makedirs(common_dir, exist_ok=True)

        flow_obj, _ = Flow.objects.get_or_create(name=flow_name)
        flow_obj.folder = flow_dir

        if os.path.exists(flow_dir):
            shutil.rmtree(flow_dir, ignore_errors=True)
            os.makedirs(flow_dir, exist_ok=True)

        node_calls, node_types, outgoing, conditional_links = {}, {}, {}, {}
        collected_code = []

        # --- Build node files ---
        for node in nodes:
            nid = str(node["id"])
            ntype = node["type"]
            data = node.get("data", {})
            name = data.get("name", f"node_{nid}")
            code = data.get("code", "")
            include_in_common = data.get("include_in_common", False)
            common_id = data.get("common_id")
            cond = data.get("cond", "True")

            node_types[nid] = ntype
            if code:
                collected_code.append(code)

            # START Node
            if ntype == "start":
                path = os.path.join(flow_dir, f"f{nid.zfill(2)}_start.py")
                params = data.get("params", [])
                node_calls[nid] = {"type": "local", "module": f"f{nid.zfill(2)}_start", "func": "start"}

                with open(path, "w", encoding="utf-8") as f:
                    f.write("import datetime\n")
                    f.write("def start(context):\n")
                    for p in params:
                        pname = p.get("name")
                        if pname:
                            f.write(f"    context.setdefault('{pname}', None)\n")
                    f.write("    print('[START]', datetime.datetime.now(), context)\n")
                    f.write("    return context\n")

            # FUNCTION Node
            elif ntype == "function":
                module_name = safe_ident(name)
                if common_id:
                    try:
                        cf_obj = CommonFunction.objects.get(id=common_id)
                        cf_name = safe_ident(cf_obj.name)
                        cf_path = os.path.join(common_dir, f"{cf_name}.py")
                        func_name = cf_obj.name
                        node_calls[nid] = {"type": "common", "module": cf_name, "func": func_name}
                        continue
                    except CommonFunction.DoesNotExist:
                        pass
                entry_func = re.search(r"def\s+([A-Za-z_][A-Za-z0-9_]*)\s*\(", code)
                entry_func = entry_func.group(1) if entry_func else module_name
                path = os.path.join(flow_dir, f"f{nid.zfill(2)}_{module_name}.py")

                with open(path, "w", encoding="utf-8") as f:
                    f.write("import datetime\n")
                    f.write(code.strip() + "\n\n")
                    f.write(f"def {module_name}_system(context):\n")
                    f.write(f"    print(f'[FUNC {nid}] {name} at', datetime.datetime.now())\n")
                    f.write(f"    return {entry_func}(context)\n")

                node_calls[nid] = {"type": "local", "module": f"f{nid.zfill(2)}_{module_name}", "func": f"{module_name}_system"}

            # CONDITIONAL Node
            elif ntype == "conditional":
                path = os.path.join(flow_dir, f"f{nid.zfill(2)}_conditional.py")
                with open(path, "w", encoding="utf-8") as f:
                    f.write("import datetime\n")
                    f.write("def conditional_system(context):\n")
                    f.write(f"    print('[COND]', datetime.datetime.now())\n")
                    f.write(f"    try:\n        result = bool({cond})\n    except Exception:\n        result = False\n")
                    f.write("    return {'__conditional_result__': result, 'context': context}\n")
                node_calls[nid] = {"type": "conditional", "module": f"f{nid.zfill(2)}_conditional", "func": "conditional_system"}
                conditional_links[nid] = {"true": [], "false": [], "default": []}

            # MODEL Node (new)
            elif ntype == "model":
                model_path = data.get("model")  # e.g., dcim.Device
                output_var = data.get("output_var", "results")
                filters = data.get("filters", {})

                if not model_path:
                    continue

                try:
                    app_label, model_name = model_path.split(".")
                except ValueError:
                    continue

                path = os.path.join(flow_dir, f"f{nid.zfill(2)}_model_{model_name}.py")
                with open(path, "w", encoding="utf-8") as f:
                    f.write(f"from nautobot.{app_label}.models import {model_name}\n\n")
                    f.write(f"def model_{model_name}(context):\n")
                    f.write(f"    filters = {json.dumps(filters, indent=4)}\n")
                    f.write("    for k,v in list(filters.items()):\n")
                    f.write("        if isinstance(v, str) and v.startswith('{{') and v.endswith('}}'):\n")
                    f.write("            key = v.strip('{} ').split('.')[-1]\n")
                    f.write("            filters[k] = context.get(key)\n")
                    f.write(f"    queryset = {model_name}.objects.filter(**filters)\n")
                    f.write(f"    context['{output_var}'] = list(queryset.values())\n")
                    f.write("    return context\n")

                node_calls[nid] = {"type": "model", "module": f"f{nid.zfill(2)}_model_{model_name}", "func": f"model_{model_name}"}

        # --- Connections ---
        for conn in connections:
            src, tgt = str(conn.get("from")), str(conn.get("to"))
            outgoing.setdefault(src, []).append(tgt)

        # --- Save flow JSON ---
        flow_obj.json_data = {
            "nodes": nodes,
            "connections": connections,
            "parameters": parameters,
            "conditional_links": conditional_links,
        }
        flow_obj.save()

        # --- Dependency detection ---
        discovered_libs = set()
        for snippet in collected_code:
            discovered_libs.update(extract_imports_from_code(snippet))
        install_report = ensure_safe_install(discovered_libs)

        with open(os.path.join(flow_dir, "requirements.txt"), "w", encoding="utf-8") as rf:
            rf.write("\n".join(sorted(install_report.get("installed", []) + install_report.get("already_present", []))))

        # --- Generate main.py ---
        main_path = os.path.join(flow_dir, "main.py")
        with open(main_path, "w", encoding="utf-8") as f:
            f.write("# Auto-generated main runner\n")
            f.write("import os, sys, json, traceback, datetime\n")
            f.write("BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..'))\n")
            f.write("FLOW_DIR = os.path.abspath(os.path.dirname(__file__))\n")
            f.write("sys.path.extend([BASE_DIR, FLOW_DIR, os.path.join(BASE_DIR, 'common_functions')])\n\n")

            for nid, info in node_calls.items():
                f.write(f"from {info['module']} import {info['func']}\n")

            f.write("\nNODE_CALLS = " + json.dumps(node_calls, indent=4) + "\n")
            f.write("NODE_TYPES = " + json.dumps(node_types, indent=4) + "\n")
            f.write("OUTGOING = " + json.dumps(outgoing, indent=4) + "\n\n")

            f.write(textwrap.dedent('''\
        def run_flow(input_data=None, debug=False):
            results, executed = {}, set()
            context = input_data or {}
            print("=== Flow Execution Started ===")

            def traverse(nid):
                nonlocal context
                if not nid or str(nid) in executed:
                    return
                executed.add(str(nid))
                node = NODE_CALLS.get(str(nid))
                fn = globals().get(node["func"])
                if not fn:
                    raise Exception(f"Missing function for node {nid}")
                print(f"[NODE {nid}] Executing {node['func']} ...")
                if node["type"] == "conditional":
                    result = fn(context)
                    flag = result.get("__conditional_result__", False)
                    context = result.get("context", context)
                    results[str(nid)] = {"type": "conditional", "result": flag}
                    targets = OUTGOING.get(str(nid), [])
                    if flag and len(targets) > 0:
                        traverse(targets[0])
                    elif not flag and len(targets) > 1:
                        traverse(targets[1])
                else:
                    context = fn(context)
                    results[str(nid)] = {"type": node["type"], "result": context}
                    for nxt in OUTGOING.get(str(nid), []):
                        traverse(nxt)

            try:
                for s, t in NODE_TYPES.items():
                    if t == "start":
                        traverse(s)
                print("=== Flow Complete ===")
                returnData = {
                    "status": "success",
                    "message": "Flow executed successfully",
                    "results": context.get('response', context),
                    "error": None,
                }
                if(debug):
                    returnData['node_results'] = results
                return returnData
            except Exception as e:
                print("❌ Flow execution failed:", e)
                returnData = {
                    "status": "error",
                    "message": str(e),
                    "trace": traceback.format_exc(),
                }
                if(debug):
                    returnData['node_results'] = results
                return returnData

        if __name__ == "__main__":
            print(json.dumps(run_flow(), indent=2))
        '''))

        return JsonResponse({
            "status": "success",
            "flow": flow_name,
            "dependency_summary": install_report
        })

    except Exception as e:
        import traceback
        traceback.print_exc()
        return JsonResponse({"status": "error", "message": str(e)})

@csrf_exempt
def save_flow_api(request):
    """
    Save flow JSON to DB and generate runnable Python files.

    This version avoids .format()/f-string substitution on large template blocks
    so braces like {{foo.bar}} remain intact. Copy-paste this function into views.py.
    """
    import os
    import json
    import re
    import ast
    import shutil
    import sys
    import textwrap
    import datetime
    import subprocess
    import importlib
    import traceback

    from django.http import JsonResponse
    from django.conf import settings
    from code_engine.models import Flow, CommonFunction

    # --- Safety / config ---
    SAFE_BUILTINS = {
        "sys", "os", "json", "re", "datetime", "math", "logging",
        "pathlib", "textwrap", "typing", "collections", "itertools",
        "functools", "time", "inspect", "base64"
    }
    BLOCKED_LIBS = {
        "subprocess", "shutil", "ctypes", "mmap", "socket", "telnetlib",
        "pickle", "marshal", "signal", "crypt"
    }

    FIELD_PRIORITY = [
        "location", "location_id", "site", "site_id",
        "tenant", "tenant_id", "rack", "rack_id",
        "region", "region_id", "id"
    ]

    def extract_imports_from_code(code_str):
        libs = set()
        try:
            tree = ast.parse(code_str)
        except Exception:
            return libs
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    libs.add(alias.name.split(".")[0])
            elif isinstance(node, ast.ImportFrom) and node.module:
                libs.add(node.module.split(".")[0])
        return libs

    def ensure_safe_install(libs_set):
        result = {"installed": [], "blocked": [], "failed": [], "already_present": []}
        for lib in sorted(libs_set):
            if not lib or lib in SAFE_BUILTINS:
                result["already_present"].append(lib)
                continue
            if lib in BLOCKED_LIBS:
                result["blocked"].append(lib)
                continue
            try:
                importlib.import_module(lib)
                result["already_present"].append(lib)
            except ImportError:
                print(f"[save_flow_api] Installing missing library: {lib}")
                proc = subprocess.run([sys.executable, "-m", "pip", "install", lib],
                                      stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
                if proc.returncode == 0:
                    result["installed"].append(lib)
                else:
                    result["failed"].append({"lib": lib, "stderr": proc.stderr})
        return result

    def safe_ident(name):
        return re.sub(r"\W+", "_", (name or "unnamed")).strip("_")

    try:
        payload = json.loads(request.body.decode())
        flow_name = payload.get("flow_name")
        nodes = payload.get("nodes", []) or []
        connections = payload.get("connections", []) or []
        parameters = payload.get("parameters", {}) or {}

        if not flow_name:
            return JsonResponse({"status": "error", "message": "flow_name is required"}, status=400)

        # Storage layout
        base_path = os.path.join(getattr(settings, "BASE_DIR", os.getcwd()), "scripts_storage")
        flow_dir = os.path.join(base_path, "flows", flow_name)
        common_dir = os.path.join(base_path, "common_functions")
        os.makedirs(flow_dir, exist_ok=True)
        os.makedirs(common_dir, exist_ok=True)

        flow_obj, _ = Flow.objects.get_or_create(name=flow_name)
        flow_obj.folder = flow_dir

        # Clean existing
        if os.path.exists(flow_dir):
            shutil.rmtree(flow_dir, ignore_errors=True)
            os.makedirs(flow_dir, exist_ok=True)

        # --- Detect Nautobot base URL & token (embed at save-time) ---
        detected_base_url = None
        try:
            detected_base_url = getattr(settings, "NAUTOBOT_API_URL", None) or getattr(settings, "NAUTOBOT_URL", None)
            if detected_base_url:
                detected_base_url = str(detected_base_url).rstrip("/")
        except Exception:
            detected_base_url = None

        if not detected_base_url:
            try:
                root_candidate = getattr(settings, "NAUTOBOT_ROOT", None)
                port_candidate = getattr(settings, "NAUTOBOT_PORT", None) or getattr(settings, "NAUTOBOT_RUN_PORT", None)
                if root_candidate:
                    detected_base_url = str(root_candidate).rstrip("/")
                elif port_candidate:
                    detected_base_url = f"http://127.0.0.1:{port_candidate}/api"
                else:
                    host = request.get_host()
                    if ":" in host:
                        hostname, port = host.split(":", 1)
                        detected_base_url = f"http://{hostname}:{port}/api"
                    else:
                        detected_base_url = f"http://{host}/api"
            except Exception:
                detected_base_url = "http://127.0.0.1:8004/api"

        detected_base_url = detected_base_url.rstrip("/")
        if not detected_base_url.endswith("/api"):
            detected_base_url = detected_base_url.rstrip("/") + "/api"

        # token detection
        embedded_token = None
        try:
            embedded_token = getattr(settings, "NAUTOBOT_API_TOKEN", None)
        except Exception:
            embedded_token = None

        if not embedded_token:
            try:
                from nautobot.extras.models import APIToken as NautobotToken
                tok = NautobotToken.objects.filter(key__isnull=False).first()
                embedded_token = tok.key if tok else None
            except Exception:
                try:
                    from nautobot.users.models import Token as UserToken
                    tok = UserToken.objects.filter(key__isnull=False).first()
                    embedded_token = tok.key if tok else None
                except Exception:
                    embedded_token = None

        # --- flow_helpers.py content (built safely via replace tokens) ---
        # Use unique markers __BASE__ and __TOKEN__ then replace them; avoids accidental {.} formatting.
        helpers_template = textwrap.dedent(
            """
            \"\"\"Auto-generated helpers for flow '__FLOW_NAME__'
            detected_base_url: __BASE__
            embedded_token_present: __TOKEN_PRESENT__
            \"\"\"
            import json
            import time
            import requests

            DEFAULT_BASE_URL = "__BASE__"
            DEFAULT_TOKEN = __TOKEN_JSON__

            def normalize_base(base_url):
                base = (base_url or DEFAULT_BASE_URL or '').rstrip('/')
                # if base ends with '/api', strip it so callers can append '/api' once
                if base.endswith('/api'):
                    base = base[:-4]
                return base.rstrip('/')

            def get_internal_nautobot_credentials(context=None):
                \"\"\"Return (base_url_with_api, token, headers). 
                Priority: context overrides -> embedded defaults.
                \"\"\"
                context = context or {}
                base = context.get('nautobot_api_url') or DEFAULT_BASE_URL
                token = context.get('nautobot_api_token') or DEFAULT_TOKEN
                if not base:
                    base = DEFAULT_BASE_URL
                base = normalize_base(base) + '/api'
                headers = {}
                if token:
                    headers['Authorization'] = f'Token {token}'
                return base, token, headers

            def fetch_all(endpoint, params=None, headers=None, timeout=10):
                \"\"\"Fetch all resources with Nautobot pagination.
                Accepts params as dict or list-of-(k,v) tuples; converts to repeated query params when needed.
                Returns aggregated list of dicts.
                \"\"\" 
                headers = headers or {}
                results = []
                next_url = endpoint
                attempts = 0

                initial_params = None
                if isinstance(params, list):
                    initial_params = params
                elif isinstance(params, dict):
                    initial_params = params
                else:
                    initial_params = params

                while next_url:
                    attempts += 1
                    if attempts > 200:
                        print('[flow_helpers] Too many pages, breaking.')
                        break
                    try:
                        print('[flow_helpers] GET', next_url, 'params=', initial_params)
                        r = requests.get(next_url, params=initial_params if next_url==endpoint else None, headers=headers, timeout=timeout)
                        r.raise_for_status()
                        data = r.json()
                        if isinstance(data, dict) and 'results' in data:
                            results.extend(data.get('results') or [])
                            next_url = data.get('next')
                            initial_params = None
                        else:
                            if isinstance(data, list):
                                results.extend(data)
                            else:
                                results.append(data)
                            next_url = None
                    except Exception as e:
                        print('[flow_helpers] fetch_all error for', next_url, ':', e)
                        break
                return results

            def extract_path_from_item(item, path_list):
                cur = item
                try:
                    for p in path_list:
                        if isinstance(cur, dict) and p in cur:
                            cur = cur[p]
                        else:
                            return None
                    return cur
                except Exception:
                    return None

            def resolve_placeholder_value(placeholder, context, prefer_key=None):
                \"\"\"Resolve placeholders like '{{locations_list}}' or '{{locations_list.tenant.id}}' to scalars or lists.\"\"\"
                p = placeholder.strip()
                if not (p.startswith('{{') and p.endswith('}}')):
                    return placeholder
                inner = p[2:-2].strip()
                parts = inner.split('.')
                root = parts[0]
                path = parts[1:] if len(parts) > 1 else []
                value = (context or {}).get(root)
                if value is None:
                    return None
                if path:
                    if isinstance(value, dict):
                        return extract_path_from_item(value, path)
                    if isinstance(value, list):
                        out = []
                        for it in value:
                            v = extract_path_from_item(it, path)
                            if v is not None:
                                out.append(v)
                        return out
                    return None
                # no path -> try to infer ids from list-of-dicts
                if isinstance(value, list):
                    if not value:
                        return []
                    if all(not isinstance(i, dict) for i in value):
                        return value
                    out = []
                    for it in value:
                        if not isinstance(it, dict):
                            continue
                        if 'id' in it:
                            out.append(it['id'])
                            continue
                        if 'pk' in it:
                            out.append(it['pk'])
                            continue
                        if prefer_key and prefer_key in it:
                            nested = it.get(prefer_key)
                            if isinstance(nested, dict) and 'id' in nested:
                                out.append(nested['id'])
                                continue
                            if isinstance(nested, (str, int)):
                                out.append(nested)
                                continue
                        found = False
                        for v in it.values():
                            if isinstance(v, dict) and 'id' in v:
                                out.append(v['id'])
                                found = True
                                break
                        if found:
                            continue
                    return list(dict.fromkeys(out))
                else:
                    if isinstance(value, dict):
                        return value.get('id') or value.get('pk') or value
                    return value

            # EOF helpers
            """
        )

        # Substitute the safe markers (no .format())
        token_json = json.dumps(embedded_token) if embedded_token else "None"
        helpers_content = helpers_template.replace("__FLOW_NAME__", flow_name.replace('"', '\\"'))
        helpers_content = helpers_content.replace("__BASE__", detected_base_url)
        helpers_content = helpers_content.replace("__TOKEN_PRESENT__", "True" if embedded_token else "False")
        helpers_content = helpers_content.replace("__TOKEN_JSON__", token_json)

        helpers_path = os.path.join(flow_dir, "flow_helpers.py")
        with open(helpers_path, "w", encoding="utf-8") as hf:
            hf.write(helpers_content)

        # --- Build nodes: create per-node files and register NODE_CALLS etc. ---
        node_calls = {}
        node_types = {}
        outgoing = {}
        conditional_links = {}
        collected_code = []
        node_by_id = {str(n.get("id")): n for n in nodes}

        for node in nodes:
            nid = str(node.get("id"))
            ntype = node.get("type")
            data = node.get("data") or {}
            name = data.get("name") or f"node_{nid}"
            code = data.get("code", "")
            include_in_common = data.get("include_in_common", False)
            common_id = data.get("common_id")
            cond = data.get("cond", "True")

            node_types[nid] = ntype
            if code:
                collected_code.append(code)

            # START node
            if ntype == "start":
                path = os.path.join(flow_dir, f"f{nid.zfill(2)}_start.py")
                params = data.get("params", []) or []
                node_calls[nid] = {"type": "local", "module": f"f{nid.zfill(2)}_start", "func": "start"}
                with open(path, "w", encoding="utf-8") as f:
                    f.write("import datetime\n\n")
                    f.write("def start(context):\n")
                    for p in params:
                        pname = p.get("name")
                        if pname:
                            f.write(f"    context.setdefault({json.dumps(pname)}, None)\n")
                    f.write("    context.setdefault('nautobot_api_url', 'https://demo.nautobot.com/api/')\n")
                    f.write("    context.setdefault('nautobot_api_token', 'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa')\n")
                    f.write("    print('[NODE start] initialized context:', context)\n")
                    f.write("    return context\n")

            # FUNCTION node
            elif ntype == "function":
                module_name = safe_ident(name)
                if common_id:
                    try:
                        cf_obj = CommonFunction.objects.get(id=common_id)
                        cf_name = safe_ident(cf_obj.name)
                        node_calls[nid] = {"type": "common", "module": cf_name, "func": cf_obj.name}
                        cf_path = os.path.join(common_dir, f"{cf_name}.py")
                        if not os.path.exists(cf_path):
                            with open(cf_path, "w", encoding="utf-8") as cf:
                                cf.write("# shim for common function: " + cf_name + "\n")
                                cf.write((cf_obj.code or "") + "\n")
                        continue
                    except Exception:
                        pass
                entry_func_m = None
                try:
                    m = re.search(r"def\s+([A-Za-z_][A-Za-z0-9_]*)\s*\(", code)
                    entry_func_m = m.group(1) if m else None
                except Exception:
                    entry_func_m = None
                entry_func = entry_func_m or module_name
                path = os.path.join(flow_dir, f"f{nid.zfill(2)}_{module_name}.py")
                with open(path, "w", encoding="utf-8") as f:
                    f.write("import datetime\n\n")
                    f.write(code.strip() + "\n\n")
                    f.write(f"def {module_name}_system(context):\n")
                    f.write(f"    print('[NODE func] Executing {name} at', datetime.datetime.now())\n")
                    f.write(f"    return {entry_func}(context)\n")
                node_calls[nid] = {"type": "local", "module": f"f{nid.zfill(2)}_{module_name}", "func": f"{module_name}_system"}

            # CONDITIONAL node
            elif ntype == "conditional":
                path = os.path.join(flow_dir, f"f{nid.zfill(2)}_conditional.py")
                with open(path, "w", encoding="utf-8") as f:
                    f.write("import datetime\n\n")
                    f.write("def conditional_system(context):\n")
                    f.write("    print('[NODE conditional] Evaluating condition')\n")
                    f.write("    try:\n")
                    f.write(f"        result = bool({cond})\n")
                    f.write("    except Exception as _e:\n")
                    f.write("        print('[NODE conditional] Error:', _e)\n")
                    f.write("        result = False\n")
                    f.write("    return {'__conditional_result__': result, 'context': context}\n")
                node_calls[nid] = {"type": "conditional", "module": f"f{nid.zfill(2)}_conditional", "func": "conditional_system"}
                conditional_links[nid] = {"true": [], "false": [], "default": []}

            # END NODE
            elif ntype == "end":
                response_keys = data.get("response_keys", [])
                if isinstance(response_keys, str):
                    response_keys = [x.strip() for x in response_keys.split(",") if x.strip()]

                module_name = f"f{nid.zfill(2)}_end"
                path = os.path.join(flow_dir, f"{module_name}.py")

                with open(path, "w", encoding="utf-8") as f:
                    f.write("import datetime\n\n")
                    f.write("def end_node(context):\n")
                    f.write("    print('[NODE end] Collecting response keys:', " + str(response_keys) + ")\n")
                    f.write("    response = {}\n")
                    for key in response_keys:
                        f.write(f"    response[{json.dumps(key)}] = context.get({json.dumps(key)})\n")
                    f.write("    context['response'] = response\n")
                    f.write("    return context\n")

                node_calls[nid] = {
                    "type": "end",
                    "module": module_name,
                    "func": "end_node"
                }

                
            # MODEL node (via Nautobot REST API)
            elif ntype == "model":
                model_path = data.get("model")  # e.g., "dcim.Location"
                output_var = data.get("output_var") or data.get("output") or safe_ident((model_path or "model"))
                filters = data.get("filters", {}) or {}

                if not model_path:
                    print(f"[save_flow_api] model node {nid} missing 'model' - skipping")
                    continue
                try:
                    app_label, model_name = model_path.split(".")
                except Exception:
                    print(f"[save_flow_api] model_path malformed ({model_path}) for node {nid}; skipping.")
                    continue

                # Try to fetch _schema at save-time to detect best field
                detected_filter_field = None
                try:
                    import requests
                    base = detected_base_url.rstrip("/")
                    if base.endswith("/api"):
                        base = base[:-4]
                    schema_url = base.rstrip("/") + f"/api/{app_label}/{model_name.lower()}s/_schema/"
                    headers = {}
                    if embedded_token:
                        headers['Authorization'] = f"Token {embedded_token}"
                    r = requests.get(schema_url, headers=headers, timeout=10)
                    if r.status_code == 200:
                        schema = r.json()
                        props = schema.get("properties", {}) or {}
                        for candidate in FIELD_PRIORITY:
                            if candidate in props:
                                detected_filter_field = candidate
                                break
                    else:
                        print(f"[save_flow_api] schema fetch returned {r.status_code} for {schema_url}")
                except Exception as e:
                    print("[save_flow_api] schema fetch failed:", e)

                if not detected_filter_field:
                    heuristic = model_name.lower()
                    if "location" in heuristic:
                        detected_filter_field = "id"
                    else:
                        detected_filter_field = "id"

                # write model node file
                path = os.path.join(flow_dir, f"f{nid.zfill(2)}_model_{model_name}.py")
                with open(path, "w", encoding="utf-8") as f:
                    f.write("import json\n")
                    f.write("from flow_helpers import get_internal_nautobot_credentials, fetch_all, resolve_placeholder_value\n\n")
                    f.write(f"def model_{model_name}(context):\n")
                    f.write(f"    print('[NODE model] {app_label}.{model_name} starting with context keys:', list(context.keys()))\n")
                    f.write(f"    filters = {json.dumps(filters, indent=4)}\n")
                    f.write("    base_url, token, headers = get_internal_nautobot_credentials(context)\n")
                    f.write("    endpoint = base_url.rstrip('/') + '/{app_label}/{model_name_lower}s/'\n".format(app_label=app_label, model_name_lower=model_name.lower()))
                    f.write("    print('[NODE model] endpoint=', endpoint)\n")
                    f.write("    resolved_params = {}\n")
                    f.write("    for k, v in list(filters.items()):\n")
                    f.write("        if isinstance(v, str) and v.strip().startswith('{{') and v.strip().endswith('}}'):\n")
                    f.write("            prefer = None\n")
                    f.write("            if '__' in k:\n")
                    f.write("                prefer = k.split('__')[0]\n")
                    f.write("            pv = resolve_placeholder_value(v, context, prefer_key=prefer)\n")
                    f.write("            if isinstance(pv, list):\n")
                    f.write("                resolved_params[k] = pv\n")
                    f.write("            else:\n")
                    f.write("                resolved_params[k] = pv\n")
                    f.write("        else:\n")
                    f.write("            resolved_params[k] = v\n\n")
                    f.write("    print('[NODE model] resolved_params=', resolved_params)\n")
                    f.write("    # Convert resolved_params to request-friendly list-of-tuples for repeated params\n")
                    f.write("    final_params = []\n")
                    f.write("    for kk, vv in resolved_params.items():\n")
                    f.write("        if isinstance(vv, list):\n")
                    f.write("            keyname = kk\n")
                    f.write("            if kk.endswith('__in'):\n")
                    f.write("                keyname = kk[:-4]\n")
                    f.write("            for item in vv:\n")
                    f.write("                final_params.append((keyname, item))\n")
                    f.write("        else:\n")
                    f.write("            final_params.append((kk, vv))\n\n")
                    f.write("    try:\n")
                    f.write("        results = fetch_all(endpoint, params=final_params, headers=headers)\n")
                    f.write("        print(f'[NODE model] fetched {len(results)} items')\n")
                    f.write("    except Exception as e:\n")
                    f.write("        print('[NODE model] API error:', e)\n")
                    f.write("        context['api_error'] = str(e)\n")
                    f.write("        results = []\n")
                    f.write(f"    context['{output_var}'] = results\n")
                    f.write("    return context\n")
                node_calls[nid] = {"type": "model", "module": f"f{nid.zfill(2)}_model_{model_name}", "func": f"model_{model_name}"}

        # --- build outgoing map ---
        for conn in connections:
            src, tgt = str(conn.get("from")), str(conn.get("to"))
            outgoing.setdefault(src, []).append(tgt)

        # --- save flow JSON ---
        flow_obj.json_data = {
            "nodes": nodes,
            "connections": connections,
            "parameters": parameters,
            "conditional_links": conditional_links,
        }
        flow_obj.save()

        # --- dependency detection & install ---
        discovered_libs = set()
        for snippet in collected_code:
            discovered_libs.update(extract_imports_from_code(snippet))
        install_report = ensure_safe_install(discovered_libs)

        try:
            with open(os.path.join(flow_dir, "requirements.txt"), "w", encoding="utf-8") as rf:
                rf.write("\n".join(sorted(install_report.get("installed", []) + install_report.get("already_present", []))))
        except Exception as e:
            print("[save_flow_api] Could not write requirements.txt:", e)

        # --- Generate main.py safely (use json.dumps for dict constants) ---
        main_path = os.path.join(flow_dir, "main.py")
        with open(main_path, "w", encoding="utf-8") as f:
            f.write("# Auto-generated main runner (API-based)\n")
            f.write("import os, sys, json, traceback, datetime\n")
            f.write("BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..'))\n")
            f.write("FLOW_DIR = os.path.abspath(os.path.dirname(__file__))\n")
            f.write("sys.path.extend([BASE_DIR, FLOW_DIR, os.path.join(BASE_DIR, 'common_functions')])\n\n")
            f.write("from flow_helpers import get_internal_nautobot_credentials, fetch_all, resolve_placeholder_value\n")
            # imports
            for nid, info in node_calls.items():
                f.write(f"from {info['module']} import {info['func']}\n")
            f.write("\n")
            f.write("NODE_CALLS = " + json.dumps(node_calls, indent=4) + "\n")
            f.write("NODE_TYPES = " + json.dumps(node_types, indent=4) + "\n")
            f.write("OUTGOING = " + json.dumps(outgoing, indent=4) + "\n\n")
            f.write(textwrap.dedent(
                """\
                def run_flow(input_data=None, debug=False):
                    results, executed = {}, set()
                    context = input_data or {}
                    print("=== Flow Execution Started ===")

                    def traverse(nid):
                        nonlocal context
                        if not nid or str(nid) in executed:
                            return
                        executed.add(str(nid))
                        node = NODE_CALLS.get(str(nid))
                        fn = globals().get(node["func"])
                        if not fn:
                            raise Exception(f"Missing function for node {nid}")
                        print(f"[NODE {nid}] Executing {node['func']} ...")
                        if node["type"] == "conditional":
                            result = fn(context)
                            flag = result.get("__conditional_result__", False)
                            context = result.get("context", context)
                            results[str(nid)] = {"type": "conditional", "result": flag}
                            targets = OUTGOING.get(str(nid), [])
                            if flag and len(targets) > 0:
                                traverse(targets[0])
                            elif not flag and len(targets) > 1:
                                traverse(targets[1])
                        else:
                            context = fn(context)
                            results[str(nid)] = {"type": node["type"], "result": context}
                            for nxt in OUTGOING.get(str(nid), []):
                                traverse(nxt)

                    try:
                        for s, t in NODE_TYPES.items():
                            if t == "start":
                                traverse(s)
                        print("=== Flow Complete ===")
                        # If END node created a response, return only that
                        final_response = context.get("response", None)

                        returnData = {
                            "status": "success",
                            "message": "Flow executed successfully",
                            "results": final_response if final_response is not None else context,
                            "error": None,
                        }
                        if debug:
                            returnData['node_results'] = results
                        return returnData
                    except Exception as e:
                        print("❌ Flow execution failed:", e)
                        returnData = {
                            "status": "error",
                            "message": str(e),
                            "trace": traceback.format_exc(),
                        }
                        if debug:
                            returnData['node_results'] = results
                        return returnData

                if __name__ == "__main__":
                    print(json.dumps(run_flow(), indent=2))
                """
            ))

        return JsonResponse({
            "status": "success",
            "flow": flow_name,
            "dependency_summary": install_report,
            "detected_base_url": detected_base_url,
            "embedded_token_present": bool(embedded_token)
        })
    except Exception as e:
        tb = traceback.format_exc()
        print("[save_flow_api] Exception:", e, tb)
        return JsonResponse({"status": "error", "message": str(e), "trace": tb}, status=500)


from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
import importlib.util
import json
import os
import traceback

@csrf_exempt
def run_flow_api(request,flow_name):
    """
    Execute a saved flow dynamically via API.
    - Loads generated main.py from flow directory.
    - Calls run_flow(params) and returns structured JSON including final_context.
    """
    if request.method != "POST":
        return JsonResponse({"status": "error", "message": "POST required"}, status=405)

    try:
        body = json.loads(request.body.decode("utf-8"))
    except Exception as e:
        return JsonResponse({
            "status": "error",
            "message": "Invalid JSON payload",
            "error": str(e)
        }, status=400)

    # flow_name = body.get("flow_name")
    params = body.get("params", {})
    debug = body.get("debug", False)

    if not flow_name:
        return JsonResponse({
            "status": "error",
            "message": "Missing 'flow_name'"
        }, status=400)

    flow_dir = _flow_dir(flow_name)
    main_script = os.path.join(flow_dir, "main.py")

    if not os.path.exists(main_script):
        return JsonResponse({
            "status": "error",
            "message": f"Flow not found: {main_script}"
        }, status=404)

    try:
        import importlib.util
        spec = importlib.util.spec_from_file_location("flow_module", main_script)
        flow_module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(flow_module)

        # Execute the flow with parameters
        result = flow_module.run_flow(params, debug)
        print("here is the result",result)
        # ✅ Ensure dict
        if not isinstance(result, dict):
            return JsonResponse({
                "status": "error",
                "message": "Flow returned non-dict response",
                "raw_result": str(result)
            }, status=500)

        safe_result = clean_for_json(result)
        return JsonResponse(safe_result, encoder=DjangoJSONEncoder, safe=False, status=200)

    except Exception as e:
        tb = traceback.format_exc()
        return JsonResponse({
            "status": "error",
            "message": f"Flow execution failed: {str(e)}",
            "error": tb
        }, status=500)


def run_flow_ui(request, flow_name):
    """
    Enhanced Run Flow UI:
    - Auto-detects Start node parameters from flow JSON
    - Renders dynamic input form fields
    """
    flow_dir = _flow_dir(flow_name)
    flow_json_path = os.path.join(flow_dir, "flow.json")

    start_params = []
    if os.path.exists(flow_json_path):
        try:
            with open(flow_json_path) as f:
                flow_data = json.load(f)
            for node in flow_data.get("nodes", []):
                if node.get("type") == "start":
                    start_params = [p.get("name") for p in node.get("data", {}).get("params", []) if p.get("name")]
                    break
        except Exception as e:
            print(f"⚠️ Error reading flow params: {e}")

    return render(
        request,
        "code_engine/run_flow.html",
        {
            "flow_name": flow_name,
            "start_params": start_params,
        },
    )

@csrf_exempt
def delete_flow_api(request, flow_name):
    """
    Delete a flow:
    - Removes DB record
    - Deletes generated files/folder from scripts_storage
    """
    if request.method != "DELETE":
        return JsonResponse({"status": "error", "message": "DELETE required"}, status=405)

    try:
        # Fetch flow
        flow_obj = Flow.objects.filter(name=flow_name).first()
        if not flow_obj:
            return JsonResponse({"status": "error", "message": "Flow not found"}, status=404)

        # Delete folder if exists
        if flow_obj.folder and os.path.exists(flow_obj.folder):
            import shutil
            try:
                shutil.rmtree(flow_obj.folder)
            except Exception as cleanup_err:
                return JsonResponse({
                    "status": "warning",
                    "message": f"Flow deleted from DB, but failed to delete folder: {cleanup_err}"
                }, status=200)

        # Delete DB record
        flow_obj.delete()

        return JsonResponse({"status": "success", "message": f"Flow '{flow_name}' deleted successfully."}, status=200)

    except Exception as e:
        tb = traceback.format_exc()
        return JsonResponse({
            "status": "error",
            "message": f"Failed to delete flow: {str(e)}",
            "error": tb
        }, status=500)
    

def ensure_common_function_dir():
    os.makedirs(COMMON_FUNCTIONS_DIR, exist_ok=True)

def get_common_function_path(name):
    safe_name = name.replace("..", "").replace("/", "")
    return os.path.join(COMMON_FUNCTIONS_DIR, f"{safe_name}.py")


@csrf_exempt
def create_common_function(request):
    """
    POST /api/common-functions/
    Body: { "name": "logger", "code": "def logger(context): ...", "description": "optional" }
    """
    if request.method != "POST":
        return HttpResponseBadRequest("Invalid method")

    try:
        data = json.loads(request.body.decode("utf-8"))
        name = data.get("name")
        code = data.get("code")

        if not name or not code:
            return JsonResponse({"status": "error", "message": "Missing name or code"}, status=400)

        ensure_common_function_dir()
        file_path = get_common_function_path(name)

        if os.path.exists(file_path) or CommonFunction.objects.filter(name=name).exists():
            return JsonResponse({"status": "error", "message": "Function already exists"}, status=400)

        with open(file_path, "w", encoding="utf-8") as f:
            f.write(code)

        CommonFunction.objects.create(
            name=name,
            code=code,
            file_path=file_path,
        )

        return JsonResponse({"status": "success", "message": f"Function '{name}' created"})
    except Exception as e:
        return JsonResponse({"status": "error", "message": str(e)}, status=500)

@csrf_exempt
def update_common_function(request, id):
    """
    PUT /api/common-functions/<id>/
    Body: { "code": "def logger(context): ...", "description": "optional" }
    """
    if request.method != "PUT":
        return HttpResponseBadRequest("Invalid method")

    try:
        data = json.loads(request.body.decode("utf-8"))
        code = data.get("code")

        if not code:
            return JsonResponse({"status": "error", "message": "Missing code"}, status=400)

        cf = CommonFunction.objects.filter(id=id).first()
        if not cf:
            return JsonResponse({"status": "error", "message": "Function not found"}, status=404)

        file_path = get_common_function_path(cf.name)

        # Update file on disk
        with open(file_path, "w", encoding="utf-8") as f:
            f.write(code)

        # Update database record
        cf.file_path = file_path
        cf.code = code
        cf.save(update_fields=["file_path","code", "updated_at"])

        return JsonResponse({"status": "success", "message": f"Function '{cf.name}' updated successfully"})
    except Exception as e:
        traceback.print_exc()
        return JsonResponse({"status": "error", "message": str(e)}, status=500)


@csrf_exempt
def delete_common_function(request, id):
    """
    DELETE /api/common-functions/<id>/delete/
    """
    try:
        
        cf = CommonFunction.objects.filter(id=id).first()

        if not cf:
            return JsonResponse({"status": "error", "message": "Function not found"}, status=404)
        file_path = get_common_function_path(cf.file_path)
        if os.path.exists(file_path):
            os.remove(file_path)

        cf.delete()

        return JsonResponse({"status": "success", "message": f"Function '{cf.name}' deleted"})
    except Exception as e:
        return JsonResponse({"status": "error", "message": str(e)}, status=500)





@require_http_methods(["GET"])
def list_nautobot_models_api(request):
    """
    Dynamically list Nautobot models and their fields.
    Used for model-based Flow Builder nodes.
    """
    allowed_apps = {"dcim", "ipam", "tenancy", "virtualization", "extras"}

    models_data = []
    for model in apps.get_models():
        app_label = model._meta.app_label
        if app_label not in allowed_apps:
            continue

        try:
            fields = []
            for f in model._meta.get_fields():
                field_info = {
                    "name": f.name,
                    "type": getattr(f, "get_internal_type", lambda: type(f).__name__)(),
                    "is_relation": f.is_relation,
                }
                if hasattr(f, "related_model") and f.related_model:
                    field_info["related_model"] = f.related_model._meta.label
                fields.append(field_info)

            models_data.append({
                "app_label": app_label,
                "model": model.__name__,
                "fields": sorted(fields, key=lambda x: x["name"]),
            })
        except Exception as e:
            continue

    return JsonResponse({"status": "success", "models": models_data})


def clean_for_json(obj):
    import datetime, decimal, zoneinfo
    if isinstance(obj, (datetime.datetime, datetime.date)):
        return obj.isoformat()
    if isinstance(obj, decimal.Decimal):
        return float(obj)
    if isinstance(obj, zoneinfo.ZoneInfo):
        return obj.key
    if isinstance(obj, (list, tuple, set)):
        return [clean_for_json(i) for i in obj]
    if isinstance(obj, dict):
        return {str(k): clean_for_json(v) for k, v in obj.items()}
    return str(obj)


