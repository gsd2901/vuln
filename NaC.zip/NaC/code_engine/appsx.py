from nautobot.extras.plugins import PluginConfig


class CodeEngineConfig(PluginConfig):
    name = "code_engine"

    verbose_name = "Code Engine"
    version = "1.0.0"
    author = "Akash Sharma"
    description = "Code execution and flow builder plugin"
    base_url = "code-engine"
    required_settings = []
    default_settings = {}
