from django.db import models

class Flow(models.Model):
    """
    Represents a saved flow. We store JSON metadata for the flow and the folder path.
    """
    name = models.CharField(max_length=200, unique=True)
    folder = models.CharField(max_length=500, blank=True)  # filesystem folder under scripts_storage/flows/
    json_data = models.JSONField(null=True, blank=True)     # raw canvas export
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.name


class CommonFunction(models.Model):
    """
    Shared, reusable function stored globally (can be added to sidebar).
    Users may reference this in flows. If used as a reference, nodes are read-only unless a replica is created.
    """
    name = models.CharField(max_length=200, unique=True)
    code = models.TextField(blank=True)
    file_path = models.TextField(blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.name
