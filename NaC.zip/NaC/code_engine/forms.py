from django import forms
from .models import Code

class CodeForm(forms.ModelForm):
    code = forms.CharField(
        widget=forms.Textarea(attrs={'rows': 20, 'cols': 100}),
        label="Python Code"
    )

    class Meta:
        model = Code
        fields = ['name', 'entry_function', 'code']
