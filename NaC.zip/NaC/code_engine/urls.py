from django.urls import path
from . import views

app_name = "code_engine"

urlpatterns = [
    path('', views.list_flows, name='list_flows'),
    path('create/', views.create_flow, name='create_flow'),
    path('edit/<str:flow_name>/', views.edit_flow, name='edit_flow'),
    path('api/get_flow_json/<str:flow_name>/', views.get_flow_json, name='get_flow_json'),
    path('api/save_flow/', views.save_flow_api, name='save_flow_api'),
    path('api/run_flow/<str:flow_name>/', views.run_flow_api, name='run_flow_api'),
    path('api/common_functions/', views.get_common_functions_api, name='get_common_functions_api'),
    path('run/<str:flow_name>/', views.run_flow_ui, name='run_flow_ui'),
    path("api/flows/<str:flow_name>/delete/", views.delete_flow_api, name="delete_flow_api"),

    path("api/common-functions/", views.create_common_function, name="create_common_function"),
    path("api/common-functions/<str:id>/", views.update_common_function, name="update_common_function"),
    path("api/common-functions/<str:id>/delete/", views.delete_common_function, name="delete_common_function"),

    path("api/models/", views.list_nautobot_models_api, name="list_nautobot_models_api"),
]
