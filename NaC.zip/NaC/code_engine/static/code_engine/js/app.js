document.addEventListener("DOMContentLoaded", () => {
    const canvas = document.getElementById("editorCanvas");
    const ctx = canvas.getContext("2d");
    const techSelect = document.getElementById("techSelect");
    const runBtn = document.getElementById("runBtn");
    const outputConsole = document.getElementById("outputConsole");

    const popup = document.getElementById("popup");
    const popupTitle = document.getElementById("popupTitle");
    const popupBody = document.getElementById("popupBody");
    const popupSave = document.getElementById("popupSave");
    const popupCancel = document.getElementById("popupCancel");

    let nodes = [];
    let selectedNode = null;
    let dragging = false;
    let entryNode = null;

    // Resize
    function resizeCanvas() {
        canvas.width = canvas.clientWidth;
        canvas.height = canvas.clientHeight;
        draw();
    }
    window.addEventListener("resize", resizeCanvas);
    resizeCanvas();

    // Draw
    function draw() {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        nodes.forEach(node => {
            ctx.fillStyle = node.type === "start" ? "#27ae60" : "#2980b9";
            ctx.fillRect(node.x, node.y, node.w, node.h);
            ctx.fillStyle = "white";
            ctx.fillText(node.label, node.x + 10, node.y + 25);
        });
    }

    // Click handler
    canvas.addEventListener("mousedown", e => {
        if (!techSelect.value) return alert("Please select a tech stack first!");
        const rect = canvas.getBoundingClientRect();
        const x = e.clientX - rect.left, y = e.clientY - rect.top;
        selectedNode = nodes.find(n => x >= n.x && x <= n.x + n.w && y >= n.y && y <= n.y + n.h);

        if (selectedNode) {
            openPopup(selectedNode);
        } else {
            const type = nodes.length === 0 ? "start" : "function";
            const newNode = { id: Date.now(), type, x, y, w: 120, h: 40, label: type === "start" ? "Start" : "Function", data: {} };
            nodes.push(newNode);
            draw();
        }
    });

    // Dragging
    canvas.addEventListener("mousemove", e => {
        if (!dragging || !selectedNode) return;
        const rect = canvas.getBoundingClientRect();
        selectedNode.x = e.clientX - rect.left - selectedNode.offsetX;
        selectedNode.y = e.clientY - rect.top - selectedNode.offsetY;
        draw();
    });

    canvas.addEventListener("mouseup", () => (dragging = false));

    // Popup functions
    function openPopup(node) {
        popup.classList.remove("hidden");
        popupTitle.textContent = node.type === "start" ? "Configure Start Node" : "Write Function Code";

        if (node.type === "start") {
            popupBody.innerHTML = `
        <label>Name:</label>
        <input type="text" id="startName" value="${node.data.name || ''}" />
        <label>Entry Function:</label>
        <input type="text" id="entryPoint" value="${node.data.entry || ''}" />
      `;
        } else {
            popupBody.innerHTML = `
        <label>Function Code:</label>
        <textarea id="funcCode">${node.data.code || ''}</textarea>
      `;
        }

        popupSave.onclick = () => {
            if (node.type === "start") {
                node.data.name = document.getElementById("startName").value;
                node.data.entry = document.getElementById("entryPoint").value;
                entryNode = node;
            } else {
                node.data.code = document.getElementById("funcCode").value;
            }
            node.label = node.type === "start" ? node.data.name || "Start" : "Function";
            popup.classList.add("hidden");
            draw();
            runBtn.disabled = false;
        };

        popupCancel.onclick = () => popup.classList.add("hidden");
    }

    // Run code
    runBtn.addEventListener("click", async () => {
        if (!entryNode) return alert("Please define the start node first!");
        const language = techSelect.value;
        const allCode = nodes.filter(n => n.type === "function").map(n => n.data.code).join("\n\n");

        const payload = {
            language,
            entry_point: entryNode.data.entry,
            code: allCode,
        };

        outputConsole.textContent = "Running code...\n";

        const resp = await fetch("/execute/", {
            method: "POST",
            headers: { "Content-Type": "application/json", "X-CSRFToken": getCSRFToken() },
            body: JSON.stringify(payload),
        });

        const data = await resp.json();
        outputConsole.textContent += data.output || "No output received.";
    });

    function getCSRFToken() {
        const cookie = document.cookie.split("; ").find(row => row.startsWith("csrftoken="));
        return cookie ? cookie.split("=")[1] : "";
    }
});
