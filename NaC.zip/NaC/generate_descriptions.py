"""
generate_field_descriptions.py
--------------------------------
Uses Azure OpenAI to generate smart Field descriptions for every param
in a Nautobot tools.py file, based on:
  - Whether the field is plain, relation, or multi-relation (from nautobot_fields_actual.py)
  - The field name and object type context

Then patches the tools.py file in-place with updated Field(...) descriptions.

Description format enforced:
  RELATION / MULTI_RELATION fields:
    "Filter by <object> UUID. First resolve <name> to UUID via <getTool>. Never pass name/slug directly."

  PLAIN fields:
    "Filter by <field> <format/example>. Accepts <type> directly — no UUID needed."

Usage:
    python generate_descriptions.py \\
        --tools    custom_chatbot/ip_addresses_tools.py \\
        --fields   custom_chatbot/nautobot_fields_actual.py \\
        --object   ip_addresses

    # To process all tools files at once:
    python generate_descriptions.py --all \\
        --fields   custom_chatbot/nautobot_fields_actual.py \\
        --tools-dir custom_chatbot/
"""

import argparse
import ast
import json
import os
import re
import sys
import httpx
from dotenv import load_dotenv
from langchain_openai import AzureChatOpenAI
from langchain_core.messages import HumanMessage

load_dotenv()

llm = AzureChatOpenAI(
    azure_deployment=os.getenv("AZURE_OPENAI_DEPLOYMENT", "gpt-5.4-mini"),
    api_version=os.getenv("AZURE_OPENAI_API_VERSION", "2025-04-01-preview"),
    azure_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT", "https://git-nw-openai-llm-prod.openai.azure.com/"),
    http_client=httpx.Client(verify=False),
    temperature=0,
    api_key=os.getenv("AZURE_OPENAI_API_KEY"),
)


# ---------------------------------------------------------------------------
# Step 1: Parse nautobot_fields_actual.py to get field categories
# ---------------------------------------------------------------------------

def parse_field_constants(fields_file: str) -> dict[str, dict]:
    """
    Parse nautobot_fields_actual.py and return a dict:
    {
      "ip_addresses": {
        "plain": [...],
        "relation": [...],
        "multi_relation": [...],
      },
      ...
    }
    """
    with open(fields_file) as f:
        source = f.read()

    tree = ast.parse(source)
    constants = {}
    for node in ast.walk(tree):
        if isinstance(node, ast.Assign):
            for target in node.targets:
                if isinstance(target, ast.Name):
                    name = target.id
                    if isinstance(node.value, ast.List):
                        values = [
                            # ✅ Fix: use .value instead of .s (Python 3.8+ compatibility)
                            elt.value for elt in node.value.elts
                            if isinstance(elt, ast.Constant) and isinstance(elt.value, str)
                        ]
                        constants[name] = values

    result = {}
    pattern = re.compile(r"^(.+?)_(PLAIN|RELATION|MULTI_RELATION)_FIELDS$")
    for const_name, fields in constants.items():
        m = pattern.match(const_name)
        if not m:
            continue
        obj_type = m.group(1).lower()
        field_type = m.group(2).lower()
        if obj_type not in result:
            result[obj_type] = {"plain": [], "relation": [], "multi_relation": []}
        key = "multi_relation" if field_type == "multi_relation" else field_type
        result[obj_type][key] = fields

    return result


# ---------------------------------------------------------------------------
# Step 2: Parse tools.py to extract Params class fields
# ---------------------------------------------------------------------------

def parse_params_fields(tools_file: str) -> dict[str, list[str]]:
    """
    Parse a tools.py file and return all Params class fields:
    {
      "ListIpAddresssParams": ["parent", "ip_version", "status", ...],
      "GetIpAddressParams":   ["id", "name", "address", ...],
    }
    """
    with open(tools_file) as f:
        source = f.read()

    tree = ast.parse(source)
    result = {}

    for node in ast.walk(tree):
        if isinstance(node, ast.ClassDef) and "Params" in node.name:
            fields = []
            for item in node.body:
                if isinstance(item, ast.AnnAssign) and isinstance(item.target, ast.Name):
                    fields.append(item.target.id)
            result[node.name] = fields

    return result


# ---------------------------------------------------------------------------
# Step 3: Call AzureChatOpenAI to generate descriptions
# ---------------------------------------------------------------------------

def call_llm(prompt: str) -> str:
    response = llm.invoke([HumanMessage(content=prompt)])
    return response.content


def generate_descriptions(
    object_type: str,
    field_categories: dict,
    params_classes: dict[str, list[str]],
) -> dict[str, dict[str, str]]:
    """
    Returns per-class, per-field descriptions matching the enforced format:

    RELATION:
      "Filter by <object> UUID. First resolve <name> to UUID via <getTool>. Never pass name/slug directly."

    PLAIN:
      "Filter by <field> e.g. '<example>'. Accepts <type> directly — no UUID needed."
    """
    plain = field_categories.get("plain", [])
    relation = field_categories.get("relation", [])
    multi_relation = field_categories.get("multi_relation", [])

    prompt = f"""You are a Nautobot API documentation expert writing Field() descriptions for Python Pydantic models.

Object type: {object_type}

Field categories for this object (from nautobot_fields_actual.py):
  PLAIN fields (scalar values — no UUID resolution needed):
    {json.dumps(plain)}

  RELATION fields (single FK — UUID required):
    {json.dumps(relation)}

  MULTI_RELATION fields (many-to-many — UUID required):
    {json.dumps(multi_relation)}

Params classes and their fields (from tools.py):
{json.dumps(params_classes, indent=2)}

============================
STRICT OUTPUT FORMAT RULES
============================

1. RELATION or MULTI_RELATION field:
   Template: "Filter by <object> UUID. First resolve <object> name to UUID via <getTool>. Never pass name/slug directly."
   Examples:
     location  -> "Filter by location UUID. First resolve location name to UUID via getLocation. Never pass name/slug directly."
     tenant    -> "Filter by tenant UUID. First resolve tenant name to UUID via getTenant. Never pass name/slug directly."
     rack      -> "Filter by rack UUID. First resolve rack name to UUID via getRack. Never pass name/slug directly."
     status    -> "Filter by status UUID. First resolve status name to UUID via getStatus. Never pass name/slug directly."
     role      -> "Filter by role UUID. First resolve role name to UUID via getRole. Never pass name/slug directly."
     platform  -> "Filter by platform UUID. First resolve platform name to UUID via getPlatform. Never pass name/slug directly."
     vrf       -> "Filter by VRF UUID. First resolve VRF name to UUID via getVrf. Never pass name/slug directly."
     tags      -> "Filter by tag UUID. First resolve tag name to UUID via getTag. Never pass name/slug directly."
     interface -> "Filter by interface UUID. First resolve interface via getInterface. Never pass name/slug directly."
     device    -> "Filter by device UUID. First resolve device name to UUID via getDevice. Never pass name/slug directly."
     provider  -> "Filter by provider UUID. First resolve provider name to UUID via getProvider. Never pass name/slug directly."
     circuit_type -> "Filter by circuit type UUID. First resolve circuit type name to UUID via getCircuitType. Never pass name/slug directly."

2. PLAIN field:
   Template: "Filter by <field label> e.g. '<concrete example>'. Accepts <type> directly — no UUID needed."
   Examples:
     name         -> "Filter by name string e.g. 'my-device'. Accepts string directly — no UUID needed."
     ip_version   -> "Filter by IP version e.g. 4 or 6. Accepts integer directly — no UUID needed."
     mask_length  -> "Filter by prefix length e.g. '24' or '32'. Accepts integer directly — no UUID needed."
     host         -> "Filter by host IP e.g. '10.0.0.1'. Accepts IP string without prefix — no UUID needed."
     address      -> "Filter by address with prefix e.g. '10.0.0.1/32'. Accepts CIDR string directly — no UUID needed."
     prefix       -> "Filter by parent prefix e.g. '10.156.1.0/24'. Accepts CIDR string directly — no UUID needed."
     serial       -> "Filter by serial number string e.g. 'SN123456'. Accepts string directly — no UUID needed."
     asset_tag    -> "Filter by asset tag string e.g. 'ASSET-001'. Accepts string directly — no UUID needed."
     vid          -> "Filter by VLAN ID integer e.g. 100. Accepts integer directly — no UUID needed."
     created      -> "Filter by creation date e.g. '2024-01-01'. Accepts ISO date string directly — no UUID needed."
     last_updated -> "Filter by last updated datetime e.g. '2024-01-01T00:00:00Z'. Accepts ISO datetime string — no UUID needed."
     description  -> "Filter by description text string. Accepts string directly — no UUID needed."
     comments     -> "Filter by comments text string. Accepts string directly — no UUID needed."
     face         -> "Filter by rack face e.g. 'front' or 'rear'. Accepts string directly — no UUID needed."
     position     -> "Filter by rack position integer e.g. 1. Accepts integer directly — no UUID needed."

3. SPECIAL fields (always use these exact descriptions):
   id          -> "UUID of the object."
   limit       -> "Maximum number of records to return. Default 5."
   query       -> "General text search query string."

4. INVALID filter fields (field appears in params but is NOT a valid Nautobot API filter for this object type):
   - A field is invalid if it does not appear in ANY of the three field category lists above AND
     it is not a standard param like id/limit/query.
   - For invalid fields, use:
     "NOT a valid direct filter for {object_type}. To get {object_type} by <field>: use list<RelatedObject>(<field>=<uuid>) first, then pass the result UUID here."
   - Example: 'device' on ip_addresses ->
     "NOT a valid direct filter for ip_addresses. To get IPs of a device: use listInterfaces(device=<uuid>) first, then listIpAddresses(interface=<uuid>)."

5. Do NOT invent resolver tools — use only these known tools:
   getLocation, getTenant, getRack, getStatus, getRole, getPlatform, getVrf, getPrefix,
   getDevice, getInterface, getProvider, getCircuitType, getTag, getDeviceType,
   getCluster, getVirtualChassis, getSoftwareVersion, getSecretsGroup, getConfigContextSchema

6. Keep every description under 35 words. No markdown. No line breaks inside the string.

Return ONLY a valid JSON object — no explanation, no markdown fences:
{{
  "ClassName": {{
    "field_name": "description here",
    ...
  }},
  ...
}}
"""

    raw = call_llm(prompt)
    clean = re.sub(r"```json|```", "", raw).strip()
    return json.loads(clean)


# ---------------------------------------------------------------------------
# Step 4: Patch tools.py with new descriptions
# ---------------------------------------------------------------------------

def patch_tools_file(tools_file: str, descriptions: dict[str, dict[str, str]]):
    """
    Replace Field(...) description= values in-place for each Params class.
    Supports both single-line and multi-line Field(...) definitions.
    Writes the updated file back to disk.
    """
    with open(tools_file) as f:
        source = f.read()

    for class_name, fields in descriptions.items():
        for field_name, desc in fields.items():
            # ✅ re.DOTALL: allows [^)]* to span multiple lines for multi-line Field(...)
            pattern = re.compile(
                rf'({re.escape(field_name)}\s*:\s*\S+\s*=\s*Field\([^)]*?description=")[^"]*(")',
                re.MULTILINE | re.DOTALL,
            )
            escaped_desc = desc.replace("\\", "\\\\").replace('"', '\\"')
            replacement = rf'\g<1>{escaped_desc}\g<2>'
            new_source = pattern.sub(replacement, source)
            if new_source != source:
                print(f"  Updated  {class_name}.{field_name}")
                source = new_source
            else:
                print(f"  Skipped  {class_name}.{field_name} (pattern not matched)")

    with open(tools_file, "w") as f:
        f.write(source)
    print(f"\nPatched: {tools_file}")


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def process_one(tools_file: str, fields_file: str, object_type: str):
    print(f"\n{'='*60}")
    print(f"Processing : {tools_file}")
    print(f"Object type: {object_type}")
    print(f"{'='*60}")

    all_field_categories = parse_field_constants(fields_file)

    # Debug: show what was parsed from the fields file
    if not all_field_categories:
        print("  DEBUG: nautobot_fields_actual.py parsed 0 entries.")
        print("  Ensure constants follow: OBJECTTYPE_PLAIN_FIELDS, OBJECTTYPE_RELATION_FIELDS, etc.")
    else:
        print(f"  Field categories loaded for: {list(all_field_categories.keys())}")

    obj_key = object_type.lower().replace("-", "_")
    field_categories = all_field_categories.get(obj_key, {"plain": [], "relation": [], "multi_relation": []})

    if not any(field_categories.values()):
        print(f"  WARNING: No field categories found for '{obj_key}' in {fields_file}")
        print(f"  Available keys: {list(all_field_categories.keys())}")

    params_classes = parse_params_fields(tools_file)
    print(f"  Found Params classes: {list(params_classes.keys())}")

    print("  Calling Azure OpenAI to generate descriptions ...")
    descriptions = generate_descriptions(obj_key, field_categories, params_classes)

    print("  Patching tools file ...")
    patch_tools_file(tools_file, descriptions)


def main():
    parser = argparse.ArgumentParser(
        description="Generate Field descriptions for Nautobot tools.py files using Azure OpenAI."
    )
    parser.add_argument("--tools", help="Path to a single tools.py file.")
    parser.add_argument("--fields", required=True, help="Path to nautobot_fields_actual.py.")
    parser.add_argument("--object", help="Object type e.g. 'ip_addresses', 'devices', 'prefixes'.")
    parser.add_argument("--all", action="store_true", help="Process all *_tools.py files in --tools-dir.")
    parser.add_argument("--tools-dir", help="Directory containing *_tools.py files (used with --all).")
    args = parser.parse_args()

    if args.all:
        if not args.tools_dir:
            print("ERROR: --tools-dir required with --all")
            sys.exit(1)
        tools_files = [
            os.path.join(args.tools_dir, f)
            for f in os.listdir(args.tools_dir)
            if f.endswith("_tools.py")
        ]
        for tools_file in sorted(tools_files):
            obj_type = os.path.basename(tools_file).replace("_tools.py", "")
            process_one(tools_file, args.fields, obj_type)
    else:
        if not args.tools or not args.object:
            print("ERROR: --tools and --object required (or use --all with --tools-dir)")
            sys.exit(1)
        process_one(args.tools, args.fields, args.object)


if __name__ == "__main__":
    main()