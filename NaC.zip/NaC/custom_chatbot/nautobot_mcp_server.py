"""
Nautobot MCP Server (FastMCP) – DROP-IN REPLACEMENT
"""

from __future__ import annotations

import inspect
import logging
import os
import urllib3
import sys
import threading
from typing import Optional
from dotenv import load_dotenv
import pynautobot
from fastmcp import FastMCP

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("nautobot-mcp")

load_dotenv()

NAUTOBOT_URL = os.getenv("NAUTOBOT_URL")
NAUTOBOT_TOKEN = os.getenv("NAUTOBOT_TOKEN")
print(NAUTOBOT_TOKEN)
VERIFY_SSL = False

if not NAUTOBOT_URL or not NAUTOBOT_TOKEN:
    raise RuntimeError("NAUTOBOT_URL and NAUTOBOT_TOKEN must be set")


api = pynautobot.api(NAUTOBOT_URL, token=NAUTOBOT_TOKEN, threading=True)
api.http_session.verify = VERIFY_SSL
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)



server = FastMCP(
    name="Nautobot",
    instructions="""
You are a Nautobot assistant.
Use tools to query and manage Nautobot objects.
Prefer read-only operations unless explicitly asked to modify data.
"""
)

from tools.nautobot_tools.tools.cables_tools import (
    ListCablesParams,
    GetCableParams,
    list_cables as tools_list_cables,
    count_cables as tools_count_cables,
    get_cable as  tools_get_cable,
)

from tools.nautobot_tools.tools.interfaces_tools import (
    ListInterfacesParams,
    GetInterfaceParams,
    list_interfaces as tools_list_interfaces,
    count_interfaces as tools_count_interfaces,
    get_interface as tools_get_interface,
)

from tools.nautobot_tools.tools.circuit_terminations_tools import (
    ListCircuitTerminationsParams,
    GetCircuitTerminationParams,
    list_circuit_terminations as tools_list_circuit_terminations,
    count_circuit_terminations as tools_count_circuit_terminations,
    get_circuit_termination as tools_get_circuit_termination,
)
from tools.nautobot_tools.tools.circuit_types_tools import (
    ListCircuitTypesParams,
    GetCircuitTypeParams,
    list_circuit_types as tools_list_circuit_types,
    count_circuit_types as tools_count_circuit_types,
    get_circuit_type as tools_get_circuit_type,
)
from tools.nautobot_tools.tools.circuits_tools import (
    ListCircuitsParams,
    GetCircuitParams,
    list_circuits as tools_list_circuits,
    count_circuits as tools_count_circuits,
    get_circuit as tools_get_circuit,
)
from tools.nautobot_tools.tools.cloud_accounts_tools import (
    ListCloudAccountsParams,
    GetCloudAccountParams,
    list_cloud_accounts as tools_list_cloud_accounts,
    get_cloud_account as tools_get_cloud_account,
    count_cloud_account as tools_count_cloud_account,
)
from tools.nautobot_tools.tools.cloud_networks_tools import (
    ListCloudNetworksParams,
    GetCloudNetworkParams,
    list_cloud_networks as tools_list_cloud_networks,
    get_cloud_network as tools_get_cloud_network,
    count_cloud_network as tools_count_cloud_network,
)
from tools.nautobot_tools.tools.cloud_resource_types_tools import (
    ListCloudResourceTypesParams,
    GetCloudResourceTypeParams,
    list_cloud_resource_types as tools_list_cloud_resource_types,
    get_cloud_resource_type as tools_get_cloud_resource_type,
    count_cloud_resource_type as tools_count_cloud_resource_type,
)
from tools.nautobot_tools.tools.cloud_services_tools import (
    ListCloudServicesParams,
    GetCloudServiceParams,
    list_cloud_services as tools_list_cloud_services,
    get_cloud_service as tools_get_cloud_service,
    count_cloud_service as tools_count_cloud_service,
)
from tools.nautobot_tools.tools.rack_space_utilization import (
    GetRackUtilizationParams,
    get_rack_utilization as tools_get_rack_utilization,)

from tools.nautobot_tools.tools.config_contexts_tools import (
    ListConfigContextsParams,
    GetConfigContextParams,
    list_config_contexts as tools_list_config_contexts,
    get_config_context as tools_get_config_context,
    count_config_context as tools_count_config_context,
)
from tools.nautobot_tools.tools.console_ports_tools import (
    ListConsolePortsParams,
    GetConsolePortParams,
    list_console_ports as tools_list_console_ports,
    get_console_port as tools_get_console_port,
    count_console_port as tools_count_console_port,
)
from tools.nautobot_tools.tools.custom_field_choices_tools import (
    ListCustomFieldChoicesParams,
    GetCustomFieldChoiceParams,
    list_custom_field_choices as tools_list_custom_field_choices,
    get_custom_field_choice as tools_get_custom_field_choice,
    count_custom_field_choice as tools_count_custom_field_choice,
)
from tools.nautobot_tools.tools.custom_fields_tools import (
    ListCustomFieldsParams,
    GetCustomFieldParams,
    list_custom_fields as tools_list_custom_fields,
    get_custom_field as tools_get_custom_field,
    count_custom_field as tools_count_custom_field,
)
from tools.nautobot_tools.tools.custom_links_tools import (
    ListCustomLinksParams,
    GetCustomLinkParams,
    list_custom_links as tools_list_custom_links,
    get_custom_link as tools_get_custom_link,
    count_custom_link as tools_count_custom_link,
)
from tools.nautobot_tools.tools.device_types_tools import (
    ListDeviceTypesParams,
    GetDeviceTypeParams,
    list_device_types as tools_list_device_types,
    count_device_types as tools_count_device_types,
    get_device_type as tools_get_device_type,
)


from tools.nautobot_tools.tools.devices_tools import (
    ListDevicesParams as ToolsListDevicesParams,
    GetDeviceParams as ToolsGetDeviceParams,
    list_devices as tools_list_devices,
    count_devices as tools_count_devices,
    get_device as tools_get_device,
)
from tools.nautobot_tools.tools.export_templates_tools import (
    ListExportTemplatesParams,
    GetExportTemplateParams,
    list_export_templates as tools_list_export_templates,
    get_export_template as tools_get_export_template,
    count_export_template as tools_count_export_template,

)
from tools.nautobot_tools.tools.inventory_items_tools import (
    ListInventoryItemsParams,
    GetInventoryItemParams,
    list_inventory_items as tools_list_inventory_items,
    get_inventory_item as tools_get_inventory_item,
    count_inventory_item as tools_count_inventory_item,
)
from tools.nautobot_tools.tools.ip_addresses_tools import (
    ListIpAddresssParams,
    GetIpAddressParams,
    list_ip_addresses as tools_list_ip_addresses,
    count_ip_addresses as tools_count_ip_addresses,
    get_ip_address as tools_get_ip_address,
)
from tools.nautobot_tools.tools.job_results_tools import (
    ListJobResultsParams,
    GetJobResultParams,
    list_job_results as tools_list_job_results,
    get_job_result as tools_get_job_result,
    count_job_result as tools_count_job_result,
)
from tools.nautobot_tools.tools.jobs_tools import (
    ListJobsParams,
    GetJobParams,
    list_jobs as tools_list_jobs,
    get_job as tools_get_job,
)
from tools.nautobot_tools.tools.locations_tools import (
    ListLocationsParams as ToolsListLocationsParams,
    GetLocationParams as ToolsGetLocationParams,
    list_locations as tools_list_locations,
    count_locations as tools_count_locations,
    get_location as tools_get_location,
)
from tools.nautobot_tools.tools.manufacturers_tools import (
    ListManufacturersParams,
    GetManufacturerParams,
    list_manufacturers as tools_list_manufacturers,
    get_manufacturer as tools_get_manufacturer,
    count_manufacturer as tools_count_manufacturer,
)
from tools.nautobot_tools.tools.module_types_tools import (
    ListModuleTypesParams,
    GetModuleTypeParams,
    list_module_types as tools_list_module_types,
    get_module_type as tools_get_module_type,
    count_module_type as tools_count_module_type,
)
from tools.nautobot_tools.tools.modules_tools import (
    ListModulesParams,
    GetModuleParams,
    list_modules as tools_list_modules,
    get_module as tools_get_module,
    count_module as tools_count_module,
)
from tools.nautobot_tools.tools.object_changes_tools import (
    ListObjectChangesParams,
    GetObjectChangeParams,
    list_object_changes as tools_list_object_changes,
    get_object_change as tools_get_object_change,
    count_object_change as tools_count_object_change,

)
from tools.nautobot_tools.tools.permissions_tools import (
    ListPermissionsParams,
    GetPermissionParams,
    list_permissions as tools_list_permissions,
    get_permission as tools_get_permission,
    count_permission as tools_count_permission,
)
from tools.nautobot_tools.tools.platforms_tools import (
    ListPlatformsParams,
    GetPlatformParams,
    list_platforms as tools_list_platforms,
    get_platform as tools_get_platform,
    count_platform as tools_count_platform,
)
from tools.nautobot_tools.tools.power_feeds_tools import (
    ListPowerFeedsParams,
    GetPowerFeedParams,
    list_power_feeds as tools_list_power_feeds,
    get_power_feed as tools_get_power_feed,
    count_power_feed as tools_count_power_feed,
)

from tools.nautobot_tools.tools.device_redundancy_group_tools import (
    ListDeviceRedundancyGroupsParams,
    GetDeviceRedundancyGroupParams,
    list_device_redundancy_groups as tools_list_device_redundancy_groups,
    get_device_redundancy_group as tools_get_device_redundancy_group,
    count_device_redundancy_group as tools_count_device_redundancy_group,
)

from tools.nautobot_tools.tools.controller_tools import (
    ListControllersParams,
    GetControllerParams,
    list_controller as tools_list_controller,
    get_controller as tools_get_controller,
    count_controller as tools_count_controller,
)

from tools.nautobot_tools.tools.power_panels_tools import (
    ListPowerPanelsParams,
    GetPowerPanelParams,
    list_power_panels as tools_list_power_panels,
    get_power_panel as tools_get_power_panel,
    count_power_panel as tools_count_power_panel,
)
from tools.nautobot_tools.tools.prefixes_tools import (
    ListPrefixesParams,
    GetPrefixParams,
    list_prefixes as tools_list_prefixes,
    count_prefixes as tools_count_prefixes,
    get_prefix as tools_get_prefix,
)
from tools.nautobot_tools.tools.providers_tools import (
    ListProvidersParams,
    GetProviderParams,
    list_providers as tools_list_providers,
    get_provider as tools_get_provider,
    count_provider as tools_count_provider,
)
from tools.nautobot_tools.tools.racks_tools import (
    ListRacksParams,
    GetRackParams,
    list_racks as tools_list_racks,
    count_racks as tools_count_racks,
    get_rack as tools_get_rack,
)
from tools.nautobot_tools.tools.secrets_tools import (
    ListSecretsParams,
    GetSecretParams,
    list_secrets as tools_list_secrets,
    get_secret as tools_get_secret,
    count_secret as tools_count_secret,
)
from tools.nautobot_tools.tools.statuses_tools import (
    ListStatussParams,
    GetStatusParams,
    list_statuses as tools_list_statuses,
    get_status as tools_get_status,
    count_status as tools_count_status,

)
from tools.nautobot_tools.tools.tags_tools import (
    ListTagsParams,
    GetTagParams,
    list_tags as tools_list_tags,
    get_tag as tools_get_tag,
    count_tag as tools_count_tag,

)
from tools.nautobot_tools.tools.tenant_groups_tools import (
    ListTenantGroupsParams,
    GetTenantGroupParams,
    list_tenant_groups as tools_list_tenant_groups,
    get_tenant_group as tools_get_tenant_group,
    count_tenant_group as tools_count_tenant_group,
)
from tools.nautobot_tools.tools.tenants_tools import (
    ListTenantsParams,
    GetTenantParams,
    list_tenants as tools_list_tenants,
    get_tenant as tools_get_tenant,
    count_tenant as tools_count_tenant,
)
from tools.nautobot_tools.tools.tokens_tools import (
    ListTokensParams,
    GetTokenParams,
    list_tokens as tools_list_tokens,
    get_token as tools_get_token,
    count_token as tools_count_token,
)
from tools.nautobot_tools.tools.virtual_chassis_tools import (
    ListVirtualChassissParams,
    GetVirtualChassisParams,
    list_virtual_chassis as tools_list_virtual_chassis,
    count_virtual_chassis as tools_count_virtual_chassis,
    get_virtual_chassis as tools_get_virtual_chassis,
)
from tools.nautobot_tools.tools.vlan_groups_tools import (
    ListVlanGroupsParams,
    GetVlanGroupParams,
    list_vlan_groups as tools_list_vlan_groups,
    count_vlan_groups as tools_count_vlan_groups,
    get_vlan_group as tools_get_vlan_group,
)
from tools.nautobot_tools.tools.vlans_tools import (
    ListVlansParams as ToolsListVlansParams,
    GetVlanParams as ToolsGetVlanParams,
    list_vlans as tools_list_vlans,
    count_vlans as tools_count_vlans,
    get_vlan as tools_get_vlan,
)
from tools.nautobot_tools.tools.vrfs_tools import (
    ListVrfsParams,
    GetVrfParams,
    list_vrfs as tools_list_vrfs,
    count_vrfs as tools_count_vrfs,
    get_vrf as tools_get_vrf,
)


def register(tool_fn):
    """Register a tool on the read-only server."""
    return server.tool()(tool_fn)


def _to_camel(name: str) -> str:
    parts = name.split("_")
    return parts[0] + "".join(p.title() for p in parts[1:])


def _default_docstring(tool_name: str) -> str:
    if tool_name.startswith("list"):
        return f"List {tool_name[4:].replace('_', ' ').strip()}."
    if tool_name.startswith("get"):
        return f"Get {tool_name[3:].replace('_', ' ').strip()}."
    if tool_name.startswith("create"):
        return f"Create {tool_name[6:].replace('_', ' ').strip()}."
    if tool_name.startswith("update"):
        return f"Update {tool_name[6:].replace('_', ' ').strip()}."
    if tool_name.startswith("delete"):
        return f"Delete {tool_name[6:].replace('_', ' ').strip()}."
    return f"Run {tool_name}."


_DOCSTRING_OVERRIDES = {
    "listDevices": "List devices from Nautobot with optional filters.",
    "countDevices": "Count devices from Nautobot with optional filters.",
    "getDevice": "Get a device by id or name.",
    "createDevice": "Create a device (requires write privileges).",
    "updateDevice": "Update a device by id or name.",
    "deleteDevice": "Delete a device by id or name.",
    "listLocations": "List locations from Nautobot with optional filters.",
    "getLocation": "Get a location by id, name, or slug.",
    "createLocation": "Create a location.",
    "updateLocation": "Update a location by id, name, or slug.",
    "deleteLocation": "Delete a location by id or name.",
    "listVlans": "List VLANs from Nautobot using pydantic params.",
    "countVlans": "Count VLANs from Nautobot using pydantic params.",
    "getVlan": "Get a single VLAN by id or name using pydantic params.",
    "createVlan": "Create a VLAN (requires write privileges).",
    "updateVlan": "Update a VLAN by id or name.",
    "deleteVlan": "Delete a VLAN by id or name.",
    "listCircuitTerminations": "List circuit terminations.",
    "getCircuitTermination": "Get circuit termination.",
    "createCircuitTermination": "Create a circuit termination.",
    "updateCircuitTermination": "Update a circuit termination.",
    "deleteCircuitTermination": "Delete a circuit termination.",
}


def _register_model_tool(tool_fn, params_model, name: Optional[str] = None, server_obj: Optional[FastMCP] = None):
    tool_name = name or _to_camel(tool_fn.__name__)

    if server_obj is None:
        server_obj = server

    def _tool(**kwargs):
        params = params_model(**kwargs)
        return tool_fn(api, params)

    _tool.__name__ = tool_name
    _tool.__qualname__ = tool_name
    _tool.__doc__ = (
        _DOCSTRING_OVERRIDES.get(tool_name)
        or tool_fn.__doc__
        or _default_docstring(tool_name)
    )

    fields = getattr(params_model, "__fields__", None) or getattr(params_model, "model_fields", None) or {}
    parameters = []
    annotations: dict = {}
    for field_name, field in fields.items():
        if hasattr(field, "required"):
            required = field.required
            default = inspect._empty if required else field.default
            annotation = getattr(field, "outer_type_", inspect._empty)
        else:  # Pydantic v2
            required = field.is_required()
            default = inspect._empty if required else field.default
            annotation = field.annotation if field.annotation is not None else inspect._empty

        if annotation is not inspect._empty:
            annotations[field_name] = annotation

        parameters.append(
            inspect.Parameter(
                field_name,
                inspect.Parameter.POSITIONAL_OR_KEYWORD,
                default=default,
                annotation=annotation,
            )
        )

    if annotations:
        _tool.__annotations__ = annotations

    _tool.__signature__ = inspect.Signature(parameters)

    if tool_name in globals():
        return globals()[tool_name]

    return server_obj.tool()(_tool)

@register
def listLocations(
    name: Optional[str] = None,
    natural_slug: Optional[str] = None,
    location_type: Optional[str] = None,
    parent:Optional[str] = None,
    status: Optional[str] = None,
    query: Optional[str] = None,
    limit: int = 5,
):
    """List locations from Nautobot with optional filters."""
    params = ToolsListLocationsParams(
        name=name,
        natural_slug=natural_slug,
        location_type=location_type,
        parent=parent,
        status=status,
        query=query,
        limit=limit,
    )
    return tools_list_locations(api, params)

@register
def getLocation(
    id: Optional[str] = None,
    name: Optional[str] = None,
    natural_slug: Optional[str] = None,
):
    """Get a location by id, name, or slug."""
    params = ToolsGetLocationParams(
        id=id,
        name=name,
        natural_slug=natural_slug,
    )
    return tools_get_location(api, params)

@register
def listVlans(
    name: Optional[str] = None,
    query: Optional[str] = None,
    vlan_group:Optional[str] = None,
    location:Optional[str] = None,
    role:Optional[str] = None,
    status:Optional[str] = None,
    tenant:Optional[str] = None,
    platform:Optional[str] = None,
    device_type:Optional[str] = None,
    tag:Optional[str] = None,
    limit: int = 5,
):
    """List VLANs from Nautobot using pydantic params."""
    params = ToolsListVlansParams(
        name=name,
        query=query,
        vlan_group=vlan_group,
        location=location,
        role=role,
        status=status,
        tenant=tenant,
        platform=platform,
        device_type=device_type,
        tag=tag,
        limit=limit,
    )
    return tools_list_vlans(api, params)
# @register
# def countVlans(
#     name: Optional[str] = None,
#     query: Optional[str] = None,
#     vlan_group:Optional[str] = None,
#     location:Optional[str] = None,
#     role:Optional[str] = None,
#     status:Optional[str] = None,
#     tenant:Optional[str] = None,
#     platform:Optional[str] = None,
#     device_type:Optional[str] = None,
#     tag:Optional[str] = None,
#     limit: int = 5,
# ):
#     """List VLANs from Nautobot using pydantic params."""
#     params = ToolsListVlansParams(
#         name=name,
#         query=query,
#         vlan_group=vlan_group,
#         location=location,
#         role=role,
#         status=status,
#         tenant=tenant,
#         platform=platform,
#         device_type=device_type,
#         tag=tag,
#         limit=limit,
#     )
#     return tools_count_vlans(api, params)

@register
def getVlan(
    id: Optional[str] = None,
    name: Optional[str] = None,
):
    """Get a single VLAN by id or name using pydantic params."""
    params = ToolsGetVlanParams(
        id=id,
        name=name,
    )
    return tools_get_vlan(api, params)

@register
def listCircuitTerminations(
    circuit: Optional[str] = None,
    location: Optional[str] = None,
    term_side: Optional[str] = None,
    query: Optional[str] = None,
    limit: int = 5,
):
    """List circuit terminations."""
    params = ListCircuitTerminationsParams(
        circuit=circuit,
        location=location,
        term_side=term_side,
        query=query,
        limit=limit,
    )
    return tools_list_circuit_terminations(api, params)

@register
def getCircuitTermination(
    id: Optional[str] = None,
    term_side: Optional[str] = None,
    circuit: Optional[str] = None,
):
    """Get circuit termination."""
    params = GetCircuitTerminationParams(
        id=id,
        term_side=term_side,
        circuit=circuit,
    )
    return tools_get_circuit_termination(api, params)

# --- Generic count tool registry -------------------------------------------
COUNT_REGISTRY: dict[str, tuple] = {
    "modules": (tools_count_module,ListModulesParams),
    # "object_changes": (tools_count_object_change,ListObjectChangesParams),
    "platforms": (tools_count_platform,ListPlatformsParams),
    "permissions": (tools_count_permission,ListPermissionsParams),
    # "secrets": (tools_count_secret,ListSecretsParams),
    # "statuses": (tools_count_status,ListStatussParams),
    # "tags": (tools_count_tag,ListTagsParams),
    # "cloud_accounts" : (tools_count_cloud_account, ListCloudAccountsParams),
    # "cloud_networks": (tools_count_cloud_network, ListCloudNetworksParams) , 
    # "cloud_resource_types":(tools_count_cloud_resource_type, ListCloudResourceTypesParams),
    # "cloud_services": (tools_count_cloud_service,ListCloudServicesParams),
    # "config_contexts": (tools_count_config_context,ListConfigContextsParams),
    # "console_ports": (tools_count_console_port,ListConsolePortsParams),
    # "custom_field_choices": (tools_count_custom_field_choice,ListCustomFieldChoicesParams),
    # "custom_fields": (tools_count_custom_field,ListCustomFieldsParams),
    # "custom_links": (tools_count_custom_link, ListCustomLinksParams),
    # "export_templates": (tools_count_export_template,ListExportTemplatesParams),
    # "inventory_items": (tools_count_inventory_item,ListInventoryItemsParams),
    # "job_results": (tools_count_job_result,ListJobResultsParams),
    "cables": (tools_count_cables, ListCablesParams),
    "devices": (tools_count_devices, ToolsListDevicesParams),
    "circuit_types": (tools_count_circuit_types, ListCircuitTypesParams),
    "device_redundancy_groups": (tools_count_device_redundancy_group, ListDeviceRedundancyGroupsParams),
    "controllers": (tools_count_controller, ListControllersParams),
    "circuit_terminations": (tools_count_circuit_terminations, ListCircuitTerminationsParams),
    "circuits": (tools_count_circuits, ListCircuitsParams),
    "device_types": (tools_count_device_types, ListDeviceTypesParams),
    # "interfaces": (tools_count_interfaces, ListInterfacesParams),
    "ip_addresses": (tools_count_ip_addresses, ListIpAddresssParams),
    "locations": (tools_count_locations, ToolsListLocationsParams),
    "manufacturers": (tools_count_manufacturer, ListManufacturersParams),
    "module_types": (tools_count_module_type, ListModuleTypesParams),
    "power_feeds": (tools_count_power_feed, ListPowerFeedsParams),
    "power_panels": (tools_count_power_panel, ListPowerPanelsParams),
    "prefixes": (tools_count_prefixes, ListPrefixesParams),
    "providers": (tools_count_provider, ListProvidersParams),
    "racks": (tools_count_racks, ListRacksParams),
    "tenants": (tools_count_tenant, ListTenantsParams),
    "virtual_chassis": (tools_count_virtual_chassis, ListVirtualChassissParams),
    "vlan_groups": (tools_count_vlan_groups, ListVlanGroupsParams),
    "vrfs": (tools_count_vrfs, ListVrfsParams),
    "vlans": (tools_count_vlans, ToolsListVlansParams),
}


def _count_field_docs() -> str:
    lines = []
    for res, (_, model) in COUNT_REGISTRY.items():
        schema = model.model_json_schema()
        fields = ", ".join(f for f in schema.get("properties", {}) if f != "limit")
        lines.append(f"  - {res}: {fields}")
    return "\n".join(lines)


@register
def countRecords(resource: str, filters: dict = {}) -> dict:
    """Placeholder — docstring is set dynamically below."""
    entry = COUNT_REGISTRY.get(resource)
    if entry is None:
        return {
            "success": False,
            "message": f"Unknown resource '{resource}'. Valid: {sorted(COUNT_REGISTRY)}",
        }

    count_fn, params_model = entry
    try:
        params = params_model(**filters)
    except Exception as e:  # pydantic.ValidationError
        return {"success": False, "message": f"Invalid filters for '{resource}': {e}"}

    return count_fn(api, params)


countRecords.__doc__ = (
    "Count Nautobot records for a given resource type.\n\n"
    f"resource: one of {sorted(COUNT_REGISTRY)}\n"
    "filters: field/value pairs valid for that resource (see below).\n\n"
    "Per-resource filter fields:\n" + _count_field_docs()
)




_AUTO_TOOL_REGISTRATIONS = [
    (tools_get_rack_utilization, GetRackUtilizationParams),
    (tools_list_cables, ListCablesParams),
    (tools_get_cable, GetCableParams),
    (tools_list_devices, ToolsListDevicesParams),
    (tools_get_device, ToolsGetDeviceParams),
    (tools_list_circuit_types, ListCircuitTypesParams),
    (tools_get_circuit_type, GetCircuitTypeParams),
    (tools_get_device_redundancy_group, GetDeviceRedundancyGroupParams),
    (tools_list_device_redundancy_groups, ListDeviceRedundancyGroupsParams),
    (tools_list_controller,ListControllersParams),
    (tools_get_controller,GetControllerParams),
    (tools_list_circuits, ListCircuitsParams),
    (tools_get_circuit, GetCircuitParams),
    (tools_list_cloud_accounts, ListCloudAccountsParams),
    (tools_get_cloud_account, GetCloudAccountParams),
    (tools_list_cloud_networks, ListCloudNetworksParams),
    (tools_get_cloud_network, GetCloudNetworkParams),
    (tools_list_cloud_resource_types, ListCloudResourceTypesParams),
    (tools_get_cloud_resource_type, GetCloudResourceTypeParams),
    (tools_list_cloud_services, ListCloudServicesParams),
    (tools_get_cloud_service, GetCloudServiceParams),
    (tools_list_config_contexts, ListConfigContextsParams),
    (tools_get_config_context, GetConfigContextParams),
    (tools_list_console_ports, ListConsolePortsParams),
    # (tools_get_console_port, GetConsolePortParams),
    # (tools_list_custom_field_choices, ListCustomFieldChoicesParams),
    # (tools_get_custom_field_choice, GetCustomFieldChoiceParams),
    # (tools_list_custom_fields, ListCustomFieldsParams),
    # (tools_get_custom_field, GetCustomFieldParams),
    # (tools_list_custom_links, ListCustomLinksParams),
    # (tools_get_custom_link, GetCustomLinkParams),
    (tools_list_devices, ToolsListDevicesParams),
    (tools_get_device, ToolsGetDeviceParams),
    (tools_list_device_types, ListDeviceTypesParams),
    (tools_get_device_type, GetDeviceTypeParams),
    (tools_list_export_templates, ListExportTemplatesParams),
    (tools_get_export_template, GetExportTemplateParams),
    (tools_list_interfaces, ListInterfacesParams),
    (tools_get_interface, GetInterfaceParams),
    (tools_count_interfaces, ListInterfacesParams),
    # (tools_list_inventory_items, ListInventoryItemsParams),
    # (tools_get_inventory_item, GetInventoryItemParams),
    (tools_list_ip_addresses, ListIpAddresssParams),
    (tools_get_ip_address, GetIpAddressParams),
    # (tools_list_job_results, ListJobResultsParams),
    # (tools_get_job_result, GetJobResultParams),
    # (tools_list_jobs, ListJobsParams),
    # (tools_get_job, GetJobParams),
    (tools_list_manufacturers, ListManufacturersParams),
    (tools_get_manufacturer, GetManufacturerParams),
    (tools_list_module_types, ListModuleTypesParams),
    (tools_get_module_type, GetModuleTypeParams),
    (tools_list_modules, ListModulesParams),
    (tools_get_module, GetModuleParams),
    # (tools_list_object_changes, ListObjectChangesParams),
    # (tools_count_object_change,ListObjectChangesParams),
    # (tools_get_object_change, GetObjectChangeParams),
    # (tools_list_permissions, ListPermissionsParams),
    # (tools_get_permission, GetPermissionParams),
    # (tools_list_platforms, ListPlatformsParams),
    # (tools_get_platform, GetPlatformParams),
    (tools_list_power_feeds, ListPowerFeedsParams),
    # (tools_count_power_feed,ListPowerFeedsParams),
    (tools_get_power_feed, GetPowerFeedParams),
    (tools_list_power_panels, ListPowerPanelsParams),
    # (tools_count_power_panel,ListPowerPanelsParams),
    (tools_get_power_panel, GetPowerPanelParams),
    (tools_list_prefixes, ListPrefixesParams),
    # (tools_count_prefixes, ListPrefixesParams),
    (tools_get_prefix, GetPrefixParams),
    (tools_list_providers, ListProvidersParams),
    # (tools_count_provider,ListProvidersParams),
    (tools_get_provider, GetProviderParams),
    (tools_list_racks, ListRacksParams),
    # (tools_count_racks, ListRacksParams),
    (tools_get_rack, GetRackParams),
    # (tools_list_secrets, ListSecretsParams),
    # (tools_count_secret,ListSecretsParams),
    # (tools_get_secret, GetSecretParams),
    # (tools_list_statuses, ListStatussParams),
    # (tools_count_status,ListStatussParams),
    # (tools_get_status, GetStatusParams),
    # (tools_list_tags, ListTagsParams),
    # (tools_count_tag,ListTagsParams),
    # (tools_get_tag, GetTagParams),
    (tools_list_tenants, ListTenantsParams),
    # (tools_count_tenant,ListTenantsParams),
    (tools_get_tenant, GetTenantParams),
    # (tools_list_tenant_groups, ListTenantGroupsParams),
    # (tools_count_tenant_group,ListTenantGroupsParams),
    # (tools_get_tenant_group, GetTenantGroupParams),
    # (tools_list_tokens, ListTokensParams),
    # (tools_count_token,ListTokensParams),
    (tools_get_token, GetTokenParams),
    (tools_list_virtual_chassis, ListVirtualChassissParams),
    # (tools_count_virtual_chassis, ListVirtualChassissParams),
    (tools_get_virtual_chassis, GetVirtualChassisParams),
    (tools_list_vlan_groups, ListVlanGroupsParams),
    # (tools_count_vlan_groups, ListVlanGroupsParams),
    (tools_get_vlan_group, GetVlanGroupParams),
    (tools_list_vrfs, ListVrfsParams),
    # (tools_count_vrfs, ListVrfsParams),
    (tools_get_vrf, GetVrfParams),
]

_AUTO_TOOL_REGISTRATIONS_READ_ONLY = [
    tool
    for tool in _AUTO_TOOL_REGISTRATIONS
    if not _to_camel(tool[0].__name__).startswith(("create", "update", "delete"))
]


for tool_fn, params_model in _AUTO_TOOL_REGISTRATIONS_READ_ONLY:
    tool_name = _to_camel(tool_fn.__name__)
    if tool_name in globals():
        continue
    _register_model_tool(tool_fn, params_model, tool_name)


if __name__ == "__main__":
    mode = sys.argv[1] if len(sys.argv) > 1 else "both"

    def _run_read_only():
        logger.info("Starting Nautobot read-only MCP server on port 3001")
        server.run(transport="streamable-http", host="0.0.0.0", port=3001)

    if mode == "ro":
        _run_read_only()
  
    else:
        t_ro = threading.Thread(target=_run_read_only, daemon=True)
        t_ro.start()
        t_ro.join()




