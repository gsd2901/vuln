print("Applying SSOT cache fix...")  # This will print when imported

# Import the class we need to patch
try:
    from nautobot_device_onboarding.diffsync.adapters.sync_network_data_adapters import SyncDevicesNautobotAdapter
    
    # Save the original __init__ method
    original_init = SyncDevicesNautobotAdapter.__init__
    
    # Create a new __init__ that adds the cache
    def patched_init(self, *args, **kwargs):
        original_init(self, *args, **kwargs)
        if not hasattr(self, 'cache'):
            self.cache = {}
            print("Added cache attribute to SyncDevicesNautobotAdapter")
    
    # Replace the __init__ method
    SyncDevicesNautobotAdapter.__init__ = patched_init
    print("SSOT cache fix applied successfully")
    
except ImportError as e:
    print(f"Could not apply SSOT cache fix: {e}")