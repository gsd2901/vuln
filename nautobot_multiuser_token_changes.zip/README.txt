Files in this package and where they go relative to the Nautobot project root:

  custom_chatbot/nautobot_mcp_server.py
  custom_chatbot/views.py
  custom_chatbot/tools/nautobot_tools/tools/nautobot_relation_utils.py
  custom_helpers.py

Plus ENV_CHANGE_INSTRUCTIONS.txt — a one-line manual edit to prod's .env
(no file to copy for that one).

Before deploying:
  1. Diff each file against prod's current copy first, in case prod has
     drifted from this dev checkout independently.
  2. Confirm the fastmcp version installed in prod supports
     fastmcp.server.dependencies.get_http_headers() (nautobot_mcp_server.py
     depends on it for per-user token routing).
  3. Restart both the Nautobot/gunicorn process (views.py, custom_helpers.py,
     nautobot_relation_utils.py) and the MCP server process
     (nautobot_mcp_server.py) after deploying — both changed.
