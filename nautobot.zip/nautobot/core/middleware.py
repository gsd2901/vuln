from zoneinfo import ZoneInfo

from django.conf import settings
from django.contrib.auth.middleware import RemoteUserMiddleware as RemoteUserMiddleware_
from django.db import ProgrammingError
from django.http import Http404
from django.urls import resolve
from django.urls.exceptions import Resolver404
from django.utils import timezone
from django.utils.deprecation import MiddlewareMixin

from custom_helpers import sanitize_html
from django.http import QueryDict
from django.http import HttpResponseNotAllowed

from nautobot.core.api.utils import is_api_request, rest_api_server_error
from nautobot.core.authentication import (
    assign_groups_to_user,
    assign_permissions_to_user,
)
from nautobot.core.settings_funcs import (
    ldap_auth_enabled,
    remote_auth_enabled,
    sso_auth_enabled,
)
from nautobot.core.views import server_error
from nautobot.extras.choices import ObjectChangeEventContextChoices
from nautobot.extras.context_managers import web_request_context

from django.core.cache import cache
from django.http import JsonResponse, HttpResponse
import time


class RemoteUserMiddleware(RemoteUserMiddleware_):
    """
    Custom implementation of Django's RemoteUserMiddleware which allows for a user-configurable HTTP header name.
    """

    force_logout_if_no_header = False

    @property
    def header(self):
        return settings.REMOTE_AUTH_HEADER

    def process_request(self, request):
        # Bypass middleware if remote authentication is not enabled
        if not remote_auth_enabled(auth_backends=settings.AUTHENTICATION_BACKENDS):
            return None

        return super().process_request(request)


class ExternalAuthMiddleware(MiddlewareMixin):
    """
    Custom implementation of Django's AuthenticationMiddleware used to set permissions for
    remotely-authenticated users.

    This must inherit from `MiddlewareMixin` to support Django middleware magic.
    """

    def process_request(self, request):
        # Bypass middleware if external authentication is not enabled
        # Session middleware handles attaching the user to the request
        backends_enabled = (
            remote_auth_enabled(auth_backends=settings.AUTHENTICATION_BACKENDS),
            sso_auth_enabled(auth_backends=settings.AUTHENTICATION_BACKENDS),
            ldap_auth_enabled(auth_backends=settings.AUTHENTICATION_BACKENDS),
        )
        if not any(backends_enabled) or not request.user.is_authenticated:
            return

        if settings.EXTERNAL_AUTH_DEFAULT_GROUPS:
            # Assign default groups to the user
            assign_groups_to_user(request.user, settings.EXTERNAL_AUTH_DEFAULT_GROUPS)

        if settings.EXTERNAL_AUTH_DEFAULT_PERMISSIONS:
            # Assign default object permissions to the user
            assign_permissions_to_user(request.user, settings.EXTERNAL_AUTH_DEFAULT_PERMISSIONS)


class ObjectChangeMiddleware:
    """
    This middleware performs three functions in response to an object being created, updated, or deleted:

        1. Create an ObjectChange to reflect the modification to the object in the changelog.
        2. Enqueue any relevant webhooks.
        3. Increment the metric counter for the event type.

    The post_save and post_delete signals are employed to catch object modifications, however changes are recorded a bit
    differently for each. Objects being saved are cached into thread-local storage for action *after* the response has
    completed. This ensures that serialization of the object is performed only after any related objects (e.g. tags)
    have been created. Conversely, deletions are acted upon immediately, so that the serialized representation of the
    object is recorded before it (and any related objects) are actually deleted from the database.
    """

    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        # Determine the resolved path of the request that initiated the change
        try:
            change_context_detail = resolve(request.path).view_name
        except Resolver404:
            change_context_detail = ""

        # Bypass change logging for health check requests to prevent database connection exhaustion
        if change_context_detail == "health_check:health_check_home":
            response = self.get_response(request)
            return response

        # Process the request with change logging enabled
        with web_request_context(
            request.user,
            context_detail=change_context_detail,
            context=ObjectChangeEventContextChoices.CONTEXT_WEB,
            request=request,
        ):
            response = self.get_response(request)

        return response


class ExceptionHandlingMiddleware:
    """
    Intercept certain exceptions which are likely indicative of installation issues and provide helpful instructions
    to the user.
    """

    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        return self.get_response(request)

    def process_exception(self, request, exception):
        # Don't catch exceptions when in debug mode
        if settings.DEBUG:
            return None

        # Ignore Http404s (defer to Django's built-in 404 handling)
        if isinstance(exception, Http404):
            return None

        # Handle exceptions that occur from REST API requests
        if is_api_request(request):
            return rest_api_server_error(request)

        # Determine the type of exception. If it's a common issue, return a custom error page with instructions.
        custom_template = None
        if isinstance(exception, ProgrammingError):
            custom_template = "exceptions/programming_error.html"
        elif isinstance(exception, ImportError):
            custom_template = "exceptions/import_error.html"
        elif isinstance(exception, PermissionError):
            custom_template = "exceptions/permission_error.html"

        # Return a custom error message, or fall back to Django's default 500 error handling
        if custom_template:
            return server_error(request, template_name=custom_template)

        return None


class UserDefinedTimeZoneMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        if request.user.is_authenticated:
            if tzname := request.user.get_config("timezone"):
                timezone.activate(ZoneInfo(tzname))
            else:
                timezone.deactivate()
        return self.get_response(request)
    
class SanitizePostMiddleware(MiddlewareMixin):
    def process_request(self, request):
        if request.method == 'POST':
            sanitized_post = {}
            for key, value in request.POST.items():
                sanitized_value = self.sanitize(value)
                sanitized_post[key] = sanitized_value

            # Rebuild immutable POST dict with sanitized data
            request.POST = QueryDict('', mutable=True)
            request.POST.update(sanitized_post)

    def sanitize(self, value):
        if isinstance(value, str):
            # Strip leading/trailing spaces and sanitize HTML
            return sanitize_html(value.strip())
        return value
    
class SecurityHeadersMiddleware(MiddlewareMixin):
    def process_response(self, request, response):
        response['X-Content-Type-Options'] = 'nosniff'
        response['Strict-Transport-Security'] = 'max-age=31536000; includeSubDomains'
        response["Content-Security-Policy"] = (
            "default-src 'self'; "
            "script-src 'self' 'unsafe-inline' https://cdnjs.cloudflare.com  https://code.jquery.com https://cdn.jsdelivr.net; "
            "font-src 'self' 'unsafe-inline' https://cdnjs.cloudflare.com; "
            "style-src 'self' 'unsafe-inline'  https://cdnjs.cloudflare.com;"
            "img-src 'self' data:; "
            "object-src 'none'; "
            "frame-ancestors 'none'; "
            "base-uri 'self'; "
        )
        response["Permissions-Policy"] = (
            "camera=(), microphone=(), geolocation=(), interest-cohort=()"
        )
        response["Cross-Origin-Embedder-Policy"] = "require-corp"
        response["Cross-Origin-Resource-Policy"] = "same-origin"
        return response
    
    def __call__(self, request):
        response = self.get_response(request)
        # Remove or modify headers
        response.headers.pop('Server', None)
        response.headers.pop('X-Powered-By', None)
        return response

    


class BlockHttpMethodsMiddleware:
    ALLOWED_METHODS = {"GET", "POST", "PUT","PATCH","DELETE","HEAD"}

    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        if request.method not in self.ALLOWED_METHODS:
            return HttpResponseNotAllowed(self.ALLOWED_METHODS)
        return self.get_response(request)
    

class GlobalRateLimitMiddleware:
    RATE_LIMIT = 1000  # requests
    TIME_WINDOW = 60  # seconds

    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        identifier = (
            request.user.username
            if request.user.is_authenticated
            else request.META.get('HTTP_X_FORWARDED_FOR', request.META.get('REMOTE_ADDR', 'unknown'))
        )

        cache_key = f"rate-limit:{identifier}"
        request_times = cache.get(cache_key)

        if not request_times:
            request_times = []

        now = time.time()

        request_times = [t for t in request_times if now - t < self.TIME_WINDOW]

        if len(request_times) >= self.RATE_LIMIT:
    
            if request.headers.get('Accept') == 'application/json' or request.path.startswith('/api/'):
                return JsonResponse({'detail': 'Rate limit exceeded'}, status=429)
            else:
                return HttpResponse(
                    "<h1>429 Too Many Requests</h1><p>You have exceeded the rate limit. Please try again later.</p>",
                    status=429
                )

        request_times.append(now)
        cache.set(cache_key, request_times, timeout=self.TIME_WINDOW)

        return self.get_response(request)
