import requests
import json
import openai  # or use local LLM alternative
from typing import Dict, Any
import re
import os
import json
import logging
import requests
from langchain_community.agent_toolkits.openapi.spec import reduce_openapi_spec
from langchain_community.chat_models import ChatOpenAI
from langchain.agents import AgentExecutor, create_react_agent
from langchain.prompts import PromptTemplate
from langchain_core.tools import tool, render_text_description
import urllib3
from dotenv import load_dotenv
from dotenv import load_dotenv
from pydantic import Field, SecretStr
from typing import List
from typing import Optional
from langchain_core.utils.utils import secret_from_env
from graphql import build_client_schema, parse, validate
import json
from sentence_transformers import SentenceTransformer
import numpy as np

# Load environment variables
load_dotenv()

# Configure logging
logging.basicConfig(level=logging.DEBUG)
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# Global variables for lazy initialization
llm = None
agent_executor = None
prompt_template = None

class ChatOpenRouter(ChatOpenAI):
    openai_api_key: Optional[SecretStr] = Field(
        alias="api_key", default_factory=secret_from_env("OPENROUTER_API_KEY", default=None)
    )
    @property
    def lc_secrets(self) -> dict[str, str]:
        return {"openai_api_key": "OPENROUTER_API_KEY"}

    def __init__(self,
                 openai_api_key: Optional[str] = None,
                 **kwargs):
        openai_api_key = openai_api_key or os.environ.get("OPENROUTER_API_KEY")
        super().__init__(base_url="https://openrouter.ai/api/v1", openai_api_key=openai_api_key, **kwargs)


# Configuration
NAUTOBOT_API = "https://172.21.17.32/api"
#OPENAI_API_KEY = "your-openai-key"  # Set to None to use regex parsing
DEVICE_FIELDS = {
    'location', 'ip', 'ipaddress', 'rack', 'platform', 'status',
    'role', 'tenant', 'device_type', 'software_version',
    'serial', 'asset_tag', 'interfaces', 'tags',"front-ports",
    "rear-ports","console-ports","console-server-ports",
    "power-ports","power-outlets","device-bays","module-bays",
    "inventory-items","count"
}
INTERFACE_FIELDS = {
    'type', 'status', 'role', 'mac', 'ip', 'description',
    'enabled', 'mtu', 'device', 'vlan', 'vrf', 'tags',"count"
}
LOCATION_FIELDS = {
    'name', 'description', 'facility', 'status', 'location_type',
    'parent', 'devices', 'racks', 'prefixes', 'vlans',
    'contact_name', 'contact_phone', 'contact_email',
    'asn', 'physical_address', 'shipping_address',
    'latitude', 'longitude', 'time_zone', 'tags',"count"
}
TAG_FIELDS = {
    'name', 'color', 'description', 'tagged_items',
    'content_types', 'created', 'last_updated',"count"
}
IPADDRESS_FIELDS = {
    'address', 'host', 'mask_length', 'type', 'ip_version',
    'dns_name', 'description', 'status', 'role', 'parent',
    'tenant', 'nat_inside', 'created', 'last_updated',
    'tags', 'interfaces', 'vm_interfaces',"count"
}
PREFIX_FIELDS = {
    'prefix', 'type', 'network', 'broadcast', 'prefix_length', 
    'ip_version', 'date_allocated', 'description', 'status',
    'role', 'parent', 'namespace', 'tenant', 'vlan', 'rir',
    'locations', 'created', 'last_updated', 'tags', 'vrfs',
    'ip_addresses', 'child_prefixes',"count"
}
VLAN_FIELDS = {
    'vid', 'name', 'description', 'status', 'role',
    'vlan_group', 'tenant', 'locations', 'prefix_count',
    'created', 'last_updated', 'tags', 'prefixes',"count"
}
CIRCUIT_FIELDS = {
    'cid', 'description', 'status', 'provider', 'circuit_type',
    'install_date', 'commit_rate', 'tenant', 'circuit_termination_a',
    'circuit_termination_z', 'created', 'last_updated', 'tags',
    'comments', 'custom_fields',"count"
}
PROVIDER_FIELDS = {
    'name', 'asn', 'account', 'portal_url', 'noc_contact',
    'admin_contact', 'comments', 'circuit_count', 'created',
    'last_updated', 'tags', 'custom_fields', 'circuits',"count"
}
RACK_FIELDS = {
    'name', 'facility_id', 'status', 'location', 'rack_group',
    'type', 'width', 'u_height', 'desc_units', 'outer_width',
    'outer_depth', 'device_count', 'power_feed_count', 'serial',
    'asset_tag', 'comments', 'role', 'tenant', 'created',
    'last_updated', 'tags', 'devices', 'power_feeds',"count"
}

class ChatbotQueryTool:
    def __init__(self,llm):
        self.session = requests.Session()
        self.llm = llm
        self.base_url = "http://172.21.17.32:8004/api"
        self.api_token = "0ee2ce61d7ca50d3e57b29d538b8c7d137b572df"
        self.headers = {"Authorization": f"Token {self.api_token}", "Accept": "application/json"}
        self.location_related_queries = {
            "devices": "dcim/devices/?format=json&location=",
            "racks": "dcim/racks/?format=json&location=",
            "prefixes": "ipam/prefixes/?format=json&location=",
            "vlans": "ipam/vlans/?format=json&location="
        }
        self.object_types = {
            "device": {
                "endpoint": "/dcim/devices/?format=json",
                "search_field": "name",
                "fields": DEVICE_FIELDS,
                "display_name": "Device",
                "handler": self._handle_device_query
            },
            "interface": {
                "endpoint": "/dcim/interfaces/?format=json",
                "search_field": "name",
                "fields": INTERFACE_FIELDS,
                "display_name": "Interface",
                "handler": self._handle_interface_query
            },
            "location": {
                "endpoint": "/dcim/locations/?format=json",
                "search_field": "name",
                "fields": LOCATION_FIELDS,
                "display_name": "Location",
                "handler": self._handle_location_query
            },
            "tag": {
                "endpoint": "/extras/tags/?format=json",
                "search_field": "name",
                "fields": TAG_FIELDS,
                "display_name": "Tag",
                "handler": self._handle_tag_query
            },
            "ipaddress": {
                "endpoint": "/ipam/ip-addresses/?format=json",
                "search_field": "address",
                "fields": IPADDRESS_FIELDS,
                "display_name": "IP Address",
                "handler": self._handle_ipaddress_query
            },
            "prefix": {
                "endpoint": "/ipam/prefixes/?format=json",
                "search_field": "prefix",
                "fields": PREFIX_FIELDS,
                "display_name": "Prefix",
                "handler": self._handle_prefix_query
            },
            "vlan": {
                "endpoint": "/ipam/vlans/?format=json",
                "search_field": "vid",
                "fields": VLAN_FIELDS,
                "display_name": "VLAN",
                "handler": self._handle_vlan_query
            },
            "circuit": {
                "endpoint": "/circuits/circuits/?format=json",
                "search_field": "cid",
                "fields": CIRCUIT_FIELDS,
                "display_name": "Circuit",
                "handler": self._handle_circuit_query
            },
            "provider": {
                "endpoint": "/circuits/providers/?format=json",
                "search_field": "name",
                "fields": PROVIDER_FIELDS,
                "display_name": "Provider",
                "handler": self._handle_provider_query
            },
            "rack": {
                "endpoint": "/dcim/racks/",
                "search_field": "name",
                "fields": RACK_FIELDS,
                "display_name": "Rack",
                "handler": self._handle_rack_query
            }
        }
        
    def parse_with_llm(self, query: str) -> Dict[str, Any]:
        
        prompt = f"""
        You are a Nautobot data extraction assistant. Your task is to analyze the user's query and extract the following information in JSON format:

        ### Instructions:
        1. **Think step-by-step** to identify:
        - The **object type** (device, interface, location, tag, ipaddress, vlan, circuit, provider, prefix,rack).
        - The **object name** (e.g., device hostname, interface name, IP address).
        - The **requested field** (specific attribute being asked for).
        2. **If uncertain at any step**, use "unknown" for that field.
        3. **Output ONLY JSON** with the keys: `object_type`, `object_name`, `requested_field`.

        Available fields for each object type:
        - Devices: {', '.join(sorted(DEVICE_FIELDS))}
        - Interfaces: {', '.join(sorted(INTERFACE_FIELDS))}
        - Locations: {', '.join(sorted(LOCATION_FIELDS))}
        - Tags: {', '.join(sorted(TAG_FIELDS))}
        - IP Addresses: {', '.join(sorted(IPADDRESS_FIELDS))}
        - Prefix: {', '.join(sorted(PREFIX_FIELDS))}
        - Vlans: {', '.join(sorted(VLAN_FIELDS))}
        - Circuit: {', '.join(sorted(CIRCUIT_FIELDS))}
        - Circuit Provider : {', '.join(sorted(PROVIDER_FIELDS))}
        - Racks: {', '.join(sorted(RACK_FIELDS))}


        Guidelines for extraction:
        - Location queries: Look for location/site/facility names and words indicating places
        - Device queries: Look for device hostnames or hardware naming patterns
        - Interface queries: Look for interface names (e.g., Gi1/0/3, Eth0) or port terms
        - Tag queries: Look for "tag" keyword followed by tag names (usually lowercase_with_underscores)
        - IP Address queries: Look for IP/CIDR patterns (e.g., 10.0.0.1 or 192.168.1.0/24)
        - Prefix queries: Look for IP/CIDR notation (e.g., 10.0.0.0/16) and "prefix" keyword
        - VLAN queries: Look for "vlan" keyword followed by VID (e.g., 100) or quoted name (e.g., "VOICE-NYC")
        - Circuit queries: Look for "circuit" keyword followed by circuit ID (e.g., "BHEC/041403//ATI") or provider reference
        - Provider queries: Look for "provider/carrier/isp" keywords followed by provider name (e.g., "AT&T")
        - Rack queries: Look for "rack/cabinet" keywords followed by rack name (e.g., "AMS01 SRR")
        - Count queries: Look for "how many" with object type (e.g., "how many racks")

        Response Format:
        - Return ONLY valid JSON with the keys: object_type, object_name, and requested_field
        - For count queries, set object_name to "count" and requested_field to "count"
        - If any information is missing or unclear, use "unknown" as the value

        Examples:
        Query: "How many items are there?"
        Thought Process:
        1. **Object Type**: "item" indicates item count → item.
        2. **Object Name**: Generic count request → "count".
        3. **Requested Field**: Counting operation → "count".
        Output:
        {{
            "object_type": "item",
            "object_name": "count",
            "requested_field": "count"
        }}
        Query: "What's the IP of router1?"
        Thought Process:
        1. **Object Type**: "router1" is a device hostname → `device`.
        2. **Object Name**: Explicitly mentioned as "router1".
        3. **Requested Field**: "IP" maps to `ipaddress` in DEVICE_FIELDS.
        Output:
        {{
            "object_type": "device",
            "object_name": "router1",
            "requested_field": "ipaddress"
        }}

        Query: "Show me VLANs on GigabitEthernet1/0/3"
        Thought Process:
        1. **Object Type**: "GigabitEthernet1/0/3" is an interface name → interface.
        2. **Object Name**: Explicitly mentioned as "GigabitEthernet1/0/3".
        3. **Requested Field**: "VLANs" maps to vlan in INTERFACE_FIELDS.
        Output:
        {{
            "object_type": "interface",
            "object_name": "GigabitEthernet1/0/3",
            "requested_field": "vlan"
        }}

        Query: "How many devices in AMER?"
        Thought Process:
        1. **Object Type**: "AMER" is a location name (keywords: "in AMER") → location.
        2. **Object Name**: Explicitly mentioned as "AMER".
        3. **Requested Field**: "How many devices" implies counting devices → devices in LOCATION_FIELDS.
        Output:
        {{
            "object_type": "location",
            "object_name": "AMER",
            "requested_field": "devices"
        }}

        Query: "what is the location of the device ams01-asw-01?"
        Thought Process:
        1. **Object Type**: 
        - "ams01-asw-01" follows device naming pattern (hostname)
        - Keyword "device" explicitly mentioned → `device`
        2. **Object Name**: 
        - Explicit device hostname: "ams01-asw-01"
        3. **Requested Field**: 
        - "location" is being asked for
        - "location" is a valid field in DEVICE_FIELDS
        Output:
        {{
            "object_type": "device",
            "object_name": "ams01-asw-01",
            "requested_field": "location"
        }}

        Query: "How many items are tagged with access_switch_a_allocation?"
        Thought Process:
        1. **Object Type**: Keyword "tagged" → tag.
        2. **Object Name**: Tag name is "access_switch_a_allocation".
        3. **Requested Field**: "How many items" implies counting → tagged_items in TAG_FIELDS.
        Output:
        {{
            "object_type": "tag",
            "object_name": "access_switch_a_allocation",
            "requested_field": "tagged_items"
        }}

        Query: "Show interfaces using 192.168.1.10"
        Thought Process:
        1. **Object Type**: "192.168.1.10" is an IP → ipaddress.
        2. **Object Name**: Explicitly mentioned as "192.168.1.10".
        3. **Requested Field**: "interfaces using" maps to interfaces in IPADDRESS_FIELDS.
        Output:
        {{
            "object_type": "ipaddress",
            "object_name": "192.168.1.10",
            "requested_field": "interfaces"
        }}

        Query: "Show prefixes in VLAN 2561"
        Thought Process:
        1. **Object Type**: "VLAN 2561" → vlan.
        2. **Object Name**: VLAN ID is "2561".
        3. **Requested Field**: "prefixes" is a valid field in VLAN_FIELDS.
        Output:
        {{
            "object_type": "vlan",
            "object_name": "2561",
            "requested_field": "prefixes"
        }}

        Query: "Show provider for circuit BHEC/041403//ATI"
        Thought Process:
        1. **Object Type**: Keyword "circuit" → circuit.
        2. **Object Name**: Circuit ID is "BHEC/041403//ATI".
        3. **Requested Field**: "provider" is a valid field in CIRCUIT_FIELDS.
        Output:
        {{
            "object_type": "circuit",
            "object_name": "BHEC/041403//ATI",
            "requested_field": "provider"
        }}

        Query: "Show circuits for provider ACME"
        Thought Process:
        1. **Object Type**: Keyword "provider" → provider.
        2. **Object Name**: Provider name is "ACME".
        3. **Requested Field**: "circuits" is a valid field in PROVIDER_FIELDS.
        Output:
        {{
            "object_type": "provider",
            "object_name": "ACME",
            "requested_field": "circuits"
        }}

        Now process this query:
        Query: "{query}"
        Thought Process:
        1. **Object Type**: <LLM explains reasoning>
        2. **Object Name**: <LLM explains reasoning>
        3. **Requested Field**: <LLM explains reasoning>
        Output:
        """
        
        try:
            print(prompt)
            response = self.llm.invoke(prompt)
            # response_out = response.content
            # print(f"COMPLETE RESPONSE ::::{response_out}")
            # if "```json" in response_out or "```" in response_out:
            #     response_out = response_out.replace("```json","")
            #     response_out = response_out.replace("```","")
            # result = json.loads(response_out)
            response_out = response.content.strip()

            # Extract JSON even if the LLM adds extra text
            json_match = re.search(r'\{.*\}', response_out, re.DOTALL)
            if json_match:
                response_out = json_match.group(0)
            
            result = json.loads(response_out)
            # return result
            print(result)
            return result
        # except:
        #     return {"error": "Could not understand query"}
        except Exception as e:
                logging.error(f"Error during query: {str(e)}", exc_info=True)
                return "error"
    
    # ----- Object-Specific Handlers -----
    def _handle_device_query(self, device_name: str, field: str) -> Dict[str, Any]:
        """Handle device-specific queries"""

        if device_name.lower() == "count" and field == "count":
            response = self.session.get(f"{self.base_url}/dcim/devices/?format=json",headers=self.headers, verify=False)
            if response.status_code == 200:
                data = response.json()
                return {
                    "display": f"Total devices: {data['count']}",
                    "details": {"total_devices": data['count']}
                }
            return {"error": "Could not fetch devices count"}

        device = self._fetch_paginated(
            f"{self.base_url}/dcim/devices/?format=json",
            search_field="name",
            search_value=device_name
        )
        if not device:
            return {"error": f"Device '{device_name}' not found"}
        
        # Special handling for interfaces
        if field in ["interfaces","front-ports","rear-ports","console-ports","console-server-ports","power-ports","power-outlets","device-bays","module-bays","inventory-items"]:
            interfaces = self._fetch_all_paginated(
                f"{self.base_url}/dcim/{field}/?format=json&device={device_name}"
            )

            return {
                "display": f"{len(interfaces)} {field}",
                "details": [i["display"] for i in interfaces]
            }
        # Special handling for tags
        if field == "tags":
            if 'tags' in device and device['tags']:
                return {
                    "display": f"{len(device['tags'])} tags",
                    "details": device['tags']
                }
            return {
                "display": "No tags",
                "details": []
            }
        # Direct attributes
        if field in ['serial', 'asset_tag']:
            return {
                "display": device.get(field, "N/A"),
                "details": {field: device.get(field)}
            }
        
        # Related objects
        if field in device:
            if isinstance(device[field], dict) and 'url' in device[field]:
                return self._fetch_details(device[field]['url'])
            return {
                "display": str(device.get(field, "N/A")),
                "details": {field: device.get(field)}
            }
        
        return {"error": f"Field '{field}' not found for device"}

    def _handle_interface_query(self, interface_name: str, field: str) -> Dict[str, Any]:
        """Handle interface-specific queries"""
        if interface_name.lower() == "count" and field == "count":
            response = self.session.get(f"{self.base_url}/dcim/interfaces/?format=json",headers=self.headers, verify=False)
            if response.status_code == 200:
                data = response.json()
                return {
                    "display": f"Total interfaces: {data['count']}",
                    "details": {"total_interfaces": data['count']}
                }
            return {"error": "Could not fetch interfaces count"}
        
        interface = self._fetch_paginated(
            f"{self.base_url}/dcim/interfaces/?format=json",
            search_field="name",
            search_value=interface_name
        )
        if not interface:
            return {"error": f"Interface '{interface_name}' not found"}
        
        # Special handling for device
        if field == "device":
            return self._fetch_details(interface['device']['url'])
        # Special handling for tags
        if field == "tags":
            if 'tags' in interface and interface['tags']:
                return {
                    "display": f"{len(interface['tags'])} tags",
                    "details": interface['tags']
                }
            return {
                "display": "No tags",
                "details": []
            }
        # Direct attributes
        if field in ['name', 'description', 'enabled', 'mtu']:
            return {
                "display": interface.get(field, "N/A"),
                "details": {field: interface.get(field)}
            }
        
        # Related objects
        if field in interface:
            if isinstance(interface[field], dict) and 'url' in interface[field]:
                return self._fetch_details(interface[field]['url'])
            return {
                "display": str(interface.get(field, "N/A")),
                "details": {field: interface.get(field)}
            }
        
        return {"error": f"Field '{field}' not found for interface"}

    def _handle_location_query(self, location_name: str, field: str) -> Dict[str, Any]:
        """Handle location-specific queries with correct relationship URLs"""
        
        if location_name.lower() == "count" and field == "count":
            response = self.session.get(f"{self.base_url}/dcim/locations/?format=json",headers=self.headers, verify=False)
            if response.status_code == 200:
                data = response.json()
                return {
                    "display": f"Total locations: {data['count']}",
                    "details": {"total_locations": data['count']}
                }
            return {"error": "Could not fetch locations count"}

        location = self._fetch_paginated(
            f"{self.base_url}/dcim/locations/?format=json",
            search_field="name",
            search_value=location_name
        )
        if not location:
            return {"error": f"Location '{location_name}' not found"}
        
        # Handle relationships using the correct endpoints
        if field in self.location_related_queries:
            related_objects = self._fetch_all_paginated(
                f"{self.base_url}/{self.location_related_queries[field]}{location_name}"
            )
            return {
                "display": f"{len(related_objects)} {field}",
                "details": related_objects
            }
        # Special handling for tags
        if field == "tags":
            if 'tags' in location and location['tags']:
                return {
                    "display": f"{len(location['tags'])} tags",
                    "details": location['tags']
                }
            return {
                "display": "No tags",
                "details": []
            }
        # Direct attributes
        if field in location:
            if isinstance(location[field], dict) and 'url' in location[field]:
                return self._fetch_details(location[field]['url'])
            return {
                "display": str(location.get(field, "N/A")),
                "details": {field: location.get(field)}
            }
        
        return {"error": f"Field '{field}' not found for location"}
    
    def _handle_tag_query(self, tag_name: str, field: str) -> Dict[str, Any]:
        """Handle tag-specific queries"""
        if tag_name.lower() == "count" and field == "count":
            response = self.session.get(f"{self.base_url}/extras/tags/?format=json",headers=self.headers, verify=False)
            if response.status_code == 200:
                data = response.json()
                return {
                    "display": f"Total tags: {data['count']}",
                    "details": {"total_tags": data['count']}
                }
            return {"error": "Could not fetch tags count"}
        tag = self._fetch_paginated(
            f"{self.base_url}/extras/tags/?format=json",
            search_field="name",
            search_value=tag_name
        )
        if not tag:
            return {"error": f"Tag '{tag_name}' not found"}
        
        # Special handling for tagged_items
        if field == "tagged_items":
            return {
                "display": f"{tag.get('tagged_items', 0)} items tagged",
                "details": {"tagged_items": tag.get('tagged_items')}
            }
        
        # Direct attributes
        if field in tag:
            if isinstance(tag[field], dict) and 'url' in tag[field]:
                return self._fetch_details(tag[field]['url'])
            return {
                "display": str(tag.get(field, "N/A")),
                "details": {field: tag.get(field)}
            }
        
        return {"error": f"Field '{field}' not found for tag"}
    # ----- Object-Specific Handlers -----
    def _handle_ipaddress_query(self, ip_address: str, field: str) -> Dict[str, Any]:
        """Handle IP address-specific queries"""
        if ip_address.lower() == "count" and field == "count":
            response = self.session.get(f"{self.base_url}/ipam/ip-addresses/?format=json",headers=self.headers, verify=False)
            if response.status_code == 200:
                data = response.json()
                return {
                    "display": f"Total ipadrress: {data['count']}",
                    "details": {"total_ips": data['count']}
                }
            return {"error": "Could not fetch ip's count"}
        # Ensure the IP address is in the correct format
        if '/' not in ip_address:
            ip_address = f"{ip_address}/32"  # Assume host address if no mask provided
        
        ip_obj = self._fetch_paginated(
            f"{self.base_url}/ipam/ip-addresses/?format=json",
            search_field="address",
            search_value=ip_address
        )
        if not ip_obj:
            return {"error": f"IP address '{ip_address}' not found"}
        
        # Special handling for interfaces
        if field == "interfaces":
            interface_refs = ip_obj.get('interfaces', [])
            if not interface_refs:
                return {
                    "display": "No interfaces assigned",
                    "details": []
                }
            
            # Fetch full details for each interface
            interface_details = []
            for interface_ref in interface_refs:
                if isinstance(interface_ref, dict) and 'url' in interface_ref:
                    interface = self._fetch_details(interface_ref['url'])
                    if 'details' in interface:
                        interface_details.append(interface['details'])
            
            return {
                "display": f"{len(interface_details)} interfaces",
                "details": interface_details if interface_details else interface_refs
            }
        
        # Special handling for parent prefix
        if field == "parent":
            if ip_obj.get('parent'):
                return self._fetch_details(ip_obj['parent']['url'])
            return {
                "display": "No parent prefix",
                "details": {}
            }
        
        # Direct attributes
        if field in ['address', 'host', 'mask_length', 'dns_name', 'description']:
            return {
                "display": ip_obj.get(field, "N/A"),
                "details": {field: ip_obj.get(field)}
            }
        
        # Related objects
        if field in ip_obj:
            if isinstance(ip_obj[field], dict) and 'url' in ip_obj[field]:
                return self._fetch_details(ip_obj[field]['url'])
            return {
                "display": str(ip_obj.get(field, "N/A")),
                "details": {field: ip_obj.get(field)}
            }
        
        return {"error": f"Field '{field}' not found for IP address"}

    def _handle_prefix_query(self, prefix: str, field: str) -> Dict[str, Any]:
        """Handle prefix-specific queries with full details"""
        if prefix.lower() == "count" and field == "count":
            response = self.session.get(f"{self.base_url}/ipam/prefixes/?format=json",headers=self.headers, verify=False)
            if response.status_code == 200:
                data = response.json()
                return {
                    "display": f"Total prefix: {data['count']}",
                    "details": {"total_prefix": data['count']}
                }
            return {"error": "Could not fetch prefix count"}
        # Ensure prefix format (add /32 if no mask provided)
        if '/' not in prefix:
            return {"error": "Prefix requires CIDR notation (e.g. 10.0.0.0/24)"}
            
        prefix_obj = self._fetch_paginated(
            f"{self.base_url}/ipam/prefixes/?format=json",
            search_field="prefix",
            search_value=prefix
        )
        if not prefix_obj:
            return {"error": f"Prefix '{prefix}' not found"}
        
        # Enhanced handling for child objects
        if field == "ip_addresses":
            ips = self._fetch_all_paginated(
                f"{self.base_url}/ipam/ip-addresses/?format=json&parent={prefix}"
            )
            return {
                "display": f"{len(ips)} IP addresses",
                "details": ips[:10],  # Show first 10 to avoid huge responses
                "total_count": len(ips)
            }
        
        if field == "child_prefixes":
            children = self._fetch_all_paginated(
                f"{self.base_url}/ipam/prefixes/?format=json&parent={prefix}"
            )
            return {
                "display": f"{len(children)} child prefixes",
                "details": children[:10],  # Show first 10
                "total_count": len(children)
            }
        
        # Related objects with details
        if field in ['parent', 'namespace', 'vlan', 'role']:
            if prefix_obj.get(field):
                return self._fetch_details(prefix_obj[field]['url'])
            return {
                "display": f"No {field} assigned",
                "details": {}
            }
        
        # Direct attributes
        if field in ['prefix', 'description', 'ip_version']:
            return {
                "display": str(prefix_obj.get(field, "N/A")),
                "details": {field: prefix_obj.get(field)}
            }
        
        # Complex fields with sub-objects
        if field in prefix_obj:
            if isinstance(prefix_obj[field], dict) and 'url' in prefix_obj[field]:
                return self._fetch_details(prefix_obj[field]['url'])
            return {
                "display": json.dumps(prefix_obj[field], indent=2),
                "details": {field: prefix_obj[field]}
            }
        
        return {"error": f"Field '{field}' not found for prefix"}
    
    def _handle_vlan_query(self, vlan_identifier: str, field: str) -> Dict[str, Any]:
        """Handle VLAN-specific queries with full details"""
        if vlan_identifier.lower() == "count" and field == "count":
            response = self.session.get(f"{self.base_url}/ipam/vlans/?format=json",headers=self.headers, verify=False)
            if response.status_code == 200:
                data = response.json()
                return {
                    "display": f"Total vlans: {data['count']}",
                    "details": {"total_vlans": data['count']}
                }
            return {"error": "Could not fetch vlans count"}
        # Try to find by VID first (numeric)
        if vlan_identifier.isdigit():
            vlan_obj = self._fetch_paginated(
                f"{self.base_url}/ipam/vlans/?format=json",
                search_field="vid",
                search_value=int(vlan_identifier))
        else:
            # Fallback to name search
            vlan_obj = self._fetch_paginated(
                f"{self.base_url}/ipam/vlans/?format=json",
                search_field="name",
                search_value=vlan_identifier)
            
        if not vlan_obj:
            return {"error": f"VLAN '{vlan_identifier}' not found"}
        
        # Enhanced handling for prefixes
        if field == "prefixes":
            prefixes = self._fetch_all_paginated(
                f"{self.base_url}/ipam/prefixes/?format=json&vlan_id={vlan_obj['id']}"
            )
            return {
                "display": f"{len(prefixes)} prefixes",
                "details": prefixes[:10],  # Show first 10
                "total_count": len(prefixes)
            }
        
        # Related objects with details
        if field in ['vlan_group', 'status', 'role', 'tenant']:
            if vlan_obj.get(field):
                return self._fetch_details(vlan_obj[field]['url'])
            return {
                "display": f"No {field} assigned",
                "details": {}
            }
        
        # Handle locations (array of objects)
        if field == "locations":
            locations = []
            for loc_ref in vlan_obj.get('locations', []):
                if isinstance(loc_ref, dict) and 'url' in loc_ref:
                    loc = self._fetch_details(loc_ref['url'])
                    if 'details' in loc:
                        locations.append(loc['details'])
            return {
                "display": f"{len(locations)} locations",
                "details": locations,
                "total_count": len(locations)
            }
        
        # Direct attributes
        if field in ['vid', 'name', 'description', 'prefix_count']:
            return {
                "display": str(vlan_obj.get(field, "N/A")),
                "details": {field: vlan_obj.get(field)}
            }
        
        # Complex fields with sub-objects
        if field in vlan_obj:
            if isinstance(vlan_obj[field], dict) and 'url' in vlan_obj[field]:
                return self._fetch_details(vlan_obj[field]['url'])
            return {
                "display": json.dumps(vlan_obj[field], indent=2),
                "details": {field: vlan_obj[field]}
            }
        
        return {"error": f"Field '{field}' not found for VLAN"}

    def _handle_circuit_query(self, circuit_id: str, field: str) -> Dict[str, Any]:
        """Handle circuit-specific queries with full details"""
        if circuit_id.lower() == "count" and field == "count":
            response = self.session.get(f"{self.base_url}/circuits/circuits/?format=json",headers=self.headers, verify=False)
            if response.status_code == 200:
                data = response.json()
                return {
                    "display": f"Total circuits: {data['count']}",
                    "details": {"total_circuits": data['count']}
                }
            return {"error": "Could not fetch circuits count"}
        circuit = self._fetch_paginated(
            f"{self.base_url}/circuits/circuits/?format=json",
            search_field="cid",
            search_value=circuit_id
        )
        if not circuit:
            return {"error": f"Circuit '{circuit_id}' not found"}
        
        # Enhanced handling for terminations
        if field in ['circuit_termination_a', 'circuit_termination_z']:
            if circuit.get(field):
                termination = self._fetch_details(circuit[field]['url'])
                return {
                    "display": f"{field.split('_')[-1].upper()} termination",
                    "details": termination.get('details', {})
                }
            return {
                "display": f"No {field} termination",
                "details": {}
            }
        
        # Related objects with details
        if field in ['provider', 'circuit_type', 'status', 'tenant']:
            if circuit.get(field):
                return self._fetch_details(circuit[field]['url'])
            return {
                "display": f"No {field} assigned",
                "details": {}
            }
        
        # Direct attributes
        if field in ['cid', 'description', 'install_date', 'commit_rate']:
            return {
                "display": str(circuit.get(field, "N/A")),
                "details": {field: circuit.get(field)}
            }
        
        # Complex fields
        if field in circuit:
            if isinstance(circuit[field], dict) and 'url' in circuit[field]:
                return self._fetch_details(circuit[field]['url'])
            return {
                "display": json.dumps(circuit[field], indent=2),
                "details": {field: circuit[field]}
            }
        
        return {"error": f"Field '{field}' not found for circuit"}
    
    def _handle_provider_query(self, provider_name: str, field: str) -> Dict[str, Any]:
        """Handle circuit provider queries with full details"""
        if provider_name.lower() == "count" and field == "count":
            response = self.session.get(f"{self.base_url}/circuits/providers/?format=json",headers=self.headers, verify=False)
            if response.status_code == 200:
                data = response.json()
                return {
                    "display": f"Total providers: {data['count']}",
                    "details": {"total_providers": data['count']}
                }
            return {"error": "Could not fetch providers count"}
        provider = self._fetch_paginated(
            f"{self.base_url}/circuits/providers/?format=json",
            search_field="name",
            search_value=provider_name
        )
        if not provider:
            return {"error": f"Provider '{provider_name}' not found"}
        
        # Enhanced handling for circuits
        if field == "circuits":
            circuits = self._fetch_all_paginated(
                f"{self.base_url}/circuits/circuits/?format=json&provider={provider_name}"
            )
            return {
                "display": f"{len(circuits)} circuits",
                "details": circuits[:10],  # Show first 10
                "total_count": len(circuits)
            }
        
        # Direct attributes
        if field in ['name', 'asn', 'account', 'portal_url']:
            return {
                "display": str(provider.get(field, "N/A")),
                "details": {field: provider.get(field)}
            }
        
        # Contact information
        if field in ['noc_contact', 'admin_contact']:
            return {
                "display": provider.get(field, "Not specified"),
                "details": {field: provider.get(field)}
            }
        
        # Complex fields
        if field in provider:
            if isinstance(provider[field], dict):
                return {
                    "display": json.dumps(provider[field], indent=2),
                    "details": {field: provider[field]}
                }
            return {
                "display": str(provider.get(field, "N/A")),
                "details": {field: provider.get(field)}
            }
        
        return {"error": f"Field '{field}' not found for provider"}
    
    def _handle_rack_query(self, rack_name: str, field: str) -> Dict[str, Any]:
        """Handle rack-specific queries with full details"""
        if rack_name.lower() == "count" and field == "count":
            response = self.session.get(f"{self.base_url}/dcim/racks/?format=json",headers=self.headers, verify=False)
            if response.status_code == 200:
                data = response.json()
                return {
                    "display": f"Total racks: {data['count']}",
                    "details": {"total racks": data['count']}
                }
            return {"error": "Could not fetch racks count"}
        rack = self._fetch_paginated(
            f"{self.base_url}/dcim/racks/",
            search_field="name",
            search_value=rack_name
        )
        if not rack:
            return {"error": f"Rack '{rack_name}' not found"}
        
        # Enhanced handling for devices
        if field == "devices":
            devices = self._fetch_all_paginated(
                f"{self.base_url}/dcim/devices/?rack={rack_name}"
            )
            return {
                "display": f"{len(devices)} devices",
                "details": devices[:10],  # Show first 10
                "total_count": len(devices)
            }
        
        # Enhanced handling for power feeds
        if field == "power_feeds":
            feeds = self._fetch_all_paginated(
                f"{self.base_url}/dcim/power-feeds/?rack={rack_name}"
            )
            return {
                "display": f"{len(feeds)} power feeds",
                "details": feeds,
                "total_count": len(feeds)
            }
        
        # Related objects with details
        if field in ['location', 'status', 'role', 'tenant', 'rack_group']:
            if rack.get(field):
                return self._fetch_details(rack[field]['url'])
            return {
                "display": f"No {field} assigned",
                "details": {}
            }
        
        # Physical attributes
        if field in ['u_height', 'width', 'outer_width', 'outer_depth']:
            value = rack.get(field)
            if field == 'width' and isinstance(value, dict):
                value = value.get('label', value.get('value'))
            return {
                "display": str(value) if value else "Not specified",
                "details": {field: value}
            }
        
        # Direct attributes
        if field in ['name', 'facility_id', 'serial', 'asset_tag', 'comments']:
            return {
                "display": str(rack.get(field, "N/A")),
                "details": {field: rack.get(field)}
            }
        
        return {"error": f"Field '{field}' not found for rack"}

    # ----- Core API Methods -----
    def get_object_info(self, object_type: str, object_name: str, requested_field: str) -> Dict[str, Any]:
        """Main method to get information about any object"""
        if object_type not in self.object_types:
            available = ', '.join(self.object_types.keys())
            return {"error": f"Unsupported object type. Available: {available}"}
        
        if not self._validate_field(object_type, requested_field):
            available = ', '.join(sorted(self.object_types[object_type]['fields']))
            return {"error": f"Invalid field '{requested_field}'. Available: {available}"}
        
        # Dispatch to the appropriate handler
        handler = self.object_types[object_type]['handler']
        return handler(object_name, requested_field)

    def _validate_field(self, object_type: str, field_name: str) -> bool:
        """Check if a field is valid for the given object type"""
        return field_name.lower() in self.object_types.get(object_type, {}).get('fields', set())

    def _fetch_paginated(self, url: str, search_field: str = None, search_value: str = None) -> Optional[Dict]:
        """Fetch paginated results, returning immediately when match is found"""
        while url:
            response = self.session.get(url,headers=self.headers, verify=False)
            if response.status_code != 200:
                return None
                
            data = response.json()
            
            # If no search criteria, return first result
            if not search_field:
                return data['results'][0] if data['results'] else None
                
            # Search current page
            for item in data['results']:
                if str(item.get(search_field, '')).lower() == str(search_value).lower():
                    return item
                    
            url = data.get('next')
        
        return None

    def _fetch_all_paginated(self, url: str) -> List[Dict]:
        """Fetch all pages of results (for composite fields)"""
        results = []
        while url:
            response = self.session.get(url,headers=self.headers, verify=False)
            if response.status_code != 200:
                break
                
            data = response.json()
            results.extend(data['results'])
            url = data.get('next')
        
        return results

    def _fetch_details(self, url: str) -> Dict[str, Any]:
        """Fetch details from a specific URL"""
        response = self.session.get(url,headers=self.headers, verify=False)
        if response.status_code == 200:
            data = response.json()
            return {
                "display": data.get('display', data.get('name', 'N/A')),
                "details": data
            }
        return {"error": "Failed to fetch details"}
    
    def query_llm(self,user_msg):
        parsed = self.parse_with_llm(user_msg)
        if 'error' in parsed:
            print(f"Error: {parsed}")
            return 
        print(f"Parsed values is {parsed} type is {type(parsed)}")
        result = self.get_object_info(
                    parsed['object_type'],
                    parsed['object_name'],
                    parsed['requested_field']
                )
        return result