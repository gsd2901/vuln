import json
import os
from django.conf import settings
from pathlib import Path
 
# Optional: change this to store in a 'cache' subfolder
CACHE_FILENAME = 'app_cache.json'
CACHE_FILE_PATH = f"{settings.BASE_DIR}/nautobot/{CACHE_FILENAME}"
 
 
def write_to_cache(data, filename=CACHE_FILE_PATH):
    """
    Writes a dictionary to a JSON file.
    """
    with open(filename, 'w') as f:
        json.dump(data, f)
 
 
def read_from_cache(filename=CACHE_FILE_PATH):
    """
    Reads a dictionary from a JSON file without deleting it.
    Returns None if file does not exist or is invalid.
    """
    try:
        with open(filename, 'r') as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        return None
  
def delete_cache(filename=CACHE_FILE_PATH):
    """
    Deletes the cache file if it exists.
    """
    if os.path.exists(filename):
        os.remove(filename)