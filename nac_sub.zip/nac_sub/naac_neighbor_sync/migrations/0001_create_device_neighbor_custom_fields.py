from django.db import migrations


def create_device_neighbor_custom_fields(apps, schema_editor):
    """Create Nautobot device custom fields for CDP and LLDP neighbors."""
    ContentType = apps.get_model("contenttypes", "ContentType")
    CustomField = apps.get_model("extras", "CustomField")

    device_content_type = ContentType.objects.get(app_label="dcim", model="device")

    field_specs = (
        {
            "key": "cdp_neighbors",
            "label": "CDP Neighbors",
            "description": "Structured CDP neighbor data collected by the NAAC Neighbor Sync job.",
        },
        {
            "key": "lldp_neighbors",
            "label": "LLDP Neighbors",
            "description": "Structured LLDP neighbor data collected by the NAAC Neighbor Sync job.",
        },
    )

    for field_spec in field_specs:
        custom_field, _ = CustomField.objects.update_or_create(
            key=field_spec["key"],
            defaults={
                "label": field_spec["label"],
                "type": "json",
                "grouping": "Neighbor Data",
                "description": field_spec["description"],
                "required": False,
                "filter_logic": "disabled",
                "default": [],
                "weight": 100,
                "advanced_ui": False,
            },
        )
        custom_field.content_types.add(device_content_type)


def delete_device_neighbor_custom_fields(apps, schema_editor):
    """Remove Nautobot device custom fields created by this plugin."""
    CustomField = apps.get_model("extras", "CustomField")
    CustomField.objects.filter(key__in=["cdp_neighbors", "lldp_neighbors"]).delete()


class Migration(migrations.Migration):
    dependencies = []

    operations = [
        migrations.RunPython(
            create_device_neighbor_custom_fields,
            delete_device_neighbor_custom_fields,
        ),
    ]
