from nautobot.extras.plugins import PluginConfig

__version__ = "0.1.0"


class NaacNeighborSyncConfig(PluginConfig):
    """Plugin entry point for NAAC neighbor sync."""

    name = "naac_neighbor_sync"
    verbose_name = "NAAC Neighbor Sync"
    version = __version__
    author = "Akash Sharma"
    author_email = "akash.sharma521@gmail.com"
    description = "Synchronize CDP and LLDP neighbor data into Nautobot device custom fields."
    base_url = "naac-neighbor-sync"
    required_settings = []
    default_settings = {}
    caching_config = {}

    def ready(self):
        super().ready()

        try:
            from nautobot.extras.models import Job as JobModel, JobQueue
            from nautobot.extras.registry import registry

            from naac_neighbor_sync.jobs import NeighborSyncJob

            job_path = "naac_neighbor_sync.jobs.NeighborSyncJob"
            registry["jobs"][job_path] = NeighborSyncJob

            default_queue, _ = JobQueue.objects.get_or_create(name="default")

            JobModel.objects.update_or_create(
                module_name="naac_neighbor_sync.jobs",
                job_class_name="NeighborSyncJob",
                defaults={
                    "name": NeighborSyncJob.name,
                    "grouping": "Neighbor Sync",
                    "description": getattr(NeighborSyncJob, "description", ""),
                    "installed": True,
                    "enabled": True,
                    "has_sensitive_variables": getattr(NeighborSyncJob, "has_sensitive_variables", False),
                    "default_job_queue": default_queue,
                },
            )

            print("[NAAC Neighbor Sync] Job registered successfully.")

        except Exception as exc:
            print(f"[NAAC Neighbor Sync] Error loading jobs: {exc}")


config = NaacNeighborSyncConfig