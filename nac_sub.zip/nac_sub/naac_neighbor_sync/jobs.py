"""Nautobot job for synchronizing CDP and LLDP neighbors into device custom fields."""

from __future__ import annotations

import re
from typing import Any, Dict, List, Optional

from django.core.exceptions import ObjectDoesNotExist, ValidationError
from django.db import transaction
from netmiko import ConnectHandler
from netmiko.exceptions import ConnectionException, NetmikoAuthenticationException, NetmikoTimeoutException

from nautobot.apps.jobs import BooleanVar, Job, MultiObjectVar, ObjectVar, register_jobs
from nautobot.dcim.models import Device, Location
from nautobot.extras.choices import SecretsGroupAccessTypeChoices, SecretsGroupSecretTypeChoices
from nautobot.extras.models import SecretsGroup

CDP_CUSTOM_FIELD_KEY = "cdp_neighbors"
LLDP_CUSTOM_FIELD_KEY = "lldp_neighbors"


class NeighborSyncJob(Job):
    """Synchronize CDP and LLDP neighbor data from selected devices."""

    class Meta:
        name = "CDP/LLDP Neighbor Sync"
        description = "SSH to devices and store CDP/LLDP neighbor data in Nautobot device custom fields."
        has_sensitive_variables = False
        approval_required = False

    location = ObjectVar(
        model=Location,
        required=True,
        description="Location used to scope which devices are eligible for neighbor synchronization.",
    )
    select_all_devices = BooleanVar(
        default=True,
        description="If enabled, sync every device in the selected location.",
    )
    devices = MultiObjectVar(
        model=Device,
        required=False,
        description="Optional list of devices to sync when 'select all devices' is disabled.",
    )
    secrets_group = ObjectVar(
        model=SecretsGroup,
        required=False,
        description="Optional secrets group override. If empty, each device's assigned secrets group is used.",
    )
    skip_unreachable = BooleanVar(
        default=True,
        description="Skip unreachable devices and continue with remaining devices.",
    )

    def run(self, *, location, select_all_devices, devices, secrets_group, skip_unreachable):
        """Execute the neighbor synchronization job."""
        device_list = self._resolve_devices(
            location=location,
            select_all_devices=select_all_devices,
            selected_devices=devices,
        )

        self.logger.info("Starting neighbor synchronization for %s device(s) in location %s", len(device_list), location.name)

        stats = {
            "devices_processed": 0,
            "devices_updated": 0,
            "devices_skipped": 0,
            "devices_failed": 0,
            "cdp_neighbors_saved": 0,
            "lldp_neighbors_saved": 0,
        }

        for device in device_list:
            stats["devices_processed"] += 1
            self.logger.info("Processing device %s", device.name)

            if not device.primary_ip:
                self.logger.warning("Device %s has no primary IP, skipping", device.name)
                stats["devices_skipped"] += 1
                continue

            credentials = self._get_device_credentials(device=device, secrets_group=secrets_group)
            if not credentials:
                self.logger.warning("No credentials available for device %s, skipping", device.name)
                stats["devices_skipped"] += 1
                continue

            try:
                cdp_neighbors, lldp_neighbors = self._collect_neighbor_data(device=device, credentials=credentials)
                self._save_neighbor_data(device=device, cdp_neighbors=cdp_neighbors, lldp_neighbors=lldp_neighbors)
                stats["devices_updated"] += 1
                stats["cdp_neighbors_saved"] += len(cdp_neighbors)
                stats["lldp_neighbors_saved"] += len(lldp_neighbors)
                self.logger.info(
                    "Updated %s with %s CDP and %s LLDP neighbors",
                    device.name,
                    len(cdp_neighbors),
                    len(lldp_neighbors),
                )
            except (NetmikoTimeoutException, NetmikoAuthenticationException, ConnectionException) as exc:
                stats["devices_failed"] += 1
                self.logger.error("Connection error on %s: %s", device.name, exc)
                if not skip_unreachable:
                    raise
            except Exception as exc:
                stats["devices_failed"] += 1
                self.logger.error("Neighbor sync failed on %s: %s", device.name, exc)
                if not skip_unreachable:
                    raise

        self.logger.info("Neighbor synchronization complete: %s", stats)
        return stats

    def _resolve_devices(self, *, location: Location, select_all_devices: bool, selected_devices) -> List[Device]:
        """Build the final device list based on the location and user selection."""
        location_devices = Device.objects.filter(location=location).select_related("platform", "primary_ip4", "primary_ip6", "secrets_group")

        if select_all_devices:
            devices = list(location_devices.order_by("name"))
            if not devices:
                raise ValidationError(f"No devices found in location '{location.name}'.")
            return devices

        selected_list = list(selected_devices or [])
        if not selected_list:
            raise ValidationError("Select one or more devices or enable 'select all devices'.")

        selected_ids = {device.pk for device in selected_list}
        valid_ids = set(location_devices.filter(pk__in=selected_ids).values_list("pk", flat=True))
        invalid_devices = [device.name for device in selected_list if device.pk not in valid_ids]
        if invalid_devices:
            raise ValidationError(
                f"Selected devices must belong to location '{location.name}'. Invalid selection: {', '.join(invalid_devices)}"
            )

        return sorted(selected_list, key=lambda device: device.name)

    def _get_device_credentials(
        self,
        *,
        device: Device,
        secrets_group: Optional[SecretsGroup] = None,
    ) -> Optional[Dict[str, str]]:
        """Get SSH credentials from a Nautobot secrets group."""
        target_secrets_group = secrets_group or device.secrets_group
        if not target_secrets_group:
            return None

        credentials: Dict[str, str] = {}
        username_found = False
        password_found = False

        for access_type in (
            SecretsGroupAccessTypeChoices.TYPE_SSH,
            SecretsGroupAccessTypeChoices.TYPE_GENERIC,
        ):
            if not username_found:
                try:
                    credentials["username"] = target_secrets_group.get_secret_value(
                        access_type=access_type,
                        secret_type=SecretsGroupSecretTypeChoices.TYPE_USERNAME,
                        obj=device,
                    )
                    username_found = True
                except (ObjectDoesNotExist, Exception):
                    pass

            if not password_found:
                try:
                    credentials["password"] = target_secrets_group.get_secret_value(
                        access_type=access_type,
                        secret_type=SecretsGroupSecretTypeChoices.TYPE_PASSWORD,
                        obj=device,
                    )
                    password_found = True
                except (ObjectDoesNotExist, Exception):
                    pass

            if username_found and password_found:
                break

        try:
            credentials["enable_password"] = target_secrets_group.get_secret_value(
                access_type=SecretsGroupAccessTypeChoices.TYPE_SSH,
                secret_type=SecretsGroupSecretTypeChoices.TYPE_SECRET,
                obj=device,
            )
        except (ObjectDoesNotExist, Exception):
            pass

        if not (username_found and password_found):
            return None
        return credentials

    def _get_device_connection_params(self, *, device: Device, credentials: Dict[str, str]) -> Dict[str, Any]:
        """Build Netmiko connection parameters for the given device."""
        if not device.primary_ip:
            raise ValidationError(f"Device {device.name} has no primary IP address.")

        network_driver = ""
        if device.platform:
            network_driver = (
                getattr(device.platform, "network_driver", None)
                or getattr(device.platform, "napalm_driver", None)
                or device.platform.name
            )
        network_driver = str(network_driver).lower()

        device_type = "cisco_ios"
        if "nxos" in network_driver or "nexus" in network_driver:
            device_type = "cisco_nxos"
        elif "iosxr" in network_driver or "cisco_xr" in network_driver or "ios-xr" in network_driver:
            device_type = "cisco_xr"
        elif "asa" in network_driver:
            device_type = "cisco_asa"
        elif "arista" in network_driver or "eos" in network_driver:
            device_type = "arista_eos"
        elif "junos" in network_driver or "juniper" in network_driver:
            device_type = "juniper"

        connection_params: Dict[str, Any] = {
            "device_type": device_type,
            "host": str(device.primary_ip.address.ip),
            "username": credentials["username"],
            "password": credentials["password"],
            "timeout": 30,
            "session_timeout": 60,
            "auth_timeout": 30,
            "banner_timeout": 30,
            "fast_cli": False,
        }
        if credentials.get("enable_password"):
            connection_params["secret"] = credentials["enable_password"]
        return connection_params

    def _collect_neighbor_data(self, *, device: Device, credentials: Dict[str, str]) -> tuple[List[Dict[str, Any]], List[Dict[str, Any]]]:
        """Collect CDP and LLDP neighbor data over SSH."""
        connection_params = self._get_device_connection_params(device=device, credentials=credentials)

        with ConnectHandler(**connection_params) as conn:
            self.logger.info("Connected to %s", device.name)
            self._prepare_session(conn)

            cdp_output = self._safe_send_command(conn, "show cdp neighbors detail")
            lldp_output = self._safe_send_command(conn, "show lldp neighbors detail")

            cdp_neighbors = self._parse_cdp_neighbors(cdp_output) if cdp_output else []
            lldp_neighbors = self._parse_lldp_neighbors(lldp_output) if lldp_output else []

            if not cdp_neighbors:
                cdp_simple = self._safe_send_command(conn, "show cdp neighbors")
                cdp_neighbors = self._parse_simple_cdp_neighbors(cdp_simple) if cdp_simple else []

            if not lldp_neighbors:
                lldp_simple = self._safe_send_command(conn, "show lldp neighbors")
                lldp_neighbors = self._parse_simple_lldp_neighbors(lldp_simple) if lldp_simple else []

            return cdp_neighbors, lldp_neighbors

    def _prepare_session(self, conn: ConnectHandler) -> None:
        """Best-effort session preparation for network CLI access."""
        try:
            conn.enable()
        except Exception:
            pass

        for command in ("terminal length 0", "terminal pager 0", "no page"):
            try:
                conn.send_command(command, read_timeout=15)
                return
            except Exception:
                continue

    def _safe_send_command(self, conn: ConnectHandler, command: str) -> str:
        """Execute a command and return empty output on unsupported commands."""
        try:
            return conn.send_command(command, read_timeout=90, cmd_verify=False)
        except Exception as exc:
            self.logger.debug("Command '%s' failed: %s", command, exc)
            return ""

    def _parse_cdp_neighbors(self, output: str) -> List[Dict[str, Any]]:
        """Parse detailed CDP neighbor output into JSON-friendly records."""
        neighbors: List[Dict[str, Any]] = []
        blocks = [block.strip() for block in output.split("-------------------------") if block.strip()]

        for block in blocks:
            neighbor = {
                "protocol": "cdp",
                "neighbor_name": self._extract_pattern(block, r"Device ID:\s*(.+)"),
                "neighbor_ip": self._extract_pattern(block, r"IP address:\s*(\d+\.\d+\.\d+\.\d+)"),
                "platform": self._extract_pattern(block, r"Platform:\s*([^,\n]+)"),
                "local_interface": self._extract_pattern(block, r"Interface:\s*([^,\n]+)"),
                "remote_interface": self._extract_pattern(block, r"Port ID(?: \(outgoing port\))?:\s*(.+)"),
                "capabilities": self._extract_capabilities(block, "Capabilities:"),
                "raw_protocol": "cdp",
            }
            if self._has_neighbor_payload(neighbor):
                neighbors.append(self._normalize_neighbor_record(neighbor))

        return neighbors

    def _parse_lldp_neighbors(self, output: str) -> List[Dict[str, Any]]:
        """Parse detailed LLDP neighbor output into JSON-friendly records."""
        neighbors: List[Dict[str, Any]] = []
        current_block: List[str] = []

        for raw_line in output.splitlines():
            line = raw_line.strip()
            if not line or set(line) == {"-"}:
                continue

            if line.startswith(("Local Intf:", "Local Interface:")) and current_block:
                neighbors.extend(self._parse_lldp_block("\n".join(current_block)))
                current_block = [line]
            else:
                current_block.append(line)

        if current_block:
            neighbors.extend(self._parse_lldp_block("\n".join(current_block)))

        return neighbors

    def _parse_lldp_block(self, block: str) -> List[Dict[str, Any]]:
        """Parse a single LLDP detail block."""
        neighbor = {
            "protocol": "lldp",
            "neighbor_name": self._extract_pattern(block, r"System Name:\s*(.+)"),
            "neighbor_ip": self._extract_first_ip(
                block,
                (
                    r"Management Address:\s*(\d+\.\d+\.\d+\.\d+)",
                    r"Management Addresses:\s*IP:\s*(\d+\.\d+\.\d+\.\d+)",
                    r"\bIP:\s*(\d+\.\d+\.\d+\.\d+)",
                    r"Management IP:\s*(\d+\.\d+\.\d+\.\d+)",
                ),
            ),
            "platform": self._extract_pattern(block, r"System Description:\s*(.+)"),
            "local_interface": self._extract_pattern(block, r"Local (?:Interface|Intf):\s*(.+)"),
            "remote_interface": self._extract_pattern(block, r"Port ID:\s*(.+)"),
            "capabilities": self._extract_capabilities(block, "Capabilities:") or self._extract_capabilities(block, "System Capabilities:"),
            "raw_protocol": "lldp",
        }

        if self._has_neighbor_payload(neighbor):
            return [self._normalize_neighbor_record(neighbor)]
        return []

    def _parse_simple_cdp_neighbors(self, output: str) -> List[Dict[str, Any]]:
        """Parse summary CDP output when detail output is unavailable."""
        neighbors: List[Dict[str, Any]] = []
        for line in output.splitlines():
            line = line.strip()
            if not line or line.startswith(("Device ID", "Capability", "Total", "-")):
                continue
            parts = line.split()
            if not parts:
                continue
            neighbors.append(
                self._normalize_neighbor_record(
                    {
                        "protocol": "cdp",
                        "neighbor_name": parts[0],
                        "neighbor_ip": None,
                        "platform": None,
                        "local_interface": None,
                        "remote_interface": None,
                        "capabilities": [],
                        "raw_protocol": "cdp",
                    }
                )
            )
        return neighbors

    def _parse_simple_lldp_neighbors(self, output: str) -> List[Dict[str, Any]]:
        """Parse summary LLDP output when detail output is unavailable."""
        neighbors: List[Dict[str, Any]] = []
        for line in output.splitlines():
            line = line.strip()
            if not line or line.startswith(("Device ID", "Local Intf", "Total", "-", "%")):
                continue
            if any(token in line.lower() for token in ("invalid input", "incomplete command", "ambiguous command", "not enabled")):
                continue
            parts = line.split()
            if not parts:
                continue
            neighbor_name = parts[0]
            if neighbor_name in {"%", "#", ">"}:
                continue
            if not any(char.isalnum() for char in neighbor_name):
                continue
            neighbors.append(
                self._normalize_neighbor_record(
                    {
                        "protocol": "lldp",
                        "neighbor_name": neighbor_name,
                        "neighbor_ip": None,
                        "platform": None,
                        "local_interface": None,
                        "remote_interface": None,
                        "capabilities": [],
                        "raw_protocol": "lldp",
                    }
                )
            )
        return neighbors

    @staticmethod
    def _has_neighbor_payload(neighbor: Dict[str, Any]) -> bool:
        """Return True only when a parsed neighbor contains actual discovered data."""
        payload_keys = ("neighbor_name", "neighbor_ip", "platform", "local_interface", "remote_interface", "capabilities")
        return any(neighbor.get(key) for key in payload_keys)

    def _normalize_neighbor_record(self, neighbor: Dict[str, Any]) -> Dict[str, Any]:
        """Normalize neighbor data into a stable JSON structure."""
        name = (neighbor.get("neighbor_name") or "").strip()
        short_name = name.split(".")[0] if name else None

        normalized = {
            "neighbor_name": short_name,
            "neighbor_ip": neighbor.get("neighbor_ip"),
            "local_interface": self._clean_value(neighbor.get("local_interface")),
            "remote_interface": self._clean_value(neighbor.get("remote_interface")),
            "platform": self._clean_value(neighbor.get("platform")),
            "capabilities": neighbor.get("capabilities") or [],
            "protocol": neighbor.get("protocol"),
            "raw_neighbor_name": self._clean_value(name),
        }
        return normalized

    def _save_neighbor_data(self, *, device: Device, cdp_neighbors: List[Dict[str, Any]], lldp_neighbors: List[Dict[str, Any]]) -> None:
        """Persist parsed neighbor data into Nautobot custom fields."""
        device.cf[CDP_CUSTOM_FIELD_KEY] = cdp_neighbors
        device.cf[LLDP_CUSTOM_FIELD_KEY] = lldp_neighbors
        with transaction.atomic():
            device.validated_save()

    @staticmethod
    def _extract_pattern(text: str, pattern: str) -> Optional[str]:
        """Return the first regex capture match from the provided text."""
        match = re.search(pattern, text, re.IGNORECASE)
        if not match:
            return None
        return NeighborSyncJob._clean_value(match.group(1))

    @staticmethod
    def _extract_first_ip(text: str, patterns: tuple[str, ...]) -> Optional[str]:
        """Return the first IP matched by any pattern."""
        for pattern in patterns:
            match = re.search(pattern, text, re.IGNORECASE)
            if match:
                return match.group(1)
        return None

    @staticmethod
    def _extract_capabilities(text: str, marker: str) -> List[str]:
        """Extract compact capability letters from a capabilities line."""
        pattern = rf"{re.escape(marker)}\s*(.+)"
        match = re.search(pattern, text, re.IGNORECASE)
        if not match:
            return []
        capabilities = []
        for char in match.group(1):
            if char.isalpha() and char.isupper():
                capabilities.append(char)
        return sorted(set(capabilities))

    @staticmethod
    def _clean_value(value: Optional[str]) -> Optional[str]:
        """Normalize empty strings and whitespace to None."""
        if value is None:
            return None
        cleaned = value.strip()
        return cleaned or None


jobs = [NeighborSyncJob]
register_jobs(*jobs)
