from nautobot.apps import NautobotAppConfig

__version__ = "0.1.0"


class NaacLocationLookupsConfig(NautobotAppConfig):
    """Registers recursive descendant/ancestor filter lookups for dcim.Location."""

    name = "naac_location_lookups"
    verbose_name = "NAAC Location Lookups"
    version = __version__
    author = "NAAC"
    description = (
        "Adds pk__descendant_of / pk__ancestor_of ORM lookups for dcim.Location, "
        "backed by a PostgreSQL recursive CTE. Intended for use in ObjectPermission constraints."
    )
    base_url = "naac-location-lookups"
    required_settings = []
    default_settings = {}

    def ready(self):
        super().ready()

        from nautobot.dcim.models import Location

        from naac_location_lookups.lookups import AncestorOf, DescendantOf

        id_field = Location._meta.get_field("id")
        id_field.register_lookup(DescendantOf)
        id_field.register_lookup(AncestorOf)


config = NaacLocationLookupsConfig
