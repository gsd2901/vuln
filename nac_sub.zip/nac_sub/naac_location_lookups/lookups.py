"""Recursive-CTE ORM lookups for self-referential parent/child tree models.

Registered (see apps.py) on `dcim.Location`'s `id` field specifically, so they
are usable as plain filter kwargs -- including inside Nautobot ObjectPermission
`constraints`, which are passed straight to `.filter(**constraints)`:

    Location.objects.filter(pk__descendant_of=some_location.pk)
    Location.objects.filter(pk__ancestor_of=some_location.pk)
    Location.objects.filter(pk__descendant_of=some_location)
    Location.objects.filter(pk__descendant_of="Region X")

The matched column is always `pk` (globally unique), even when the rhs is
given as a name -- the name is only used to resolve which row to anchor the
walk on. `Location.name` is unique per-parent, not globally (see
`unique_together = [["parent", "name"]]` on the model), so a name that
matches more than one Location is rejected instead of silently picking one.

PostgreSQL-only: both lookups emit a `WITH RECURSIVE` CTE.
"""
import uuid

from django.db.models import Lookup


class _RecursiveTreeLookup(Lookup):
    """Shared plumbing: dynamic table/column resolution + instance/name-as-rhs support."""

    parent_field_name = "parent"

    def get_prep_lookup(self):
        # Allow `pk__descendant_of=some_instance` in addition to `=some_instance.pk`.
        if hasattr(self.rhs, "pk"):
            self.rhs = self.rhs.pk
        elif isinstance(self.rhs, str):
            try:
                uuid.UUID(self.rhs)
            except ValueError:
                # Not a UUID string -- treat it as a `name` to resolve to a pk.
                self.rhs = self._resolve_name_to_pk(self.rhs)
        return super().get_prep_lookup()

    def _resolve_name_to_pk(self, name):
        model = self.lhs.output_field.model
        try:
            return model.objects.get(name=name).pk
        except model.DoesNotExist:
            raise model.DoesNotExist(f"No {model.__name__} found with name={name!r}.") from None
        except model.MultipleObjectsReturned:
            raise model.MultipleObjectsReturned(
                f"Multiple {model.__name__} objects are named {name!r} ({model.__name__} names are "
                "only unique per-parent, not globally) -- pass the pk or instance instead to disambiguate."
            ) from None

    def _identifiers(self, connection):
        model = self.lhs.output_field.model
        meta = model._meta
        quote = connection.ops.quote_name
        return {
            "table": quote(meta.db_table),
            "pk_column": quote(meta.pk.column),
            "parent_column": quote(meta.get_field(self.parent_field_name).column),
        }


class DescendantOf(_RecursiveTreeLookup):
    """`pk__descendant_of=<pk, instance, or name>`: matches descendants, excluding self."""

    lookup_name = "descendant_of"

    def as_sql(self, compiler, connection):
        lhs_sql, lhs_params = self.process_lhs(compiler, connection)
        rhs_sql, rhs_params = self.process_rhs(compiler, connection)
        ids = self._identifiers(connection)

        sql = (
            f"{lhs_sql} IN ("
            f"WITH RECURSIVE descendant_tree(id, path) AS ("
            f"SELECT loc.{ids['pk_column']}, ARRAY[loc.{ids['pk_column']}] "
            f"FROM {ids['table']} AS loc "
            f"WHERE loc.{ids['parent_column']} = {rhs_sql} "
            "UNION ALL "
            f"SELECT loc.{ids['pk_column']}, dt.path || loc.{ids['pk_column']} "
            f"FROM {ids['table']} AS loc "
            f"INNER JOIN descendant_tree AS dt ON loc.{ids['parent_column']} = dt.id "
            f"WHERE NOT loc.{ids['pk_column']} = ANY(dt.path)"
            ") SELECT id FROM descendant_tree"
            ")"
        )
        params = list(lhs_params) + list(rhs_params)
        return sql, params


class AncestorOf(_RecursiveTreeLookup):
    """`pk__ancestor_of=<pk, instance, or name>`: matches ancestors, excluding self."""

    lookup_name = "ancestor_of"

    def as_sql(self, compiler, connection):
        lhs_sql, lhs_params = self.process_lhs(compiler, connection)
        rhs_sql, rhs_params = self.process_rhs(compiler, connection)
        ids = self._identifiers(connection)

        sql = (
            f"{lhs_sql} IN ("
            f"WITH RECURSIVE ancestor_tree(id, path) AS ("
            f"SELECT loc.{ids['parent_column']}, ARRAY[loc.{ids['parent_column']}] "
            f"FROM {ids['table']} AS loc "
            f"WHERE loc.{ids['pk_column']} = {rhs_sql} AND loc.{ids['parent_column']} IS NOT NULL "
            "UNION ALL "
            f"SELECT loc.{ids['parent_column']}, anc.path || loc.{ids['parent_column']} "
            f"FROM {ids['table']} AS loc "
            f"INNER JOIN ancestor_tree AS anc ON loc.{ids['pk_column']} = anc.id "
            f"WHERE loc.{ids['parent_column']} IS NOT NULL "
            f"AND NOT loc.{ids['parent_column']} = ANY(anc.path)"
            ") SELECT id FROM ancestor_tree"
            ")"
        )
        params = list(lhs_params) + list(rhs_params)
        return sql, params
