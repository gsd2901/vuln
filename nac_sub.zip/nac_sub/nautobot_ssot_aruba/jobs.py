from diffsync.logging import enable_console_logging
from nautobot.core.celery import register_jobs
from nautobot_ssot.jobs.base import DataSource
from nautobot_ssot_aruba.diffsync.adapters.aruba import ArubaAdapter
from nautobot_ssot_aruba.diffsync.adapters.nautobot import ArubaSSOtNautobotAdapter
from nautobot.dcim.models import Controller
from nautobot.apps.jobs import BooleanVar, ObjectVar, Job
from diffsync.enum import DiffSyncFlags

name = "Aruba SSoT" #pylint: disable-invalid-name

class ArubaSSOTJob(DataSource):
    """Synchronize device data from aruba into Nautobot safely (no deletions)."""
    dryrun = BooleanVar(description="Run in dry run mode (no database changes)")
    aruba_controller = ObjectVar(
        model= Controller,
        required = True,
        description="Select the Aruba Controller instance to sync from."
    )
    
    class Meta:
        name = "Aruba -> Nautobot Device Sync"
        description = "Synchronize device and related data from Aruba with Nautobot code models."
        approval_required = False
        has_sensitive_variables = False
    
    def load_source_adapter(self):
        """Initialize Aruba data source adapter using instance context"""
        self.logger.debug("loading aruba source adapter for : %s", self.aruba_controller)
        self.source_adapter = ArubaAdapter(aruba = self.aruba_controller, job=self)
        self.logger.debug(f"the object and it dir :{dir(self.source_adapter)}")
        self.source_adapter.load()
        self.logger.debug("loading aruba source adapter for :")
        
    def load_target_adapter(self):
        """Initialize Nautobot data target adapter"""
        self.logger.debug("Loading nautobot target adapter.")
        self.target_adapter = ArubaSSOtNautobotAdapter(aruba = self.aruba_controller,job=self)
        self.target_adapter.load()

        
    def run(self, aruba_controller:Controller, dryrun: bool = False, **kwargs):
        """Standard SSoT job entrypoint."""
        self.aruba_controller = aruba_controller
        self.diffsync_flags = DiffSyncFlags.SKIP_UNMATCHED_DST
        self.dryrun = dryrun
        return super().run(aruba_controller=self.aruba_controller,dryrun=self.dryrun,flags=DiffSyncFlags.SKIP_UNMATCHED_DST, **kwargs)

jobs = [ArubaSSOTJob]
register_jobs(*jobs)