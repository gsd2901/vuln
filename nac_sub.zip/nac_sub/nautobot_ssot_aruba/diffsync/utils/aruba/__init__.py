import uuid
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
from nautobot.extras.choices import (
    SecretsGroupAccessTypeChoices,
    SecretsGroupSecretTypeChoices,
)

DEFAULT_TIMEOUT = 10
RETRY_STRATEGY = Retry(
    total=3,
    backoff_factor=0.5,
    status_forcelist=(429, 500, 502, 503, 504),
    allowed_methods=frozenset(["GET", "POST", "PUT", "DELETE", "PATCH"]),
)

class ArubaAdapterError(Exception):
    """Base exception for ArubaAdapter errors."""

class ArubaAPIError(ArubaAdapterError):
    """Raised when the Aruba API returns an error or unexpected payload"""

class ValidationError(ArubaAdapterError):
    """Raised when a record fails basic validation."""

class Aruba:
    """
    Updated adapter to authenticate with Aruba Central (OAuth2)
    instead of Lighthouse.
    """

    def __init__(self, controller=None, job=None, base_url=None):
        self.aruba = controller
        self.job = job

        # Aruba API host (example: "apigw-uswest4.central.arubanetworks.com")
        self.api_host = self._get_aruba_host()

        # Refresh token login creds
        self.creds = self._get_creds_from_controller()
        self.refresh_token = self.creds.get("refresh_token")
        self.client_id = self.creds.get("client_id")
        self.client_secret = self.creds.get("client_secret")

        self.session = self._build_session()

        # OAuth2 access token
        self.access_token = self._refresh_access_token()
        
        self.base_url = f"{self.api_host}"

        self.job.logger.info("Initialized ArubaAdapter (api host: %s)", self.api_host)

    def _get_aruba_host(self):
        """Return Aruba Central API host stored in Nautobot secrets."""
        try:
            val = self.aruba.external_integration.remote_url
            if not val:
                raise ArubaAdapterError("Empty Aruba API Host in secrets.")
            return val
        except Exception as exc:
            self.job.logger.exception("Failed to get Aruba API Host")
            raise ArubaAdapterError("Failed to get Aruba API Host") from exc

    def _get_creds_from_controller(self):
        """Fetch client_id, client_secret, refresh_token from controller."""
        try:
            secrets = {}
            secrets['client_id']=self.aruba.external_integration.secrets_group.get_secret_value(
                access_type = SecretsGroupAccessTypeChoices.TYPE_HTTP,
                secret_type = SecretsGroupSecretTypeChoices.TYPE_USERNAME
            )
            secrets['client_secret']=self.aruba.external_integration.secrets_group.get_secret_value(
                access_type = SecretsGroupAccessTypeChoices.TYPE_HTTP,
                secret_type = SecretsGroupSecretTypeChoices.TYPE_PASSWORD
            )
            secrets['refresh_token']=self.aruba.external_integration.secrets_group.get_secret_value(
                access_type = SecretsGroupAccessTypeChoices.TYPE_HTTP,
                secret_type = SecretsGroupSecretTypeChoices.TYPE_TOKEN
            )
            
            return secrets
        except Exception as exc:
            self.job.logger.exception("Failed to load Aruba Central secrets")
            raise ArubaAdapterError("Failed to load Aruba Central secrets") from exc

    # ---------------------------------------------------------------------
    # OAuth2 TOKEN
    # ---------------------------------------------------------------------
    def _refresh_access_token(self):
        """Refresh Aruba Central access token."""
        token_url = f"{self.api_host}/oauth2/token"

        payload = {
            "grant_type": "refresh_token",
            "client_id": self.client_id,
            "client_secret": self.client_secret,
            "refresh_token": self.refresh_token,
        }

        resp = self.session.post(
            token_url, data=payload, timeout=DEFAULT_TIMEOUT, verify=False
        )
        resp.raise_for_status()

        data = resp.json()
        token = data.get("access_token")
        if not token:
            raise ArubaAdapterError(f"Token refresh failed: {data}")

        # Set bearer token header
        self.session.headers.update({"Authorization": f"Bearer {token}"})
        return token

    # ---------------------------------------------------------------------
    # Build Requests session
    # ---------------------------------------------------------------------
    def _build_session(self) -> requests.Session:
        s = requests.Session()
        adapter = HTTPAdapter(max_retries=RETRY_STRATEGY)
        s.mount("https://", adapter)
        s.mount("http://", adapter)
        s.headers.update({"User-Agent": f"nautobot-aruba-adapter/{uuid.uuid4()}"})
        return s
