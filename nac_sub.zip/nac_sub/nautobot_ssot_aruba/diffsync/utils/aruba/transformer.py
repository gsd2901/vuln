from typing import Dict, Any
from nautobot_ssot_aruba.diffsync.utils.aruba import ValidationError

def transform_record(raw: Dict[str, Any], logger) -> Dict[str, Any]:
    """
    Transform Aruba Central devices (Switches + APs)
    into unified DiffSync internal structure.
    """

    try:
        device_type = raw.get("device_type", "switch")  # default to switch

        # -------------------------
        # Shared fields
        # -------------------------
        record = {
            "id": raw.get("serial", raw.get("name")),
            "name": raw.get("name"),
            "serial_number": raw.get("serial"),
            "manufacturer": "Aruba",
            "operating_system": raw.get("firmware_version", ""),
            "location": raw.get("site", "Unknown"),
            "namespace": "Aruba",
            "tenant": "Default Tenant",
            "prefix": "",
            "vrfName": "",
            "vrfRd": "",
            "vlanName": "",
            "vlanid": 0,
            "interfaces": raw.get("interfaces", []),
            "ip_address": raw.get("ip_address"),
            "internet_facing": False,
        }

        # -------------------------
        # Switch-specific
        # -------------------------
        if device_type == "switch":
            record.update({
                "role": "Switch",
                "model_id": raw.get("model", "Switch"),
                "operational_status": raw.get("status", "Unknown"),
            })

        # -------------------------
        # AP-specific
        # -------------------------
        elif device_type == "ap":
            record.update({
                "role": "Access Point",
                "model_id": raw.get("model", "Access Point"),
                "operational_status": raw.get("status", "Unknown"),
            })

        logger.debug(
            "Transformed Aruba %s record %s -> %s",
            device_type, raw.get("name"), record
        )
        logger.debug(f" the record is {record}")
        return record

    except Exception as exc:
        logger.exception("Failed to transform record: %s", raw)
        raise ValidationError("Failed to transform Aruba Central record") from exc
