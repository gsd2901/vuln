def fetch_devices(session, api_host, logger):
    """
    Fetch Aruba Central Switches + APs together.
    """
    all_devices = []

    # -----------------------------------------
    # Fetch SWITCHES
    # -----------------------------------------
    switch_endpoint = f"{api_host}/monitoring/v1/switches"
    logger.info(f"Fetching Aruba Switches: {switch_endpoint}")

    try:
        resp = session.get(switch_endpoint, timeout=10, verify=False)
        resp.raise_for_status()
        data = resp.json()
        switches = data.get("switches") or []
        logger.info(f"Fetched {len(switches)} switches")

        for sw in switches:
            sw["device_type"] = "switch"      # <-- important flag
        all_devices.extend(switches)

    except Exception:
        logger.exception("Failed to fetch Aruba switches")

    # -----------------------------------------
    # Fetch APs
    # -----------------------------------------
    ap_endpoint = f"{api_host}/monitoring/v2/aps"
    logger.info(f"Fetching Aruba APs: {ap_endpoint}")

    try:
        resp = session.get(ap_endpoint, timeout=10, verify=False)
        resp.raise_for_status()
        data = resp.json()
        aps = data.get("aps") or []
        logger.info(f"Fetched {len(aps)} APs")

        for ap in aps:
            ap["device_type"] = "ap"          # <-- important flag
        all_devices.extend(aps)

    except Exception:
        logger.exception("Failed to fetch Aruba APs")

    logger.info(f"Total Aruba devices fetched: {len(all_devices)}")
    return all_devices
