from __future__ import annotations
from typing import Any, Dict, Iterable, List, Optional, Set
import requests
from diffsync import Adapter
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
from nautobot_ssot_aruba.diffsync.utils.aruba import fetch_devices as fetch
from nautobot_ssot_aruba.diffsync.utils.aruba import transformer as transform
from nautobot_ssot_aruba.diffsync.utils.aruba import Aruba
from nautobot.dcim.models import Controller

from nautobot_ssot_aruba.diffsync.models.aruba import (
    ArubaDevice,
    ArubaDeviceType,
    ArubaManufacturer,
    ArubaLocation,
    ArubaIPAddress,
    ArubaInterface,
    ArubaStatus,
    ArubaPlatform,
    ArubaNameSpace,
    ArubaRole,
    ArubaTenant,
)

# ------- Adapter---------


class ArubaAdapter(Adapter):
    """
    Diffsync adapter for Aruba -> Nautobot
    Usage:
        adapter = ArubaAdapter(aruba_controller, job=myjob_instance)
        adapter.load() #seeds diffsync objects from aruba
        # Then use adapter.run_sync() or export the nautobotas needed

    """

    device = ArubaDevice
    device_type = ArubaDeviceType
    manufacturer = ArubaManufacturer
    location = ArubaLocation
    ipaddress = ArubaIPAddress
    interface = ArubaInterface
    status = ArubaStatus
    platform = ArubaPlatform
    namespace = ArubaNameSpace
    role = ArubaRole
    tenant = ArubaTenant

    top_level = {
        "manufacturer",
        "device_type",
        "status",
        "platform",
        "location",
        "role",
        "namespace",
        "tenant",
        "device",
        "interface",
        "ipaddress",
    }

    def __init__(
        self,
        aruba: Controller,
        job: Optional[Any] = None,
        base_url: Optional[str] = None,
    ):
        """
        :param self: Description
        :param aruba: Description
        :param job: Description
        :param base_url: Description
        """
        super().__init__()
        self.job = job
        self.aruba = aruba
        self.aruba_object = Aruba(self.aruba, self.job, base_url)
        self.session = self.aruba_object.session
        self.url = self.aruba_object.base_url

    def fetch_from_aruba(self):
        self.job.logger.debug(f"Here we are calling fetch_from_aruba")
        return fetch.fetch_devices(self.session, self.url, self.job.logger)

    def transform_aruba_record(self, raw):
        return transform.transform_record(raw, self.job.logger)

    def _add_if_missing(
        self, obj_type_callable, identifier_field: str, identifier_value: Any, **kwargs
    ):
        """
        Add a DiffSync object only if an object type with identifier_value not already present in the memory model list for this session
        """
        existing_values = {
            getattr(o, identifier_field)
            for o in self._get_objects_of_type(obj_type_callable)
        }
        if identifier_value in existing_values:
            self.job.logger.debug(
                "Skipping add of %s-%s; already present",
                identifier_field,
                identifier_value,
            )
            return
        self.job.logger.debug("Adding object %s-%s", identifier_field, identifier_value)
        self.add(obj_type_callable(**kwargs))

    def _get_objects_of_type(self, obj_type_callable) -> Iterable:
        """
        Return list in memory objects of a given diffsync type already added. Diffsync keeps objects on self; we can introspect by name but the simpler safe approach is to read self._objects attribute(internal). If your Diffsync version adapt this method or maintain your own membership sets.
        """

        try:
            type_name = obj_type_callable.__name__
            objs = []
            if hasattr(self, "_objects") and type_name in self._objects:
                objs = list(self._objects[type_name].values())
            return objs
        except Exception:
            return []

    # -------- Entity specific convenience methods---------
    def ensure_manufacturer(self, name: str):
        if not name:
            name = "unknown"
        self._add_if_missing(self.manufacturer, "name", name, name=name)

    def ensure_device_type(self, model_ref: str):
        model_ref = model_ref or "unknown"
        self._add_if_missing(self.device_type, "model", model_ref, model=model_ref)

    def ensure_location(self, name: str, status: str):
        name = name or "Aruba Staging"
        self.add(self.location(name=name,status__name=status))
        # self._add_if_missing(self.location, "name", name, status__name=status, name=name)

    def ensure_status(self, name: str):
        name = name or "unknown"
        self._add_if_missing(self.status, "name", name, name=name)

    def ensure_platform(self, name: str):
        name = name or "unknown"
        self._add_if_missing(self.platform, "name", name, name=name)

    def ensure_role(self, name: str):
        name = name or "defaultrole"
        self._add_if_missing(self.role, "name", name, name=name)

    def ensure_namespace(self, name:str):
        name = name or "Global"
        self._add_if_missing(self.namespace,"name",name,name=name)

    def ensure_tenant(self, name: str):
        name = name or "defaultTenant"
        self._add_if_missing(self.tenant, "name", name, name=name)

    def ensure_prefix(
        self,
        prefix: str,
        namespace: str,
        status: str,
        role: str,
        tenant: str,
        vlan: str,
        locations: List[str],
    ):
        prefix = prefix or "0.0.0.0/0"
        self._add_if_missing(
            self.prefix,
            "prefix",
            prefix,
            prefix=prefix,
            namespace=namespace,
            status=status,
            role=role,
            tenant=tenant,
            vlan=vlan,
            locations=locations,
        )

    def add_ip_if_new(
        self,
        ip_address: str,
        device_name: str,
        interface_name: str,
        status: str,
        role: str,
        namespace: str,
    ):
        if not ip_address:
            return
        existing_addrs = {
            getattr(x, "address", None)
            for x in self._get_objects_of_type(self.ipaddress)
        }
        if ip_address in existing_addrs:
            self.job.logger.debug("Skipping ip %s (already added)", ip_address)
            return

        self.add(
            self.ipaddress(
                host=ip_address,
                status=status,
                role__name=role,
                namespace=namespace,
                interface__name=interface_name,
                device__name=device_name,
            )
        )

    def add_interface_if_new(
            self, device_name: str, iface: Dict[str, Any], status: str
        ):
            name = iface.get("name")
            if not name:
                return
            existing_ifaces = {
                (getattr(x, "device_name", None), getattr(x, "name", None))
                for x in self._get_objects_of_type(self.interface)
            }
            if (device_name, name) in existing_ifaces:
                self.job.logger.debug(
                    "Skipping interface %s on %s (already exist)", name, device_name
                )
                return
            self.add(
                self.interface(
                    device__name=device_name,
                    name=name,
                    enabled=iface.get("enabled", True),
                    type=iface.get("type", ""),
                    description=iface.get("description", "") or "",
                    status=status,
                )
            )

    # -------- Main load flow ----------
    def load(self):
            """
            Primary entrypoint to fetch aruba data and seed diffsync objects. After calling load(), Diffsync's internal graph will be populated with manufacturers, types, devices, interfaces, ipadddress etc.
            """
            self.job.logger.debug(f"calling the load function")
            nodes = self.fetch_from_aruba()
            records = [self.transform_aruba_record(n) for n in nodes]
            # local in memory trackers to avoid repeated checks
            seen_devices: Set[str] = set()
            seen_device_types: Set[str] = set()
            seen_manufacturers: Set[str] = set()
            seen_locations: Set[str] = set()
            seen_ipaddresses: Set[str] = set()
            seen_interfaces: Set[str] = set()
            seen_statuses: Set[str] = set()
            seen_platforms: Set[str] = set()
            seen_namespaces: Set[str] = set()
            seen_roles: Set[str] = set()
            seen_tenants: Set[str] = set()

            for r in records:
                if r["manufacturer"] not in seen_manufacturers:
                    self.ensure_manufacturer(r["manufacturer"])
                    seen_manufacturers.add(r["manufacturer"])

                if r["model_id"] not in seen_device_types:
                    self.ensure_device_type(r["model_id"])
                    seen_device_types.add(r["model_id"])

                if r["location"] not in seen_locations:
                    self.ensure_location(r["location"], r["operational_status"])
                    seen_locations.add(r["location"])

                if r["operational_status"] not in seen_statuses:
                    self.ensure_status(r["operational_status"])
                    seen_statuses.add(r["operational_status"])

                if r["operating_system"] not in seen_platforms:
                    self.ensure_platform(r["operating_system"])
                    seen_platforms.add(r["operating_system"])

                if r["role"] not in seen_roles:
                    self.ensure_role(r["role"])
                    seen_roles.add(r["role"])

                if r["namespace"] not in seen_namespaces:
                    self.ensure_namespace(r["namespace"])
                    seen_namespaces.add(r["namespace"])

                if r["tenant"] not in seen_tenants:
                    self.ensure_tenant(r["tenant"])
                    seen_tenants.add(r["tenant"])

                for iface in r.get("interfaces", []):
                    ipv4 = iface.get("ipv4_addr")
                    if ipv4 and ipv4 not in seen_ipaddresses:
                        self.add_ip_if_new(
                            ip_address=ipv4,
                            device_name=r["name"],
                            interface_name=iface.get("name", ""),
                            status=r["operational_status"],
                            role=r["role"],
                            namespace=r["namespace"],
                        )
                        seen_ipaddresses.add(ipv4)

                # Add device
                # avoid duplicates: check in memory device list first
                existing_device_names = {
                    getattr(d, "name") for d in self._get_objects_of_type(self.device)
                }
                if r["name"] not in existing_device_names and r["serial_number"]:
                    try:
                        self.add(
                            self.device(
                                name=r["name"],
                                serial=r["serial_number"],
                                device_type__model=r["model_id"],
                                location__name=r["location"],
                                platform__name=r["operating_system"],
                                manufacturer=r["manufacturer"],
                                status__name=r["operational_status"],
                                primary_ipv4__host="",
                                primary_ipv6__host="",
                            )
                        )
                    except Exception as e:
                        continue

                # Add interfaces
                seen_iface_names: Set[str] = set()
                for iface in r.get("interfaces", []):
                    iface_name = iface.get("name")
                    if iface_name and iface_name not in seen_iface_names:
                        self.add_interface_if_new(
                            r["name"], iface, r["operational_status"]
                        )
                        seen_iface_names.add(iface_name)

            self.job.logger.info("Load complete: %d records processed", len(records))
