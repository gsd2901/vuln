from __future__ import annotations
import logging
from typing import Any, Dict, Iterable, List, Optional, Set
from django.db import transaction
from django.db.models import Prefetch
from diffsync import DiffSync


from nautobot.dcim.models import (
    Device,
    DeviceType,
    Manufacturer,
    Location,
    Interface,
    Platform,
)
from nautobot.ipam.models import IPAddress, Prefix, Namespace, VLAN, VRF
from nautobot.tenancy.models import Tenant
from nautobot.extras.models import Status, Role
from nautobot_ssot.contrib import NautobotAdapter

from nautobot_ssot_aruba.diffsync.models.nautobot import (
    NautobotDevice,
    NautobotDeviceType,
    NautobotManufacturer,
    NautobotLocation,
    NautobotIPAddress,
    NautobotInterface,
    NautobotStatus,
    NautobotPlatform,
    NautobotNameSpace,
    NautobotRole,
    NautobotTenant,
)

DEFAULT_BATCH_SIZE = 1000


def _safe_str(obj: Optional[object]) -> str:
    return str(obj) if obj is not None else ""


class ArubaSSOtNautobotAdapter(NautobotAdapter):
    """
    DiffSync adapter that loads Nautobot data into DiffSync models.
    This adapter intetionally performs *read-only* operations against the Nautobot ORM It converts related Fields to name/IDs expected by the plugins's Diffsync models and skips relationships that cannot be reolved
    """

    device = NautobotDevice
    device_type = NautobotDeviceType
    manufacturer = NautobotManufacturer
    location = NautobotLocation
    ipaddress = NautobotIPAddress
    interface = NautobotInterface
    status = NautobotStatus
    platform = NautobotPlatform
    namespace = NautobotNameSpace
    role = NautobotRole
    tenant = NautobotTenant

    top_level = {
        "manufacturer",
        "device_type",
        "status",
        "platform",
        "location",
        "role",
        "namespace",
        "tenant",
        "device",
        "interface",
        "ipaddress",
    }

    def __init__(self, aruba, *args, batch_size: int = DEFAULT_BATCH_SIZE, **kwargs):
        
        super().__init__(*args, **kwargs)
        self._backend = "Nautobot"
        self.batch_size = batch_size
        self.aruba = aruba

    def load_manufacturers(self):
        for mfg in Manufacturer.objects.all():
            self.add(self.manufacturer(name=mfg.name))

    def load_device_type(self):
        for dt in DeviceType.objects.select_related("manufacturer"):
            self.add(
                self.device_type(
                    model=dt.model,
                    manufacturere__name=(
                        dt.manufacturer.name if dt.manufacturer else None
                    ),
                )
            )

    def load_statuses(self):
        for st in Status.objects.all():
            self.add(self.status(name=st.name))

    def load_roles(self):
        for role_obj in Role.objects.all():
            self.add(self.role(name=role_obj.name))

    def load_platforms(self):
        for platform_obj in Platform.objects.all():
            self.add(self.platform(name=platform_obj.name))

    def load_tenants(self):
        for tenant_obj in Tenant.objects.all():
            self.add(self.tenant(name=tenant_obj.name))

    def load_namespaces(self):
        for namespace_obj in Namespace.objects.all():
            self.add(self.namespace(name=namespace_obj.name))

    def load_locations(self):
        for loc in Location.objects.select_related("status"):
            try:
                self.add(
                    self.location(
                        name=loc.name,
                        status__name=loc.status.name if loc.status else None,
                    )
                )
            except Exception as e:
                continue


    def load_devicesx(self):
        for device_obj in Device.object.filter(location__name == "Location Staging").select_related(
            "device_type", "location", "platform", "status"
        ):
            self.add(
                self.device(
                    name=device_obj.name,
                    serial=device_obj.serial,
                    device_type=(
                        device_obj.device_type.model if device_obj.device_type else None
                    ),
                    location=device_obj.location.name if device_obj.location else None,
                    platform=device_obj.platform.name if device_obj.platform else None,
                    status=device_obj.status.name if device_obj.status else None,
                    primary_ip4=(
                        str(device_obj.primary_ip4) if device_obj.primary_ip4 else None
                    ),
                    primary_ip6=(
                        str(device_obj.primary_ip6) if device_obj.primary_ip6 else None
                    ),
                )
            )
            
    def load_devices(self):
        # If controller selected, filter based on its managed device group
        if self.aruba:
            try:
                md_group = self.aruba.managed_device_group
                qs = Device.objects.filter(managed_device_group=md_group)
            except Exception:
                qs = Device.objects.none()
        else:
            qs = Device.objects.all()

        qs = qs.select_related("device_type", "location", "platform", "status")

        for device_obj in qs:
            self.add(
                self.device(
                    name=device_obj.name,
                    serial=device_obj.serial,
                    device_type__model=device_obj.device_type.model if device_obj.device_type else None,
                    location__name=device_obj.location.name if device_obj.location else None,
                    platform__name=device_obj.platform.name if device_obj.platform else None,
                    status__name=device_obj.status.name if device_obj.status else None,
                    primary_ip4__host=str(device_obj.primary_ip4) if device_obj.primary_ip4 else None,
                    primary_ip6__host=str(device_obj.primary_ip6) if device_obj.primary_ip6 else None,
                )
            )

    def load_interfaces(self):
        for intf in Interface.objects.select_related("device", "status"):
            try:
                self.add(
                    self.interface(
                        device__name=intf.device.name if intf.device else None,
                        name=intf.name,
                        enabled=intf.enabled,
                        type=intf.type,
                        description=intf.description,
                        status=intf.status.name if intf.status else None,
                    )
                    )
            except Exception as e:
                continue
        

    # def load_ipaddresss(self):
    #     self.job.logger.debug(f"here is the load of nautobot")
    #     for ip in IPAddress.objects.select_related(
    #         "parent",  "status", "role"
    #     ):
    #         try:
    #             interface_name = None
    #             device_name = None
    #             self.job.logger.info(f"the device_name is  {device_name}")
    #             if hasattr(ip, "assigned_object") and isinstance(
    #                 ip.assigned_object, Interface
    #             ):
    #                 interface_name = ip.assigned_object.name
    #                 device_name = (
    #                     ip.assigned_object.device.name
    #                     if ip.assigned_object.device
    #                     else None
    #                 )
    #             elif hasattr(ip, "device") and ip.device:
    #                 device_name = ip.device.name
    #             self.job.logger.info(f"the device_name is  {device_name}")
    #             self.add(
    #                 self.ipaddress(
    #                     host=str(ip.host),
    #                     mask_length=ip.mask_length,
    #                     namespace=(
    #                         ip.parent.namespace.name
    #                         if getattr(ip, "parent", None) and ip.parent.namespace
    #                         else None
    #                     ),
    #                     status=ip.status.name if ip.status else None,
    #                     role__name=ip.role.name if ip.role else None,
    #                     interface__name=interface_name,
    #                     device__name=device_name,
    #                     tenant=ip.tenant.name if getattr(ip, "tenant", None) else None,
    #                 )
    #             )
    #         except Exception as e:
    #             self.job.logger.info(f"the errpr is : {e}")

    def load_ipaddresss(self):
        self.job.logger.debug("here is the load of nautobot")
        for ip in IPAddress.objects.select_related(
            "status", "role", "parent", "tenant", "nat_inside"
        ):
            try:
                interface_name = None
                device_name = None
                
                if hasattr(ip, "assigned_object") and isinstance(ip.assigned_object, Interface):
                    interface_name = ip.assigned_object.name
                    device_name = ip.assigned_object.device.name if ip.assigned_object.device else None
                elif hasattr(ip, "device") and ip.device:
                    device_name = ip.device.name

                # As before, namespace safe check
                namespace_name = None

                self.add(
                    self.ipaddress(
                        host=str(ip.host),
                        mask_length=ip.mask_length,
                        namespace=namespace_name,
                        status=ip.status.name if ip.status else None,
                        role__name=ip.role.name if ip.role else None,
                        interface__name=interface_name,
                        device__name=device_name,
                        tenant=ip.tenant.name if ip.tenant else None,
                    )
                )
            except Exception as e:
                self.job.logger.info(f"the error is : {e}")




    # def load_ipaddresss(self):
    #     self.job.logger.debug(f"here is the load of nautobot")
    #     qs = (
    #         IPAddress.objects.select_related(
    #             "parent",
    #             "parent_namespace",
    #             "status",
    #             "role",
    #             "tenant",
    #         )
    #         .prefetch_related(
    #             "interfaces__device",
    #             "vm_interfaces__virtual_machine",
    #             "primary_ip4_for",
    #             "primary_ip6_for",
    #         )
    #     )

    #     for ip in qs:
    #         self.job.logger.debug(f"here is the load of nautobot {ip}")
    #         try:
    #             interface_name = None
    #             device_name = None

    #             # 1) Physical interfaces (preferred)
    #             self.job.logger.debug(f"here is the load of nautobot 263")
    #             if hasattr(ip, "interfaces") and ip.interfaces.exists():
    #                 iface = ip.interfaces.first()
    #                 if isinstance(iface, Interface) and iface.device:
    #                     interface_name = iface.name
    #                     device_name = iface.device.name

    #             # 2) VM interfaces if no physical interface
    #             self.job.logger.debug(f"here is the load of nautobot 271")
    #             if not device_name and hasattr(ip, "vm_interfaces") and ip.vm_interfaces.exists():
    #                 vm_iface = ip.vm_interfaces.first()
    #                 if vm_iface and vm_iface.virtual_machine:
    #                     interface_name = vm_iface.name
    #                     device_name = vm_iface.virtual_machine.name

    #             # 3) Fallback: devices/VMs for which this is primary IP
    #             if not device_name and hasattr(ip, "primary_ip4_for") and ip.primary_ip4_for.exists():
    #                 primary4 = ip.primary_ip4_for.first()
    #                 if primary4:
    #                     device_name = primary4.name

    #             if not device_name and hasattr(ip, "primary_ip6_for") and ip.primary_ip6_for.exists():
    #                 primary6 = ip.primary_ip6_for.first()
    #                 if primary6:
    #                     device_name = primary6.name

    #             self.job.logger.info(f"IP {ip.host}: device={device_name}, interface={interface_name}")
    #             self.job.logger.debug(f"here is the load of nautobot 290")
    #             self.add(
    #                 self.ipaddress(
    #                     host=str(ip.host),
    #                     mask_length=ip.mask_length,
    #                     namespace=(
    #                         ip.parent.namespace.name
    #                         if getattr(ip, "parent", None) and getattr(ip.parent, "namespace", None)
    #                         else None
    #                     ),
    #                     status=ip.status.name if ip.status else None,
    #                     role__name=ip.role.name if ip.role else None,
    #                     interface__name=interface_name,
    #                     device__name=device_name,  # This is SAFE now
    #                     tenant=ip.tenant.name if getattr(ip, "tenant", None) else None,
    #                 )
    #             )
    #         except Exception as e:
    #             self.job.logger.error(f"Failed IP {getattr(ip, 'host', 'unknown')}: {e}")
    #             continue

    
    def load(self):
        self.job.logger.debug(f"here is the load of nautobot")
        for model_name in self.top_level:
            self.job.logger.debug(f"here is the load of nautobot with model {model_name}")
            loader = getattr(self, f"load_{model_name}s", None)
            if loader:
                loader()
            else:
                self.job.logger.debug(f"here is the load of nautobot with model {model_name} in else block")
                diffsync_cls = getattr(self, model_name)
                self._load_objects(diffsync_cls)
