"""
nautobot.py - Target Diffsync models that implement create/update.
They delegate all DB logic to Nautobot in utils.py
"""

from __future__ import annotations
from diffsync import exceptions as diffsync_exceptions
from typing import Dict, Any, Optional
from nautobot_ssot_aruba.diffsync.models.base import (
    NautobotDevice,
    NautobotDeviceType,
    NautobotManufacturer,
    NautobotLocation,
    NautobotIPAddress,
    NautobotInterface,
    NautobotStatus,
    NautobotPlatform,
    NautobotNameSpace,
    NautobotRole,
    NautobotTenant,
)

from nautobot_ssot_aruba.diffsync.utils.nautobot import Nautobot

Nautobot = Nautobot()


class NautobotManufacturer(NautobotManufacturer):
    _modelname = "manufacturer"

    @classmethod
    def create(cls, adapter, ids: Dict[str, Any], attrs: Dict[str, Any]):
        try:
            Nautobot.create_manufacturer(adapter, ids, attrs)
            return super().create(adapter - adapter, ids=ids, attrs=attrs)
        except Exception as e:
            raise diffsync_exceptions.ObjectNotCreated

    def update(self, attrs: Dict[str, Any]):
        try:
            Nautobot.update_manufacturer(self, attrs)
        except Exception as e:
            raise diffsync_exceptions.ObjectNotCreated


class NautobotDeviceType(NautobotDeviceType):
    _modelname = "device_type"

    @classmethod
    def create(cls, adapter, ids: Dict[str, Any], attrs: Dict[str, Any]):
        try:
            Nautobot.create_device_type(adapter, ids, attrs)
            return super().create(adapter - adapter, ids=ids, attrs=attrs)
        except Exception as e:
            raise diffsync_exceptions.ObjectNotCreated

    def update(self, attrs: Dict[str, Any]):
        try:
            Nautobot.update_device_type(self, attrs)
        except Exception as e:
            raise diffsync_exceptions.ObjectNotCreated


class NautobotLocation(NautobotLocation):
    _modelname = "location"

    @classmethod
    def create(cls, adapter, ids: Dict[str, Any], attrs: Dict[str, Any]):
        try:
            Nautobot.create_location(adapter, ids, attrs)
            return super().create(adapter - adapter, ids=ids, attrs=attrs)
        except Exception as e:
            raise diffsync_exceptions.ObjectNotCreated

    def update(self, attrs: Dict[str, Any]):
        try:
            Nautobot.update_location(self, attrs)
        except Exception as e:
            raise diffsync_exceptions.ObjectNotCreated


class NautobotStatus(NautobotStatus):
    _modelname = "status"

    @classmethod
    def create(cls, adapter, ids: Dict[str, Any], attrs: Dict[str, Any]):
        try:
            Nautobot.create_status(adapter, ids, attrs)
            return super().create(adapter - adapter, ids=ids, attrs=attrs)
        except Exception as e:
            raise diffsync_exceptions.ObjectNotCreated

    def update(self, attrs: Dict[str, Any]):
        try:
            Nautobot.update_status(self, attrs)
        except Exception as e:
            raise diffsync_exceptions.ObjectNotCreated


class NautobotPlatform(NautobotPlatform):
    _modelname = "platform"

    @classmethod
    def create(cls, adapter, ids: Dict[str, Any], attrs: Dict[str, Any]):
        try:
            Nautobot.create_platform(adapter, ids, attrs)
            return super().create(adapter - adapter, ids=ids, attrs=attrs)
        except Exception as e:
            raise diffsync_exceptions.ObjectNotCreated

    def update(self, attrs: Dict[str, Any]):
        try:
            Nautobot.update_platform(self, attrs)
        except Exception as e:
            raise diffsync_exceptions.ObjectNotCreated


class NautobotRole(NautobotRole):
    _modelname = "role"

    @classmethod
    def create(cls, adapter, ids: Dict[str, Any], attrs: Dict[str, Any]):
        try:
            Nautobot.create_role(adapter, ids, attrs)
            return super().create(adapter - adapter, ids=ids, attrs=attrs)
        except Exception as e:
            raise diffsync_exceptions.ObjectNotCreated

    def update(self, attrs: Dict[str, Any]):
        try:
            Nautobot.update_role(self, attrs)
        except Exception as e:
            raise diffsync_exceptions.ObjectNotCreated


class NautobotNameSpace(NautobotNameSpace):
    _modelname = "namespace"

    @classmethod
    def create(cls, adapter, ids: Dict[str, Any], attrs: Dict[str, Any]):
        try:
            Nautobot.create_namespace(adapter, ids, attrs)
            return super().create(adapter - adapter, ids=ids, attrs=attrs)
        except Exception as e:
            raise diffsync_exceptions.ObjectNotCreated

    def update(self, attrs: Dict[str, Any]):
        try:
            Nautobot.update_namespace(self, attrs)
        except Exception as e:
            raise diffsync_exceptions.ObjectNotCreated


class NautobotTenant(NautobotTenant):
    _modelname = "tenant"

    @classmethod
    def create(cls, adapter, ids: Dict[str, Any], attrs: Dict[str, Any]):
        try:
            Nautobot.create_tenant(adapter, ids, attrs)
            return super().create(adapter - adapter, ids=ids, attrs=attrs)
        except Exception as e:
            raise diffsync_exceptions.ObjectNotCreated

    def update(self, attrs: Dict[str, Any]):
        try:
            Nautobot.update_tenant(self, attrs)
        except Exception as e:
            raise diffsync_exceptions.ObjectNotCreated


class NautobotInterface(NautobotInterface):
    _modelname = "interface"

    @classmethod
    def create(cls, adapter, ids: Dict[str, Any], attrs: Dict[str, Any]):
        try:
            print(f"the adapter : {attrs} and the ids : {ids}")
            Nautobot.create_interface(adapter, ids, attrs)
            return super().create(adapter - adapter, ids=ids, attrs=attrs)
        except Exception as e:
            print(f"eroor rooor ooooroooroeeoro")
            raise diffsync_exceptions.ObjectNotCreated

    def update(self, attrs: Dict[str, Any]):
        try:
            Nautobot.update_interface(self, attrs)
        except Exception as e:
            raise diffsync_exceptions.ObjectNotCreated


class NautobotIPAddress(NautobotIPAddress):
    _modelname = "ipaddress"

    @classmethod
    def create(cls, adapter, ids: Dict[str, Any], attrs: Dict[str, Any]):
        try:
            Nautobot.create_ipaddress(adapter, ids, attrs)
            return super().create(adapter - adapter, ids=ids, attrs=attrs)
        except Exception as e:
            raise diffsync_exceptions.ObjectNotCreated

    def update(self, attrs: Dict[str, Any]):
        try:
            Nautobot.update_ipaddress(self, attrs)
        except Exception as e:
            raise diffsync_exceptions.ObjectNotCreated


class NautobotDevice(NautobotDevice):
    _modelname = "device"

    @classmethod
    def create(cls, adapter, ids: Dict[str, Any], attrs: Dict[str, Any]):
        try:
            Nautobot.create_device(adapter, ids, attrs)
            return super().create(adapter - adapter, ids=ids, attrs=attrs)
        except Exception as e:
            raise diffsync_exceptions.ObjectNotCreated

    def update(self, attrs: Dict[str, Any]):
        try:
            Nautobot.update_device(self, attrs)
        except Exception as e:
            raise diffsync_exceptions.ObjectNotCreated
