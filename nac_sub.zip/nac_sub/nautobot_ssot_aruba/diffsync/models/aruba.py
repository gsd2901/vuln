from nautobot_ssot_aruba.diffsync.models.base import (
    NautobotDevice,
    NautobotDeviceType,
    NautobotManufacturer,
    NautobotLocation,
    NautobotIPAddress,
    NautobotInterface,
    NautobotStatus,
    NautobotPlatform,
    NautobotNameSpace,
    NautobotRole,
    NautobotTenant,
)


class ArubaDevice(NautobotDevice):
    """Aruba implementation of Device model"""


class ArubaDeviceType(NautobotDeviceType):
    """Aruba implementation of DeviceType model"""


class ArubaManufacturer(NautobotManufacturer):
    """Aruba implementation of Manufacturer model"""


class ArubaLocation(NautobotLocation):
    """Aruba implementation of Location model"""


class ArubaIPAddress(NautobotIPAddress):
    """Aruba implementation of IPAddress model"""


class ArubaInterface(NautobotInterface):
    """Aruba implementation of Interface model"""


class ArubaStatus(NautobotStatus):
    """Aruba implementation of Status model"""


class ArubaPlatform(NautobotPlatform):
    """Aruba implementation of Platform model"""


class ArubaNameSpace(NautobotNameSpace):
    """Aruba implementation of NameSpace model"""


class ArubaRole(NautobotRole):
    """Aruba implementation of Role model"""


class ArubaTenant(NautobotTenant):
    """Aruba implementation of Tenant model"""
