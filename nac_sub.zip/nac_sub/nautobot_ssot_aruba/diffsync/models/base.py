from diffsync import DiffSyncModel
import uuid
from typing import Optional, ClassVar
from nautobot_ssot.contrib import NautobotModel
from diffsync.enum import DiffSyncModelFlags
from nautobot.dcim.models import Manufacturer, DeviceType, Device, Interface, Location, Platform
from nautobot.extras.models import Status, Role
from nautobot.ipam.models import VLAN, Prefix, VRF, IPAddress, Namespace
from nautobot.tenancy.models import Tenant

# Manufacturer
class NautobotManufacturer(NautobotModel):
    flags: ClassVar = DiffSyncModelFlags.SKIP_UNMATCHED_DST
    _model = Manufacturer
    _modelname = "manufacturer"
    _identifiers = ("name",)
    _attributes = ()
    name: Optional[str] = None


# Device Type
class NautobotDeviceType(NautobotModel):
    flags: ClassVar = DiffSyncModelFlags.SKIP_UNMATCHED_DST
    _model = DeviceType
    _modelname = "device_type"
    _identifiers = ("model",)
    _attributes = ()
    model: str


# Status
class NautobotStatus(NautobotModel):
    flags: ClassVar = DiffSyncModelFlags.SKIP_UNMATCHED_DST
    _model = Status
    _modelname = "status"
    _identifiers = ("name",)
    _attributes = ()
    name: str


# Platform
class NautobotPlatform(NautobotModel):
    flags: ClassVar = DiffSyncModelFlags.SKIP_UNMATCHED_DST
    _model = Platform
    _modelname = "platform"
    _identifiers = ("name",)
    _attributes = ()
    name: str


# DeviceRole
class NautobotRole(NautobotModel):
    flags: ClassVar = DiffSyncModelFlags.SKIP_UNMATCHED_DST
    _model = Role
    _modelname = "role"
    _identifiers = ("name",)
    _attributes = ()
    name: str


# Tenant
class NautobotTenant(NautobotModel):
    flags: ClassVar = DiffSyncModelFlags.SKIP_UNMATCHED_DST
    _model = Tenant
    _modelname = "tenant"
    _identifiers = ("name",)
    _attributes = ()
    name: str


# Namespace
class NautobotNameSpace(NautobotModel):
    flags: ClassVar = DiffSyncModelFlags.SKIP_UNMATCHED_DST
    _model = Namespace
    _modelname = "namespace"
    _identifiers = ("name",)
    _attributes = ()
    name: str


# Location
class NautobotLocation(NautobotModel):
    flags: ClassVar = DiffSyncModelFlags.SKIP_UNMATCHED_DST
    _model = Location
    _modelname = "location"

    _identifiers = ("name",)
    _attributes = ( "status__name",)
    
    name: str
    status__name: str


# IPAddress
class NautobotIPAddress(NautobotModel):
    flags: ClassVar = DiffSyncModelFlags.SKIP_UNMATCHED_DST
    _model = IPAddress
    _modelname = "ipaddress"
    _identifiers = ("host",)
    _attributes = ("status", "role__name","device__name","interface__name",)
    host: Optional[str] = None
    status: Optional[str] = None
    role__name: Optional[str] = None
    device__name: Optional[str] = None
    interface__name: Optional[str] = None


# Device
class NautobotDevice(NautobotModel):
    flags: ClassVar = DiffSyncModelFlags.SKIP_UNMATCHED_DST
    _model = Device
    _modelname = "device"
    _identifiers = ("name",)
    _attributes = (
        "serial",
        "device_type__model",
        "location__name",
        "platform__name",
        "status__name",
        "primary_ip4__host",
        "primary_ip6__host",
    )
    name: Optional[str] = None
    serial: Optional[str] = None
    device_type__model: Optional[str] = None
    location__name: Optional[str] = None
    platform__name: Optional[str] = None
    status__name: Optional[str] = None
    primary_ip4__host: Optional[str] = None
    primary_ip6__host: Optional[str] = None


# Interface
class NautobotInterface(NautobotModel):
    flags: ClassVar = DiffSyncModelFlags.SKIP_UNMATCHED_DST
    _model = Interface
    _modelname = "interface"
    _identifiers = ("device__name", "name")
    _attributes = ("enabled", "type", "description", "status")
    device__name: Optional[str] = None
    name: str
    enabled: bool
    type: str
    description: str
    status: str
