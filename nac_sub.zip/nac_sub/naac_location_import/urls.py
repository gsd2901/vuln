# naac_location_import/urls.py

from django.urls import path
from . import views

urlpatterns = [
    path(
        "download-template/",
        views.download_location_template,
        name="download_location_template",
    ),
]