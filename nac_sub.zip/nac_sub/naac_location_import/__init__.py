from nautobot.apps import NautobotAppConfig

__version__ = "0.1.0"


class NaacLocationCreationConfig(NautobotAppConfig):
    """Location Hierarchy Creation Plugin."""

    name = "naac_location_import"
    verbose_name = "NAAC Location Import"

    jobs = "jobs"

    description = (
        "Create Continent -> Country -> State -> City -> "
        "Building -> Floor -> Room hierarchy from CSV/XLSX"
    )

    version = __version__

    author = "Megha Rathore"
    author_email = "meghasingh.rathore@hcltech.com"

    base_url = "location-import"

    required_settings = []
    default_settings = {}
    caching_config = {}

    def ready(self):
            super().ready()
    
            try:
                from nautobot.extras.models import Job as JobModel, JobQueue
                from nautobot.extras.registry import registry
                from naac_location_import.jobs import LocationHierarchyImport
    
                job_path = "naac_location_import.jobs.LocationHierarchyImport"
    
                # Register job in registry
                registry["jobs"][job_path] = LocationHierarchyImport
    
                # Ensure default queue exists
                default_queue, _ = JobQueue.objects.get_or_create(name="default")
    
                # Register or update job metadata
                JobModel.objects.update_or_create(
                    module_name="naac_location_import.jobs",
                    job_class_name="LocationHierarchyImport",
                    defaults={
                        "name": LocationHierarchyImport.name,
                        "grouping": "Location Import",
                        "description": getattr(LocationHierarchyImport, "description", ""),
                        "installed": True,
                        "enabled": True,
                        "has_sensitive_variables": False,
                        "default_job_queue": default_queue,
                    },
                )
    
                print("[Location Hierarchy Import] Job registered successfully.")
    
            except Exception as exc:
                print(f"[Location Hierarchy Import] Error loading jobs: {exc}")


config = NaacLocationCreationConfig