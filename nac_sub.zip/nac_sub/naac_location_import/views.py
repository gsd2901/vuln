from pathlib import Path
from django.http import FileResponse, Http404

def download_location_template(request):
    file_path = (
        Path(__file__).resolve().parent
        / "static"
        / "naac_location_import"
        / "location_template.csv"
    )

    if not file_path.exists():
        raise Http404(f"Template file not found: {file_path}")

    return FileResponse(
        open(file_path, "rb"),
        as_attachment=True,
        filename="location_template.csv",
    )