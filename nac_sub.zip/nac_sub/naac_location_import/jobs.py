from nautobot.apps.jobs import Job, FileVar, BooleanVar
from nautobot.dcim.models import Location, LocationType
from nautobot.extras.models import Status
from django.urls import reverse

import pandas as pd
import re

class LocationHierarchyImport(Job):

    download_link = reverse("plugins:naac_location_import:download_location_template")
    csv_file = FileVar(
        required=True,
        description=f"""
        Upload CSV or XLSX file.

        <br><br>
       
        <a href="{download_link}" target="_blank">
            📥 Download Sample CSV Template
        </a>
        """
    )

    dry_run = BooleanVar(
        description="Preview only. No objects will be created.",
        default=True
    )

    class Meta:
        name = "Location Hierarchy Import"
        description = (
            "Create Continent → Country → State → City → "
            "Building → Floor → Room hierarchy from uploaded file."
        )

    def load_file(self, uploaded_file):

        filename = uploaded_file.name.lower()

        if filename.endswith(".csv"):

            try:
                return pd.read_csv(uploaded_file, encoding="utf-8")

            except UnicodeDecodeError:

                uploaded_file.seek(0)

                return pd.read_csv(
                    uploaded_file,
                    encoding="latin1"
                )

        elif filename.endswith(".xlsx"):

            return pd.read_excel(uploaded_file)

        raise Exception(
            f"Unsupported file format: {uploaded_file.name}. "
            f"Please upload only CSV or XLSX files."
        )
    
    def get_location_type(self, name):

        try:
            return LocationType.objects.get(name=name)

        except LocationType.DoesNotExist:

            raise Exception(
                f"Location type '{name}' not found."
            )
        
    def get_active_status(self):

        status = Status.objects.filter(
            name__icontains="active"
        ).first()

        if not status:
            raise Exception(
                "No Active status found"
            )

        return status

    def names_match(self, a, b):
        return str(a).strip().lower() == str(b).strip().lower()
    
    def normalize_geography_name(self, name):

        name = self.safe_str(name)

        if not name:
            return ""

        return name.title()

    def safe_str(self, value):

        if pd.isna(value):
            return ""

        value = str(value).strip()

        if value.lower() in ["nan", "none", "null"]:
            return ""

        return value
    
    def normalize_building_name(self, seating_location, building_name):

        seating_location = self.safe_str(seating_location).upper()
        building_name = self.safe_str(building_name)

        if not building_name:
            return ""

        groups = []

        for group in building_name.split(","):

            words = []

            for word in group.strip().split():

                if re.match(r'^[A-Za-z]+\d+$', word):
                    words.append(word.upper())

                elif len(word) <= 3:
                    words.append(word.upper())

                elif "-" in word:

                    parts = []

                    for item in word.split("-"):

                        if re.match(r'^[A-Za-z]+\d+$', word):
                            words.append(word.upper())
                        
                        elif len(word) <= 3:
                            words.append(word.upper())
                        else:
                            parts.append(item.capitalize())

                    words.append("-".join(parts))

                else:
                    words.append(word.capitalize())

            groups.append(" ".join(words))

        building_name = ", ".join(groups)

        return f"{seating_location} - {building_name}"
    
    def words_to_number(self, text):

        units = {
            "ZERO": 0,

            "ONE": 1,
            "FIRST": 1,

            "TWO": 2,
            "SECOND": 2,

            "THREE": 3,
            "THIRD": 3,

            "FOUR": 4,
            "FOURTH": 4,

            "FIVE": 5,
            "FIFTH": 5,

            "SIX": 6,
            "SIXTH": 6,

            "SEVEN": 7,
            "SEVENTH": 7,

            "EIGHT": 8,
            "EIGHTH": 8,

            "NINE": 9,
            "NINTH": 9,

            "ELEVEN": 11,
            "ELEVENTH": 11,

            "TWELVE": 12,
            "TWELFTH": 12,
            "TWELVETH": 12,     

            "THIRTEEN": 13,
            "THIRTEENTH": 13,

            "FOURTEEN": 14,
            "FOURTEENTH": 14,

            "FIFTEEN": 15,
            "FIFTEENTH": 15,

            "SIXTEEN": 16,
            "SIXTEENTH": 16,

            "SEVENTEEN": 17,
            "SEVENTEENTH": 17,

            "EIGHTEEN": 18,
            "EIGHTEENTH": 18,

            "NINETEEN": 19,
            "NINETEENTH": 19
        }

        tens = {
            "TEN": 10,
            "TENTH": 10,
            "TWENTY": 20,
            "TWENTIETH": 20,
            "THIRTY": 30,
            "THIRTIETH": 30,
            "FORTY": 40,
            "FORTIETH": 40,
            "FIFTY": 50,
            "FIFTIETH": 50
        }

        total = 0

        for word in text.split():

            if word in tens:
                total += tens[word]

            elif word in units:
                total += units[word]

        return total
    
    def normalize_floor_name(self, floor):

        if not floor or pd.isna(floor):
            return ""

        floor = self.safe_str(floor).strip().upper()

        if floor == "GROUND FLOOR":
            return "Ground Floor"

        if floor == "BASEMENT":
            return "Basement"

        if floor == "MEZZANINE":
            return "Mezzanine"

        match = re.search(r'(\d+)', floor)

        if match:
            return f"Floor {match.group(1)}"

        floor_text = re.sub(r'\bFLOOR\b', '', floor).strip()

        number = self.words_to_number(floor_text)

        if number > 0:
            return f"Floor {number}"

        return floor.title()
    
    def normalize_room_name(self, rack_code, acrm_name):

        if not rack_code or pd.isna(rack_code):
            return ""
        rack_code = self.safe_str(rack_code).strip().upper()
        if "-" in rack_code:
            room_base = rack_code.rsplit("-", 1)[0]
        else:
            room_base = rack_code
        acrm_name = self.safe_str(acrm_name).strip().upper()
        if acrm_name:
            return f"{room_base}-{acrm_name}"
        return room_base
    
    def get_or_create_location(
        self,
        name,
        location_type,
        status,
        parent=None,
        dry_run=True
    ):

        existing = Location.objects.filter(
            name__iexact=name,
            location_type=location_type,
            parent=parent
        ).first()

        if existing:

            self.stats[location_type.name]["already_exists"] += 1
            return existing, False


        if dry_run:

            self.stats[location_type.name]["created"] += 1

            return Location(
                name=name,
                location_type=location_type,
                parent=parent
            ), False

        obj = Location.objects.create(
            name=name,
            location_type=location_type,
            parent=parent,
            status=status
        )

        self.stats[location_type.name]["created"] += 1

        return obj, True

    def create_geography_hierarchy(self, continent, country, state, city, region_type, status, dry_run):
        continent_obj, _ = self.get_or_create_location(continent, region_type, status, dry_run=dry_run)
        country_obj, _ = self.get_or_create_location(country, region_type, status, parent=continent_obj, dry_run=dry_run)
        state_obj, _ = self.get_or_create_location(state, region_type, status, parent=country_obj, dry_run=dry_run)
        city_obj, _ = self.get_or_create_location(city,region_type, status, parent=state_obj, dry_run=dry_run)
        return city_obj
 
    def run(self, **kwargs):
        
        self.stats = {
            "Region": {"created": 0, "already_exists": 0},
            "Building": {"created": 0, "already_exists": 0},
            "Floor": {"created": 0, "already_exists": 0},
            "Room": {"created": 0, "already_exists": 0},
        }
        self.invalid_records = []
        uploaded_file = kwargs["csv_file"]
        dry_run = kwargs["dry_run"]

        self.logger.info("===== JOB START =====")
        self.logger.info(f"File: {uploaded_file.name}")
        self.logger.info(f"Dry Run: {dry_run}")

        df = self.load_file(uploaded_file)

        required_columns = [
            "location__parent__parent__parent__parent__parent__parent__name",
            "location__parent__parent__parent__parent__parent__name",
            "location__parent__parent__parent__parent__name",
            "REGION",
            "SEATING TEAM LOCATION",
            "TOWER",
            "FLOOR",
            "ACRM NAME",
            "RACK CODE"
        ]

        missing = [
            col
            for col in required_columns
            if col not in df.columns
        ]

        if missing:

            raise Exception(
                "Missing columns: "
                + ", ".join(missing)
            )
        
        unique_geographies = set()
        towers = set()
        tower_floor_map = {}
        floor_room_map = {}

        self.logger.info(f"Loaded {len(df)} records")
        self.logger.info(f"Columns found: {df.columns.tolist()}")
    
        """Create complete location hierarchy"""
    
        self.logger.info("=" * 60)
        self.logger.info("CREATING LOCATION HIERARCHY FROM CSV/XLSX")
        self.logger.info("=" * 60 + "\n")
    
        # Get location type IDs
        self.logger.info("Getting location types...")
        region_type_id = self.get_location_type('Region')
        tower_type_id = self.get_location_type('Building')
        floor_type_id = self.get_location_type('Floor')
        room_type_id = self.get_location_type('Room')

        status = self.get_active_status()

        for _, row in df.iterrows():
            continent = self.normalize_geography_name(
                row.get(
                'location__parent__parent__parent__parent__parent__parent__name',
                ''
                )
            )
            country = self.normalize_geography_name(
                row.get(
                'location__parent__parent__parent__parent__parent__name',
                ''
                )
            )
            state = self.normalize_geography_name(
                row.get(
                'location__parent__parent__parent__parent__name',
                ''
                )
            )
            city = self.normalize_geography_name(
                row.get('REGION', '')
            )
            building = self.normalize_building_name(
                row.get("SEATING TEAM LOCATION", ""),
                row.get("TOWER", "")
            )
            floor = self.normalize_floor_name(
                row.get("FLOOR", "")
            )
            room = self.normalize_room_name(
                row.get("RACK CODE", ""),
                row.get("ACRM NAME", "")
            )


            if building:
                towers.add(building)

                tower_key = (
                    continent,
                    country,
                    state,
                    city,
                    building
                )

                if tower_key not in tower_floor_map:
                    tower_floor_map[tower_key] = set()

                if floor:
                    tower_floor_map[tower_key].add(floor)

                    if building and floor and room:

                        room_key = (
                            continent,
                            country,
                            state,
                            city,
                            building,
                            floor
                        )

                        if room_key not in floor_room_map:
                            floor_room_map[room_key] = set()

                        floor_room_map[room_key].add(room)
                        
            if all([continent, country, state, city]):
                unique_geographies.add(
                    (
                        continent,
                        country,
                        state,
                        city
                    )
                )
            else:
                self.logger.warning(
                    f"Skipping invalid geography: "
                    f"{continent}/{country}/{state}/{city}"
                )

        city_cache = {}

        for continent, country, state, city in sorted(unique_geographies):

            city_obj = self.create_geography_hierarchy(
                continent,
                country,
                state,
                city,
                region_type_id,
                status,
                dry_run
            )

            city_cache[
                (
                    continent,
                    country,
                    state,
                    city
                )
            ] = city_obj

        for tower_key in sorted(tower_floor_map.keys()):

            continent, country, state, city, building = tower_key

            city_obj = city_cache.get(
                (
                    continent,
                    country,
                    state,
                    city
                )
            )

            building_obj, _ = self.get_or_create_location(
                building,
                tower_type_id,
                status,
                parent=city_obj,
                dry_run=dry_run
            )

            for floor in sorted(
                tower_floor_map[tower_key]
            ):

                floor_obj, _ = self.get_or_create_location(
                    floor,
                    floor_type_id,
                    status,
                    parent=building_obj,
                    dry_run=dry_run
                )

                room_key = (
                    continent,
                    country,
                    state,
                    city,
                    building,
                    floor
                )

                if room_key in floor_room_map:

                    for room in sorted(
                        floor_room_map[room_key]
                    ):

                        self.get_or_create_location(
                            room,
                            room_type_id,
                            status,
                            parent=floor_obj,
                            dry_run=dry_run
                        )

        self.logger.info("Calculating results...")

        self.logger.info(
            f"Regions={self.stats['Region']}, "
            f"Buildings={self.stats['Building']}, "
            f"Floors={self.stats['Floor']}, "
            f"Rooms={self.stats['Room']}"
        )

        self.logger.success("Job completed")

jobs = [LocationHierarchyImport]

# Register jobs with Nautobot
from nautobot.apps.jobs import register_jobs
register_jobs(*jobs)


