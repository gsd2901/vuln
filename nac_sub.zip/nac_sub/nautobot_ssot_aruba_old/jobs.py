from nautobot.apps.jobs import Job, StringVar
from nautobot_ssot.jobs import DataSource
from .diffsync.sync import run_aruba_sync


class ArubaSSOTJob(DataSource, Job):
    """Sync Aruba devices into Nautobot using DiffSync."""

    host = StringVar(description="Aruba host IP or FQDN")

    class Meta:
        name = "Aruba Device Sync"
        description = "Synchronize Aruba devices into Nautobot"
        commit_default = False  # ensures dry-run by default

    def run(self, host, dryrun=False, **kwargs):
        """
        Execute the Aruba SSoT job.
        Accepts additional keyword arguments like memory_profiling automatically passed by Nautobot.
        """
        self.logger.info(f"Starting Aruba SSoT job (dry_run={dryrun})")

        result = run_aruba_sync(
            host,
            dry_run=dryrun,
            job_logger=self.logger
        )

        if dryrun:
            self.logger.info(f"Dry-run complete. Changes not applied: {result}")
        else:
            self.logger.info(f"Sync applied successfully: {result}")

        return f"Aruba sync completed successfully (dry_run={dryrun}).\nSummary: {result}"
