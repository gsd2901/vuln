# nautobot_ssot_aruba/diffsync/sync.py
from .adapter_aruba import ArubaAdapter
from .adapter_nautobot import NautobotAdapter

def run_aruba_sync(dry_run=True, job_logger=None):
    """
    Run Aruba → Nautobot sync using DiffSync.
    Supports dry-run mode (dry_run=True) or full commit (dry_run=False).
    Deletes in Nautobot are ignored completely because delete() is not implemented.
    """
    src = ArubaAdapter(job_logger=job_logger)
    dst = NautobotAdapter(job_logger=job_logger)

    if job_logger:
        job_logger.info("Loading data from Aruba...")
    src.load(dry_run=dry_run)

    if job_logger:
        job_logger.info("Loading data from Nautobot...")
    dst.load()

    diff = dst.diff_from(src)
    summary = diff.summary()

    # Remove deletes from summary
    summary["delete"] = 0

    if dry_run:
        if job_logger:
            job_logger.info("Dry-run mode: no changes will be applied.")
            job_logger.info(f"Dry-run summary: { {k: v for k, v in summary.items() if k != 'delete'} }")
        return summary

    # Commit changes (creates and updates only)
    dst.sync_from(src)  # delete() is absent, so nothing will be deleted

    if job_logger:
        job_logger.info("Sync complete.")
        job_logger.info(f"Summary: { {k: v for k, v in summary.items() if k != 'delete'} }")

    return summary
