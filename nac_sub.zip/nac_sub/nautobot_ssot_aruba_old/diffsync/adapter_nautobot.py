# nautobot_ssot_aruba/diffsync/adapter_nautobot.py
from diffsync import DiffSyncModel
from nautobot_ssot.contrib import NautobotAdapter
from django.db import transaction
from django.contrib.contenttypes.models import ContentType

from nautobot.dcim.models import Device, DeviceType, Manufacturer, Location, LocationType, Interface, Platform, SoftwareVersion
from nautobot.ipam.models import IPAddress, Namespace, Prefix
from nautobot.tenancy.models import Tenant
from nautobot.extras.models import Role, Tag, Status

import ipaddress as pyip
from typing import Optional
import traceback


class NautobotDevice(DiffSyncModel):
    _modelname = "device"
    _identifiers = ("name",)
    _attributes = (
        "ip_address", "ipv6_address", "model", "role", "status", "location", 
        "tenant", "release_type", "namespace", "config_id", "config_sync_time", 
        "configuration_state", "flags", "group", "standby_ip", "switch_ip",
        "serial", "software_version" 
    )

    # Core identifiers
    name: str
    
    # All attributes for sync logic
    ip_address: Optional[str] = ""
    ipv6_address: Optional[str] = ""
    model: Optional[str] = ""
    role: Optional[str] = ""
    status: Optional[str] = ""
    location: Optional[str] = ""
    tenant: Optional[str] = ""
    release_type: Optional[str] = ""
    namespace: Optional[str] = ""
    config_id: Optional[str] = None
    config_sync_time: Optional[str] = None
    configuration_state: Optional[str] = None
    flags: Optional[str] = None
    group: Optional[str] = None
    standby_ip: Optional[str] = None
    switch_ip: Optional[str] = None
    serial: Optional[str] = ""
    software_version: Optional[str] = "" 

    @classmethod 
    def create(cls, adapter, ids, attrs):
        """Create device using custom sync logic."""
        adapter.log(f"Creating device {ids.get('name')}")
        
        # Create temp model for your sync_device logic
        temp_model = type('TempDevice', (), {
            'name': ids.get('name', ''), 
            'ip_address': attrs.get('ip_address', ''),
            'ipv6_address': attrs.get('ipv6_address', ''),
            'model': attrs.get('model', ''),
            'role': attrs.get('role', ''),
            'status': attrs.get('status', ''),
            'location': attrs.get('location', ''),
            'tenant': attrs.get('tenant', ''),
            'release_type': attrs.get('release_type', ''),
            'namespace': attrs.get('namespace', ''),
            'config_id': attrs.get('config_id'),
            'config_sync_time': attrs.get('config_sync_time'),
            'configuration_state': attrs.get('configuration_state'),
            'flags': attrs.get('flags'),
            'group': attrs.get('group'),
            'standby_ip': attrs.get('standby_ip'),
            'switch_ip': attrs.get('switch_ip'),
            'serial': attrs.get('serial', ''),
            'software_version': attrs.get('software_version', ''), 
        })()
        
        # Run your custom sync logic
        adapter.sync_device(temp_model, "create")
        
        # Create and return the DiffSync model instance
        instance = cls(name=ids.get('name'), **attrs)
        return instance

    def update(self, attrs):
        """Update device using custom sync logic."""
        self.adapter.log(f"Updating device {self.name}")
        
        # Create temp model for sync_device
        temp_model = type('TempDevice', (), {
            'name': self.name, 
            'ip_address': attrs.get('ip_address', getattr(self, 'ip_address', '')),
            'ipv6_address': attrs.get('ipv6_address', getattr(self, 'ipv6_address', '')),
            'model': attrs.get('model', getattr(self, 'model', '')),
            'role': attrs.get('role', getattr(self, 'role', '')),
            'status': attrs.get('status', getattr(self, 'status', '')),
            'location': attrs.get('location', getattr(self, 'location', '')),
            'tenant': attrs.get('tenant', getattr(self, 'tenant', '')),
            'release_type': attrs.get('release_type', getattr(self, 'release_type', '')),
            'namespace': attrs.get('namespace', getattr(self, 'namespace', '')),
            'config_id': attrs.get('config_id', getattr(self, 'config_id')),
            'config_sync_time': attrs.get('config_sync_time', getattr(self, 'config_sync_time')),
            'configuration_state': attrs.get('configuration_state', getattr(self, 'configuration_state')),
            'flags': attrs.get('flags', getattr(self, 'flags')),
            'group': attrs.get('group', getattr(self, 'group')),
            'standby_ip': attrs.get('standby_ip', getattr(self, 'standby_ip')),
            'switch_ip': attrs.get('switch_ip', getattr(self, 'switch_ip')),
            'serial': attrs.get('serial', getattr(self, 'serial', '')),
            'software_version': attrs.get('software_version', getattr(self, 'software_version', '')), 
        })()
        
        # Run your custom sync logic
        self.adapter.sync_device(temp_model, "update")
        
        # Update self with new attributes
        for key, value in attrs.items():
            if hasattr(self, key):
                setattr(self, key, value)
                
        return self

    def delete(self):
        """Delete method - we don't delete devices in this sync."""
        self.adapter.log(f"Delete operation skipped for device {self.name}")
        return self


class NautobotAdapter(NautobotAdapter):
    device = NautobotDevice
    top_level = ["device"]

    MGMT_IFACE_NAME = "mgmt0"
    DEFAULT_IPV4_PREFIXLEN = 32
    DEFAULT_IPV6_PREFIXLEN = 128
    
    # === LOCATION MAPPING & CONFIGURATION (Unchanged) ===
    LOCATION_MAP = {
        "AMCAM": "USA>NJ>LAB",
        "B70": "USA>NJ>CAMDEN",
    }
    LOCATION_TYPE_MAP = {
        0: "Country",  # USA
        1: "Region",   # NJ
        2: "Site",     # LAB or CAMDEN
    }
    # ============================================

    def __init__(self, job=None, sync=None, job_logger=None, *args, **kwargs):
        super().__init__(job=job, sync=sync, *args, **kwargs)
        self.job_logger = job_logger or job

    def log(self, message):
        print(f"[NAUTOBOT DEBUG] {message}", flush=True)
        if self.job_logger:
            if hasattr(self.job_logger, 'log_info'):
                self.job_logger.log_info(message)
            elif hasattr(self.job_logger, 'info'):
                self.job_logger.info(message)

    def load(self):
        """Load existing devices from Nautobot."""
        self.log("Loading existing devices from Nautobot...")
        for dev in Device.objects.all():
            # Get custom field data safely
            custom_data = {}
            try:
                if hasattr(dev, '_custom_field_data') and dev._custom_field_data:
                    custom_data = dev._custom_field_data
                elif hasattr(dev, 'custom_field_data') and dev.custom_field_data:
                    custom_data = dev.custom_field_data
            except:
                custom_data = {}
            
            # Use core software_version field if available
            software_version = dev.software_version.version if dev.software_version else ""
            
            self.add(self.device(
                name=dev.name, 
                ip_address=str(dev.primary_ip4.address) if dev.primary_ip4 else "",
                ipv6_address=str(dev.primary_ip6.address) if dev.primary_ip6 else "",
                model=dev.device_type.model if dev.device_type else "",
                role=dev.role.name if dev.role else "",
                status=dev.status.name,
                location=dev.location.name if dev.location else "", 
                tenant=dev.tenant.name if dev.tenant else "",
                release_type=dev.platform.name if dev.platform else "",
                namespace="default",
                config_id=custom_data.get('config_id'),
                config_sync_time=custom_data.get('config_sync_time'),
                configuration_state=custom_data.get('configuration_state'),
                flags=custom_data.get('flags'),
                group=custom_data.get('group'),
                standby_ip=custom_data.get('standby_ip'),
                switch_ip=custom_data.get('switch_ip'),
                serial=dev.serial or "", 
                software_version=software_version, 
            ))
            self.log(f"Loaded device {dev.name}")

        total = len(self.get_all("device"))
        self.log(f"Total devices loaded: {total}")
        return self

    # === LOCATION HELPER METHODS (Unchanged) ===
    def _parse_location_from_name(self, hostname: str) -> str:
        """Parses the hostname to determine the full hierarchical location path."""
        # Note: Order matters for checking prefixes
        if hostname.upper().startswith("AMCAM"):
            return self.LOCATION_MAP["AMCAM"]
        if hostname.upper().startswith("B70"):
            return self.LOCATION_MAP["B70"]
        
        # Fallback location
        return "UNKNOWN>DEFAULT>SITE"

    def _get_or_create_manufacturer(self, name="Aruba"):
        obj, created = Manufacturer.objects.get_or_create(
            name=name,
            defaults={'description': f'Auto-created manufacturer for {name}'}
        )
        self.log(f"Manufacturer: {name} (created={created})")
        return obj, created

    # nautobot_ssot_aruba/diffsync/adapter_nautobot.py

# ... (around line 430)

    def _get_or_create_device_type(self, model_name, manufacturer):
        
        clean_model = model_name or "Unknown Device"
        
        obj, created = DeviceType.objects.get_or_create(
            model=clean_model, manufacturer=manufacturer, 
            defaults={
                'part_number': clean_model, 'u_height': 1, 'is_full_depth': True,
                'subdevice_role': '', 'front_image': '', 'rear_image': '',
                'comments': f'Auto-created device type for {clean_model}', 
            }
        )
        self.log(f"DeviceType: {clean_model} (created={created})") 
        return obj, created

    def _get_or_create_location_type(self, type_name="Site"):
        device_ct = ContentType.objects.get_for_model(Device)
        obj, created = LocationType.objects.get_or_create(
            name=type_name,
            defaults={'description': f'Auto-created {type_name} location type', 'nestable': True}
        )
        if created or not obj.content_types.filter(id=device_ct.id).exists():
            obj.content_types.add(device_ct)
        self.log(f"LocationType: {type_name} (created={created})")
        return obj, created

    def _get_or_create_location(self, full_location_path: str):
        location_names = full_location_path.split('>')
        parent_location = None
        final_location_obj = None

        for idx, location_name in enumerate(location_names):
            location_name = location_name.strip()
            location_type_name = self.LOCATION_TYPE_MAP.get(idx, "Site")
            location_type, _ = self._get_or_create_location_type(location_type_name)
            status_obj, _ = self._get_or_create_status("Active")

            try:
                obj, created = Location.objects.get_or_create(
                    name=location_name,
                    parent=parent_location,
                    defaults={
                        'description': f'Auto-created location: {location_name}',
                        'location_type': location_type, 
                        'status': status_obj,
                        'comments': f'Auto-created location for {location_name}',
                    }
                )
                self.log(f"Location: {location_name} (type: {location_type_name}, parent: {parent_location.name if parent_location else 'None'}, created={created})")
                
                parent_location = obj
                final_location_obj = obj
            
            except Exception as e:
                self.log(f"Error creating/getting hierarchical location {location_name}: {e}")
                raise

        return final_location_obj, created

    def _get_or_create_platform(self, platform_name):
        # <<< MODIFIED: Fallback for missing platform_name >>>
        if not platform_name:
            # Use a sensible default for Aruba Wireless Controllers/Mobility Masters
            platform_name = "ArubaOS-Mobility" 
            self.log(f"WARNING: No Platform provided by source, using fallback: {platform_name}")
            
        obj, created = Platform.objects.get_or_create(
            name=platform_name,
            defaults={
                'napalm_driver': '', 'description': f'Auto-created platform for {platform_name}',
                # Use a generic driver or one matching the type of device
                'network_driver': 'aruba_aoscx' if "CX" in platform_name else 'aruba_mobility_conductor',
            }
        )
        self.log(f"Platform: {platform_name} (created={created})")
        return obj, created

    def _get_or_create_tenant(self, tenant_name):
        if not tenant_name:
            tenant_name = "Default Tenant"
        obj, created = Tenant.objects.get_or_create(name=tenant_name, defaults={})
        self.log(f"Tenant: {tenant_name} (created={created})")
        return obj, created

    def _get_or_create_namespace(self, namespace_name):
        if not namespace_name:
            namespace_name = "default"
        obj, created = Namespace.objects.get_or_create(name=namespace_name, defaults={})
        self.log(f"Namespace: {namespace_name} (created={created})")
        return obj, created

    def _ensure_interface(self, device_obj, iface_name):
        status_obj, _ = self._get_or_create_status("Active")
        iface, created = Interface.objects.get_or_create(
            device=device_obj, name=iface_name,
            defaults={'type': 'other', 'status': status_obj}
        )
        self.log(f"Interface: {iface_name} for {device_obj.name} (created={created})")
        return iface, created

    def _ensure_default_prefixes(self, namespace_obj):
        status_obj, _ = self._get_or_create_status("Active")
        default_prefixes = ["10.0.0.0/8", "172.16.0.0/12", "192.168.0.0/16", "0.0.0.0/0"]
        for prefix_str in default_prefixes:
            try:
                Prefix.objects.get_or_create(
                    network=prefix_str, namespace=namespace_obj,
                    defaults={'status': status_obj, 'type': 'network'}
                )
            except Exception as e:
                self.log(f"Could not create prefix {prefix_str}: {e}")
                continue

    def _create_or_get_ip(self, raw_ip, namespace_obj=None):
        if not raw_ip:
            return None, False
        if not namespace_obj:
            namespace_obj, _ = self._get_or_create_namespace("default")
        self._ensure_default_prefixes(namespace_obj)
        try:
            if "/" in raw_ip:
                ip_obj = pyip.ip_network(raw_ip, strict=False)
                addr = str(ip_obj.with_prefixlen)
            else:
                ip = pyip.ip_address(raw_ip)
                addr = f"{raw_ip}/{self.DEFAULT_IPV4_PREFIXLEN}" if ip.version == 4 else f"{raw_ip}/{self.DEFAULT_IPV6_PREFIXLEN}"
        except Exception as e:
            self.log(f"Invalid IP '{raw_ip}': {e}")
            return None, False
        status_obj, _ = self._get_or_create_status("Active")
        try:
            obj, created = IPAddress.objects.get_or_create(
                address=addr, namespace=namespace_obj,
                defaults={'status': status_obj}
            )
            self.log(f"IP address: {addr} (created={created})")
            return obj, created
        except Exception as e:
            self.log(f"Error creating IP address {addr}: {e}")
            try:
                obj, created = IPAddress.objects.get_or_create(
                    address=addr,
                    defaults={'namespace': namespace_obj, 'status': status_obj}
                )
                self.log(f"IP address: {addr} (created={created} - fallback method)")
                return obj, created
            except Exception as e2:
                self.log(f"Fallback IP creation also failed: {e2}")
                return None, False

    def _get_or_create_status(self, status_name):
        if not status_name:
            status_name = "Active"
        status_mapping = {
            "up": "Active", "active": "Active", "down": "Offline", "offline": "Offline", 
            "failed": "Failed", "maintenance": "Maintenance", "planned": "Planned", 
            "decommissioning": "Decommissioning"
        }
        mapped_status = status_mapping.get(status_name.lower(), "Active")
        color_mapping = {
            "Active": "4caf50", "Offline": "f44336", "Failed": "ff5722",
            "Maintenance": "ff9800", "Planned": "2196f3", "Decommissioning": "9e9e9e"
        }
        try:
            obj = Status.objects.get(name=mapped_status)
            self.log(f"Status: {mapped_status} (existing)")
            return obj, False
        except Status.DoesNotExist:
            try:
                device_ct = ContentType.objects.get_for_model(Device)
                location_ct = ContentType.objects.get_for_model(Location)
                interface_ct = ContentType.objects.get_for_model(Interface)
                obj, created = Status.objects.get_or_create(
                    name=mapped_status,
                    defaults={'color': color_mapping.get(mapped_status, '9e9e9e')}
                )
                if created:
                    obj.content_types.set([device_ct, location_ct, interface_ct])
                self.log(f"Status: {mapped_status} (created={created})")
                return obj, created
            except Exception as e:
                self.log(f"Error creating status {mapped_status}: {e}")
                try:
                    obj = Status.objects.filter(name="Active").first()
                    if obj:
                        self.log("Using existing Active status as fallback")
                        return obj, False
                except:
                    pass
                raise ValueError(f"Unable to create or find any status")

    def _get_or_create_role(self, role_name):
        if not role_name:
            role_name = "Network Device"
        device_ct = ContentType.objects.get_for_model(Device)
        try:
            obj, created = Role.objects.get_or_create(
                name=role_name,
                defaults={'color': '607d8b'}
            )
            if created or not obj.content_types.filter(id=device_ct.id).exists():
                obj.content_types.add(device_ct)
            self.log(f"Role: {role_name} (created={created})")
            return obj, created
        except Exception as e:
            self.log(f"Error creating role {role_name}: {e}")
            try:
                obj, created = Role.objects.get_or_create(
                    name="Network Device",
                    defaults={'color': '607d8b'}
                )
                if created or not obj.content_types.filter(id=device_ct.id).exists():
                    obj.content_types.add(device_ct)
                self.log(f"Created fallback role: Network Device")
                return obj, created
            except Exception as fallback_error:
                self.log(f"Failed to create fallback role: {fallback_error}")
                raise ValueError(f"Unable to create any role for device")

    # === MODIFIED sync_device METHOD ===
    @transaction.atomic
    def sync_device(self, model, action):
        self.log(f"Start syncing device {model.name} (action={action})")
        if not model.name:
            self.log("Skipping device with empty name")
            return
        try:
            # Removed redundant transaction.atomic() as it's now on the method decorator

            # Location Logic
            full_location_path = self._parse_location_from_name(model.name)
            location_obj, _ = self._get_or_create_location(full_location_path=full_location_path)
            
            # Other Dependencies
            manufacturer, _ = self._get_or_create_manufacturer()
            device_type_name_to_use = model.role or "Unknown Device"
            dtype, _ = self._get_or_create_device_type(model.role or "Unknown", manufacturer)
            role_obj, _ = self._get_or_create_role(model.model or "Network Device")
            tenant_obj, _ = self._get_or_create_tenant(model.tenant)
            namespace_obj, _ = self._get_or_create_namespace(model.namespace)
            status_obj, _ = self._get_or_create_status(model.status or "Active")
            
            # Platform is guaranteed to be created/retrieved now due to fallback logic in the helper
            platform_obj, _ = self._get_or_create_platform(model.release_type)

            # <<< VERIFICATION STEP (Optional, but helpful) >>>
            self.log(f"Platform object name: {platform_obj.name if platform_obj else 'None'}")
            self.log(f"Software version from source: {model.software_version}")

            # Software Version Logic
            sw_version_obj = None
            if model.software_version and platform_obj:
                sw_version_obj, sw_created = SoftwareVersion.objects.get_or_create(
                    platform=platform_obj,
                    version=model.software_version,  # The string version from your source
                    defaults={'status': status_obj} 
                )
                self.log(f"SoftwareVersion {sw_version_obj.version} (created={sw_created}) set for {model.name}")
            else:
                 self.log(f"Skipping SoftwareVersion link: version='{model.software_version}' or platform is missing.")


            defaults = {
                "device_type": dtype, "role": role_obj, "location": location_obj, 
                "platform": platform_obj, "tenant": tenant_obj, "status": status_obj,
                "serial": model.serial, 
                "software_version": sw_version_obj, 
            }
            
            if not defaults["role"]:
                raise ValueError(f"Failed to create role for device {model.name}")
            
            # Device Update/Create
            device_obj, created = Device.objects.update_or_create(
                name=model.name, 
                defaults=defaults
            )
            self.log(f"Device created/updated: {device_obj.name} (ID: {device_obj.id})")

            # Custom Fields Logic
            custom_fields = {}
            for key in ("config_id", "config_sync_time", "configuration_state", 
                        "flags", "group", "standby_ip", "switch_ip"):
                val = getattr(model, key, None)
                if val is not None:
                    custom_fields[key] = val
            
            if custom_fields:
                try:
                    if hasattr(device_obj, '_custom_field_data'):
                        existing_cfd = device_obj._custom_field_data or {}
                        existing_cfd.update(custom_fields)
                        device_obj._custom_field_data = existing_cfd
                    else:
                        existing_cfd = getattr(device_obj, 'custom_field_data', {}) or {}
                        existing_cfd.update(custom_fields)
                        device_obj.custom_field_data = existing_cfd
                    self.log(f"Updated custom fields for {device_obj.name}: {list(custom_fields.keys())}")
                except Exception as cf_error:
                    self.log(f"Custom field update failed: {cf_error}")
                    for key, value in custom_fields.items():
                        self.log(f"  {key}: {value}")

            # Interface and IP Logic
            iface, _ = self._ensure_interface(device_obj, self.MGMT_IFACE_NAME)

            if model.ip_address:
                ip_obj, _ = self._create_or_get_ip(model.ip_address, namespace_obj)
                if ip_obj:
                    iface.ip_addresses.add(ip_obj)
                    if pyip.ip_address(str(ip_obj.address).split("/")[0]).version == 4:
                        device_obj.primary_ip4 = ip_obj

            if model.ipv6_address:
                ipv6_obj, _ = self._create_or_get_ip(model.ipv6_address, namespace_obj)
                if ipv6_obj:
                    iface.ip_addresses.add(ipv6_obj)
                    if pyip.ip_address(str(ipv6_obj.address).split("/")[0]).version == 6:
                        device_obj.primary_ip6 = ipv6_obj

            device_obj.save()
            self.log(f"Device {device_obj.name} saved successfully")

            # Tag Logic
            if model.group:
                tag_obj, _ = Tag.objects.get_or_create(
                    name=str(model.group),
                    defaults={
                        'color': '2196f3',
                        'description': f'Auto-created tag for group {model.group}'
                    }
                )
                device_obj.tags.add(tag_obj)

            self.log(f"Finished syncing device {model.name}")

        except Exception as e:
            self.log(f"Error syncing {model.name}: {e}")
            self.log(f"Full traceback:\n{traceback.format_exc()}")
            raise