# nautobot_ssot_aruba/diffsync/adapter_aruba.py

import requests
import os
from diffsync import DiffSync, DiffSyncModel
from typing import Optional, ClassVar

# Disable insecure request warnings if any HTTPS cert issues
requests.packages.urllib3.disable_warnings()


# ================================================================
# Aruba Central DiffSync Device Model
# ================================================================
class ArubaDevice(DiffSyncModel):
    _modelname: ClassVar[str] = "device"
    _identifiers: ClassVar[tuple[str, ...]] = ("name",)
    _attributes: ClassVar[tuple[str, ...]] = (
        "ip_address", "ipv6_address", "model", "role", "status", "location",
        "tenant", "release_type", "namespace", "config_id", "config_sync_time",
        "configuration_state", "flags", "group", "standby_ip", "switch_ip",
        "serial", "software_version"
    )

    name: str
    ip_address: Optional[str] = ""
    ipv6_address: Optional[str] = ""
    model: Optional[str] = ""
    role: Optional[str] = ""
    status: Optional[str] = ""
    location: Optional[str] = ""
    tenant: Optional[str] = ""
    release_type: Optional[str] = ""
    namespace: Optional[str] = ""
    config_id: Optional[str] = ""
    config_sync_time: Optional[str] = ""
    configuration_state: Optional[str] = ""
    flags: Optional[str] = ""
    group: Optional[str] = ""
    standby_ip: Optional[str] = ""
    switch_ip: Optional[str] = ""
    serial: Optional[str] = ""
    software_version: Optional[str] = ""


# ================================================================
# Aruba Central Adapter
# ================================================================
class ArubaAdapter(DiffSync):
    device = ArubaDevice
    top_level = ["device"]

    def __init__(self, job_logger=None, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.job_logger = job_logger
        self.session = requests.Session()

        # Variables (loaded via environment variables)
        self.client_id = os.getenv("ARUBA_CLIENT_ID")
        self.client_secret = os.getenv("ARUBA_CLIENT_SECRET")
        self.refresh_token = os.getenv("ARUBA_REFRESH_TOKEN")
        self.api_host = os.getenv("ARUBA_API_HOST") 

        # Aruba Central OAuth token endpoint (GLOBAL)
        self.token_endpoint = "/oauth2/token"

        self.access_token = None

    def log(self, message):
        if self.job_logger:
            self.job_logger.info(message)
        else:
            print(message)

    # ================================================================
    # OAuth2 Token Refresh
    # ================================================================
    def refresh_access_token(self):
        """Refresh OAuth2 Access Token using Aruba Central refresh token."""
        self.log("Refreshing Aruba Central access token...")

        payload = {
            "grant_type": "refresh_token",
            "client_id": self.client_id,
            "client_secret": self.client_secret,
            "refresh_token": self.refresh_token,
        }

        headers = {"Content-Type": "application/x-www-form-urlencoded"}

        token_url = f"https://{self.api_host}{self.token_endpoint}"

        resp = self.session.post(token_url, data=payload, headers=headers, verify=False)
        self.log(f"Token response status: {resp.status_code}")
        self.log(f"Token response body: {resp.text}")

        resp.raise_for_status()
        token_data = resp.json()

        if "access_token" not in token_data:
            raise Exception(f"Failed to refresh token: {token_data}")

        self.access_token = token_data["access_token"]
        self.log("Access token successfully refreshed.")

    # ================================================================
    # Generic GET for Aruba Central API
    # ================================================================
    def api_get(self, endpoint: str):
        """Perform GET using Bearer token."""

        if not self.access_token:
            self.refresh_access_token()

        url = f"https://{self.api_host}{endpoint}"
        headers = {"Authorization": f"Bearer {self.access_token}"}

        self.log(f"GET {url}")
        resp = self.session.get(url, headers=headers, verify=False)

        if resp.status_code == 401:
            # token expired → refresh + retry
            self.log("Token expired. Refreshing and retrying...")
            self.refresh_access_token()
            headers = {"Authorization": f"Bearer {self.access_token}"}
            resp = self.session.get(url, headers=headers, verify=False)

        resp.raise_for_status()
        return resp.json()

    # ================================================================
    # Load Switches + APs
    # ================================================================
    def load(self, dry_run=True):
        self.log("Loading data from Aruba Central...")

        seen = set()

        # ------------------------------------------------------------
        # Switches API
        # ------------------------------------------------------------
        try:
            switches_data = self.api_get("/monitoring/v1/switches")
            switches = switches_data.get("switches") or []
            self.log(f"Found {len(switches)} switches.")

            for sw in switches:
                hostname = sw.get("name")
                if not hostname or hostname in seen:
                    continue
                seen.add(hostname)

                device_data = {
                    "name": hostname,
                    "ip_address": sw.get("ip_address", ""),
                    "ipv6_address": sw.get("ipv6_address", ""),
                    "model": sw.get("model", "Switch"),
                    "role": "Switch",
                    "status": sw.get("status", "Active"),
                    "location": sw.get("site", ""),
                    "tenant": "Default Tenant",
                    "release_type": "",
                    "namespace": "default",
                    "config_id": "",
                    "config_sync_time": "",
                    "configuration_state": sw.get("status", ""),
                    "flags": "",
                    "group": sw.get("group_name", ""),
                    "standby_ip": "",
                    "switch_ip": "",
                    "serial": sw.get("serial", ""),
                    "software_version": sw.get("firmware_version", ""),
                }

                self.add(self.device(**device_data))
                self.log(f"Added Switch: {hostname}")

        except Exception as e:
            self.log(f"Error fetching switches: {e}")

        # ------------------------------------------------------------
        # APs API
        # ------------------------------------------------------------
        # try:
        #     aps_data = self.api_get("/monitoring/v2/aps")
        #     aps = aps_data.get("aps") or []
        #     self.log(f"Found {len(aps)} APs.")

        #     for ap in aps:
        #         hostname = ap.get("name")
        #         if not hostname or hostname in seen:
        #             continue
        #         seen.add(hostname)

        #         device_data = {
        #             "name": hostname,
        #             "ip_address": ap.get("ip_address", ""),
        #             "ipv6_address": "",
        #             "model": ap.get("model", "Access Point"),
        #             "role": "Access Point",
        #             "status": ap.get("status", "Active"),
        #             "location": ap.get("site", ""),
        #             "tenant": "Default Tenant",
        #             "release_type": "",
        #             "namespace": "default",
        #             "config_id": "",
        #             "config_sync_time": "",
        #             "configuration_state": ap.get("status", ""),
        #             "flags": "",
        #             "group": ap.get("group_name", ""),
        #             "standby_ip": "",
        #             "switch_ip": "",
        #             "serial": ap.get("serial", ""),
        #             "software_version": ap.get("firmware_version", ""),
        #         }

        #         self.add(self.device(**device_data))
        #         self.log(f"Added AP: {hostname}")

        # except Exception as e:
        #     self.log(f"Error fetching APs: {e}")

        total_devices = len(self.get_all(self.device))
        self.log(f"Total devices loaded: {total_devices}")

        return self
