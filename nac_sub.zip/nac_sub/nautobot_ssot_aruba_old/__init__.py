"""Nautobot SSoT Aruba plugin initialization."""

from nautobot.apps import NautobotAppConfig


class NautobotSSOTArubaConfig(NautobotAppConfig):
    """Plugin configuration for the Aruba SSoT plugin."""

    name = "nautobot_ssot_aruba"
    verbose_name = "Nautobot SSoT Aruba"
    version = "1.0.0"
    author = "Your Name"
    author_email = "you@example.com"
    description = "Plugin to sync Aruba devices into Nautobot using SSoT DiffSync."
    base_url = "nautobot-ssot-aruba"
    required_settings = []
    default_settings = {}
    caching_config = {}

    def ready(self):
        """Called when the plugin is loaded."""
        super().ready()

        try:
            from nautobot.extras.models import Job as JobModel, JobQueue
            from nautobot.extras.registry import registry
            from . import jobs  # Import your jobs file

            # Reference to your job class
            ArubaSSOTJob = jobs.ArubaSSOTJob

            # Register in Nautobot's job registry
            registry["jobs"]["nautobot_ssot_aruba.jobs.ArubaSSOTJob"] = ArubaSSOTJob

            # Ensure a default job queue exists
            default_queue, _ = JobQueue.objects.get_or_create(name="default")

            # Register the job in DB if not already
            JobModel.objects.get_or_create(
                job_class_name="ArubaSSOTJob",
                module_name="nautobot_ssot_aruba.jobs",
                defaults={
                    "name": ArubaSSOTJob.name,
                    "grouping": getattr(ArubaSSOTJob, "grouping", "Aruba SSoT"),
                    "description": getattr(
                        ArubaSSOTJob,
                        "description",
                        "Sync Aruba devices into Nautobot using DiffSync.",
                    ),
                    "installed": True,
                    "enabled": True,
                    "has_sensitive_variables": getattr(ArubaSSOTJob, "has_sensitive_variables", False),
                    "default_job_queue": default_queue,
                },
            )

            print("[ArubaSSOT] Job registered successfully.")

        except Exception as e:
            print(f"[ArubaSSOT] Error loading job: {e}")


config = NautobotSSOTArubaConfig
