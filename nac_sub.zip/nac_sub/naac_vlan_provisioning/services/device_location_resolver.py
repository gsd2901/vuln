from nautobot.ipam.models import IPAddress


def get_device_location_from_ip(ip_address):
    """
    Get Nautobot device location from management IP.
    """

    ip_obj = IPAddress.objects.get(
        address__startswith=ip_address
    )

    if ip_obj.primary_ip4_for.exists():
        device = ip_obj.primary_ip4_for.first()

        if device.location:
            return device.location.name

    return None