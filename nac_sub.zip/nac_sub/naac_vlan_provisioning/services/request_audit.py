"""Helpers to persist API request/response audit records."""

import logging

from naac_vlan_provisioning.models import APIRequestAuditLog

logger = logging.getLogger(__name__)


def _extract_task_id(payload):
    """Extract task id from known payload shapes."""
    if not isinstance(payload, dict):
        return "UNASSIGNED"

    task = payload.get("task")
    if isinstance(task, dict) and task.get("id"):
        return str(task.get("id"))

    if payload.get("task_id"):
        return str(payload.get("task_id"))

    return "UNASSIGNED"


def create_api_audit_log(request, endpoint_name, payload, response_data, success, status_code, error_message=""):
    """Persist one API call audit row."""
    try:
        APIRequestAuditLog.objects.create(
            task_id=_extract_task_id(payload),
            endpoint=endpoint_name or request.path,
            method=request.method,
            payload=payload if isinstance(payload, dict) else {},
            response=response_data if isinstance(response_data, dict) else {"raw": str(response_data)},
            success=bool(success),
            status_code=int(status_code),
            error_message=str(error_message or ""),
        )
    except Exception:
        # Never let audit persistence failures break API behavior.
        logger.exception(
            "Failed to persist API request audit log for endpoint=%s method=%s",
            endpoint_name or getattr(request, "path", "unknown"),
            getattr(request, "method", "unknown"),
        )
