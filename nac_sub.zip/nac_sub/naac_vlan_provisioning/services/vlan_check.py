"""VLAN check step wired to the legacy VLAN script."""


def run_vlan_check(payload, conn):
    """
    Validate VLAN configuration.

    Returns:
        vlan_message (str)

    Raises:
        Exception on failure
    """
    from naac_vlan_provisioning.checks.vlan_check import check_vlan

    port = payload.get("port", {})
    interface = port.get("interface")
    vlan = port.get("access_vlan", port.get("data_vlan", port.get("vlan")))

    if not interface:
        raise Exception("Missing interface")

    if vlan in (None, ""):
        raise Exception("Missing VLAN")

    status, message = check_vlan(conn, interface, vlan)

    if not status:
        raise Exception(message)

    return message
