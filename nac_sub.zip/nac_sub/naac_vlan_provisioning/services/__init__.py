"""Service layer for naac_vlan_provisioning."""
