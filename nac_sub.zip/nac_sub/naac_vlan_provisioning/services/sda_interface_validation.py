"""

SDA Interface Validation.

"""


import logging


logger = logging.getLogger(__name__)




def validate_interface(

    dnac_client,

    device_id,

    interface_name,

):

    """

    Validate interface exists and

    is not trunk / port-channel.

    """


    result = dnac_client.get_device_interfaces(

        device_id

    )


    interfaces = result.get(

        "response",

        [],

    )


    target_interface = None


    for interface in interfaces:


        if (

            interface.get("portName")

            == interface_name

        ):

            target_interface = interface

            break


    if not target_interface:

        raise Exception(

            f"Interface {interface_name} not found"

        )


    interface_id = target_interface.get("id")


    if not interface_id:

        raise Exception(

            "Interface ID not found"

        )


    # trunk validation

    vlan_mode = str(

        target_interface.get(

            "vlanMode",

            "",

        )

    ).lower()


    if vlan_mode == "trunk":

        raise Exception(

            f"{interface_name} is a trunk port"

        )


    # port-channel validation

    port_type = str(

        target_interface.get(

            "portType",

            "",

        )

    ).lower()


    if "port-channel" in port_type:

        raise Exception(

            f"{interface_name} belongs to port-channel"

        )


    target_interface["interface_id"] = interface_id


    return target_interface
 