def validate_enable_assignment(

    dnac_client,

    device_id,

    interface_name,

):

    result = dnac_client.get_port_assignments(

        device_id,

        interface_name,

    )


    assignments = result.get(

        "response",

        [],

    )


    if not assignments:

        raise Exception(

            "Assignment not found after enable"

        )


    return assignments[0]

def validate_disable_assignment(

    dnac_client,

    device_id,

    interface_name,

):

    result = dnac_client.get_port_assignments(

        device_id,

        interface_name,

    )


    assignments = result.get(

        "response",

        [],

    )


    if assignments:

        raise Exception(

            "Assignment still exists after disable"

        )


    return True