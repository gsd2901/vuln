"""

SDA Port Assignment Validation.

"""


import logging


logger = logging.getLogger(__name__)




def get_current_assignment(

    dnac_client,

    device_id,

    interface_name,

):

    """

    Return current SDA port assignment.

    """


    logger.info(

        "Checking SDA assignment for %s %s",

        device_id,

        interface_name,

    )


    result = dnac_client.get_port_assignments(

        device_id,

        interface_name,

    )


    assignments = result.get(

        "response",

        [],

    )


    if assignments:

        return assignments[0]


    return None

def assign_port(

    dnac_client,

    payload,

):

    """

    Create SDA port assignment.

    """


    logger.info(

        "Creating SDA port assignment"

    )


    return dnac_client.create_port_assignment(

        payload

    )

def update_port(

    dnac_client,

    payload,

):

    """

    Update SDA port assignment.

    """


    logger.info(

        "Updating SDA port assignment"

    )


    return dnac_client.update_port_assignment(

        payload

    )

def delete_port(

    dnac_client,

    assignment_id,

):

    """

    Delete SDA port assignment.

    """


    logger.info(

        "Deleting SDA port assignment %s",

        assignment_id,

    )


    return dnac_client.delete_port_assignment(

        assignment_id

    )
  

 