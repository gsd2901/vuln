def transform_to_legacy(payload):
    """
    Convert new structured payload → legacy format expected by checks/services
    """

    return {
        "task_id": payload["task"]["id"],
        "ci": {
            "ip": payload["device"].get("ip"),
            "username": payload.get("credentials", {}).get("username"),
            "password": payload.get("credentials", {}).get("password"),
            "use_secret": payload.get("credentials", {}).get("use_secret", False),
        },
        "port": payload["port"]
    }
