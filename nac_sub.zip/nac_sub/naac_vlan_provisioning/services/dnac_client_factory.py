"""
DNAC Client Factory.
"""

from django.conf import settings

from naac_vlan_provisioning.services.dnac_client import (
    DNACClient,
)


def get_dnac_client(location_name):

    plugin_config = settings.PLUGINS_CONFIG.get(
        "naac_vlan_provisioning",
        {},
    )

    dnac_config = plugin_config.get(
        "dnac",
        {},
    )

    location_name = str(
        location_name or ""
    ).upper()

    if "VIJAYAWADA" in location_name:
        base_url = dnac_config.get(
            "vja_url"
        )

    elif "NOIDA" in location_name:
        base_url = dnac_config.get(
            "noida_url"
        )

    else:
        base_url = dnac_config.get(
            "geo_url"
        )

    return DNACClient(
        base_url=base_url,
        username=dnac_config.get(
            "username"
        ),
        password=dnac_config.get(
            "password"
        ),
    )