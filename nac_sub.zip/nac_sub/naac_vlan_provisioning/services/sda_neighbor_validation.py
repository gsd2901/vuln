"""

SDA Neighbor Validation.

"""


import logging


logger = logging.getLogger(__name__)




def validate_non_uplink_port(

    dnac_client,

    device_id,

    interface_name,

):

    """

    Validate interface is not uplink.

    """


    result = dnac_client.get_neighbors(

        device_id

    )


    neighbors = result.get(

        "response",

        [],

    )


    for neighbor in neighbors:


        local_interface = (

            neighbor.get("localInterfaceName")

            or neighbor.get("localInterface")

            or ""

        )


        if local_interface != interface_name:

            continue


        raise Exception(

            f"{interface_name} is connected to a neighbor device and appears to be an uplink port"

        )


    return True
