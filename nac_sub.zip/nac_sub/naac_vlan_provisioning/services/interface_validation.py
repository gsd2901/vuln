"""Interface validation step wired to the legacy interface script."""


def run_interface_validation(payload, conn):
    """
    Validate interface configuration.

    Returns:
        interface_data (dict)

    Raises:
        Exception on failure
    """
    from naac_vlan_provisioning.checks.interface_check import check_interface

    interface = payload.get("port", {}).get("interface")

    if not interface:
        raise Exception("Missing interface")

    status, message, data = check_interface(conn, interface)

    if not status:
        raise Exception(message)

    return data