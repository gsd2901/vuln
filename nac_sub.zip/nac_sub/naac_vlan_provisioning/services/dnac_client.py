"""
Cisco DNAC API client.
"""


import requests

import logging

logger = logging.getLogger(__name__)


class DNACClient:

    """
    Wrapper around Cisco DNAC APIs.
    """

    def __init__(

        self,

        base_url,

        username,

        password,

    ):

        self.base_url = base_url.rstrip("/")

        self.username = username

        self.password = password

        self.token = None


    def get_token(self):

        """
        Generate DNAC authentication token.
        """

        url = (

            f"{self.base_url}"

            "/dna/system/api/v1/auth/token"

        )

        response = requests.post(

            url,

            auth=(

                self.username,

                self.password,

            ),

            verify=False,

            timeout=30,

        )

        response.raise_for_status()

        token = response.json().get("Token")

        if not token:

            raise Exception(

                "DNAC token not returned"

            )

        self.token = token

        return token

    def get_headers(self):

        """
        Return authenticated headers.
        """

        if not self.token:

            self.get_token()

        return {

            "X-Auth-Token": self.token,

            "Content-Type": "application/json",

        }

    def get_device_by_ip(self, ip_address):

        """

        Lookup device in DNAC using management IP.

        """


        url = (

            f"{self.base_url}"

            f"/dna/intent/api/v1/network-device/ip-address/{ip_address}"

        )


        response = requests.get(

            url,

            headers=self.get_headers(),

            verify=False,

            timeout=30,

        )


        response.raise_for_status()


        return response.json() 

    def get_device_by_hostname(

        self,

        hostname,

    ):

        """

        Lookup device in DNAC using hostname.

        """


        url = (

            f"{self.base_url}"

            f"/dna/intent/api/v1/network-device"

        )


        response = requests.get(

            url,

            headers=self.get_headers(),

            params={

                "hostname": hostname,

            },

            verify=False,

            timeout=30,

        )


        response.raise_for_status()


        return response.json()

    def get_all_devices(self):

        """

        Return all devices from DNAC inventory.

        """


        url = (

            f"{self.base_url}"

            f"/dna/intent/api/v1/network-device"

        )


        response = requests.get(

            url,

            headers=self.get_headers(),

            verify=False,

            timeout=30,

        )


        response.raise_for_status()


        return response.json()

    def get_fabric_edge_device(
            self,
            device_ip,
    ):
        url = (
            f"{self.base_url}"
            "/dna/intent/api/v1/business/sda/edge-device"
        )

        response = requests.get(
            url,
            headers=self.get_headers(),
            params={
                "deviceManagementIpAddress": device_ip
            },
            verify=False,
            timeout=30,
        )

        response.raise_for_status()

        return response.json()

    def get_port_assignments(

        self,

        device_id,

        interface_name,

        ):

        """

        Get current SDA port assignment.

        """


        url = (

            f"{self.base_url}"

            "/dna/intent/api/v1/sda/portAssignments"

        )


        response = requests.get(

            url,

            headers=self.get_headers(),

            params={

                "networkDeviceId": device_id,

                "interfaceName": interface_name,

            },

            verify=False,

            timeout=30,

        )


        response.raise_for_status()


        return response.json()
    

    def get_device_interfaces(

        self,

        device_id,

    ):

        """

        Get all interfaces for a device.

        """


        url = (

            f"{self.base_url}"

            f"/dna/intent/api/v1/interface/network-device/{device_id}"

        )


        response = requests.get(

            url,

            headers=self.get_headers(),

            verify=False,

            timeout=30,

        )


        response.raise_for_status()


        return response.json()

    def get_neighbors(

        self,

        device_id,

    ):

        """

        Get LLDP/CDP neighbors.

        """


        url = (

            f"{self.base_url}"

            f"/dna/intent/api/v1/network-device/{device_id}/neighbor"

        )


        response = requests.get(

            url,

            headers=self.get_headers(),

            verify=False,

            timeout=30,

        )


        response.raise_for_status()


        return response.json()
    def get_interface_details(
        self,
        interface_id,
    ):
        """
        Get interface details.
        """

        url = (
            f"{self.base_url}"
            f"/dna/intent/api/v1/interface/{interface_id}"
        )

        response = requests.get(
            url,
            headers=self.get_headers(),
            verify=False,
            timeout=30,
        )

        response.raise_for_status()

        return response.json()

    def get_virtual_networks(self):

        """

        Get SDA Virtual Networks.

        """


        url = (

            f"{self.base_url}"

            "/dna/intent/api/v1/business/sda/virtual-network"

        )


        response = requests.get(

            url,

            headers=self.get_headers(),

            verify=False,

            timeout=30,

        )


        response.raise_for_status()


        return response.json()

    def get_ip_pools(self):

        """

        Get SDA IP Pools.

        """


        url = (

            f"{self.base_url}"

            "/dna/intent/api/v1/business/sda/virtualnetwork/ippool"

        )


        response = requests.get(

            url,

            headers=self.get_headers(),

            verify=False,

            timeout=30,

        )


        response.raise_for_status()


        return response.json() 

    def create_port_assignment(

        self,

        payload,

    ):

        url = (

            f"{self.base_url}"

            "/dna/intent/api/v1/sda/portAssignments"

        )


        response = requests.post(

            url,

            headers=self.get_headers(),

            json=payload,

            verify=False,

            timeout=60,

        )


        response.raise_for_status()


        return response.json()

    def update_port_assignment(

        self,

        payload,

    ):

        url = (

            f"{self.base_url}"

            "/dna/intent/api/v1/sda/portAssignments"

        )


        response = requests.put(

            url,

            headers=self.get_headers(),

            json=payload,

            verify=False,

            timeout=60,

        )


        response.raise_for_status()


        return response.json()

    def delete_port_assignment(

        self,

        assignment_id,

    ):

        url = (

            f"{self.base_url}"

            f"/dna/intent/api/v1/sda/portAssignments/{assignment_id}"

        )


        response = requests.delete(

            url,

            headers=self.get_headers(),

            verify=False,

            timeout=60,

        )


        response.raise_for_status()


        return response.json()

    def get_task_status(

        self,

        task_id,

    ):

        """

        Get DNAC task status.

        """


        url = (

            f"{self.base_url}"

            f"/dna/intent/api/v1/task/{task_id}"

        )


        response = requests.get(

            url,

            headers=self.get_headers(),

            verify=False,

            timeout=30,

        )


        response.raise_for_status()


        return response.json()
    

