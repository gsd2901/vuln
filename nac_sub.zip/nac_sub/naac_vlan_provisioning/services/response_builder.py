"""Response generation helper for VLAN provisioning."""


def build_response(payload, flow_result):
    """
    Build standardized response for DISABLED port flow.
    This aligns with API response contract and flow diagram.
    """

    return {
        "step": "validate_vlan_access",
        "mode": flow_result.get("mode", "unknown"),
        "result": "condition_based",
        "next_action": flow_result.get("next_action"),
        "interface": flow_result.get("interface"),
        "message": flow_result.get("port_mode_message"),
    }