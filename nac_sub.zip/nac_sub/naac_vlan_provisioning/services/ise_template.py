"""ISE template helpers for validation and command generation."""

import re


SUPPORTED_PROFILES = {
    "staging",
    "user_data_voice",
    "user_data",
    "printer",
    "voice",
    "cctv",
    "act",
    "bms",
    "cms",
    "aruba_wap",
    "cisco_wap",
}

PROFILE_DESCRIPTIONS = {
    "staging": "#SoE#",
    "user_data_voice": "#USRC#",
    "user_data": "#USRD#",
    "printer": "#PRT#",
    "voice": "#USRV#",
    "cctv": "#CCT#",
    "act": "#ACT#",
    "bms": "#BMS#",
    "cms": "#CMS#",
    "aruba_wap": "#WAP#ARUBA#",
    "cisco_wap": "#WAP#CISCO#",
}

TRUNK_PROFILES = {"aruba_wap", "cisco_wap"}
VOICE_REQUIRED_PROFILES = {"user_data_voice", "bms", "cms"}
DATA_REQUIRED_PROFILES = {
    "staging",
    "user_data_voice",
    "user_data",
    "printer",
    "cctv",
    "act",
    "bms",
    "cms",
}


def _int_vlan(value):
    if value in (None, ""):
        return None
    try:
        vlan = int(value)
    except Exception:
        raise Exception("VLAN values must be integers")

    if not (1 <= vlan <= 4094):
        raise Exception("VLAN values must be between 1-4094")
    return vlan


def _normalize_profile(value):
    if not value:
        return "user_data"

    profile = str(value).strip().lower()
    profile = profile.replace("-", "_").replace(" ", "_")
    return profile


def _normalize_description(value):
    if value is None:
        return ""
    return str(value).strip()


def _build_profile_description(profile, payload_description):
    """Build final interface description from payload + profile mapping."""
    description = _normalize_description(payload_description)
    profile_description = PROFILE_DESCRIPTIONS.get(profile, "")

    if not description:
        return profile_description or None

    # Keep payload description only when it already contains the selected profile marker.
    if profile_description and profile_description in description:
        return description

    if profile_description:
        return f"{profile_description} {description}"

    return description


def _parse_allowed_vlans(value):
    """Normalize allowed VLAN input into an integer list."""
    if value in (None, ""):
        return []

    if isinstance(value, str):
        items = [item.strip() for item in value.split(",") if item.strip()]
        return [_int_vlan(item) for item in items]

    if isinstance(value, (list, tuple, set)):
        return [_int_vlan(item) for item in value]

    return [_int_vlan(value)]


def extract_port_spec(payload):
    """Extract and normalize port spec from payload with backward compatibility."""
    port = payload.get("port", {}) or {}
    profile = _normalize_profile(port.get("profile") or port.get("port_type_matrix"))
    raw_access_vlan = port.get("access_vlan", port.get("data_vlan", port.get("vlan")))
    raw_voice_vlan = port.get("voice_vlan")
    raw_native_vlan = port.get("native_vlan")
    raw_allowed_vlans = port.get("allowed_vlans")

    access_vlan = _int_vlan(raw_access_vlan)

    if profile in TRUNK_PROFILES:
        # Backward-compatible alias for trunk payloads:
        # native_vlan <- access_vlan, allowed_vlans <- voice_vlan
        native_source = raw_native_vlan if raw_native_vlan not in (None, "") else raw_access_vlan
        allowed_source = raw_allowed_vlans if raw_allowed_vlans not in (None, "", []) else raw_voice_vlan
        native_vlan = _int_vlan(native_source)
        allowed_vlan_list = _parse_allowed_vlans(allowed_source)
        voice_vlan = None
    else:
        voice_vlan = _int_vlan(raw_voice_vlan)
        native_vlan = _int_vlan(raw_native_vlan)
        allowed_vlan_list = _parse_allowed_vlans(raw_allowed_vlans)

    spec = {
        "interface": port.get("interface"),
        "mode": str(port.get("mode", "")).strip().lower(),
        "profile": profile,
        "payload_description": _normalize_description(port.get("new_interface_description")),
        "description": _build_profile_description(profile, port.get("new_interface_description")),
        "access_vlan": access_vlan,
        "voice_vlan": voice_vlan,
        "native_vlan": native_vlan,
        "allowed_vlans": allowed_vlan_list,
    }
    return spec


def validate_port_spec(payload):
    """Validate ISE-specific payload requirements."""
    spec = extract_port_spec(payload)

    if spec["profile"] not in SUPPORTED_PROFILES:
        raise Exception(
            "port.profile must be one of: "
            + ", ".join(sorted(SUPPORTED_PROFILES))
        )

    if spec["mode"] not in {"enabled", "disabled"}:
        raise Exception("port.mode must be enabled or disabled")

    # ✅ NEW: Interface required for BOTH modes
    if not spec["interface"]:
        raise Exception("port.interface is required")

    # ✅ Relax validation for disabled mode
    if spec["mode"] == "disabled":
        return spec

    # ✅ Existing validation continues for enabled mode only
    if not spec["payload_description"]:
        raise Exception("port.description is required")

    if spec["profile"] in DATA_REQUIRED_PROFILES and spec["access_vlan"] is None:
        raise Exception(f"port.access_vlan is required for profile '{spec['profile']}'")

    if spec["profile"] in VOICE_REQUIRED_PROFILES and spec["voice_vlan"] is None:
        raise Exception(f"port.voice_vlan is required for profile '{spec['profile']}'")

    if spec["profile"] == "voice" and spec["voice_vlan"] is None:
        raise Exception("port.voice_vlan is required for profile 'voice'")

    if spec["profile"] in TRUNK_PROFILES and spec["native_vlan"] is None:
        raise Exception(f"port.native_vlan is required for profile '{spec['profile']}'")

    if spec["profile"] == "cisco_wap" and not spec["allowed_vlans"]:
        raise Exception("port.allowed_vlans is required for profile 'cisco_wap'")

    return spec


def pick_device_tracking_policy(conn):
    """
    Select attach-policy with fallback.

    Behavior:
    1) ise-tracking
    2) IPDT_POLICY
    3) if neither exists, bootstrap ise-tracking policy
    """
    command = "show run | i device-tracking policy"
    out = conn.send_command(command)
    out_lower = out.lower()
    if "invalid input" in out_lower or "% invalid" in out_lower:
        out_lower = ""

    combined = out_lower
    discovered_policies = set()
    for line in combined.splitlines():
        match = re.search(r"\bdevice-tracking policy\s+(\S+)", line.strip())
        if match:
            discovered_policies.add(match.group(1))

    if re.search(r"\bise-tracking\b", combined):
        return {
            "selected_policy": "ise-tracking",
            "bootstrap_required": False,
            "bootstrap_commands": [],
            "source": "existing",
        }

    if re.search(r"\bipdt_policy\b", combined):
        return {
            "selected_policy": "IPDT_POLICY",
            "bootstrap_required": False,
            "bootstrap_commands": [],
            "source": "existing",
        }

    # Fallback requested by operations:
    # create and use ise-tracking when no policy is available.
    return {
        "selected_policy": "ise-tracking",
        "bootstrap_required": True,
        "bootstrap_commands": [
            "device-tracking policy ise-tracking",
            "tracking enable",
            "exit",
        ],
        "source": "bootstrapped_global_policy",
        "discovered_policies": sorted(discovered_policies),
    }


def resolve_storm_level(interface_data):
    """Map speed to storm-control level."""
    speed_raw = str(interface_data.get("speed") or "").strip().upper()
    speed_normalized = speed_raw.replace("A-", "")

    if re.search(r"\b(10|20|25)\s*G\b", speed_normalized):
        return "0.30"

    if re.search(r"\b(10000|20000|25000)\b", speed_normalized):
        return "0.30"

    return "3.00"


def _common_auth_commands(host_mode):
    return [
        "authentication event fail action next-method",
        f"authentication host-mode {host_mode}",
        "authentication order mab dot1x",
        "authentication priority dot1x mab",
        "authentication port-control auto",
        "authentication violation restrict",
        "mab",
        "dot1x pae authenticator",
    ]


def _server_dead_commands(spec):
    commands = []
    if spec["profile"] in TRUNK_PROFILES:
        commands.append(
            f"authentication event server dead action authorize vlan {spec['native_vlan']}"
        )
    elif spec["profile"] != "voice" and spec["access_vlan"] is not None:
        commands.append(
            f"authentication event server dead action authorize vlan {spec['access_vlan']}"
        )

    commands.append("authentication event server dead action authorize voice")
    return commands


def build_ise_commands(payload, interface_data, tracking_policy, bootstrap_commands=None):
    """Build full ISE template commands for configured profile."""
    spec = validate_port_spec(payload)
    storm_level = resolve_storm_level(interface_data)
    bootstrap_commands = bootstrap_commands or []

    interface = spec["interface"]
    if not interface:
        raise Exception("Missing interface")

    # ✅ NEW: Handle DISABLED mode (minimal impact)
    if spec["mode"] == "disabled":
        commands = [
            f"default interface {interface}",
            f"interface {interface}",
            "shutdown",
            "exit",
        ]
        return {
            "commands": commands,
            "storm_level": storm_level,
            "profile": spec["profile"],
            "access_vlan": spec["access_vlan"],
        }

    # ✅ Existing logic continues unchanged for ENABLED
    commands = list(bootstrap_commands) + [
        f"default interface {interface}",
        f"interface {interface}"
    ]

    if spec["description"]:
        commands.append(f"description {spec['description']}")

    if spec["profile"] in TRUNK_PROFILES:
        commands.extend(
            [
                f"switchport trunk native vlan {spec['native_vlan']}",
            ]
        )
        if spec["profile"] == "cisco_wap":
            allowed = ",".join(str(vlan) for vlan in spec["allowed_vlans"])
            commands.append(f"switchport trunk allowed vlan {allowed}")
        commands.append("switchport mode trunk")
    else:
        if spec["access_vlan"] is not None:
            commands.append(f"switchport access vlan {spec['access_vlan']}")
        commands.append("switchport mode access")
        if spec["voice_vlan"] is not None:
            commands.append(f"switchport voice vlan {spec['voice_vlan']}")

    commands.append(f"device-tracking attach-policy {tracking_policy}")
    if spec["profile"] in TRUNK_PROFILES:
        commands.append("logging event trunk-status")

    commands.extend(
        _common_auth_commands(
            "multi-host" if spec["profile"] in TRUNK_PROFILES else "multi-domain"
        )
    )
    commands.extend(_server_dead_commands(spec))
    commands.append("authentication event server alive action reinitialize")
    commands.extend(
        [
            f"storm-control broadcast level {storm_level}",
            f"storm-control multicast level {storm_level}",
            "storm-control action trap",
        ]
    )

    if spec["profile"] in TRUNK_PROFILES:
        commands.append("spanning-tree portfast trunk")
    else:
        commands.extend(
            [
                "spanning-tree portfast",
                "spanning-tree bpduguard enable",
            ]
        )
    
    commands.append("no shutdown")

    return {
        "commands": commands,
        "storm_level": storm_level,
        "profile": spec["profile"],
        "access_vlan": spec["access_vlan"],
    }
