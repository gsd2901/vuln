"""High-level validation flow wired to the legacy pre-validation scripts."""

from naac_vlan_provisioning.services.payload_transformer import transform_to_legacy
from naac_vlan_provisioning.services.health_check import run_health_check
from naac_vlan_provisioning.services.interface_validation import run_interface_validation
from naac_vlan_provisioning.services.vlan_check import run_vlan_check
from naac_vlan_provisioning.services.vlan_executor import run_vlan_configuration
from naac_vlan_provisioning.services.ise_template import (
    pick_device_tracking_policy,
    resolve_storm_level,
)
from naac_vlan_provisioning.services.servicenow_workflow import (
    run_post_provision_snow_actions,
)
from naac_vlan_provisioning.services.workflow_router import (
    determine_workflow,
)
from naac_vlan_provisioning.services.device_location_resolver import (
    get_device_location_from_ip,
)
from naac_vlan_provisioning.services.dnac_client_factory import (
    get_dnac_client,
)
from naac_vlan_provisioning.services.sda_vlan_executor import (
    run_sda_vlan_configuration,
)
 

def validate_payload(payload):
    """Validate structured payload using legacy checks via transformer."""
    from naac_vlan_provisioning.checks.payload_check import check_payload

    status, message = check_payload(payload)
    if not status:
        raise Exception(message)

    return {"message": "Payload validation successful"}


def validate_device_type(payload):
    """Validate device role via Nautobot (SoT)."""
    from naac_vlan_provisioning.checks.device_role_check import check_device_role

    device = payload.get("device", {}) if isinstance(payload, dict) else {}
    ci = {
        "ip": device.get("ip"),
    }
    status, message = check_device_role(ci)

    if not status:
        raise Exception(message)

    return {"message": "Device type validation successful"}


def validate_vlan_access(payload):
    """VLAN access validation (STRICT diagram-aligned)."""
    from naac_vlan_provisioning.checks.port_mode_check import check_port_mode

    legacy_payload = transform_to_legacy(payload)

    response = {
        "step": "validate_vlan_access",
        "execution_path": None,
        "decision": None,
        "reason": None,
        "checks": {"reachability": {}, "interface": {}, "vlan": {}},
        "action": {},
    }
    connection = None

    port_status, port_message, mode = check_port_mode(legacy_payload)
    if not port_status:
        raise Exception(port_message)

    response["execution_path"] = mode

    try:
        connection = run_health_check(legacy_payload)
        response["checks"]["reachability"] = {
            "status": "passed",
            "message": "Device reachable",
        }
    except Exception as e:
        response["checks"]["reachability"] = {
            "status": "failed",
            "message": str(e),
        }
        response["decision"] = "stop"
        response["reason"] = "Device not reachable"
        response["action"] = {
            "next_step": "update_log",
            "summary": "Stop execution due to reachability failure",
        }
        return response

    try:
        try:
            interface_data = run_interface_validation(legacy_payload, connection)
        except Exception as e:
            message = str(e)
            response["checks"]["interface"] = {
                "status": "failed",
                "message": message,
            }
            response["checks"]["vlan"] = {"status": "skipped"}
            response["decision"] = "stop"
            response["reason"] = (
                "Interface not present"
                if "interface not present" in message.lower()
                else message
            )
            response["action"] = {
                "next_step": "update_log",
                "summary": "Stop execution due to interface validation failure",
            }
            return response

        interface_mode = interface_data.get("mode")
        interface_status = interface_data.get("status")
        storm_level = resolve_storm_level(interface_data)
        is_trunk = interface_mode == "trunk"
        is_interface_up = interface_status == "up"

        response["checks"]["interface"] = {
            "status": "passed",
            "details": interface_data,
            "message": f"Interface is {interface_status}",
            "captures": {
                "trunk": is_trunk,
                "interface_up": is_interface_up,
            },
        }
        response["checks"]["storm_control"] = {
            "status": "evaluated",
            "level": storm_level,
        }

        try:
            policy_info = pick_device_tracking_policy(connection)
            response["checks"]["device_tracking_policy"] = {
                "status": "passed",
                "selected": policy_info.get("selected_policy"),
                "source": policy_info.get("source"),
                "bootstrap_required": policy_info.get(
                    "bootstrap_required", False
                ),
                "bootstrap_commands": policy_info.get(
                    "bootstrap_commands", []
                ),
            }
        except Exception as e:
            response["checks"]["device_tracking_policy"] = {
                "status": "failed",
                "message": str(e),
            }
            response["decision"] = "stop"
            response["reason"] = str(e)
            response["checks"]["vlan"] = {"status": "skipped"}
            response["action"] = {
                "next_step": "update_log",
                "summary": "Stop execution due to missing device-tracking policy",
            }
            return response

        if interface_mode == "l3":
            response["checks"]["interface"]["status"] = "failed"
            response["checks"]["interface"]["message"] = "Interface is routed (L3)"
            response["decision"] = "stop"
            response["reason"] = "VLAN cannot be configured on L3 interface"
            response["checks"]["vlan"] = {"status": "skipped"}
            response["action"] = {
                "next_step": "update_log",
                "summary": "Stop execution (L3 interface)",
            }
            return response

        # ============================================================
        # ✅ NEW STRICT INTERFACE LOGIC (APPLIES TO BOTH MODES)
        # ============================================================

        if is_trunk:
            response["checks"]["interface"]["status"] = "failed"
            response["checks"]["interface"]["message"] = "Interface is trunk"
            response["decision"] = "stop"
            response["reason"] = "Trunk interface not allowed"
            response["checks"]["vlan"] = {"status": "skipped"}
            response["action"] = {
                "next_step": "update_log",
                "summary": "Stop execution (trunk interface)",
            }
            return response

        if is_interface_up:
            response["checks"]["interface"]["status"] = "failed"
            response["checks"]["interface"]["message"] = "Interface is up"
            response["decision"] = "stop"
            response["reason"] = "Interface is active (up) - cannot proceed"
            response["checks"]["vlan"] = {"status": "skipped"}
            response["action"] = {
                "next_step": "update_log",
                "summary": "Stop execution (interface up)",
            }
            return response

        # ✅ If reached here → valid interface
        response["checks"]["interface"][
            "message"
        ] = "Interface is down and not trunk, proceeding"

        # ============================================================
        # ✅ ENABLE MODE → VLAN STRICT VALIDATION
        # ============================================================

        if mode == "enabled":

            requested_vlan = legacy_payload.get("port", {}).get(
                "access_vlan",
                legacy_payload.get("port", {}).get(
                    "data_vlan", legacy_payload.get("port", {}).get("vlan")
                ),
            )

            if requested_vlan in (None, ""):
                response["checks"]["vlan"] = {
                    "status": "skipped",
                    "message": "No VLAN provided",
                }
                response["decision"] = "change_required"
                response["reason"] = "No VLAN provided"
                response["action"] = {
                    "next_step": "proceed",
                    "summary": "Proceed with configuration",
                }
                return response

            try:
                vlan_message = run_vlan_check(legacy_payload, connection)
            except Exception as e:
                vlan_error = str(e)
                response["checks"]["vlan"] = {
                    "status": "failed",
                    "message": vlan_error,
                }

                if "not present on device" in vlan_error:
                    response["decision"] = "stop"
                    response["reason"] = "VLAN not present on device"
                else:
                    response["decision"] = "stop"
                    response["reason"] = vlan_error

                response["action"] = {
                    "next_step": "update_log",
                    "summary": "Stop execution due to VLAN validation failure",
                }
                return response

            response["checks"]["vlan"] = {
                "status": "evaluated",
                "message": vlan_message,
            }

            # ✅ VLAN not present
            if "not present on device" in vlan_message:
                response["decision"] = "stop"
                response["reason"] = "VLAN not present on device"
                response["action"] = {
                    "next_step": "update_log",
                    "summary": "Stop execution (VLAN missing)",
                }
                return response

            # ✅ VLAN already used anywhere
            if "already present" in vlan_message.lower():
                response["decision"] = "stop"
                response["reason"] = "VLAN already configured on another interface"
                response["action"] = {
                    "next_step": "update_log",
                    "summary": "Stop execution (VLAN already in use)",
                }
                return response

            # ✅ VLAN exists and free
            response["decision"] = "change_required"
            response["reason"] = "VLAN exists and not configured anywhere"
            response["action"] = {
                "next_step": "proceed",
                "summary": "Proceed with VLAN configuration",
            }
            return response

        # ============================================================
        # ✅ DISABLE MODE (VLAN SKIPPED)
        # ============================================================

        response["checks"]["vlan"] = {
            "status": "skipped",
            "message": "Skipped for disable flow",
        }

        response["decision"] = "change_required"
        response["reason"] = "Disable pre-checks passed"
        response["action"] = {
            "next_step": "proceed",
            "summary": "Proceed with configuration push",
        }

        return response

    finally:
        if connection and hasattr(connection, "disconnect"):
            connection.disconnect()

def provision_vlan(payload):
    """
    Validate payload + device type + VLAN access and configure VLAN.

    SNOW actions are always executed:
    - On success → execution details added to work notes
    - On failure → error details added to work notes
    """

    execution = {}
    error = None

    try:
        # Step 1: Validations
        validate_payload(payload)
        validate_device_type(payload)

        vlan_access_result = validate_vlan_access(payload)
        if vlan_access_result.get("decision") != "change_required":
            raise ValueError(
                f"Provisioning blocked: {vlan_access_result.get('reason', 'validation did not permit configuration')}"
            )

        # Step 2: Prepare + Execute
        legacy_payload = transform_to_legacy(payload)
        connection = None

        try:
            connection = run_health_check(

                legacy_payload

            )


            workflow_type = determine_workflow(
                connection
            )

            if workflow_type == "SDA":

                dnac_client = get_dnac_client()

                execution = (
                    run_sda_vlan_configuration(
                        payload,
                        dnac_client,
                    )
                )

            else:

                #
                # LEGACY FLOW
                #

                execution = (
                    run_vlan_configuration(
                        legacy_payload,
                        connection,
                    )
                )

            execution["workflow_type"] = (
                workflow_type
            )

            execution["status"] = "success"
            

        finally:
            if connection and hasattr(connection, "disconnect"):
                connection.disconnect()

    except Exception as exc:
        # Capture failure details for SNOW
        error = str(exc)

        execution = {
            "status": "failed",
            "error": error,
        }   

    # ✅ Always run SNOW actions
    servicenow_result = run_post_provision_snow_actions(payload, execution)

    # Final message
    if execution.get("status") == "failed":
        message = "VLAN provisioning failed, but SNOW ticket updated and closed"
    elif servicenow_result.get("status") == "failed":
        message = "VLAN configured, but ServiceNow post-actions failed"
    else:
        message = "VLAN configured successfully"

    return {
        "message": message,
        "execution": execution,
        "servicenow": servicenow_result,
    }
