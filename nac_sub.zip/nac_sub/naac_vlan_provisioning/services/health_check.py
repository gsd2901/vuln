"""Health check step wired to the legacy reachability script."""

import logging
from nautobot.ipam.models import IPAddress
from django.conf import settings
from nautobot.extras.models import SecretsGroup

def run_health_check(payload):
    """
    Resolve device + credentials from Nautobot and establish connection.

    Returns:
        connection object

    Raises:
        Exception on failure
    """
    from naac_vlan_provisioning.checks.reachability_check import check_reachability

    ci = payload.get("ci", {})
    ip_address = ci.get("ip")

    if not ip_address:
        raise Exception("Missing device IP")

    # ---------------------------
    # 1. Resolve IP → Device
    # ---------------------------
    ip_obj = IPAddress.objects.filter(host=ip_address).first()

    if not ip_obj:
        raise Exception(f"IP {ip_address} not found.")

    device = None

    # Priority 1: Interface mapping
    if ip_obj.interfaces.exists():
        device = ip_obj.interfaces.first().device

    # Priority 2: Primary IP mapping
    elif ip_obj.primary_ip4_for.exists():
        device = ip_obj.primary_ip4_for.first()

    if not device:
        raise Exception(f"No device associated with IP {ip_address}")

    logging.info(f"Resolved device {device.name} for IP {ip_address}")

    # ---------------------------
    # 2. Fetch credentials from Plugin Config
    # ---------------------------
    from django.conf import settings
    from nautobot.extras.models import SecretsGroup

    secret_group_name = settings.PLUGINS_CONFIG.get(
        "naac_vlan_provisioning", {}
    ).get("secret_group_name")

    if not secret_group_name:
        raise Exception("Secret group not configured in plugin settings")

    try:
        secret_group = SecretsGroup.objects.get(name=secret_group_name)
    except SecretsGroup.DoesNotExist:
        raise Exception(f"Secret group '{secret_group_name}' not found")

    username = None
    password = None

    try:
        # Iterate over associations (version-safe)
        for assoc in secret_group.secrets_group_associations.all():
            if assoc.secret_type == "username":
                username = assoc.secret.get_value()
            elif assoc.secret_type == "password":
                password = assoc.secret.get_value()

    except Exception as e:
        raise Exception(f"Failed to retrieve secrets: {str(e)}")

    if not username or not password:
        raise Exception(
            "Secrets missing username/password. "
            "Ensure access_type 'username' and 'password' are configured in Secret Group."
        )

    # ---------------------------
    # 3. Reachability check (SSH)
    # ---------------------------
    status, result = check_reachability(ip_address, username, password)

    if not status:
        raise Exception(result)

    logging.info(f"Device reachable: {ip_address}")

    return result  # connection object