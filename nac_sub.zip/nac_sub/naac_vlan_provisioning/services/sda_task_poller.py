"""

DNAC Task Polling Service.

"""


import logging

import time


logger = logging.getLogger(__name__)

def poll_task_status(

    dnac_client,

    task_id,

    max_attempts=30,

    wait_time=10,

):

    """

    Poll DNAC task until SUCCESS / FAILURE.

    """


    for attempt in range(max_attempts):


        result = dnac_client.get_task_status(

            task_id

        )


        task = result.get(

            "response",

            {},

        )


        if task.get("isError") is True:


            raise Exception(

                task.get(

                    "failureReason",

                    "DNAC task failed",

                )

            )


        progress = str(

            task.get(

                "progress",

                "",

            )

        ).lower()


        if "success" in progress:

            return task


        logger.info(

            "Task %s still running. Attempt %s/%s",

            task_id,

            attempt + 1,

            max_attempts,

        )


        time.sleep(wait_time)


    raise Exception(

        f"Task timeout: {task_id}"

    )
 
 