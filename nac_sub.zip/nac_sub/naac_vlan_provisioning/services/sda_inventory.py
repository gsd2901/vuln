"""

SDA Inventory Validation Service.

"""


import logging


logger = logging.getLogger(__name__)




def validate_device_inventory(

    dnac_client,

    ip_address=None,

    hostname=None,

):

    """

    Inventory lookup sequence:


    1. Lookup by management IP

    2. If not found, lookup by hostname

    3. If still not found, get all devices and filter

    """


    device = None


    # Step 1: Lookup by IP

    if ip_address:

        logger.info(

            "Searching DNAC inventory by IP %s",

            ip_address,

        )


        try:
            result = dnac_client.get_device_by_ip(
                ip_address
            )

            device = result.get(
                "response",
                {}
            )
        except Exception:

            logger.exception(

                "IP lookup failed"

            )


    # Step 2: Lookup by hostname

    if not device and hostname:


        logger.info(

            "Searching DNAC inventory by hostname %s",

            hostname,

        )


        try:

            result = dnac_client.get_device_by_hostname(

                hostname

            )


            response = result.get(

                "response",

                [],

            )


            if response:

                device = response[0]


        except Exception:

            logger.exception(

                "Hostname lookup failed"

            )


    # Step 3: Get all devices and filter

    if not device and hostname:


        logger.info(

            "Searching complete DNAC inventory"

        )


        try:

            result = dnac_client.get_all_devices()


            devices = result.get(

                "response",

                [],

            )


            for entry in devices:


                if (

                    str(

                        entry.get(

                            "hostname",

                            "",

                        )

                    ).lower()

                    == hostname.lower()

                ):

                    device = entry

                    break


        except Exception:

            logger.exception(

                "Inventory filter failed"

            )


    if not device:

        raise Exception(
            "Device not found in DNAC inventory"
        )

 # Validate managed state

    managed_state = str(

        device.get(

            "managementState",

            "",

        )

    ).lower()


    if (

        managed_state

        and managed_state != "managed"

    ):

        raise Exception(

            f"Device is not managed. Current state: {managed_state}"

        )


# Validate reachability

    reachability = str(

        device.get(

            "reachabilityStatus",

            "",

        )

    ).lower()


    if (

        reachability

        and reachability != "reachable"

    ):

        raise Exception(

            f"Device is not reachable. Current status: {reachability}"

        )


# Extract Device ID

    device_id = (

        device.get("id")

        or device.get("instanceUuid")

    )


    if not device_id:

        raise Exception(

            "Device ID not found in DNAC inventory response"

        )


    device["device_id"] = device_id


    return device
    