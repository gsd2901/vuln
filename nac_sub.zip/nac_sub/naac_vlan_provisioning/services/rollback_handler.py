"""

SDA Rollback Handler.

"""


import logging


logger = logging.getLogger(__name__)

def rollback_assignment(

    dnac_client,

    device_id,

    interface_name,

):

    """

    Rollback SDA port assignment.

    """


    from naac_vlan_provisioning.services.sda_port_assignment import (

        get_current_assignment,

        delete_port,

    )


    assignment = get_current_assignment(

        dnac_client,

        device_id,

        interface_name,

    )


    if not assignment:

        return {

            "status": "no_assignment_found",

        }


    assignment_id = assignment.get("id")


    if not assignment_id:

        raise Exception(

            "Assignment ID not found for rollback."

        )


    delete_result = delete_port(

        dnac_client,

        assignment_id,

    )


    return {

        "status": "rollback_completed",

        "assignment_id": assignment_id,

        "delete_result": delete_result,

    }

def validate_rollback(

    dnac_client,

    device_id,

    interface_name,

):

    """

    Verify rollback was successful.

    """


    result = dnac_client.get_port_assignments(

        device_id,

        interface_name,

    )


    assignments = result.get(

        "response",

        [],

    )


    if assignments:

        raise Exception(

            "Rollback validation failed. SDA assignment still exists."

        )


    return {

        "status": "rollback_verified",

    }

def build_rollback_response(

    failure_reason,

):

    """

    Build rollback response.

    """


    return {

        "status": "rollback_completed",

        "failure_reason": str(

            failure_reason

        ),

        "manual_intervention_required": True,

    }  