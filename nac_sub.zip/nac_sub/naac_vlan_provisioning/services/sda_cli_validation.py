"""

SDA CLI Post Validation.

"""


import logging


logger = logging.getLogger(__name__)

def validate_running_config(

    conn,

    interface_name,

):

    """

    Post-check running config validation.

    """


    output = conn.send_command(

        f"show running-config interface {interface_name}"

    )


    return output

def validate_interface_status(

    conn,

    interface_name,

):

    """

    Post-check interface status validation.

    """


    output = conn.send_command(

        f"show interface {interface_name} status"

    )


    return output
  