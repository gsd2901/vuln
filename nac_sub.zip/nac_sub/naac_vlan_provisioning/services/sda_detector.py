"""
SDA detection service.
Determines whether a switch is SDA-enabled or Legacy.
"""

import logging

logger = logging.getLogger(__name__)

def is_sda_device(conn):

    """
    Determine whether device belongs to SDA fabric.
    Returns:
        True  -> SDA
        False -> Legacy
    """

    try:
        output = conn.send_command(
            "show run | i router lisp"
        )

        logger.info(
            "SDA detection output: %s",
            output
        )

        return "router lisp" in output.lower()

    except Exception as exc:
        logger.exception(
            "Failed SDA detection: %s",
            exc,
        )
        return False
 