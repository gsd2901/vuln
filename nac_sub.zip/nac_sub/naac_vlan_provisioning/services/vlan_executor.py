"""VLAN configuration execution service."""

from naac_vlan_provisioning.checks.interface_check import check_interface
from naac_vlan_provisioning.services.ise_template import (
    build_ise_commands,
    pick_device_tracking_policy,
)


def run_vlan_configuration(payload, conn):
    """
    Configure full ISE template on a target interface.

    Returns:
        dict with execution details.

    Raises:
        Exception on invalid input or execution failure.
    """
    port = payload.get("port", {})
    interface = port.get("interface")

    if not interface:
        raise Exception("Missing interface")

    ok, message, interface_data = check_interface(conn, interface)
    if not ok:
        raise Exception(message)

    policy_info = pick_device_tracking_policy(conn)
    tracking_policy = policy_info.get("selected_policy")
    planned = build_ise_commands(
        payload,
        interface_data,
        tracking_policy,
        bootstrap_commands=policy_info.get("bootstrap_commands", []),
    )
    commands = planned["commands"]

    output = conn.send_config_set(commands)
    save_output = conn.save_config()

    return {
        "configured": True,
        "interface": interface,
        "vlan": planned.get("access_vlan"),
        "profile": planned.get("profile"),
        "storm_level": planned.get("storm_level"),
        "tracking_policy": tracking_policy,
        "tracking_policy_source": policy_info.get("source"),
        "tracking_policy_bootstrap_required": policy_info.get("bootstrap_required", False),
        "commands": commands,
        "device_response": output,
        "save_response": save_output,
    }
