"""
SDA Fabric Edge Validation.
"""

import logging

logger = logging.getLogger(__name__)


def validate_fabric_edge(
    dnac_client,
    device_ip,
):
    """
    Validate device is SDA Fabric Edge.
    """

    logger.info(
        "Validating SDA Fabric Edge device: %s",
        device_ip,
    )

    result = dnac_client.get_fabric_edge_device(
        device_ip,
    )

    role = str(
        result.get(
            "roles",
            "",
        )
    ).upper()

    if role != "EDGENODE":
        raise Exception(
            f"Device {device_ip} is not an SDA Edge Node"
        )

    return result