"""
Workflow routing logic.
Decides SDA workflow vs Legacy workflow.
"""


from naac_vlan_provisioning.services.sda_detector import is_sda_device

def determine_workflow(conn):


    if is_sda_device(conn):

        return "SDA"


    return "LEGACY"

 
 