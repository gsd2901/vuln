"""ServiceNow workflow helpers for post-provision task updates."""

from dataclasses import dataclass

import requests
from django.conf import settings
import logging

logger = logging.getLogger(__name__)


class ServiceNowConfigError(Exception):
    """Invalid or missing ServiceNow configuration."""


class ServiceNowRequestError(Exception):
    """Error returned by ServiceNow API."""


@dataclass
class ServiceNowConfig:
    instance_url: str
    username: str = ""
    password: str = ""
    token: str = ""
    verify_ssl: bool = True
    timeout: int = 30


class ServiceNowWorkflowClient:
    """Small ServiceNow API wrapper for post-provision updates."""

    def __init__(self, config: ServiceNowConfig):
        self.config = config
        self.session = requests.Session()
        self.session.verify = config.verify_ssl

        if config.token:
            self.session.headers.update({"Authorization": f"Bearer {config.token}"})
        elif config.username and config.password:
            self.session.auth = (config.username, config.password)
        else:
            raise ServiceNowConfigError("ServiceNow auth is not configured. Set token or username/password.")

    @classmethod
    def from_plugin_settings(cls):
        plugin_cfg = settings.PLUGINS_CONFIG.get("naac_vlan_provisioning", {})
        sn_cfg = plugin_cfg.get("servicenow", {})
        instance_url = str(sn_cfg.get("instance_url", "")).strip()

        if not instance_url:
            raise ServiceNowConfigError("Missing ServiceNow instance_url in PLUGINS_CONFIG['naac_vlan_provisioning']['servicenow'].")

        config = ServiceNowConfig(
            instance_url=instance_url.rstrip("/"),
            username=str(sn_cfg.get("username", "")).strip(),
            password=str(sn_cfg.get("password", "")).strip(),
            token=str(sn_cfg.get("token", "")).strip(),
            verify_ssl=bool(sn_cfg.get("verify_ssl", True)),
            timeout=int(sn_cfg.get("timeout", 30)),
        )
        return cls(config)

    def update_change_notes(self, *, change_number: str, notes: str):
        if not change_number:
            raise ServiceNowRequestError("Missing change number for ServiceNow notes update.")
        url = f"{self.config.instance_url}/api/hclti/snaap_integration/change/notes/{change_number}"
        return self._request("POST", url, json={"notes": notes})

    def close_change(self, *, change_number: str,status: str, close_notes: str):
        if not change_number:
            raise ServiceNowRequestError("Missing change number for ServiceNow closure.")
        url = f"{self.config.instance_url}/api/hclti/snaap_integration/task_closure"
        payload = {"change_number": change_number, "status": status, "close_notes": close_notes}
        logger.debug("Sending ServiceNow closure payload: %s", payload)
        return self._request("PUT", url, json=payload)

    def _request(self, method: str, url: str, **kwargs):
        try:
            response = self.session.request(
                method=method,
                url=url,
                headers={"Accept": "application/json"},
                timeout=self.config.timeout,
                **kwargs,
            )
        except requests.RequestException as exc:
            raise ServiceNowRequestError(f"ServiceNow request error: {exc}") from exc

        if response.status_code < 200 or response.status_code >= 300:
            raise ServiceNowRequestError(
                f"ServiceNow API request failed ({response.status_code}): {response.text[:500]}"
            )

        try:
            return response.json()
        except ValueError:
            return {"raw": response.text}


def _first_non_empty(*values):
    for value in values:
        if value not in (None, ""):
            return str(value)
    return ""


def _resolve_change_number(payload: dict):
    task = payload.get("task", {}) if isinstance(payload, dict) else {}
    change = payload.get("change", {}) if isinstance(payload, dict) else {}

    change_value = ""
    if isinstance(change, dict):
        change_value = _first_non_empty(
            change.get("number"),
            change.get("id"),
            change.get("change_number"),
        )

    if isinstance(task, dict):
        return _first_non_empty(
            change_value,
            task.get("id"),
            task.get("number"),
            task.get("change_number"),
            task.get("snaap_task_id"),
        )
    return _first_non_empty(change_value, payload.get("change_number"))


def _build_change_notes(execution: dict):
    """Build SNOW work notes based on execution result."""

    if not isinstance(execution, dict):
        return "VLAN provisioning update: No execution details available."

    status = execution.get("status")

    # ✅ Failure case
    if status == "failed":
        error = execution.get("error", "Unknown error")

        return (
            "VLAN provisioning FAILED.\n\n"
            f"Error:\n{error}"
        )

    # ✅ Success case
    commands = execution.get("commands")
    if not commands:
        return "VLAN configuration updated successfully."

    commands_block = "\n".join(str(command) for command in commands)

    return (
        "VLAN configuration updated successfully.\n\n"
        "Pushed config:\n"
        f"{commands_block}"
    )


def run_post_provision_snow_actions(payload: dict, execution: dict):
    """Update SNOW change notes and then close the related CR."""

    logger.info("Starting post-provision SNOW actions")

    result = {
        "status": "skipped",
        "work_notes_update": {"status": "skipped", "message": "Not attempted."},
        "change_close": {"status": "skipped", "message": "Not attempted."},
    }

    # Initialize client
    try:
        client = ServiceNowWorkflowClient.from_plugin_settings()
        logger.debug("ServiceNow client initialized successfully")
    except ServiceNowConfigError as exc:
        logger.error("Failed to initialize ServiceNow client: %s", exc)
        result["work_notes_update"] = {"status": "skipped", "message": str(exc)}
        result["change_close"] = {"status": "skipped", "message": str(exc)}
        return result

    # Prepare inputs
    change_number = _resolve_change_number(payload)
    work_notes = _build_change_notes(execution)
    close_notes = "Closed by SNAP integration"

    logger.debug("Resolved change number: %s", change_number)

    if not change_number:
        logger.warning("Missing change number, skipping SNOW actions")
        message = "Missing change number (task.id or change.number)."

        result["work_notes_update"] = {"status": "skipped", "message": message}
        result["change_close"] = {"status": "skipped", "message": message}
        return result

    # Step 1: Update work notes
    try:
        logger.info("Updating work notes for change: %s", change_number)
        client.update_change_notes(change_number=change_number, notes=work_notes)

        result["work_notes_update"] = {
            "status": "success",
            "change_number": change_number,
        }

        logger.info("Work notes updated successfully")
    except Exception as exc:
        logger.error("Failed to update work notes for %s: %s", change_number, exc)

        result["work_notes_update"] = {
            "status": "failed",
            "change_number": change_number,
            "message": str(exc),
        }

    
    # Step 2: Close / Cancel change (only if step 1 succeeded)
    if result["work_notes_update"].get("status") == "success":
        try:
            # ✅ Decide action based on execution result
            exec_status = (execution or {}).get("status")

            if exec_status == "failed":
                desired_status = "cancel"
                close_notes = "Change cancelled as provisioning failed."
            else:
                desired_status = "success"
                close_notes = "Change implemented successfully."

            logger.info(
                "Updating change %s with status '%s'",
                change_number,
                desired_status,
            )

            close_response = client.close_change(
                change_number=change_number,
                status=desired_status,        # ✅ NEW
                close_notes=close_notes,      # ✅ UPDATED dynamically
            )

            logger.debug("Close/cancel response: %s", close_response)

            result["change_close"] = {
                "status": close_response.get("status", "success"),  # unchanged fallback
                "change_number": change_number,
                "response": close_response,
            }

            logger.info("Change %s operation completed", desired_status)

        except Exception as exc:
            logger.error("Failed to update change %s: %s", change_number, exc)

            result["change_close"] = {
                "status": "failed",
                "change_number": change_number,
                "message": str(exc),
            }
    else:
        logger.warning(
            "Skipping change close because work notes update failed for %s",
            change_number,
        )

        result["change_close"] = {
            "status": "skipped",
            "change_number": change_number,
            "message": "Skipped because work note update failed.",
        }

    # Final status evaluation (unchanged logic)
    statuses = {
        result["work_notes_update"].get("status"),
        result["change_close"].get("status"),
    }

    logger.debug("Final step statuses: %s", statuses)

    if "failed" in statuses:
        result["status"] = "failed"
    elif "success" in statuses:
        result["status"] = "success"
    else:
        result["status"] = "skipped"

    logger.info("Completed SNOW actions with final status: %s", result["status"])

    return result
