"""

SDA Interface Status Validation.

"""


import logging


logger = logging.getLogger(__name__)




def validate_interface_status(

    dnac_client,

    interface_id,

):

    """

    Validate interface status.

    """


    result = dnac_client.get_interface_details(

        interface_id

    )


    interface = result.get(

        "response",

        {}

    )


    status = str(

        interface.get(

            "status",

            ""

        )

    ).lower()


    allowed_status = {

        "up",

        "down",

        "admin down",

    }


    if status and status not in allowed_status:

        raise Exception(

            f"Unsupported interface status: {status}"

        )


    return interface
 