"""

SDA VLAN Execution Workflow.

"""


import logging


from naac_vlan_provisioning.services.sda_inventory import (

    validate_device_inventory,

)


from naac_vlan_provisioning.services.sda_fabric_validation import (

    validate_fabric_edge,

)


from naac_vlan_provisioning.services.sda_port_assignment import (

    get_current_assignment,

    assign_port,

    update_port,

    delete_port,

)


from naac_vlan_provisioning.services.sda_interface_validation import (

    validate_interface,

)


from naac_vlan_provisioning.services.sda_neighbor_validation import (

    validate_non_uplink_port,

)


from naac_vlan_provisioning.services.sda_interface_status_validation import (

    validate_interface_status,

)


from naac_vlan_provisioning.services.sda_pool_validation import (

    validate_virtual_network,

    validate_ip_pool,

)


from naac_vlan_provisioning.services.sda_task_poller import (

    poll_task_status,

)


from naac_vlan_provisioning.services.sda_post_validation import (

    validate_enable_assignment,

    validate_disable_assignment,

)


from naac_vlan_provisioning.services.rollback_handler import (

    rollback_assignment,

    validate_rollback,

)


logger = logging.getLogger(__name__)




def run_sda_vlan_configuration(

    payload,

    dnac_client,

):

    """

    SDA VLAN workflow.


    Currently implemented:

    - Inventory validation

    - Fabric edge validation

    - Current assignment validation

    - Interface validation

    - Neighbor validation

    - Interface status validation


    Pending clarification:

    - VN mapping

    - Data Pool mapping

    - SGT mapping

    - Authentication template mapping

    """


    logger.info(

        "Starting SDA VLAN workflow"

    )


    device = payload.get(

        "device",

        {},

    )


    port = payload.get(

        "port",

        {},

    )


    ip_address = device.get(

        "ip",

    )


    interface_name = port.get(

        "interface",

    )


    mode = str(

        port.get(

            "mode",

            "",

        )

    ).lower()


    # --------------------------------------------------

    # Step 1

    # Inventory Validation

    # --------------------------------------------------


    inventory_device = (

        validate_device_inventory(

            dnac_client,

            ip_address=ip_address,

        )

    )


    device_id = inventory_device.get(

        "device_id"

    )


    # --------------------------------------------------

    # Step 2

    # Fabric Edge Validation

    # --------------------------------------------------


    validate_fabric_edge(

        dnac_client,

        ip_address,

    )


    # --------------------------------------------------

    # Step 3

    # Current Assignment Check

    # --------------------------------------------------


    current_assignment = (

        get_current_assignment(

            dnac_client,

            device_id,

            interface_name,

        )

    )


    # --------------------------------------------------

    # Step 4

    # Interface Validation

    # --------------------------------------------------


    interface_data = (

        validate_interface(

            dnac_client,

            device_id,

            interface_name,

        )

    )


    interface_id = (

        interface_data.get(

            "interface_id"

        )

    )


    # --------------------------------------------------

    # Step 5

    # Neighbor Validation

    # --------------------------------------------------


    validate_non_uplink_port(

        dnac_client,

        device_id,

        interface_name,

    )
    # logger.warning(
    #     "Skipping neighbor validation temporarily"
    # )


    # --------------------------------------------------

    # Step 6

    # Interface Status Validation

    # --------------------------------------------------


    validate_interface_status(

        dnac_client,

        interface_id,

    )


    # --------------------------------------------------

    # Step 7

    # VN Validation

    # --------------------------------------------------

    #

    # TODO:

    # Confirm final payload source for:

    #   virtual network

    #

    # validate_virtual_network(...)

    #

    # --------------------------------------------------


    # --------------------------------------------------

    # Step 8

    # IP Pool Validation

    # --------------------------------------------------

    #

    # TODO:

    # Confirm final payload source for:

    #   data pool

    #   voice pool

    #

    # validate_ip_pool(...)

    #

    # --------------------------------------------------


    logger.info(

        "SDA pre-check validations completed"

    )


    # --------------------------------------------------

    # Step 9+

    # SDA Provisioning

    # --------------------------------------------------

    #

    # TODO:

    # Enable

    # Update

    # Disable

    #

    # assign_port(...)

    # update_port(...)

    # delete_port(...)

    #

    # poll_task_status(...)

    #

    # validate_enable_assignment(...)

    # validate_disable_assignment(...)

    #

    # rollback_assignment(...)

    # validate_rollback(...)

    #

    # --------------------------------------------------


    return {

        "workflow_type": "SDA",

        "status": "pre_checks_completed",

        "device_id": device_id,

        "interface_id": interface_id,

        "current_assignment": current_assignment,

        "next_step": "sda_port_assignment_pending",

    }
 