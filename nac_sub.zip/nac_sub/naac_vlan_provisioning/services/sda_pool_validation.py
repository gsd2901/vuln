"""

SDA VN Validation.

"""


import logging


logger = logging.getLogger(__name__)




def validate_virtual_network(

    dnac_client,

    virtual_network_name,

):

    """

    Validate Virtual Network exists.

    """


    result = dnac_client.get_virtual_networks()


    virtual_networks = result.get(

        "response",

        [],

    )


    for vn in virtual_networks:


        vn_name = (

            vn.get("virtualNetworkName")

            or vn.get("name")

            or ""

        )


        if vn_name.lower() == virtual_network_name.lower():

            return vn


    raise Exception(

        f"Virtual Network '{virtual_network_name}' not found"

    )

def validate_ip_pool(

    dnac_client,

    pool_name,

):

    """

    Validate Data Pool / IP Pool exists.

    """


    result = dnac_client.get_ip_pools()


    pools = result.get(

        "response",

        [],

    )


    for pool in pools:


        current_pool = (

            pool.get("ipPoolName")

            or pool.get("name")

            or ""

        )


        if current_pool.lower() == pool_name.lower():

            return pool


    raise Exception(

        f"IP Pool '{pool_name}' not found"

    )
  