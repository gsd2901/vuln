# VLAN Validation

Skeleton for an API-driven Nautobot plugin that will validate incoming payloads,
device type eligibility, and VLAN access behavior.

## Planned API Surface

- `validate payload`
- `validate device type`
- `validate vlan access`

## Validation Flow

### 1. Validate Payload

Entry point for request shape, required fields, and basic input sanity checks.

### 2. Validate Device Type

Checks whether the target device type is eligible for the requested VLAN operation.

### 3. Validate VLAN Access

This step branches based on port state:

- If the port is enabled:
  - health check
  - interface validation
  - vlan check
- If the port is disabled:
  - health check
  - interface validation
  - response is generated from the resulting condition evaluation

## Suggested Internal Layout

- `api/` for request/response handling
- `services/` for orchestration and validation steps
- `tests/` for unit and API coverage

This repository now includes the legacy pre-validation check scripts as reusable
modules. The flow is still intentionally lightweight so you can replace pieces
incrementally without changing the high-level architecture.
