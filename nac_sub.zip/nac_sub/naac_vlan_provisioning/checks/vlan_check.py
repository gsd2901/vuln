import logging
import re


def check_vlan(conn, interface, vlan):
    logging.info(f"Checking VLAN {vlan} on interface {interface}")

    try:
        vlan_str = str(vlan)

        # ---------------------------
        # 1. Check VLAN exists on device
        # ---------------------------
        vlan_output = conn.send_command("show vlan brief")

        # Use regex to match exact VLAN ID at line start
        vlan_pattern = rf"^{vlan_str}\s"
        if not re.search(vlan_pattern, vlan_output, re.MULTILINE):
            logging.error(f"VLAN {vlan} not present on device")
            return False, f"VLAN {vlan} not present on device"

        logging.info(f"VLAN {vlan} exists on device")

        # ---------------------------
        # 2. Check interface config
        # ---------------------------
        int_output = conn.send_command(f"show running-config interface {interface}")

        int_output_lower = int_output.lower()

        # Access mode check
        if f"access vlan {vlan}" in int_output_lower:
            logging.info("VLAN already configured on interface")
            return True, "VLAN already present"

        # Trunk mode check (allowed VLANs)
        if "switchport mode trunk" in int_output_lower:
            if vlan_str in int_output:
                logging.info("VLAN already allowed on trunk interface")
                return True, "VLAN already present (trunk)"

        logging.info("VLAN needs to be configured")
        return True, "VLAN needs to be configured"

    except Exception as e:
        logging.error(f"VLAN check error: {str(e)}")
        return False, str(e)