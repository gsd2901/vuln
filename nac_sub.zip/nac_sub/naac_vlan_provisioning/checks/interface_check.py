import logging


def normalize_interface(interface: str) -> str:
    """Normalize long interface names to short form (Cisco style)."""
    mapping = {
        "gigabitethernet": "gi",
        "fastethernet": "fa",
        "tengigabitethernet": "te",
        "ethernet": "eth",
    }

    interface = interface.strip()
    interface_lower = interface.lower()

    for long, short in mapping.items():
        if interface_lower.startswith(long):
            return interface_lower.replace(long, short)

    return interface_lower


def _parse_interface_status_line(line: str):
    """Parse show interface status line and return state/vlan/speed when possible."""
    tokens = line.split()
    if len(tokens) < 3:
        return None, None, None

    known_states = {
        "connected",
        "notconnect",
        "disabled",
        "err-disabled",
        "inactive",
        "monitoring",
        "sfpabsent",
    }

    state_index = None
    for idx, token in enumerate(tokens[1:], start=1):
        if token.lower() in known_states:
            state_index = idx
            break

    if state_index is None:
        return None, None, None

    state = tokens[state_index].lower()
    vlan = tokens[state_index + 1].lower() if len(tokens) > state_index + 1 else None
    speed = tokens[state_index + 3] if len(tokens) > state_index + 3 else None
    return state, vlan, speed


def check_interface(conn, interface):
    logging.info(f"Checking interface: {interface}")

    try:
        interface = interface.strip()
        normalized_interface = normalize_interface(interface)

        # ---------------------------
        # 1. Check if interface exists
        # ---------------------------
        output = conn.send_command(f"show interface {interface}")
        output_lower = output.lower()

        if (
            not output
            or "invalid input" in output_lower
            or "not found" in output_lower
            or "% invalid" in output_lower
        ):
            logging.error("Interface not present -> STOP")
            return False, "Interface not present", None

        logging.info("Interface exists")

        # ---------------------------
        # 2. Check trunk mode (FULL output parsing)
        # ---------------------------
        trunk_output = conn.send_command("show interfaces trunk")
        is_trunk = normalized_interface in trunk_output.lower()
        if is_trunk:
            logging.info("Interface is trunk")

        # ---------------------------
        # 3. Parse interface status (NO include, full parsing)
        # ---------------------------
        full_output = conn.send_command("show interface status")

        status = "unknown"
        mode = "trunk" if is_trunk else "access"
        speed = None

        for line in full_output.splitlines():
            parts = line.split()

            if not parts:
                continue

            port = parts[0].lower()

            # Exact match with normalized interface
            if port == normalized_interface:
                state, vlan, speed = _parse_interface_status_line(line)
                if state:
                    if state == "connected":
                        status = "up"
                    elif state == "notconnect":
                        status = "down"
                    elif state == "disabled":
                        status = "admin_down"
                    else:
                        status = "unknown"

                if vlan:
                    if vlan == "routed":
                        mode = "l3"
                    elif not is_trunk:
                        mode = "access"

                break

        logging.info(f"Interface status: {status}, mode: {mode}, speed: {speed}")

        return True, f"Interface is {status}", {
            "mode": mode,
            "status": status,
            "speed": speed,
        }

    except Exception as e:
        logging.error(f"Interface check error: {str(e)}")
        return False, str(e), None
