import logging
from naac_vlan_provisioning.services.ise_template import validate_port_spec


def check_payload(data):
    logging.info("Checking payload")

    # ---------------------------
    # 1. Root Validation
    # ---------------------------
    if not isinstance(data, dict):
        return False, "Payload must be a JSON object"

    required_root_keys = ["task", "device", "port"]
    for key in required_root_keys:
        if key not in data:
            return False, f"Missing required field: {key}"

    # ---------------------------
    # 2. Task Validation
    # ---------------------------
    task = data.get("task")
    if not isinstance(task, dict):
        return False, "task must be an object"

    if not task.get("id"):
        return False, "Missing task.id"

    # Optional fields (no strict validation needed)
    # task.type, task.requested_by, task.source

    # ---------------------------
    # 3. Device Validation
    # ---------------------------
    device = data.get("device")
    if not isinstance(device, dict):
        return False, "device must be an object"

    ip = device.get("ip")
    if not ip or not isinstance(ip, str):
        return False, "Missing or invalid device.ip"

    # ---------------------------
    # 4. Port Validation
    # ---------------------------
    port = data.get("port")
    if not isinstance(port, dict):
        return False, "port must be an object"

    required_port_fields = ["interface", "mode"]
    for field in required_port_fields:
        if field not in port:
            return False, f"Missing port.{field}"

    # Interface validation
    interface = port.get("interface")
    if not isinstance(interface, str) or not interface.strip():
        return False, "port.interface must be a non-empty string"

    # Mode validation
    mode = port.get("mode")
    if not isinstance(mode, str) or mode.lower() not in ["enabled", "disabled"]:
        return False, "port.mode must be enabled or disabled"

    # ISE profile + VLAN combination validation
    try:
        validate_port_spec(data)
    except Exception as e:
        return False, str(e)

    # ---------------------------
    # 5. Change Window (Optional)
    # ---------------------------
    change = data.get("change")
    if change:
        if not isinstance(change, dict):
            return False, "change must be an object"

        # Optional validation
        # You can enforce datetime format later if needed

    return True, "Payload validation successful"
