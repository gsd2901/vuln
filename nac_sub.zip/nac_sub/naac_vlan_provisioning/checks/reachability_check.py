import logging
from netmiko import ConnectHandler


def check_reachability(ip_address, username, password):
    """
    Establish SSH connection to device.

    Returns:
        (True, connection) on success
        (False, error_message) on failure
    """
    logging.info(f"Checking device reachability: {ip_address}")

    if not ip_address:
        return False, "Missing IP address"

    if not username or not password:
        return False, "Missing device credentials"

    try:
        conn = ConnectHandler(
            device_type="cisco_ios",
            host=ip_address,
            username=username,
            password=password,
            timeout=10,
            banner_timeout=5,
            auth_timeout=10,
        )

        logging.info(f"SSH connection established to {ip_address}")
        return True, conn

    except Exception as e:
        logging.error(f"SSH connection failed for {ip_address}: {str(e)}")
        return False, "Device unreachable"