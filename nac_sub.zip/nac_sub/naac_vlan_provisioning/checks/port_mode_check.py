import logging

def check_port_mode(data):
    logging.info("Checking port mode")

    port = data.get("port", {})
    mode = port.get("mode", "")

    if not isinstance(mode, str):
        return False, "Invalid port mode type", None

    mode = mode.lower()

    if mode not in ["enabled", "disabled"]:
        return False, f"Invalid port mode: {mode}", None

    return True, "Port mode valid", mode