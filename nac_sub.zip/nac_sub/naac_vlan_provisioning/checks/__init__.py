"""Legacy pre-validation check scripts used by naac_vlan_provisioning."""
