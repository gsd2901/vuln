import logging
from nautobot.ipam.models import IPAddress


def check_device_role(ci):
    logging.info("Checking device role")

    ip = ci.get("ip")

    if not ip:
        return False, "Missing device IP"

    # ---------------------------
    # 1. Fetch IP object
    # ---------------------------
    ip_obj = IPAddress.objects.filter(host=ip).first()

    if not ip_obj:
        return False, "Device unavailable"

    # ---------------------------
    # 2. Resolve Device
    # ---------------------------
    device = None

    if ip_obj.interfaces.exists():
        device = ip_obj.interfaces.first().device
    elif ip_obj.primary_ip4_for.exists():
        device = ip_obj.primary_ip4_for.first()

    if not device:
        return False, f"No device found for IP {ip}"

    # ---------------------------
    # 3. Validate role
    # ---------------------------
    role = device.role.name.lower() if device.role else ""

    if role != "access":
        return False, f"Unsupported device role: {role}"

    return True, "Device role valid"
