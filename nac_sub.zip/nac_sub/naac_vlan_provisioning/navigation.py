"""App navigation menu items."""

from nautobot.apps.ui import NavMenuGroup, NavMenuItem, NavMenuTab


menu_items = (
    NavMenuTab(
        name="Extensibility",
        weight=1000,
        groups=(
            NavMenuGroup(
                name="NAAC VLAN Provisioning",
                weight=300,
                items=(
                    NavMenuItem(
                        link="admin:naac_vlan_provisioning_apirequestauditlog_task_groups",
                        name="API Logs",
                        permissions=["naac_vlan_provisioning.view_apirequestauditlog"],
                        # icon="mdi-file-document",  # ✅ ONLY place for icon
                    ),
                ),
            ),
        ),
    ),
)