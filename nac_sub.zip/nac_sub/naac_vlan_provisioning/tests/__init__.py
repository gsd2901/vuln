"""Tests for naac_vlan_provisioning."""
