from unittest.mock import MagicMock, patch

from naac_vlan_provisioning.services.servicenow_workflow import (
    ServiceNowConfig,
    ServiceNowRequestError,
    ServiceNowWorkflowClient,
    run_post_provision_snow_actions,
)


def test_update_change_notes_posts_to_new_endpoint():
    client = ServiceNowWorkflowClient(
        ServiceNowConfig(instance_url="https://snow.example.com", token="token-value")
    )

    notes = "VLAN configuration updated successfully.\n\nPushed config:\ninterface GigabitEthernet1/0/2\nshutdown"

    with patch.object(client, "_request", return_value={"ok": True}) as request_mock:
        response = client.update_change_notes(
            change_number="CHG0073636",
            notes=notes,
        )

    assert response == {"ok": True}
    request_mock.assert_called_once_with(
        "POST",
        "https://snow.example.com/api/hclti/snaap_integration/change/notes/CHG0073636",
        json={"notes": notes},
    )


def test_close_change_calls_closure_endpoint():
    client = ServiceNowWorkflowClient(
        ServiceNowConfig(instance_url="https://snow.example.com", token="token-value")
    )

    with patch.object(client, "_request", return_value={"status": "Success"}) as request_mock:
        response = client.close_change(
            change_number="CHG0073636",
            close_notes="Closed by SNAP integration",
        )

    assert response == {"status": "Success"}
    request_mock.assert_called_once_with(
        "PUT",
        "https://snow.example.com/api/hclti/snaap_integration/task_closure",
        json={
            "change_number": "CHG0073636",
            "close_notes": "Closed by SNAP integration",
        },
    )


def test_update_change_notes_requires_change_number():
    client = ServiceNowWorkflowClient(
        ServiceNowConfig(instance_url="https://snow.example.com", token="token-value")
    )

    with patch.object(client, "_request") as request_mock:
        try:
            client.update_change_notes(change_number="", notes="note")
        except ServiceNowRequestError as exc:
            assert str(exc) == "Missing change number for ServiceNow notes update."
        else:
            raise AssertionError("Expected ServiceNowRequestError")

    request_mock.assert_not_called()


def test_close_change_requires_change_number():
    client = ServiceNowWorkflowClient(
        ServiceNowConfig(instance_url="https://snow.example.com", token="token-value")
    )

    with patch.object(client, "_request") as request_mock:
        try:
            client.close_change(change_number="", close_notes="Closed by SNAP integration")
        except ServiceNowRequestError as exc:
            assert str(exc) == "Missing change number for ServiceNow closure."
        else:
            raise AssertionError("Expected ServiceNowRequestError")

    request_mock.assert_not_called()


@patch("naac_vlan_provisioning.services.servicenow_workflow.ServiceNowWorkflowClient.from_plugin_settings")
def test_run_post_provision_snow_actions_updates_notes_then_closes_change(from_plugin_settings_mock):
    client = MagicMock()
    from_plugin_settings_mock.return_value = client

    payload = {
        "task": {
            "id": "CHG0073636",
            "type": "vlan_access_enable",
            "requested_by": "akash",
            "source": "SNOW",
        },
        "device": {"ip": "10.156.181.101"},
        "port": {
            "interface": "GigabitEthernet1/0/2",
            "mode": "disabled",
            "profile": "user_data",
            "description": "Reception Data",
            "access_vlan": 505,
        },
        "change": {
            "window_start": "2026-01-01T00:00:00",
            "window_end": "2026-01-01T00:30:00",
        },
    }

    execution = {
        "configured": True,
        "commands": [
            "interface GigabitEthernet1/0/2",
            "shutdown",
        ],
    }

    result = run_post_provision_snow_actions(payload, execution=execution)

    assert result == {
        "status": "success",
        "work_notes_update": {
            "status": "success",
            "change_number": "CHG0073636",
        },
        "change_close": {
            "status": "success",
            "change_number": "CHG0073636",
        },
    }
    client.update_change_notes.assert_called_once_with(
        change_number="CHG0073636",
        notes="VLAN configuration updated successfully.\n\nPushed config:\ninterface GigabitEthernet1/0/2\nshutdown",
    )
    client.close_change.assert_called_once_with(
        change_number="CHG0073636",
        close_notes="Closed by SNAP integration",
    )


@patch("naac_vlan_provisioning.services.servicenow_workflow.ServiceNowWorkflowClient.from_plugin_settings")
def test_run_post_provision_snow_actions_uses_default_note_without_commands(from_plugin_settings_mock):
    client = MagicMock()
    from_plugin_settings_mock.return_value = client

    result = run_post_provision_snow_actions({"task": {"id": "CHG0073636"}}, execution={})

    assert result == {
        "status": "success",
        "work_notes_update": {
            "status": "success",
            "change_number": "CHG0073636",
        },
        "change_close": {
            "status": "success",
            "change_number": "CHG0073636",
        },
    }
    client.update_change_notes.assert_called_once_with(
        change_number="CHG0073636",
        notes="VLAN configuration updated successfully.",
    )
    client.close_change.assert_called_once_with(
        change_number="CHG0073636",
        close_notes="Closed by SNAP integration",
    )


@patch("naac_vlan_provisioning.services.servicenow_workflow.ServiceNowWorkflowClient.from_plugin_settings")
def test_run_post_provision_snow_actions_skips_close_when_notes_fail(from_plugin_settings_mock):
    client = MagicMock()
    client.update_change_notes.side_effect = Exception("notes failed")
    from_plugin_settings_mock.return_value = client

    result = run_post_provision_snow_actions({"task": {"id": "CHG0073636"}}, execution={})

    assert result == {
        "status": "failed",
        "work_notes_update": {
            "status": "failed",
            "change_number": "CHG0073636",
            "message": "notes failed",
        },
        "change_close": {
            "status": "skipped",
            "change_number": "CHG0073636",
            "message": "Skipped because work note update failed.",
        },
    }
    client.close_change.assert_not_called()


@patch("naac_vlan_provisioning.services.servicenow_workflow.ServiceNowWorkflowClient.from_plugin_settings")
def test_run_post_provision_snow_actions_reports_close_failure(from_plugin_settings_mock):
    client = MagicMock()
    client.close_change.side_effect = Exception("close failed")
    from_plugin_settings_mock.return_value = client

    result = run_post_provision_snow_actions({"task": {"id": "CHG0073636"}}, execution={})

    assert result == {
        "status": "failed",
        "work_notes_update": {
            "status": "success",
            "change_number": "CHG0073636",
        },
        "change_close": {
            "status": "failed",
            "change_number": "CHG0073636",
            "message": "close failed",
        },
    }


@patch("naac_vlan_provisioning.services.servicenow_workflow.ServiceNowWorkflowClient.from_plugin_settings")
def test_run_post_provision_snow_actions_skips_when_change_number_missing(from_plugin_settings_mock):
    from_plugin_settings_mock.return_value = MagicMock()

    result = run_post_provision_snow_actions({"task": {}}, execution={})

    assert result == {
        "status": "skipped",
        "work_notes_update": {
            "status": "skipped",
            "message": "Missing change number (task.id or change.number).",
        },
        "change_close": {
            "status": "skipped",
            "message": "Missing change number (task.id or change.number).",
        },
    }
