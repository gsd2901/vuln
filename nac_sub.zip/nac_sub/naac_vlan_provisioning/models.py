"""Database models for naac_vlan_provisioning."""

from django.db import models


class APIRequestAuditLog(models.Model):
    """Stores request/response audit trail for plugin API calls."""

    task_id = models.CharField(max_length=128, db_index=True, default="UNASSIGNED")
    endpoint = models.CharField(max_length=255)
    method = models.CharField(max_length=16)
    payload = models.JSONField(default=dict, blank=True)
    response = models.JSONField(default=dict, blank=True)
    success = models.BooleanField(default=False)
    status_code = models.PositiveIntegerField(default=500)
    error_message = models.TextField(blank=True, default="")
    created = models.DateTimeField(auto_now_add=True, db_index=True)

    class Meta:
        ordering = ["-created"]
        indexes = [
            models.Index(fields=["task_id", "-created"]),
            models.Index(fields=["endpoint", "-created"]),
        ]

    def __str__(self):
        return f"{self.task_id} {self.method} {self.endpoint} ({self.status_code})"
