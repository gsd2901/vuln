from nautobot.apps import NautobotAppConfig

__version__ = "0.1.0"


class NaacVlanProvisioningConfig(NautobotAppConfig):
    """Plugin entry point for the naac_vlan_provisioning app."""

    name = "naac_vlan_provisioning"
    verbose_name = "NAAC VLAN Provisioning"
    version = __version__
    author = "TODO"
    author_email = "TODO"
    secret_group_name = "SSH Group"
    description = "API-oriented VLAN provisioning plugin skeleton."
    base_url = "naac-vlan-provisioning"
    required_settings = []
    default_settings = {}
    caching_config = {}

    def ready(self):
        """Called when the plugin is loaded."""
        super().ready()


config = NaacVlanProvisioningConfig
