"""API entry points for naac_vlan_provisioning."""

from django.db.models import Count, Max
from rest_framework import status
from rest_framework.authentication import SessionAuthentication
from rest_framework.decorators import api_view, authentication_classes, permission_classes
from rest_framework.permissions import AllowAny
from rest_framework.response import Response

from naac_vlan_provisioning.api.serializers import (
    ValidateDeviceTypeSerializer,
    ValidatePayloadSerializer,
    ValidateVlanAccessSerializer,
)
from naac_vlan_provisioning.models import APIRequestAuditLog
from naac_vlan_provisioning.services.request_audit import create_api_audit_log
from naac_vlan_provisioning.services.validation_orchestrator import (
    provision_vlan,
    validate_device_type,
    validate_payload,
    validate_vlan_access,
)


def build_response(success: bool, step: str, data=None, errors=None, http_status=status.HTTP_200_OK):
    """Standard API response builder."""
    return Response(
        {
            "success": success,
            "step": step,
            # "data": data if success else None,
            "data": data,
            "errors": errors if not success else None,
        },
        status=http_status,
    )


def _servicenow_failure_details(servicenow_result):
    """Return failed ServiceNow post-action messages for compact responses."""
    failures = []
    action_labels = {
        "work_notes_update": "work_notes",
        "change_close": "change_close",
    }

    for key, action in action_labels.items():
        action_result = servicenow_result.get(key, {})
        if action_result.get("status") != "failed":
            continue

        failures.append(
            {
                "action": action,
                "table": action_result.get("table"),
                "number": action_result.get("change_number") or action_result.get("task_number"),
                "message": action_result.get("message", "ServiceNow post-action failed"),
            }
        )

    return failures


def _build_and_audit_response(request, step, payload, success, data=None, errors=None, http_status=status.HTTP_200_OK):
    """Build API response and persist request/response audit row."""
    response = build_response(
        success=success,
        step=step,
        data=data,
        errors=errors,
        http_status=http_status,
    )
    create_api_audit_log(
        request=request,
        endpoint_name=step,
        payload=payload,
        response_data=response.data,
        success=success,
        status_code=response.status_code,
        error_message=errors if not success else "",
    )
    return response


@api_view(["POST"])
@authentication_classes([SessionAuthentication])
@permission_classes([AllowAny])
def validate_payload_view(request):
    """Validate incoming payload structure."""
    payload = request.data if isinstance(request.data, dict) else {}
    serializer = ValidatePayloadSerializer(data=request.data)

    if not serializer.is_valid():
        return _build_and_audit_response(
            request=request,
            success=False,
            step="validate_payload",
            payload=payload,
            errors=serializer.errors,
            http_status=status.HTTP_400_BAD_REQUEST,
        )

    try:
        result = validate_payload(serializer.validated_data)
        return _build_and_audit_response(
            request=request,
            success=True,
            step="validate_payload",
            payload=payload,
            data=result,
        )
    except Exception as e:
        return _build_and_audit_response(
            request=request,
            success=False,
            step="validate_payload",
            payload=payload,
            errors=str(e),
            http_status=status.HTTP_400_BAD_REQUEST,
        )


@api_view(["POST"])
@authentication_classes([SessionAuthentication])
@permission_classes([AllowAny])
def validate_device_type_view(request):
    """Validate device role/type."""
    payload = request.data if isinstance(request.data, dict) else {}
    serializer = ValidateDeviceTypeSerializer(data=request.data)

    if not serializer.is_valid():
        return _build_and_audit_response(
            request=request,
            success=False,
            step="validate_device_type",
            payload=payload,
            errors=serializer.errors,
            http_status=status.HTTP_400_BAD_REQUEST,
        )

    try:
        result = validate_device_type(serializer.validated_data)
        return _build_and_audit_response(
            request=request,
            success=True,
            step="validate_device_type",
            payload=payload,
            data=result,
        )
    except Exception as e:
        return _build_and_audit_response(
            request=request,
            success=False,
            step="validate_device_type",
            payload=payload,
            errors=str(e),
            http_status=status.HTTP_400_BAD_REQUEST,
        )


@api_view(["POST"])
@authentication_classes([SessionAuthentication])
@permission_classes([AllowAny])
def validate_vlan_access_view(request):
    """Full VLAN access validation pipeline."""
    payload = request.data if isinstance(request.data, dict) else {}
    serializer = ValidateVlanAccessSerializer(data=request.data)

    if not serializer.is_valid():
        return _build_and_audit_response(
            request=request,
            success=False,
            step="validate_vlan_access",
            payload=payload,
            errors=serializer.errors,
            http_status=status.HTTP_400_BAD_REQUEST,
        )

    try:
        result = validate_vlan_access(serializer.validated_data)
        
        decision = result.get("decision")
        errors = None

        if decision == "change_required":
            http_status = status.HTTP_200_OK
            success = True
        else:
            http_status = status.HTTP_400_BAD_REQUEST 
            success = False
            if result.get("reason"):
                errors = result["reason"]

        return _build_and_audit_response(
            request=request,
            success=success,
            step="validate_vlan_access",
            payload=payload,
            data=result,
            errors=errors,
            http_status=http_status,
        )
    except Exception as e:
        return _build_and_audit_response(
            request=request,
            success=False,
            step="validate_vlan_access",
            payload=payload,
            errors=str(e),
            http_status=status.HTTP_400_BAD_REQUEST,
        )


@api_view(["POST"])
@authentication_classes([SessionAuthentication])
@permission_classes([AllowAny])
def provision_vlan_view(request):
    """
    End-to-end VLAN provisioning flow:
    payload -> device type -> vlan access -> configure vlan.
    """
    payload = request.data if isinstance(request.data, dict) else {}
    serializer = ValidateVlanAccessSerializer(data=request.data)

    if not serializer.is_valid():
        return _build_and_audit_response(
            request=request,
            success=False,
            step="provision_vlan",
            payload=payload,
            errors=serializer.errors,
            http_status=status.HTTP_400_BAD_REQUEST,
        )

    try:
        result = provision_vlan(serializer.validated_data)
        verbose = str(request.query_params.get("verbose", "")).lower() == "true"

        if verbose:
            response_data = result
        else:
            execution = result.get("execution", {})
            servicenow_result = result.get("servicenow", {})
            snow_errors = _servicenow_failure_details(servicenow_result)
            response_data = {
                "message": result.get("message", "VLAN configured successfully"),
                "interface": execution.get("interface"),
                "vlan": execution.get("vlan"),
                "status": "configured" if execution.get("configured") else "not_configured",
                "snow_status": servicenow_result.get("status"),
            }
            if snow_errors:
                response_data["snow_error"] = "; ".join(error["message"] for error in snow_errors)
                response_data["snow_errors"] = snow_errors

        return _build_and_audit_response(
            request=request,
            success=True,
            step="provision_vlan",
            payload=payload,
            data=response_data,
        )
    except ValueError as e:
        return _build_and_audit_response(
            request=request,
            success=False,
            step="provision_vlan",
            payload=payload,
            errors=str(e),
            http_status=status.HTTP_400_BAD_REQUEST,
        )
    except Exception as e:
        return _build_and_audit_response(
            request=request,
            success=False,
            step="provision_vlan",
            payload=payload,
            errors=str(e),
            http_status=status.HTTP_400_BAD_REQUEST,
        )


@api_view(["GET"])
@authentication_classes([SessionAuthentication])
@permission_classes([AllowAny])
def task_request_summary_view(request):
    """
    Return task-level summary:
    - task_id
    - number of API requests under each task
    - last request time
    """
    summary_rows = (
        APIRequestAuditLog.objects.values("task_id")
        .annotate(request_count=Count("id"), last_request_at=Max("created"))
        .order_by("-last_request_at")
    )

    data = [
        {
            "task_id": row["task_id"],
            "request_count": row["request_count"],
            "last_request_at": row["last_request_at"].isoformat() if row["last_request_at"] else None,
        }
        for row in summary_rows
    ]

    return build_response(success=True, step="task_request_summary", data={"tasks": data})


@api_view(["GET"])
@authentication_classes([SessionAuthentication])
@permission_classes([AllowAny])
def task_request_detail_view(request, task_id):
    """
    Return drill-down list for one task id:
    - all API calls
    - request payload
    - response
    """
    logs = APIRequestAuditLog.objects.filter(task_id=task_id).order_by("-created")

    detail_rows = [
        {
            "id": log.id,
            "created": log.created.isoformat(),
            "endpoint": log.endpoint,
            "method": log.method,
            "status_code": log.status_code,
            "success": log.success,
            "payload": log.payload,
            "response": log.response,
            "error_message": log.error_message,
        }
        for log in logs
    ]

    return build_response(
        success=True,
        step="task_request_detail",
        data={
            "task_id": task_id,
            "request_count": logs.count(),
            "requests": detail_rows,
        },
    )

@api_view(["PATCH"])
@authentication_classes([SessionAuthentication])
@permission_classes([AllowAny])
def validate_patch(request):
    payload = request.data
    return Response(payload)


@api_view(["POST"])
@authentication_classes([SessionAuthentication])
@permission_classes([AllowAny])
def validate_post(request):
    payload = request.data
    return Response(payload)


@api_view(["PUT"])
@authentication_classes([SessionAuthentication])
@permission_classes([AllowAny])
def validate_put(request):
    payload = request.data
    return Response(payload)