"""Serializer-style request validators for naac_vlan_provisioning."""

from naac_vlan_provisioning.services.ise_template import validate_port_spec


class BaseValidationSerializer:
    """Minimal serializer-like validator."""

    required_fields = []

    def __init__(self, data):
        self.initial_data = data or {}
        self.validated_data = {}
        self.errors = {}

    def is_valid(self, raise_exception=False):
        self.errors = {}
        self.validated_data = {}

        for field in self.required_fields:
            value = self.initial_data.get(field)
            if value in (None, ""):
                self.errors[field] = "This field is required."
            else:
                self.validated_data[field] = value

        if self.errors:
            if raise_exception:
                raise ValueError(self.errors)
            return False

        self.validated_data = dict(self.initial_data)
        return True


# ---------------------------------------------------
# Payload Serializer (NEW STRUCTURE)
# ---------------------------------------------------

class ValidatePayloadSerializer(BaseValidationSerializer):
    """
    Validate new structured payload:
    {
        task,
        device,
        port,
        change (optional)
    }
    """

    required_fields = ["task", "device", "port"]

    def is_valid(self, raise_exception=False):
        self.errors = {}
        self.validated_data = {}

        task = self.initial_data.get("task")
        device = self.initial_data.get("device")
        port = self.initial_data.get("port")

        # ---------------------------
        # Task Validation
        # ---------------------------
        if not isinstance(task, dict):
            self.errors["task"] = "task must be an object."
        elif not task.get("id"):
            self.errors["task.id"] = "This field is required."

        # ---------------------------
        # Device Validation
        # ---------------------------
        if not isinstance(device, dict):
            self.errors["device"] = "device must be an object."
        elif not device.get("ip"):
            self.errors["device.ip"] = "This field is required."

        # ---------------------------
        # Port Validation
        # ---------------------------
        if not isinstance(port, dict):
            self.errors["port"] = "port must be an object."
        else:
            if not port.get("interface"):
                self.errors["port.interface"] = "This field is required."

            if not port.get("mode"):
                self.errors["port.mode"] = "This field is required."
            else:
                try:
                    validate_port_spec(self.initial_data)
                except Exception as e:
                    self.errors["port"] = str(e)

        if self.errors:
            if raise_exception:
                raise ValueError(self.errors)
            return False

        self.validated_data = dict(self.initial_data)
        return True


# ---------------------------------------------------
# Device Type Serializer
# ---------------------------------------------------

class ValidateDeviceTypeSerializer(BaseValidationSerializer):
    """Only device IP is required (role comes from Nautobot)."""

    required_fields = ["device"]

    def is_valid(self, raise_exception=False):
        self.errors = {}
        self.validated_data = {}

        device = self.initial_data.get("device")

        if not isinstance(device, dict):
            self.errors["device"] = "device must be an object."
        elif not device.get("ip"):
            self.errors["device.ip"] = "This field is required."

        if self.errors:
            if raise_exception:
                raise ValueError(self.errors)
            return False

        self.validated_data = dict(self.initial_data)
        return True


# ---------------------------------------------------
# VLAN Access Serializer
# ---------------------------------------------------

class ValidateVlanAccessSerializer(BaseValidationSerializer):
    """Validate full VLAN access payload."""

    required_fields = ["task", "device", "port"]

    def is_valid(self, raise_exception=False):
        # Reuse payload validation
        serializer = ValidatePayloadSerializer(self.initial_data)
        is_valid = serializer.is_valid(raise_exception=raise_exception)

        if not is_valid:
            self.errors = serializer.errors
            return False

        self.validated_data = serializer.validated_data
        return True
