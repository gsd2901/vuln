from django.urls import path
from naac_vlan_provisioning.api.views import (
    provision_vlan_view,
    task_request_detail_view,
    task_request_summary_view,
    validate_device_type_view,
    validate_payload_view,
    validate_vlan_access_view,
    validate_patch,
    validate_post,
    validate_put,
)

urlpatterns = [
    path("validate-payload/", validate_payload_view),
    path("validate-device-type/", validate_device_type_view),
    path("validate-vlan-access/", validate_vlan_access_view),
    path("provision-vlan/", provision_vlan_view),
    path("task-requests/summary/", task_request_summary_view),
    path("task-requests/<str:task_id>/", task_request_detail_view),
    path("validate-patch/", validate_patch),
    path("validate-post/", validate_post),
    path("validate-put/", validate_put),
]
