"""Admin registration for NAAC VLAN provisioning plugin models."""

import base64
import json

from urllib.parse import quote

from django.contrib import admin
from django.db.models import Count, Max
from django.shortcuts import redirect
from django.template.response import TemplateResponse
from django.urls import path, reverse
from django.utils.http import urlencode
from django.utils.html import format_html

from naac_vlan_provisioning.models import APIRequestAuditLog


@admin.register(APIRequestAuditLog)
class APIRequestAuditLogAdmin(admin.ModelAdmin):
    """Admin view for request/response audit logs."""

    change_form_template = "admin/naac_vlan_provisioning/apirequestauditlog/change_form.html"

    list_display = (
        "created",
        "task_id",
        "endpoint",
        "method",
        "status_code",
        "success",
    )
    search_fields = ("task_id", "endpoint", "error_message")
    list_filter = ("success", "method", "status_code", "endpoint", "created")
    ordering = ("-created",)
    date_hierarchy = "created"

    fields = (
        "created",
        "task_id",
        "endpoint",
        "method",
        "status_code",
        "success",
        "error_message",
        "payload_json_view",
        "response_json_view",
    )

    readonly_fields = fields

    def get_urls(self):
        """Expose custom grouped and per-task detail views."""
        urls = super().get_urls()
        custom_urls = [
            path(
                "task-groups/",
                self.admin_site.admin_view(self.task_groups_view),
                name="naac_vlan_provisioning_apirequestauditlog_task_groups",
            ),
            path(
                "task/<path:task_id>/",
                self.admin_site.admin_view(self.task_detail_view),
                name="naac_vlan_provisioning_apirequestauditlog_task_detail",
            ),
        ]
        return custom_urls + urls

    def has_add_permission(self, request):
        """Prevent manual creation of audit log entries from admin."""
        return False

    def change_view(self, request, object_id, form_url="", extra_context=None):
        """Render change page in view-only mode (no save controls)."""
        extra_context = extra_context or {}
        extra_context.update(
            {
                "show_save": False,
                "show_save_and_continue": False,
                "show_save_and_add_another": False,
            }
        )
        return super().change_view(request, object_id, form_url, extra_context)

    def changelist_view(self, request, extra_context=None):
        """
        Default admin entrypoint should show task groups instead of raw rows.
        If any query params are present, show the normal filtered changelist.
        """
        if request.GET:
            return super().changelist_view(request, extra_context=extra_context)

        task_groups_url = reverse(
            "admin:naac_vlan_provisioning_apirequestauditlog_task_groups"
        )
        return redirect(task_groups_url)

    def task_groups_view(self, request):
        """Render one card per task ID with count and drill-down links."""
        grouped = list(
            APIRequestAuditLog.objects.values("task_id")
            .annotate(request_count=Count("id"), last_request_at=Max("created"))
            .order_by("-last_request_at")
        )

        total_calls = APIRequestAuditLog.objects.count()
        total_tasks = len(grouped)
        latest_call = APIRequestAuditLog.objects.order_by("-created").first()

        logs_by_task = {}
        for log in APIRequestAuditLog.objects.order_by("-created"):
            task_key = log.task_id or "UNASSIGNED"
            logs_by_task.setdefault(task_key, []).append(
                {
                    "id": log.id,
                    "created": log.created,
                    "endpoint": log.endpoint,
                    "method": log.method,
                    "status_code": log.status_code,
                    "success": log.success,
                    "object_admin_url": reverse(
                        "admin:naac_vlan_provisioning_apirequestauditlog_change",
                        args=[log.id],
                    ),
                }
            )

        api_base_path = "/api/plugins/naac-vlan-provisioning/task-requests/"
        api_summary_url = request.build_absolute_uri(f"{api_base_path}summary/")

        task_groups = []
        for row in grouped:
            task_id = row.get("task_id") or "UNASSIGNED"
            task_groups.append(
                {
                    "task_id": task_id,
                    "request_count": row.get("request_count", 0),
                    "last_request_at": row.get("last_request_at"),
                    "detail_url": reverse(
                        "admin:naac_vlan_provisioning_apirequestauditlog_task_detail",
                        args=[task_id],
                    ),
                    "logs": logs_by_task.get(task_id, []),
                }
            )

        context = {
            **self.admin_site.each_context(request),
            "opts": self.model._meta,
            "title": "API Request Logs by Task ID",
            "task_groups": task_groups,
            "api_summary_url": api_summary_url,
            "total_calls": total_calls,
            "total_tasks": total_tasks,
            "latest_call": latest_call,
        }
        return TemplateResponse(
            request,
            "admin/naac_vlan_provisioning/apirequestauditlog/task_groups.html",
            context,
        )

    def task_detail_view(self, request, task_id):
        """Render task-scoped log detail with JSON request/response viewers."""
        logs_qs = APIRequestAuditLog.objects.filter(task_id=task_id).order_by("-created")

        logs = []
        success_count = 0
        failure_count = 0
        for log in logs_qs:
            if log.success:
                success_count += 1
            else:
                failure_count += 1

            payload_pretty = self._to_pretty_json(log.payload)
            response_pretty = self._to_pretty_json(log.response)
            logs.append(
                {
                    "id": log.id,
                    "created": log.created,
                    "endpoint": log.endpoint,
                    "method": log.method,
                    "status_code": log.status_code,
                    "success": log.success,
                    "error_message": log.error_message,
                    "payload_b64": self._to_b64_text(payload_pretty),
                    "payload_pretty": payload_pretty,
                    "response_b64": self._to_b64_text(response_pretty),
                    "response_pretty": response_pretty,
                    "object_admin_url": reverse(
                        "admin:naac_vlan_provisioning_apirequestauditlog_change",
                        args=[log.id],
                    ),
                }
            )

        context = {
            **self.admin_site.each_context(request),
            "opts": self.model._meta,
            "title": f"Task Logs: {task_id}",
            "task_id": task_id,
            "logs": logs,
            "total_calls": len(logs),
            "success_count": success_count,
            "failure_count": failure_count,
            "back_url": reverse("admin:naac_vlan_provisioning_apirequestauditlog_task_groups"),
            "api_detail_url": request.build_absolute_uri(
                f"/api/plugins/naac-vlan-provisioning/task-requests/{quote(task_id, safe='')}/"
            ),
        }
        return TemplateResponse(
            request,
            "admin/naac_vlan_provisioning/apirequestauditlog/task_detail.html",
            context,
        )

    @staticmethod
    def _to_pretty_json(value):
        """Render arbitrary JSON value into consistent pretty text."""
        return json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True)

    @staticmethod
    def _to_b64_text(raw_text):
        """Encode arbitrary text into base64 for safe HTML embedding."""
        return base64.b64encode(raw_text.encode("utf-8")).decode("ascii")

    def payload_json_view(self, obj):
        """Readonly JSON viewer shell for request payload."""
        payload_pretty = self._to_pretty_json(obj.payload)
        return format_html(
            '<div class="naac-json-viewer" data-json-b64="{}"><pre class="naac-json-fallback">{}</pre></div>',
            self._to_b64_text(payload_pretty),
            payload_pretty,
        )

    payload_json_view.short_description = "Request Payload"

    def response_json_view(self, obj):
        """Readonly JSON viewer shell for response payload."""
        response_pretty = self._to_pretty_json(obj.response)
        return format_html(
            '<div class="naac-json-viewer" data-json-b64="{}"><pre class="naac-json-fallback">{}</pre></div>',
            self._to_b64_text(response_pretty),
            response_pretty,
        )

    response_json_view.short_description = "Response Payload"
