from django.db import migrations, models


class Migration(migrations.Migration):
    initial = True

    dependencies = []

    operations = [
        migrations.CreateModel(
            name="APIRequestAuditLog",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("task_id", models.CharField(db_index=True, default="UNASSIGNED", max_length=128)),
                ("endpoint", models.CharField(max_length=255)),
                ("method", models.CharField(max_length=16)),
                ("payload", models.JSONField(blank=True, default=dict)),
                ("response", models.JSONField(blank=True, default=dict)),
                ("success", models.BooleanField(default=False)),
                ("status_code", models.PositiveIntegerField(default=500)),
                ("error_message", models.TextField(blank=True, default="")),
                ("created", models.DateTimeField(auto_now_add=True, db_index=True)),
            ],
            options={"ordering": ["-created"]},
        ),
        migrations.AddIndex(
            model_name="apirequestauditlog",
            index=models.Index(fields=["task_id", "-created"], name="naac_vlan_p_task_id_b96e0f_idx"),
        ),
        migrations.AddIndex(
            model_name="apirequestauditlog",
            index=models.Index(fields=["endpoint", "-created"], name="naac_vlan_p_endpoin_91ac93_idx"),
        ),
    ]
