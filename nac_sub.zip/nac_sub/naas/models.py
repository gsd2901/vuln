from django.db import models
from nautobot.dcim.models import Location, DeviceType, Rack
from nautobot.ipam.models import VLAN, VRF, Prefix
from nautobot.extras.models import Tag
import uuid
from django.utils import timezone

class SiteOnboarding(models.Model):
    id = models.UUIDField(default=uuid.uuid4, editable=False, primary_key=True, unique=True)
    name = models.CharField(max_length=100)
    location = models.ForeignKey(Location, on_delete=models.PROTECT, related_name="sites")
    tags = models.ManyToManyField(Tag, related_name="siteonboardings", blank=True)
    num_prefixes_masks = models.PositiveIntegerField(default=0)
    vlans = models.ManyToManyField(VLAN, related_name="site_onboardings", blank=True)
    vlan_requirements = models.JSONField(blank=True, default=list)
    vlan_description = models.TextField(help_text="VLAN Description for the site onboarding.", blank=True, null=True)
    uplink = models.CharField(max_length=100, blank=True, null=True)

    def __str__(self):
        return self.name

class Device(models.Model):
    site_onboarding = models.ForeignKey(SiteOnboarding, on_delete=models.CASCADE, related_name="devices")
    name = models.CharField(max_length=100)
    device_type = models.ForeignKey(DeviceType, on_delete=models.PROTECT)
    rack = models.ForeignKey(Rack, on_delete=models.PROTECT)
    vrfs = models.ManyToManyField(VRF, blank=True)
    serial_number = models.CharField(max_length=100, blank=True, null=True)

    def __str__(self):
        return self.name

class UpgradeApprovalRequest(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    approval_token = models.UUIDField(default=uuid.uuid4, editable=False, unique=True)
    created_at = models.DateTimeField(auto_now_add=True)
    expires_at = models.DateTimeField()
    requester = models.CharField(max_length=150)
    approver_email = models.EmailField()
    device_ip = models.CharField(max_length=255)
    job_parameters = models.JSONField()
    approved_at = models.DateTimeField(null=True, blank=True)
    approved_by = models.CharField(max_length=150, null=True, blank=True)
    rejected_at = models.DateTimeField(null=True, blank=True)
    rejected_by = models.CharField(max_length=150, null=True, blank=True)
    rejection_reason = models.TextField(blank=True, null=True)
    depends_on_approval = models.UUIDField(null=True, blank=True)
    status = models.CharField(
        max_length=20, 
        choices=[
            ('pending', 'Pending Approval'),
            ('approved', 'Approved'),
            ('rejected', 'Rejected'),
            ('expired', 'Expired'),
            ('executed', 'Executed')
        ],
        default='pending'
    )
    
    def __str__(self):
        return f"Approval {self.id} - {self.device_ip} ({self.status})"
    
    def is_expired(self):
        return timezone.now() > self.expires_at
    
    def can_be_approved(self):
        return self.status == 'pending' and not self.is_expired()
    
class RebootApprovalRequest(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    approval_token = models.UUIDField(default=uuid.uuid4, editable=False, unique=True)
    created_at = models.DateTimeField(auto_now_add=True)
    expires_at = models.DateTimeField()
    requester = models.CharField(max_length=150)
    requester_email = models.CharField(max_length=255,null=True,blank=True,default=None)
    approver_email = models.EmailField()
    #device_ip = models.CharField(max_length=255)
    device_ip = models.TextField()
    job_parameters = models.JSONField()
    approved_at = models.DateTimeField(null=True, blank=True)
    approved_by = models.CharField(max_length=150, null=True, blank=True)
    rejected_at = models.DateTimeField(null=True, blank=True)
    rejected_by = models.CharField(max_length=150, null=True, blank=True)
    rejection_reason = models.TextField(blank=True, null=True)
    #depends_on_approval = models.UUIDField(null=True, blank=True)
    status = models.CharField(
        max_length=20, 
        choices=[
            ('pending', 'Pending Approval'),
            ('approved', 'Approved'),
            ('rejected', 'Rejected'),
            ('expired', 'Expired'),
            ('executed', 'Executed')
        ],
        default='pending'
    )
    
    def __str__(self):
        return f"Approval {self.id} - {self.cr_number} ({self.status})"
    
    def is_expired(self):
        return timezone.now() > self.expires_at
    
    def can_be_approved(self):
        return self.status == 'pending' and not self.is_expired()
    




######## F5 ###########

# from django.contrib.auth import get_user_model
# from nautobot.apps.models import PrimaryModel
# from nautobot.core.models.generics import BaseModel
# from nautobot.extras.utils import extras_features

# User = get_user_model()

# @extras_features(
#     "custom_fields",
#     "custom_links",
#     "export_templates",
#     "relationships",
#     "webhooks",
# )
# class F5Device(PrimaryModel):
#     """F5 BigIP Device Model"""
#     name = models.CharField(max_length=100, unique=True)
#     ip_address = models.GenericIPAddressField()
#     username = models.CharField(max_length=50)
#     password = models.CharField(max_length=255)  # Consider encryption
#     partition = models.CharField(max_length=50, default="Common")
#     is_active = models.BooleanField(default=True)
#     description = models.TextField(blank=True)
    
#     class Meta:
#         ordering = ["name"]
#         verbose_name = "F5 Device"
#         verbose_name_plural = "F5 Devices"
    
#     def __str__(self):
#         return f"{self.name} ({self.ip_address})"

# @extras_features(
#     "custom_fields",
#     "custom_links",
#     "export_templates",
#     "relationships",
#     "webhooks",
# )
# class F5VIP(PrimaryModel):
#     """F5 Virtual IP Model"""
#     device = models.ForeignKey(F5Device, on_delete=models.CASCADE, related_name="vips")
#     name = models.CharField(max_length=100)
#     partition = models.CharField(max_length=50, default="Common")
#     destination = models.CharField(max_length=100)
#     pool = models.CharField(max_length=100, blank=True)
#     description = models.TextField(blank=True)
#     created_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True)
    
#     class Meta:
#         ordering = ["device", "name"]
#         unique_together = ["device", "name", "partition"]
#         verbose_name = "F5 VIP"
#         verbose_name_plural = "F5 VIPs"
    
#     def __str__(self):
#         return f"{self.device.name}/{self.partition}/{self.name}"

# @extras_features(
#     "custom_fields",
#     "custom_links", 
#     "export_templates",
#     "relationships",
#     "webhooks",
# )
# class F5Pool(PrimaryModel):
#     """F5 Pool Model"""
#     device = models.ForeignKey(F5Device, on_delete=models.CASCADE, related_name="pools")
#     name = models.CharField(max_length=100)
#     partition = models.CharField(max_length=50, default="Common")
#     description = models.TextField(blank=True)
#     load_balancing_mode = models.CharField(max_length=50, default="round-robin")
#     members = models.TextField(help_text="One member per line (IP:Port or hostname:port)")
#     created_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True)
    
#     class Meta:
#         ordering = ["device", "name"]
#         unique_together = ["device", "name", "partition"]
#         verbose_name = "F5 Pool"
#         verbose_name_plural = "F5 Pools"
    
#     def __str__(self):
#         return f"{self.device.name}/{self.partition}/{self.name}"

# class F5ValidationResult(BaseModel):
#     """Store VIP validation results"""
#     device = models.ForeignKey(F5Device, on_delete=models.CASCADE)
#     partition = models.CharField(max_length=50)
#     vip_names = models.TextField()
#     result_data = models.JSONField()
#     user = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True)
    
#     class Meta:
#         ordering = ["-created"]
#         verbose_name = "F5 Validation Result"
#         verbose_name_plural = "F5 Validation Results"





#F5 VIP Config
# class F5VIPConfig(models.Model):
#     id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
#     name = models.CharField(max_length=150, null=False, blank=False)
#     cr_number = models.CharField(max_length=150, null=True, blank=True)
#     description = models.CharField(max_length=150, null=True, blank=True)
#     destination = models.CharField(max_length=150, null=True, blank=True)
#     pool = models.CharField(max_length=150, null=True, blank=True)
#     ip_protocol = models.CharField(max_length=150, null=True, blank=True)
#     partition = models.CharField(max_length=150, null=True, blank=True)
#     source = models.CharField(max_length=150, null=True, blank=True)
#     snat_pool = models.CharField(max_length=150, null=True, blank=True)
#     protocol_client = models.CharField(max_length=150, null=True, blank=True)
#     protocol_server = models.CharField(max_length=150, null=True, blank=True)
#     http_client = models.CharField(max_length=150, null=True, blank=True)
#     http_server = models.CharField(max_length=150, null=True, blank=True)
#     status = models.CharField(
#         max_length=20, 
#         choices=[
#             ('pending', 'Pending Approval'),
#             ('approved', 'Approved'),
#             ('rejected', 'Rejected'),
#             ('expired', 'Expired'),
#             ('executed', 'Executed')
#         ],
#         default='pending'
#     )
#     created_at = models.DateTimeField(auto_now_add=True)



class F5ApprovalRequest(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    approval_token = models.UUIDField(default=uuid.uuid4, editable=False, unique=True)
    created_at = models.DateTimeField(auto_now_add=True)
    expires_at = models.DateTimeField()
    requester = models.CharField(max_length=150)
    requester_email = models.CharField(max_length=255,null=True,blank=True,default=None)
    approver_email = models.EmailField()
    operation = models.CharField(max_length=150)
    cr_number = models.CharField(max_length=150)
    job_parameters = models.JSONField()
    approved_at = models.DateTimeField(null=True, blank=True)
    approved_by = models.CharField(max_length=150, null=True, blank=True)
    rejected_at = models.DateTimeField(null=True, blank=True)
    rejected_by = models.CharField(max_length=150, null=True, blank=True)
    rejection_reason = models.TextField(blank=True, null=True)
    status = models.CharField(
        max_length=20, 
        choices=[
            ('pending', 'Pending Approval'),
            ('approved', 'Approved'),
            ('rejected', 'Rejected'),
            ('expired', 'Expired'),
            ('executed', 'Executed')
        ],
        default='pending'
    )
    
    def __str__(self):
        return f"Approval {self.id} - {self.cr_number} ({self.status})"
    
    def is_expired(self):
        return timezone.now() > self.expires_at
    
    def can_be_approved(self):
        return self.status == 'pending' and not self.is_expired()
