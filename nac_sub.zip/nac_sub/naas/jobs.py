# jobs.py
import os
import tempfile
import subprocess
import logging
import time
from datetime import datetime
from django.core.exceptions import ObjectDoesNotExist
import paramiko
import json
from django.conf import settings
from nautobot.extras.jobs import (
    Job, StringVar, BooleanVar, IntegerVar, ChoiceVar, ObjectVar, MultiObjectVar)
from naas.utils import check_upload_job_status
import re
from datetime import datetime
from nautobot.dcim.models import Device, Location, DeviceType
from nautobot.apps.jobs import (register_jobs)
from naas import constants
import shutil
from nautobot_golden_config.models import GoldenConfig, ConfigCompliance, ComplianceRule
from django.utils.timezone import now
from netmiko import ConnectHandler
from jinja2 import Environment, FileSystemLoader, TemplateNotFound
import difflib
from typing import Dict, Any, List, Callable
from django.db import transaction

logger = logging.getLogger(__name__)

import os
import tempfile
import subprocess
import logging
import time
import re
from datetime import datetime
from django.core.exceptions import ObjectDoesNotExist
import paramiko
import json
from django.conf import settings
from nautobot.extras.jobs import (
    Job, StringVar, BooleanVar, IntegerVar, ChoiceVar, ObjectVar, MultiObjectVar)
from nautobot.dcim.models import Device, Location, DeviceType
from nautobot.apps.jobs import (register_jobs)
from naas import constants
from naas.utils import check_upload_job_status
import shutil
from nautobot_golden_config.models import GoldenConfig, ConfigCompliance, ComplianceRule
from django.utils.timezone import now
from netmiko import ConnectHandler
from jinja2 import Environment, FileSystemLoader, TemplateNotFound
import difflib
from typing import Dict, Any, List, Callable
from django.db import transaction

logger = logging.getLogger(__name__)

# Hardcoded persistent path for Jinja templates
JINJA_TEMPLATES_PATH = "/home/ubuntu/nautobot-dev/nautobot/git/jinja_templates"

# --- Main Job Class ---
class ExtendedGoldenConfigJob(Job):
    class Meta:
        name = "Extended Golden Config Job"
        description = "Generates backup, intended, and compliance configs with optional remediation."

    location = ObjectVar(
        model=Location,
        description="Select the location for the devices.",
    )

    device_type = ObjectVar(
        model=DeviceType,
        description="Select the device type.",
    )

    config_level = ChoiceVar(
        choices=(
            ("global", "Global Config"),
            ("local", "Local Config"),
        ),
        description="Choose the configuration level (Global or Local).",
    )

    global_config_modules = StringVar(
        description="Enter global configuration modules (comma-separated, e.g., hostname,tacacs).",
        required=False,
    )

    local_config_modules = StringVar(
        description="Enter local configuration modules (comma-separated, e.g., vrf,interface).",
        required=False,
    )

    compliance_rules = MultiObjectVar(
        model=ComplianceRule,
        description="Select one or more compliance rules to check against.",
        required=True,
    )
    
    # New variable for remediation
    enable_remediation = BooleanVar(
        default=False,
        description="Enable automatic configuration remediation for non-compliant devices.",
        label="Enable Remediation"
    )

    def get_running_config(self, device):
        """Retrieves the running configuration from a device using Netmiko."""
        try:
            ip_address = str(device.primary_ip.address.ip)
            netmiko_options = {
                'banner_timeout': 30,
            }
            self.logger.info(f"Attempting to SSH to device {device.name} at {ip_address}...")
            
            conn = ConnectHandler(
                device_type="cisco_xe",
                host=ip_address,
                username=getattr(settings, "NAUTOBOT_DEVICE_USERNAME", "netadmin"),
                password=getattr(settings, "NAUTOBOT_DEVICE_PASSWORD", "netadmin@hcl"),
                **netmiko_options
            )
            self.logger.success(f"Successfully connected to {device.name}.")
            return conn.send_command("show running-config")
        except Exception as e:
            self.logger.failure(f"Failed to retrieve running config from {device.name}: {e}")
            return None

    def generate_intended_config(self, device, selected_modules, template_path):
        """Generates the intended configuration from a Jinja2 template."""
        template_file = "intended_config.j2"
        try:
            if not device.primary_ip:
                self.logger.warning(f"Device {device.name} has no primary IP address defined. Skipping intended config generation.")
                return None
            
            env = Environment(loader=FileSystemLoader(template_path))
            template = env.get_template(template_file)
            
            rendered_config = template.render(
                device=device,
                modules=selected_modules
            )

            self.logger.info(f"Intended config generated for {device.name}.")
            return rendered_config
        except TemplateNotFound:
            self.logger.failure(f"Template file '{template_file}' not found in '{template_path}'.")
            return None
        except Exception as e:
            self.logger.failure(f"Error rendering template for {device.name}: {e}")
            return None
            
    def remediate_config(self, device, remediation_config):
        """Applies the remediation configuration to the device using Netmiko."""
        try:
            ip_address = str(device.primary_ip.address.ip)
            self.logger.info(f"Attempting to connect to {device.name} to apply remediation.")
            
            enable_password = getattr(settings, "NAUTOBOT_DEVICE_PASSWORD", "@ut0M@t10n")
            
            netmiko_options = {
                'global_delay_factor': 2,
                'session_log': f"/tmp/netmiko_session_{device.name}_{int(time.time())}.log",
                'banner_timeout': 30,
            }
            
            conn = ConnectHandler(
                device_type="cisco_xe",
                host=ip_address,
                username=getattr(settings, "NAUTOBOT_DEVICE_USERNAME", "netadmin"),
                password=getattr(settings, "NAUTOBOT_DEVICE_PASSWORD", "netadmin@hcl"),
                secret=enable_password,
                **netmiko_options
            )
            
            if not conn.check_enable_mode():
                conn.enable()

            self.logger.info(f"Applying remediation configuration to {device.name}...")
            output = conn.send_config_set(remediation_config.splitlines())
            conn.save_config()
            conn.disconnect()
            self.logger.success(f"Remediation successfully applied to {device.name}.")
            return True
        except Exception as e:
            self.logger.failure(f"Failed to apply remediation to {device.name}: {e}")
            return False

    def run(self, data=None, commit=None, **kwargs):
        """Main execution logic for the job."""
        self.logger.info("Starting Extended Golden Config Job.")

        if data is None:
            data = kwargs
        
        if data is None:
            self.logger.failure("Job received no data. Aborting.")
            return "Job aborted due to missing parameters."
        
        location = data.get('location')
        device_type_obj = data.get('device_type')
        config_level = data.get("config_level")
        compliance_rules = data.get("compliance_rules")
        enable_remediation = data.get("enable_remediation", False)

        if not compliance_rules:
            self.logger.failure("No compliance rules selected. Aborting.")
            return "Job aborted due to missing parameters."
        
        backup_repo_url = "https://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@github.com/kshitij-shawarma/goldenconfig.git"
        intended_repo_url = "https://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@github.com/kshitij-shawarma/intended-config.git"
        jinja_repo_url = "https://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@github.com/kshitij-shawarma/jinja-templates.git"
        git_branch = "main"

        if config_level == "global" and data.get("global_config_modules"):
            selected_modules = [m.strip() for m in data["global_config_modules"].split(',')]
        elif config_level == "local" and data.get("local_config_modules"):
            selected_modules = [m.strip() for m in data["local_config_modules"].split(',')]
        else:
            selected_modules = []

        if not location or not device_type_obj:
            self.logger.failure("Missing required location or device type.")
            return "Job aborted due to missing parameters."

        self.logger.info(f"Filtering devices for location '{location.name}' and type '{device_type_obj.model}'.")
        
        devices = Device.objects.filter(
            location=location,
            device_type=device_type_obj
        )

        if not devices.exists():
            self.logger.warning("No devices found matching the selected criteria.")
            return "No devices found to run the job on."

        # --- LOGIC FOR JINJA TEMPLATES REPO ---
        jinja_template_files_path = os.path.join(JINJA_TEMPLATES_PATH, "templates")
        
        try:
            if not os.path.exists(JINJA_TEMPLATES_PATH):
                self.logger.info(f"Cloning Jinja templates into {JINJA_TEMPLATES_PATH}")
                try:
                    self.logger.info(f"Executing git clone command: git clone --branch {git_branch} {jinja_repo_url} {JINJA_TEMPLATES_PATH}")
                    result = subprocess.run(
                        ['git', 'clone', '--branch', git_branch, jinja_repo_url, JINJA_TEMPLATES_PATH],
                        check=True,
                        capture_output=True,
                        text=True
                    )
                    self.logger.info(f"Git clone stdout: {result.stdout}")
                    self.logger.info(f"Git clone stderr: {result.stderr}")
                except subprocess.CalledProcessError as e:
                    self.logger.failure(f"Git clone command failed: {e.cmd}")
                    self.logger.failure(f"Git clone stdout: {e.stdout}")
                    self.logger.failure(f"Git clone stderr: {e.stderr}")
                    raise  # Re-raise the exception to fail the job
            else:
                self.logger.info(f"Templates already exist. Cleaning and pulling latest changes.")
                
                # Capture the output for reset and clean
                try:
                    self.logger.info("Executing git reset --hard HEAD")
                    result_reset = subprocess.run(
                        ['git', 'reset', '--hard', 'HEAD'],
                        check=True,
                        cwd=JINJA_TEMPLATES_PATH,
                        capture_output=True,
                        text=True
                    )
                    self.logger.info(f"Git reset stdout: {result_reset.stdout}")
                    self.logger.info(f"Git reset stderr: {result_reset.stderr}")
                    
                    self.logger.info("Executing git clean -fdx")
                    result_clean = subprocess.run(
                        ['git', 'clean', '-fdx'],
                        check=True,
                        cwd=JINJA_TEMPLATES_PATH,
                        capture_output=True,
                        text=True
                    )
                    self.logger.info(f"Git clean stdout: {result_clean.stdout}")
                    self.logger.info(f"Git clean stderr: {result_clean.stderr}")
                    
                    self.logger.info(f"Executing git pull origin {git_branch}")
                    result_pull = subprocess.run(
                        ['git', 'pull', 'origin', git_branch],
                        check=True,
                        cwd=JINJA_TEMPLATES_PATH,
                        capture_output=True,
                        text=True
                    )
                    self.logger.info(f"Git pull stdout: {result_pull.stdout}")
                    self.logger.info(f"Git pull stderr: {result_pull.stderr}")
                    
                except subprocess.CalledProcessError as e:
                    self.logger.failure(f"Git command failed: {e.cmd}")
                    self.logger.failure(f"Git command stdout: {e.stdout}")
                    self.logger.failure(f"Git command stderr: {e.stderr}")
                    raise  # Re-raise the exception to fail the job

        except subprocess.CalledProcessError as e:
            self.logger.failure(f"Git operation failed for Jinja templates repo: {e}")
            return "Job failed due to a Git error with the Jinja templates repository."
        
        try:
            with tempfile.TemporaryDirectory() as backup_repo_path, \
                 tempfile.TemporaryDirectory() as intended_repo_path:

                self.logger.info(f"Cloning backup repo into {backup_repo_path}")
                subprocess.run(['git', 'clone', '--branch', git_branch, backup_repo_url, backup_repo_path], check=True)

                self.logger.info(f"Cloning intended config repo into {intended_repo_path}")
                subprocess.run(['git', 'clone', '--branch', git_branch, intended_repo_url, intended_repo_path], check=True)
                
                for device in devices:
                    self.logger.info(f"Processing device: {device.name}")

                    backup_config = self.get_running_config(device)
                    intended_config = self.generate_intended_config(device, selected_modules, jinja_template_files_path)
                    
                    if not backup_config or not intended_config:
                        self.logger.failure(f"Skipping all operations for {device.name} due to missing config data.")
                        continue
                    
                    # Store backup config in Git
                    backup_config_file_path = os.path.join(backup_repo_path, f'{device.name}.cfg')
                    with open(backup_config_file_path, 'w') as config_file:
                        config_file.write(backup_config)
                    subprocess.run(['git', 'add', backup_config_file_path], check=True, cwd=backup_repo_path)
                    
                    status_output = subprocess.run(['git', 'status', '--porcelain'], capture_output=True, text=True, check=True, cwd=backup_repo_path)
                    if status_output.stdout:
                        subprocess.run(['git', 'commit', '-m', f'Update backup config for {device.name}'], check=True, cwd=backup_repo_path)
                    else:
                        self.logger.warning(f"No changes to commit for backup config for {device.name}. Skipping commit.")
                        
                    # Store intended config in Git
                    intended_config_file_path = os.path.join(intended_repo_path, f'{device.name}.cfg')
                    with open(intended_config_file_path, 'w') as config_file:
                        config_file.write(intended_config)
                    subprocess.run(['git', 'add', intended_config_file_path], check=True, cwd=intended_repo_path)
                    
                    status_output = subprocess.run(['git', 'status', '--porcelain'], capture_output=True, text=True, check=True, cwd=intended_repo_path)
                    if status_output.stdout:
                        subprocess.run(['git', 'commit', '-m', f'Update intended config for {device.name}'], check=True, cwd=intended_repo_path)
                    else:
                        self.logger.warning(f"No changes to commit for intended config for {device.name}. Skipping commit.")
                        
                    self.logger.info(f"Continuing with Golden Config processing for {device.name}.")

                    golden_config_obj, _ = GoldenConfig.objects.get_or_create(device=device)
                    golden_config_obj.backup_config = backup_config
                    golden_config_obj.intended_config = intended_config
                    golden_config_obj.backup_last_success_date = now()
                    golden_config_obj.intended_last_success_date = now()
                    golden_config_obj.save()
                    
                    # Loop through each selected compliance rule
                    for rule in compliance_rules:
                        # --- START OF COMPLIANCE CHECK AND REMEDIATION LOGIC ---
                        
                        self.logger.info(f"Performing pre-remediation compliance check for rule: '{rule.description}' on device: {device.name}")
                        
                        try:
                            # Correctly render the 'Config To Match' field using Jinja2
                            # Replace [CORRECT_FIELD_NAME] with the actual field name you find
                            template = Environment().from_string(rule.description)
                            rendered_intended_config = template.render(device=device)

                            # Normalize both the rendered intended config and the actual config
                            intended_lines_to_check = {line.strip() for line in rendered_intended_config.splitlines() if line.strip()}
                            backup_lines_normalized = {re.sub(r'\s+', ' ', line.strip()) for line in backup_config.splitlines() if line.strip()}
                            
                            non_compliant_lines = []
                            
                            # Perform the comparison
                            for intended_line in intended_lines_to_check:
                                if intended_line not in backup_lines_normalized:
                                    non_compliant_lines.append(intended_line)
                        except Exception as e:
                            self.logger.failure(f"Error processing rule '{rule.description}': {e}")
                            continue

                        compliance = not non_compliant_lines
                        diff = "The following lines are missing from the running configuration:\n" + "\n".join(non_compliant_lines) if non_compliant_lines else ""
                        
                        if compliance:
                            self.logger.success(f"Device is fully compliant with rule '{rule.description}'. No remediation needed.")
                        else:
                            self.logger.warning(f"Device is NON-COMPLIANT with rule '{rule.description}'. Remediation required.")

                        final_compliance_status = compliance
                        final_diff = diff
                        
                        if not final_compliance_status and enable_remediation:
                            self.logger.info(f"Remediation enabled. Attempting to apply configuration to {device.name}.")
                            remediation_status = self.remediate_config(device, "\n".join(non_compliant_lines))
                            
                            if remediation_status:
                                self.logger.success(f"Remediation was successful for {device.name}. Now re-verifying compliance.")
                                
                                backup_config_after_remediation = self.get_running_config(device)
                                
                                if backup_config_after_remediation:
                                    golden_config_obj.backup_config = backup_config_after_remediation
                                    golden_config_obj.save()
                                    
                                    backup_lines_after = {re.sub(r'\s+', ' ', line.strip()) for line in backup_config_after_remediation.splitlines() if line.strip()}
                                    
                                    final_non_compliant_lines = []
                                    for intended_line in intended_lines_to_check:
                                        if intended_line not in backup_lines_after:
                                            final_non_compliant_lines.append(intended_line)
                                    
                                    final_compliance_status = not final_non_compliant_lines
                                    final_diff = "" if final_compliance_status else "The following lines are still missing after remediation:\n" + "\n".join(final_non_compliant_lines)
                                    
                                    if final_compliance_status:
                                        self.logger.success(f"Device is now fully compliant after remediation.")
                                    else:
                                        self.logger.warning(f"Remediation failed to achieve full compliance. Still non-compliant.")
                                else:
                                    self.logger.failure(f"Failed to retrieve running config after remediation. Cannot verify final compliance.")
                                    final_compliance_status = False
                                    final_diff = "Failed to verify compliance after remediation."
                            else:
                                self.logger.failure(f"Remediation failed for {device.name}. Manual intervention required.")
                                final_compliance_status = False
                                
                        # Update the ConfigCompliance model with the final status and diff
                        compliance_obj, _ = ConfigCompliance.objects.get_or_create(
                            device=device,
                            rule=rule
                        )
                        compliance_obj.compliance = final_compliance_status
                        compliance_obj.actual = backup_config
                        compliance_obj.intended = rendered_intended_config.strip()
                        compliance_obj.diff = final_diff
                        compliance_obj.save()
                        
                        self.logger.info(f"Final compliance status for rule '{rule.description}' determined as: {final_compliance_status}.")
                
                self.logger.info(f"Pushing changes to backup repo.")
                subprocess.run(['git', 'push', 'origin', git_branch], check=True, cwd=backup_repo_path)

                self.logger.info(f"Pushing changes to intended config repo.")
                subprocess.run(['git', 'push', 'origin', git_branch], check=True, cwd=intended_repo_path)

                self.logger.success("Configurations successfully stored in Git repositories.")

        except subprocess.CalledProcessError as e:
            self.logger.failure(f"Git operation failed: {e}")
            return "Job failed due to a Git error."
        
        self.logger.success("Extended golden config job complete.")
        return "Extended golden config process complete for all selected devices."

logger = logging.getLogger(__name__)
class DeviceUpgradeJob(Job):
    """
    Job to upgrade network device firmware using Ansible.
    """
    # Define job variables that will appear in the Nautobot UI
    device_ip = StringVar(
        description="IP address of the device to upgrade",
        required=True
    )
    
    tftp_server = StringVar(
        description="TFTP server IP address",
        required=True
    )
    
    tftp_path = StringVar(
        description="Path on TFTP server where files are stored",
        required=True
    )
    
    image_file = StringVar(
        description="Firmware image filename",
        required=True
    )
    
    md5_checksum = StringVar(
        description="MD5 checksum of the firmware image",
        default=""
    )

    vrf_name = StringVar(
        description="VRF name to use for TFTP transfer (leave blank if not required)",
        default="",
        required=False
    )

    auth_method = ChoiceVar(
        description="Authentication method",
        choices=(
            ('SSH', 'SSH'),
            ('Telnet', 'Telnet')
        ),
        default='SSH'
    )
    
    credential_profile = StringVar(
        description="Credentials profile to use",
        default="default"
    )
    
    primary_action = ChoiceVar(
        description="Primary action",
        choices=(
            ('upload', 'Upload Image'),
            ('upload_install', 'Upload & Install Image'),
            ('install', 'Install Image')
        ),
        default="upload"
    )
    
    secondary_action = ChoiceVar(
        description="Secondary action",
        choices=(
            ('none', 'None'),
            ('reload', 'Reload Device'),
            ('verify', 'Verify Installation')
        ),
        default="none"
    )
    
    ansible_server = StringVar(
        description="Ansible server IP address",
        default="172.21.17.41"
    )

    ansible_server_user = StringVar(
        description="Username for Ansible server",
        default="ubuntu"
    )
    
    ansible_server_password = StringVar(
        description="Password for Ansible server",
        default=""
    )

    # NEW: Virtual environment path configuration
    ansible_venv_path = StringVar(
        description="Virtual environment path on Ansible server",
        default="/home/ubuntu/.ios_upgrade"
    )
    
    # Use Nautobot's built-in dry run functionality
    dryrun = BooleanVar(
        description="Test mode - no changes will be made",
        default=True
    )
    
    # All required validations will be performed by default - remove 'hidden' parameter
    check_memory = BooleanVar(
        description="Verify free flash memory",
        default=True
    )
    
    check_compatibility = BooleanVar(
        description="Verify IOS compatibility",
        default=True
    )
    
    backup_config = BooleanVar(
        description="Backup configuration",
        default=True
    )
    
    verify_boot = BooleanVar(
        description="Verify boot success",
        default=True
    )
    
    verify_features = BooleanVar(
        description="Verify features post-upgrade",
        default=True
    )
    
    enable_rollback = BooleanVar(
        description="Enable automatic rollback",
        default=True
    )

    class Meta:
        name = "Device Firmware Upgrade"
        description = "Upgrade firmware on network devices using Ansible playbooks"
        has_sensitive_variables = True  # Mark as having sensitive variables
        field_order = [
            'device_ip', 'tftp_server', 'tftp_path', 'image_file', 
            'md5_checksum', 'vrf_name', 'auth_method', 'credential_profile',
            'primary_action', 'secondary_action', 'ansible_server',
            'ansible_server_user', 'ansible_server_password', 'ansible_venv_path', 'dryrun'
        ]

    def pre_run(self, data, commit):
        """
        Pre-run hook to check if this job depends on another job.
        """
        # Check if this is an install job that depends on an upload job
        depends_on_job_id = data.get('depends_on_job_id')
        if depends_on_job_id and data.get('primary_action') == 'install':
            self.logger.info(f"This install job depends on upload job {depends_on_job_id}")
            
            # Check if the upload job was successful
            from naas.utils import check_upload_job_status
            if not check_upload_job_status(depends_on_job_id):
                self.logger.error(f"Upload job {depends_on_job_id} did not complete successfully. Aborting install.")
                # Return a job error
                return False, "Installation aborted because the upload job did not complete successfully."
        
        # Continue with the job
        return True, None

    def run(self, data=None, commit=None, **kwargs):
        """
        Run the device upgrade job.
        """
        # Log what we received for debugging
        self.logger.info(f"Run method received data and kwargs (sensitive values redacted)")
        
        # If we received individual parameters instead of a data dict, build the data dict
        if data is None:
            data = kwargs
        
        temp_file = None
        
        # Extract variables from data - with error handling
        try:
            device_ip = data.get('device_ip', kwargs.get('device_ip', ''))
            tftp_server = data.get('tftp_server', kwargs.get('tftp_server', '172.21.17.41'))
            tftp_path = data.get('tftp_path', kwargs.get('tftp_path', ''))
            image_file = data.get('image_file', kwargs.get('image_file', ''))
            md5_checksum = data.get('md5_checksum', kwargs.get('md5_checksum', ''))
            upgrade_version = data.get('upgrade_version', kwargs.get('upgrade_version', 'Unknown'))
            change_number = data.get('change_number', kwargs.get('change_number', ''))
            vrf_name = data.get('vrf_name', kwargs.get('vrf_name', ''))
            
            # Email settings
            smtp_server = data.get('smtp_server', kwargs.get('smtp_server', 'smtp.gmail.com'))
            email_sender = data.get('email_sender', kwargs.get('email_sender', 'no-reply@hcltech.com'))
            email_receiver = data.get('email_receiver', kwargs.get('email_receiver', 'avinash_sharma@hcltech.com'))
            
            auth_method = data.get('auth_method', kwargs.get('auth_method', 'SSH'))
            credential_profile = data.get('credential_profile', kwargs.get('credential_profile', 'default'))
            primary_action = data.get('primary_action', kwargs.get('primary_action', ''))
            secondary_action = data.get('secondary_action', kwargs.get('secondary_action', 'none'))
            
            # Get Ansible server details
            ansible_server = data.get('ansible_server', kwargs.get('ansible_server', '172.21.17.41'))
            ansible_server_user = data.get('ansible_server_user', kwargs.get('ansible_server_user', 'ubuntu'))
            ansible_server_password = data.get('ansible_server_password', kwargs.get('ansible_server_password', 'Passw0rd@123'))
            
            # NEW: Get virtual environment path
            ansible_venv_path = data.get('ansible_venv_path', kwargs.get('ansible_venv_path', '~/.ios_upgrade'))
            
            # Set dry run from the form if provided, otherwise use the commit parameter
            dry_run = data.get('dryrun', not bool(commit))
            
            # Get validation parameters - always set to True by default
            check_memory = data.get('check_memory', kwargs.get('check_memory', True))
            check_compatibility = data.get('check_compatibility', kwargs.get('check_compatibility', True))
            backup_config = data.get('backup_config', kwargs.get('backup_config', True))
            verify_boot = data.get('verify_boot', kwargs.get('verify_boot', True))
            verify_features = data.get('verify_features', kwargs.get('verify_features', True))
            enable_rollback = data.get('enable_rollback', kwargs.get('enable_rollback', True))
            
            if image_file.startswith(tftp_path):
                # Remove the TFTP root path to get the relative path
                ios_path = '/'.join(image_file.split('/')[:-1])
                new_ios_bin = image_file.split('/')[-1]  # "cat9k_iosxe_npe.17.06.07.SPA.bin"
            else:
                # Fallback if the paths don't match as expected
                # Just use the filename
                new_ios_bin = os.path.basename(image_file)


            # If version not provided, extract from image file
            if upgrade_version == "Unknown" and image_file:
                import re
                filename = os.path.basename(image_file)
                version_match = re.search(r'\.(\d+\.\d+\.\d+)\.', filename)
                if version_match:
                    upgrade_version = version_match.group(1)
                    self.logger.info(f"Extracted version {upgrade_version} from image filename")
            
            # Get credentials from credential profile or environment
            if credential_profile == 'default':
                ansible_user = os.environ.get('ANSIBLE_USER', 'netadmin')
                ansible_password = os.environ.get('ANSIBLE_PASSWORD', 'netadmin@hcl')
            else:
                # Get credentials from Nautobot secrets or other source
                self.logger.info(f"Using credential profile: {credential_profile}")
                ansible_user = "netadmin"  # Replace with actual credential retrieval
                ansible_password = "netadmin@hcl"  # Replace with actual credential retrieval
            
            # Create unique filenames with timestamp to avoid conflicts
            timestamp = int(time.time())
            job_id = str(kwargs.get('job_id', timestamp))
            
            # Create unique filename with timestamp suffix
            unique_inventory = f"devices_9300_{job_id}.ini"
            unique_vars = f"9300_vars_{job_id}.yml"
            
            # Set the paths for the files on the Ansible server
            inventory_filename = f"/home/ubuntu/ios_upgrade/9300/{unique_inventory}"
            vars_filename = f"/home/ubuntu/ios_upgrade/9300/{unique_vars}"
            
            # Symlink names (these are what the playbook will use)
            inventory_symlink = "/home/ubuntu/ios_upgrade/9300/devices_9300.ini"
            vars_symlink = "/home/ubuntu/ios_upgrade/9300/9300_vars.yml"
            
            # FIXED: Create the Ansible inventory content with correct connection parameters
            inventory_content = f"""[switches]
{device_ip}

[switches:vars]
ansible_connection=network_cli
ansible_become=yes
ansible_become_method=enable
ansible_network_os=ios
ansible_user={ansible_user}
ansible_password="{ansible_password}"
ansible_python_interpreter=/usr/bin/python3
ansible_host_key_checking=false
ansible_command_timeout=30
ansible_connect_timeout=30
"""

            # Create the Ansible vars content - now includes validation flags
            vars_content = f"""# Main upgrade variables
upgrade_ios_version: {upgrade_version}
new_ios_bin: {new_ios_bin}
new_ios_md5: {md5_checksum}
ios_path: {ios_path}/
tftp_server: {tftp_server}
tftp_path: {tftp_path}
precheck_path: /home/ubuntu/pre_config
postcheck_path: /home/ubuntu/post_config

# Additional required variables
is_check_mode: "{{{{ ansible_check_mode | default(false) }}}}"
"""
            # Add change number if provided
            if change_number:
                vars_content += f"change_number: {change_number}\n"

            if vrf_name:
                vars_content += f"vrf_name: {vrf_name}\n"

            self.logger.info(f"vrf_name: {vrf_name}")
                # Create the device_type_vars.yml content
            # Add email settings
            vars_content += f"""smtp_server: {smtp_server}
sender: {email_sender}
receiver: {email_receiver}
skip_email_notifications: true
"""
            # Determine which playbook to use based on test mode
            if primary_action == 'upload':
                playbook_name = 'upload-9300.yml'
            elif primary_action == 'install':
                playbook_name = 'upgrade-9300.yml'
            elif primary_action == 'upload_install':
                playbook_name = 'upload-9300.yml'
            else:
                # Fallback to default upload playbook if action is unrecognized
                self.logger.warning(f"Unrecognized primary action: {primary_action}. Using default upload playbook.")
                playbook_name = 'upload-9300.yml'
            
            playbook_path = f"/home/ubuntu/ios_upgrade/9300/{playbook_name}"
            
            # UPDATED: Create a shell script to run on the Ansible server with virtual environment activation
            shell_script = f"""#!/bin/bash
echo "Starting firmware upgrade job {job_id} for device {device_ip}"

# Expand tilde to full path if needed
VENV_PATH="{ansible_venv_path}"
if [[ "$VENV_PATH" == "~"* ]]; then
    VENV_PATH="$HOME/${{VENV_PATH:2}}"
fi

echo "Using virtual environment path: $VENV_PATH"

# Check if virtual environment exists
if [ ! -d "$VENV_PATH" ]; then
    echo "ERROR: Virtual environment not found at $VENV_PATH"
    echo "Available directories in $HOME:"
    ls -la $HOME/ | grep -E "(ios|ansible|venv)" || echo "No matching directories found"
    echo "Please ensure the virtual environment is properly configured"
    exit 1
fi

# Test virtual environment activation
echo "Testing virtual environment activation..."
source "$VENV_PATH/bin/activate"
if [ $? -ne 0 ]; then
    echo "ERROR: Failed to activate virtual environment at $VENV_PATH"
    exit 1
fi

# Check if ansible-playbook is available in the virtual environment
which ansible-playbook > /dev/null 2>&1
if [ $? -ne 0 ]; then
    echo "ERROR: ansible-playbook not found in virtual environment"
    echo "Current PATH: $PATH"
    echo "Available commands:"
    which ansible || echo "ansible not found"
    exit 1
fi

echo "Virtual environment activated successfully"
echo "Using ansible-playbook: $(which ansible-playbook)"
echo "Ansible version: $(ansible-playbook --version | head -1)"

# Create directory for job files if it doesn't exist
mkdir -p /home/ubuntu/ios_upgrade/job_files

# Create inventory file with unique name
cat > {inventory_filename} << 'EOL'
{inventory_content}
EOL
chmod 644 {inventory_filename}

# Create vars file with unique name
cat > {vars_filename} << 'EOL'
{vars_content}
EOL
chmod 644 {vars_filename}

# Create or update symlinks to point to the latest files
ln -sf {inventory_filename} {inventory_symlink}
ln -sf {vars_filename} {vars_symlink}

# Display created files for debugging
echo "=== Created inventory file: {inventory_filename} ==="
cat {inventory_filename}
echo

echo "=== Created vars file: {vars_filename} ==="
cat {vars_filename}
echo

echo "=== Symlink status ==="
ls -la {inventory_symlink} {vars_symlink}
echo

# Change to the ios_upgrade directory
cd /home/ubuntu/ios_upgrade/9300

# Ensure we're still in the virtual environment after changing directories
source "$VENV_PATH/bin/activate"

# Test connectivity to device before running full playbook
echo "=== Testing device connectivity ==="
ansible -i {inventory_symlink} switches -m raw -a "show version" -c network_cli
CONNECTIVITY_TEST=$?

if [ $CONNECTIVITY_TEST -ne 0 ]; then
    echo "WARNING: Device connectivity test failed. Proceeding with playbook anyway..."
else
    echo "Device connectivity test successful"
fi

echo

# Run Ansible playbook with virtual environment activated
echo "=== Running Ansible playbook ==="
echo "Command: ansible-playbook -i {inventory_symlink} {playbook_path} {'-C' if dry_run else ''} -v"
ansible-playbook -i {inventory_symlink} {playbook_path} {'-C' if dry_run else ''} -v
ANSIBLE_RESULT=$?

# Log the result
echo "=== Ansible playbook execution completed ==="
echo "Exit code: $ANSIBLE_RESULT"

# Save files for record-keeping (move to a job_files directory)
mkdir -p /home/ubuntu/ios_upgrade/job_files/{job_id}
cp {inventory_filename} {vars_filename} /home/ubuntu/ios_upgrade/job_files/{job_id}/

# Clean up symlinks

# Return success message
if [ $ANSIBLE_RESULT -eq 0 ]; then
    if [ "{str(dry_run).lower()}" = "true" ]; then
        echo "=== SIMULATION SUCCESSFUL ==="
        echo "Simulation successful for firmware upgrade on {device_ip}"
    else
        echo "=== UPGRADE SUCCESSFUL ==="
        echo "Successfully completed firmware upgrade on {device_ip}"
    fi
else
    echo "=== UPGRADE FAILED ==="
    echo "Failed to execute firmware upgrade on {device_ip}"
    echo "Check the ansible output above for details"
fi

echo "Job files saved to: /home/ubuntu/ios_upgrade/job_files/{job_id}/"
exit $ANSIBLE_RESULT
"""
            
            # Create a temporary file for the shell script
            temp_file = tempfile.NamedTemporaryFile(mode='w+', suffix='.sh', delete=False)
            temp_file.write(shell_script)
            temp_file.flush()
            script_path = temp_file.name
            temp_file.close()
            
            # Make the script executable
            os.chmod(script_path, 0o755)
            
            self.logger.info(f"Connecting to Ansible server {ansible_server_user}@{ansible_server}")
            self.logger.info(f"Using virtual environment: {ansible_venv_path}")
            
            self.logger.info(f"vars_content: {vars_content}")
            # If we have a password, use sshpass for authentication
            if ansible_server_password:
                # Run sshpass to execute the script on the remote server
                cmd = [
                    "sshpass", 
                    "-p", ansible_server_password,
                    "ssh",
                    "-o", "StrictHostKeyChecking=no",
                    f"{ansible_server_user}@{ansible_server}",
                    "bash -s"
                ]
                
                self.logger.info("Using password authentication for Ansible server")
            else:
                # Use regular SSH without password
                cmd = [
                    "ssh",
                    "-o", "StrictHostKeyChecking=no",
                    f"{ansible_server_user}@{ansible_server}",
                    "bash -s"
                ]
                
                self.logger.info("Using default authentication for Ansible server")
            
            try:
                # Execute the SSH command, feeding the script via stdin
                self.logger.info(f"Executing firmware upgrade script on {ansible_server}")
                
                with open(script_path, 'r') as script:
                    process = subprocess.Popen(
                        cmd,
                        stdin=script,
                        stdout=subprocess.PIPE,
                        stderr=subprocess.PIPE,
                        text=True
                    )
                
                # Stream output to job logs
                stdout_lines = []
                for line in process.stdout:
                    line = line.strip()
                    stdout_lines.append(line)
                    if line:
                        self.logger.info(line)
                
                # Wait for the process to finish
                return_code = process.wait()
                
                # Handle any errors
                if return_code != 0:
                    stderr = process.stderr.read()
                    self.logger.error(f"SSH command failed with exit code {return_code}")
                    self.logger.error(f"Error output: {stderr}")
                    
                    # Check for common SSH errors
                    if "Connection refused" in stderr:
                        self.logger.error("Connection refused. Check if SSH service is running on the Ansible server.")
                    elif "Permission denied" in stderr:
                        self.logger.error("Permission denied. Check your username and password for the Ansible server.")
                    elif "Host key verification failed" in stderr:
                        self.logger.error("Host key verification failed.")
                    elif "Virtual environment not found" in '\n'.join(stdout_lines):
                        self.logger.error(f"Virtual environment not found at {ansible_venv_path}. Please check the path.")
                    
                    return False
                
                # Get the last line of output as the final status message
                final_message = stdout_lines[-1] if stdout_lines else "Operation completed"
                self.logger.info(f"Final status: {final_message}")

                trigger_install = data.get('trigger_install_after_completion', kwargs.get('trigger_install_after_completion', False))
                
                if trigger_install and primary_action == 'upload':
                    self.logger.info("Upload completed successfully. Triggering install job.")
                    
                    # Get the install parameters from the data
                    install_kwargs = data.get('install_job_params', kwargs.get('install_job_params', {}))
                    
                    if install_kwargs:
                        # Set the primary action to install
                        install_kwargs['primary_action'] = 'install'
                        
                        # Add reference to this job ID for dependency checking
                        install_kwargs['depends_on_job_id'] = str(kwargs.get('job_id'))
                        
                        # Get the job model
                        from nautobot.extras.models import Job, JobResult
                        try:
                            job_model = Job.objects.get(job_class_name='DeviceUpgradeJob', module_name='naas.jobs')
                            
                            # Create and enqueue the install job
                            install_job = JobResult.enqueue_job(
                                job_model=job_model,
                                user=kwargs.get('user'),
                                **install_kwargs
                            )
                            
                            self.logger.info(f"Successfully triggered install job {install_job.pk}")
                        except Exception as e:
                            self.logger.error(f"Failed to trigger install job: {str(e)}")
                            import traceback
                            self.logger.error(traceback.format_exc())
                    else:
                        self.logger.error("No install parameters found. Cannot trigger install job.")
                        
                return True
                
            except Exception as e:
                self.logger.error(f"Error executing SSH command: {str(e)}")
                return False
            
        except Exception as e:
            self.logger.error(f"Error during firmware upgrade: {str(e)}")
            return False
        finally:
            # Always clean up the temporary file if it exists
            if temp_file and os.path.exists(temp_file.name):
                try:
                    os.unlink(temp_file.name)
                except Exception as e:
                    self.logger.error(f"Error cleaning up temporary file: {str(e)}")


class DeviceRebootJob(Job):
    """
    Job to reboot network device using python.
    """
    # Define job variables that will appear in the Nautobot UI
    device_ip = StringVar(
        description="IP address of the device to reboot",
        required=True
    )
    
    tftp_server = StringVar(
        description="TFTP server IP address",
        required=True
    )
    
    tftp_path = StringVar(
        description="Path on TFTP server where files are stored",
        required=True
    )
    
    vrf_name = StringVar(
        description="VRF name to use for TFTP transfer (leave blank if not required)",
        default="",
        required=False
    )

    auth_method = ChoiceVar(
        description="Authentication method",
        choices=(
            ('SSH', 'SSH'),
            ('Telnet', 'Telnet')
        ),
        default='SSH'
    )
    
    credential_profile = StringVar(
        description="Credentials profile to use",
        default="default"
    )
    
    
    ansible_server = StringVar(
        description="Ansible server IP address",
        default="172.21.17.41"
    )

    ansible_server_user = StringVar(
        description="Username for Ansible server",
        default="ubuntu"
    )
    
    ansible_server_password = StringVar(
        description="Password for Ansible server",
        default=""
    )
    
    # Use Nautobot's built-in dry run functionality
    dryrun = BooleanVar(
        description="Test mode - no changes will be made",
        default=True
    )
    
    # All required validations will be performed by default - remove 'hidden' parameter
    check_memory = BooleanVar(
        description="Verify free flash memory",
        default=True
    )
    
    check_compatibility = BooleanVar(
        description="Verify IOS compatibility",
        default=True
    )
    
    backup_config = BooleanVar(
        description="Backup configuration",
        default=True
    )
    
    verify_boot = BooleanVar(
        description="Verify boot success",
        default=True
    )
    
    verify_features = BooleanVar(
        description="Verify features post-reboot",
        default=True
    )
    
    executionMode = StringVar(
        description="Execution Mode Serial/Parellel",
        default=True
    )
    email_receiver = StringVar(
        description= "Enter receiver Email",
        default=True,
    )
    class Meta:
        name = "Device Reboot"
        description = "Reboot network devices using Ansible playbooks / Python Scripts"
        has_sensitive_variables = True  # Mark as having sensitive variables
        field_order = [
            'device_ip', 'tftp_server', 'tftp_path', 
             'vrf_name', 'auth_method', 'credential_profile',
             'ansible_server','ansible_server_user', 
             'ansible_server_password', 'dryrun','executionMode','email_receiver'
        ]
    
    def run(self, data=None, commit=None, **kwargs):
        """
        Run the device reboot job.
        """
        import naas.constants
        from pathlib import Path
        import re
        # Log what we received for debugging
        self.logger.info(f"Run method received data and kwargs (sensitive values redacted)")
        # If we received individual parameters instead of a data dict, build the data dict
        if data is None:
            data = kwargs
        temp_file = None
        
        # Extract variables from data - with error handling
        try:
            vars_content = ''
            final_output = ''
            device_ip_list = []
            device_ips = data.get('device_ip', kwargs.get('device_ip', ''))
            

            executionMode = data.get('executionMode',kwargs.get('executionMode','serial'))
            if executionMode == 'serial':
                device_ip_list = device_ips
            else:
                device_ip_list.append(device_ips)
            tftp_server = data.get('tftp_server', kwargs.get('tftp_server', '172.21.17.41'))

            tftp_path = data.get('tftp_path', kwargs.get('tftp_path', ''))
            
            change_number = data.get('change_number', kwargs.get('change_number', ''))
            vrf_name = data.get('vrf_name', kwargs.get('vrf_name', ''))
            
            # Email settings
            smtp_server = data.get('smtp_server', kwargs.get('smtp_server', 'smtp.gmail.com'))
            email_sender = data.get('email_sender', kwargs.get('email_sender', 'no-reply@hcltech.com'))
            email_receiver = data.get('email_receiver', kwargs.get('email_receiver', 'vidhiprakashb.sampa@hcltech.com'))
            #email_part1 = data.get('email_part1',kwargs.get('email_part1','vidhiprakashb.sampa'))
            #email_part2 = data.get('email_part2',kwargs.get('email_part2','hcltech.com'))
            #email_receiver = email_part1+'@'+email_part2
            auth_method = data.get('auth_method', kwargs.get('auth_method', 'SSH'))
            credential_profile = data.get('credential_profile', kwargs.get('credential_profile', 'default'))
            
            # Get Ansible server details
            ansible_server = data.get('ansible_server', kwargs.get('ansible_server', '172.21.17.41'))
            user = ansible_server_user = data.get('ansible_server_user', kwargs.get('ansible_server_user', 'ubuntu'))
            passwd = ansible_server_password = data.get('ansible_server_password', kwargs.get('ansible_server_password', 'Passw0rd@123'))
            
            # Set dry run from the form if provided, otherwise use the commit parameter
            dry_run = data.get('dryrun', not bool(commit))
            
            # Get credentials from credential profile or environment
            if credential_profile == 'default':
                user = ansible_user = os.environ.get('ANSIBLE_USER', 'netadmin')
                passwd = ansible_password = os.environ.get('ANSIBLE_PASSWORD', 'netadmin@hcl')
            else:
                # Get credentials from Nautobot secrets or other source
                self.logger.info(f"Using credential profile: {credential_profile}")
                user = ansible_user = "netadmin"  # Replace with actual credential retrieval
                passwd = ansible_password = "netadmin@hcl"  # Replace with actual credential retrieval
            
            # Create unique filenames with timestamp to avoid conflicts
            timestamp = int(time.time())
            job_id = str(kwargs.get('job_id', timestamp))
            
            '''
            Reboot code starts
            '''
            reboot_commands = naas.constants.reboot_const['Catalyst']['reboot']
            post_run_commands = naas.constants.reboot_const['Catalyst']['post_check']
            
            if dry_run:
                self.logger.info('Dry Run')
                reboot_commands = []
            
            for device_ip in device_ip_list:
                tftp_filename = device_ip+'_config.cfg'
                current_dir = Path(__file__).parent
                tmp_dir = current_dir / 'tmp_files'
                output_file_name = device_ip+'_postcheck.txt'
                if os.path.exists(tmp_dir / output_file_name):
                    self.logger.info('Removing Old file.')
                    os.remove(tmp_dir / output_file_name)
                precheck_file_name = device_ip+'_precheck.txt'
                output_file = tmp_dir / output_file_name
                precheck_output_file = tmp_dir / precheck_file_name
                tftp_backup_command = f"copy running-config tftp://{tftp_server}/{tftp_filename}"
                if vrf_name is not None:
                    tftp_backup_command += f" vrf {vrf_name}"
                client = paramiko.SSHClient()
                client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
                client.connect(device_ip, username=user, password=passwd, port=22, timeout=30)
                print(f"Successfully connected to {device_ip}")
                
                ssh_shell = client.invoke_shell()
                time.sleep(3)
                # Start - Before Reboot take backup on tftp
                self.logger.info('Backup Process will be start on tftp server')
                ssh_shell.send(tftp_backup_command + "\n")
                time.sleep(2)

                # Handle TFTP confirmation prompts if needed
                tftp_output = ssh_shell.recv(5000).decode('utf-8')
                if "Address or name of remote host" in tftp_output:
                    ssh_shell.send(tftp_server + "\n")
                    time.sleep(2)
                    tftp_output += ssh_shell.recv(5000).decode('utf-8')

                if "Destination filename" in tftp_output:
                    #self.logger.info('inside Destination filename')
                    ssh_shell.send(tftp_filename + "\n")
                    time.sleep(2)
                time.sleep(10)
                # Receive final output
                tftp_output += ssh_shell.recv(5000).decode('utf-8')
                self.logger.info(f"TFTP Final output: {tftp_output}")
                # End - Before Reboot take backup on tftp
                ssh_shell.send(b"terminal length 0\n")
                time.sleep(3)
                for command in reboot_commands:
                    ssh_shell.send(command.encode() + b'\n')
                    time.sleep(2) 
                    output = ""
                    while ssh_shell.recv_ready():
                        output += ssh_shell.recv(65535).decode().lower()
                    print(f"Output of '{command}':\n{output}")
                    if "y/n" in output:
                        ssh_shell.send(b"y\n")
                        time.sleep(1)
                    elif "confirm" in output:
                        ssh_shell.send(b"\n") 
                        time.sleep(2)
                    else :
                        ssh_shell.send(b"\n") 
                    time.sleep(2) 
                    final_output = ""
                    while ssh_shell.recv_ready():
                        final_output += ssh_shell.recv(65535).decode()
                
                time.sleep(5)
                client.close()
                self.logger.info("Going to sleep for 5 mins after reboot...")
                if not dry_run:
                    #self.logger.info('Dry Run')
                    time.sleep(300)
                self.logger.info(f"Pinging switch at {device_ip}...")
                ind = 0
                
                while not self.is_up(device_ip,email_receiver):
                    self.logger.info(device_ip+" Switch is still down!")
                    time.sleep(5)
                    ind += 1
                    if ind > 5:
                        self.logger.info("Tried Ping 5 times.")
                        break
                
                self.logger.info(device_ip+" Switch is up!")
                self.logger.info('Connecting device again to do post run')
                ip_result = ''
                client = paramiko.SSHClient()
                client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
                client.connect(device_ip, username=user, password=passwd, port=22, timeout=30)
                ip_result = ip_result + (f"Successfully connected to {device_ip}")
                
                ssh_shell = client.invoke_shell()
                time.sleep(3)
                ssh_shell.send(b"terminal length 0\n")
                time.sleep(3)
                ip_result = ip_result + "Running pre check commands<br/>"
                for key,value in post_run_commands.items():
                    ssh_shell.send(value.encode() + b'\n')
                    time.sleep(4)
                    #output = ""
                    while not ssh_shell.recv_ready():
                        time.sleep(10)
                    while ssh_shell.recv_ready():
                        res = ssh_shell.recv(65535).decode()
                        ip_result += res
                        ansi_escape = re.compile(r'\x1B[@-_][0-?]*[ -/]*[@-~]')
                        cleaned = ansi_escape.sub('', res)
                        cleaned = cleaned.replace('\r', '')
                        with open(output_file, 'a') as f:
                            #print('file created.')
                            f.write(f"Output of '{value}':\n{cleaned}\n")
                            f.write("*" * 100 + "\n")
                    
                    
                client.close()
                self.compare_command_outputs(precheck_output_file, output_file,device_ip,email_receiver)
                
            return True          
        except Exception as e:
            self.logger.error(f"Error during device reboot: {str(e)}")
            return False
        finally:
            # Always clean up the temporary file if it exists
            
            if temp_file and os.path.exists(temp_file.name):
                try:
                    os.unlink(temp_file.name)
                except Exception as e:
                    self.logger.error(f"Error cleaning up temporary file: {str(e)}")
    def is_up(self,ip,receiver):
        mail_already_sent = False
        import os
        import subprocess
        error_to_report = ''
        try:
            result = subprocess.run(
                ["ping", "-c", "1", "-W", "1", ip],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                timeout=5
            )
            return result.returncode == 0
        except subprocess.TimeoutExpired:
            error_to_report = f"Ping to {ip} timed out."
            self.logger.error(error_to_report)
            return False
        finally:
            if error_to_report != '':
                self.send_mail(error_to_report,ip,receiver)
                mail_already_sent = True
    
    def compare_command_outputs(self,before_file, after_file,ip,email_receiver):
        from pathlib import Path
        import difflib
        current_dir = Path(__file__).parent
        tmp_dir = current_dir / 'tmp_files'
        output_file_name = ip+'_comparison_output.txt'
        output_file = tmp_dir / output_file_name

        if os.path.exists(output_file):
            # Remove the file
            self.logger.info('Removing Old comparison file.')
            os.remove(output_file)

        mail_already_sent = False
        error_to_report = '' 
        try:
            def split_into_sections(filename):
                sections = {}
                current_command = None
                current_output = []
        
                with open(filename, 'r') as f:
                    for line in f:
                        stripped_line = line.strip()
                        if stripped_line.startswith('*' * 100): 
                            if current_command: 
                                sections[current_command] = current_output
                            current_command = None  
                            current_output = []
                        elif not current_command: 
                            current_command = stripped_line
                        else:
                            current_output.append(stripped_line)
        
                if current_command:
                    sections[current_command] = current_output
        
                return sections
        
            before_sections = split_into_sections(before_file)
            after_sections = split_into_sections(after_file)
        
            changes_found = False
            output_content = [] 
        
            for command in before_sections.keys() | after_sections.keys():
                before_output = before_sections.get(command, [])
                after_output = after_sections.get(command, [])
        
                diff = list(difflib.ndiff(before_output, after_output))
        
                added, removed, changed = [], [], []
                prev_removed = None 
        
                for line in diff:
                    stripped_line = line[2:].strip()
                    if line.startswith('- '):
                        prev_removed = stripped_line
                    elif line.startswith('+ '):
                        if prev_removed:
                            changed.append((prev_removed, stripped_line))
                            prev_removed = None
                        else:
                            added.append(stripped_line)
                    elif prev_removed:
                        removed.append(prev_removed)
                        prev_removed = None

                if added or removed or changed:
                    changes_found = True 
        
                    output_content.append(f"\n{'#' * 50}\nCommand: {command}\n{'#' * 50}")
        
                    if added:
                        output_content.append("\nAdded:")
                        output_content.append("\n".join(added))
        
                    if removed:
                        output_content.append("\nRemoved:")
                        output_content.append("\n".join(removed))
        
                    if changed:
                        output_content.append("\nChanged:")
                        for old, new in changed:
                            output_content.append(f"Previous: {old}")
                            output_content.append(f"New: {new}\n")
        
            if changes_found:
                file=output_file_name
                compare_file=os.path.join(tmp_dir,file )
                with open(compare_file, "w") as out:
                    out.write("\n".join(output_content) + "\n")
                self.logger.info("Comparison completed. Results saved to "+compare_file)
                self.send_mail(compare_file,ip,email_receiver)
                precheck_file = os.path.join(tmp_dir,ip+'_precheck.txt' )
                postcheck_file = os.path.join(tmp_dir,ip+'_postcheck.txt')
                
                if os.path.exists(precheck_file):
                    # Remove the file
                    os.remove(precheck_file)
                if os.path.exists(postcheck_file):
                    # Remove the file
                    os.remove(postcheck_file)
                if os.path.exists(compare_file):
                    # Remove the file
                    os.remove(compare_file)

            else:
                self.logger.info("Nothing is changed. No output file is created.Kindly check the uptime status whether the reboot activity is completed or not.")
        except IOError as e:
            self.logger.info(f"File I/O error: {e}")
            error_to_report = f"IO Error: {e}"
            return False
        except Exception as e:
            self.logger.info(f"Error executing commands: {e}")
            error_to_report = f"{type(e).__name__}: {e}"
            return False
        finally:
            if error_to_report:
                self.send_mail(error_to_report,ip,email_receiver)
                mail_already_sent = True

    def send_mail(self,data,ip,receiver):
        import naas.constants
        import smtplib
        from email.mime.text import MIMEText
        from email.mime.multipart import MIMEMultipart
        from email.message import EmailMessage 

        try: 
            smtp_server = naas.constants.smtp_lib_server
            smtp_port = naas.constants.smtp_port
            sender = username = naas.constants.sender_email
            password = naas.constants.sender_password

            if isinstance(data, str) and os.path.isfile(data) and data.endswith(".txt"):
                
                with open(data, "rb") as f:
                    subject = ip+ " : Comparision file"
                    body='PFA the comparison output.'
                    msg = EmailMessage()
                    msg["From"] = sender
                    msg["To"] = receiver
                    msg["Subject"] = subject
                    msg.set_content(body)
                    msg.add_attachment(f.read(), maintype="text", subtype="plain", filename=ip+'_Comparision.txt')
                
            else:
                subject = data+" : Error Mail"
                body=data
                msg = MIMEMultipart()
                msg['From'] = sender
                msg['To'] = receiver
                msg['Subject'] = subject
                msg.attach(MIMEText(body, 'plain'))

            with smtplib.SMTP(smtp_server, smtp_port) as server:
                server.starttls()
                server.login(username, password) 
                server.send_message(msg)
                #receiver_lst = receiver.split('@')
                #+receiver_lst[0]+'@'+receiver_lst[1]
            self.logger.info("Email sent! ")
        except Exception as e:
            self.logger.info(f"Error executing commands: {e}")


class DeviceF5ConfigJob(Job):
    """
    Job to configure F5 devices using python integration scripts.
    """
    
    # F5 Device Connection Details
    f5_ip = StringVar(
        description="F5 device IP address or FQDN",
        required=True
    )
    
    f5_username = StringVar(
        description="F5 admin username",
        default="admin",
        required=True
    )
    
    f5_password = StringVar(
        description="F5 admin password",
        required=True
    )
    
    # Operation Type
    operation = ChoiceVar(
        description="F5 operation to perform",
        choices=(
            ('create_vip', 'Create VIP'),
            ('create_pool', 'Create Pool'),
            ('modify_pool', 'Modify Pool'),
            ('vip_validation', 'VIP Validation')
        ),
        required=True
    )
    
    # Configuration Data (JSON)
    config_data = StringVar(
        description="F5 configuration data (JSON format)",
        required=True
    )
    
    # Email settings
    email_receiver = StringVar(
        description="Email receiver for notifications",
        required=True
    )
    
    # Dry run option
    dryrun = BooleanVar(
        description="Test mode - no changes will be made",
        default=False
    )
    
    class Meta:
        name = "F5 Configuration"
        description = "Configure F5 devices using automation scripts"
        has_sensitive_variables = True
        field_order = [
            'f5_ip', 'f5_username', 'f5_password', 'operation', 
            'config_data', 'email_receiver', 'dryrun'
        ]
    
    def run(self, data=None, commit=None, **kwargs):
        """
        Run the F5 configuration job.
        """
        import naas.constants
        from pathlib import Path
        
        # Log what we received for debugging
        self.logger.info(f"F5 Job started - Operation: {kwargs.get('operation')}")
        
        if data is None:
            data = kwargs

        cr_number = data.get('cr_number', kwargs.get('cr_number'))
        
        try:
            # Extract variables from data
            f5_ip = data.get('f5_ip', kwargs.get('f5_ip'))
            f5_username = data.get('f5_username', kwargs.get('f5_username', 'admin'))
            f5_password = data.get('f5_password', kwargs.get('f5_password'))
            operation = data.get('operation', kwargs.get('operation'))
            config_data_str = data.get('config_data', kwargs.get('config_data', '{}'))
            email_receiver = data.get('email_receiver', kwargs.get('email_receiver'))
            dry_run = data.get('dryrun', kwargs.get('dryrun', False))
            
            # Parse configuration data
            try:
                config_data = json.loads(config_data_str) if isinstance(config_data_str, str) else config_data_str
            except json.JSONDecodeError as e:
                self.logger.error(f"Invalid JSON in config_data: {e}")
                return False
            
            self.logger.info(f"F5 Device: {f5_ip}, Operation: {operation}")
            self.logger.info(f"Dry Run: {dry_run}")
            
            # Import F5 class (make sure this is available in your environment)
            try:
                from .f5_bigip import F5Bigip  # Adjust import path as needed
            except ImportError:
                self.logger.error("F5Bigip class not found. Make sure f5_bigip.py is in the correct location.")
                return False
            
            # Connect to F5 device
            self.logger.info(f"Connecting to F5 device: {f5_ip}")
            f5bigip = F5Bigip(f5_ip, f5_username, f5_password)
            
            # Check if F5 is active/standalone
            if not f5bigip.check_standby():
                error_msg = "F5 is not the active or standalone device. Please connect to Active F5."
                self.logger.error(error_msg)
                self.send_error_email(error_msg, email_receiver)
                return False
            
            self.logger.info(f"Connected to Active F5: {f5_ip}")
            
            # Execute the appropriate operation
            result = self.execute_f5_operation(f5bigip, operation, config_data, dry_run)
            
            if result['success']:
                self.logger.info(f"F5 operation completed successfully: {result['message']}")
                self.send_success_email(operation, result['message'], email_receiver, f5_ip)
                

                if cr_number and not dry_run:
                    cr_update_result = self.update_servicenow_cr(
                        cr_number=cr_number,
                        status='completed',
                        work_notes=f"F5 {operation} completed successfully. {result['message']}",
                        close_code='successful',
                        close_notes=f"Automated F5 configuration completed at {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
                    )
                    self.logger.info(f"ServiceNow CR update result: {cr_update_result}")
                
                # Trigger sync if not dry run
                if not dry_run:
                    sync_result = f5bigip.verify_sync_status()
                    self.logger.info(f"F5 sync status: {sync_result}")
                
                return True
            else:
                self.logger.error(f"F5 operation failed: {result['message']}")
                self.send_error_email(f"F5 {operation} failed: {result['message']}", email_receiver)

                # Update ServiceNow CR with failure details
                if cr_number:
                    cr_update_result = self.update_servicenow_cr(
                        cr_number=cr_number,
                        status='failed',
                        work_notes=f"F5 {operation} failed: {result['message']}",
                        close_code='unsuccessful',
                        close_notes=f"Automated F5 configuration failed at {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
                    )
                    self.logger.info(f"ServiceNow CR update result: {cr_update_result}")
                
                return False
                
        except Exception as e:
            error_msg = f"Error during F5 configuration: {str(e)}"
            self.logger.error(error_msg)
            self.send_error_email(error_msg, email_receiver)

            if cr_number:
                cr_update_result = self.update_servicenow_cr(
                    cr_number=cr_number,
                    status='failed',
                    work_notes=f"F5 configuration error: {str(e)}",
                    close_code='unsuccessful',
                    close_notes=f"Automated F5 configuration encountered an error at {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
                )
                self.logger.info(f"ServiceNow CR update result: {cr_update_result}")
            
            return False
        
    def update_servicenow_cr(self, cr_number, status, work_notes, close_code=None, close_notes=None):
        """
        Update ServiceNow Change Request status and add work notes
        """
        try:
            # ServiceNow API configuration (add these to your settings/constants)
            from dotenv import load_dotenv
            load_dotenv()

            snow_instance = os.getenv('SERVICENOW_INSTANCE', 'hclpocm1.service-now.com')
            snow_username = os.getenv('SERVICENOW_USERNAME')
            snow_password = os.getenv('SERVICENOW_PASSWORD')
            
            # ServiceNow API endpoint
            url = f"https://{snow_instance}/api/now/table/change_request"
            
            # Headers
            headers = {
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            }
            
            # Authentication
            auth = (snow_username, snow_password)
            
            # First, get the CR sys_id using the CR number
            params = {
                'sysparm_query': f'number={cr_number}',
                'sysparm_fields': 'sys_id,state,number'
            }
            
            response = requests.get(url, headers=headers, auth=auth, params=params)
            
            if response.status_code != 200:
                self.logger.error(f"Failed to find CR {cr_number}: {response.status_code} - {response.text}")
                return {'success': False, 'message': f'CR not found: {response.text}'}
            
            cr_data = response.json()
            
            if not cr_data.get('result'):
                self.logger.error(f"CR {cr_number} not found in ServiceNow")
                return {'success': False, 'message': 'CR not found'}
            
            sys_id = cr_data['result'][0]['sys_id']
            current_state = cr_data['result'][0]['state']
            
            self.logger.info(f"Found CR {cr_number} with sys_id: {sys_id}, current state: {current_state}")
            
            # Prepare update data
            update_data = {
                'work_notes': work_notes
            }
            
            # Set status based on operation result
            if status == 'completed':
                # ServiceNow CR states (adjust these values based on your ServiceNow configuration)
                update_data['state'] = '3'  # Implement state
                update_data['u_implementation_status'] = 'completed'
                
                if close_code and close_notes:
                    update_data['close_code'] = close_code
                    update_data['close_notes'] = close_notes
                    update_data['state'] = '7'  # Closed state
                    
            elif status == 'failed':
                update_data['state'] = '4'  # Canceled/Failed state
                update_data['u_implementation_status'] = 'failed'
                
                if close_code and close_notes:
                    update_data['close_code'] = close_code
                    update_data['close_notes'] = close_notes
            
            # Update the CR
            update_url = f"{url}/{sys_id}"
            update_response = requests.put(
                update_url, 
                headers=headers, 
                auth=auth, 
                data=json.dumps(update_data)
            )
            
            if update_response.status_code == 200:
                self.logger.info(f"Successfully updated CR {cr_number} to status: {status}")
                return {'success': True, 'message': f'CR {cr_number} updated successfully'}
            else:
                self.logger.error(f"Failed to update CR {cr_number}: {update_response.status_code} - {update_response.text}")
                return {'success': False, 'message': f'Update failed: {update_response.text}'}
                
        except Exception as e:
            self.logger.error(f"Error updating ServiceNow CR {cr_number}: {str(e)}")
            return {'success': False, 'message': f'Update error: {str(e)}'}
    
    def get_cr_from_approval_request(self, approval_id=None):
        """
        Helper method to get CR number from approval request if needed
        """
        try:
            if approval_id:
                # Query your approval model to get CR number
                from naas.models import F5ApprovalRequest
                approval = F5ApprovalRequest.objects.get(id=approval_id)
                return approval.cr_number
        except Exception as e:
            self.logger.error(f"Error getting CR from approval: {str(e)}")
        return None
    
    def execute_f5_operation(self, f5bigip, operation, config_data, dry_run):
        """Execute the specific F5 operation based on the operation type"""
        
        try:
            if operation == 'create_vip':
                return self.create_vip(f5bigip, config_data, dry_run)
            elif operation == 'create_pool':
                return self.create_pool(f5bigip, config_data, dry_run)
            elif operation == 'modify_pool':
                return self.modify_pool(f5bigip, config_data, dry_run)
            elif operation == 'vip_validation':
                return self.validate_vip(f5bigip, config_data)
            else:
                return {'success': False, 'message': f'Unknown operation: {operation}'}
                
        except Exception as e:
            return {'success': False, 'message': f'Operation {operation} failed: {str(e)}'}
    
    def create_vip(self, f5bigip, config_data, dry_run):
        """Create VIP on F5 device"""
        self.logger.info("Starting VIP creation")
        
        try:
            # Convert ServiceNow parsed data to F5 format
            vip_config = {
                'name': config_data.get('name'),
                'partition': config_data.get('partition', 'Common'),
                'description': config_data.get('description', ''),
                'destination': config_data.get('destination'),
                'mask': config_data.get('mask', '255.255.255.255'),
                'source': config_data.get('source', '0.0.0.0/0'),
                'pool': config_data.get('pool'),
                'ipProtocol': config_data.get('ipProtocol', 'tcp'),
                'profiles': []
            }
            
            # Add SNAT pool if specified
            if config_data.get('snatpool'):
                vip_config['snatpool'] = config_data.get('snatpool')
            
            # Process profiles
            profiles = config_data.get('profiles', {})
            if profiles:
                # Add TCP profiles
                if profiles.get('tcp_client'):
                    vip_config['profiles'].append({
                        'name': profiles['tcp_client'].replace('/Common/', ''),
                        'context': 'clientside'
                    })
                
                if profiles.get('tcp_server'):
                    vip_config['profiles'].append({
                        'name': profiles['tcp_server'].replace('/Common/', ''),
                        'context': 'serverside'
                    })
                
                # Add HTTP profiles
                if profiles.get('http_client'):
                    vip_config['profiles'].append({
                        'name': profiles['http_client'].replace('/Common/', '')
                    })
                
                # Add SSL profiles
                if profiles.get('ssl_client'):
                    vip_config['profiles'].append({
                        'name': profiles['ssl_client'].replace('/Common/', ''),
                        'context': 'clientside'
                    })
                
                if profiles.get('ssl_server'):
                    vip_config['profiles'].append({
                        'name': profiles['ssl_server'].replace('/Common/', ''),
                        'context': 'serverside'
                    })
            
            if dry_run:
                return {'success': True, 'message': f'DRY RUN: VIP {vip_config["name"]} would be created with config: {vip_config}'}
            
            # Create VIP using F5 SDK
            result = f5bigip.vip_creation(**vip_config)
            
            if "successfully" in result.lower():
                return {'success': True, 'message': result}
            else:
                return {'success': False, 'message': result}
                
        except Exception as e:
            return {'success': False, 'message': f'VIP creation error: {str(e)}'}
    
    def create_pool(self, f5bigip, config_data, dry_run):
        """Create Pool on F5 device"""
        self.logger.info("Starting Pool creation")
        
        try:
            pool_config = {
                'name': config_data.get('pool_name'),
                'description': config_data.get('description', ''),
                'loadBalancingMode': config_data.get('load_balancing_mode', 'round-robin'),
                'member': []
            }
            
            # Process pool members
            pool_members = config_data.get('pool_members', '')
            if pool_members:
                for line in pool_members.split('\n'):
                    member = line.strip()
                    if member:
                        pool_config['member'].append({'name': member})
            
            partition = config_data.get('partition', 'Common')
            
            if dry_run:
                return {'success': True, 'message': f'DRY RUN: Pool {pool_config["name"]} would be created with {len(pool_config["member"])} members'}
            
            # Create Pool using F5 SDK
            result = f5bigip.pool_creation(partition=partition, **pool_config)
            
            if "successfully" in result.lower():
                return {'success': True, 'message': result}
            else:
                return {'success': False, 'message': result}
                
        except Exception as e:
            return {'success': False, 'message': f'Pool creation error: {str(e)}'}
    
    def modify_pool(self, f5bigip, config_data, dry_run):
        """Modify Pool on F5 device"""
        self.logger.info("Starting Pool modification")
        
        try:
            pool_modifications = []
            partition = config_data.get('partition', 'Common')
            pool_name = config_data.get('pool_name')
            
            # Process pool member modifications
            modifications = config_data.get('pool_member_modifications', '')
            if modifications:
                members = []
                for line in modifications.split('\n'):
                    line = line.strip()
                    if line and ',' in line:
                        member_name, action = line.split(',', 1)
                        members.append({
                            'name': member_name.strip(),
                            'action': action.strip()
                        })
                
                pool_modifications.append({
                    'name': pool_name,
                    'member': members
                })
            
            if dry_run:
                return {'success': True, 'message': f'DRY RUN: Pool {pool_name} would be modified with {len(pool_modifications[0]["member"])} member changes'}
            
            # Modify Pool using F5 SDK
            result = f5bigip.pool_modification(partition, pool_modifications)
            
            success_count = sum(1 for item in result if 'successfully' in item['Action'].lower())
            total_count = len(result)
            
            if success_count == total_count:
                return {'success': True, 'message': f'All {total_count} pool modifications completed successfully'}
            else:
                failed_items = [item for item in result if 'successfully' not in item['Action'].lower()]
                return {'success': False, 'message': f'{success_count}/{total_count} modifications succeeded. Failures: {failed_items}'}
                
        except Exception as e:
            return {'success': False, 'message': f'Pool modification error: {str(e)}'}
    
    def validate_vip(self, f5bigip, config_data):
        """Validate VIP on F5 device"""
        self.logger.info("Starting VIP validation")
        
        try:
            partition = config_data.get('partition', 'Common')
            vip_names = config_data.get('vip_names', [])
            
            if isinstance(vip_names, str):
                vip_names = [name.strip() for name in vip_names.split(',')]
            
            # Validate VIPs using F5 SDK
            vip_stats, vip_groups = f5bigip.vip_validation(partition, vip_names)
            
            # Format results
            results = []
            for vip in vip_stats:
                results.append(f"VIP {partition}/{vip['name']}: {vip['state']} - {vip['remarks']}")
            
            return {'success': True, 'message': '\n'.join(results)}
                
        except Exception as e:
            return {'success': False, 'message': f'VIP validation error: {str(e)}'}
    
    def send_success_email(self, operation, message, email_receiver, f5_ip):
        """Send success notification email"""
        try:
            self.send_email(
                subject=f"F5 {operation} - Success",
                body=f"F5 operation completed successfully on {f5_ip}:\n\n{message}",
                receiver=email_receiver
            )
        except Exception as e:
            self.logger.error(f"Error sending success email: {e}")
    
    def send_error_email(self, error_message, email_receiver):
        """Send error notification email"""
        try:
            self.send_email(
                subject="F5 Configuration - Error",
                body=f"F5 operation failed:\n\n{error_message}",
                receiver=email_receiver
            )
        except Exception as e:
            self.logger.error(f"Error sending error email: {e}")
    
    def send_email(self, subject, body, receiver):
        """Send email notification"""
        import naas.constants
        import smtplib
        from email.mime.text import MIMEText
        from email.mime.multipart import MIMEMultipart
        
        try:
            smtp_server = naas.constants.smtp_lib_server
            smtp_port = naas.constants.smtp_port
            sender = naas.constants.sender_email
            password = naas.constants.sender_password
            
            msg = MIMEMultipart()
            msg['From'] = sender
            msg['To'] = receiver
            msg['Subject'] = subject
            msg.attach(MIMEText(body, 'plain'))
            
            with smtplib.SMTP(smtp_server, smtp_port) as server:
                server.starttls()
                server.login(sender, password)
                server.send_message(msg)
            
            self.logger.info("Email notification sent successfully")
            
        except Exception as e:
            self.logger.error(f"Error sending email: {e}")