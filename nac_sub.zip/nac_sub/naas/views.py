from django.shortcuts import render, redirect, get_object_or_404
from django.http import JsonResponse, HttpResponseRedirect, HttpResponse
from django.core.serializers import serialize
from nautobot.dcim.models import DeviceType, Rack, Device
from nautobot.dcim.models import Location, LocationType
from nautobot.ipam.models import VLAN, Prefix
from nautobot.extras.models import Tag, Status
from django.urls import reverse
import paramiko
from django.utils import timezone
from django.core.mail import send_mail
from django.template.loader import render_to_string
from django.contrib import messages
import urllib3
from dotenv import load_dotenv
from django.db import connection
from .forms import SiteOnboardingForm, DeviceForm, MultiVLANConfigurationForm, ACIConfigForm, MultiF5OperationForm
from django.http import JsonResponse
from nautobot.cloud.models import CloudService
import json
from django.core.exceptions import ObjectDoesNotExist
from uuid import UUID, uuid4
import jinja2
from django.template import loader
from netmiko import ConnectHandler, NetMikoTimeoutException, NetMikoAuthenticationException
import requests
from requests.auth import HTTPBasicAuth
import re
import yaml
import os
from github import Github
from django.http import JsonResponse
from django.contrib.auth.decorators import login_required, permission_required
from django.views.decorators.csrf import csrf_exempt, csrf_protect
from django.views.decorators.http import require_GET, require_POST,require_http_methods
import logging
from django.utils.safestring import mark_safe
from nautobot.core.views.generic import GenericView
from django.utils.decorators import method_decorator
from .models import UpgradeApprovalRequest as UpgradeApproval
from .models import RebootApprovalRequest
from .models import F5ApprovalRequest as F5Approval
import datetime
from datetime import timedelta
from .config_generator import ConfigGenerator

from nautobot.extras.models import JobResult, Job

from .utils import F5VIPSNOWDescriptionParser

from rest_framework.generics import GenericAPIView
from rest_framework.response import Response
from nautobot.ipam.models import IPAddress
from nautobot.extras.models import Tag
from django.db.models import Count
from naas.utils import start_ios_upgrade, deploy_vlan_configs, get_device_connection
from naas.utils import fetch_devices, start_ios_upgrade, deploy_vlan_configs

from github import GithubException

from nautobot.dcim.models import  Location, Device as NautobotDevice, DeviceType, Rack
from nautobot.extras.models import Role

from nautobot.ipam.models import Prefix, VLAN
from nautobot.extras.models import JobResult, Job
from jinja2 import Template
from jinja2 import Environment, BaseLoader

logger = logging.getLogger(__name__)

# Define the active status value
ACTIVE_STATUS_NAME = 'Active'  
UNUSED_TAG_NAME = 'unused'
APIC_IP = "sandboxapicdc.cisco.com"
TEMPLATE_FILE = 'config_template.j2'
RESULT_FILE = 'aci_results.xml'
USR = os.environ.get('ACI_USER_ID', '')
PWD = os.environ.get('ACI_PWD', '')


logger = logging.getLogger(__name__)

def site_onboarding_view(request):
    if request.method == "POST":
        form = SiteOnboardingForm(request.POST)
        if form.is_valid():
            try:
                router_quantity = int(request.POST.get("router_quantity", "0").strip() or 0)
                switch_quantity = int(request.POST.get("switch_quantity", "0").strip() or 0)
                prefix_quantity = int(request.POST.get("prefix_quantity", "0").strip() or 0)
                site_onboarding = form.save()
            except ValueError as e:
                return JsonResponse({"error": f"Invalid input: {e}"}, status=400)

            # Handle router devices
            for i in range(router_quantity):
                device_form = DeviceForm({
                    'name': request.POST.get(f'router_name_{i}', '').strip(),
                    'device_type': request.POST.get(f'router_device_type_{i}', None),
                    'rack': request.POST.get(f'router_rack_{i}', None),
                    'tags': request.POST.getlist(f'router_tags_{i}', []),
                    'serial_number': request.POST.get(f'router_serial_number_{i}', '').strip(),
                    'management_ip_address': request.POST.get(f'router_mgmt_ip_{i}', '').strip(),
                })
                if device_form.is_valid():
                    device = device_form.save(commit=False)
                    device.site_onboarding = site_onboarding
                    device.save()
                    device.tags.set(device_form.cleaned_data['tags'])

            # Handle switch devices
            for i in range(switch_quantity):
                device_form = DeviceForm({
                    'name': request.POST.get(f'switch_name_{i}'),
                    'device_type': request.POST.get(f'switch_device_type_{i}'),
                    'rack': request.POST.get(f'switch_rack_{i}'),
                    'tags': request.POST.getlist(f'switch_tags_{i}'),
                    'serial_number': request.POST.get(f'switch_serial_number_{i}'),
                    'management_ip_address': request.POST.get(f'switch_mgmt_ip_{i}')
                })
                if device_form.is_valid():
                    device = device_form.save(commit=False)
                    device.site_onboarding = site_onboarding
                    device.save()
                    device.tags.set(device_form.cleaned_data['tags'])

            return redirect('naas:site_onboarding')  # Replace 'success_url' with   success URL
    else:
        form = SiteOnboardingForm()

    device_types_json = serialize('json', DeviceType.objects.all())
    racks_json = serialize('json', Rack.objects.filter(status__name=ACTIVE_STATUS_NAME, tags__name=UNUSED_TAG_NAME))
    prefixes_json = serialize('json', Prefix.objects.filter(status__name=ACTIVE_STATUS_NAME, tags__name=UNUSED_TAG_NAME))
    vlans_json = serialize('json', VLAN.objects.filter(status__name=ACTIVE_STATUS_NAME, tags__name=UNUSED_TAG_NAME))

    # Get tags for devices
    device_tags = Tag.objects.get_for_model(Device)
    device_tags_json = serialize('json', device_tags)

    # Get tags for prefixes
    prefix_tags = Tag.objects.get_for_model(Prefix)
    prefix_tags_json = serialize('json', prefix_tags)

    # Get tags for cloud services
    cloud_service_tags = Tag.objects.get_for_model(CloudService)
    cloud_service_tags_json = serialize('json', cloud_service_tags)

    return render(request, 'naas/naas.html', {
        'form': form,
        'device_types_json': device_types_json,
        'racks_json': racks_json,
        'tags_json': device_tags_json,
        'prefixes_json': prefixes_json,
        'vlans_json': vlans_json,
        'prefix_tags_json': prefix_tags_json,
        'cloud_service_tags_json': cloud_service_tags_json,
    })

def is_valid_uuid(value):
    try:
        UUID(str(value))
        return True
    except ValueError:
        return False

def form_config_view(request):
    if request.method == 'POST':
        form_data = json.loads(request.body)
        return JsonResponse(form_data)
    else:
        form_data = json.loads(request.GET.get('data', '{}'))
        
        # Fetch actual values from the database
        for key, value in form_data.items():
            if key == 'csrfmiddlewaretoken':
                continue  # Skip the CSRF token
            if is_valid_uuid(value):
                try:
                    if key == 'location':
                        form_data[key] = Location.objects.get(pk=value).name
                    elif key.startswith('device_type_'):
                        form_data[key] = DeviceType.objects.get(pk=value).model
                    elif key.startswith('rack_'):
                        form_data[key] = Rack.objects.get(pk=value).name
                    elif key.startswith('tags_') or key == 'site_tags':
                        form_data[key] = Tag.objects.get(pk=value).name
                    elif key.startswith('prefix_'):
                        form_data[key] = Prefix.objects.get(pk=value).prefix
                    elif key.startswith('vlan_'):
                        form_data[key] = VLAN.objects.get(pk=value).name
                    elif key.startswith('prefix_tags_'):
                        form_data[key] = Tag.objects.get(pk=value).name
                except ObjectDoesNotExist:
                    form_data[key] = 'Not Found'
            else:
                # Handle non-UUID values if necessary
                form_data[key] = value

@login_required
def vlan_config_view(request):
    form = MultiVLANConfigurationForm()
    return render(request, 'naas/vlan_config.html', {'form': form})


@login_required
def f5_big_ip_config_view(request):
    form = MultiVLANConfigurationForm()
    return render(request, 'naas/f5_bigip_config.html', {'form': form})


def vlan_config_preview(request):
    if request.method == 'POST':
        form = MultiVLANConfigurationForm(data=request.POST)
        if form.is_valid():
            configs = []
            for row_data in form.cleaned_data():
                vlan = VLAN.objects.get(id=row_data['vlan'].id)

                # Extract and calculate the ip_with_subnet value
                gateway_ip = row_data.get('gateway_ip', '')
                subnet = str(row_data.get('subnet', ''))
                ip_with_subnet = f"{gateway_ip}/{subnet.rsplit('/')[-1]}" if gateway_ip and subnet else ''

                sanitized_switch_ip = row_data['switch_ip'].replace('.', '_')

                config = {
                    'switch_ip': row_data['switch_ip'],
                    'vlan': vlan.vid,  # Use the VLAN's numeric ID
                    'admin_state': row_data['admin_state'],
                    'vlan_description': row_data.get('vlan_description', ''),
                    'subnet': str(row_data.get('subnet', '')),
                    'gateway_ip': row_data.get('gateway_ip', ''),
                    'ip_with_subnet': ip_with_subnet,
                    'mtu_size': row_data.get('mtu_size', ''),
                    'sanitized_switch_ip' :sanitized_switch_ip
                }
                configs.append(config)
            
            if configs:
                return render(request, 'naas/vlan_config_preview.jinja2', {
                    'configs': configs,
                    'configs_json': json.dumps(configs)
                })
        
        # If form is invalid or no configs, return to form with errors
        return render(request, 'naas/vlan_config.html', {'form': form})
    
    return HttpResponseRedirect(reverse('plugins:naas:vlan-config'))

def get_subnets(request, vlan_id):
    try:
        vlan_uuid = UUID(vlan_id)
        subnets = Prefix.objects.filter(vlan_id=vlan_uuid)
        subnets_data = [{'id': str(subnet.id), 'prefix': str(subnet)} for subnet in subnets]
        return JsonResponse({'subnets': subnets_data})
    except (ValueError, TypeError):
        return JsonResponse({'error': 'Invalid VLAN ID'}, status=400)


@csrf_protect    
def vlan_config_deploy(request):
    if request.method == "POST":
        try:
            configs = json.loads(request.POST.get('configs', '[]'))
            username = os.environ.get('ARISTA_USER_ID', '')
            password = os.environ.get('ARISTA_USER_PWD', '')

            result_data = deploy_vlan_configs(configs, username, password)

            # UI expects template rendering
            return render(request, "naas/vlan_config_response.html", result_data)

        except json.JSONDecodeError:
            return JsonResponse(
                {"status": "error", "message": "Invalid form data"}, status=400
            )
    return JsonResponse({"status": "error", "message": "Invalid request method"}, status=400)

def get_servicenow_change_request(cr_number):
    SERVICENOW_USERNAME = os.getenv('SERVICENOW_USERNAME')
    SERVICENOW_PASSWORD = os.getenv('SERVICENOW_PASSWORD')
    url = f'https://hclpocm1.service-now.com/api/now/table/change_request?sysparm_query=number={cr_number}'
    auth = HTTPBasicAuth(SERVICENOW_USERNAME, SERVICENOW_PASSWORD)
    headers = {
        'Accept': 'application/json'
    }
    response = requests.get(url, auth=auth, headers=headers)
    if response.status_code == 200:
        return response.json()
    else:
        return None

def parse_description(short_description, description):
    parsed_data = {}
    combined_text = f"{short_description}\n{description}"
    if 'ARISTA' in combined_text:
        switch_ip_match = re.search(r'Switch IP:\s*([\d\.]+)', description)
        vlan_match = re.search(r'vlan\s*(\d+)', description, re.IGNORECASE)
        subnet_match = re.search(r'Subnet\s*:\s*([\d\.\/]+)', description)
        gateway_ip_match = re.search(r'GW:\s*([\d\.\/]+)', description)
        description_match = re.search(r'description:\s*(.*)', description, re.IGNORECASE)
        mtu_match = re.search(r'mtu\s*:\s*(\d+)', description, re.IGNORECASE)
        if switch_ip_match:
            parsed_data['switch_ip'] = switch_ip_match.group(1)
        if vlan_match:
            parsed_data['vlan'] = vlan_match.group(1)
        if subnet_match:
            parsed_data['subnet'] = subnet_match.group(1)
        if gateway_ip_match:
            parsed_data['gateway_ip'] = gateway_ip_match.group(1)
        if description_match:
            parsed_data['description'] = description_match.group(1).strip()
        if mtu_match:
            parsed_data['mtu'] = mtu_match.group(1)
    elif 'CISCO' in combined_text and 'ACI' in combined_text:
        fabric_name_match = re.search(r'fabricName:\s*(\S+)', description)
        pod_id_match = re.search(r'podId:\s*(\d+)', description)
        node_id_match = re.search(r'nodeId:\s*(\d+)', description)
        tenant_match = re.search(r'Tenant:\s*(\S+)', description)
        ap_match = re.search(r'AP:\s*(\S+)', description)
        epg_match = re.search(r'EPG:\s*(\S+)', description)
        vlan_match = re.search(r'vlan:\s*(\d+)', description)
        mode_match = re.search(r'mode:\s*(\S+)', description)
        from_port_match = re.search(r'fromPort:\s*(\d+)', description)
        to_port_match = re.search(r'toPort:\s*(\d+)', description)
        if fabric_name_match:
            parsed_data['fabric_name'] = fabric_name_match.group(1)
        if pod_id_match:
            parsed_data['pod_id'] = pod_id_match.group(1)
        if node_id_match:
            parsed_data['node_id'] = node_id_match.group(1)
        if tenant_match:
            parsed_data['tenant'] = tenant_match.group(1)
        if ap_match:
            parsed_data['ap'] = ap_match.group(1)
        if epg_match:
            parsed_data['epg'] = epg_match.group(1)
        if vlan_match:
            parsed_data['vlan'] = vlan_match.group(1)
        if mode_match:
            parsed_data['mode'] = mode_match.group(1)
        if from_port_match:
            parsed_data['from_port'] = from_port_match.group(1)
        if to_port_match:
            parsed_data['to_port'] = to_port_match.group(1)
    return parsed_data

@require_GET
def fetch_change_request(request, cr_number):
    cr_data = get_servicenow_change_request(cr_number)
    description = cr_data['result'][0]['description']
    short_description = cr_data['result'][0]['short_description']

    parsed_data = parse_description(short_description, description)

    if cr_data:
        return JsonResponse({
            'status': 'success',
            'description': 'Title: ' + short_description + '\nDescription: ' + description,
            'parsed_data': parsed_data
        })
    else:
        return JsonResponse({
            'status': 'error',
            'message': 'Change request not found'
        }, status=404)


@csrf_exempt
@require_POST
def log_validator_details(request):
    import json
    data = json.loads(request.body)
    name = data.get('name')
    email = data.get('email')
    employee_id = data.get('employee_id')

    if name and email and employee_id:
        logger.info(f'Validator Name: {name}')
        logger.info(f'Validator Email: {email}')
        logger.info(f'Validator Employee ID: {employee_id}')
        # Send email notification
        try:
            send_email(
                to_email=email,
                subject="VLAN Configuration Validation Completed",
                template_name="emails/vlan_validator_notification.html",
                context={
                    "validator_name": name,
                    "validator_email": email,
                    "validator_employee_id": employee_id,
                },
                action_name="Validator Notification",
            )
        except Exception as e:
            logger.error(f"Failed to send validator email: {str(e)}")
            
        return JsonResponse({'status': 'success'})
    else:
        return JsonResponse({'status': 'error', 'message': 'Invalid data'}, status=400)

@csrf_exempt
@require_POST
def run_command(request):
    data = json.loads(request.body)
    command = data.get('command')
    ip = data.get('ip')
    username = data.get('username')
    password = data.get('password')

    if not command:
        return JsonResponse({'status': 'error', 'message': 'No command provided'}, status=400)

    try:
        with get_device_connection(ip, username, password) as net_connect:
            output = net_connect.send_command(command)
        return JsonResponse({'status': 'success', 'output': output})
    except (NetMikoTimeoutException, NetMikoAuthenticationException) as e:
        logger.error(f'Failed to run command: {e}')
        return JsonResponse({'status': 'error', 'message': str(e)}, status=500)
    
def switches_view(request):
    return render(request, 'naas/switches.html')

def cisco_detailed_view(request):
    return render(request, 'naas/cisco_detailed.html')

def arista_detailed_view(request):
    return render(request, 'naas/arista_detailed.html')

def hpe_detailed_view(request):
    return render(request, 'naas/hpe_detailed.html')

def juniper_detailed_view(request):
    return render(request, 'naas/juniper_detailed.html')

def f5__detailed_view(request):
    return render(request, 'naas/f5_detailed.html')


@csrf_exempt
def aci_config(request):
    if request.method == 'POST':
        form = ACIConfigForm(request.POST)
        if form.is_valid():
            data = form.cleaned_data

            # Define APIC IP and credentials
            apic_ip = "sandboxapicdc.cisco.com"
            usr = os.environ.get('ACI_USER_ID', '')
            pwd = os.environ.get('ACI_PWD', '')

            # Define URL and credentials for RESTAPI authentication
            auth_url = "https://%s/api/aaaLogin.json" % apic_ip
            headers = {'content-type': 'application/json'}
            payload = {
                "aaaUser": {
                    "attributes": {
                        "name": usr,
                        "pwd": pwd
                    }
                }
            }

            # Suppress warnings when restapi uses https with self-signed certificate
            urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

            # Authenticate in APIC and save the security token
            response = requests.post(auth_url, data=json.dumps(payload), headers=headers, verify=False, timeout=10)
            if response.status_code == 200:
                apic_auth_cookie = response.cookies
            else:
                return render(request, 'aci_config.html', {'form': form, 'error': 'Authentication failed'})

            # Read the jinja2 template
            mytemplatefile = 'config_template.j2'
            myjloader = jinja2.FileSystemLoader(os.getcwd())
            myjenv = jinja2.Environment(loader=myjloader, trim_blocks=True, lstrip_blocks=True)
            myjtemplate = myjenv.get_template(mytemplatefile)

            # Prepare data for jinja2 template
            dictforjinja = {
                'fabricName': data['fabricName'],
                'podId': data['podId'],
                'nodeId': data['nodeId'],
                'Tenant': data['Tenant'],
                'AP': data['AP'],
                'EPG': data['EPG'],
                'vlan': data['vlan'],
                'mode': 'regular' if data['mode'] == 'trunk' else 'untagged',
                'fromPort': data['fromPort'],
                'toPort': data['toPort']
            }

            # Generate the XML payload
            myresult = myjtemplate.render(var=dictforjinja)

            # Define POST url for RESTAPI, target the correct EPG object
            post_url = "https://%s/api/mo/uni/tn-%s/ap-%s/epg-%s.xml" % (apic_ip, dictforjinja['Tenant'], dictforjinja['AP'], dictforjinja['EPG'])

            # POST the XML result created from template and data from the form
            headers = {'content-type': 'application/xml'}
            response = requests.post(post_url, data=myresult, cookies=apic_auth_cookie, headers=headers, verify=False, timeout=5)

            if response.status_code == 200:
                return render(request, 'naas/aci_config.html', {'form': form, 'success': 'Configuration applied successfully'})
            else:
                return render(request, 'naas/aci_config.html', {'form': form, 'error': 'Configuration failed'})

    else:
        form = ACIConfigForm()

    return render(request, 'naas/aci_config.html', {'form': form})

def aci_templates_list(request):
    return render(request, 'naas/aci_list_templates.html')

def arista_cn_templates_list(request):
    return render(request, 'naas/arista_cn_templates_list.html')

def f5_bigip_templates_list(request):
    return render(request, 'naas/f5_bigip_templates_list.html')

def cisco_catalyst_templates_list(request):
    return render(request, 'naas/cisco_catalyst_list.html')

def aci_vlan_to_port_form(request):
    if request.method == 'POST':
        form = ACIConfigForm(request.POST)
        if form.is_valid():
            config_data = form.cleaned_data
            config_preview = loader.render_to_string('naas/aci_vlan_to_port.jinja2', {'var': config_data})
            return render(request, 'naas/aci_vlan_to_port_preview.html', {'config_preview': config_preview, 'config_data': config_data})
    else:
        form = ACIConfigForm()
    return render(request, 'naas/aci_vlan_to_port_form.html', {'form': form})

def aci_vlan_to_port_preview(request):
    if request.method == 'POST':
        try:
            print("POST data:", request.POST)
            
            from_port = int(request.POST['fromPort'])
            to_port = int(request.POST['toPort'])
            
            config_data = {
                'tenant': request.POST['tenant'],
                'ap': request.POST['ap'],
                'epg': request.POST['epg'],
                'fromPort': from_port,
                'toPort': to_port,
                'vlan': request.POST['vlan'],
                'mode': request.POST['mode'],
                'podId': request.POST['podId'],
                'nodeId': request.POST['nodeId']
            }
            
            print("Config data:", config_data)
            
            template_context = {
                'var': {
                    **config_data,
                    'port_range': list(range(from_port, to_port + 1))
                }
            }
            
            print("Template context:", template_context)
            
            # Get the absolute path to the template
            template_path = 'naas/aci_vlan_to_port.jinja2'
            print(f"Looking for template at: {template_path}")
            
            try:
                config_preview = loader.render_to_string(
                    template_path,
                    template_context
                )
                print("Rendered config_preview:", config_preview)
                print("Length of config_preview:", len(config_preview))
            except Exception as template_error:
                print("Template rendering error:", str(template_error))
                return HttpResponse(f"Template error: {str(template_error)}")
            
            config_preview = loader.render_to_string(
                template_path,
                template_context
            )
            
            # Try to force string conversion and strip any problematic characters
            config_preview = str(config_preview).strip()
            
            # Add some test content to verify rendering
            #config_preview = "START\n" + config_preview + "\nEND"
            
            context = {
                'config_preview': config_preview,
                'config_data': config_data
            }
            
            return render(request, 'naas/aci_vlan_to_port_preview.html', context)
            
        except Exception as e:
            print(f"Error in view: {str(e)}")
            import traceback
            print(f"Traceback: {traceback.format_exc()}")
            return HttpResponse(f"Error: {str(e)}")
    
    return redirect('aci_vlan_to_port_form')

def aci_vlan_to_port_submit(request):
    if request.method == 'POST':
        try:
            config_preview = request.POST.get('config_preview')
            config_data_str = request.POST.get('config_data')
            print("Config data (raw):", config_data_str)
            print("Config preview (XML):", config_preview)

            # Parse the JSON string
            try:
                if config_data_str.startswith("{") and config_data_str.endswith("}"):
                    config_data_str = config_data_str.replace("'", "\"")
                config_data = json.loads(config_data_str)
            except json.JSONDecodeError as e:
                print(f"JSON decode error: {str(e)}")
                return render(request, 'naas/aci_config_response.html', {
                    'status_class': 'error',
                    'message': f"Invalid JSON data: {str(e)}"
                })

            # Define the APIC IP and credentials
            apic_ip = "sandboxapicdc.cisco.com"
            usr = os.environ.get('ACI_USER_ID', '')
            pwd = os.environ.get('ACI_PWD', '')

            # Define URL and credentials for RESTAPI authentication
            auth_url = f"https://{apic_ip}/api/aaaLogin.json"
            headers = {'content-type': 'application/json'}
            auth_payload = {
                "aaaUser": {
                    "attributes": {
                        "name": usr,
                        "pwd": pwd
                    }
                }
            }

            # Suppress warnings for self-signed certificates
            requests.packages.urllib3.disable_warnings()

            # Authenticate with APIC
            auth_response = requests.post(auth_url, data=json.dumps(auth_payload), headers=headers, verify=False, timeout=10)
            print("\n--- AUTH response is %s" % auth_response)
            
            if auth_response.status_code != 200:
                return render(request, 'naas/aci_config_response.html', {
                    'status_class': 'error',
                    'message': "Authentication failed."
                })

            cookies = auth_response.cookies
            headers = {'content-type': 'application/xml'}

            # 1. Create Tenant if it doesn't exist
            tenant_xml = f"""
            <fvTenant name="{config_data['tenant']}">
            </fvTenant>
            """
            tenant_url = f"https://{apic_ip}/api/mo/uni/tn-{config_data['tenant']}.xml"
            tenant_response = requests.post(tenant_url, data=tenant_xml, cookies=cookies, headers=headers, verify=False, timeout=5)
            print("Tenant creation response:", tenant_response.status_code)
            
            if tenant_response.status_code != 200:
                return render(request, 'naas/aci_config_response.html', {
                    'status_class': 'error',
                    'message': f"Failed to create tenant. Error: {tenant_response.content.decode('utf-8')}"
                })

            # 2. Create Application Profile if it doesn't exist
            ap_xml = f"""
            <fvAp name="{config_data['ap']}">
            </fvAp>
            """
            ap_url = f"https://{apic_ip}/api/mo/uni/tn-{config_data['tenant']}/ap-{config_data['ap']}.xml"
            ap_response = requests.post(ap_url, data=ap_xml, cookies=cookies, headers=headers, verify=False, timeout=5)
            print("AP creation response:", ap_response.status_code)
            
            if ap_response.status_code != 200:
                return render(request, 'naas/aci_config_response.html', {
                    'status_class': 'error',
                    'message': f"Failed to create Application Profile. Error: {ap_response.content.decode('utf-8')}"
                })

            # 3. Create EPG if it doesn't exist
            epg_xml = f"""
            <fvAEPg name="{config_data['epg']}">
                <fvRsDomAtt tDn="uni/phys-phys"/>
            </fvAEPg>
            """
            epg_url = f"https://{apic_ip}/api/mo/uni/tn-{config_data['tenant']}/ap-{config_data['ap']}/epg-{config_data['epg']}.xml"
            epg_response = requests.post(epg_url, data=epg_xml, cookies=cookies, headers=headers, verify=False, timeout=5)
            print("EPG creation response:", epg_response.status_code)
            
            if epg_response.status_code != 200:
                return render(request, 'naas/aci_config_response.html', {
                    'status_class': 'error',
                    'message': f"Failed to create EPG. Error: {epg_response.content.decode('utf-8')}"
                })

            # 4. Now deploy the port bindings
            # Translate mode values in config_preview
            if config_data['mode'] == 'access':
                config_preview = config_preview.replace('mode="access"', 'mode="untagged"')
            elif config_data['mode'] == 'trunk':
                config_preview = config_preview.replace('mode="trunk"', 'mode="regular"')

            # POST the port binding configuration
            post_url = f"https://{apic_ip}/api/mo/uni/tn-{config_data['tenant']}/ap-{config_data['ap']}/epg-{config_data['epg']}.xml"
            print("POST URL:", post_url)
            
            response = requests.post(
                post_url, 
                data=config_preview, 
                cookies=cookies, 
                headers=headers, 
                verify=False, 
                timeout=5
            )

            print("POST response status code:", response.status_code)
            print("POST response content:", response.content.decode('utf-8'))

            # Check for successful configuration
            if response.status_code == 200 and '<imdata totalCount="0">' in response.content.decode('utf-8'):
                return render(request, 'naas/aci_config_response.html', {
                    'status_class': 'success',
                    'message': "Configuration deployed successfully!",
                    'output': response.content.decode('utf-8')
                })
            else:
                return render(request, 'naas/aci_config_response.html', {
                    'status_class': 'error',
                    'message': f"Failed to deploy configuration. Error: {response.content.decode('utf-8')}"
                })

        except Exception as e:
            print(f"Error in view: {str(e)}")
            import traceback
            print(f"Traceback: {traceback.format_exc()}")
            return render(request, 'naas/aci_config_response.html', {
                'status_class': 'error',
                'message': f"Error: {str(e)}"
            })

    return redirect('aci_vlan_to_port_form')

def get_show_vlan(net_connect, vlan_id=None):
    """Get show vlan output from device"""
    command = f'show vlan {vlan_id}' if vlan_id else 'show vlan brief'
    return net_connect.send_command(command)

def get_show_ip_interface_brief(net_connect, vlan_id=None):
    """Get show ip interface brief output from device"""
    command = f'show ip interface vlan {vlan_id}' if vlan_id else 'show ip interface brief'
    return net_connect.send_command(command)

@csrf_exempt
def get_device_status_view(request):
    """View to handle device status retrieval request"""
    if request.method == 'POST':
        try:
            # Parse incoming JSON data
            data = json.loads(request.body)
            switch_ip = data.get('switch_ip')
            command = data.get('command')
            vlan_id = data.get('vlan_id', None)
            
            # Use hardcoded or environment-based credentials
            username = os.environ.get('ARISTA_USER_ID', '')
            password = os.environ.get('ARISTA_USER_PWD', '')
            
            # Retrieve device status
            result = get_device_status(switch_ip, username, password, command, vlan_id)
            
            # Return appropriate response based on command
            if result['status'] == 'success':
                if command.startswith('show vlan'):
                    return JsonResponse({
                        'status': 'success',
                        'vlan_output': result['output']
                    })
                elif command.startswith('show ip interface vlan') or command == 'show ip interface brief':
                    return JsonResponse({
                        'status': 'success',
                        'ip_interface_output': result['output']
                    })
                else:
                    return JsonResponse({
                        'status': 'error',
                        'message': 'Invalid command'
                    }, status=400)
            else:
                return JsonResponse({
                    'status': 'error',
                    'message': result.get('error', 'Unknown error')
                }, status=500)
        
        except json.JSONDecodeError:
            return JsonResponse({
                'status': 'error',
                'message': 'Invalid JSON'
            }, status=400)
        
        except (NetMikoTimeoutException, NetMikoAuthenticationException) as e:
            logger.error(f"Unexpected error in get_device_status_view: {e}")
            return JsonResponse({
                'status': 'error',
                'message': 'Internal server error'
            }, status=500)
    
    return JsonResponse({
        'status': 'error',
        'message': 'Method not allowed'
    }, status=405)


def get_device_status(ip, username, password, command, vlan_id=None):
    """Get device status information"""
    try:
        with get_device_connection(ip, username, password) as net_connect:
            if command.startswith('show vlan'):
                output = get_show_vlan(net_connect, vlan_id)
            elif command.startswith('show ip interface vlan') or command == 'show ip interface brief':
                output = get_show_ip_interface_brief(net_connect, vlan_id)
            else:
                return {
                    'status': 'error',
                    'error': 'Invalid command'
                }
            return {
                'status': 'success',
                'output': output
            }
    except (NetMikoTimeoutException, NetMikoAuthenticationException) as e:
        return {
            'status': 'error',
            'error': str(e)
        }


@require_http_methods(["POST"])
@csrf_protect
def create_epg_config(request):
    try:
        data = json.loads(request.body)
        
        # Create YAML content with the new structure
        yaml_content = {
            "apic": {
                "tenants": [
                    {
                        "name": data["tenant_name"],
                        "application_profiles": [
                            {
                                "name": data["application_profile"],
                                "endpoint_groups": [
                                    {
                                        "name": data["endpoint_group"],
                                        "bridge_domain": data["bridge_domain"],
                                        "physical_domains": [data["physical_domain"]]
                                    }
                                ]
                            }
                        ]
                    }
                ]
            }
        }
    
        # Convert to YAML string
        yaml_str = yaml.dump(
            yaml_content, 
            default_flow_style=False,
            allow_unicode=True, 
            sort_keys=False        
        )
        
        # GitHub integration
        load_dotenv()
        g = Github(os.getenv('GITHUB_TOKEN'))
        #g = Github(GITHUB_TOKEN)
        repo = g.get_repo("vyshaghpoc/nexusascode")
        print(repo)
        # Create a new branch
        base_branch = repo.get_branch("main")
        branch_name = f"add-epg-{data['endpoint_group'].lower()}"
        ref = f"refs/heads/{branch_name}"
        repo.create_git_ref(ref=ref, sha=base_branch.commit.sha)
        
        # Create file path
        file_path = f"tenants/{data['tenant_name']}/data/epg/{data['endpoint_group'].lower()}.yaml"
        
        # Create commit and file
        repo.create_file(
            path=file_path,
            message=f"Add {data['endpoint_group']} configuration",
            content=yaml_str,
            branch=branch_name
        )

        # Create pull request
        pr = repo.create_pull(
            title=f"Add {data['endpoint_group']} configuration",
            body="Created via ACI Template UI",
            head=branch_name,
            base="main"
        )

        return JsonResponse({
            'success': True,
            'pr_url': pr.html_url,
            'pr_number': pr.number
        })

    except (GithubException, yaml.YAMLError) as e:
        return JsonResponse({
            'success': False,
            'error': str(e)
        }, status=500)
    
def tenant_catalog_view(request):
    return render(request, 'naas/aci_tenant_child_objects.html')

@csrf_exempt
def get_ethernet_interfaces_view(request):
    """View to retrieve available Ethernet interfaces for a switch"""
    if request.method == 'POST':
        try:
            # Parse incoming JSON data
            data = json.loads(request.body)
            switch_ip = data.get('switch_ip')
            
            # Use hardcoded or environment-based credentials
            username = os.environ.get('ARISTA_USER_ID', '')
            password = os.environ.get('ARISTA_USER_PWD', '')
            
            # Retrieve Ethernet interfaces
            result = get_ethernet_interfaces(switch_ip, username, password)
            
            # Return response
            if result['status'] == 'success':
                return JsonResponse({
                    'status': 'success',
                    'interfaces': result['interfaces']
                })
            else:
                return JsonResponse({
                    'status': 'error',
                    'message': result.get('error', 'Unknown error')
                }, status=500)
        
        except json.JSONDecodeError:
            return JsonResponse({
                'status': 'error',
                'message': 'Invalid JSON'
            }, status=400)
        
        except Exception as e:
            logger.error(f"Unexpected error in get_ethernet_interfaces_view: {e}")
            return JsonResponse({
                'status': 'error',
                'message': 'Internal server error'
            }, status=500)
    
    return JsonResponse({
        'status': 'error',
        'message': 'Method not allowed'
    }, status=405)


def get_ethernet_interfaces(ip, username, password):
    """Get available Ethernet interfaces for a device"""
    try:
        with get_device_connection(ip, username, password) as net_connect:
            # Run command to get Ethernet interfaces
            net_connect.enable()
            output = net_connect.send_command("show interfaces | grep -Eo '^Ethernet[0-9]+'")
            
            # Split output into list, removing any whitespace
            interfaces = [intf.strip() for intf in output.split('\n') if intf.strip()]
            
            return {
                'status': 'success',
                'interfaces': interfaces
            }
    except Exception as e:
        return {
            'status': 'error',
            'error': str(e)
        }
    

@csrf_exempt
def configure_interface_view(request):
    """View to configure multiple network interfaces in bulk"""
    if request.method == 'POST':
        try:
            # Parse incoming JSON data
            data = json.loads(request.body)
            switch_ip = data.get('switch_ip')
            commands = data.get('commands', [])
            
            # Use hardcoded or environment-based credentials
            username = os.environ.get('ARISTA_USER_ID', '')
            password = os.environ.get('ARISTA_USER_PWD', '')
            
            # Configure interfaces in bulk
            results = bulk_configure_interfaces(switch_ip, username, password, commands)
            
            # Check if all configurations were successful
            if all(result['status'] == 'success' for result in results):
                return JsonResponse({
                    'status': 'success',
                    'message': 'All interfaces configured successfully',
                    'details': results
                })
            else:
                # Collect failed configurations
                failed_configs = [
                    result for result in results 
                    if result['status'] != 'success'
                ]
                return JsonResponse({
                    'status': 'partial_error',
                    'message': 'Some interfaces failed configuration',
                    'failed_configs': failed_configs
                }, status=500)
        
        except json.JSONDecodeError:
            return JsonResponse({
                'status': 'error',
                'message': 'Invalid JSON'
            }, status=400)
        
        except Exception as e:
            logger.error(f"Unexpected error in configure_interfaces_view: {e}")
            return JsonResponse({
                'status': 'error',
                'message': 'Internal server error'
            }, status=500)
    
    return JsonResponse({
        'status': 'error',
        'message': 'Method not allowed'
    }, status=405)


def bulk_configure_interfaces(ip, username, password, commands):
    """
    Configure multiple network interfaces with given commands
    Returns a list of configuration results for each interface
    """
    results = []
    try:
        with get_device_connection(ip, username, password) as net_connect:
            # First enter privileged mode
            try:
                net_connect.enable()
            except Exception as enable_error:
                return [{
                    'status': 'error',
                    'error': str(enable_error),
                    'message': 'Failed to enter privileged mode'
                }]
            
            # Group commands by interface
            interface_configs = {}
            current_interface = None
            
            for command in commands:
                if command.startswith('interface '):
                    current_interface = command
                    interface_configs[current_interface] = [command]
                elif current_interface:
                    interface_configs[current_interface].append(command)
            
            # Configure each interface with its command group
            for interface, config_commands in interface_configs.items():
                try:
                    # Send all commands for this interface as a single set
                    output = net_connect.send_config_set(config_commands)
                    print(f"Configuration output for {interface}:\n{output}")
                    
                    # Check for error indicators in output
                    if "Invalid input" in output or "ERROR" in output:
                        results.append({
                            'interface': interface.split(' ', 1)[1],
                            'status': 'error',
                            'error': 'Configuration error detected',
                            'output': output
                        })
                    else:
                        results.append({
                            'interface': interface.split(' ', 1)[1],
                            'status': 'success',
                            'output': output
                        })
                
                except Exception as cmd_error:
                    results.append({
                        'interface': interface.split(' ', 1)[1],
                        'status': 'error',
                        'error': str(cmd_error),
                        'commands': config_commands
                    })
            
            try:
                # Save configuration
                output = net_connect.save_config()
                print(f"Save config output: {output}")
            except Exception as save_error:
                results.append({
                    'status': 'error',
                    'error': str(save_error),
                    'message': 'Failed to save configuration'
                })
        
        return results
    
    except Exception as connection_error:
        return [{
            'status': 'error',
            'error': str(connection_error),
            'message': 'Failed to establish device connection'
        }]

@csrf_exempt
def get_interface_config_view(request):
    """View to fetch current interface configurations"""
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            switch_ip = data.get('switch_ip')
            interfaces = data.get('interfaces', [])
            username = os.environ.get('ARISTA_USER_ID', '')
            password = os.environ.get('ARISTA_USER_PWD', '')

            # Get current configuration
            config = get_interface_config(switch_ip, username, password, interfaces)
            
            return JsonResponse({
                'status': 'success',
                'config': config
            })
        except Exception as e:
            logger.error(f"Error in get_interface_config_view: {e}")
            return JsonResponse({
                'status': 'error',
                'message': str(e)
            }, status=500)

    return JsonResponse({
        'status': 'error',
        'message': 'Method not allowed'
    }, status=405)

def get_interface_config(ip, username, password, interfaces):
    """Fetch current configuration for specified interfaces"""
    try:
        with get_device_connection(ip, username, password) as net_connect:
            # Build show command for multiple interfaces
            interface_list = ' '.join(interfaces)
            command = f"show running-config interface {interface_list}"
            net_connect.enable()
            # Execute command and get output
            output = net_connect.send_command(command)
            
            return output

    except Exception as e:
        raise Exception(f"Failed to get interface configuration: {str(e)}")

class SwitchOnboardingView(GenericView):
    template_name = 'naas/switch_onboarding.html'
    
    @method_decorator(login_required)
    @method_decorator(permission_required('dcim.add_device', raise_exception=True))
    def get(self, request):
        """
        Handle GET requests for the switch onboarding form.
        """
        # Get all required data for form fields
        locations = Location.objects.all()
        device_types = DeviceType.objects.select_related('manufacturer').all()
        racks = Rack.objects.all()
        prefixes = Prefix.objects.all()
        vlans = VLAN.objects.all()
        
        # Get tags categorized by type
        all_tags = Tag.objects.all()
        site_tags = [tag for tag in all_tags if tag.name.lower().startswith('site-')]
        switch_tags = [tag for tag in all_tags if tag.name.lower().startswith('sw-')]
        prefix_tags = [tag for tag in all_tags if tag.name.lower().startswith('prefix-')]
        cloud_service_tags = [tag for tag in all_tags if tag.name.lower().startswith('cloud-')]
        
        # Convert data to JSON for JavaScript use
        context = {
            'locations_json': json.dumps([{'pk': str(loc.pk), 'fields': {'name': loc.name}} for loc in locations]),
            'device_types_json': json.dumps([{
                'pk': str(dt.pk), 
                'fields': {
                    'model': dt.model,
                    'manufacturer': dt.manufacturer.name if dt.manufacturer else ''
                }
            } for dt in device_types]),
            'racks_json': json.dumps([{'pk': str(rack.pk), 'fields': {'name': rack.name}} for rack in racks]),
            'prefixes_json': json.dumps([{
                'pk': str(prefix.pk), 
                'fields': {
                    'network': str(prefix.network), 
                    'prefix_length': prefix.prefix_length
                }
            } for prefix in prefixes]),
            'vlans_json': json.dumps([{
                'pk': str(vlan.pk), 
                'fields': {
                    'name': vlan.name, 
                    'vid': vlan.vid
                }
            } for vlan in vlans]),
            'site_tags_json': json.dumps([{'pk': str(tag.pk), 'fields': {'name': tag.name}} for tag in site_tags]),
            'switch_tags_json': json.dumps([{'pk': str(tag.pk), 'fields': {'name': tag.name}} for tag in switch_tags]),
            'prefix_tags_json': json.dumps([{'pk': str(tag.pk), 'fields': {'name': tag.name}} for tag in prefix_tags]),
            'cloud_service_tags_json': json.dumps([{'pk': str(tag.pk), 'fields': {'name': tag.name}} for tag in cloud_service_tags]),
            'tags_json': json.dumps([{'pk': str(tag.pk), 'fields': {'name': tag.name}} for tag in all_tags]),
            'locations': locations,
        }
        
        return render(request, self.template_name, context)
    
    @method_decorator(login_required)
    @method_decorator(permission_required('dcim.add_device', raise_exception=True))
    def post(self, request):
        """
        Handle POST requests for the switch onboarding form.
        """
        try:
            with transaction.atomic():
                # Get basic form data
                name = request.POST.get('name')
                location_id = request.POST.get('location')
                switch_quantity = int(request.POST.get('switch_quantity', 0))
                prefix_quantity = int(request.POST.get('prefix_quantity', 0))
                tool_quantity = int(request.POST.get('tool_quantity', 0))
                digital_twin = 'digital_twin' in request.POST
                
                # Retrieve location
                try:
                    location = Location.objects.get(pk=location_id)
                except Location.DoesNotExist:
                    messages.error(request, f"Location with ID {location_id} does not exist.")
                    return redirect('plugins:naas:switch-onboarding')
                
                # Get active status for new devices
                active_status = Status.objects.get(name='Active')
                
                # Process switch devices
                created_switches = []
                for i in range(switch_quantity):
                    switch_name = request.POST.get(f'switch_name_{i}')
                    device_type_id = request.POST.get(f'device_type_{i}')
                    rack_id = request.POST.get(f'rack_{i}')
                    mgmt_ip = request.POST.get(f'switch_mgmt_ip_{i}')
                    serial_number = request.POST.get(f'switch_serial_{i}')

                    # Get interface configuration settings
                    interface_count = int(request.POST.get(f'interface_count_{i}', 24))
                    interface_type = request.POST.get(f'interface_type_{i}', 'access')
                    default_vlan_id = request.POST.get(f'default_vlan_{i}')
                    
                    # Get tags for this switch
                    switch_tags_ids = request.POST.getlist(f'switch_tags_{i}', [])
                    switch_tags = Tag.objects.filter(pk__in=switch_tags_ids)
                    
                    # Retrieve device type and rack
                    try:
                        device_type = DeviceType.objects.get(pk=device_type_id)
                        rack = Rack.objects.get(pk=rack_id)
                    except DeviceType.DoesNotExist:
                        messages.error(request, f"Device type with ID {device_type_id} does not exist.")
                        return redirect('plugins:naas:switch-onboarding')
                    except Rack.DoesNotExist:
                        messages.error(request, f"Rack with ID {rack_id} does not exist.")
                        return redirect('plugins:naas:switch-onboarding')
                    
                    # Create the switch device
                    switch = Device.objects.create(
                        name=switch_name,
                        device_type=device_type,
                        location=location,
                        rack=rack,
                        status=active_status,
                        serial=serial_number,
                        # Add other required fields based on   Device model
                    )
                    
                    # Add tags to the switch
                    switch.tags.set(switch_tags)
                    
                    # If management IP is provided, create primary IP assignment
                    if mgmt_ip:
                        try:
                            # Parse management IP and create IPAddress object
                            ip_obj = IPAddress.objects.create(
                                address=f"{mgmt_ip}/32",  # Convert to CIDR notation
                                status=active_status,
                                dns_name=f"{switch_name}.example.com"  # Optional DNS name
                            )
                            
                            # Create management interface
                            mgmt_interface = Interface.objects.create(
                                device=switch,
                                name='Management',
                                type='virtual',
                                enabled=True,
                                description='Management Interface'
                            )
                            
                            # Associate the IP with the interface
                            ip_obj.assigned_object = mgmt_interface
                            ip_obj.save()
                            
                            # Assign as the primary IP for the device
                            switch.primary_ip4 = ip_obj
                            switch.save()
                        except Exception as e:
                            messages.warning(request, f"Error assigning management IP to {switch_name}: {str(e)}")
                    
                    # Create interfaces based on configuration
                    for j in range(1, interface_count + 1):
                        interface_name = f'GigabitEthernet0/{j}'
                        
                        # Create the physical interface
                        interface_obj = Interface.objects.create(
                            device=switch,
                            name=interface_name,
                            type='1000base-t',
                            description=f'{"Access" if interface_type == "access" else "Trunk"} Port {j}',
                            enabled=True
                        )
                        
                        # Set custom fields for mode (if supported)
                        if hasattr(interface_obj, 'custom_field_data'):
                            custom_field_data = {'mode': interface_type}
                            interface_obj.custom_field_data = custom_field_data
                            interface_obj.save()
                        
                        # Create VLAN associations
                        if interface_type == 'access':
                            # For access ports, associate with a single untagged VLAN
                            if default_vlan_id:
                                try:
                                    vlan = VLAN.objects.get(pk=default_vlan_id)
                                    # Create actual association
                                    InterfaceVLAN.objects.create(
                                        interface=interface_obj,
                                        vlan=vlan,
                                        tagged=False
                                    )
                                except VLAN.DoesNotExist:
                                    messages.warning(request, f"VLAN with ID {default_vlan_id} not found.")
                                except Exception as e:
                                    messages.warning(request, f"Error associating VLAN with interface: {str(e)}")
                        else:
                            # For trunk ports, set native VLAN and allow all VLANs
                            if default_vlan_id:
                                try:
                                    vlan = VLAN.objects.get(pk=default_vlan_id)
                                    # Set native VLAN
                                    InterfaceVLAN.objects.create(
                                        interface=interface_obj,
                                        vlan=vlan,
                                        tagged=False
                                    )
                                    
                                    # Add all other VLANs as tagged
                                    for other_vlan in VLAN.objects.exclude(pk=default_vlan_id):
                                        InterfaceVLAN.objects.create(
                                            interface=interface_obj,
                                            vlan=other_vlan,
                                            tagged=True
                                        )
                                except VLAN.DoesNotExist:
                                    messages.warning(request, f"VLAN with ID {default_vlan_id} not found.")
                                except Exception as e:
                                    messages.warning(request, f"Error associating VLANs with trunk interface: {str(e)}")
                    
                    created_switches.append(switch)
                
                # Process prefixes and VLANs (optional)
                created_prefixes = []
                if prefix_quantity > 0:
                    for i in range(prefix_quantity):
                        prefix_id = request.POST.get(f'prefix_{i}')
                        vlan_id = request.POST.get(f'prefix_vlan_{i}')
                        vlan_name = request.POST.get(f'prefix_vlan_name_{i}')
                        gw_ip = request.POST.get(f'prefix_gw_ip_{i}')
                        
                        # Get tags for this prefix
                        prefix_tags_ids = request.POST.getlist(f'prefix_tags_{i}', [])
                        prefix_tags = Tag.objects.filter(pk__in=prefix_tags_ids)
                        
                        # Create or assign prefix if all required data is present
                        if prefix_id and vlan_id:
                            try:
                                # Get the prefix object
                                prefix = Prefix.objects.get(pk=prefix_id)
                                
                                # Get or create the VLAN if needed
                                vlan = VLAN.objects.get(pk=vlan_id)
                                
                                # Associate the prefix with the VLAN
                                prefix.vlan = vlan
                                
                                # Set a gateway IP if provided
                                if gw_ip:
                                    # Create IPAddress for gateway
                                    gateway_ip = IPAddress.objects.create(
                                        address=f"{gw_ip}/32",
                                        status=active_status,
                                        role=IPAddressRoleChoices.ROLE_ANYCAST if prefix.family == 6 else IPAddressRoleChoices.ROLE_SECONDARY,
                                        dns_name=f"gw.{vlan_name}.example.com" if vlan_name else None
                                    )
                                    
                                    # Associate with prefix
                                    prefix.gateway = gateway_ip
                                
                                # Add tags to the prefix
                                prefix.tags.set(prefix_tags)
                                prefix.save()
                                
                                created_prefixes.append(prefix)
                            except Prefix.DoesNotExist:
                                messages.warning(request, f"Prefix with ID {prefix_id} not found.")
                            except VLAN.DoesNotExist:
                                messages.warning(request, f"VLAN with ID {vlan_id} not found.")
                            except Exception as e:
                                messages.warning(request, f"Error processing prefix: {str(e)}")
                
                # Process tools (optional)
                created_tools = []
                if tool_quantity > 0:
                    for i in range(tool_quantity):
                        tool_name = request.POST.get(f'tool_name_{i}')
                        tool_ip = request.POST.get(f'tool_ip_{i}')
                        tool_status = request.POST.get(f'tool_status_{i}')
                        
                        # Get tags for this tool
                        tool_tags_ids = request.POST.getlist(f'tool_tags_{i}', [])
                        tool_tags = Tag.objects.filter(pk__in=tool_tags_ids)
                        
                        # Create tool if all required data is present
                        if tool_name and tool_ip:
                            try:
                                # Check if   Nautobot has a custom model for tools/services
                                # If not, we'll create a Device object with appropriate type and tags
                                
                                # Find or create a device type for tools
                                tool_device_type, _ = DeviceType.objects.get_or_create(
                                    model="Network Tool",
                                    defaults={
                                        'manufacturer': Manufacturer.objects.first(),  #  set a specific manufacturer
                                        'u_height': 1,
                                        'is_full_depth': False
                                    }
                                )
                                
                                # Create the tool as a Device
                                tool = Device.objects.create(
                                    name=tool_name,
                                    device_type=tool_device_type,
                                    location=location,  # Use the same location as the switches
                                    status=Status.objects.get(name=tool_status) if tool_status else active_status
                                )
                                
                                # Add tool IP if provided
                                if tool_ip:
                                    ip_obj = IPAddress.objects.create(
                                        address=f"{tool_ip}/32",
                                        status=active_status
                                    )
                                    
                                    # Create management interface
                                    mgmt_interface = Interface.objects.create(
                                        device=tool,
                                        name='Management',
                                        type='virtual',
                                        enabled=True
                                    )
                                    
                                    # Associate IP with interface
                                    ip_obj.assigned_object = mgmt_interface
                                    ip_obj.save()
                                    
                                    # Set as primary IP
                                    tool.primary_ip4 = ip_obj
                                    tool.save()
                                
                                # Add tags to the tool
                                tool.tags.set(tool_tags)
                                
                                created_tools.append(tool)
                            except Exception as e:
                                messages.warning(request, f"Error creating tool {tool_name}: {str(e)}")
                
                # Handle digital twin (optional)
                if digital_twin:
                    try:
                        # Create digital twin instances for each switch
                        for switch in created_switches:
                            # Create a copy with modified name and add digital twin tag
                            digital_twin = Device.objects.create(
                                name=f"DT-{switch.name}",
                                device_type=switch.device_type,
                                location=switch.location,
                                rack=switch.rack,
                                status=active_status
                            )
                            
                            # Add digital twin tag
                            dt_tag, _ = Tag.objects.get_or_create(
                                name="DIGITAL-TWIN",
                                defaults={'color': '0000FF'}
                            )
                            
                            # Copy all tags from original switch and add digital twin tag
                            dt_tags = list(switch.tags.all())
                            dt_tags.append(dt_tag)
                            digital_twin.tags.set(dt_tags)
                            
                            # Copy interfaces
                            for original_interface in Interface.objects.filter(device=switch):
                                dt_interface = Interface.objects.create(
                                    device=digital_twin,
                                    name=original_interface.name,
                                    type=original_interface.type,
                                    description=f"DT-{original_interface.description}" if original_interface.description else "Digital Twin Interface",
                                    enabled=original_interface.enabled
                                )
                                
                                # Copy custom field data if it exists
                                if hasattr(original_interface, 'custom_field_data') and original_interface.custom_field_data:
                                    dt_interface.custom_field_data = original_interface.custom_field_data
                                    dt_interface.save()
                                
                                # Copy VLAN associations
                                for vlan_association in InterfaceVLAN.objects.filter(interface=original_interface):
                                    InterfaceVLAN.objects.create(
                                        interface=dt_interface,
                                        vlan=vlan_association.vlan,
                                        tagged=vlan_association.tagged
                                    )
                            
                            messages.info(request, f"Created digital twin {digital_twin.name} for {switch.name}")
                    except Exception as e:
                        messages.warning(request, f"Error creating digital twins: {str(e)}")
                
                # Set success message
                messages.success(request, f"Successfully created {len(created_switches)} switches, {len(created_prefixes)} prefixes, and {len(created_tools)} tools.")
                
                return redirect('plugins:naas:switch-onboarding')
                
        except Exception as e:
            # Handle any errors that occur during processing
            messages.error(request, f"Error during switch onboarding: {str(e)}")
            return redirect('plugins:naas:switch-onboarding')


class GenerateSwitchConfigView(GenericView):
    """
    AJAX view to generate switch configurations without saving to the database.
    """
    
    def process_interfaces(self, switch_index, data):
        """
        Process interface configurations for a switch, supporting per-interface settings.
        Returns a list of interface dictionaries ready for the template.
        """
        # Get interface settings from the switchInterfaceSettings object
        interface_settings = data.get('switchInterfaceSettings', {}).get(str(switch_index), {})
        
        # Get default settings
        interface_count = int(interface_settings.get('interfaceCount', 24))
        default_interface_type = interface_settings.get('interfaceType', 'access')
        default_vlan_id = interface_settings.get('defaultVlan', '1')
        
        # Get per-interface settings
        per_interface_settings = interface_settings.get('interfaces', {})
        
        # Default VLAN vid
        default_vlan_vid = 1
        
        # Try to get the default VLAN object
        if default_vlan_id != '1':
            try:
                default_vlan = VLAN.objects.get(pk=default_vlan_id)
                default_vlan_vid = default_vlan.vid
            except VLAN.DoesNotExist:
                pass
        
        # Generate interfaces
        interfaces = []
        for i in range(1, interface_count + 1):
            # Check if this interface has custom settings
            custom_settings = per_interface_settings.get(str(i), {})
            
            # Determine interface type (custom or default)
            interface_type = custom_settings.get('type', default_interface_type)
            
            # Determine VLAN ID (custom or default)
            vlan_id = custom_settings.get('vlan', default_vlan_id)
            vlan_vid = default_vlan_vid
            
            # Try to get the custom VLAN if specified
            if vlan_id != default_vlan_id:
                try:
                    vlan = VLAN.objects.get(pk=vlan_id)
                    vlan_vid = vlan.vid
                except VLAN.DoesNotExist:
                    pass
            
            # Get description (custom or default)
            description = custom_settings.get('description', f'{"Access" if interface_type == "access" else "Trunk"} Port {i}')
            
            # Create the interface dictionary
            interface = {
                'name': f'GigabitEthernet0/{i}',
                'description': description,
                'mode': interface_type
            }
            
            # Add mode-specific settings
            if interface_type == 'access':
                interface['vlan'] = vlan_vid
            else:  # trunk
                interface['native_vlan'] = vlan_vid
                
                # Add allowed VLANs (default to 'all')
                allowed_vlans = custom_settings.get('allowed_vlans', 'all')
                interface['allowed_vlans'] = allowed_vlans
            
            # Add the interface to the list
            interfaces.append(interface)
        
        return interfaces


    @method_decorator(login_required)
    @method_decorator(require_POST)
    def post(self, request):
        """
        Handle AJAX POST request to generate switch configurations.
        """
        try:
            # Parse JSON data from request
            data = json.loads(request.body)
            
            # Basic form data
            name = data.get('name', 'Unnamed Site')
            location_name = data.get('location_name', '')
            switch_quantity = int(data.get('switch_quantity', 0))
            digital_twin = data.get('digital_twin') == 'on'

            # Get site tag from location name
            site_tag_name = location_name[:5].upper() if location_name else ""
            print(f"Looking for site tag: {site_tag_name}")

            
            # Get VLANs for the selected location
            filtered_vlans = []
            if site_tag_name:
                try:
                    # Try to get tag objects (case-insensitive)
                    site_tag = Tag.objects.filter(name__iexact=site_tag_name).first()
                    
                    # Try uppercase PROD first, then any tag containing "prod" case insensitive
                    prod_tag = Tag.objects.filter(name__iexact='PROD').first()
                    if not prod_tag:
                        prod_tag = Tag.objects.filter(name__icontains='prod').first()
                    
                    vlan_tag = Tag.objects.filter(name__iexact='VLAN').first()
                    
                    print(f"Tags found: site_tag={site_tag}, prod_tag={prod_tag}, vlan_tag={vlan_tag}")
                    
                    # If we found the site tag
                    if site_tag:
                        # Get VLANs with the site tag
                        site_vlans = VLAN.objects.filter(tags=site_tag)
                        
                        # Now iterate through these VLANs and check their tags manually
                        for vlan in site_vlans:
                            # Check if this VLAN has tags that *contain* "prod" and "vlan"
                            vlan_tag_names = [tag.name.lower() for tag in vlan.tags.all()]
                            has_prod = any('prod' in tag.lower() for tag in vlan_tag_names)
                            has_vlan = any('vlan' in tag.lower() for tag in vlan_tag_names)
                            
                            # If it has appropriate tags or if we're just using site tag
                            if has_prod and has_vlan:
                                filtered_vlans.append({
                                    'vid': vlan.vid,
                                    'name': vlan.name
                                })
                        print("filtered_vlans::", filtered_vlans)
                        
                        # If we still don't have any VLANs, get all
                        if not filtered_vlans:
                            all_vlans = VLAN.objects.all()
                            for vlan in all_vlans:
                                filtered_vlans.append({
                                    'vid': vlan.vid,
                                    'name': vlan.name
                                })

                except Exception as e:
                    print(f"Error filtering VLANs by tags: {str(e)}")
                    # In case of error, try to get all VLANs
                    all_vlans = VLAN.objects.all()
                    for vlan in all_vlans:
                        filtered_vlans.append({
                            'vid': vlan.vid,
                            'name': vlan.name
                        })

            # Add default VLAN if not already included
            if not any(v['vid'] == 1 for v in filtered_vlans):
                filtered_vlans.append({
                    'vid': 1,
                    'name': 'default'
                })
        
            # Initialize configuration generator
            generator = ConfigGenerator(template_dir='/home/ubuntu/nautobot-dev/nautobot/naas/templates/naas')
            
            # Process each switch
            configs = {}
            for i in range(switch_quantity):
                switch_name = data.get(f'switch_name_{i}') or f"{name}-SW{i+1}"
                device_type_id = data.get(f'device_type_{i}')
                mgmt_ip = data.get(f'switch_mgmt_ip_{i}')
                interface_type = data.get(f'interface_type_{i}', 'access')
                default_vlan = data.get(f'default_vlan_{i}', '1')
                interface_count = int(data.get(f'interface_count_{i}', 24))
                
                # Get VLAN information
                vlan_objects = filtered_vlans.copy() 
                if default_vlan != '1':
                    try:
                        vlan = VLAN.objects.get(pk=default_vlan)
                        if not any(v['vid'] == vlan.vid for v in vlan_objects):
                            vlan_objects.append({
                                'vid': vlan.vid,
                                'name': vlan.name
                            })
                    except VLAN.DoesNotExist:
                        pass

                else:
                    vlan_objects.append({
                        'vid': 1,
                        'name': 'default'
                    })
                
                # Add VLANs from prefixes section (optional)
                prefix_quantity = int(data.get('prefix_quantity', 0))
                if prefix_quantity > 0:
                    for j in range(prefix_quantity):
                        vlan_id = data.get(f'prefix_vlan_{j}')
                        vlan_name = data.get(f'prefix_vlan_name_{j}', f'VLAN-{j+1}')
                        
                        if vlan_id:
                            try:
                                vlan = VLAN.objects.get(pk=vlan_id)
                                if not any(v['vid'] == vlan.vid for v in vlan_objects):
                                    vlan_objects.append({
                                        'vid': vlan.vid,
                                        'name': vlan_name or vlan.name
                                    })
                            except VLAN.DoesNotExist:
                                pass
                
                # Process interfaces with per-interface configuration
                interfaces = self.process_interfaces(i, data)
                    
                # Add uplink ports
                uplinks = [
                    {
                        'name': 'GigabitEthernet0/48',
                        'description': 'Uplink to Core'
                    }
                ]
                
                # Handle tools integration (optional)
                tools = []
                tool_quantity = int(data.get('tool_quantity', 0))
                if tool_quantity > 0:
                    for j in range(tool_quantity):
                        tool_name = data.get(f'tool_name_{j}')
                        tool_ip = data.get(f'tool_ip_{j}')
                        
                        if tool_name and tool_ip:
                            tools.append({
                                'name': tool_name,
                                'ip': tool_ip
                            })
                
                # Prepare switch data for template rendering
                switch_data = {
                    'switch': {
                        'name': switch_name,
                        'location': data.get('location_name', 'Default Location'),
                        'management_ip': mgmt_ip,
                        'management_subnet': '255.255.255.0',
                        'enable_aaa': False,
                        'enable_snmp': True,
                        'snmp_community': 'public',
                        'contact': 'admin@example.com'
                    },
                    'organization_name': name,
                    'vlans': vlan_objects,
                    'interfaces': interfaces,
                    'uplinks': uplinks,
                    'tools': tools,
                    'digital_twin': digital_twin,
                    'timestamp': datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                }
                
                # Generate the configuration
                config = generator.generate_switch_config(switch_data, template_name='switch_onboard.jinja2')
                configs[switch_name] = config
                
                # Generate digital twin configuration if requested
                if digital_twin:
                    dt_switch_name = f"DT-{switch_name}"
                    dt_switch_data = copy.deepcopy(switch_data)
                    dt_switch_data['switch']['name'] = dt_switch_name
                    
                    # Change management IP for digital twin if provided
                    if mgmt_ip:
                        ip_parts = mgmt_ip.split('.')
                        if len(ip_parts) == 4:
                            # Increment the last octet for digital twin
                            ip_parts[3] = str(int(ip_parts[3]) + 100)
                            dt_switch_data['switch']['management_ip'] = '.'.join(ip_parts)
                    
                    dt_config = generator.generate_switch_config(dt_switch_data, template_name='switch_onboard.jinja2')
                    configs[dt_switch_name] = dt_config
            
            # Return the configurations as JSON response
            return JsonResponse({
                'success': True,
                'configs': configs
            })
            
        except Exception as e:
            # Return error message
            return JsonResponse({
                'success': False,
                'error': str(e)
            }, status=400)


AUTH_METHODS = [
    {"value": "SSH", "label": "SSH"},
    {"value": "TACACS", "label": "TACACS+"},
    {"value": "RADIUS", "label": "RADIUS"},
]

CREDENTIAL_PROFILES = [
    {"value": "default", "label": "Default"},
    {"value": "admin", "label": "Admin"},
    {"value": "operator", "label": "Operator"},
]

PRIMARY_ACTIONS = [
    {"value": "upload", "label": "Upload Image"},
    {"value": "verify", "label": "Verify Only"},
    {"value": "upload_install", "label": "Upload & Install"},
]

SECONDARY_ACTIONS = [
    {"value": "none", "label": "None"},
    {"value": "verify", "label": "Verify"},
    {"value": "backup", "label": "Backup Current"},
    {"value": "install", "label": "Install Image"},
]

EXECUTION_TYPES = [
    {"value": "immediate", "label": "Immediate"},
    {"value": "scheduled", "label": "Scheduled"},
    {"value": "maintenance", "label": "Maintenance Window"},
]

EXECUTION_MODES = [
    {"value": "serial", "label": "Serial (One by one)"},
    {"value": "parallel", "label": "Parallel (Simultaneous)"},
]

NOTIFICATION_TYPES = [
    {"value": "email", "label": "Email"},
    {"value": "slack", "label": "Slack"},
    {"value": "teams", "label": "Microsoft Teams"},
    {"value": "none", "label": "None"},
]

TICKET_SYSTEMS = [
    {"value": "none", "label": "None"},
    {"value": "servicenow", "label": "ServiceNow"},
    {"value": "jira", "label": "Jira"},
]

# Sample job data - in production, this would come from a database table
SAMPLE_JOBS = [
    {
        "id": 1001,
        "job_id": "JOB-1001",
        "device_ip": "192.168.1.10",
        "device_type": "SWITCH-3850",
        "started_at": "2025-03-12 10:30",
        "status": "Completed",
        "status_class": "success",
        "timeline": [
            {"title": "Job Created", "time": "10:30:15", "description": "Upgrade job created"},
            {"title": "File Transfer", "time": "10:32:10", "description": "IOS image transferred"},
            {"title": "Completed", "time": "10:45:32", "description": "Upgrade completed successfully"}
        ]
    },
    {
        "id": 1002,
        "job_id": "JOB-1002",
        "device_ip": "192.168.1.11",
        "device_type": "SWITCH-9300",
        "started_at": "2025-03-12 11:15",
        "status": "In Progress",
        "status_class": "running",
        "timeline": [
            {"title": "Job Created", "time": "11:15:20", "description": "Upgrade job created"},
            {"title": "Pre-Checks", "time": "11:15:45", "description": "Pre-upgrade checks running"},
            {"title": "File Transfer", "time": "11:17:10", "description": "File transfer in progress"}
        ]
    },
    {
        "id": 1003,
        "job_id": "JOB-1003",
        "device_ip": "192.168.1.12",
        "device_type": "SWITCH-3850",
        "started_at": "2025-03-12 09:45",
        "status": "Failed",
        "status_class": "failed",
        "timeline": [
            {"title": "Job Created", "time": "09:45:10", "description": "Upgrade job created"},
            {"title": "Pre-Checks", "time": "09:45:30", "description": "Pre-upgrade checks started"},
            {"title": "Failed", "time": "09:46:15", "description": "Insufficient flash memory"}
        ]
    }
]

# Sample device data - in production, this would come from Nautobot's Device model
SAMPLE_DEVICES = [
    {
        "id": 1,
        "hostname": "switch01.example.com",
        "ip_address": "192.168.1.10",
        "device_type": "SWITCH-3850",
        "ios_version": "16.9.5",
        "last_upgraded": "2025-03-12",
        "status": "Up to Date",
        "status_class": "success"
    },
    {
        "id": 2,
        "hostname": "switch02.example.com",
        "ip_address": "192.168.1.11",
        "device_type": "SWITCH-9300",
        "ios_version": "17.1.1",
        "last_upgraded": "2025-01-15",
        "status": "Update Available",
        "status_class": "pending"
    },
    {
        "id": 3,
        "hostname": "switch03.example.com",
        "ip_address": "192.168.1.12",
        "device_type": "SWITCH-3850",
        "ios_version": "16.6.5",
        "last_upgraded": "2024-11-20",
        "status": "Outdated",
        "status_class": "failed"
    }
]

# Sample job detail data
JOB_DETAIL = {
    "1001": {
        "device": "192.168.1.10",
        "device_type": "SWITCH-3850",
        "job_type": "IOS Upgrade",
        "status": "Completed",
        "status_class": "success",
        "started_at": "2025-03-12 10:30:15",
        "completed_at": "2025-03-12 10:45:32",
        "duration": "15m 17s",
        "requested_by": "admin",
        "timeline": [
            {"title": "Job Created", "time": "10:30:15", "description": "Upgrade job created for device 192.168.1.10"},
            {"title": "Pre-Checks Started", "time": "10:30:20", "description": "Verifying free flash memory and compatibility"},
            {"title": "Backup Configuration", "time": "10:31:45", "description": "Configuration backup completed successfully"},
            {"title": "File Transfer Started", "time": "10:32:10", "description": "Transferring IOS image to device"},
            {"title": "File Transfer Completed", "time": "10:38:22", "description": "IOS image transferred successfully"},
            {"title": "Installation Started", "time": "10:38:30", "description": "Installing new IOS image"},
            {"title": "Device Reboot", "time": "10:42:15", "description": "Device rebooting with new IOS image"},
            {"title": "Post-Verification", "time": "10:44:45", "description": "Verifying device boot and feature functionality"},
            {"title": "Job Completed", "time": "10:45:32", "description": "Upgrade completed successfully"}
        ],
        "logs": [
            {"time": "10:31:00", "level": "INFO", "message": "Initiating configuration backup"},
            {"time": "10:31:45", "level": "INFO", "message": "Configuration backup completed"},
            {"time": "10:32:00", "level": "INFO", "message": "Preparing for file transfer"},
            {"time": "10:32:10", "level": "INFO", "message": "Starting file transfer via TFTP"},
            {"time": "10:35:20", "level": "INFO", "message": "File transfer 50% complete"},
            {"time": "10:38:22", "level": "INFO", "message": "File transfer completed successfully"},
            {"time": "10:38:30", "level": "INFO", "message": "Verifying file integrity"},
            {"time": "10:38:45", "level": "INFO", "message": "File integrity verified"},
            {"time": "10:39:00", "level": "INFO", "message": "Starting installation"},
            {"time": "10:42:15", "level": "INFO", "message": "Installation complete, rebooting device"},
            {"time": "10:44:30", "level": "INFO", "message": "Device back online"},
            {"time": "10:44:45", "level": "INFO", "message": "Starting post-upgrade verification"},
            {"time": "10:45:15", "level": "INFO", "message": "Verified new IOS version: 16.9.5"},
            {"time": "10:45:25", "level": "INFO", "message": "All features operational"},
            {"time": "10:45:32", "level": "INFO", "message": "Upgrade job completed successfully"}
        ],
        "config": {
            "ip_switch": "192.168.1.10",
            "device_type": "SWITCH-3850",
            "tftp_server": "10.0.0.100",
            "file_path": "/tftpboot/cat3k_caa-universalk9.16.09.05.SPA.bin",
            "auth_method": "SSH",
            "primary_push": "Upload & Install",
            "pre_checks": "Memory Check, Compatibility Check, Config Backup",
            "post_checks": "Boot Verification, Feature Verification",
            "execution_type": "Immediate",
            "notifications": "Email"
        }
    }
}

@login_required
@csrf_protect
def ios_upgrade(request):
    """
    Main view for the IOS upgrade interface.
    """
    if request.method == 'POST':
        # Process form submission
        return handle_form_submission(request)
    
    # Get device types from Nautobot
    device_types = []
    for dt in DeviceType.objects.all():
        device_types.append({
            "value": dt.model,
            "label": f"{dt.manufacturer.name} {dt.model}"
        })
    
    # Get regions from Nautobot (for filtering)
    regions = []
    location_type = LocationType.objects.filter(name__icontains='region').first()
    if location_type:
        for region in Location.objects.filter(location_type=location_type):
            regions.append({
                "value": region.name,
                "label": region.name
            })
    
    # Get actual devices from Nautobot
    devices = []
    active_status = Status.objects.get(name='Active')
    for device in Device.objects.filter(status=active_status):
        # Determine status based on IOS version
        # ios_version = device.custom_field_data.get('ios_version', 'Unknown') if hasattr(device, 'custom_field_data') else 'Unknown'
        # last_upgraded = device.custom_field_data.get('last_upgraded', 'Never') if hasattr(device, 'custom_field_data') else 'Never'
        ios_version = getattr(device, 'custom_field_data', {}).get('ios_version') or '10.2.5'
        last_upgraded = getattr(device, 'custom_field_data', {}).get('last_upgraded') or '2025-07-08'
        
        # Determine the status class based on version
        status = "Unknown"
        status_class = "pending"
        flash_space = "Unknown"
        
        if ios_version != 'Unknown':
            # This is a simple example - you'd have your own logic to determine upgrade status
            if ios_version.startswith('17'):
                status = "Up to Date"
                status_class = "success"
            elif ios_version.startswith('16.9') or ios_version.startswith('16.12'):
                status = "Update Available"
                status_class = "pending"
            else:
                status = "Outdated"
                status_class = "failed"
        
        # Get flash space from custom field if available
        # flash_space = device.custom_field_data.get('flash_space', 'Unknown') if hasattr(device, 'custom_field_data') else 'Unknown'
        import random
        flash_space = getattr(device, 'custom_field_data', {}).get('flash_space') or f"{random.uniform(2000, 3000):.4f} MB"

        
        # Get the region if available
        region = "Unknown"
        if device.location and device.location.parent:
            region = device.location.parent.name
        
        devices.append({
            "id": str(device.id),
            "hostname": device.name,
            "ip_address": str(device.primary_ip.address.ip) if device.primary_ip else "No IP",
            "device_type": device.device_type.model if device.device_type else "Unknown",
            "ios_version": ios_version,
            "status": status,
            "status_class": status_class,
            "flash_space": flash_space,
            "last_upgraded": last_upgraded,
            "region": region
        })
    
    
    tftp_servers = [
        {"value": "default", "label": "Default Ansible Server (172.21.17.41)"},
        {"value": "manual", "label": "Manual Entry"}
    ]
    
    # Get initial list of IOS images
    # For initial page load, we'll set an empty list and load via AJAX
    ios_images = []
    
    context = {
        'device_types': device_types,
        'regions': regions,
        'devices': devices,
        'ios_images': ios_images,
        'tftp_servers': tftp_servers,
        'default_tftp_server': '172.21.17.41',
        'default_tftp_path': '/srv/tftp/'
    }
    
    return render(request, 'naas/ios_upgrade.html', context)

@login_required
@csrf_protect
def switch_reboot(request):
    '''
    from django.db import connection
    for table in connection.introspection.table_names():
        print(table)
    '''
    print(reverse('plugins:naas:approve-reboot', args=['853ac3cf-64da-4a7c-8d37-e16bffc725ce']))
    if request.method == 'POST':
        # Process form submission
        pass
    # Get device types from Nautobot
    device_types = []
    for dt in DeviceType.objects.all():
        device_types.append({
            "value": dt.model,
            "label": f"{dt.manufacturer.name} {dt.model}"
        })
    
    # Get regions from Nautobot (for filtering)
    regions = []
    location_type = LocationType.objects.filter(name__icontains='region').first()
    if location_type:
        for region in Location.objects.filter(location_type=location_type):
            regions.append({
                "value": region.name,
                "label": region.name
            })
    
    # Get actual devices from Nautobot
    devices = []
    active_status = Status.objects.get(name='Active')
    for device in Device.objects.filter(status=active_status):
        # Determine status based on IOS version
        ios_version = device.custom_field_data.get('ios_version', 'Unknown') if hasattr(device, 'custom_field_data') else 'Unknown'
        last_upgraded = device.custom_field_data.get('last_upgraded', 'Never') if hasattr(device, 'custom_field_data') else 'Never'
        
        # Determine the status class based on version
        status = "Unknown"
        status_class = "pending"
        flash_space = "Unknown"
        
        if ios_version != 'Unknown':
            # This is a simple example - you'd have your own logic to determine upgrade status
            if ios_version.startswith('17'):
                status = "Up to Date"
                status_class = "success"
            elif ios_version.startswith('16.9') or ios_version.startswith('16.12'):
                status = "Update Available"
                status_class = "pending"
            else:
                status = "Outdated"
                status_class = "failed"
        
        # Get flash space from custom field if available
        flash_space = device.custom_field_data.get('flash_space', 'Unknown') if hasattr(device, 'custom_field_data') else 'Unknown'
        
        # Get the region if available
        region = "Unknown"
        if device.location and device.location.parent:
            region = device.location.parent.name
        
        devices.append({
            "id": str(device.id),
            "hostname": device.name,
            "ip_address": str(device.primary_ip.address.ip) if device.primary_ip else "No IP",
            "device_type": device.device_type.model if device.device_type else "Unknown",
            "ios_version": ios_version,
            "status": status,
            "status_class": status_class,
            "flash_space": flash_space,
            "last_upgraded": last_upgraded,
            "region": region
        })
    
    
    tftp_servers = [
        {"value": "default", "label": "Default Ansible Server (172.21.17.41)"},
        {"value": "manual", "label": "Manual Entry"}
    ]
    
    # Get initial list of IOS images
    # For initial page load, we'll set an empty list and load via AJAX
    ios_images = []
    context = {
        'device_types': device_types,
        'regions': regions,
        'devices': devices,
        'ios_images': ios_images,
        'tftp_servers': tftp_servers,
        'default_tftp_server': '172.21.17.41',
        'default_tftp_path': '/srv/tftp/',
        
    }
    
    return render(request, 'naas/switch_reboot.html', context)

def show_version(request):
    """
    Connect to the Ansible server and execute a playbook to get 'show version' from the switch.
    Uses credentials from environment or database.
    Returns the parsed version information as JSON.
    """
    if request.method != 'POST':
        return JsonResponse({'success': False, 'error': 'Only POST method is allowed'})
    
    # Get switch IP from request
    switch_ip = request.POST.get('switch_ip')
    switch_ip = switch_ip.split('/')[0]
    if not switch_ip:
        return JsonResponse({
            'success': False, 
            'error': 'Missing required parameter: switch_ip'
        })
    
    # Get credential profile from request or use default
    credential_profile = request.POST.get('credential_profile', 'default')
    
    # Get credentials from database or environment based on the profile
    credentials = get_device_credentials(switch_ip, credential_profile)
    
    try:
        # Prepare the variables for Ansible
        extra_vars = {
            'switch_ip': switch_ip,
            'ansible_user': credentials.get('username'),
            'ansible_password': credentials.get('password')
        }
        
        # Convert to JSON string
        extra_vars_json = json.dumps(extra_vars)
        
        # Get Ansible VM connection details from environment or settings
        ansible_connection = get_ansible_connection_details()
        
        # Force password authentication since that's what you're using
        ansible_connection['use_key'] = False
        
        # Ensure we have the password from your environment or settings
        if not ansible_connection['password']:
            ansible_connection['password'] = os.environ.get('ANSIBLE_VM_PASSWORD', '')

        venv_path = "~/.ios_upgrade"  # or full path like "/home/ubuntu/.ios_upgrade"
        
        # Use sshpass for non-interactive password authentication
        ssh_cmd = [
            'sshpass', '-p', ansible_connection['password'],
            'ssh',
            '-o', 'StrictHostKeyChecking=no',
            f"{ansible_connection['username']}@{ansible_connection['hostname']}",
            f"source {venv_path}/bin/activate && "
            f"cd {ansible_connection['ansible_path']} && ansible-playbook -i '{switch_ip},' cisco_show_version.yml -e '{extra_vars_json}'"
        ]
        
        # Execute the command with appropriate authentication
        import subprocess
        import os
        import re
        
        # Set environment for subprocess
        ssh_env = os.environ.copy()
        
        # Execute the command
        process = subprocess.Popen(
            ssh_cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            universal_newlines=True,
            env=ssh_env
        )
        
        stdout, stderr = process.communicate()
        
        # Log the raw output for debugging
        logger.debug(f"Ansible stdout: {stdout}")
        logger.debug(f"Ansible stderr: {stderr}")
        
        if process.returncode != 0:
            logger.error(f"Ansible execution failed: {stderr}")
            return JsonResponse({
                'success': False,
                'error': f'Ansible execution failed: {stderr}'
            })
        
        # Parse the Ansible output to extract version information
        version_info = parse_show_version(stdout)
        
        # Log the parsed info for debugging
        logger.debug(f"Parsed version info: {version_info}")
        
        # Ensure we have critical info
        if not version_info['ios_version']:
            # Try harder to find the version in the output
            version_match = re.search(r'Version\s+([0-9.]+)', stdout)
            if version_match:
                version_info['ios_version'] = version_match.group(1)
        
        # Make sure display values are cleaned up
        for key in version_info:
            if isinstance(version_info[key], str):
                # Remove any excessive newlines or formatting
                version_info[key] = version_info[key].replace('\\n', ' ').strip()
        
        return JsonResponse({
            'success': True,
            'version_info': version_info
        })
            
    except Exception as e:
        logger.error(f"Error in show_version: {str(e)}")
        return JsonResponse({
            'success': False,
            'error': f'An error occurred: {str(e)}'
        })

def get_ansible_connection_details():
    """
    Get Ansible VM connection details from environment variables or settings.
    Returns a dictionary with connection parameters.
    """
    import os
    from django.conf import settings
    
    # Default values
    connection = {
        'device_type': 'linux',
        'hostname': '172.21.17.41',
        'username': 'ubuntu',
        'ansible_path': 'ios_upgrade/',
        'use_key': False,
        'key_path': None,
        'password': os.environ.get('ANSIBLE_VM_PASSWORD', ''),
        'port': 22
    }
    
    # Try to get from environment variables
    connection['hostname'] = os.environ.get('ANSIBLE_VM_HOSTNAME', connection['hostname'])
    connection['username'] = os.environ.get('ANSIBLE_VM_USERNAME', connection['username'])
    connection['ansible_path'] = os.environ.get('ANSIBLE_VM_PATH', connection['ansible_path'])
    connection['use_key'] = os.environ.get('ANSIBLE_VM_USE_KEY', 'false').lower() == 'true'

    if connection['use_key']:
        connection['key_path'] = os.environ.get('ANSIBLE_VM_KEY_PATH')
    else:
        connection['password'] = os.environ.get('ANSIBLE_VM_PASSWORD', '')
    
    # If settings has ANSIBLE_VM_CONNECTION, use that
    if hasattr(settings, 'ANSIBLE_VM_CONNECTION'):
        connection.update(settings.ANSIBLE_VM_CONNECTION)
    
    return connection

def get_device_credentials(switch_ip, credential_profile='default'):
    """
    Get device credentials from database or environment variables.
    Returns a dictionary with username and password.
    """
    # Option 1: Get from environment variables
    import os
    
    # Default credentials from environment
    default_username = os.environ.get('CISCO_DEFAULT_USERNAME')
    default_password = os.environ.get('CISCO_DEFAULT_PASSWORD')
    
    # Profile-specific credentials from environment
    profile_username = os.environ.get(f'CISCO_{credential_profile.upper()}_USERNAME')
    profile_password = os.environ.get(f'CISCO_{credential_profile.upper()}_PASSWORD')
    
    # Use profile credentials if available, otherwise fall back to default
    username = profile_username or default_username
    password = profile_password or default_password
    
    # Option 2: Get from database (example, adapt to your model)
    if not username or not password:
        try:
            # Example: query credentials from a hypothetical model
            # Adjust this to use your actual credential storage model
            from django.conf import settings
            
            # Try to find device-specific credentials first
            # device_creds = DeviceCredential.objects.filter(device_ip=switch_ip).first()
            # 
            # if device_creds:
            #     username = device_creds.username
            #     password = device_creds.password
            # else:
            #     # Fall back to profile credentials
            #     profile_creds = CredentialProfile.objects.filter(name=credential_profile).first()
            #     if profile_creds:
            #         username = profile_creds.username
            #         password = profile_creds.password
            
            # Example: if using Django settings for credentials
            if hasattr(settings, 'NETWORK_DEVICE_CREDENTIALS'):
                creds = settings.NETWORK_DEVICE_CREDENTIALS.get(credential_profile, {})
                username = username or creds.get('username')
                password = password or creds.get('password')
                
        except Exception as e:
            logger.error(f"Error retrieving credentials from database: {str(e)}")
            # Continue with environment variables if available
    
    # If still no credentials, use a fallback (for development only, not recommended for production)
    if not username or not password:
        logger.warning("Using fallback credentials - this is not secure for production!")
        username = os.environ.get('CU_net_username', '')
        password = os.environ.get('CU_net_password', '')
    
    return {
        'username': username,
        'password': password
    }

def parse_show_version(stdout):
    """
    Parse the Ansible playbook output to extract version information.
    
    Args:
        stdout: The raw output from the ansible-playbook command.
        
    Returns:
        dict: Structured version information
    """
    import json
    import re

    # Initialize default version info
    version_info = {
        'ios_version': None,
        'device_model': None,
        'serial_number': None,
        'uptime': None,
        'total_memory': None,
        'boot_file': None,
        'image_file': None,
        'raw_output': stdout
    }
    
    # Look for the JSON data in the Ansible output
    # The JSON structure is between "ok: [IP] => {" and before "PLAY RECAP"
    json_pattern = r'TASK \[Print output as JSON\][\s\S]*?ok: \[[^\]]+\] => (\{[\s\S]*?\})\s*PLAY RECAP'
    json_match = re.search(json_pattern, stdout)
    
    if json_match:
        try:
            # Extract the JSON part
            json_data = json_match.group(1)
            data = json.loads(json_data)
            
            # Extract version info from the structured data
            if 'output' in data:
                output_data = data['output']
                
                # Get data from ansible_facts if available
                if 'ansible_facts' in output_data:
                    facts = output_data['ansible_facts']
                    version_info['ios_version'] = facts.get('net_version')
                    version_info['device_model'] = facts.get('net_model')
                    version_info['serial_number'] = facts.get('net_serialnum')
                    
                    # Format memory properly
                    if 'net_memtotal_mb' in facts:
                        version_info['total_memory'] = f"{facts['net_memtotal_mb']} MB"
                
                # Get raw command output
                if 'stdout' in output_data:
                    raw_output = output_data['stdout']
                    version_info['raw_output'] = raw_output
                    
                    # Extract uptime from raw output (just the first line)
                    uptime_match = re.search(r'uptime is ([^\n]+)', raw_output)
                    if uptime_match:
                        version_info['uptime'] = uptime_match.group(1).strip()
                    
                    # Extract boot file
                    boot_match = re.search(r'BOOTLDR:\s+([^\n]+)', raw_output)
                    if boot_match:
                        version_info['boot_file'] = boot_match.group(1).strip()
                    
                    # Extract image file
                    image_match = re.search(r'System image file is\s+["\'](.*?)["\']', raw_output)
                    if image_match:
                        version_info['image_file'] = image_match.group(1).strip()
        
        except json.JSONDecodeError as e:
            print(f"Error parsing JSON: {e}")
    
    # If we still don't have all the information, try parsing the raw output directly
    if not version_info['ios_version']:
        # Look for version in the raw output
        version_match = re.search(r'Cisco IOS XE Software,\s+Version\s+([0-9.]+)', stdout)
        if version_match:
            version_info['ios_version'] = version_match.group(1)
    
    if not version_info['device_model']:
        # Try to find model from the "cisco C9300-48U" pattern
        model_match = re.search(r'cisco\s+([^\s(]+)', stdout)
        if model_match:
            version_info['device_model'] = model_match.group(1)
    
    if not version_info['serial_number']:
        # Look for serial number
        serial_match = re.search(r'System Serial Number\s*:\s*(\S+)', stdout)
        if serial_match:
            version_info['serial_number'] = serial_match.group(1)
    
    if not version_info['uptime']:
        # Try to find uptime
        uptime_match = re.search(r'uptime is ([^\n]+)', stdout)
        if uptime_match:
            version_info['uptime'] = uptime_match.group(1).strip()
    
    if not version_info['image_file']:
        # Try to find image file
        image_match = re.search(r'System image file is\s+["\'](.*?)["\']', stdout)
        if image_match:
            version_info['image_file'] = image_match.group(1).strip()
    
    if not version_info['boot_file']:
        # Try to find boot file
        boot_match = re.search(r'BOOTLDR:\s+([^\n]+)', stdout)
        if boot_match:
            version_info['boot_file'] = boot_match.group(1).strip()
    
    if not version_info['total_memory'] and 'processor with' in stdout:
        # Try to find memory
        memory_match = re.search(r'with\s+([0-9]+K)/([0-9]+K)\s+bytes of memory', stdout)
        if memory_match:
            version_info['total_memory'] = memory_match.group(1)
    
    return version_info


def handle_form_submission(request):
    """
    Process the IOS upgrade form submission.
    """
    try:
        # Extract form data
        ip_switch = request.POST.get('ipSwitch')
        device_type = request.POST.get('deviceType')
        tftp_source = request.POST.get('tftpSource')
        file_path = request.POST.get('filePath')
        primary_push = request.POST.get('primaryPush')
        
        # Create a job ID
        job_id = f"JOB-{str(uuid4())[:8].upper()}"
        
        # Look up the device in Nautobot
        device = None
        try:
            # Try to find by IP first
            from nautobot.ipam.models import IPAddress
            ip_obj = IPAddress.objects.filter(address__contains=ip_switch).first()
            if ip_obj and ip_obj.assigned_object:
                device = ip_obj.assigned_object.parent
            
            # If not found by IP, try by name
            if not device:
                device = Device.objects.filter(name__icontains=ip_switch).first()
                
            if not device:
                return JsonResponse({
                    'success': False,
                    'error': f"Device with IP/hostname {ip_switch} not found in Nautobot"
                })
        except Exception as e:
            logger.error(f"Error looking up device: {str(e)}")
            # Continue even if device lookup fails - maybe it's not in Nautobot yet
        
        
        # 1. Create a database record for the job (e.g., in a custom model)
        # 2. Trigger the Ansible playbook execution
        
        # For a real implementation, execute Ansible on the remote VM:
        result = execute_ansible_playbook(ip_switch, device_type, tftp_source, file_path, primary_push)
        
        # Store the job details in   database
        # job_record = UpgradeJob.objects.create(
        #     job_id=job_id,
        #     device=device,
        #     device_ip=ip_switch,
        #     device_type=device_type,
        #     status="Pending",
        #     created_by=request.user,
        #     ansible_output=result.get('output', '')
        # )
        
        # Return success response
        return JsonResponse({
            'success': True,
            'message': 'Job created successfully',
            'job_id': job_id
        })
        
    except Exception as e:
        logger.error(f"Error processing upgrade form: {str(e)}")
        return JsonResponse({
            'success': False,
            'error': str(e)
        })

def execute_ansible_playbook(ip_switch, device_type, tftp_source, file_path, primary_push):
    """
    Execute the Ansible playbook on the remote Ansible VM.
    
    This function would connect to   Ansible VM via SSH and trigger 
    the playbook execution with the appropriate parameters.
    """
    try:
        # Construct the variables to pass to Ansible
        extra_vars = {
            'ip_address': ip_switch,
            'device_type': device_type,
            'tftp_server': tftp_source,
            'ios_image_path': file_path,
            'action': primary_push
        }
        
        # Convert to JSON string
        extra_vars_json = json.dumps(extra_vars)
        
        # Build the SSH command
        ssh_cmd = [
            'ssh',
            'ubuntu@172.21.17.41',  # Ansible VM IP
            f'cd /path/to/ansible && ansible-playbook cisco_ios_upgrade.yml -e \'{extra_vars_json}\''
        ]
        
        # Execute the command
        process = subprocess.Popen(
            ssh_cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            universal_newlines=True
        )
        
        stdout, stderr = process.communicate()
        
        if process.returncode != 0:
            raise Exception(f"Ansible execution failed: {stderr}")
        
        return {
            'success': True,
            'output': stdout
        }
        
    except Exception as e:
        logger.error(f"Error executing Ansible playbook: {str(e)}")
        raise

@login_required
def validate_upgrade_form(request):
    """
    Validate the upgrade form without submitting it.
    """
    if request.method == 'POST':
        # Perform validation checks
        errors = []
        
        # Check required fields
        ip_switch = request.POST.get('ipSwitch')
        if not ip_switch:
            errors.append("IP Switch is required")
        
        device_type = request.POST.get('deviceType')
        if not device_type:
            errors.append("Device Type is required")
        
        tftp_source = request.POST.get('tftpSource')
        if not tftp_source:
            errors.append("TFTP/SCP Server is required")
        
        file_path = request.POST.get('filePath')
        if not file_path:
            errors.append("File Path is required")
        
        # Check if the device exists in Nautobot
        if ip_switch:
            device_found = False
            try:
                # Try to find by IP first
                from nautobot.ipam.models import IPAddress
                ip_obj = IPAddress.objects.filter(address__contains=ip_switch).first()
                if ip_obj and ip_obj.assigned_object:
                    device_found = True
                
                # If not found by IP, try by name
                if not device_found:
                    device = Device.objects.filter(name__icontains=ip_switch).first()
                    if device:
                        device_found = True
                
                if not device_found:
                    errors.append(f"Device with IP/hostname {ip_switch} not found in Nautobot")
            except Exception as e:
                logger.error(f"Error looking up device: {str(e)}")
                errors.append(f"Error validating device: {str(e)}")
        
        # Return validation result
        if errors:
            return JsonResponse({
                'valid': False,
                'errors': errors
            })
        else:
            return JsonResponse({
                'valid': True
            })
    
    return JsonResponse({
        'valid': False,
        'errors': ['Invalid request method']
    })

@login_required
def job_detail(request):
    """
    Get detailed information about a specific job.
    """
    job_id = request.GET.get('job_id')
    if not job_id:
        return JsonResponse({
            'success': False,
            'error': 'Job ID is required'
        })
    
    # In production, fetch this from   database
    job_data = JOB_DETAIL.get(job_id)
    if not job_data:
        return JsonResponse({
            'success': False,
            'error': f'Job with ID {job_id} not found'
        })
    
    # Render the job detail HTML
    html = render_job_detail(job_data)
    
    return JsonResponse({
        'success': True,
        'html': html
    })

def render_job_detail(job_data):
    """
    Render the job detail HTML for the modal.
    """
    
    html = f"""
    <div class="tabs">
        <button class="tab-button active" data-modal-tab="jobOverview">Overview</button>
        <button class="tab-button" data-modal-tab="jobLogs">Logs</button>
        <button class="tab-button" data-modal-tab="jobConfig">Configuration</button>
    </div>
    
    <div class="tab-content active" id="jobOverview-modal">
        <div class="row">
            <div class="col-md-6">
                <p><strong>Device:</strong> {job_data['device']}</p>
                <p><strong>Device Type:</strong> {job_data['device_type']}</p>
                <p><strong>Job Type:</strong> {job_data['job_type']}</p>
                <p><strong>Status:</strong> <span class="status-badge status-{job_data['status_class']}">{job_data['status']}</span></p>
            </div>
            <div class="col-md-6">
                <p><strong>Started:</strong> {job_data['started_at']}</p>
                <p><strong>Completed:</strong> {job_data['completed_at']}</p>
                <p><strong>Duration:</strong> {job_data['duration']}</p>
                <p><strong>Requested By:</strong> {job_data['requested_by']}</p>
            </div>
        </div>
        <h4 style="border-bottom: 1px solid #ddd; padding-bottom: 10px;">Status Timeline</h4>
        <div class="timeline" style="margin-top: 15px;">
    """
    
    # Add timeline items
    for event in job_data['timeline']:
        html += f"""
            <div class="timeline-item">
                <div><strong>{event['title']}</strong> <span class="timeline-time">{event['time']}</span></div>
                <div class="text-muted">{event['description']}</div>
            </div>
        """
    
    html += """
        </div>
    </div>
    
    <div class="tab-content" id="jobLogs-modal">
        <div style="margin-bottom: 15px;">
            <div class="input-group">
                <input type="text" placeholder="Search logs...">
                <button class="btn-outline-secondary">
                    <i class="fas fa-search"></i>
                </button>
            </div>
        </div>
        <div style="background-color: #000; color: #00ff00; padding: 15px; border-radius: 4px; height: 400px; overflow-y: auto; font-family: monospace;">
    """
    
    # Add log entries
    for log in job_data['logs']:
        html += f"""
            <div>[{log['time']}] {log['level']}: {log['message']}</div>
        """
    
    html += """
        </div>
    </div>
    
    <div class="tab-content" id="jobConfig-modal">
        <div style="background-color: #f8f9fa; padding: 15px; border-radius: 4px; margin-bottom: 15px;">
            <i class="fas fa-info-circle"></i> This tab shows the configuration used for this upgrade job.
        </div>
        <div>
    """
    
    # Add configuration items
    for key, value in job_data['config'].items():
        html += f"""
            <div class="row" style="margin-bottom: 10px; padding-bottom: 10px; border-bottom: 1px solid #eee;">
                <div class="col-md-6"><strong>{key.replace('_', ' ').title()}:</strong></div>
                <div class="col-md-6">{value}</div>
            </div>
        """
    
    html += """
        </div>
    </div>
    """
    
    return html

@login_required
def refresh_job_status(request):
    """
    Refresh the job status list.
    """
    # In production,  fetch the latest jobs from   database
    jobs = SAMPLE_JOBS
    
    # Render the job list HTML
    html = render_job_list(jobs)
    
    return JsonResponse({
        'success': True,
        'html': html
    })

def render_job_list(jobs):
    """
    Render the job list HTML.
    """
    # In a real implementation,  Django's template system
    if not jobs:
        return """
            <div class="row">
                <div class="col-md-12">
                    <p class="text-center text-muted">No jobs found</p>
                </div>
            </div>
        """
    
    html = ""
    for job in jobs:
        html += f"""
            <div class="row" style="margin-bottom: 15px; padding-bottom: 15px; border-bottom: 1px solid #eee;">
                <div class="col-md-6">
                    <p><strong>Job ID:</strong> <a href="#" class="job-detail-link" data-job-id="{job['id']}">{job['job_id']}</a></p>
                    <p><strong>Device:</strong> {job['device_ip']}</p>
                    <p><strong>Type:</strong> {job['device_type']}</p>
                    <p><strong>Started:</strong> {job['started_at']}</p>
                    <p><strong>Status:</strong> <span class="status-badge status-{job['status_class']}">{job['status']}</span></p>
                </div>
                <div class="col-md-6">
                    <h4>Timeline</h4>
                    <div class="timeline">
        """
        
        # Add timeline items
        for event in job['timeline']:
            html += f"""
                        <div class="timeline-item">
                            <div><strong>{event['title']}</strong> <span class="timeline-time">{event['time']}</span></div>
                            <div class="text-muted">{event['description']}</div>
                        </div>
            """
        
        html += """
                    </div>
                </div>
            </div>
        """
    
    return html

@login_required
def search_devices(request):
    params = request.GET
    return fetch_devices(params)
    

def render_device_list(devices):
    """
    Render the device list HTML.
    """
    # In a real implementation, Django's template system
    if not devices:
        return """
            <div class="row">
                <div class="col-md-12">
                    <p class="text-center text-muted">No devices found</p>
                </div>
            </div>
        """
    
    html = ""
    for device in devices:
        html += f"""
            <div class="row" style="margin-bottom: 15px; padding-bottom: 15px; border-bottom: 1px solid #eee;">
                <div class="col-md-12">
                    <div class="checkbox-container" style="float: left; margin-right: 15px;">
                        <input type="checkbox" id="device{device['id']}" class="device-checkbox" value="{device['id']}">
                    </div>
                    <div>
                        <p><strong>Hostname:</strong> {device['hostname']} <small class="text-muted">({device['ip_address']})</small></p>
                        <p><strong>Device Type:</strong> {device['device_type']}</p>
                        <p><strong>Current IOS:</strong> {device['ios_version']}</p>
                        <p><strong>Last Upgraded:</strong> {device['last_upgraded']}</p>
                        <p><strong>Status:</strong> <span class="status-badge status-{device['status_class']}">{device['status']}</span></p>
                        <div style="margin-top: 10px;">
                            <button class="btn-outline-primary upgrade-device-btn" data-device-id="{device['id']}" style="padding: 5px 10px; font-size: 14px; margin-right: 5px;">
                                <i class="fas fa-sync"></i> Upgrade
                            </button>
                            <button class="btn-outline-secondary device-history-btn" data-device-id="{device['id']}" style="padding: 5px 10px; font-size: 14px; margin-right: 5px;">
                                <i class="fas fa-history"></i> History
                            </button>
                            <button class="btn-outline-secondary edit-device-btn" data-device-id="{device['id']}" style="padding: 5px 10px; font-size: 14px;">
                                <i class="fas fa-edit"></i> Edit
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        """
    
    return html

@login_required
def get_device_info(request):
    """
    Get information about a specific device.
    """
    device_id = request.GET.get('device_id')
    if not device_id:
        return JsonResponse({
            'success': False,
            'error': 'Device ID is required'
        })
    
    try:
        # Get the actual device from Nautobot
        device = Device.objects.get(id=device_id)
        
        return JsonResponse({
            'success': True,
            'ip_address': str(device.primary_ip.address.ip) if device.primary_ip else "",
            'device_type': device.device_type.model,
            'hostname': device.name
        })
    except Device.DoesNotExist:
        return JsonResponse({
            'success': False,
            'error': f'Device with ID {device_id} not found'
        })
    except Exception as e:
        logger.error(f"Error fetching device info: {str(e)}")
        return JsonResponse({
            'success': False,
            'error': f'Error retrieving device information: {str(e)}'
        })


@login_required
def job_progress(request):
    """
    Get the current progress of a job.
    """
    job_id = request.GET.get('job_id')
    if not job_id:
        return JsonResponse({'success': False, 'error': 'Job ID is required'})
    
    try:
        # In a real application, you would query your job database
        # job = UpgradeJob.objects.get(job_id=job_id)
        
        # For this example, we'll simulate job progress
        # In a real application, you would get this from the job record
        import time
        import random
        
        # Get current timestamp
        current_time = time.time()
        
        # Extract timestamp from job ID (just for simulation)
        job_timestamp = int(job_id.split('-')[1], 16) % 100000
        
        # Calculate elapsed time (in seconds)
        elapsed_time = current_time - job_timestamp
        
        # Simulate job progress based on elapsed time
        # In a real application, this would come from the actual job status
        if elapsed_time < 5:
            status = 'Running'
            progress = int(elapsed_time * 10)  # 0-50% in first 5 seconds
            message = 'Starting pre-upgrade checks'
        elif elapsed_time < 10:
            status = 'Running'
            progress = 50 + int((elapsed_time - 5) * 5)  # 50-75% in next 5 seconds
            message = 'Transferring IOS image'
        elif elapsed_time < 15:
            status = 'Running'
            progress = 75 + int((elapsed_time - 10) * 5)  # 75-100% in final 5 seconds
            message = 'Installing IOS image'
        else:
            # Randomly decide if job succeeds or fails
            if random.random() < 0.8:  # 80% success rate
                status = 'Success'
                progress = 100
                message = 'Upgrade completed successfully'
            else:
                status = 'Failed'
                progress = random.randint(75, 95)
                message = 'Upgrade failed: Error during installation'
        
        # Add the log entry
        if not hasattr(request.session, 'job_logs'):
            request.session.job_logs = {}
        
        if job_id not in request.session.job_logs:
            request.session.job_logs[job_id] = []
        
        request.session.job_logs[job_id].append({
            'timestamp': datetime.datetime.now().strftime('%H:%M:%S'),
            'message': message
        })
        
        return JsonResponse({
            'success': True,
            'status': status,
            'progress': progress,
            'message': message,
            'logs': request.session.job_logs.get(job_id, [])
        })
    
    except Exception as e:
        logger.error(f"Error getting job progress: {str(e)}")
        return JsonResponse({
            'success': False,
            'error': str(e)
        })


@login_required
@csrf_protect
def save_device_info(request):
    """
    Save device information to the database.
    """
    if request.method != 'POST':
        return JsonResponse({'success': False, 'error': 'Only POST method is allowed'})
    
    try:
        # Extract data from request
        device_ip = request.POST.get('device_ip')
        ios_version = request.POST.get('ios_version')
        model = request.POST.get('model')
        flash_space = request.POST.get('flash_space') 
        hostname = request.POST.get('hostname')  # Add hostname parameter from frontend
        
        if not hostname and not device_ip:
            return JsonResponse({'success': False, 'error': 'Device IP or hostname is required'})
        
        # Find the device in Nautobot
        from nautobot.dcim.models import Device
        
        # Try to find the device by hostname first (more reliable)
        device = None
        if hostname:
            device = Device.objects.filter(name=hostname).first()
        
        # If not found by hostname, try by IP (this is a simplifier approach)
        if not device and device_ip:
            # Just look at primary IP fields which are more direct
            device = Device.objects.filter(
                models.Q(primary_ip4__host=device_ip) | 
                models.Q(primary_ip6__host=device_ip)
            ).first()
        
        if not device:
            return JsonResponse({
                'success': False, 
                'error': f'Device not found with hostname {hostname} or IP {device_ip}'
            })
        
        # Update custom fields for the device
        if not hasattr(device, 'custom_field_data'):
            # Initialize custom fields if not already present
            device.custom_field_data = {}
        
        # Save device information to custom fields
        device.custom_field_data['ios_version'] = ios_version
        device.custom_field_data['flash_space'] = flash_space
        device.custom_field_data['last_upgraded'] = datetime.datetime.now().strftime('%Y-%m-%d')
        
        # Save the device
        device.save()
        
        return JsonResponse({
            'success': True,
            'message': f'Device information updated for {hostname or device_ip}'
        })
        
    except Exception as e:
        import logging
        import traceback
        logger = logging.getLogger(__name__)
        logger.error(f"Error saving device info: {str(e)}")
        logger.error(traceback.format_exc())
        
        return JsonResponse({
            'success': False,
            'error': str(e)
        })


def list_tftp_images(request):
    """
    List available IOS images on the TFTP server using Netmiko.
    This function connects to the TFTP server via SSH and lists all files in the TFTP directory
    and its subdirectories. It also calculates and provides MD5 checksums for each image.
    """
    try:
        # Get connection details
        conn_details = get_ansible_connection_details()
        
        # Base TFTP directory
        tftp_base_dir = '/srv/tftp/9300'
        
        # Connect to the server using Netmiko
        net_connect = ConnectHandler(
            device_type=conn_details['device_type'],
            host=conn_details['hostname'],
            username=conn_details['username'],
            password=conn_details['password'],
            port=conn_details['port']
        )
        
        # Initialize results
        images = []
        
        # Function to process a directory
        def process_directory(directory):
            nonlocal images, net_connect
            
            # Get the listing of the directory
            dirs_output = net_connect.send_command(f"ls -la {directory}")
            
            # Parse the listing to find image files and subdirectories
            subdirs = []
            for line in dirs_output.splitlines():
                parts = line.split()
                if len(parts) < 9:
                    continue
                    
                file_name = parts[8]
                
                # Skip . and .. directory entries
                if file_name in ['.', '..']:
                    continue
                
                # Check if this is a directory
                if line.startswith('d'):
                    # Add to list of subdirectories to process
                    subdirs.append(f"{directory}{file_name}/")
                    continue
                
                # Check if this is an image file (ends with .bin or .image)
                if file_name.endswith('.bin') or file_name.endswith('.image'):
                    # Extract device type from filename if possible (common naming patterns)
                    device_type = "Unknown"
                    
                    # Attempt to infer device type from filename
                    if "cat9k" in file_name.lower():
                        device_type = "Catalyst 9000"
                    elif "cat3k" in file_name.lower():
                        device_type = "Catalyst 3000"
                    elif "3850" in file_name:
                        device_type = "Catalyst 3850"
                    elif "9300" in file_name:
                        device_type = "Catalyst 9300"
                    elif "9400" in file_name:
                        device_type = "Catalyst 9400"
                    elif "9500" in file_name:
                        device_type = "Catalyst 9500"
                        
                    # Get file size in more readable format
                    file_size = parts[4]
                    size_str = f"{int(file_size) / 1024 / 1024:.2f} MB"
                    
                    # Path to file
                    file_path = f"{directory}{file_name}"
                    
                    # Calculate MD5 checksum for the file
                    try:
                        md5_output = net_connect.send_command(
                            f"md5sum {file_path}",
                            expect_string=r"ubuntu@ubuntu:~\$",
                            read_timeout=90
                        )
                    except NetMikoTimeoutException as e:
                        # Log the timeout and continue
                        logger.warning(f"Timeout calculating MD5 for {file_path}")
                        md5_checksum = "Calculation timed out"
                    md5_checksum = "Unknown"
                    
                    # Parse MD5 output (format: [md5sum] [filename])
                    if md5_output and len(md5_output.split()) >= 1:
                        md5_checksum = md5_output.split()[0]
                    
                    images.append({
                        "value": file_name,
                        "label": f"{file_name} ({size_str}) - {directory}",
                        "device_type": device_type,
                        "size": size_str,
                        "path": file_path,
                        "md5_checksum": md5_checksum
                    })
            
            # Process all subdirectories
            for subdir in subdirs:
                process_directory(subdir)
        
        # Start processing from the base directory
        process_directory(tftp_base_dir)
        
        # Sort images by device type and then by name
        images = sorted(images, key=lambda x: (x['device_type'], x['value']))
        
        # Extract unique device types for filtering
        device_types = sorted(list(set(image['device_type'] for image in images)))
        
        # Close SSH connection
        net_connect.disconnect()
        
        return JsonResponse({
            'success': True,
            'images': images,
            'device_types': device_types
        })
    
    except Exception as e:
        import traceback
        return JsonResponse({
            'success': False,
            'error': str(e),
            'trace': traceback.format_exc()
        })
    

@login_required
@csrf_protect
def start_upgrade(request):
    """
    Start the upgrade process for selected devices.
    This function handles all upgrade types:
    - upload: Only uploads the firmware image
    - install: Only installs a previously uploaded image
    - upload_install: Uploads and then installs the firmware when upload completes
    
    Each operation can be executed immediately or scheduled for later.
    """
    if request.method != 'POST':
        return JsonResponse({'success': False, 'error': 'Only POST method is allowed'})
    
    try:
        devices = request.data.get('devices', [])
        result = start_ios_upgrade(request.user, devices, request.data)
        return Response({'success': True, 'message': 'Jobs created', **result}, status=status.HTTP_200_OK)
    except Exception as e:
        return Response({'success': False, 'error': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

@login_required
def job_progress(request):
    """
    Get the progress of a job with detailed logs.
    """
    job_id = request.GET.get('job_id')
    if not job_id:
        return JsonResponse({
            'success': False,
            'error': 'Job ID is required'
        })
    
    try:
        # Look up the job result directly by primary key (UUID)
        job_result = JobResult.objects.get(pk=job_id)
        
        # Log raw job result data for debugging
        logger.info(f"Raw job result for {job_id}: status={job_result.status}")
        
        # Get detailed job logs from the database
        logs = []
        
        # Try to get real logs from various sources in JobResult
        try:
            # First try: Get logs from Nautobot's JobResult method
            # This attempts to get all detailed logs with timestamps
            if hasattr(job_result, 'get_log'):
                try:
                    for entry in job_result.get_log():
                        logs.append({
                            'timestamp': entry.get('created', ''),
                            'message': entry.get('message', '')
                        })
                except Exception as log_error:
                    logger.info(f"Could not get logs with get_log method: {str(log_error)}")
                    
            # Second try: Direct access to job_result logs if it's a list
            elif hasattr(job_result, 'log') and isinstance(job_result.log, list):
                for entry in job_result.log:
                    if isinstance(entry, dict):
                        logs.append({
                            'timestamp': entry.get('created', ''),
                            'message': entry.get('message', '')
                        })
                    else:
                        logs.append({
                            'timestamp': '',
                            'message': str(entry)
                        })
            
            # Third try: If job has data with log entries
            elif hasattr(job_result, 'data') and job_result.data and 'log_entries' in job_result.data:
                for entry in job_result.data['log_entries']:
                    if isinstance(entry, dict):
                        logs.append({
                            'timestamp': entry.get('timestamp', ''),
                            'message': entry.get('message', '')
                        })
                    else:
                        logs.append({
                            'timestamp': '',
                            'message': str(entry)
                        }) 
            
            # Fallback: If log is a method or unsuccessful, check if there's job output
            if not logs and hasattr(job_result, 'job_output') and job_result.job_output:
                # Split the output by line and add as log entries
                output_lines = job_result.job_output.split('\n')
                for line in output_lines:
                    if line.strip():
                        logs.append({
                            'timestamp': '',
                            'message': line.strip()
                        })
            
            # Last fallback: Check the job_result string representation
            if not logs:
                job_repr = str(job_result)
                
                # Try to extract device IP and status from the string representation
                import re
                match = re.search(r'Device\s+(\S+).+?\((\w+)\)', job_repr)
                if match:
                    device_ip = match.group(1)
                    status = match.group(2)
                    
                    # Create a log entry
                    logs.append({
                        'timestamp': '',
                        'message': f"Firmware upgrade for device {device_ip} completed with status: {status}"
                    })
                else:
                    # Just add the string representation as a message
                    logs.append({
                        'timestamp': '',
                        'message': f"Job completed: {job_repr}"
                    })
            
        except Exception as e:
            logger.error(f"Error getting detailed logs: {str(e)}")
            logs.append({
                'timestamp': '',
                'message': f"Error retrieving logs: {str(e)}"
            })
        
        # If no logs were found through any method, add a default message
        if not logs:
            logs.append({
                'timestamp': '',
                'message': 'No detailed logs available for this job'
            })
        
        # Extract status directly from the job_result object
        # Also check if "SUCCESS" is in the string representation
        job_repr = str(job_result)
        
        # Determine success based on job_repr or status
        is_success = "SUCCESS" in job_repr or job_result.status == "completed"
        is_failed = "FAILED" in job_repr or job_result.status in ["failed", "errored"]
        is_running = "RUNNING" in job_repr or job_result.status == "running"
        
        # Calculate progress based on inferred status
        progress = 0
        if is_running:
            progress = 50
        elif is_success or is_failed:
            progress = 100
        
        # Determine frontend status
        if is_success:
            frontend_status = 'Success'
        elif is_failed:
            frontend_status = 'Failed'
        elif is_running:
            frontend_status = 'Running'
        else:
            frontend_status = 'Pending'
        
        # Log the inferred status
        logger.info(f"Inferred status for job {job_id}: {frontend_status}, progress: {progress}")
        
        # Job is completed if it's success or failed
        is_completed = is_success or is_failed
        
        # Return job status with details
        return JsonResponse({
            'success': True,
            'status': frontend_status,
            'progress': progress,
            'logs': logs,
            'job_id': job_id,
            'completed': is_completed
        })
    
    except JobResult.DoesNotExist:
        return JsonResponse({
            'success': False,
            'error': f'Job with ID {job_id} not found'
        })
    except Exception as e:
        logger.error(f"Error getting job progress: {str(e)}")
        return JsonResponse({
            'success': False,
            'error': str(e)
        })

@login_required
def job_history(request):
    """
    Return job history for the current user.
    """
    try:
        # Get all JobResults for DeviceUpgradeJob
        job_model = Job.objects.get(job_class_name='DeviceUpgradeJob', module_name='naas.jobs')
        
        # Get search parameters
        search_term = request.GET.get('q', '')
        status_filter = request.GET.get('status', '')
        
        # Build base queryset
        query = JobResult.objects.filter(job_model=job_model)
        
        # Apply filters
        if search_term:
            # We'll filter post-fetch
            pass
        
        if status_filter:
            query = query.filter(status=status_filter)
        
        # Order by date_created
        job_results = query.order_by('-date_created')[:50]  # Get more to allow for filtering
        
        jobs = []
        for result in job_results:
            # Extract job parameters
            device_ip = None
            
            # Try to get device_ip from task_kwargs
            if hasattr(result, 'task_kwargs') and result.task_kwargs:
                try:
                    task_kwargs = result.task_kwargs
                    if isinstance(task_kwargs, str):
                        import json
                        task_kwargs = json.loads(task_kwargs)
                    
                    device_ip = task_kwargs.get('device_ip')
                except Exception as e:
                    logger.warning(f"Error extracting task_kwargs: {str(e)}")
            
            # Apply search filter if needed
            if search_term and (not device_ip or search_term.lower() not in device_ip.lower()):
                if not str(result.pk).lower().startswith(search_term.lower()):
                    continue  # Skip this result if it doesn't match the search term
            
            # Build timeline from job logs
            timeline = []
            from nautobot.extras.models import JobLogEntry
            
            # Use 'created' field instead of 'date_created' for ordering
            logs = JobLogEntry.objects.filter(job_result=result).order_by('created')
            
            for log in logs:
                try:
                    if log.log_level in ('info', 'success', 'warning', 'error'):
                        # Use 'created' field for the time value
                        timeline.append({
                            'title': log.log_level.capitalize(),
                            'time': log.created.strftime('%H:%M:%S'),
                            'description': log.message[:100] if log.message else "No message"
                        })
                except Exception as e:
                    logger.warning(f"Error processing log entry: {str(e)}")
            
            # Determine if this is a scheduled job
            scheduled_time = None
            if hasattr(result, 'scheduled_job') and result.scheduled_job:
                try:
                    scheduled_time = result.scheduled_job.scheduled_time.strftime('%Y-%m-%d %H:%M')
                except Exception as e:
                    logger.warning(f"Error extracting scheduled time: {str(e)}")
            
            # Create job entry
            job_data = {
                'id': str(result.pk),
                'device_ip': device_ip or 'Unknown',
                'device_type': 'SWITCH',  # Default type
                'status': result.status,
                'timeline': timeline
            }
            
            # Add dates if available
            if hasattr(result, 'started') and result.started:
                job_data['started_at'] = result.started.strftime('%Y-%m-%d %H:%M')
            
            if hasattr(result, 'date_done') and result.date_done:
                job_data['completed_at'] = result.date_done.strftime('%Y-%m-%d %H:%M')
            
            if scheduled_time:
                job_data['scheduled_time'] = scheduled_time
            
            jobs.append(job_data)
        
        # Limit to 20 jobs after filtering
        jobs = jobs[:20]
        
        return JsonResponse({
            'success': True,
            'jobs': jobs
        })
    
    except Exception as e:
        logger.error(f"Error retrieving job history: {str(e)}")
        import traceback
        logger.error(traceback.format_exc())
        return JsonResponse({
            'success': False,
            'error': str(e)
        })

@login_required
@csrf_protect
def precheck_validate(request):
    """
    Perform pre-validation checks for a Cisco device before upgrade
    This function connects to the device and runs checks for:
    - Flash memory availability
    - CPU utilization
    - Recent error logs
    - Overall device health
    """
    if request.method != 'POST':
        return JsonResponse({'success': False, 'error': 'Only POST method is allowed'})
    
    # Get device IP from request
    device_ip = request.POST.get('device_ip')
    if not device_ip:
        return JsonResponse({
            'success': False, 
            'error': 'Missing required parameter: device_ip'
        })
    
    # Clean up device IP if it contains subnet mask
    device_ip = device_ip.split('/')[0] if '/' in device_ip else device_ip
    
    # Get credential profile from request or use default
    credential_profile = request.POST.get('credential_profile', 'default')
    
    # Get credentials from database or environment based on the profile
    credentials = get_device_credentials(device_ip, credential_profile)
    
    try:
        # Prepare the variables for Ansible
        extra_vars = {
            'switch_ip': device_ip,
            'ansible_user': credentials.get('username'),
            'ansible_password': credentials.get('password'),
            'min_flash_free_percent': 30,  # Configurable minimum flash percentage
            'required_free_space_mb': 100,  # Configurable minimum flash space in MB
        }
        
        # Convert to JSON string
        extra_vars_json = json.dumps(extra_vars)
        
        # Get Ansible VM connection details from environment or settings
        ansible_connection = get_ansible_connection_details()
        
        # Force password authentication since that's what you're using
        ansible_connection['use_key'] = False
        
        # Ensure we have the password
        if not ansible_connection['password']:
            ansible_connection['password'] = os.environ.get('ANSIBLE_VM_PASSWORD', '')
        
        # Use sshpass for non-interactive password authentication
        # ssh_cmd = [
        #     'sshpass', '-p', ansible_connection['password'],
        #     'ssh',
        #     '-o', 'StrictHostKeyChecking=no',
        #     f"{ansible_connection['username']}@{ansible_connection['hostname']}",
        #     f"cd {ansible_connection['ansible_path']} && source /home/ubuntu/node_down/node_down_venv/bin/activate && ansible-playbook -i '{device_ip},' cisco_precheck.yml -e '{extra_vars_json}'"
        # ]
        ssh_cmd = [
            'sshpass', '-p', ansible_connection['password'],
            'ssh',
            '-o', 'StrictHostKeyChecking=no',
            f"{ansible_connection['username']}@{ansible_connection['hostname']}",
            (
                f"source /home/ubuntu/node_down/node_down_venv/bin/activate"
                f"cd {ansible_connection['ansible_path']}"
                f"ansible-playbook -i '{device_ip},' cisco_precheck.yml -e '{extra_vars_json}'"
            )
        ]

        
        # Execute the command with appropriate authentication
        import subprocess
        import os
        import re
        import json
        
        # Set environment for subprocess
        ssh_env = os.environ.copy()
        
        # Execute the command
        process = subprocess.Popen(
            ssh_cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            universal_newlines=True,
            env=ssh_env
        )
        
        stdout, stderr = process.communicate()
        
        # Log the raw output for debugging
        logger.debug(f"Ansible stdout: {stdout}")
        logger.debug(f"Ansible stderr: {stderr}")
        
        if process.returncode != 0:
            logger.error(f"Ansible execution failed: {stderr}")
            return JsonResponse({
                'success': False,
                'error': f'Ansible execution failed: {stderr}'
            })
        
        # Parse the Ansible output to extract pre-check results
        results = parse_precheck_results(stdout)
        
        # Add raw output for debugging purposes
        results['raw_output'] = stdout
        
        # Prepare a list of issues and recommendations based on results
        issues = []
        recommendations = []
        
        # Check flash status
        if results.get('flash_status') != 'PASS':
            issues.append(f"Insufficient flash space: {results.get('flash_free_percent', 0)}% free, {results.get('flash_free_mb', 0)} MB available.")
            recommendations.append("Delete unnecessary files from flash memory or consider using a smaller IOS image.")
        
        # Check CPU status
        if results.get('cpu_status') != 'PASS':
            issues.append(f"High CPU utilization: {results.get('cpu_five_min', 0)}% (5-minute average).")
            recommendations.append("Consider scheduling the upgrade during a period of lower activity.")
        
        # Check for error logs
        if results.get('error_status') != 'PASS':
            issues.append("Recent error logs detected.")
            recommendations.append("Review the error logs before proceeding with the upgrade.")
        
        # Add issues and recommendations to results
        results['issues'] = issues
        results['recommendations'] = recommendations
        
        return JsonResponse({
            'success': True,
            'results': results
        })
            
    except Exception as e:
        logger.error(f"Error in precheck_validate: {str(e)}")
        import traceback
        logger.error(traceback.format_exc())
        return JsonResponse({
            'success': False,
            'error': f'An error occurred: {str(e)}'
        })

def parse_precheck_results(ansible_output):
    """
    Parse the Ansible playbook output to extract pre-check results.
    
    Args:
        ansible_output: The raw output from the ansible-playbook command.
        
    Returns:
        dict: Structured pre-check results
    """
    # Initialize default results
    results = {
        'ios_version': 'Unknown',
        'flash_total_mb': 0,
        'flash_used_mb': 0,
        'flash_free_mb': 0,
        'flash_used_percent': 0,
        'flash_free_percent': 0,
        'flash_status': 'FAIL',
        'cpu_five_min': 0,
        'cpu_status': 'FAIL',
        'error_status': 'WARN',
        'overall_status': 'NOT READY'
    }
    
    try:
        # Look for consolidated results in the Ansible output
        # Format: hostname,IOS Version,Flash Used %,Flash Free (MB),Flash Status,CPU 5min %,CPU Status,Error Status
        csv_pattern = r'(\S+),([^,]+),(\d+\.\d+),(\d+\.\d+),(\w+),(\d+),(\w+),(\w+)'
        csv_match = re.search(csv_pattern, ansible_output)
        
        if csv_match:
            # Extract values from the match
            hostname = csv_match.group(1)
            results['ios_version'] = csv_match.group(2)
            results['flash_used_percent'] = float(csv_match.group(3))
            results['flash_free_mb'] = float(csv_match.group(4))
            results['flash_status'] = csv_match.group(5)
            results['cpu_five_min'] = int(csv_match.group(6))
            results['cpu_status'] = csv_match.group(7)
            results['error_status'] = csv_match.group(8)
            
            # Calculate flash total and used based on percentages
            if results['flash_used_percent'] > 0:
                results['flash_free_percent'] = 100 - results['flash_used_percent']
                results['flash_total_mb'] = round(results['flash_free_mb'] * 100 / results['flash_free_percent'], 2)
                results['flash_used_mb'] = round(results['flash_total_mb'] - results['flash_free_mb'], 2)
            
            # Determine overall status
            if results['flash_status'] == 'PASS' and results['cpu_status'] == 'PASS' and results['error_status'] == 'PASS':
                results['overall_status'] = 'READY'
            elif results['flash_status'] == 'PASS' and results['cpu_status'] == 'PASS' and results['error_status'] == 'WARN':
                results['overall_status'] = 'READY WITH WARNINGS'
            else:
                results['overall_status'] = 'NOT READY'
        else:
            # Try to extract summary info directly from Ansible output
            # Look for summary section
            summary_pattern = r'UPGRADE READINESS:\s*--+\s*Overall Status:\s*(\w+(?:\s+\w+)*)'
            summary_match = re.search(summary_pattern, ansible_output)
            
            if summary_match:
                results['overall_status'] = summary_match.group(1).strip()
            
            # Look for flash info
            flash_pattern = r'Flash Total:\s*([\d.]+)\s*MB\s*Flash Used:\s*([\d.]+)\s*MB\s*\(([\d.]+)%\)\s*Flash Free:\s*([\d.]+)\s*MB\s*\(([\d.]+)%\)\s*Flash Status:\s*(\w+)'
            flash_match = re.search(flash_pattern, ansible_output)
            
            if flash_match:
                results['flash_total_mb'] = float(flash_match.group(1))
                results['flash_used_mb'] = float(flash_match.group(2))
                results['flash_used_percent'] = float(flash_match.group(3))
                results['flash_free_mb'] = float(flash_match.group(4))
                results['flash_free_percent'] = float(flash_match.group(5))
                results['flash_status'] = flash_match.group(6)
            
            # Look for CPU info
            cpu_pattern = r'CPU \(5min avg\):\s*(\d+)%\s*CPU Status:\s*(\w+)'
            cpu_match = re.search(cpu_pattern, ansible_output)
            
            if cpu_match:
                results['cpu_five_min'] = int(cpu_match.group(1))
                results['cpu_status'] = cpu_match.group(2)
            
            # Look for error status
            error_pattern = r'Error Log Status:\s*(\w+)'
            error_match = re.search(error_pattern, ansible_output)
            
            if error_match:
                results['error_status'] = error_match.group(1)
            
            # Look for IOS version
            version_pattern = r'IOS Version:\s*([^\n]+)'
            version_match = re.search(version_pattern, ansible_output)
            
            if version_match:
                results['ios_version'] = version_match.group(1).strip()
                
    except Exception as e:
        # Log the error but continue with default values
        logger.error(f"Error parsing precheck results: {str(e)}")
        import traceback
        logger.error(traceback.format_exc())
    
    return results

import time
import random

def mock_precheck_response(device_ips, scenario='success'):
    """
    Generate mock Ansible precheck response for testing with realistic delay
    scenario options: 'success', 'low_flash', 'high_cpu', 'connection_failed', 'mixed'
    """
    # Simulate Ansible execution time
    # Base delay + additional time per device
    base_delay = 10
    per_device_delay = 2
    total_delay = base_delay + (len(device_ips) * per_device_delay)
    
    logger.info(f"Mock mode: Simulating Ansible execution for {total_delay} seconds...")
    time.sleep(total_delay)
    
    device_results = {}
    
    for idx, device_ip in enumerate(device_ips):
        clean_ip = device_ip.split('/')[0] if '/' in device_ip else device_ip
        
        # Different scenarios
        if scenario == 'success':
            ios_version, flash_free_pct, cpu = "17.9.4a", 45, 15
        elif scenario == 'low_flash':
            ios_version, flash_free_pct, cpu = "17.6.5", 15, 20
        elif scenario == 'high_cpu':
            ios_version, flash_free_pct, cpu = "16.12.8", 50, 85
        elif scenario == 'mixed':
            # Alternate between success and failures
            if idx % 2 == 0:
                ios_version, flash_free_pct, cpu = "17.9.4a", 45, 15
            else:
                ios_version, flash_free_pct, cpu = "17.6.5", 15, 20
        else:
            ios_version, flash_free_pct, cpu = "Unknown", 0, 0
        
        flash_total = random.randint(2000, 8000)
        flash_free = int(flash_total * flash_free_pct / 100)
        flash_used = flash_total - flash_free
        flash_used_percent = int((flash_used / flash_total) * 100)
        
        device_results[clean_ip] = {
            'device_ip': clean_ip,
            'ios_version': ios_version,
            'flash_total_mb': flash_total,
            'flash_used_mb': flash_used,
            'flash_free_mb': flash_free,
            'flash_used_percent': flash_used_percent,
            'flash_free_percent': flash_free_pct,
            'flash_status': 'PASS' if flash_free_pct >= 30 else 'FAIL',
            'cpu_5min': cpu,
            'cpu_status': 'PASS' if cpu < 80 else 'FAIL',
            'error_status': 'PASS',
            'overall_status': 'READY' if flash_free_pct >= 30 and cpu < 80 else 'NOT READY',
            'issues': [],
            'raw_output': generate_mock_ansible_output(clean_ip, ios_version, flash_total, flash_used, cpu)
        }
        
        # Add issues if not ready
        if device_results[clean_ip]['overall_status'] == 'NOT READY':
            if device_results[clean_ip]['flash_status'] == 'FAIL':
                device_results[clean_ip]['issues'].append(
                    f'Flash storage below threshold (Current: {flash_free_pct}%, Required: 30%)'
                )
            if device_results[clean_ip]['cpu_status'] == 'FAIL':
                device_results[clean_ip]['issues'].append(
                    f'High CPU utilization (Current: {cpu}%, Threshold: 80%)'
                )
    
    logger.info(f"Mock mode: Completed simulation for {len(device_ips)} devices")
    
    return JsonResponse({
        'success': True,
        'results': device_results,
        'raw_ansible_output': generate_mock_ansible_output(
            device_ips[0] if device_ips else '172.17.222.216', 
            "17.9.4a", 4096, 1500, 15
        ),
        'mock_mode': True,
        'scenario': scenario,
        'execution_time': f"{total_delay}s"
    })

def generate_mock_ansible_output(device_ip, ios_version, flash_total, flash_used, cpu):
    """
    Generate realistic Ansible output format
    """
    clean_ip = device_ip.split('/')[0] if '/' in device_ip else device_ip
    flash_free = flash_total - flash_used
    flash_used_percent = int((flash_used / flash_total) * 100)
    flash_free_percent = 100 - flash_used_percent
    flash_status = "PASS" if flash_free_percent >= 30 else "FAIL"
    
    output = f"""ansible-playbook [core 2.18.6]
  config file = None
  configured module search path = ['/home/ubuntu/.ansible/plugins/modules', '/usr/share/ansible/plugins/modules']
  ansible python module location = /home/ubuntu/ND/node_down_venv/lib/python3.12/site-packages/ansible
  ansible collection location = /home/ubuntu/.ansible/collections:/usr/share/ansible/collections
  executable location = /home/ubuntu/ND/node_down_venv/bin/ansible-playbook
  python version = 3.12.3 (main, Aug 14 2025, 17:47:21) [GCC 13.3.0] (/home/ubuntu/ND/node_down_venv/bin/python3)
  jinja version = 3.1.6
  libyaml = True

PLAYBOOK: cisco_precheck.yml ***************************************************
1 plays in cisco_precheck.yml

PLAY [Cisco IOS Upgrade Pre-Check] *********************************************

TASK [Display inventory information] *******************************************
ok: [{clean_ip}] => {{
    "msg": "Checking device {clean_ip} with connection network_cli"
}}

TASK [Check connection to device] **********************************************
ok: [{clean_ip}]

TASK [Show connection results] *************************************************
ok: [{clean_ip}] => {{
    "msg": "Connection test result: Success"
}}

TASK [Check hardware and software version] *************************************
ok: [{clean_ip}]

TASK [Check flash storage] *****************************************************
ok: [{clean_ip}]

TASK [Check CPU utilization] ***************************************************
ok: [{clean_ip}]

TASK [Check error logs] ********************************************************
ok: [{clean_ip}]

TASK [Generate device pre-check summary] ***************************************
ok: [{clean_ip}] => {{
    "msg": "==================================================\\nCISCO IOS UPGRADE PRE-CHECK SUMMARY\\n==================================================\\nDevice: {clean_ip}\\n\\nDEVICE INFORMATION:\\n--------------------------------------------------\\nIOS Version: {ios_version}\\n\\n\\nSTORAGE STATUS:\\n--------------------------------------------------\\nFlash Total: {flash_total} MB\\nFlash Used: {flash_used} MB ({flash_used_percent}%)\\nFlash Free: {flash_free} MB ({flash_free_percent}%)\\nFlash Status: {flash_status}\\n\\nSYSTEM HEALTH:\\n--------------------------------------------------\\nCPU (5min avg): {cpu}%\\nCPU Status: PASS\\nError Log Status: PASS\\n\\nUPGRADE READINESS:\\n--------------------------------------------------\\nOverall Status: {'READY' if flash_status == 'PASS' else 'NOT READY'}\\n==================================================\\n"
}}

TASK [Output results in CSV format for easy parsing] ***************************
ok: [{clean_ip}] => {{
    "msg": "{clean_ip},{ios_version},{flash_total},{flash_free},{flash_status},{cpu},PASS,PASS"
}}

PLAY RECAP *********************************************************************
{clean_ip}             : ok=9    changed=0    unreachable=0    failed=0    skipped=0    rescued=0    ignored=0   
"""
    return output


@login_required
@csrf_protect
def precheck_validate_multiple(request):
    """
    Validate multiple Cisco devices before upgrade
    """
    if request.method != 'POST':
        return JsonResponse({'success': False, 'error': 'Only POST method is allowed'})
    
    # Get device IPs from request
    import json
    device_ips_json = request.POST.get('device_ips', '[]')
    try:
        device_ips = json.loads(device_ips_json)
    except json.JSONDecodeError:
        return JsonResponse({
            'success': False, 
            'error': 'Invalid device IPs format'
        })
    
    if not device_ips:
        return JsonResponse({
            'success': False, 
            'error': 'No devices specified'
        })
    
    # TEMPORARY: Enable mock mode for testing
    MOCK_MODE = True  # Set to False when authentication is fixed
    
    if MOCK_MODE:
        return mock_precheck_response(device_ips)
    
    # Get credential profile
    credential_profile = request.POST.get('credential_profile', 'default')
    
    try:
        # Create a temporary inventory file with all devices
        import tempfile
        import os
        
        # with tempfile.NamedTemporaryFile(mode='w+', delete=False, suffix='.ini') as temp_ini:
        #     # Write the device group
        #     temp_ini.write("[switches]\n")
        #     for device_ip in device_ips:
        #         # Clean IP if it has subnet mask
        #         clean_ip = device_ip.split('/')[0] if '/' in device_ip else device_ip
        #         temp_ini.write(f"{clean_ip}\n")
            
        #     # Write group variables - FIXED: Use correct connection parameters
        #     temp_ini.write("\n[switches:vars]\n")
        #     temp_ini.write("\n ansible_ssh_common_args='-o PreferredAuthentications=password' \n")
        #     temp_ini.write("ansible_connection=network_cli\n")  # Fixed: was ansible.netcommon.network_cli
        #     temp_ini.write("ansible_become=yes\n")
        #     temp_ini.write("ansible_become_method=enable\n")
        #     temp_ini.write("ansible_network_os=ios\n")  # Fixed: was cisco.ios.ios
            
        #     # Get credentials (use the same for all devices for simplicity)
        #     credentials = get_device_credentials(device_ips[0], credential_profile)
        #     temp_ini.write(f"ansible_user={credentials.get('username')}\n")
        #     temp_ini.write(f"ansible_password={credentials.get('password')}\n")
        #     temp_ini.write("ansible_python_interpreter=/usr/bin/python3\n")
        #     temp_ini.write("ansible_host_key_checking=false\n")  # Added for better connectivity
        #     temp_ini.write("ansible_command_timeout=30\n")  # Added timeout
        #     temp_ini.write("ansible_connect_timeout=30\n")  # Added connect timeout
            
        #     temp_ini_path = temp_ini.name
        
        with tempfile.NamedTemporaryFile(mode='w+', delete=False, suffix='.ini') as temp_ini:
            # Write the device group
            temp_ini.write("[switches]\n")
            for device_ip in device_ips:
                # Clean IP if it has subnet mask
                clean_ip = device_ip.split('/')[0] if '/' in device_ip else device_ip
                temp_ini.write(f"{clean_ip}\n")
            
            # Write group variables - FIXED: Proper formatting and parameters
            temp_ini.write("\n[switches:vars]\n")
            temp_ini.write("ansible_connection=network_cli\n")
            temp_ini.write("ansible_network_os=ios\n")
            temp_ini.write("ansible_become=yes\n")
            temp_ini.write("ansible_become_method=enable\n")
            
            # Get credentials
            credentials = get_device_credentials(device_ips[0], credential_profile)
            temp_ini.write(f"ansible_user={credentials.get('username')}\n")
            temp_ini.write(f"ansible_password={credentials.get('password')}\n")
            
            # CRITICAL: Force password authentication, disable publickey
            temp_ini.write("ansible_ssh_common_args='-o PreferredAuthentications=password -o PubkeyAuthentication=no'\n")
            
            # Additional settings
            temp_ini.write("ansible_python_interpreter=/usr/bin/python3\n")
            temp_ini.write("ansible_host_key_checking=False\n")  # Capital F
            temp_ini.write("ansible_command_timeout=30\n")
            temp_ini.write("ansible_connect_timeout=30\n")
            
            temp_ini_path = temp_ini.name
        # Get Ansible connection details
        ansible_connection = get_ansible_connection_details()
        
        # Prepare extra variables for the playbook
        extra_vars = {
            'min_flash_free_percent': 30,  # Minimum flash percentage
            'required_free_space_mb': 100,  # Minimum flash space in MB
            'results_directory': './results'
        }
        
        extra_vars_json = json.dumps(extra_vars)
        
        # Copy the inventory file to the Ansible server
        remote_ini_path = f"{ansible_connection['ansible_path']}/{os.path.basename(temp_ini_path)}"
        
        scp_cmd = [
            'sshpass', '-p', ansible_connection['password'],
            'scp',
            '-o', 'StrictHostKeyChecking=no',
            temp_ini_path,
            f"{ansible_connection['username']}@{ansible_connection['hostname']}:{remote_ini_path}"
        ]
        
        # Execute the SCP command
        import subprocess
        scp_process = subprocess.Popen(
            scp_cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            universal_newlines=True
        )
        
        scp_stdout, scp_stderr = scp_process.communicate()
        
        if scp_process.returncode != 0:
            os.unlink(temp_ini_path)  # Clean up the temp file
            logger.error(f"SCP failed: {scp_stderr}")
            return JsonResponse({
                'success': False,
                'error': f'Failed to copy inventory file to Ansible server: {scp_stderr}'
            })
        
        # UPDATED: Run the Ansible playbook with virtual environment activation
        # Define virtual environment path - adjust this path as needed
        venv_path = "/home/ubuntu/node_down/node_down_venv"  # or full path like "/home/ubuntu/.ios_upgrade"
        
        # Create command with virtual environment activation
        # ansible_cmd = (
        #     f"source {venv_path}/bin/activate && "
        #     f"cd {ansible_connection['ansible_path']} && "
        #     f"ansible-playbook -i {os.path.basename(temp_ini_path)} cisco_precheck.yml -vvv -e '{extra_vars_json}'"
        # )

        ansible_cmd = (
            f"export ANSIBLE_HOST_KEY_CHECKING=False && "
            f"export ANSIBLE_SSH_ARGS='-o PreferredAuthentications=password -o PubkeyAuthentication=no' && "
            f"unset SSH_AUTH_SOCK && "  # Disable SSH agent
            f"source {venv_path}/bin/activate && "
            f"cd {ansible_connection['ansible_path']} && "
            f"ansible-playbook -i {os.path.basename(temp_ini_path)} cisco_precheck.yml -vvv -e '{extra_vars_json}'"
        )
        
        ssh_cmd = [
            'sshpass', '-p', ansible_connection['password'],
            'ssh',
            '-o', 'StrictHostKeyChecking=no',
            f"{ansible_connection['username']}@{ansible_connection['hostname']}",
            ansible_cmd
        ]

        logger.info(f"Executing SSH command: {' '.join(ssh_cmd)}")
        
        # Execute the command
        process = subprocess.Popen(
            ssh_cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            universal_newlines=True
        )
        
        stdout, stderr = process.communicate()

        # Log both stdout and stderr for better debugging
        logger.info(f"ansible_output: {stdout}")
        if stderr:
            logger.error(f"Ansible stderr: {stderr}")
        
        # Clean up the temp file
        # os.unlink(temp_ini_path)
        
        # Clean up remote inventory file (optional but good practice)
        cleanup_cmd = [
            'sshpass', '-p', ansible_connection['password'],
            'ssh',
            '-o', 'StrictHostKeyChecking=no',
            f"{ansible_connection['username']}@{ansible_connection['hostname']}",
            f"rm -f {remote_ini_path}"
        ]
        
        try:
            subprocess.run(cleanup_cmd, timeout=10, capture_output=True)
        except subprocess.TimeoutExpired:
            logger.warning("Cleanup command timed out")
        except Exception as cleanup_error:
            logger.warning(f"Cleanup failed: {cleanup_error}")
        
        # Check for Ansible execution errors
        if process.returncode != 0:
            logger.error(f"Ansible execution failed: {stderr}")
            return JsonResponse({
                'success': False,
                'error': f'Ansible execution failed: {stderr}'
            })
        
        if "PLAY RECAP" not in stdout:
            logger.error("Expected Ansible output format not found")
            logger.error(f"Actual output: {stdout[:1000]}")  # Log a truncated version of the output
            return JsonResponse({
                'success': False,
                'error': 'Ansible playbook did not produce expected output format. Check if the playbook is correctly configured.'
            })
        
        # Parse the results for each device
        device_results = {}
        
        for device_ip in device_ips:
            # Clean IP for consistency
            clean_ip = device_ip.split('/')[0] if '/' in device_ip else device_ip
            
            # Parse results for this device from the Ansible output
            device_result = parse_precheck_results_for_device(stdout, clean_ip)
            
            # Add the raw output to each device result
            device_result['raw_output'] = stdout
            
            device_results[clean_ip] = device_result
            
            # Print debug info
            logger.info(f"Device: {clean_ip}, Result: {device_result}")
        
        return JsonResponse({
            'success': True,
            'results': device_results,
            'raw_ansible_output': stdout  # Include the full raw output at the top level as well
        })
        
    except Exception as e:
        logger.error(f"Error in precheck_validate_multiple: {str(e)}")
        import traceback
        logger.error(traceback.format_exc())
        return JsonResponse({
            'success': False,
            'error': f'An error occurred: {str(e)}'
        })

def parse_precheck_results_for_device(ansible_output, device_ip):
    """
    Parse the Ansible output to extract results for a specific device
    """
    import re
    import logging
    
    logger = logging.getLogger(__name__)
    
    # Default results
    results = {
        'ios_version': 'Unknown',
        'flash_total_mb': 0,
        'flash_used_mb': 0,
        'flash_free_mb': 0,
        'flash_used_percent': 0,
        'flash_free_percent': 0,
        'flash_status': 'UNKNOWN',
        'cpu_five_min': 0,
        'cpu_status': 'UNKNOWN',
        'error_status': 'UNKNOWN',
        'overall_status': 'NOT READY',
        'issues': [],
        'recommendations': []
    }
    
    try:
        # First, try to extract IOS version from ansible_facts if available
        logger.info('ansible_output', ansible_output)
        ios_facts_match = re.search(r'ansible_net_version":\s*"([^"]+)"', ansible_output)
        if ios_facts_match:
            results['ios_version'] = ios_facts_match.group(1)
            
        # Look for CSV results for this device
        csv_pattern = rf'{re.escape(device_ip)},([^,\n]+),([^,\n]+),([^,\n]+),([^,\n]+),([^,\n]+),([^,\n]+),([^,\n]+)'
        csv_match = re.search(csv_pattern, ansible_output)
        
        if csv_match:
            # Process IOS version from CSV if not already set
            if results['ios_version'] == 'Unknown':
                results['ios_version'] = csv_match.group(1).strip()
            
            # Process flash metrics
            try:
                results['flash_used_percent'] = float(csv_match.group(2).strip())
            except (ValueError, TypeError):
                pass
                
            try:
                results['flash_free_mb'] = float(csv_match.group(3).strip())
            except (ValueError, TypeError):
                pass
                
            results['flash_status'] = csv_match.group(4).strip()
            
            # Process CPU metrics
            try:
                cpu_value = csv_match.group(5).strip()
                results['cpu_five_min'] = int(cpu_value) if cpu_value.isdigit() else 0
            except (ValueError, TypeError, AttributeError):
                pass
                
            results['cpu_status'] = csv_match.group(6).strip()
            
            # Clean error status - remove any trailing content
            error_status = csv_match.group(7).strip()
            if error_status:
                # Get just PASS, FAIL, WARN, or UNKNOWN
                status_match = re.search(r'^(PASS|FAIL|WARN|UNKNOWN)', error_status)
                if status_match:
                    results['error_status'] = status_match.group(1)
            
            # Calculate flash metrics if we have percentage
            if results['flash_used_percent'] > 0 and results['flash_free_mb'] > 0:
                results['flash_free_percent'] = 100 - results['flash_used_percent']
                results['flash_total_mb'] = round(results['flash_free_mb'] * 100 / results['flash_free_percent'], 2)
                results['flash_used_mb'] = round(results['flash_total_mb'] - results['flash_free_mb'], 2)
        
        # Look for summary section for this device
        summary_pattern = rf'CISCO IOS UPGRADE PRE-CHECK SUMMARY\s*=+\s*Device: {re.escape(device_ip)}(.*?)=+'
        summary_match = re.search(summary_pattern, ansible_output, re.DOTALL)
        if summary_match:
            summary_section = summary_match.group(1)
            
            # Extract IOS version if not already set
            if results['ios_version'] == 'Unknown':
                ios_version_match = re.search(r'IOS Version:\s*([^\n]+)', summary_section)
                if ios_version_match:
                    results['ios_version'] = ios_version_match.group(1).strip()
            
            # Extract flash information
            flash_info_match = re.search(r'Flash Total:\s*([\d.]+)\s*MB\s*Flash Used:\s*([\d.]+)\s*MB\s*\(([\d.]+)%\)\s*Flash Free:\s*([\d.]+)\s*MB\s*\(([\d.]+)%\)\s*Flash Status:\s*(\w+)', summary_section)
            if flash_info_match:
                results['flash_total_mb'] = float(flash_info_match.group(1))
                results['flash_used_mb'] = float(flash_info_match.group(2))
                results['flash_used_percent'] = float(flash_info_match.group(3))
                results['flash_free_mb'] = float(flash_info_match.group(4))
                results['flash_free_percent'] = float(flash_info_match.group(5))
                results['flash_status'] = flash_info_match.group(6)
            
            # Extract CPU information
            cpu_match = re.search(r'CPU \(5min avg\):\s*(\d+)%\s*CPU Status:\s*(\w+)', summary_section)
            if cpu_match:
                results['cpu_five_min'] = int(cpu_match.group(1))
                results['cpu_status'] = cpu_match.group(2)
            
            # Extract error status
            error_match = re.search(r'Error Log Status:\s*(\w+)', summary_section)
            if error_match:
                results['error_status'] = error_match.group(1)
            
            # Extract overall status
            overall_match = re.search(r'Overall Status:\s*([^\n]+)', summary_section)
            if overall_match:
                results['overall_status'] = overall_match.group(1).strip()
        
        # If we have data from debugging print statement
        debug_pattern = rf'Device: {re.escape(device_ip)}, IOS: ([^,]+), Flash: ([^,]+), CPU: ([^,]+), Error: ([^,]+), Overall: ([^\n]+)'
        debug_match = re.search(debug_pattern, ansible_output)
        if debug_match:
            if results['ios_version'] == 'Unknown':
                results['ios_version'] = debug_match.group(1).strip()
            if results['flash_status'] == 'UNKNOWN':
                results['flash_status'] = debug_match.group(2).strip()
            if results['cpu_status'] == 'UNKNOWN':
                results['cpu_status'] = debug_match.group(3).strip()
            if results['error_status'] == 'UNKNOWN':
                results['error_status'] = debug_match.group(4).strip()
            results['overall_status'] = debug_match.group(5).strip()
        
        # If we have valid flash and (valid or unknown CPU) and valid error status, set as READY
        if results['flash_status'] == 'PASS' and (results['cpu_status'] == 'PASS' or results['cpu_five_min'] == 0) and results['error_status'] == 'PASS':
            results['overall_status'] = 'READY'
        elif results['flash_status'] == 'PASS' and (results['cpu_status'] == 'PASS' or results['cpu_five_min'] == 0) and results['error_status'] == 'WARN':
            results['overall_status'] = 'READY WITH WARNINGS'
        
        # Add issues and recommendations based on status
        results['issues'] = []
        results['recommendations'] = []
        
        if results['flash_status'] != 'PASS' and results['flash_status'] != 'UNKNOWN':
            results['issues'].append(f"Insufficient flash space: {results['flash_free_percent']}% free, {results['flash_free_mb']} MB available.")
            results['recommendations'].append("Delete unnecessary files from flash memory or consider using a smaller IOS image.")
        
        if results['cpu_status'] != 'PASS' and results['cpu_status'] != 'UNKNOWN' and results['cpu_five_min'] > 0:
            results['issues'].append(f"High CPU utilization: {results['cpu_five_min']}% (5-minute average).")
            results['recommendations'].append("Consider scheduling the upgrade during a period of lower activity.")
        
        if results['error_status'] != 'PASS' and results['error_status'] != 'UNKNOWN':
            results['issues'].append("Recent error logs detected.")
            results['recommendations'].append("Review the error logs before proceeding with the upgrade.")
        
        # If device is ready but has no values filled in, add a general recommendation
        if results['overall_status'] == 'READY' and not results['issues']:
            results['recommendations'].append("Device appears ready for upgrade. Ensure you have a backup configuration before proceeding.")
        
        logger.info(f"Parsing results for {device_ip}: Flash: {results['flash_status']}, CPU: {results['cpu_status']}, Error: {results['error_status']}, Overall: {results['overall_status']}")
        
    except Exception as e:
        import traceback
        logger.error(f"Error parsing results for device {device_ip}: {str(e)}")
        logger.error(traceback.format_exc())
        
        # Add error as an issue
        results['issues'] = [f"Error parsing validation results: {str(e)}"]
        results['recommendations'] = ["Try running the validation again or check device connectivity."]
    
    return results
@login_required
@csrf_protect
@require_POST
def request_upgrade_approval(request):
    """
    Create an upgrade approval request and send notification email.
    This is a new endpoint that doesn't interfere with the original start_upgrade.
    """
    try:
        # Parse job parameters from request
        job_params = json.loads(request.body)
        # Extract key parameters for easier access
        devices = job_params.get('devices', [])
        email_receiver = job_params.get('email_receiver')
        
        # Extract precheck results if available
        precheck_results = job_params.get('precheck_results', {})
        
        if not devices:
            return JsonResponse({
                'success': False,
                'error': 'No devices specified'
            })
            
        if not email_receiver:
            return JsonResponse({
                'success': False,
                'error': 'Approver email is required'
            })
        
        # Set expiration time (24 hours from now)
        expires_at = timezone.now() + timedelta(hours=72)
        
        # Prepare response data
        approval_ids = {}
        install_approval_ids = {}
        
        # Create approval requests for each device
        for device_ip in devices:
            # Clean up device IP if needed
            clean_device_ip = device_ip.split('/')[0] if '/' in device_ip else device_ip
            
            # Create a copy of job parameters for this device
            device_params = job_params.copy()
            device_params['device_ip'] = clean_device_ip
            
            # Get device-specific precheck results if available
            if clean_device_ip in precheck_results:
                device_params['precheck_result'] = precheck_results[clean_device_ip]
                
                # Create a summary of the precheck result for logging
                precheck_summary = {
                    'ios_version': precheck_results[clean_device_ip].get('ios_version', 'Unknown'),
                    'flash_status': precheck_results[clean_device_ip].get('flash_status', 'Unknown'),
                    'cpu_status': precheck_results[clean_device_ip].get('cpu_status', 'Unknown'),
                    'overall_status': precheck_results[clean_device_ip].get('overall_status', 'Unknown')
                }
                logger.info(f"Including precheck results for {clean_device_ip}: {precheck_summary}")
            
            # Remove the devices list as we're processing one device at a time
            if 'devices' in device_params:
                del device_params['devices']
            
            # Remove the full precheck_results collection as we've already extracted 
            # the specific device's result
            if 'precheck_results' in device_params:
                del device_params['precheck_results']
            
            # Check if this is an upload_install job
            is_upload_install = device_params.get('primary_action') == 'upload_install'
            
            if is_upload_install:
                # Create two approval requests - one for upload and one for install
                
                # Upload approval
                upload_params = device_params.copy()
                upload_params['primary_action'] = 'upload'
                
                upload_approval = UpgradeApproval.objects.create(
                    requester=request.user.username,
                    approver_email=email_receiver,
                    device_ip=clean_device_ip,
                    job_parameters=upload_params,
                    expires_at=expires_at
                )
                
                # Install approval (depends on upload approval)
                install_params = device_params.copy()
                install_params['primary_action'] = 'install'
                install_params['depends_on_approval'] = str(upload_approval.id)
                
                install_approval = UpgradeApproval.objects.create(
                    requester=request.user.username,
                    approver_email=email_receiver,
                    device_ip=clean_device_ip,
                    job_parameters=install_params,
                    expires_at=expires_at,
                    depends_on_approval=upload_approval.id
                )
                
                # Store approval IDs
                approval_ids[device_ip] = str(upload_approval.id)
                install_approval_ids[device_ip] = str(install_approval.id)
                
                # Send email for upload approval only initially
                send_approval_email(request, upload_approval)
                
            else:
                # Regular single approval
                approval = UpgradeApproval.objects.create(
                    requester=request.user.username,
                    approver_email=email_receiver,
                    device_ip=clean_device_ip,
                    job_parameters=device_params,
                    expires_at=expires_at
                )
                
                # Store approval ID
                approval_ids[device_ip] = str(approval.id)
                
                # Send approval email
                send_approval_email(request, approval)
        
        # Return success response
        response = {
            'success': True,
            'message': f'Approval requests created for {len(devices)} device(s)',
            'approval_ids': approval_ids
        }
        
        if install_approval_ids:
            response['install_approval_ids'] = install_approval_ids
        
        return JsonResponse(response)
                
    except Exception as e:
        import traceback
        logger.error(f"Error creating approval request: {str(e)}")
        logger.error(traceback.format_exc())
        return JsonResponse({
            'success': False,
            'error': f'Error creating approval request: {str(e)}'
        })

def send_approval_email(request, approval):
    """Helper function to send approval request email"""
    # Build the approval URL
    approval_url = request.build_absolute_uri(
        reverse('plugins:naas:approve-upgrade', args=[str(approval.approval_token)])
    )
    
    # Format primary action for display
    primary_action = approval.job_parameters.get('primary_action', '')
    action_name = {
        'upload': 'Upload Image Only',
        'install': 'Install Image Only',
        'upload_install': 'Upload and Install Image'
    }.get(primary_action, primary_action)
    
    # Prepare email context
    context = {
        'device_ip': approval.device_ip,
        'requester': approval.requester,
        'approval_url': approval_url,
        'expires_at': approval.expires_at,
        'job_params': approval.job_parameters,
        'action_name': action_name,
        'approval_id': str(approval.id)
    }
    
    # Render email template
    subject = f'Firmware Upgrade Approval Request for {approval.device_ip}'
    html_message = render_to_string('naas/approval_request.html', context)
    plain_message = f"""
Firmware upgrade approval requested for {approval.device_ip}
Requested by: {approval.requester}
Action: {action_name}
Approve at: {approval_url}
    """
    
    # Send email
    from_email = approval.job_parameters.get('email_sender', 'no-reply@example.com')
    recipient = approval.approver_email
    
    try:
        send_mail(
            subject=subject,
            message=plain_message,
            from_email=from_email,
            recipient_list=[recipient],
            html_message=html_message
        )
        logger.info(f"Approval email sent to {recipient} for device {approval.device_ip}")
        return True
    except Exception as e:
        logger.error(f"Error sending approval email: {str(e)}")
        return False

@login_required
def approve_upgrade(request, token):
    """Handle approval page and approval actions"""
    # Get the approval by token or return 404
    approval = get_object_or_404(UpgradeApproval, approval_token=token)
    
    # Extract target version from image filename
    if approval.job_parameters and approval.job_parameters.get('image_file'):
        image_file = approval.job_parameters['image_file']
        # Extract version using regex, for example:
        import re
        match = re.search(r'(\d+\.\d+\.\d+)\.SPA', image_file)
        if match:
            approval.job_parameters['target_version'] = match.group(1)

    # Check if already processed
    if approval.status != 'pending':
        message = f"This request has already been {approval.status}."
        return render(request, 'naas/approval_result.html', {
            'success': False,
            'message': message,
            'approval': approval
        })
    
    # Check if expired
    if approval.is_expired():
        approval.status = 'expired'
        approval.save()
        return render(request, 'naas/approval_result.html', {
            'success': False,
            'message': 'This approval request has expired.',
            'approval': approval
        })
    
    # Check if it depends on another approval
    if approval.depends_on_approval:
        try:
            parent_approval = UpgradeApproval.objects.get(id=approval.depends_on_approval)
            if parent_approval.status != 'approved' and parent_approval.status != 'executed':
                return render(request, 'naas/approval_result.html', {
                    'success': False,
                    'message': 'The prerequisite upload job must be approved first.',
                    'approval': approval,
                    'parent_approval': parent_approval
                })
        except UpgradeApproval.DoesNotExist:
            logger.error(f"Parent approval {approval.depends_on_approval} not found")
    
    # Handle POST request (approval action)
    if request.method == 'POST':
        action = request.POST.get('action', '')
        comments = request.POST.get('comments', '')
        
        if action == 'approve':
            # Mark as approved
            approval.status = 'approved'
            approval.approved_at = timezone.now()
            approval.approved_by = request.user.username
            approval.save()
            
            # Queue the job for execution
            job_success, job_id, message = queue_job_from_approval(approval, request.user)
            
            # Update approval status based on job creation result
            if job_success:
                approval.status = 'executed'
                approval.save()
                return render(request, 'naas/approval_result.html', {
                    'success': True,
                    'message': 'The upgrade job has been approved and queued successfully.',
                    'job_id': job_id,
                    'approval': approval
                })
            else:
                return render(request, 'naas/approval_result.html', {
                    'success': False,
                    'message': f'The upgrade was approved, but job creation failed: {message}',
                    'approval': approval
                })
        
        elif action == 'reject':
            # Mark as rejected
            approval.status = 'rejected'
            approval.rejected_at = timezone.now()
            approval.rejected_by = request.user.username
            approval.rejection_reason = comments
            approval.save()
            
            return render(request, 'naas/approval_result.html', {
                'success': False,
                'message': 'The upgrade request has been rejected.',
                'approval': approval
            })
    
    # Handle GET request (show approval page)
    return render(request, 'naas/approval_page.html', {
        'approval': approval
    })

def queue_job_from_approval(approval, user):
    """
    Create and queue a job from an approval request.
    Returns (success, job_id, message)
    """
    try:
        # Get the job model
        job_model = Job.objects.get(job_class_name='DeviceUpgradeJob', module_name='naas.jobs')
        
        job_params = approval.job_parameters.copy()

        # Get job parameters
        
        if 'vrf' in job_params and 'vrf_name' not in job_params:
            job_params['vrf_name'] = job_params['vrf']
            logger.info(f"Copied VRF parameter from 'vrf' to 'vrf_name': {job_params['vrf_name']}")
        
        # Remove unnecessary parameters
        job_params.pop('precheck_result', None)
        
        # Create the job
        job_result = JobResult.enqueue_job(
            job_model=job_model,
            user=user,
            **job_params
        )
        
        return True, str(job_result.id), "Job created successfully"
    
    except Exception as e:
        logger.error(f"Error creating job from approval: {str(e)}")
        import traceback
        logger.error(traceback.format_exc())
        return False, None, str(e)

@login_required
@require_GET
def get_approval_status(request, approval_id):
    """API endpoint to check approval status"""
    try:
        approval = get_object_or_404(UpgradeApproval, id=approval_id)
        
        # Update status if expired
        if approval.status == 'pending' and approval.is_expired():
            approval.status = 'expired'
            approval.save()
        
        # Map status to display class
        status_class = {
            'pending': 'pending',
            'approved': 'success',
            'rejected': 'failed',
            'expired': 'warning',
            'executed': 'success'
        }.get(approval.status, 'pending')
        
        return JsonResponse({
            'success': True,
            'status': approval.status,
            'status_class': status_class,
            'updated_at': approval.approved_at or approval.rejected_at or approval.created_at
        })
    
    except Exception as e:
        return JsonResponse({
            'success': False,
            'error': str(e)
        })

@login_required
def approval_dashboard(request):
    """Dashboard for managing approval requests"""
    # Get filter parameters
    status = request.GET.get('status', '')
    device = request.GET.get('device', '')
    
    # Start with all approvals
    approvals = UpgradeApproval.objects.all().order_by('-created_at')
    
    # Apply filters
    if status:
        approvals = approvals.filter(status=status)
    
    if device:
        approvals = approvals.filter(device_ip__icontains=device)
    
    # Render the dashboard
    return render(request, 'naas/approval_dashboard.html', {
        'approvals': approvals,
        'status': status,
        'device': device
    })


@login_required
@csrf_protect
def start_reboot(request):
    """
    Start the reboot process for selected devices.
    This function will run below command to reboot devices
    - write memory,
    - reload
    
    Each operation can be executed immediately or scheduled for later.
    """
    
    try:
        
        # Extract form data
        devices = json.loads(request.POST.get('devices', '[]'))
        tftp_server = request.POST.get('tftpServer')
        tftp_path = request.POST.get('tftpPath')
        auth_method = request.POST.get('authMethod')
        credential_profile = request.POST.get('credentialProfile')
        execution_type = request.POST.get('executionType')
        executionMode = request.POST.get('executionMode')
        # Get new parameters for device_type_vars.yml
        #md5_checksum = request.POST.get('md5Checksum', '')
        #upgrade_version = request.POST.get('upgradeVersion', 'Unknown')
        change_number = request.POST.get('changeNumber', '')
        vrf_name = request.POST.get('vrf', None)
        
        # Email notification params
        smtp_server = request.POST.get('smtp_server', 'smtp.gmail.com')
        email_sender = request.POST.get('emailSender', 'no-reply@hcltech.com')
        #email_receiver = request.POST.get('emailReceiver', 'vidhiprakashb.sampa@hcltech.com')
        #print('email_receiver',email_receiver)
        #if email_receiver=='':
        #    email_receiver = 'vidhiprakashb.sampa@hcltech.com'
        email_receiver = request.user.email
        #email_parts = email_receiver.split('@')
        #print('email_parts',email_parts)
        #email_part1 = email_parts[0]
        #email_part2 = email_parts[1]
        # Check if test mode is enabled
        test_mode = request.POST.get('testMode', 'true').lower() == 'true'
        
        logger.info(f"Reboot request - Devices: {devices}, Test Mode: {test_mode}")
        
        # Get the job model - this should always exist now because of our __init__.py code
        try:
            job_model = Job.objects.get(job_class_name='DeviceRebootJob', module_name='naas.jobs')
        except Job.DoesNotExist:
            logger.error("DeviceRebootJob not found in the database despite auto-registration")
            return JsonResponse({
                'success': False,
                'error': 'DeviceRebootJob not found in the database. Please try restarting the server.'
            })
        
        # Get schedule time if not immediate
        schedule_time = None
        if execution_type != 'immediate':
            schedule_time_str = request.POST.get('scheduleTime')
            if schedule_time_str:
                from django.utils import timezone
                from datetime import datetime
                
                try:
                    # Parse the datetime string
                    schedule_time = datetime.fromisoformat(schedule_time_str.replace('Z', '+00:00'))
                    # Ensure it's timezone aware
                    if timezone.is_naive(schedule_time):
                        schedule_time = timezone.make_aware(schedule_time)
                except ValueError as e:
                    logger.error(f"Invalid schedule time format: {schedule_time_str} - {str(e)}")
                    return JsonResponse({
                        'success': False,
                        'error': f"Invalid schedule time format: {str(e)}"
                    })
        
        # Create job records for each device
        job_ids = {}
        install_job_ids = {}
        if executionMode == 'serial':
            devices_list_to_pass = []
            devices_map = []
            for device_ip in devices:
                # Clean the device IP if it contains subnet mask
                clean_device_ip = device_ip.split('/')[0] if '/' in device_ip else device_ip
                devices_list_to_pass.append(clean_device_ip)
                devices_map.append(device_ip)
                
            # Prepare job parameters
            job_kwargs = {
                'device_ip': devices_list_to_pass,
                'tftp_server': tftp_server,
                'tftp_path': tftp_path,
                'auth_method': auth_method,
                'credential_profile': credential_profile,
                'dryrun': test_mode,
                # New parameters for device_type_vars.yml
                'change_number': change_number,
                'vrf_name': vrf_name,
                'smtp_server': smtp_server,
                'email_sender': email_sender,
                'email_receiver': email_receiver,
                # Always set these validation parameters to True
                'check_memory': True,
                'check_compatibility': True,
                'backup_config': True,
                'verify_boot': True,
                'verify_features': True,
                'enable_rollback': True,
                #'email_part1':email_part1,
                #'email_part2':email_part2,
                'executionMode':executionMode,
            }
            
                # Create a unique name for the job
            job_name = f"Device Reboot for {clean_device_ip}"
            if schedule_time:
                job_name += f" - {schedule_time.strftime('%Y-%m-%d %H:%M')}"
                    
            # SCHEDULED JOBS
            if schedule_time:
                from nautobot.extras.choices import JobExecutionType
                from nautobot.extras.models import ScheduledJob
                
                # Regular job scheduling (upload or install)
                scheduled_job = ScheduledJob.create_schedule(
                    job_model=job_model,
                    user=request.user,
                    name=job_name,
                    start_time=schedule_time,
                    interval=JobExecutionType.TYPE_FUTURE,  # One-time execution
                    approval_required=False,
                    **job_kwargs
                )
                    
                # Store the job_id for tracking
                for device_ip_single in devices_map:
                    job_ids[device_ip_single] = str(scheduled_job.pk)
                log_msg = f"Scheduled {'test' if test_mode else 'Reboot'} job {scheduled_job.pk} for device {device_ip} at {schedule_time}"
                logger.info(log_msg)
            # Modified section for IMMEDIATE JOBS in start_upgrade view
            else:
                # Regular immediate job (simple upload or install)
                job_result = JobResult.enqueue_job(
                    job_model=job_model,
                    user=request.user,
                    **job_kwargs
                )
                
                # Store the job_id for tracking
                #job_ids[device_ip] = str(job_result.pk)
                # Store the job_id for tracking
                for device_ip_single in devices_map:
                    job_ids[device_ip_single] = str(job_result.pk)
                log_msg = f"Started {'test' if test_mode else 'Reboot'} job {job_result.pk} for device {device_ip}"
                logger.info(log_msg)
            # Return success response with job IDs in the expected format
        else:
            for device_ip in devices:
                # Clean the device IP if it contains subnet mask
                clean_device_ip = device_ip.split('/')[0] if '/' in device_ip else device_ip
                
                # Prepare job parameters
                job_kwargs = {
                    'device_ip': clean_device_ip,
                    'tftp_server': tftp_server,
                    'tftp_path': tftp_path,
                    'auth_method': auth_method,
                    'credential_profile': credential_profile,
                    'dryrun': test_mode,
                    # New parameters for device_type_vars.yml
                    'change_number': change_number,
                    'vrf_name': vrf_name,
                    'smtp_server': smtp_server,
                    'email_sender': email_sender,
                    'email_receiver': email_receiver,
                    # Always set these validation parameters to True
                    'check_memory': True,
                    'check_compatibility': True,
                    'backup_config': True,
                    'verify_boot': True,
                    'verify_features': True,
                    'enable_rollback': True,
                    #'email_part1':email_part1,
                    #'email_part2':email_part2,
                    'executionMode':executionMode,
                }
                
                # Create a unique name for the job
                job_name = f"Device Reboot for {clean_device_ip}"
                if schedule_time:
                    job_name += f" - {schedule_time.strftime('%Y-%m-%d %H:%M')}"
                    
                # SCHEDULED JOBS
                if schedule_time:
                    from nautobot.extras.choices import JobExecutionType
                    from nautobot.extras.models import ScheduledJob
                    
                    # Regular job scheduling (upload or install)
                    scheduled_job = ScheduledJob.create_schedule(
                        job_model=job_model,
                        user=request.user,
                        name=job_name,
                        start_time=schedule_time,
                        interval=JobExecutionType.TYPE_FUTURE,  # One-time execution
                        approval_required=False,
                        **job_kwargs
                    )
                        
                    # Store the job_id for tracking
                    job_ids[device_ip] = str(scheduled_job.pk)
                    log_msg = f"Scheduled {'test' if test_mode else 'Reboot'} job {scheduled_job.pk} for device {device_ip} at {schedule_time}"
                    logger.info(log_msg)
                # Modified section for IMMEDIATE JOBS in start_upgrade view
                else:
                    print('job_kwargs:',job_kwargs)
                    # Regular immediate job (simple upload or install)
                    job_result = JobResult.enqueue_job(
                        job_model=job_model,
                        user=request.user,
                        **job_kwargs
                    )
                    
                    # Store the job_id for tracking
                    job_ids[device_ip] = str(job_result.pk)
                    log_msg = f"Started {'test' if test_mode else 'Reboot'} job {job_result.pk} for device {device_ip}"
                    logger.info(log_msg)
            # Return success response with job IDs in the expected format
        
        response_data = {
            'success': True,
            'message': f"{'Test' if test_mode else 'Reboot'} jobs {'scheduled' if schedule_time else 'created'} successfully",
            'job_ids': job_ids,  # Primary job IDs (upload jobs for upload_install)
            'test_mode': test_mode,
            'scheduled': bool(schedule_time)
        }
        
        return JsonResponse(response_data)
        """
        if request.method != 'POST':
            return JsonResponse({'success': False, 'error': 'Only POST method is allowed'})
        response_data = {
            'success': True,
            'message': f"Success",
            'job_ids': 0,  # Primary job IDs (upload jobs for upload_install)
            'test_mode': 0,
            'scheduled': bool(0)
        }
        # If we created install jobs as part of upload_install, include those in the response
        return JsonResponse(response_data)
        """
    except Exception as e:
        logger.error(f"Error starting reboot process: {str(e)}")
        import traceback
        logger.error(traceback.format_exc())
        return JsonResponse({
            'success': False,
            'error': str(e)
        })
    



@login_required
def reboot_job_progress(request):
    """
    Get the progress of a job with detailed logs.
    """
    job_id = request.GET.get('job_id')
    if not job_id:
        return JsonResponse({
            'success': False,
            'error': 'Job ID is required'
        })
    
    try:
        # Look up the job result directly by primary key (UUID)
        job_result = JobResult.objects.get(pk=job_id)
        
        # Log raw job result data for debugging
        logger.info(f"Raw job result for {job_id}: status={job_result.status}")
        
        # Get detailed job logs from the database
        logs = []
        
        # Try to get real logs from various sources in JobResult
        try:
            # First try: Get logs from Nautobot's JobResult method
            # This attempts to get all detailed logs with timestamps
            if hasattr(job_result, 'get_log'):
                try:
                    for entry in job_result.get_log():
                        logs.append({
                            'timestamp': entry.get('created', ''),
                            'message': entry.get('message', '')
                        })
                except Exception as log_error:
                    logger.info(f"Could not get logs with get_log method: {str(log_error)}")
                    
            # Second try: Direct access to job_result logs if it's a list
            elif hasattr(job_result, 'log') and isinstance(job_result.log, list):
                for entry in job_result.log:
                    if isinstance(entry, dict):
                        logs.append({
                            'timestamp': entry.get('created', ''),
                            'message': entry.get('message', '')
                        })
                    else:
                        logs.append({
                            'timestamp': '',
                            'message': str(entry)
                        })
            
            # Third try: If job has data with log entries
            elif hasattr(job_result, 'data') and job_result.data and 'log_entries' in job_result.data:
                for entry in job_result.data['log_entries']:
                    if isinstance(entry, dict):
                        logs.append({
                            'timestamp': entry.get('timestamp', ''),
                            'message': entry.get('message', '')
                        })
                    else:
                        logs.append({
                            'timestamp': '',
                            'message': str(entry)
                        }) 
            
            # Fallback: If log is a method or unsuccessful, check if there's job output
            if not logs and hasattr(job_result, 'job_output') and job_result.job_output:
                # Split the output by line and add as log entries
                output_lines = job_result.job_output.split('\n')
                for line in output_lines:
                    if line.strip():
                        logs.append({
                            'timestamp': '',
                            'message': line.strip()
                        })
            
            # Last fallback: Check the job_result string representation
            if not logs:
                job_repr = str(job_result)
                
                # Try to extract device IP and status from the string representation
                import re
                match = re.search(r'Device\s+(\S+).+?\((\w+)\)', job_repr)
                if match:
                    device_ip = match.group(1)
                    status = match.group(2)
                    
                    # Create a log entry
                    logs.append({
                        'timestamp': '',
                        'message': f"Device Reboot for device {device_ip} completed with status: {status}"
                    })
                else:
                    # Just add the string representation as a message
                    logs.append({
                        'timestamp': '',
                        'message': f"Job completed: {job_repr}"
                    })
            
        except Exception as e:
            logger.error(f"Error getting detailed logs: {str(e)}")
            logs.append({
                'timestamp': '',
                'message': f"Error retrieving logs: {str(e)}"
            })
        
        # If no logs were found through any method, add a default message
        if not logs:
            logs.append({
                'timestamp': '',
                'message': 'No detailed logs available for this job'
            })
        
        # Extract status directly from the job_result object
        # Also check if "SUCCESS" is in the string representation
        job_repr = str(job_result)
        
        # Determine success based on job_repr or status
        is_success = "SUCCESS" in job_repr or job_result.status == "completed"
        is_failed = "FAILED" in job_repr or job_result.status in ["failed", "errored"]
        is_running = "RUNNING" in job_repr or job_result.status == "running"
        
        # Calculate progress based on inferred status
        progress = 0
        if is_running:
            progress = 50
        elif is_success or is_failed:
            progress = 100
        
        # Determine frontend status
        if is_success:
            frontend_status = 'Success'
        elif is_failed:
            frontend_status = 'Failed'
        elif is_running:
            frontend_status = 'Running'
        else:
            frontend_status = 'Pending'
        
        # Log the inferred status
        logger.info(f"Inferred status for job {job_id}: {frontend_status}, progress: {progress}")
        
        # Job is completed if it's success or failed
        is_completed = is_success or is_failed
        
        # Return job status with details
        return JsonResponse({
            'success': True,
            'status': frontend_status,
            'progress': progress,
            'logs': logs,
            'job_id': job_id,
            'completed': is_completed
        })
    
    except JobResult.DoesNotExist:
        return JsonResponse({
            'success': False,
            'error': f'Job with ID {job_id} not found'
        })
    except Exception as e:
        logger.error(f"Error getting job progress: {str(e)}")
        return JsonResponse({
            'success': False,
            'error': str(e)
        })

@login_required
def reboot_job_history(request):
    """
    Return job history for the current user.
    """
    try:
        # Get all JobResults for DeviceRebootJob
        job_model = Job.objects.get(job_class_name='DeviceRebootJob', module_name='naas.jobs')
        
        # Get search parameters
        search_term = request.GET.get('q', '')
        status_filter = request.GET.get('status', '')
        
        # Build base queryset
        query = JobResult.objects.filter(job_model=job_model)
        
        # Apply filters
        if search_term:
            # We'll filter post-fetch
            pass
        
        if status_filter:
            query = query.filter(status=status_filter)
        
        # Order by date_created
        job_results = query.order_by('-date_created')[:50]  # Get more to allow for filtering
        
        jobs = []
        for result in job_results:
            # Extract job parameters
            device_ip = None
            
            # Try to get device_ip from task_kwargs
            if hasattr(result, 'task_kwargs') and result.task_kwargs:
                try:
                    task_kwargs = result.task_kwargs
                    if isinstance(task_kwargs, str):
                        import json
                        task_kwargs = json.loads(task_kwargs)
                    
                    device_ip = task_kwargs.get('device_ip')
                except Exception as e:
                    logger.warning(f"Error extracting task_kwargs: {str(e)}")
            
            # Apply search filter if needed
            if search_term and (not device_ip or search_term.lower() not in device_ip.lower()):
                if not str(result.pk).lower().startswith(search_term.lower()):
                    continue  # Skip this result if it doesn't match the search term
            
            # Build timeline from job logs
            timeline = []
            from nautobot.extras.models import JobLogEntry
            
            # Use 'created' field instead of 'date_created' for ordering
            logs = JobLogEntry.objects.filter(job_result=result).order_by('created')
            
            for log in logs:
                try:
                    if log.log_level in ('info', 'success', 'warning', 'error'):
                        # Use 'created' field for the time value
                        timeline.append({
                            'title': log.log_level.capitalize(),
                            'time': log.created.strftime('%H:%M:%S'),
                            'description': log.message[:100] if log.message else "No message"
                        })
                except Exception as e:
                    logger.warning(f"Error processing log entry: {str(e)}")
            
            # Determine if this is a scheduled job
            scheduled_time = None
            if hasattr(result, 'scheduled_job') and result.scheduled_job:
                try:
                    scheduled_time = result.scheduled_job.scheduled_time.strftime('%Y-%m-%d %H:%M')
                except Exception as e:
                    logger.warning(f"Error extracting scheduled time: {str(e)}")
            
            # Create job entry
            job_data = {
                'id': str(result.pk),
                'device_ip': device_ip or 'Unknown',
                'device_type': 'SWITCH',  # Default type
                'status': result.status,
                'timeline': timeline
            }
            
            # Add dates if available
            if hasattr(result, 'started') and result.started:
                job_data['started_at'] = result.started.strftime('%Y-%m-%d %H:%M')
            
            if hasattr(result, 'date_done') and result.date_done:
                job_data['completed_at'] = result.date_done.strftime('%Y-%m-%d %H:%M')
            
            if scheduled_time:
                job_data['scheduled_time'] = scheduled_time
            
            jobs.append(job_data)
        
        # Limit to 20 jobs after filtering
        jobs = jobs[:20]
        
        return JsonResponse({
            'success': True,
            'jobs': jobs
        })
    
    except Exception as e:
        logger.error(f"Error retrieving job history: {str(e)}")
        import traceback
        logger.error(traceback.format_exc())
        return JsonResponse({
            'success': False,
            'error': str(e)
        })

@login_required
@csrf_protect
def reboot_precheck_validate_multiple(request):
    """
    Validate multiple Cisco devices before reboot
    """
    import paramiko
    import time
    import naas.constants
    if request.method != 'POST':
        return JsonResponse({'success': False, 'error': 'Only POST method is allowed'})
    
    # Get device IPs from request
    import json
    device_ips_json = request.POST.get('device_ips', '[]')
    try:
        device_ips = json.loads(device_ips_json)
        
    except json.JSONDecodeError:
        return JsonResponse({
            'success': False, 
            'error': 'Invalid device IPs format'
        })
    
    if not device_ips:
        return JsonResponse({
            'success': False, 
            'error': 'No devices specified'
        })
    
    # Get credential profile
    credential_profile = request.POST.get('credential_profile', 'default')
    executionMode = request.POST.get('executionMode','serial')
    #print('executionMode',executionMode)
    from pathlib import Path
    # Get credentials (use the same for all devices for simplicity)
    # In a prod.uction environment, you might want to handle different credentials per device
    credentials = get_device_credentials(device_ips[0], credential_profile)
    user = credentials.get('username')
    passwd = credentials.get('password')
    #print(user)
    #print(passwd)
    pre_check_commands = naas.constants.reboot_const['Catalyst']['pre_check']
    backup_commands = naas.constants.reboot_const['Catalyst']['backup']
    
    return_output = {}
    for ip_full in device_ips:
        try:
            ip_result=''
            ip_ar = ip_full.split('/')
            ip = ip_ar[0]
            current_dir = Path(__file__).parent
            tmp_dir = current_dir / 'tmp_files'
            output_file_name = ip+'_precheck.txt'
            output_file = tmp_dir / output_file_name
            if os.path.exists(output_file):                
                os.remove(output_file)
            client = paramiko.SSHClient()
            client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            client.connect(ip, username=user, password=passwd, port=22, timeout=30)
            ip_result = ip_result + (f"Successfully connected to {ip}")
            
            ssh_shell = client.invoke_shell()
            time.sleep(3)
            ssh_shell.send(b"terminal length 0\n")
            time.sleep(3)
            ip_result = ip_result + "Running pre check commands<br/>"
            return_output[ip_full] = {}
            for key,value in pre_check_commands.items():
                ssh_shell.send(value.encode() + b'\n')
                time.sleep(4)
                print('Running -'+value)
                while not ssh_shell.recv_ready():
                    time.sleep(10)
                while ssh_shell.recv_ready():
                    res = ssh_shell.recv(65535).decode()
                    ip_result += res
                    ansi_escape = re.compile(r'\x1B[@-_][0-?]*[ -/]*[@-~]')
                    cleaned = ansi_escape.sub('', res)
                    cleaned = cleaned.replace('\r', '')
                    with open(output_file, 'a') as f:
                        f.write(f"Output of '{value}':\n{cleaned}\n")
                        f.write("*" * 100 + "\n")
                
                if key not in ['show_version','show_logging']:
                    return_output[ip_full][key] = 'PASS'
            
            ip_parse_result = reboot_parse_precheck_results_for_device(ip_result, ip)
            return_output[ip_full].update(ip_parse_result)
            
            # Add the raw output to each device result
            return_output[ip_full]['raw_output'] = ip_result
            
            #Take Backup Of Configuration
            for command in backup_commands:
                ssh_shell.send(command.encode() + b'\n')
                time.sleep(2) 
                output = ""
                while ssh_shell.recv_ready():
                    output += ssh_shell.recv(65535).decode().lower()
                print(f"Output of '{command}':\n{output}")
                if "yes/no" in output.lower():
                    ssh_shell.send(b"yes\n")
                    time.sleep(1)
                elif "confirm" in output:
                    ssh_shell.send(b"\n") 
                    time.sleep(2)
                else :
                    ssh_shell.send(b"\n") 
                time.sleep(2) 
                backup_output = ""
                while ssh_shell.recv_ready():
                    backup_output += ssh_shell.recv(65535).decode()
        
        except paramiko.AuthenticationException:
            print('paramiko.AuthenticationException')
            ip_result = ip_result + "Authentication failed, please verify your credentials."
            #raise
        except paramiko.SSHException as sshException:
            print('paramiko.SSHException')
            ip_result = ip_result + (f"Unable to establish SSH connection: {sshException}")
            #raise
        except IOError as io_error:
            print('IOError')
            ip_result = ip_result + (f"File I/O error: {io_error}")
            #raise
        except Exception as e:
            print(f"Error executing commands on {ip}: {e}")
            ip_result = ip_result + (f"Error executing commands on {ip}: {e}")
            #raise
    return JsonResponse({
            'success': True,
            'results': return_output,
            #'raw_ansible_output': stdout  # Include the full raw output at the top level as well
        })

def reboot_parse_precheck_results_for_device(paramiko_output, device_ip):
    """
    Parse the paramiko output to extract results for a specific device
    """
    import re
    import logging
    import math
    logger = logging.getLogger(__name__)
    # Default results
    results = {
        'ios_version': 'Unknown',
        'flash_total_mb': 0,
        'flash_used_mb': 0,
        'flash_free_mb': 0,
        'flash_used_percent': 0,
        'flash_free_percent': 0,
        'flash_status': 'UNKNOWN',
        'error_status': 'UNKNOWN',
        'overall_status': 'NOT READY',
        'issues': [],
        'recommendations': []
    }
    try:
        # First, try to extract IOS version from ansible_facts if available
        ios_facts_match = re.search(r', Version ([\d\.A-Za-z0-9]+)', paramiko_output)
        if ios_facts_match:
            results['ios_version'] = ios_facts_match.group(1)
        '''
        check flash data
        '''
        for line in paramiko_output.splitlines():
            if 'flash:' in line or 'bootflash:' in line:
                try:
                    parts = re.split(r'\s+',line.strip())
                    total = math.ceil(int(parts[1]) / (1024 * 1024))
                    free = math.ceil(int(parts[2]) / (1024 * 1024))
                    used = total - free
                    results['flash_total_mb'] = total
                    results['flash_used_mb'] = used
                    results['flash_free_mb'] = free
                    results['flash_free_percent'] = math.ceil((results['flash_free_mb'] / results['flash_total_mb']) * 100)
                    required_free_space_mb = 100
                    min_flash_free_percent = 30
                    if results['flash_free_percent']  >= min_flash_free_percent and results['flash_free_mb'] >= required_free_space_mb:
                        results['flash_status'] = 'PASS'
                    
                    break
                except ValueError:
                    print(f"Skipping invalid line - {line}")
        # Extract flash information
        flash_info_match = re.search(r'Flash Total:\s*([\d.]+)\s*MB\s*Flash Used:\s*([\d.]+)\s*MB\s*\(([\d.]+)%\)\s*Flash Free:\s*([\d.]+)\s*MB\s*\(([\d.]+)%\)\s*Flash Status:\s*(\w+)', paramiko_output)
        if flash_info_match:
            results['flash_total_mb'] = float(flash_info_match.group(1))
            results['flash_used_mb'] = float(flash_info_match.group(2))
            results['flash_used_percent'] = float(flash_info_match.group(3))
            results['flash_free_mb'] = float(flash_info_match.group(4))
            results['flash_free_percent'] = float(flash_info_match.group(5))
           
        # Extract error status
        error_match = re.search(r'Error \s*(\w+)', paramiko_output)
        if error_match:
            results['error_status'] = 'WARN'
        else:
            results['error_status'] = 'PASS'
        
        if results['flash_status'] == 'PASS' and results['error_status'] == 'PASS':
            results['overall_status'] = 'READY'
        elif results['error_status'] == 'WARN' and results['flash_status'] == 'PASS':
            results['overall_status'] = 'READY WITH WARNINGS'
        else:
            results['overall_status'] = 'NOT READY'
        
        # If we have data from debugging print statement
        debug_pattern = rf'Device: {re.escape(device_ip)}, IOS: ([^,]+), Flash: ([^,]+), CPU: ([^,]+), Error: ([^,]+), Overall: ([^\n]+)'
        debug_match = re.search(debug_pattern, paramiko_output)
        if debug_match:
            if results['ios_version'] == 'Unknown':
                results['ios_version'] = debug_match.group(1).strip()
            if results['flash_status'] == 'UNKNOWN':
                results['flash_status'] = debug_match.group(2).strip()
            if results['error_status'] == 'UNKNOWN':
                results['error_status'] = debug_match.group(4).strip()
            results['overall_status'] = debug_match.group(5).strip()
        
        # If we have valid flash and (valid or unknown CPU) and valid error status, set as READY
        if results['flash_status'] == 'PASS' and results['error_status'] == 'PASS':
            results['overall_status'] = 'READY'
        elif results['flash_status'] == 'PASS' and results['error_status'] == 'WARN':
            results['overall_status'] = 'READY WITH WARNINGS'
        
        # Add issues and recommendations based on status
        results['issues'] = []
        results['recommendations'] = []
        
        if results['flash_status'] != 'PASS' and results['flash_status'] != 'UNKNOWN':
            results['issues'].append(f"Insufficient flash space: {results['flash_free_percent']}% free, {results['flash_free_mb']} MB available.")
            results['recommendations'].append("Delete unnecessary files from flash memory or consider using a smaller IOS image.")
        
        
        if results['error_status'] != 'PASS' and results['error_status'] != 'UNKNOWN':
            results['issues'].append("Recent error logs detected.")
            results['recommendations'].append("Review the error logs before proceeding with the upgrade.")
        
        # If device is ready but has no values filled in, add a general recommendation
        if results['overall_status'] == 'READY' and not results['issues']:
            results['recommendations'].append("Device appears ready for reboot. Ensure you have a backup configuration before proceeding.")
        
        logger.info(f"Parsing results for {device_ip}: Flash: {results['flash_status']}, Error: {results['error_status']}, Overall: {results['overall_status']}")
        
    except Exception as e:
        import traceback
        logger.error(f"Error parsing results for device {device_ip}: {str(e)}")
        logger.error(traceback.format_exc())
        
        # Add error as an issue
        results['issues'] = [f"Error parsing validation results: {str(e)}"]
        results['recommendations'] = ["Try running the validation again or check device connectivity."]
    
    return results

@login_required
@csrf_protect
@require_POST
def reboot_request_approval(request):
    """
    Create an reboot approval request and send notification email.
    This is a new endpoint that doesn't interfere with the original start_upgrade.
    """
    try:
        # Parse job parameters from request
        job_params = json.loads(request.body)
        # Extract key parameters for easier access
        devices = job_params.get('devices', [])
        email_receiver = job_params.get('email_receiver')
        executionMode = job_params.get('executionMode')
        # Extract precheck results if available
        precheck_results = job_params.get('precheck_results', {})
        #print('precheck_results : ',precheck_results)
        if not devices:
            return JsonResponse({
                'success': False,
                'error': 'No devices specified'
            })
            
        if not email_receiver:
            return JsonResponse({
                'success': False,
                'error': 'Approver email is required'
            })
        
        # Set expiration time (24 hours from now)
        expires_at = timezone.now() + timedelta(hours=72)
        
        # Prepare response data
        approval_ids = {}
        install_approval_ids = {}
        # Create approval requests for each device
        cleaned_devices = []
        devices_at_once = []
        if executionMode == 'serial':
            for device_ip in devices:
                clean_device_ip = device_ip.split('/')[0] if '/' in device_ip else device_ip
                # Create a copy of job parameters for this device
                device_params = job_params.copy()
                device_params['device_ip'] = clean_device_ip

                cleaned_devices.append(clean_device_ip)
                # Get device-specific precheck results if available
                if clean_device_ip in precheck_results:
                    #print('pre-',precheck_results[clean_device_ip])
                    device_params['precheck_result'] = precheck_results
                    
                    # Create a summary of the precheck result for logging
                    
                    precheck_summary = {
                        'ios_version': precheck_results[clean_device_ip].get('ios_version', 'Unknown'),
                        'flash_status': precheck_results[clean_device_ip].get('flash_status', 'Unknown'),
                        'show_running_config_result': precheck_results[clean_device_ip].get('show_running_config_result', 'Unknown'),
                        'show_ip_interface_brief': precheck_results[clean_device_ip].get('show_ip_interface_brief', 'Unknown'),
                        'show_vlan': precheck_results[clean_device_ip].get('show_vlan', 'Unknown'),
                        'show_spanning_tree': precheck_results[clean_device_ip].get('show_spanning_tree', 'Unknown'),
                        'show_ip_route': precheck_results[clean_device_ip].get('show_ip_route', 'Unknown'),
                        'show_cdp_neighbors_detail': precheck_results[clean_device_ip].get('show_cdp_neighbors_detail', 'Unknown'),
                        'show_interfaces_status': precheck_results[clean_device_ip].get('show_interfaces_status', 'Unknown'),
                        'overall_status': precheck_results[clean_device_ip].get('overall_status', 'Unknown')
                    }
                    logger.info(f"Including precheck results for {clean_device_ip}: {precheck_summary}")
                
                # Remove the devices list as we're processing one device at a time
                if 'devices' in device_params:
                    del device_params['devices']
                
                # Remove the full precheck_results collection as we've already extracted 
                # the specific device's result
                if 'precheck_results' in device_params:
                    del device_params['precheck_results']
                

            devices_at_once = ','.join(cleaned_devices)
            # Regular single approval
            approval = RebootApprovalRequest.objects.create(
                requester=request.user.username,
                approver_email=email_receiver,
                device_ip=devices_at_once,
                job_parameters=device_params,
                expires_at=expires_at,
                requester_email=request.user.email,
            )
            
            # Store approval ID
            approval_ids[device_ip] = str(approval.id)
            
            # Send approval email
            reboot_send_approval_email(request, approval)
        else:        
            for device_ip in devices:
                # Clean up device IP if needed
                clean_device_ip = device_ip.split('/')[0] if '/' in device_ip else device_ip
                
                # Create a copy of job parameters for this device
                device_params = job_params.copy()
                device_params['device_ip'] = clean_device_ip
                
                # Get device-specific precheck results if available
                if clean_device_ip in precheck_results:
                    device_params['precheck_result'] = precheck_results
                    
                    # Create a summary of the precheck result for logging
                    
                    precheck_summary = {
                        'ios_version': precheck_results[clean_device_ip].get('ios_version', 'Unknown'),
                        'flash_status': precheck_results[clean_device_ip].get('flash_status', 'Unknown'),
                        'show_running_config_result': precheck_results[clean_device_ip].get('show_running_config_result', 'Unknown'),
                        'show_ip_interface_brief': precheck_results[clean_device_ip].get('show_ip_interface_brief', 'Unknown'),
                        'show_vlan': precheck_results[clean_device_ip].get('show_vlan', 'Unknown'),
                        'show_spanning_tree': precheck_results[clean_device_ip].get('show_spanning_tree', 'Unknown'),
                        'show_ip_route': precheck_results[clean_device_ip].get('show_ip_route', 'Unknown'),
                        'show_cdp_neighbors_detail': precheck_results[clean_device_ip].get('show_cdp_neighbors_detail', 'Unknown'),
                        'show_interfaces_status': precheck_results[clean_device_ip].get('show_interfaces_status', 'Unknown'),
                        'overall_status': precheck_results[clean_device_ip].get('overall_status', 'Unknown')
                    }
                    logger.info(f"Including precheck results for {clean_device_ip}: {precheck_summary}")
                
                # Remove the devices list as we're processing one device at a time
                if 'devices' in device_params:
                    del device_params['devices']
                
                # Remove the full precheck_results collection as we've already extracted 
                # the specific device's result
                if 'precheck_results' in device_params:
                    del device_params['precheck_results']
                
                # Regular single approval
                approval = RebootApprovalRequest.objects.create(
                    requester=request.user.username,
                    approver_email=email_receiver,
                    device_ip=clean_device_ip,
                    job_parameters=device_params,
                    expires_at=expires_at
                )
                
                # Store approval ID
                approval_ids[device_ip] = str(approval.id)
                
                # Send approval email
                reboot_send_approval_email(request, approval)
        
        
        # Return success response
        response = {
            'success': True,
            'message': f'Approval requests created for {len(devices)} device(s)',
            'approval_ids': approval_ids
        }
        
        return JsonResponse(response)
                
    except Exception as e:
        import traceback
        logger.error(f"Error creating approval request: {str(e)}")
        logger.error(traceback.format_exc())
        return JsonResponse({
            'success': False,
            'error': f'Error creating approval request: {str(e)}'
        })

def reboot_send_approval_email(request, approval):
    """Helper function to send approval request email"""
    
    approval_url = request.build_absolute_uri(reverse('plugins:naas:approve-reboot', args=[str(approval.approval_token)])) #'/plugins/naas/approve-reboot/'+str(approval.approval_token) 
    
    # Prepare email context
    context = {
        'device_ip': approval.device_ip,
        'requester': approval.requester,
        'approval_url': approval_url,
        'expires_at': approval.expires_at,
        'job_params': approval.job_parameters,
        'action_name': 'Reboot',
        'approval_id': str(approval.id)
    }
    # Render email template
    subject = f'Device Reboot Approval Request for {approval.device_ip}'
    html_message =  loader.render_to_string('naas/reboot_approval_request.html', context)
    plain_message = f"""
Device Reboot approval requested for {approval.device_ip}
Requested by: {approval.requester}
Action: Reboot
Approve at: {approval_url}
    """
    # Send email
    import smtplib
    from email.mime.text import MIMEText
    from email.mime.multipart import MIMEMultipart
    from naas import constants
    sender_email = constants.sender_email
    sender_password = constants.sender_password  # Use App Password if using Gmail

    # Create the email
    msg = MIMEMultipart('alternative')
    msg['From'] = sender_email
    msg['To'] = approval.approver_email
    msg['Subject'] = subject

    # Attach the message body
    msg.attach(MIMEText(html_message, 'html'))

    try:
        # Connect to the SMTP server
        server = smtplib.SMTP(constants.smtp_lib_server, constants.smtp_port)
        server.starttls()
        server.login(sender_email, sender_password)

        # Send the email
        server.sendmail(sender_email, msg['To'] , msg.as_string())
        server.quit()

        logger.info("Email sent successfully!")
        return True
    except Exception as e:
        logger.info(f"Error sending email: {e}")
        return False
    
@login_required
def approve_reboot(request, token):
    """Handle approval page and approval actions"""
    # Get the approval by token or return 404
    approval = get_object_or_404(RebootApprovalRequest, approval_token=token)
    
    # Check if already processed
    if approval.status != 'pending':
        message = f"This request has already been {approval.status}."
        return render(request, 'naas/reboot_approval_result.html', {
            'success': False,
            'message': message,
            'approval': approval
        })
    
    # Check if expired
    if approval.is_expired():
        approval.status = 'expired'
        approval.save()
        return render(request, 'naas/reboot_approval_result.html', {
            'success': False,
            'message': 'This approval request has expired.',
            'approval': approval
        })
    
    
    # Handle POST request (approval action)
    if request.method == 'POST':
        action = request.POST.get('action_to_be_taken', '')
        comments = request.POST.get('comments', '')
        
        if action == 'approve':
            # Mark as approved
            approval.status = 'approved'
            approval.approved_at = timezone.now()
            approval.approved_by = request.user.username
            approval.save()
            
            # Queue the job for execution
            job_success, job_id, message = reboot_queue_job_from_approval(approval, request.user)
            
            # Update approval status based on job creation result
            if job_success:
                approval.status = 'executed'
                approval.save()
                return render(request, 'naas/reboot_approval_result.html', {
                    'success': True,
                    'message': 'The reboot job has been approved and queued successfully.',
                    'job_id': job_id,
                    'approval': approval
                })
            else:
                return render(request, 'naas/reboot_approval_result.html', {
                    'success': False,
                    'message': f'The upgrade was approved, but job creation failed: {message}',
                    'approval': approval
                })
        
        elif action == 'reject':
            # Mark as rejected
            approval.status = 'rejected'
            approval.rejected_at = timezone.now()
            approval.rejected_by = request.user.username
            approval.rejection_reason = comments
            approval.save()
            
            return render(request, 'naas/reboot_approval_result.html', {
                'success': False,
                'message': 'The reboot request has been rejected.',
                'approval': approval
            })
    
    # Handle GET request (show approval page)
    return render(request, 'naas/reboot_approval_page.html', {
        'approval': approval
    })

def reboot_queue_job_from_approval(approval, user):
    """
    Create and queue a job from an approval request.
    Returns (success, job_id, message)
    """
    try:
        from naas import constants
        # Get the job model
        job_model = Job.objects.get(job_class_name='DeviceRebootJob', module_name='naas.jobs')
        
        job_params = approval.job_parameters.copy()
        #if job_params['email_receiver']=='':
        #    job_params['email_receiver'] = constants.smtp_default_email_receiver
        job_params['email_receiver'] = approval.requester_email
        email_parts = job_params['email_receiver'].split('@')
        #print('email_parts',email_parts)
        job_params['email_part1'] = email_parts[0]
        job_params['email_part2'] = email_parts[1]
        device_ips = approval.device_ip
        device_ips_list = device_ips.split(',')
        job_params['device_ip'] = device_ips_list
        if isinstance(device_ips_list,list):
            job_params['executionMode'] = 'serial'
        else:
            job_params['executionMode'] = 'parallel'
        # Get job parameters
        
        if 'vrf' in job_params and 'vrf_name' not in job_params:
            job_params['vrf_name'] = job_params['vrf']
            logger.info(f"Copied VRF parameter from 'vrf' to 'vrf_name': {job_params['vrf_name']}")
        
        # Remove unnecessary parameters
        job_params.pop('precheck_result', None)
        logger.info('job_params',job_params)
        # Create the job
        job_result = JobResult.enqueue_job(
            job_model=job_model,
            user=user,
            **job_params
        )
        
        return True, str(job_result.id), "Job created successfully"
    
    except Exception as e:
        logger.error(f"Error creating job from approval: {str(e)}")
        import traceback
        logger.error(traceback.format_exc())
        return False, None, str(e)

@login_required
@require_GET
def reboot_get_approval_status(request, approval_id):
    """API endpoint to check approval status"""
    try:
        approval = get_object_or_404(RebootApprovalRequest, id=approval_id)
        
        # Update status if expired
        if approval.status == 'pending' and approval.is_expired():
            approval.status = 'expired'
            approval.save()
        
        # Map status to display class
        status_class = {
            'pending': 'pending',
            'approved': 'success',
            'rejected': 'failed',
            'expired': 'warning',
            'executed': 'success'
        }.get(approval.status, 'pending')
        
        return JsonResponse({
            'success': True,
            'status': approval.status,
            'status_class': status_class,
            'updated_at': approval.approved_at or approval.rejected_at or approval.created_at
        })
    
    except Exception as e:
        return JsonResponse({
            'success': False,
            'error': str(e)
        })

@login_required
def reboot_approval_dashboard(request):
    """Dashboard for managing approval requests"""
    # Get filter parameters
    status = request.GET.get('status', '')
    device = request.GET.get('device', '')
    
    # Start with all approvals
    approvals = RebootApprovalRequest.objects.all().order_by('-created_at')
    
    # Apply filters
    if status:
        approvals = approvals.filter(status=status)
    
    if device:
        approvals = approvals.filter(device_ip__icontains=device)
    
    # Render the dashboard
    return render(request, 'naas/reboot_approval_dashboard.html', {
        'approvals': approvals,
        'status': status,
        'device': device
    })


@csrf_exempt
@require_http_methods(["GET"])
def fetch_f5_change_request(request, cr_number):
    """
    Fetch ServiceNow Change Request details and parse for F5 configuration
    """
    try:
        # Here you would integrate with your ServiceNow API
        # For now, returning mock data based on the example provided
        
        # Mock ServiceNow API call
        cr_details = get_servicenow_change_request(cr_number)
        
        if not cr_details:
            return JsonResponse({
                'status': 'error',
                'message': f'Change Request {cr_number} not found'
            })
        
        # Parse the description for F5 configuration data
        parsed_data = F5VIPSNOWDescriptionParser.parse_description(cr_details['result'][0]['description'])
        
        return JsonResponse({
            'status': 'success',
            'cr_number': cr_number,
            'description': cr_details['result'][0]['description'],
            'parsed_data': parsed_data,
            'auto_detected_operation': parsed_data.get('operation'),
            'state': cr_details.get('state', 'New'),
            'priority': cr_details.get('priority', 'Medium'),
            'requester': cr_details.get('requester', 'Unknown')
        })
        
    except Exception as e:
        return JsonResponse({
            'status': 'error',
            'message': f'Error fetching Change Request: {str(e)}'
        })


@csrf_exempt
def f5_config_preview(request):
    """Enhanced F5 configuration preview with SNOW integration"""
    if request.method == "POST":
        form = MultiF5OperationForm(request.POST)
        if form.is_valid():
            cleaned_data = form.get_cleaned_data()
            # Process the configuration based on operation type
            operation = cleaned_data.get('operation')
            requested_cr = cleaned_data.get('requested_cr')
            details = cleaned_data.get('details', {})
            
            # Generate preview/configuration
            config_preview = generate_f5_config_preview(operation, details)
            
            return render(request, "naas/f5_config_result.html", {
                "operation": operation,
                "requested_cr": requested_cr,
                "details": details,
                "config_preview": config_preview,
                "success": True
            })
        else:
            return render(request, "naas/f5_config.html", {
                "form": form,
                "errors": form.errors
            })
    else:
        # Get available VIPs for validation form
        vip_choices = get_available_vips()  # Implement this function
        form = MultiF5OperationForm(vip_choices=vip_choices)
    
    return render(request, "naas/f5_config.html", {"form": form})


def generate_f5_config_preview(operation, details):
    """Generate F5 configuration preview based on operation and details"""
    
    if operation == 'create_vip':
        return generate_vip_config(details)
    elif operation == 'create_pool':
        return generate_pool_config(details)
    elif operation == 'modify_pool':
        return generate_pool_modification_config(details)
    elif operation == 'vip_validation':
        return generate_vip_validation_config(details)
    
    return {}

def generate_vip_config(details):
    """Generate VIP configuration YAML"""
    config = {
        'vip_creation': {
            'vip': [{
                'name': details.get('name'),
                'partition': details.get('partition', 'Common'),
                'description': details.get('description', ''),
                'destination': details.get('destination'),
                'mask': details.get('mask', '255.255.255.255'),
                'source': details.get('source', '0.0.0.0/0'),
                'pool': details.get('pool'),
                'ipProtocol': details.get('ipProtocol', 'tcp'),
                'profiles': []
            }]
        }
    }
    
    # Add profiles
    profiles = []
    if details.get('protocol_client'):
        profiles.append({
            'name': details['protocol_client'].replace('/Common/', ''),
            'context': 'clientside'
        })
    
    if details.get('protocol_server') and details.get('protocol_server') != '':
        profiles.append({
            'name': details['protocol_server'].replace('/Common/', ''),
            'context': 'serverside'
        })
    
    if details.get('http_client'):
        profiles.append({'name': details['http_client'].replace('/Common/', '')})
    
    if details.get('ssl_client'):
        profiles.append({
            'name': details['ssl_client'].replace('/Common/', ''),
            'context': 'clientside'
        })
    
    if details.get('ssl_server'):
        profiles.append({
            'name': details['ssl_server'].replace('/Common/', ''),
            'context': 'serverside'
        })
    
    config['vip_creation']['vip'][0]['profiles'] = profiles
    
    # Add optional fields
    if details.get('snatpool'):
        config['vip_creation']['vip'][0]['snatpool'] = details['snatpool']
    
    return config

def generate_pool_config(details):
    """Generate Pool configuration"""
    members = []
    if details.get('pool_members'):
        for line in details['pool_members'].split('\n'):
            line = line.strip()
            if line:
                members.append({'address': line})
    
    config = {
        'pool_creation': {
            'pool': [{
                'name': details.get('pool_name'),
                'partition': details.get('partition', 'Common'),
                'description': details.get('description', ''),
                'load_balancing_mode': details.get('load_balancing_mode', 'round-robin'),
                'members': members
            }]
        }
    }
    
    return config

def generate_pool_modification_config(details):
    """Generate Pool modification configuration"""
    modifications = []
    if details.get('pool_member_modifications'):
        for line in details['pool_member_modifications'].split('\n'):
            line = line.strip()
            if line and ',' in line:
                address, action = line.split(',', 1)
                modifications.append({
                    'address': address.strip(),
                    'action': action.strip()
                })
    
    config = {
        'pool_modification': {
            'pool_name': details.get('pool_name'),
            'partition': details.get('partition', 'Common'),
            'modifications': modifications
        }
    }
    
    return config

def generate_vip_validation_config(details):
    """Generate VIP validation configuration"""
    config = {
        'vip_validation': {
            'partition': details.get('partition', 'Common'),
            'vip_names': details.get('vip_name', [])
        }
    }
    
    return config

def get_available_vips():
    """Get list of available VIPs for validation"""
    # This should query your F5 device or database
    # For now, returning mock data
    return [
        ('all', 'All VIPs'),
        ('VIP_WEBAPP_PROD', 'VIP_WEBAPP_PROD'),
        ('VIP_API_PROD', 'VIP_API_PROD'),
        ('VIP_TEST_01', 'VIP_TEST_01'),
    ]

@csrf_exempt
def f5_config_request_approval(request):
    """Submit request for F5 config approval"""
    if request.method == "POST":
        try:
            payload = json.loads(request.body)
            operation = payload.get('operation',)
            requested_cr = payload.get('requested_cr','')
            details = payload.get('data', {})                
            email_receiver = payload.get('email_receiver', '') 
            print("Herere is the params",details)

            # Set expiration time (24 hours from now)
            expires_at = timezone.now() + timedelta(hours=72)   

            f5Approval = F5Approval.objects.create(
                requester=request.user.username,
                requester_email=request.user.email,
                approver_email=email_receiver,
                operation=operation,
                cr_number=requested_cr,
                job_parameters=details,
                expires_at=expires_at
            ) 
                
            return JsonResponse({
                'success': True,
                'message': 'Request submitted successfully'
            }, status=200) 
            
        except json.JSONDecodeError:
            return JsonResponse({
                'success': False,
                'error': 'Issue request'
            }, status=400)        
        except Exception as e:
            print("Error occurred:", str(e))
            return JsonResponse({
                'success': False,
                'error': 'Error Occurred'
            }, status=400)  
    else:
        return JsonResponse({
            'success': False,
            'error': 'Invalid request'
        })

@login_required
def f5_approval_dashboard(request):
    """Enhanced dashboard for managing approval requests from both catalog and ServiceNow"""
    
    # Get filter parameters
    status = request.GET.get('status', '')
    cr_number = request.GET.get('cr_number', '')
    source = request.GET.get('source', '')
    operation = request.GET.get('operation', '')
    
    # Start with all approvals
    approvals = F5Approval.objects.all().order_by('-created_at')
    
    # Apply filters
    if status:
        approvals = approvals.filter(status=status)
    
    if cr_number:
        approvals = approvals.filter(cr_number__icontains=cr_number)
        
    if operation:
        approvals = approvals.filter(operation__icontains=operation)
    
    if source:
        if source == 'servicenow':
            approvals = approvals.filter(requester__icontains='ServiceNow')
        elif source == 'catalog':
            approvals = approvals.exclude(requester__icontains='ServiceNow').exclude(requester__icontains='ChatBot-')
        elif source == 'chat-bot':
            approvals = approvals.filter(requester__icontains='ChatBot-')
    
    # Get statistics for dashboard
    total_requests = F5Approval.objects.count()
    pending_requests = F5Approval.objects.filter(status='pending').count()
    servicenow_requests = F5Approval.objects.filter(requester__icontains='ServiceNow').count()
    chatbot_requests = F5Approval.objects.filter(requester__icontains='ChatBot-').count()
    catalog_requests = total_requests - servicenow_requests - chatbot_requests
    
    context = {
        'approvals': approvals,
        'status': status,
        'cr_number': cr_number,
        'source': source,
        'operation': operation,
        'statistics': {
            'total_requests': total_requests,
            'pending_requests': pending_requests,
            'servicenow_requests': servicenow_requests,
            'catalog_requests': catalog_requests,
            'chatbot_requests': chatbot_requests,
        }
    }
    
    return render(request, 'naas/f5_approval_dashboard.html', context)


@login_required
def approve_f5_config(request, token):
    """Enhanced approval page handler for both ServiceNow and UI Catalog requests"""
    
    # Get the approval by token or return 404
    approval = get_object_or_404(F5Approval, approval_token=token)
    
    # Check if already processed
    if approval.status != 'pending':
        message = f"This request has already been {approval.status}."
        return render(request, 'naas/f5_approval_result.html', {
            'success': False,
            'message': message,
            'approval': approval
        })
    
    # Check if expired
    if approval.is_expired():
        approval.status = 'expired'
        approval.save()
        return render(request, 'naas/f5_approval_result.html', {
            'success': False,
            'message': 'This approval request has expired.',
            'approval': approval
        })
    
    # Handle POST request (approval action)
    if request.method == 'POST':
        action = request.POST.get('action_to_be_taken', '')
        comments = request.POST.get('comments', '')
        
        if action == 'approve':
            # Mark as approved
            approval.status = 'approved'
            approval.approved_at = timezone.now()
            approval.approved_by = request.user.username
            approval.save()
            
            # Queue the F5 job for execution
            job_success, job_id, message = f5_queue_job_from_approval(approval, request.user)
            
            # Update approval status based on job creation result
            if job_success:
                approval.status = 'executed'
                approval.save()
                return render(request, 'naas/f5_approval_result.html', {
                    'success': True,
                    'message': 'The F5 configuration request has been approved and queued successfully.',
                    'job_id': job_id,
                    'approval': approval
                })
            else:
                return render(request, 'naas/f5_approval_result.html', {
                    'success': False,
                    'message': f'The F5 config was approved, but job creation failed: {message}',
                    'approval': approval
                })
        
        elif action == 'reject':
            # Mark as rejected
            approval.status = 'rejected'
            approval.rejected_at = timezone.now()
            approval.rejected_by = request.user.username
            approval.rejection_reason = comments
            approval.save()
            
            return render(request, 'naas/f5_approval_result.html', {
                'success': False,
                'message': 'The F5 configuration request has been rejected.',
                'approval': approval
            })
    
    # Handle GET request (show approval page)
    # Process job_parameters for better display
    processed_params = {}
    
    if approval.job_parameters:
        for key, value in approval.job_parameters.items():
            # Clean up parameter names for display
            display_key = key.replace('_', ' ').title()
            
            # Handle special cases
            if key == 'ipProtocol':
                display_key = 'IP Protocol'
            elif key == 'snatpool':
                display_key = 'SNAT Pool'
            elif key == 'job_parameters':
                continue  # Skip nested job_parameters
            
            processed_params[display_key] = value
    
    # Determine source type for display
    is_servicenow = 'ServiceNow' in approval.requester or 'servicenow' in approval.requester.lower()
    
    context = {
        'approval': approval,
        'processed_params': processed_params,
        'is_servicenow': is_servicenow,
        'source_display': 'ServiceNow Webhook' if is_servicenow else 'UI Catalog'
    }
    
    return render(request, 'naas/f5_approval_page.html', context)


def f5_queue_job_from_approval(approval, user):
    """
    Enhanced job creation that includes CR number for ServiceNow updates
    """
    try:
        # Get the F5 job model
        job_model = Job.objects.get(job_class_name='DeviceF5ConfigJob', module_name='naas.jobs')
        
        # Prepare job parameters from approval data
        job_params = approval.job_parameters.copy()
        
        # Add CR number for ServiceNow updates
        job_params['cr_number'] = approval.cr_number
        
        # Set F5 device connection details
        job_params['f5_ip'] = job_params.get('f5_ip', '172.21.17.111')
        job_params['f5_username'] = job_params.get('f5_username', 'admin')
        job_params['f5_password'] = job_params.get('f5_password', 'HCLtech@2025')
        
        # Set operation from approval
        job_params['operation'] = approval.operation
        
        # Convert job_parameters to JSON string for the job
        job_params['config_data'] = json.dumps(approval.job_parameters)
        
        # Set email receiver
        job_params['email_receiver'] = approval.requester_email or approval.approver_email
        
        # Set dry run to False for approved requests
        job_params['dryrun'] = False
        
        logger.info(f"Creating F5 job with CR number: {approval.cr_number}")
        
        # Create the job
        job_result = JobResult.enqueue_job(
            job_model=job_model,
            user=user,
            **job_params
        )
        
        logger.info(f"F5 job created successfully with ID: {job_result.id}")
        return True, str(job_result.id), "F5 job created successfully"
    
    except Exception as e:
        logger.error(f"Error creating F5 job from approval: {str(e)}")
        return False, None, str(e)

class AvailableIPsView(GenericAPIView):
    queryset = IPAddress.objects.all()

    def get(self, request):
        tag_names = request.query_params.get("tag", "unused").split(",")
        tags = Tag.objects.filter(name__in=tag_names)

        if tags.count() != len(tag_names):
            return Response({"error": "One or more tags not found.", "availableIPs": []})

        ips = (
            IPAddress.objects
            .filter(tags__in=tags)
            .annotate(tag_count=Count("tags"))
            .filter(tag_count=len(tags))
        )

        ip_list = [
            f"{ip.host}/{ip.mask_length}"
            for ip in ips
            if ip.host and ip.mask_length is not None
        ]
        return Response({"availableIPs": ip_list})

@csrf_exempt
def trigger_f5_job(request):
    """Handle F5 job trigger from chat-bot"""
    if request.method == "POST":
        try:
            payload = json.loads(request.body)
            print("Chat-bot F5 request:", payload)
            
            # Extract data from the wizard
            operation = "VIP Creation"  # Default operation from chat-bot
            details = payload  # The entire f5WizardData
            
            # CR number in ServiceNow
            cr_number = create_servicenow_cr(
                summary=f"F5 {operation} - Chat-bot Request",
                description=f"Automated F5 configuration request from chat-bot for VIP: {details.get('name', 'Unknown')}",
                details=details
            )
            
            # Set expiration time (24 hours from now)
            expires_at = timezone.now() + timedelta(hours=72)
            
            if request.user.is_authenticated:
                username = request.user.username
                user_email = request.user.email
            else:
                username = "anonymous"
                user_email = "net-bot@hcltech.com"
            
            # F5 approval record with chat-bot source
            f5_approval = F5Approval.objects.create(
                requester="ChatBot-" + username,  # Mark as chat-bot source
                requester_email=user_email,
                #approver_email=get_default_f5_approver_email(),
                operation=operation,
                cr_number=cr_number,
                job_parameters=details,
                expires_at=expires_at
                # status='pending' is the default
            )
            
            return JsonResponse({
                'success': True,
                'message': 'F5 configuration request submitted successfully',
                'cr_number': cr_number,
                'approval_id': str(f5_approval.id)
            }, status=200)
            
        except json.JSONDecodeError:
            return JsonResponse({
                'success': False,
                'error': 'Invalid JSON data'
            }, status=400)
        except Exception as e:
            print("Error in trigger_f5_job:", str(e))
            return JsonResponse({
                'success': False,
                'error': f'Failed to submit F5 request: {str(e)}'
            }, status=500)
    else:
        return JsonResponse({
            'success': False,
            'error': 'Method not allowed'
        }, status=405)

def create_servicenow_cr(summary, description, details):
    """Create a CR in ServiceNow and return the CR number"""
    try:

        SERVICENOW_USERNAME = os.getenv('SERVICENOW_USERNAME')
        SERVICENOW_PASSWORD = os.getenv('SERVICENOW_PASSWORD')
        url = f'https://hclpocm1.service-now.com'

        # ServiceNow CR creation payload
        cr_payload = {
            "short_description": summary,
            "description": description,
            "category": "Network",
            "subcategory": "Load Balancer",
            "type": "Normal",
            "state": "New",
            "impact": "Medium",
            "priority": "Medium",
            # "assignment_group": "Network Operations",
            # "u_automation_details": json.dumps(details)
        }
        
        # Make API call to ServiceNow (adjust URL and auth as needed)
        response = requests.post(
            "https://hclpocm1.service-now.com/api/now/table/change_request",
            json=cr_payload,
            auth=(SERVICENOW_USERNAME, SERVICENOW_PASSWORD),
            headers={"Content-Type": "application/json"}
        )
        
        if response.status_code == 201:
            cr_data = response.json()
            return cr_data.get('result', {}).get('number', 'CR-UNKNOWN')
        else:
            print(f"ServiceNow CR creation failed: {response.text}")
            # Generate a fallback CR number
            import uuid
            return f"CHAT-CR-{str(uuid.uuid4())[:8].upper()}"
            
    except Exception as e:
        print(f"Error creating ServiceNow CR: {str(e)}")
        # Generate a fallback CR number
        import uuid
        return f"CHAT-CR-{str(uuid.uuid4())[:8].upper()}"

def site_onboarding_preview(request):
    """Preview view with corrected field name mapping"""
    if request.method == 'POST':
        post_data_from_previous_page = form_data = request.POST
        
        
        # Enhanced debug - show all form keys to verify field names
        print("=== ALL FORM KEYS ===")
        all_keys = list(form_data.keys())
        router_keys = [k for k in all_keys if k.startswith('router_')]
        switch_keys = [k for k in all_keys if k.startswith('switch_')]
        
        print(f"Router keys: {router_keys}")
        print(f"Switch keys: {switch_keys}")
        print("=====================")
        
        # Helper functions
        def safe_int_conversion(value, default=0):
            try:
                return int(value) if value and value.strip() else default
            except (ValueError, TypeError):
                return default
        
        def get_object_display_name(model, uuid_value, fallback="Not selected"):
            try:
                if uuid_value and uuid_value.strip():
                    obj = model.objects.get(pk=uuid_value)
                    for attr in ['display', 'name', 'slug', 'model']:
                        if hasattr(obj, attr):
                            value = getattr(obj, attr)
                            if value:
                                if model == DeviceType and hasattr(obj, 'manufacturer'):
                                    return f"{obj.manufacturer.name} {value}"
                                return str(value)
                    return str(obj)
                return fallback
            except Exception as e:
                print(f"Error resolving {model.__name__} UUID {uuid_value}: {e}")
                return fallback
        
        def get_tag_names(tag_uuids):
            if not tag_uuids:
                return []
            tag_names = []
            for tag_uuid in tag_uuids:
                try:
                    if tag_uuid and tag_uuid.strip():
                        tag = Tag.objects.get(pk=tag_uuid)
                        tag_names.append(tag.name)
                except Exception as e:
                    if tag_uuid:
                        tag_names.append(str(tag_uuid))
            return tag_names
        
        def get_status_name(status_uuid):
            try:
                if status_uuid and status_uuid.strip():
                    status = Status.objects.get(pk=status_uuid)
                    return status.name
                return "Not selected"
            except Exception as e:
                return status_uuid or "Not selected"
        
        # Helper function to extract device data with debugging
        def extract_device_data(prefix, quantity):
            devices = []
            print(f"\n=== EXTRACTING {prefix.upper()} DATA ===")
            
            for i in range(quantity):
                # Try all possible field name variations
                possible_names = [
                    f'{prefix}_name_{i}',
                    f'{prefix}name_{i}',
                    f'{prefix}_device_name_{i}',
                ]
                
                possible_device_types = [
                    f'{prefix}_device_type_{i}',
                    f'{prefix}device_type_{i}',
                    f'{prefix}_devicetype_{i}',
                ]
                
                possible_racks = [
                    f'{prefix}_rack_{i}',
                    f'{prefix}rack_{i}',
                ]
                
                # Find the correct field names by checking what exists
                device_name = ''
                device_type_uuid = ''
                rack_uuid = ''
                
                for name_field in possible_names:
                    if form_data.get(name_field):
                        device_name = form_data.get(name_field, '').strip()
                        print(f"Found name in field: {name_field} = '{device_name}'")
                        break
                
                for dt_field in possible_device_types:
                    if form_data.get(dt_field):
                        device_type_uuid = form_data.get(dt_field, '').strip()
                        print(f"Found device_type in field: {dt_field} = '{device_type_uuid}'")
                        break
                
                for rack_field in possible_racks:
                    if form_data.get(rack_field):
                        rack_uuid = form_data.get(rack_field, '').strip()
                        print(f"Found rack in field: {rack_field} = '{rack_uuid}'")
                        break
                
                # Get management IP and serial number
                mgmt_ip = (
                    form_data.get(f'{prefix}_mgmt_ip_{i}', '').strip() or
                    form_data.get(f'{prefix}mgmt_ip_{i}', '').strip() or
                    form_data.get(f'{prefix}_management_ip_{i}', '').strip()
                )
                
                serial_number = (
                    form_data.get(f'{prefix}_serial_number_{i}', '').strip() or
                    form_data.get(f'{prefix}serial_number_{i}', '').strip() or
                    form_data.get(f'{prefix}_serial_{i}', '').strip()
                )
                
                # Get tags
                tag_uuids = (
                    form_data.getlist(f'{prefix}_tags_{i}') or
                    form_data.getlist(f'{prefix}tags_{i}') or
                    []
                )
                
                print(f"{prefix.capitalize()} {i}: name='{device_name}', type='{device_type_uuid}', rack='{rack_uuid}'")
                
                device = {
                    'name': device_name or f'{prefix.capitalize()} {i+1}',
                    'device_type': get_object_display_name(DeviceType, device_type_uuid),
                    'rack': get_object_display_name(Rack, rack_uuid),
                    'management_ip': mgmt_ip,
                    'serial_number': serial_number,
                    'tags': get_tag_names(tag_uuids)
                }
                
                devices.append(device)
            
            return devices
        
        # Site data processing
        site_tags = form_data.getlist('site_tags') or []
        site_name = (
            form_data.get('site_name', '').strip() or 
            form_data.get('name', '').strip() or 
            'Not provided'
        )
        
        site_data = {
            'name': site_name,
            'location': get_object_display_name(Location, form_data.get('location')),
            'status': get_status_name(form_data.get('status')),
            'tags': get_tag_names(site_tags),
            'digital_twin': form_data.get('digital_twin') == 'on'
        }
        
        # Process devices using the helper function
        router_quantity = safe_int_conversion(form_data.get('router_quantity'))
        switch_quantity = safe_int_conversion(form_data.get('switch_quantity'))
        
        router_devices = extract_device_data('router', router_quantity)
        switch_devices = extract_device_data('switch', switch_quantity)
        
        # Process prefixes and tools (unchanged)
        prefix_quantity = safe_int_conversion(form_data.get('prefix_quantity'))
        prefix_masks = []
        
        for i in range(prefix_quantity):
            prefix_uuid = form_data.get(f'prefix_{i}', '').strip()
            vlan_uuid = form_data.get(f'vlan_{i}', '').strip()
            tag_uuids = form_data.getlist(f'prefix_tags_{i}') or []
            
            prefix_name = 'Not selected'
            if prefix_uuid:
                try:
                    prefix_obj = Prefix.objects.get(pk=prefix_uuid)
                    prefix_name = f"{prefix_obj.network}/{prefix_obj.prefix_length}"
                except Exception:
                    prefix_name = prefix_uuid
            
            vlan_name = 'Not selected'
            if vlan_uuid:
                try:
                    vlan_obj = VLAN.objects.get(pk=vlan_uuid)
                    vlan_name = f"{vlan_obj.name} (VLAN {vlan_obj.vid})"
                except Exception:
                    vlan_name = vlan_uuid
            
            prefix_masks.append({
                'prefix': prefix_name,
                'vlan': vlan_name,
                'vlan_name': form_data.get(f'vlan_name_{i}', '').strip(),
                'vlan_type': form_data.get(f'vlan_type_{i}', '').strip(),
                'gateway_ip': form_data.get(f'gw_ip_{i}', '').strip(),
                'tags': get_tag_names(tag_uuids)
            })
        
        # Process tools
        tool_quantity = safe_int_conversion(form_data.get('tool_quantity'))
        tools = []
        
        for i in range(tool_quantity):
            tag_uuids = form_data.getlist(f'tool_tags_{i}') or []
            
            tools.append({
                'name': form_data.get(f'tool_name_{i}', '').strip(),
                'ip': form_data.get(f'tool_ip_{i}', '').strip(),
                'status': form_data.get(f'tool_status_{i}', '').strip(),
                'tags': get_tag_names(tag_uuids)
            })

        # NEW: Generate router configurations
        router_configs = generate_router_configurations(
            router_devices, prefix_masks, site_data
        )
        print("Here is the router config",router_configs)
        # NEW: Generate switch configurations  
        switch_configs = generate_switch_configurations(
            switch_devices, prefix_masks, site_data
        )
        print("Here is the switch config",switch_configs)
        context = {
            'form_data': json.dumps(post_data_from_previous_page),
            'site_data': site_data,
            'router_devices': router_devices,
            'switch_devices': switch_devices,
            'prefix_masks': prefix_masks,
            'tools': tools,
            'router_configs': router_configs,  # NEW
            'switch_configs': switch_configs,  # NEW
            'onboarding_data_json': json.dumps({
                'site_data': site_data,
                'router_devices': router_devices,
                'switch_devices': switch_devices,
                'prefix_masks': prefix_masks,
                'tools': tools
            })
        }
        
        return render(request, 'naas/site_onboarding_preview.html', context)
    
    return redirect('plugins:naas:site-onboarding')

def generate_router_configurations(router_devices, prefix_masks, site_data):
    """Generate router configurations using proper Jinja2"""
    configurations = []

    for i, device in enumerate(router_devices):
        if not device['name']:
            continue

        # Determine routing protocol
        routing_protocol = determine_routing_protocol(device['name'])

        # Convert prefix_masks to VLANs
        vlans = convert_prefixes_to_vlans(prefix_masks)

        # Generate router interfaces for topology
        router_interfaces = generate_router_interfaces(i, vlans)

        # Prepare template context
        config_context = {
            'device': device,
            'site': site_data,
            'current_date': timezone.now().strftime('%Y-%m-%d %H:%M:%S'),
            'routing_protocol': routing_protocol,
            'router_interfaces': router_interfaces,
            'vlans': vlans,
            'switch_count': 2,  # Based on your topology
            'inter_vlan_routing': True,
            'static_routes': get_static_routes(routing_protocol),
            'ospf_networks': get_ospf_networks(routing_protocol, device.get('management_ip')),
            'bgp_asn': get_bgp_asn(site_data),
            'bgp_neighbors': get_bgp_neighbors(routing_protocol),
            'dhcp_pools': generate_dhcp_pools(vlans),
            'ntp_servers': ['10.0.0.1', '10.0.0.2'],
            'snmp_community': 'nautobot_readonly',
            'snmp_contact': 'network-admin@company.com',
            'snmp_location': f"{site_data['name']} - {device.get('rack', 'Unknown')}",
            'syslog_server': '10.0.0.100'
        }

        # Generate configuration using Jinja2
        try:
            # Use string template directly to avoid file loading issues
            template_string = get_router_template_string()

            # Create Jinja2 environment
            env = Environment(loader=BaseLoader())
            template = env.from_string(template_string)

            # Render configuration
            configuration = template.render(config_context)

            configurations.append({
                'device': device,
                'routing_protocol': routing_protocol,
                'router_interfaces': router_interfaces,
                'vlans': vlans,
                'configuration': configuration,
                'topology_role': 'hub'
            })

        except Exception as e:
            logger.error(f"Error generating router config for {device['name']}: {e}")
            print(f"Template rendering error: {e}")
            print(f"Config context keys: {list(config_context.keys())}")
            configurations.append({
                'device': device,
                'error': f"Configuration generation failed: {e}"
            })

    return configurations


def generate_switch_configurations(switch_devices, prefix_masks, site_data):
    """Generate switch configurations using proper Jinja2"""
    configurations = []

    for i, device in enumerate(switch_devices):
        if not device['name']:
            continue

        vlans = convert_prefixes_to_vlans(prefix_masks)
        uplink_config = generate_switch_uplink_config(i)
        access_interfaces = generate_topology_access_interfaces(i, vlans, 24)

        config_context = {
            'device': device,
            'site': site_data,
            'current_date': timezone.now().strftime('%Y-%m-%d %H:%M:%S'),
            'mgmt_vlan': vlans[0]['vid'] if vlans else 1,
            'mgmt_subnet_mask': '255.255.255.0',
            'default_gateway': calculate_gateway(device.get('management_ip', '192.168.1.1')),
            'vlans': vlans,
            'uplink_config': uplink_config,
            'trunk_vlans': [str(vlan['vid']) for vlan in vlans],
            'native_vlan': 1,
            'access_interfaces': access_interfaces,
            'stp_mode': 'rapid-pvst',
            'stp_priority': calculate_stp_priority(i),
            'switch_number': i + 1,
            'router_connection': f'Router Interface 1/{i + 1}',
            'qos_enabled': True,
            'poe_enabled': True,
            'poe_interfaces': generate_poe_interfaces(12),
            'snmp_community': 'nautobot_readonly',
            'snmp_contact': 'network-admin@company.com',
            'snmp_location': f"{site_data['name']} - {device.get('rack', 'Unknown')}",
            'ntp_servers': ['10.0.0.1', '10.0.0.2'],
            'syslog_server': '10.0.0.100'
        }

        try:
            template_string = get_switch_template_string()
            env = Environment(loader=BaseLoader())
            template = env.from_string(template_string)
            configuration = template.render(config_context)

            configurations.append({
                'device': device,
                'vlans': vlans,
                'uplink_config': uplink_config,
                'access_interfaces': len(access_interfaces),
                'configuration': configuration,
                'topology_role': 'spoke',
                'router_connection': uplink_config['router_interface']
            })

        except Exception as e:
            logger.error(f"Error generating switch config for {device['name']}: {e}")
            print(f"Template rendering error: {e}")
            print(f"Config context keys: {list(config_context.keys())}")
            configurations.append({
                'device': device,
                'error': f"Configuration generation failed: {e}"
            })

    return configurations

def get_router_template_string():
    """Router template with proper Jinja2 syntax"""
    return """
!
! {{ device.name }} Configuration - Hub Router
! Generated by Nautobot Site Onboarding Plugin  
! Date: {{ current_date }}
! Topology: Hub-and-Spoke with {{ switch_count }} switches
!

hostname {{ device.name }}

! Basic configuration
enable secret cisco
service password-encryption
no ip domain-lookup
ip domain-name {{ site.name|lower }}.local

! Management interface
interface Loopback0
ip address {{ device.management_ip }} 255.255.255.255
description Management Loopback

! Inter-VLAN routing enabled
ip routing

! Switch connection interfaces (Hub-and-Spoke)
{% for interface in router_interfaces %}
{% if interface.type == "trunk" %}
interface {{ interface.name }}
description {{ interface.description }}
switchport mode trunk
switchport trunk allowed vlan {{ interface.allowed_vlans|join(',') }}
switchport trunk native vlan {{ interface.native_vlan }}
no shutdown
{% endif %}
{% endfor %}

! External uplink configuration
{% for interface in router_interfaces %}
{% if interface.type == "routed" %}
interface {{ interface.name }}
description {{ interface.description }}
ip address {{ interface.ip_address }} {{ interface.subnet_mask }}
no shutdown
{% endif %}
{% endfor %}

! VLAN and SVI Configuration (Inter-VLAN Routing)
{% for vlan in vlans %}
vlan {{ vlan.vid }}
name {{ vlan.name }}

interface Vlan{{ vlan.vid }}
description Gateway for {{ vlan.name }}
{% if vlan.ip_address %}
ip address {{ vlan.ip_address }} {{ vlan.subnet_mask }}
{% endif %}
no shutdown
{% endfor %}

{% if routing_protocol == "static" %}
! Static routing configuration
{% for route in static_routes %}
ip route {{ route.network }} {{ route.mask }} {{ route.next_hop }}
{% endfor %}
{% for interface in router_interfaces %}
{% if interface.type == "routed" %}
ip route 0.0.0.0 0.0.0.0 {{ interface.next_hop }}
{% endif %}
{% endfor %}

{% elif routing_protocol == "ospf" %}
! OSPF Configuration
router ospf 1
router-id {{ device.management_ip }}
{% for network in ospf_networks %}
network {{ network.network }} {{ network.wildcard }} area {{ network.area }}
{% endfor %}
{% for vlan in vlans %}
network {{ vlan.ip_address }} 0.0.0.255 area 0
{% endfor %}

{% elif routing_protocol == "bgp" %}
! BGP Configuration
router bgp {{ bgp_asn }}
bgp router-id {{ device.management_ip }}
bgp log-neighbor-changes
{% for neighbor in bgp_neighbors %}
neighbor {{ neighbor.ip }} remote-as {{ neighbor.asn }}
neighbor {{ neighbor.ip }} description {{ neighbor.description }}
{% endfor %}
{% for vlan in vlans %}
network {{ vlan.ip_address }} mask {{ vlan.subnet_mask }}
{% endfor %}
{% endif %}

! DHCP Configuration for all VLANs
{% for dhcp_pool in dhcp_pools %}
ip dhcp pool {{ dhcp_pool.name }}
network {{ dhcp_pool.network }} {{ dhcp_pool.mask }}
default-router {{ dhcp_pool.gateway }}
dns-server {{ dhcp_pool.dns_servers|join(' ') }}
domain-name {{ dhcp_pool.domain_name }}
lease {{ dhcp_pool.lease_days }}
{% endfor %}

! Spanning Tree Configuration (Root Bridge)
spanning-tree mode rapid-pvst
{% for vlan in vlans %}
spanning-tree vlan {{ vlan.vid }} priority 0
{% endfor %}

! Console and VTY configuration
line con 0
password cisco
login
logging synchronous

line vty 0 4
password cisco
login
transport input ssh telnet

! SSH Configuration
ip ssh version 2
crypto key generate rsa modulus 1024
username admin privilege 15 secret cisco

! NTP Configuration
{% for ntp_server in ntp_servers %}
ntp server {{ ntp_server }}
{% endfor %}

! SNMP Configuration
snmp-server community {{ snmp_community }} RO
snmp-server contact {{ snmp_contact }}
snmp-server location {{ snmp_location }}

! Logging
logging {{ syslog_server }}
logging trap informational

end
write memory
"""

def get_switch_template_string():
    """Switch template with proper Jinja2 syntax"""
    return """
!
! {{ device.name }} Configuration - Spoke Switch {{ switch_number }}
! Generated by Nautobot Site Onboarding Plugin
! Date: {{ current_date }}
! Topology: Connected to {{ router_connection }}
!

hostname {{ device.name }}

! Basic configuration
enable secret cisco
service password-encryption
no ip domain-lookup
ip domain-name {{ site.name|lower }}.local

! Management VLAN and IP
vlan {{ mgmt_vlan }}
name Management

interface vlan{{ mgmt_vlan }}
ip address {{ device.management_ip }} {{ mgmt_subnet_mask }}
no shutdown

ip default-gateway {{ default_gateway }}

! VLAN Configuration
{% for vlan in vlans %}
vlan {{ vlan.vid }}
name {{ vlan.name }}
{% endfor %}

! Spanning Tree Configuration (Spoke Switch)
spanning-tree mode {{ stp_mode }}
spanning-tree priority {{ stp_priority }}
{% for vlan in vlans %}
spanning-tree vlan {{ vlan.vid }} priority {{ stp_priority }}
{% endfor %}

! Uplink to Router ({{ router_connection }})
interface {{ uplink_config.interface }}
description {{ uplink_config.description }}
switchport mode trunk
switchport trunk allowed vlan {{ trunk_vlans|join(',') }}
switchport trunk native vlan {{ native_vlan }}
no shutdown

! Access port configuration
{% for interface in access_interfaces %}
interface {{ interface.name }}
description {{ interface.description }}
switchport mode access
switchport access vlan {{ interface.vlan }}
spanning-tree portfast
{% if interface.port_security %}
switchport port-security
switchport port-security maximum 2
switchport port-security violation shutdown
switchport port-security mac-address sticky
{% endif %}
{% if interface.storm_control %}
storm-control broadcast level 50.00
storm-control multicast level 50.00
{% endif %}
no shutdown
{% endfor %}

{% if qos_enabled %}
! Quality of Service (QoS) Configuration
mls qos
{% endif %}

{% if poe_enabled %}
! Power over Ethernet (PoE) Configuration  
{% for interface in poe_interfaces %}
interface {{ interface.name }}
power inline {{ interface.poe_priority }}
{% endfor %}
{% endif %}

! Console and VTY configuration
line con 0
password cisco
login
logging synchronous

line vty 0 15
password cisco
login
transport input ssh telnet

! SSH Configuration
ip ssh version 2
crypto key generate rsa modulus 1024
username admin privilege 15 secret cisco

! SNMP Configuration
snmp-server community {{ snmp_community }} RO
snmp-server contact {{ snmp_contact }}
snmp-server location {{ snmp_location }}

! NTP Configuration
{% for ntp_server in ntp_servers %}
ntp server {{ ntp_server }}
{% endfor %}

! Logging
logging {{ syslog_server }}
logging trap informational

end
write memory
"""

def convert_prefixes_to_vlans(prefix_masks):
    """Convert prefix mask data to VLAN configuration with error handling"""
    vlans = []

    if not prefix_masks:
        # Return default VLAN if no prefixes
        return [{'vid': 1, 'name': 'default', 'ip_address': None, 'subnet_mask': '255.255.255.0'}]

    for i, prefix in enumerate(prefix_masks):
        try:
            vlan_name = prefix.get('vlan_name', f'VLAN_{i+10}')
            if not vlan_name:
                vlan_name = f'VLAN_{i+10}'

            vlan_vid = int(prefix.get('vlan', 0)) if prefix.get('vlan') else (10 + i)
            gateway_ip = prefix.get('gateway_ip', f'192.168.{i+10}.1')

            vlans.append({
                'vid': vlan_vid,
                'name': vlan_name,
                'description': f"{prefix.get('vlan_type', 'Data')} VLAN",
                'ip_address': gateway_ip,
                'subnet_mask': '255.255.255.0'
            })
        except Exception as e:
            logger.error(f"Error processing prefix {i}: {e}")
            continue

    # Ensure at least one VLAN exists
    if not vlans:
        vlans = [{'vid': 1, 'name': 'default', 'ip_address': None, 'subnet_mask': '255.255.255.0'}]

    return vlans


def generate_router_interfaces(router_index, vlans):
    """Generate router interface configuration for hub-and-spoke topology"""
    interfaces = []

    # Interface 1/1 - Connection to Switch 1
    interfaces.append({
        'name': 'GigabitEthernet1/1',
        'description': 'Connection to Access-Switch-01',
        'type': 'trunk',
        'allowed_vlans': [str(vlan['vid']) for vlan in vlans],
        'native_vlan': 1,
        'switch_connection': 'Switch-01'
    })

    # Interface 1/2 - Connection to Switch 2
    interfaces.append({
        'name': 'GigabitEthernet1/2',
        'description': 'Connection to Access-Switch-02', 
        'type': 'trunk',
        'allowed_vlans': [str(vlan['vid']) for vlan in vlans],
        'native_vlan': 1,
        'switch_connection': 'Switch-02'
    })

    # External uplink interface
    interfaces.append({
        'name': 'GigabitEthernet0/0',
        'description': 'Uplink to External Network',
        'type': 'routed',
        'ip_address': f'10.0.{router_index + 1}.1',
        'subnet_mask': '255.255.255.252',
        'next_hop': f'10.0.{router_index + 1}.2'
    })

    return interfaces


def generate_switch_uplink_config(switch_index):
    """Generate uplink configuration for each switch to router"""
    return {
        'interface': 'GigabitEthernet0/25',
        'description': f'Uplink to Router Interface 1/{switch_index + 1}',
        'router_interface': f'GigabitEthernet1/{switch_index + 1}',
        'type': 'trunk',
        'switch_number': switch_index + 1
    }


def generate_topology_access_interfaces(switch_index, vlans, port_count):
    """Generate access interfaces with proper error handling"""
    interfaces = []

    if not vlans:
        vlans = [{'vid': 1, 'name': 'default'}]

    vlan_index = 0
    for i in range(1, port_count):  # Skip port 25 (uplink)
        if i == 25:
            continue

        current_vlan = vlans[vlan_index % len(vlans)]
        vlan_index += 1

        interfaces.append({
            'name': f'FastEthernet0/{i}',
            'vlan': current_vlan['vid'],
            'description': f'Access Port - VLAN {current_vlan["vid"]} ({current_vlan["name"]})',
            'port_security': True,
            'storm_control': True,
            'portfast': True
        })

    return interfaces


# Fix other helper functions with proper error handling
def calculate_gateway(mgmt_ip):
    """Calculate gateway IP with error handling"""
    if not mgmt_ip:
        return "192.168.1.1"

    try:
        ip = ipaddress.IPv4Address(mgmt_ip)
        network = ipaddress.IPv4Network(f"{ip}/24", strict=False)
        return str(network.network_address + 1)
    except Exception as e:
        logger.error(f"Error calculating gateway for {mgmt_ip}: {e}")
        return "192.168.1.1"


def calculate_stp_priority(switch_index):
    """Calculate STP priority for each switch"""
    return 8192 + (switch_index * 4096)


def generate_dhcp_pools(vlans):
    """Generate DHCP pools with error handling"""
    pools = []

    for vlan in vlans:
        try:
            if vlan.get('ip_address'):
                network_obj = ipaddress.IPv4Network(f"{vlan['ip_address']}/24", strict=False)
                pools.append({
                    'name': f"DHCP_{vlan['name'].replace(' ', '_')}",
                    'network': str(network_obj.network_address),
                    'mask': '255.255.255.0',
                    'gateway': vlan['ip_address'],
                    'dns_servers': ['8.8.8.8', '8.8.4.4'],
                    'domain_name': 'local',
                    'lease_days': 7
                })
        except Exception as e:
            logger.error(f"Error generating DHCP pool for VLAN {vlan.get('name', 'unknown')}: {e}")
            continue

    return pools


def generate_poe_interfaces(poe_port_count):
    """Generate PoE interface configurations"""
    interfaces = []
    for i in range(1, poe_port_count + 1):
        interfaces.append({
            'name': f'FastEthernet0/{i}',
            'poe_priority': 'auto'
        })
    return interfaces


# Keep your existing helper functions
def determine_routing_protocol(device_name):
    """Determine routing protocol based on device name"""
    if not device_name:
        return 'static'

    name_lower = device_name.lower()
    if 'core' in name_lower or 'border' in name_lower:
        return 'bgp'
    elif 'distribution' in name_lower or 'dist' in name_lower:
        return 'ospf'
    else:
        return 'static'


def get_static_routes(routing_protocol):
    if routing_protocol == 'static':
        return [{'network': '192.168.0.0', 'mask': '255.255.0.0', 'next_hop': '10.0.0.1'}]
    return []


def get_ospf_networks(routing_protocol, router_id):
    if routing_protocol == 'ospf':
        return [
            {'network': '10.0.0.0', 'wildcard': '0.255.255.255', 'area': '0'},
            {'network': '192.168.0.0', 'wildcard': '0.0.255.255', 'area': '0'}
        ]
    return []


def get_bgp_asn(site_data):
    return 65001


def get_bgp_neighbors(routing_protocol):
    if routing_protocol == 'bgp':
        return [{'ip': '10.0.0.2', 'asn': 65002, 'description': 'ISP Peer'}]
    return []

def generate_access_interfaces(port_count, vlans):
    """Generate access interface configurations"""
    interfaces = []
    vlan_index = 0

    for i in range(1, port_count + 1):
        if vlans:
            vlan = vlans[vlan_index % len(vlans)]
            vlan_index += 1
        else:
            vlan = {'vid': 1}

        interfaces.append({
            'name': f'FastEthernet0/{i}',
            'vlan': vlan['vid'],
            'description': f'Access Port - VLAN {vlan["vid"]}',
            'port_security': True,
            'storm_control': True
        })

    return interfaces

def generate_server_interfaces(vlans):
    """Generate server interface configurations"""
    if not vlans:
        return []

    return [{
        'name': 'GigabitEthernet0/24',
        'server_name': 'Server-1',
        'allowed_vlans': [str(vlan['vid']) for vlan in vlans],
        'native_vlan': vlans[0]['vid'],
        'bpduguard': True
    }]


# Force Paramiko to allow weak/legacy algorithms for your devices
paramiko.transport._preferred_kex = (
    'diffie-hellman-group14-sha1',  # This matches your manual command
    'diffie-hellman-group-exchange-sha1',
    'diffie-hellman-group1-sha1',
)
paramiko.transport._preferred_keys = (
    'ssh-rsa',
)

# Also set these for extra compatibility
paramiko.transport._preferred_ciphers = (
    'aes128-ctr', 'aes192-ctr', 'aes256-ctr',
    'aes128-cbc', 'aes192-cbc', 'aes256-cbc',
)
paramiko.transport._preferred_macs = (
    'hmac-sha2-256', 'hmac-sha2-512', 'hmac-sha1', 'hmac-sha1-96',
)

def site_onboarding_provisioning(request):
    """Handle the provisioning of configurations to devices - UPDATED VERSION"""
    if request.method == 'POST':
        try:
            print("=== PROVISIONING DEBUG ===")
            print("POST data keys:", list(request.POST.keys()))
            
            # Get configurations from session
            router_configs = request.session.get('router_configs', [])
            switch_configs = request.session.get('switch_configs', [])
            site_data = request.session.get('site_data', {'name': 'Unknown Site'})
            
            print(f"From session - Router configs: {len(router_configs)}, Switch configs: {len(switch_configs)}")
            
            # If no configs in session, create fallback test configurations
            if not router_configs and not switch_configs:
                print("No configs in session, creating fallback test configurations...")
                router_configs, switch_configs = create_fallback_configurations()
            
            # Device mapping - FIXED: Remove device_name from connection params
            device_mapping = {
                'router': [
                    {
                        "device_type": "cisco_ios",
                        "host": "172.21.17.240",  # Changed from 'ip' to 'host'
                        "username": "admin",
                        "password": "Passw0rd@123",
                        "global_delay_factor": 3,  # Increased for legacy devices
                        "timeout": 20,  # Added timeout
                        # device_name is for our tracking only, not for ConnectHandler
                        "_device_name": "Router-01"  
                    }
                ],
                'switch': [
                    {
                        "device_type": "cisco_ios", 
                        "host": "172.21.17.241",  # Changed from 'ip' to 'host'
                        "username": "admin",
                        "password": "Passw0rd@123",
                        "global_delay_factor": 3,
                        "timeout": 20,
                        "_device_name": "Switch-01"  # Prefixed with _ to avoid confusion
                    },
                    {
                        "device_type": "cisco_ios",
                        "host": "172.21.17.242",  # Changed from 'ip' to 'host'
                        "username": "admin",
                        "password": "Passw0rd@123",
                        "global_delay_factor": 3,
                        "timeout": 20,
                        "_device_name": "Switch-02"
                    }
                ]
            }
            
            provisioning_results = []
            
            # Process router configurations
            print(f"Processing {len(router_configs)} router configurations...")
            for i, router_config in enumerate(router_configs):
                if i < len(device_mapping['router']):
                    device_info = device_mapping['router'][i].copy()
                    
                    # Add the device name for our tracking
                    device_info['device_name'] = device_info.pop('_device_name', f'Router-{i+1}')
                    
                    # Get configuration text
                    config_text = router_config.get('configuration', '')
                    if not config_text and 'device' in router_config:
                        # Generate a basic config if missing
                        config_text = f"""
hostname {router_config['device'].get('name', 'Router-01')}
interface loopback0
 ip address {router_config['device'].get('management_ip', '192.168.1.1')} 255.255.255.255
 description Management Interface
"""
                    
                    if config_text:
                        result = provision_device_config(
                            device_info=device_info,
                            configuration=config_text,
                            device_role='router',
                            config_data=router_config
                        )
                        provisioning_results.append(result)
            
            # Process switch configurations  
            print(f"Processing {len(switch_configs)} switch configurations...")
            for i, switch_config in enumerate(switch_configs):
                if i < len(device_mapping['switch']):
                    device_info = device_mapping['switch'][i].copy()
                    
                    # Add the device name for our tracking
                    device_info['device_name'] = device_info.pop('_device_name', f'Switch-{i+1}')
                    
                    # Get configuration text
                    config_text = switch_config.get('configuration', '')
                    if not config_text and 'device' in switch_config:
                        # Generate a basic config if missing
                        config_text = f"""
hostname {switch_config['device'].get('name', f'Switch-{i+1:02d}')}
interface vlan1
 ip address {switch_config['device'].get('management_ip', f'192.168.1.{50+i}')} 255.255.255.0
 no shutdown
ip default-gateway 192.168.1.1
"""
                    
                    if config_text:
                        result = provision_device_config(
                            device_info=device_info,
                            configuration=config_text,
                            device_role='switch', 
                            config_data=switch_config
                        )
                        provisioning_results.append(result)
            
            print(f"Total provisioning results: {len(provisioning_results)}")
            
            # Calculate statistics
            successful_devices = len([r for r in provisioning_results if r['status'] == 'success'])
            failed_devices = len([r for r in provisioning_results if r['status'] == 'failed'])
            
            # Clear session data after use
            for key in ['router_configs', 'switch_configs', 'site_data', 'router_devices', 'switch_devices', 'prefix_masks']:
                request.session.pop(key, None)
            
            # Return results
            context = {
                'provisioning_results': provisioning_results,
                'site_data': site_data,
                'total_devices': len(provisioning_results),
                'successful_devices': successful_devices,
                'failed_devices': failed_devices
            }
            
            return render(request, 'naas/provisioning_results.html', context)
            
        except Exception as e:
            import traceback
            print(f"Provisioning error: {e}")
            print(f"Traceback: {traceback.format_exc()}")
            
            return JsonResponse({
                'status': 'error',
                'message': f'Provisioning failed: {str(e)}',
                'debug_info': str(traceback.format_exc())
            }, status=500)
    
    return JsonResponse({'status': 'error', 'message': 'Invalid request method'}, status=405)


def parse_form_data_from_string(form_data_string):
    """Parse form data string back into structured data"""
    try:
        # This is a simplified version - you may need to adjust based on your actual data format
        data = json.loads(form_data_string) if form_data_string.startswith('{') else {}
        
        site_data = data.get('site_data', {'name': 'Test Site'})
        router_devices = data.get('router_devices', [])
        switch_devices = data.get('switch_devices', [])
        prefix_masks = data.get('prefix_masks', [])
        
        return site_data, router_devices, switch_devices, prefix_masks
        
    except Exception as e:
        print(f"Error parsing form data string: {e}")
        return {'name': 'Test Site'}, [], [], []


def provision_device_config(device_info, configuration, device_role, config_data):
    """Provision configuration using known working credentials"""
    device_name = device_info.get('device_name', device_info.get('host', 'Unknown'))
    
    result = {
        'device_name': device_name,
        'device_ip': device_info.get('host', 'Unknown'),
        'device_role': device_role,
        'status': 'unknown',
        'message': '',
        'backup_status': 'not_attempted',
        'config_commands': 0,
        'execution_time': 0,
        'output': ''
    }
    
    try:
        import time
        start_time = time.time()
        
        commands = parse_configuration_to_commands(configuration)
        result['config_commands'] = len(commands)
        
        if not commands:
            result['status'] = 'failed'
            result['message'] = 'No valid commands found in configuration'
            return result
        
        # Use the EXACT credentials that work manually
        connection_params = {
            'device_type': 'cisco_ios',
            'host': device_info.get('host'),
            'username': 'admin',
            'password': 'Passw0rd@123',  # Fixed: zero instead of 'o'
            'global_delay_factor': 4,
            'timeout': 30,
        }
        
        print(f"Connecting to {device_name} ({connection_params['host']}) with admin/Passw0rd@123...")
        
        # Connect using known working credentials
        conn = ConnectHandler(**connection_params)
        prompt = conn.find_prompt()
        print(f"Connected successfully! Prompt: {prompt}")
        
        # Backup configuration
        try:
            running_config = conn.send_command('show running-config', delay_factor=4)
            backup_filename = save_backup_config(connection_params['host'], running_config)
            result['backup_status'] = 'success'
        except Exception as backup_error:
            result['backup_status'] = 'failed'
            print(f"Backup failed: {backup_error}")
        
        # Enter enable mode if needed
        if not prompt.endswith('#'):
            try:
                conn.enable()
            except:
                pass  # Continue even if enable fails
        
        # Send configuration commands
        batch_size = 5
        output_log = []
        successful_commands = 0
        
        for i in range(0, len(commands), batch_size):
            batch = commands[i:i + batch_size]
            try:
                batch_output = conn.send_config_set(batch, delay_factor=4)
                output_log.append(f"Batch {i//batch_size + 1}: SUCCESS\n{batch_output}")
                successful_commands += len(batch)
                time.sleep(2)  # Pause between batches
            except Exception as batch_error:
                output_log.append(f"Batch {i//batch_size + 1}: FAILED - {str(batch_error)}")
                continue
        
        # Save configuration
        try:
            save_output = conn.send_command('write memory', delay_factor=5)
            output_log.append(f"Save: {save_output}")
        except Exception as save_error:
            output_log.append(f"Save failed: {save_error}")
        
        conn.disconnect()
        
        if successful_commands > 0:
            result['status'] = 'success'
            result['message'] = f'Successfully applied {successful_commands}/{len(commands)} commands'
        else:
            result['status'] = 'failed'
            result['message'] = 'Failed to apply any commands'
        
        result['output'] = '\n'.join(output_log)
        result['execution_time'] = round(time.time() - start_time, 2)
        
    except Exception as e:
        result['status'] = 'failed'
        result['message'] = f'Failed: {str(e)}'
        result['output'] = str(e)
    
    return result

def parse_configuration_to_commands(configuration):
    """Parse full configuration text into individual commands"""
    commands = []
    
    if not configuration:
        return commands
    
    lines = configuration.split('\n')
    skip_commands = [
        '!',  # Comments
        'end',  # End command
        'write memory',  # Save command - we handle this separately
        'exit',  # Exit commands
        ''  # Empty lines
    ]
    
    dangerous_commands = [
        'reload',
        'erase startup-config',
        'format',
        'delete',
        'no running-config'
    ]
    
    for line in lines:
        line = line.strip()
        
        # Skip empty lines and comments
        if not line or line.startswith('!'):
            continue
            
        # Skip specific commands
        if line in skip_commands:
            continue
            
        # Check for dangerous commands
        line_lower = line.lower()
        if any(dangerous in line_lower for dangerous in dangerous_commands):
            print(f"Skipping dangerous command: {line}")
            continue
        
        # Clean up the command
        cleaned_command = line
        
        # Handle special formatting
        if cleaned_command.startswith(' '):
            # Keep indentation for sub-commands
            pass
        
        commands.append(cleaned_command)
    
    return commands


def save_backup_config(device_ip, config_content):
    """Save device backup configuration"""
    try:
        import os
        from django.conf import settings
        
        # Create backups directory if it doesn't exist
        backup_dir = os.path.join(settings.BASE_DIR, 'device_backups')
        os.makedirs(backup_dir, exist_ok=True)
        
        # Generate backup filename with timestamp
        from datetime import datetime
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        backup_filename = f"backup_{device_ip}_{timestamp}.txt"
        backup_path = os.path.join(backup_dir, backup_filename)
        
        # Save backup file
        with open(backup_path, 'w') as f:
            f.write(config_content)
        
        print(f"Backup saved: {backup_path}")
        return backup_filename
        
    except Exception as e:
        print(f"Failed to save backup for {device_ip}: {e}")
        return None


def save_onboarding_to_database(onboarding_data, router_configs, switch_configs):
    """Save onboarding data to database (your existing logic)"""
    try:
        # Add your existing database save logic here
        # This is where you would create Site, Device, VLAN objects etc.
        
        print(f"Saving site onboarding to database: {onboarding_data.get('site_data', {}).get('name', 'Unknown')}")
        
        # Example of what you might save:
        # site = Site.objects.create(name=site_data['name'], ...)
        # for router_config in router_configs:
        #     Device.objects.create(name=router_config['device']['name'], ...)
        
    except Exception as e:
        print(f"Database save failed: {e}")
        # Don't raise exception - provisioning was successful even if DB save fails

def create_fallback_configurations():
    """Create test configurations when no data is available"""
    
    # Sample router configuration
    router_configs = [{
        'device': {
            'name': 'Router-01',
            'management_ip': '192.168.1.1',
            'device_type': 'Cisco ISR4331'
        },
        'configuration': '''
hostname Router-01
interface loopback0
 ip address 192.168.1.1 255.255.255.255
 description Management Interface
interface GigabitEthernet0/0
 description Uplink to External Network
 ip address 10.0.1.1 255.255.255.252
 no shutdown
interface GigabitEthernet1/1
 description Connection to Access-Switch-01
 switchport mode trunk
 switchport trunk allowed vlan 10,20,30
 no shutdown
interface GigabitEthernet1/2
 description Connection to Access-Switch-02
 switchport mode trunk
 switchport trunk allowed vlan 10,20,30
 no shutdown
vlan 10
 name Data_VLAN
vlan 20
 name Voice_VLAN
vlan 30
 name Guest_VLAN
interface Vlan10
 description Gateway for Data_VLAN
 ip address 192.168.10.1 255.255.255.0
 no shutdown
interface Vlan20
 description Gateway for Voice_VLAN
 ip address 192.168.20.1 255.255.255.0
 no shutdown
interface Vlan30
 description Gateway for Guest_VLAN
 ip address 192.168.30.1 255.255.255.0
 no shutdown
ip route 0.0.0.0 0.0.0.0 10.0.1.2
'''
    }]
    
    # Sample switch configurations
    switch_configs = [
        {
            'device': {
                'name': 'Switch-01',
                'management_ip': '192.168.1.51',
                'device_type': 'Cisco Catalyst 2960'
            },
            'configuration': '''
hostname Switch-01
interface vlan1
 ip address 192.168.1.51 255.255.255.0
 no shutdown
ip default-gateway 192.168.1.1
vlan 10
 name Data_VLAN
vlan 20
 name Voice_VLAN
vlan 30
 name Guest_VLAN
interface GigabitEthernet0/25
 description Uplink to Router Interface 1/1
 switchport mode trunk
 switchport trunk allowed vlan 10,20,30
 no shutdown
interface range FastEthernet0/1-24
 switchport mode access
 switchport access vlan 10
 spanning-tree portfast
 no shutdown
'''
        },
        {
            'device': {
                'name': 'Switch-02',
                'management_ip': '192.168.1.52',
                'device_type': 'Cisco Catalyst 2960'
            },
            'configuration': '''
hostname Switch-02
interface vlan1
 ip address 192.168.1.52 255.255.255.0
 no shutdown
ip default-gateway 192.168.1.1
vlan 10
 name Data_VLAN
vlan 20
 name Voice_VLAN
vlan 30
 name Guest_VLAN
interface GigabitEthernet0/25
 description Uplink to Router Interface 1/2
 switchport mode trunk
 switchport trunk allowed vlan 10,20,30
 no shutdown
interface range FastEthernet0/1-24
 switchport mode access
 switchport access vlan 20
 spanning-tree portfast
 no shutdown
'''
        }
    ]
    
    return router_configs, switch_configs