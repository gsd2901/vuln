from rest_framework.views import APIView
from rest_framework.permissions import IsAuthenticated, AllowAny
from rest_framework.response import Response
from rest_framework import status
import json
from naas.utils import fetch_devices, start_ios_upgrade, deploy_vlan_configs


class DevicesListAPIView(APIView):
    """
    API endpoint for Devices List.
    """

    permission_classes = [IsAuthenticated]  # or [AllowAny] if you want no auth

    def get(self, request, *args, **kwargs):
        """
        Get Devices list for IOS Upgrade.
        """
        params = request.GET
        return fetch_devices(params)

class IOSUpgradeAPIView(APIView):
    """
    API endpoint for IOS upgrade (POST trigger).
    """

    permission_classes = [IsAuthenticated]  # or [AllowAny] if you want no auth

    def post(self, request, *args, **kwargs):
        """
        Trigger IOS upgrade (same as UI form submission).
        """
        devices = request.data.get('devices', [])
        return start_ios_upgrade(request.user, devices, request.data)


class VLANConfigDeployAPIView(APIView):
    """
    API endpoint for deploying VLAN configurations.
    """
    permission_classes = [IsAuthenticated]  # or [AllowAny] if you want no auth

    def post(self, request, *args, **kwargs):
        """
        Deploy VLAN configurations to switches.
        Expected params:
        - configs: list of VLAN configs (dicts with switch_ip, vlan, admin_state, vlan_description, subnet, gateway_ip, mtu_size)
        - username: (optional) switch login username
        - password: (optional) switch login password
        """
        
        try:
            configs = request.data.get("configs", [])
            username = request.data.get("username", "hcl")
            password = request.data.get("password", "cisco")

            if not configs:
                return Response(
                    {"status": "error", "message": "No VLAN configs provided"},
                    status=status.HTTP_400_BAD_REQUEST,
                )

            result_data = deploy_vlan_configs(configs, username, password)
            return Response(result_data, status=status.HTTP_200_OK)

        except Exception as e:
            return Response(
                {"status": "error", "message": str(e)},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR,
            )
