from django.urls import path
from .views import DevicesListAPIView,IOSUpgradeAPIView, VLANConfigDeployAPIView

urlpatterns = [
    path("devices-list/", DevicesListAPIView.as_view(), name="devices-list"),
    path("ios-upgrade/", IOSUpgradeAPIView.as_view(), name="ios-upgrade"),
    path("vlan-config-deploy/", VLANConfigDeployAPIView.as_view(), name="vlan-config-deploy"),
]
