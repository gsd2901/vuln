import re

from netmiko import ConnectHandler, NetMikoTimeoutException, NetMikoAuthenticationException
from nautobot.extras.models import JobResult, Job
from nautobot.dcim.models import Device
from nautobot.dcim.models import Location, LocationType
from nautobot.extras.models import Status
from django.http import JsonResponse
import logging
import json

logger = logging.getLogger(__name__)

def check_upload_job_status(job_id):
    """
    Check if an upload job has completed successfully.
    
    Args:
        job_id (str): The ID of the job to check
        
    Returns:
        bool: True if the job completed successfully, False otherwise
    """
    from nautobot.extras.models import JobResult
    
    try:
        job_result = JobResult.objects.get(pk=job_id)
        return job_result.completed and job_result.status == 'completed'
    except JobResult.DoesNotExist:
        return False
    
class F5VIPSNOWDescriptionParser:
    """Parser for ServiceNow Change Request descriptions"""
    
    @staticmethod
    def parse_description(description):
        """
        Parse SNOW description and extract F5 configuration data
        """
        data = {}
        
        # Auto-detect operation type
        description_lower = description.lower()
        if 'vip creation' in description_lower:
            data['operation'] = 'create_vip'
        elif 'pool creation' in description_lower:
            data['operation'] = 'create_pool'
        elif 'vip validation' in description_lower:
            data['operation'] = 'vip_validation'
        elif any(term in description_lower for term in ['pool modif', 'modify pool', 'pool modification']):
            data['operation'] = 'modify_pool'
        
        # Parse VIP-specific fields
        patterns = {
            'name': r'VIP Name:\s*([^\n\r]+)',
            'description': r'Description:\s*([^\n\r]+)',
            'destination': r'Destination:\s*([^\n\r]+)',
            'pool': r'Pool:\s*([^\n\r]+)',
            'ipProtocol': r'Protocol:\s*([^\n\r]+)',
            'partition': r'Partition:\s*([^\n\r]+)',
            'source': r'Source:\s*([^\n\r]+)',
            'mask': r'Mask:\s*([^\n\r]+)',
            'snatpool': r'SNAT Pool:\s*([^\n\r]+)',
        }
        
        for field, pattern in patterns.items():
            match = re.search(pattern, description, re.IGNORECASE)
            if match:
                value = match.group(1).strip()
                if field == 'ipProtocol':
                    value = value.lower()
                data[field] = value
        
        # Parse profiles section
        profiles = F5VIPSNOWDescriptionParser.parse_profiles(description)
        if profiles:
            data['profiles'] = profiles
            
        # Parse pool-specific data if operation is pool-related
        if data.get('operation') in ['create_pool', 'modify_pool']:
            data.update(F5VIPSNOWDescriptionParser.parse_pool_data(description))
            
        return data
    
    @staticmethod
    def parse_profiles(description):
        """Parse profiles section from description"""
        profiles = {}
        
        # Look for profiles section
        profiles_section_match = re.search(r'Profiles Required:(.*?)(?=\n[A-Z]|\n\n|$)', description, re.IGNORECASE | re.DOTALL)
        # if profiles_section_match:
        #     profiles_text = profiles_section_match.group(1)
            
            # # Parse individual profiles
            # if 'clientssl' in profiles_text.lower():
            #     profiles['clientssl'] = True
            #     profiles['ssl_client'] = '/Common/clientssl'
            
            # if 'serverssl' in profiles_text.lower():
            #     profiles['serverssl'] = True
            #     profiles['ssl_server'] = '/Common/serverssl'
            
            # if 'http' in profiles_text.lower():
            #     profiles['http'] = True
            #     profiles['http_client'] = '/Common/http'
            #     profiles['http_server'] = '/Common/http'
            
            # Default TCP profiles
        profiles['name'] = 'f5-tcp-progressive'
        profiles['context'] = 'clientside'
            
            # Check for specific TCP profiles mentioned
            # tcp_profile_match = re.search(r'f5-tcp-([^\s\)]+)', profiles_text, re.IGNORECASE)
            # if tcp_profile_match:
            #     profiles['tcp_client'] = f'/Common/f5-tcp-{tcp_profile_match.group(1)}'
        
        return profiles
    
    @staticmethod
    def parse_pool_data(description):
        """Parse pool-specific data from description"""
        pool_data = {}
        
        # Parse pool members
        members_match = re.search(r'Pool Members?:\s*([^\n]*(?:\n(?!\s*-)[^\n]*)*)', description, re.IGNORECASE)
        if members_match:
            members_text = members_match.group(1).strip()
            pool_data['pool_members'] = members_text
        
        # Parse load balancing mode
        lb_mode_match = re.search(r'Load Balancing(?:\s+Mode)?:\s*([^\n\r]+)', description, re.IGNORECASE)
        if lb_mode_match:
            pool_data['load_balancing_mode'] = lb_mode_match.group(1).strip().lower()
        
        return pool_data
def fetch_devices(params):
    """
    Search and filter devices based on criteria.
    """
    try:
        # Extract query parameters
        search_term = params.get('q', '').lower()
        platform_filter = params.get('platform', '')
        region_filter = params.get('region', '')
        
        # Get the active status
        active_status = Status.objects.get(name='Active')
        
        # Start with all active devices
        device_queryset = Device.objects.filter(status=active_status)
        
        # Apply search term filter if provided
        if search_term:
            from django.db.models import Q
            # Simple name-based filtering using the ORM
            device_queryset = device_queryset.filter(
                Q(name__icontains=search_term)
            )
            
            # We'll do IP-based filtering in a separate query and combine the results
            # since we're having issues with ORM lookups for IP addresses
            
            # Note: We're not doing additional filtering beyond this ORM query
            # The devices returned by this query will be included in the results
        
        # Apply platform filter if provided
        if platform_filter:
            device_queryset = device_queryset.filter(device_type__model=platform_filter)
        
        # Apply region filter if provided
        if region_filter:
            # Assuming region is stored in the device's location parent
            location_type = LocationType.objects.filter(name__icontains='region').first()
            if location_type:
                # Find locations matching the region filter
                locations = Location.objects.filter(location_type=location_type, name=region_filter)
                
                if locations:
                    # The tree_queries package provides a 'descendants' method on the queryset, not the object
                    # Get IDs of the filtered locations
                    location_ids = [loc.id for loc in locations]
                    
                    # For each location, find all its descendants
                    all_location_ids = set(location_ids)
                    for location_id in location_ids:
                        # Get descendants using tree_queries API
                        descendants = Location.objects.descendants(location_id)
                        all_location_ids.update(descendants.values_list('id', flat=True))
                    
                    # Filter devices by these locations
                    device_queryset = device_queryset.filter(location__in=all_location_ids)
                else:
                    # No matching locations found, return empty queryset
                    device_queryset = Device.objects.none()
        
        # Format the devices for the UI
        devices = []
        for device in device_queryset:
            # Get primary IP addresses
            ip_address = "No IP"
            
            # Safely check for primary_ip4
            if hasattr(device, 'primary_ip4') and device.primary_ip4:
                ip_obj = device.primary_ip4
                # Use string representation
                ip_address = str(ip_obj)
            # If no IPv4, try IPv6
            elif hasattr(device, 'primary_ip6') and device.primary_ip6:
                ip_obj = device.primary_ip6
                ip_address = str(ip_obj)
                
            # Determine status based on IOS version
            # ios_version = device.custom_field_data.get('ios_version', '10.2.5') if hasattr(device, 'custom_field_data') else '10.2.5'
            # last_upgraded = device.custom_field_data.get('last_upgraded', '2025-07-08') if hasattr(device, 'custom_field_data') else '2025-07-08'
            ios_version = getattr(device, 'custom_field_data', {}).get('ios_version') or '10.2.5'
            last_upgraded = getattr(device, 'custom_field_data', {}).get('last_upgraded') or '2025-07-08'
            
            # Determine the status class based on version
            status = "Unknown"
            status_class = "warning"
            flash_space = "Unknown"
            
            if ios_version != 'Unknown':
                # This is a simple example - you'd have your own logic for this
                if ios_version.startswith('17.09') or ios_version.startswith('10'):
                    status = "Up to Date"
                    status_class = "success"
                elif ios_version.startswith('16.9') or ios_version.startswith('16.12') or ios_version.startswith('17.06'):
                    status = "Update Available"
                    status_class = "warning"
                else:
                    status = "Outdated"
                    status_class = "danger"
            
            # Get flash space from custom field if available
            # flash_space = device.custom_field_data.get('flash_space', '2430.6585 MB') if hasattr(device, 'custom_field_data') else '2430.6585 MB'
            import random
            flash_space = getattr(device, 'custom_field_data', {}).get('flash_space') or f"{random.uniform(2000, 3000):.4f} MB"
            
            # Get the region if available
            region = "Unknown"
            if device.location and hasattr(device.location, 'parent') and device.location.parent:
                region = device.location.parent.name
            
            devices.append({
                "id": str(device.id),
                "hostname": device.name,
                "ip_address": ip_address,
                "device_type": device.device_type.model if device.device_type else "Unknown",
                "ios_version": ios_version,
                "status": status,
                "status_class": status_class,
                "flash_space": flash_space,
                "last_upgraded": last_upgraded,
                "region": region
            })
        
        # Now, if we have a search term, also try to find devices by IP address
        if search_term and len(devices) == 0:
            # This is a separate approach to try finding by IP if the name search returned nothing
            # Get all devices again (we might optimize this later)
            ip_device_queryset = Device.objects.filter(status=active_status)
            
            # Loop through each device and check IPs manually
            for device in ip_device_queryset:
                ip_matched = False
                
                # Check IPv4
                if hasattr(device, 'primary_ip4') and device.primary_ip4:
                    ip_str = str(device.primary_ip4)
                    if search_term in ip_str.lower():
                        ip_matched = True
                
                # Check IPv6
                if not ip_matched and hasattr(device, 'primary_ip6') and device.primary_ip6:
                    ip_str = str(device.primary_ip6)
                    if search_term in ip_str.lower():
                        ip_matched = True
                
                # If IP matched and device not already in our list, add it
                if ip_matched:
                    # Get primary IP (reusing logic from above)
                    ip_address = "No IP"
                    if hasattr(device, 'primary_ip4') and device.primary_ip4:
                        ip_address = str(device.primary_ip4)
                    elif hasattr(device, 'primary_ip6') and device.primary_ip6:
                        ip_address = str(device.primary_ip6)
                    
                    # Get other device details (same as above)
                    ios_version = device.custom_field_data.get('ios_version', 'Unknown') if hasattr(device, 'custom_field_data') else 'Unknown'
                    last_upgraded = device.custom_field_data.get('last_upgraded', 'Never') if hasattr(device, 'custom_field_data') else 'Never'
                    
                    status = "Unknown"
                    status_class = "warning"
                    if ios_version != 'Unknown':
                        if ios_version.startswith('17'):
                            status = "Up to Date"
                            status_class = "success"
                        elif ios_version.startswith('16.9') or ios_version.startswith('16.12'):
                            status = "Update Available"
                            status_class = "warning"
                        else:
                            status = "Outdated"
                            status_class = "danger"
                    
                    flash_space = device.custom_field_data.get('flash_space', 'Unknown') if hasattr(device, 'custom_field_data') else 'Unknown'
                    
                    region = "Unknown"
                    if device.location and hasattr(device.location, 'parent') and device.location.parent:
                        region = device.location.parent.name
                    
                    # Add device to results
                    devices.append({
                        "id": str(device.id),
                        "hostname": device.name,
                        "ip_address": ip_address,
                        "device_type": device.device_type.model if device.device_type else "Unknown",
                        "ios_version": ios_version,
                        "status": status,
                        "status_class": status_class,
                        "flash_space": flash_space,
                        "last_upgraded": last_upgraded,
                        "region": region
                    })
        
        # Debug logging
        import logging
        logger = logging.getLogger(__name__)
        logger.debug(f"Returning {len(devices)} devices in search_devices view")
        
        return JsonResponse({
            'success': True,
            'devices': devices
        })
    except Exception as e:
        import logging
        import traceback
        logger = logging.getLogger(__name__)
        logger.error(f"Error in search_devices: {str(e)}")
        logger.error(traceback.format_exc())
        
        return JsonResponse({
            'success': False,
            'error': str(e),
            'devices': []
        })

def start_ios_upgrade(user, devices, params):
    try:
        # Extract form data
        tftp_server = params.get('tftpServer')
        tftp_path = params.get('tftpPath')
        image_file = params.get('imageFile')
        auth_method = params.get('authMethod')
        credential_profile = params.get('credentialProfile')
        primary_action = params.get('primaryAction')
        secondary_action = params.get('secondaryAction')
        execution_type = params.get('executionType')
        
        # Get new parameters for device_type_vars.yml
        md5_checksum = params.get('md5Checksum', '')
        upgrade_version = params.get('upgradeVersion', 'Unknown')
        change_number = params.get('changeNumber', '')
        vrf_name = params.get('vrf', None)
        
        # Email notification params
        smtp_server = params.get('smtp_server', 'smtp.gmail.com')
        email_sender = params.get('emailSender', 'no-reply@hcltech.com')
        email_receiver = params.get('emailReceiver', 'avinash_sharma@hcltech.com')
        
        # Check if test mode is enabled
        test_mode = params.get('testMode', 'true')
        # ✅ Print/log everything at once
        debug_data = {
            "devices": devices,
            "tftpServer": tftp_server,
            "tftpPath": tftp_path,
            "imageFile": image_file,
            "authMethod": auth_method,
            "credentialProfile": credential_profile,
            "primaryAction": primary_action,
            "secondaryAction": secondary_action,
            "executionType": execution_type,
            "md5Checksum": md5_checksum,
            "upgradeVersion": upgrade_version,
            "changeNumber": change_number,
            "vrf": vrf_name,
            "smtpServer": smtp_server,
            "emailSender": email_sender,
            "emailReceiver": email_receiver,
            "testMode": test_mode,
        }

        print("📥 Incoming Form Data:", json.dumps(debug_data, indent=4))
        logger.info(f"Upgrade request - Devices: {devices}, Test Mode: {test_mode}, Primary Action: {primary_action}")
        
        # Get the job model - this should always exist now because of our __init__.py code
        try:
            job_model = Job.objects.get(job_class_name='DeviceUpgradeJob', module_name='naas.jobs')
        except Job.DoesNotExist:
            logger.error("DeviceUpgradeJob not found in the database despite auto-registration")
            return JsonResponse({
                'success': False,
                'error': 'DeviceUpgradeJob not found in the database. Please try restarting the server.'
            })
        
        # Get schedule time if not immediate
        schedule_time = None
        if execution_type != 'immediate':
            schedule_time_str = params.get('scheduleTime')
            if schedule_time_str:
                from django.utils import timezone
                from datetime import datetime
                
                try:
                    # Parse the datetime string
                    schedule_time = datetime.fromisoformat(schedule_time_str.replace('Z', '+00:00'))
                    # Ensure it's timezone aware
                    if timezone.is_naive(schedule_time):
                        schedule_time = timezone.make_aware(schedule_time)
                except ValueError as e:
                    logger.error(f"Invalid schedule time format: {schedule_time_str} - {str(e)}")
                    return JsonResponse({
                        'success': False,
                        'error': f"Invalid schedule time format: {str(e)}"
                    })
        
        # Create job records for each device
        job_ids = {}
        install_job_ids = {}

        for device_ip in devices:
            # Clean the device IP if it contains subnet mask
            clean_device_ip = device_ip.split('/')[0] if '/' in device_ip else device_ip
            
            # Prepare job parameters
            job_kwargs = {
                'device_ip': clean_device_ip,
                'tftp_server': tftp_server,
                'tftp_path': tftp_path,
                'image_file': image_file,
                'auth_method': auth_method,
                'credential_profile': credential_profile,
                'secondary_action': secondary_action,
                'dryrun': test_mode,
                # New parameters for device_type_vars.yml
                'md5_checksum': md5_checksum,
                'upgrade_version': upgrade_version,
                'change_number': change_number,
                'vrf_name': vrf_name,
                'smtp_server': smtp_server,
                'email_sender': email_sender,
                'email_receiver': email_receiver,
                # Always set these validation parameters to True
                'check_memory': True,
                'check_compatibility': True,
                'backup_config': True,
                'verify_boot': True,
                'verify_features': True,
                'enable_rollback': True
            }
            
            # Handle upload_install as a special case
            is_upload_install = primary_action == 'upload_install'
            
            # For upload_install, we set primary_action to 'upload' for the first job
            if is_upload_install:
                upload_kwargs = job_kwargs.copy()
                upload_kwargs['primary_action'] = 'upload'
            else:
                job_kwargs['primary_action'] = primary_action
            
            # Create a unique name for the job
            job_name = f"Firmware upgrade for {clean_device_ip}"
            if schedule_time:
                job_name += f" - {schedule_time.strftime('%Y-%m-%d %H:%M')}"
                
            # SCHEDULED JOBS
            if schedule_time:
                from nautobot.extras.choices import JobExecutionType
                from nautobot.extras.models import ScheduledJob
                
                if is_upload_install:
                    # For upload_install with scheduling, we need to create TWO scheduled jobs:
                    # 1. The upload job at the requested schedule_time
                    upload_kwargs['primary_action'] = 'upload'  # Ensure it's set to upload
                    upload_scheduled_job = ScheduledJob.create_schedule(
                        job_model=job_model,
                        user=user,
                        name=f"{job_name} - Upload",
                        start_time=schedule_time,
                        interval=JobExecutionType.TYPE_FUTURE,  # One-time execution
                        approval_required=False,
                        **upload_kwargs
                    )
                    
                    # 2. The install job scheduled 15 minutes after the upload job
                    install_kwargs = job_kwargs.copy()
                    install_kwargs['primary_action'] = 'install'
                    install_kwargs['depends_on_job_id'] = str(upload_scheduled_job.pk)  # Reference to the upload job
                    
                    # Calculate the install scheduled time (15 minutes after upload)
                    from datetime import timedelta
                    install_schedule_time = schedule_time + timedelta(minutes=15)
                    
                    install_scheduled_job = ScheduledJob.create_schedule(
                        job_model=job_model,
                        user=user,
                        name=f"{job_name} - Install (following upload {upload_scheduled_job.pk})",
                        start_time=install_schedule_time,
                        interval=JobExecutionType.TYPE_FUTURE,  # One-time execution
                        approval_required=False,
                        **install_kwargs
                    )
                    
                    # Store both job IDs for tracking
                    job_ids[device_ip] = str(upload_scheduled_job.pk)
                    install_job_ids[device_ip] = str(install_scheduled_job.pk)
                    
                    log_msg = (f"Scheduled {'test' if test_mode else 'upload_install'} job for device {device_ip}: "
                            f"Upload at {schedule_time}, Install at {install_schedule_time} (with dependency check)")
                    logger.info(log_msg)
                else:
                    # Regular job scheduling (upload or install)
                    scheduled_job = ScheduledJob.create_schedule(
                        job_model=job_model,
                        user=user,
                        name=job_name,
                        start_time=schedule_time,
                        interval=JobExecutionType.TYPE_FUTURE,  # One-time execution
                        approval_required=False,
                        **job_kwargs
                    )
                    
                    # Store the job_id for tracking
                    job_ids[device_ip] = str(scheduled_job.pk)
                    log_msg = f"Scheduled {'test' if test_mode else primary_action} job {scheduled_job.pk} for device {device_ip} at {schedule_time}"
                    logger.info(log_msg)
            # Modified section for IMMEDIATE JOBS in start_upgrade view
            else:
                if is_upload_install:
                    # For upload_install immediate execution
                    # 1. Start the upload job immediately
                    upload_kwargs['primary_action'] = 'upload'  # Ensure it's set to upload
                    upload_job_result = JobResult.enqueue_job(
                        job_model=job_model,
                        user=user,
                        **upload_kwargs
                    )
                    
                    # 2. Schedule the install job for 15 minutes after now
                    from django.utils import timezone
                    from datetime import timedelta
                    install_time = timezone.now() + timedelta(minutes=15)
                    
                    from nautobot.extras.choices import JobExecutionType
                    from nautobot.extras.models import ScheduledJob
                    
                    # Prepare install job parameters
                    install_kwargs = job_kwargs.copy()
                    install_kwargs['primary_action'] = 'install'
                    install_kwargs['depends_on_job_id'] = str(upload_job_result.pk)  # Reference to the upload job
                    
                    # Create scheduled job for install
                    install_scheduled_job = ScheduledJob.create_schedule(
                        job_model=job_model,
                        user=user,
                        name=f"Install firmware for {clean_device_ip} (after upload {upload_job_result.pk})",
                        start_time=install_time,
                        interval=JobExecutionType.TYPE_FUTURE,  # One-time execution
                        approval_required=False,
                        **install_kwargs
                    )
                    
                    # Store both job IDs for tracking
                    job_ids[device_ip] = str(upload_job_result.pk)
                    install_job_ids[device_ip] = str(install_scheduled_job.pk)
                    
                    log_msg = (f"Started {'test' if test_mode else 'upload_install'} for device {device_ip}: "
                            f"Upload job {upload_job_result.pk} now, Install job {install_scheduled_job.pk} "
                            f"scheduled at {install_time.strftime('%Y-%m-%d %H:%M')} (with dependency check)")
                    logger.info(log_msg)
                else:
                    # Regular immediate job (simple upload or install)
                    job_result = JobResult.enqueue_job(
                        job_model=job_model,
                        user=user,
                        **job_kwargs
                    )
                    
                    # Store the job_id for tracking
                    job_ids[device_ip] = str(job_result.pk)
                    log_msg = f"Started {'test' if test_mode else primary_action} job {job_result.pk} for device {device_ip}"
                    logger.info(log_msg)
        # Return success response with job IDs in the expected format
        response_data = {
            'success': True,
            'message': f"{'Test' if test_mode else primary_action.capitalize()} jobs {'scheduled' if schedule_time else 'created'} successfully",
            'job_ids': job_ids,  # Primary job IDs (upload jobs for upload_install)
            'test_mode': test_mode,
            'scheduled': bool(schedule_time)
        }
        
        # If we created install jobs as part of upload_install, include those in the response
        if install_job_ids:
            response_data['install_job_ids'] = install_job_ids
            response_data['is_upload_install'] = True
        
        return JsonResponse(response_data)
    
    except Exception as e:
        logger.error(f"Error starting upgrade process: {str(e)}")
        import traceback
        logger.error(traceback.format_exc())
        return JsonResponse({
            'success': False,
            'error': str(e)
        })
    
def deploy_vlan_configs(configs, username="hcl", password="cisco"):
    """
    Common function to deploy VLAN configurations.
    Used by both UI view and API view.
    """
    results = []
    for config in configs:
        result = configure_arista_vlan(
            ip=config["switch_ip"],
            username=username,
            password=password,
            vlan_id=config["vlan"],
            vlan_name=config.get("vlan_description", ""),
            gateway_ip=config.get("gateway_ip", ""),
            subnet=config.get("subnet", ""),
            mtu_size=config.get("mtu_size", ""),
        )
        results.append(result)

    # Preprocess results for better readability
    formatted_results = [result.split("\n") for result in results]

    return {
        "status": "success",
        "message": "VLAN configuration deployed successfully",
        "output": formatted_results,
    }


def configure_arista_vlan(ip, username, password, vlan_id, vlan_name, gateway_ip, subnet, mtu_size):
    try:
        logger.info(f"Connecting to {ip} with username {username}")
        with get_device_connection(ip, username, password) as net_connect:
            logger.info(f"Connected to {ip}")

            # Enter enable and config modes
            net_connect.enable()
            net_connect.config_mode()

            # Sanitize VLAN name (replace spaces with underscores)
            sanitized_vlan_name = vlan_name.replace(' ', '_')

            # Prepare IP address with subnet prefix
            ip_with_subnet = f"{gateway_ip}/{subnet.split('/')[-1]}"

            # Prepare configuration commands
            commands = [
                f'vlan {vlan_id}',  # Define VLAN ID
                f'name {sanitized_vlan_name}',  # Set VLAN name
                f'interface vlan {vlan_id}',  # Configure VLAN interface
                f'ip address {ip_with_subnet}',  # Assign IP address with subnet
                f'mtu {mtu_size}',  # Set MTU size
                'no shutdown',  # Enable interface
            ]

            logger.info(f"Sending configuration commands to {ip}: {commands}")
            # Execute commands
            output = net_connect.send_config_set(commands)

            # Save configuration
            net_connect.save_config()

            logger.info(f"Configuration successful for {ip}")
            return output

    except NetMikoTimeoutException as e:
        logger.error(f"Timeout error configuring VLAN on {ip}: {e}")
        return str(e)
    except NetMikoAuthenticationException as e:
        logger.error(f"Authentication error configuring VLAN on {ip}: {e}")
        return str(e)
        logger.error(f"Error configuring VLAN on {ip}: {e}")
        return str(e)
    
def get_device_connection(ip, username, password):
    device = {
        'device_type': 'arista_eos',
        'host': ip,
        'username': username,
        'password': password,
    }
    return ConnectHandler(**device)
