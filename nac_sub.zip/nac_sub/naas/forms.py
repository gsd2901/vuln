from django import forms
from nautobot.dcim.models import Location, DeviceType, Rack
from nautobot.ipam.models import VRF, VLAN, Prefix
from nautobot.extras.models import Tag, Status
from .models import SiteOnboarding, Device
from nautobot.core.forms import DynamicModelMultipleChoiceField
import uuid

class SiteOnboardingForm(forms.ModelForm):
    site_tags = DynamicModelMultipleChoiceField(queryset=Tag.objects.all(), required=False)

    class Meta:
        model = SiteOnboarding
        fields = ['name', 'location', 'site_tags']

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['location'].queryset = Location.objects.all()

class DeviceForm(forms.ModelForm):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        unused_tag = Tag.objects.get(name="unused")
        active_status = Status.objects.get(name="Active")

        self.fields['rack'].queryset = Rack.objects.filter(tags=unused_tag, status=active_status)
        self.fields['vrfs'].queryset = VRF.objects.filter(tags=unused_tag, status=active_status)

    device_type = forms.ModelChoiceField(queryset=DeviceType.objects.all(), required=True)
    rack = forms.ModelChoiceField(queryset=Rack.objects.all(), required=True)
    vrfs = DynamicModelMultipleChoiceField(queryset=VRF.objects.all(), required=False)
    serial_number = forms.CharField(max_length=100, required=False)

    class Meta:
        model = Device
        fields = ['name', 'device_type', 'rack', 'vrfs', 'serial_number']


from nautobot.ipam.models import VLAN, Prefix
import uuid
class VLANConfigurationForm(forms.Form):
    
    switch_ip = forms.GenericIPAddressField(
        protocol='IPv4',
        widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Enter Switch IP'})
    )
    
    # Initialize with empty queryset, will be populated in __init__
    vlan = forms.ModelChoiceField(
        queryset=VLAN.objects.none(),  # Start with empty queryset
        widget=forms.Select(attrs={'class': 'form-control vlan-select'})
    )
    
    admin_state = forms.ChoiceField(
        choices=[('no shutdown', 'No Shutdown'), ('shutdown', 'Shutdown')],
        widget=forms.Select(attrs={'class': 'form-control'})
    )
    
    vlan_description = forms.CharField(
        max_length=100,
        required=False,
        widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Enter VLAN Description'})
    )
    
    subnet = forms.ModelChoiceField(
        queryset=Prefix.objects.none(),
        required=False,
        widget=forms.Select(attrs={'class': 'form-control subnet-select'})
    )
    
    gateway_ip = forms.GenericIPAddressField(
        protocol='IPv4',
        required=False,
        widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Enter Gateway IP'})
    )
    
    mtu_size = forms.IntegerField(
        required=False,
        widget=forms.NumberInput(attrs={'class': 'form-control', 'placeholder': 'Enter MTU Size'})
    )

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        
        # Move database queries here - safe to do during form instantiation
        try:
            unused_tag = Tag.objects.get(name="unused")
            active_status = Status.objects.get(name="Active")
            
            # Now set the queryset with the retrieved objects
            self.fields['vlan'].queryset = VLAN.objects.filter(
                tags=unused_tag, 
                status=active_status
            )
            
        except (Tag.DoesNotExist, Status.DoesNotExist):
            # Fallback: if tags/status don't exist, show all VLANs
            self.fields['vlan'].queryset = VLAN.objects.all()
        
        # Handle dynamic subnet loading based on selected VLAN
        if 'vlan' in self.data:
            try:
                vlan_id = uuid.UUID(self.data.get('vlan'))
                self.fields['subnet'].queryset = Prefix.objects.filter(vlan_id=vlan_id)
            except (ValueError, TypeError):
                pass  # invalid input from the client; ignore and fallback to empty Prefix queryset

class MultiVLANConfigurationForm(forms.Form):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.rows = []
        data = kwargs.get('data', None)
        print("data", data)
        if data:
            # Get all unique row indices from the submitted data
            indices = set()
            for key in data.keys():
                if key.startswith('switch_ip_'):
                    index = key.split('_')[-1]
                    indices.add(index)
            
            # Create a form for each row
            for index in indices:
                row_data = {
                    'switch_ip': data.get(f'switch_ip_{index}'),
                    'vlan': data.get(f'vlan_{index}'),
                    'admin_state': data.get(f'admin_state_{index}'),
                    'vlan_description': data.get(f'vlan_description_{index}'),
                    'subnet': data.get(f'subnet_{index}'),
                    'gateway_ip': data.get(f'gateway_ip_{index}'),
                    'mtu_size': data.get(f'mtu_size_{index}')
                }
                row_form = VLANConfigurationForm(row_data)
                self.rows.append(row_form)
        else:
            # Create 3 empty rows for new form
            for _ in range(3):
                print('____', _)
                self.rows.append(VLANConfigurationForm())

    def is_valid(self):
        return all(row_form.is_valid() for row_form in self.rows)

    def cleaned_data(self):
        return [form.cleaned_data for form in self.rows if form.is_valid()]
    

class ACIConfigForm(forms.Form):
    fabricName = forms.CharField(max_length=100)
    podId = forms.IntegerField()
    nodeId = forms.IntegerField()
    Tenant = forms.CharField(max_length=100)
    AP = forms.CharField(max_length=100)
    EPG = forms.CharField(max_length=100)
    vlan = forms.IntegerField()
    mode = forms.ChoiceField(choices=[('access', 'Access'), ('trunk', 'Trunk')])
    fromPort = forms.IntegerField()
    toPort = forms.IntegerField()

# nautobot-dev/nautobot/naas/forms.py
##### F5 froms #########



# Below are the forms to manage the F5 operations
# --- Shared Choices ---
LOAD_BALANCING_CHOICES = [
    ('round-robin', 'Round Robin'),
    ('ratio-member', 'Ratio Member'),
    ('dynamic-ratio-member', 'Dynamic Ratio Member'),
    ('dynamic-ratio-node', 'Dynamic Ratio Node'),
    ('fastest-app-response', 'Fastest App Response'),
    ('fastest-node', 'Fastest Node'),
]

PROFILE_CHOICES = [
    ('/Common/tcp', 'tcp'),
    ('/Common/f5-tcp-lan', 'f5-tcp-lan'),
    ('/Common/f5-tcp-progressive', 'f5-tcp-progressive'),
    ('/Common/f5-tcp-mobile', 'f5-tcp-mobile'),
    # Add others as needed...
]

ACTION_CHOICES = [
    ('enable', 'Enable'),
    ('disable', 'Disable'),
    ('add', 'Add'),
    ('remove', 'Remove'),
    ('test', 'Test'),
]

# Profile choices for F5
PROFILE_CHOICES = [
    ('/Common/f5-tcp-lan', 'f5-tcp-lan'),
    ('/Common/f5-tcp-progressive', 'f5-tcp-progressive'),
    ('/Common/f5-tcp-wan', 'f5-tcp-wan'),
    ('/Common/tcp', 'tcp'),
    ('/Common/tcp-lan-optimized', 'tcp-lan-optimized'),
    ('/Common/tcp-wan-optimized', 'tcp-wan-optimized'),
    ('/Common/http', 'http'),
    ('/Common/http-explicit', 'http-explicit'),
    ('/Common/http-transparent', 'http-transparent'),
    ('/Common/clientssl', 'clientssl'),
    ('/Common/serverssl', 'serverssl'),
]

# Load balancing mode choices
LOAD_BALANCING_CHOICES = [
    ('round-robin', 'Round Robin'),
    ('ratio-member', 'Ratio Member'),
    ('least-connections-member', 'Least Connections'),
    ('fastest-node', 'Fastest Node'),
    ('dynamic-ratio-member', 'Dynamic Ratio Member'),
    ('fastest-app-response', 'Fastest Application Response'),
]

class VipCreationForm(forms.Form):
    # Basic VIP Configuration
    partition = forms.CharField(
        initial='Common', 
        required=True,
        widget=forms.TextInput(attrs={'readonly': True})
    )
    name = forms.CharField(
        label="VIP Name", 
        required=True,
        widget=forms.TextInput(attrs={'placeholder': 'e.g. VIP_WEBAPP_PROD'})
    )
    description = forms.CharField(
        widget=forms.TextInput(attrs={'placeholder': 'Production web application load balancer'}),
        required=False
    )
    destination = forms.CharField(
        help_text="IP:Port format",
        required=True,
        widget=forms.TextInput(attrs={'placeholder': '192.0.2.121:443'})
    )
    mask = forms.CharField(
        initial='255.255.255.255',
        required=True
    )
    source = forms.CharField(
        initial='0.0.0.0/0',
        required=True
    )
    pool = forms.CharField(
        required=True,
        widget=forms.TextInput(attrs={'placeholder': 'webapp_prod_pool'})
    )
    ipProtocol = forms.ChoiceField(
        choices=[('tcp', 'TCP'), ('udp', 'UDP')],
        required=True
    )
    snatpool = forms.CharField(
        required=False,
        widget=forms.TextInput(attrs={'placeholder': 'prod_snat_pool'})
    )

    # Profile Configuration
    protocol_client = forms.ChoiceField(
        label="Protocol Profile (Client)",
        choices=PROFILE_CHOICES,
        required=True
    )
    protocol_server = forms.ChoiceField(
        label="Protocol Profile (Server)",
        choices=[('', '(Use Client Profile)')] + PROFILE_CHOICES,
        required=False
    )
    http_client = forms.ChoiceField(
        label="HTTP Profile (Client)",
        choices=[('', 'None')] + [(p[0], p[1]) for p in PROFILE_CHOICES if 'http' in p[0]],
        required=False
    )
    http_server = forms.ChoiceField(
        label="HTTP Profile (Server)",
        choices=[('', '(Use Client Profile)')] + [(p[0], p[1]) for p in PROFILE_CHOICES if 'http' in p[0]],
        required=False
    )
    ssl_client = forms.ChoiceField(
        label="SSL Profile (Client)",
        choices=[('', 'None')] + [(p[0], p[1]) for p in PROFILE_CHOICES if 'ssl' in p[0]],
        required=False
    )
    ssl_server = forms.ChoiceField(
        label="SSL Profile (Server)",
        choices=[('', 'None')] + [(p[0], p[1]) for p in PROFILE_CHOICES if 'ssl' in p[0]],
        required=False
    )

class VipValidationForm(forms.Form):
    partition = forms.CharField(
        initial='Common',
        required=True,
        widget=forms.TextInput(attrs={'readonly': True})
    )
    vip_name = forms.MultipleChoiceField(
        widget=forms.SelectMultiple(attrs={'class': 'form-control'}),
        required=True,
        choices=[],
        label="VIP Names"
    )

    def __init__(self, *args, vip_choices=None, **kwargs):
        super().__init__(*args, **kwargs)
        if vip_choices:
            self.fields['vip_name'].choices = vip_choices

class PoolCreationForm(forms.Form):
    partition = forms.CharField(
        initial='Common',
        required=True,
        widget=forms.TextInput(attrs={'readonly': True})
    )
    pool_name = forms.CharField(
        required=True,
        widget=forms.TextInput(attrs={'placeholder': 'webapp_prod_pool'})
    )
    description = forms.CharField(
        required=False,
        widget=forms.TextInput(attrs={'placeholder': 'Production web application pool'})
    )
    load_balancing_mode = forms.ChoiceField(
        choices=LOAD_BALANCING_CHOICES,
        required=True
    )
    pool_members = forms.CharField(
        widget=forms.Textarea(attrs={
            'rows': 4,
            'placeholder': '10.0.1.10:80\n10.0.1.11:80\napp01.local:80'
        }),
        required=True,
        help_text="One member per line (IP:Port or hostname:Port)"
    )

class PoolModificationForm(forms.Form):
    partition = forms.CharField(
        initial='Common',
        required=True,
        widget=forms.TextInput(attrs={'readonly': True})
    )
    pool_name = forms.CharField(
        required=True,
        widget=forms.TextInput(attrs={'placeholder': 'webapp_prod_pool'})
    )
    pool_member_modifications = forms.CharField(
        widget=forms.Textarea(attrs={
            'rows': 5,
            'placeholder': '10.0.1.10:80,disable\n10.0.1.12:80,add\n10.0.1.11:80,enable'
        }),
        required=True,
        help_text="Format: IP:Port,action (enable, disable, add, remove)"
    )

class MultiF5OperationForm(forms.Form):
    OPERATION_CHOICES = [
        ('', '-- Select Operation --'),
        ('create_vip', 'Create VIP'),
        ('vip_validation', 'VIP Validation'),
        ('create_pool', 'Create Pool'),
        ('modify_pool', 'Modify Pool'),
    ]

    operation = forms.ChoiceField(
        choices=OPERATION_CHOICES,
        label="Select F5 Operation",
        required=True
    )

    requested_cr = forms.CharField(
        required=False,
        widget=forms.HiddenInput()
    )

    def __init__(self, *args, **kwargs):
        vip_choices = kwargs.pop('vip_choices', [])
        super().__init__(*args, **kwargs)

        self.sub_form = None
        self.vip_data = None
        data = self.data
        
        if data:
            selected_operation = data.get('operation')
            
            if selected_operation == 'create_vip':
                # Extract VIP-specific fields from form data
                self.vip_data = self._extract_vip_data(data)  
                self.sub_form = VipCreationForm(self.vip_data)          
            elif selected_operation == 'vip_validation':
                self.sub_form = VipValidationForm(data, vip_choices=vip_choices)
            elif selected_operation == 'create_pool':
                self.sub_form = PoolCreationForm(data)
            elif selected_operation == 'modify_pool':
                self.sub_form = PoolModificationForm(data)

    def _extract_vip_data(self, data):
        """Extract VIP-specific fields from the combined form data"""
        vip_data = {}
        
        # Map fields with _0 suffix to their clean names
        field_mapping = {
            'name_0': 'name',
            'partition_0': 'partition', 
            'description_0': 'description',
            'destination_0': 'destination',
            'source_0': 'source',
            'pool_0': 'pool',
            'ipProtocol_0': 'ipProtocol',
            'snatpool_0': 'snatpool',
            'protocol_client_0': 'protocol_client',
            'protocol_server_0': 'protocol_server',
            'http_client_0': 'http_client',
            'http_server_0': 'http_server',
            'ssl_client_0': 'ssl_client',
            'ssl_server_0': 'ssl_server',
        }
        
        for form_field, clean_field in field_mapping.items():
            if form_field in data:
                vip_data[clean_field] = data[form_field]
        
        # Set defaults
        vip_data.setdefault('mask', '255.255.255.255')
        vip_data.setdefault('source', '0.0.0.0/0')
        vip_data.setdefault('partition', 'Common')
        
        return vip_data

    def is_valid(self):
        base_valid = super().is_valid()
        if self.sub_form:
            return base_valid and self.sub_form.is_valid()
        return base_valid

    def get_cleaned_data(self):
        if self.sub_form and self.sub_form.is_valid():
            return {
                'operation': self.cleaned_data.get('operation'),
                'requested_cr': self.cleaned_data.get('requested_cr'),
                'details': self.vip_data
            }
        return self.cleaned_data
    

# from django.core.exceptions import ValidationError
# import json

# from nautobot.apps.forms import (
#     NautobotModelForm,
#     NautobotFilterForm,
#     StaticSelect2,
#     DynamicModelChoiceField,
# )

# from .models import F5Device, F5VIP, F5Pool

# class F5DeviceForm(NautobotModelForm):
#     class Meta:
#         model = F5Device
#         fields = ['name', 'ip_address', 'username', 'password', 'partition', 'is_active', 'description']
#         widgets = {
#             'password': forms.PasswordInput(),
#             'description': forms.Textarea(attrs={'rows': 3}),
#         }

# class VIPValidationForm(forms.Form):
#     device = forms.ModelChoiceField(
#         queryset=F5Device.objects.filter(is_active=True),
#         widget=StaticSelect2(),
#         help_text="Select F5 device"
#     )
#     partition = forms.CharField(
#         max_length=50,
#         initial="Common",
#         help_text="F5 partition name"
#     )
#     vip_names = forms.CharField(
#         widget=forms.Textarea(attrs={'rows': 4, 'placeholder': 'Enter VIP names separated by commas, or "all" for all VIPs'}),
#         help_text="VIP names separated by commas, or 'all' for all VIPs in partition"
#     )

# class VIPCreationForm(forms.Form):
#     device = forms.ModelChoiceField(
#         queryset=F5Device.objects.filter(is_active=True),
#         widget=StaticSelect2()
#     )
#     name = forms.CharField(max_length=100, help_text="VIP name")
#     partition = forms.CharField(max_length=50, initial="Common")
#     description = forms.CharField(required=False, widget=forms.Textarea(attrs={'rows': 2}))
#     destination = forms.CharField(
#         max_length=100,
#         help_text="IP:Port (e.g., 192.168.1.10:80)"
#     )
#     mask = forms.CharField(initial="255.255.255.255")
#     source = forms.CharField(initial="0.0.0.0/0")
#     pool = forms.CharField(max_length=100, help_text="Pool name")
#     ip_protocol = forms.ChoiceField(
#         choices=[('tcp', 'TCP'), ('udp', 'UDP')],
#         initial='tcp'
#     )
#     snatpool = forms.CharField(required=False, help_text="SNAT pool name (optional)")
#     profiles = forms.CharField(
#         required=False,
#         widget=forms.Textarea(attrs={'rows': 5, 'placeholder': 'JSON format profiles'}),
#         help_text="Profiles in JSON format (optional)"
#     )

# class PoolCreationForm(forms.Form):
#     device = forms.ModelChoiceField(
#         queryset=F5Device.objects.filter(is_active=True),
#         widget=StaticSelect2()
#     )
#     name = forms.CharField(max_length=100, help_text="Pool name")
#     partition = forms.CharField(max_length=50, initial="Common")
#     description = forms.CharField(required=False, widget=forms.Textarea(attrs={'rows': 2}))
#     load_balancing_mode = forms.ChoiceField(
#         choices=[
#             ('round-robin', 'Round Robin'),
#             ('ratio-member', 'Ratio Member'),
#             ('dynamic-ratio-member', 'Dynamic Ratio Member'),
#             ('dynamic-ratio-node', 'Dynamic Ratio Node'),
#             ('fastest-app-response', 'Fastest App Response'),
#             ('fastest-node', 'Fastest Node'),
#         ],
#         initial='round-robin'
#     )
#     members = forms.CharField(
#         widget=forms.Textarea(attrs={'rows': 5, 'placeholder': 'One member per line\n10.0.0.101:80\n10.0.0.102:80'}),
#         help_text="Pool members, one per line (IP:Port or hostname:port)"
#     )
#     monitor = forms.CharField(
#         required=False,
#         initial="http",
#         help_text="Health monitor (optional)"
#     )

# class PoolModificationForm(forms.Form):
#     device = forms.ModelChoiceField(
#         queryset=F5Device.objects.filter(is_active=True),
#         widget=StaticSelect2()
#     )
#     partition = forms.CharField(max_length=50, initial="Common")
#     modifications = forms.CharField(
#         widget=forms.Textarea(attrs={'rows': 10}),
#         help_text="JSON format modifications"
#     )
    
#     def clean_modifications(self):
#         data = self.cleaned_data['modifications']
#         try:
#             json.loads(data)
#             return data
#         except json.JSONDecodeError:
#             raise ValidationError("Invalid JSON format")

# class F5ConnectionForm(forms.Form):
#     ip_address = forms.GenericIPAddressField()
#     username = forms.CharField(max_length=50)
#     password = forms.CharField(widget=forms.PasswordInput())