# templatetags/yaml_filters.py
import yaml
from django import template
from django.utils.safestring import mark_safe

register = template.Library()

@register.filter
def pprint(value):
    """Convert Python object to properly formatted YAML"""
    try:
        if isinstance(value, dict):
            yaml_output = yaml.dump(
                value, 
                default_flow_style=False, 
                indent=2,
                allow_unicode=True,
                sort_keys=False
            )
            return mark_safe(yaml_output)
        return str(value)
    except Exception:
        return str(value)

@register.filter  
def yaml_format(value):
    """Format value as YAML with syntax highlighting classes"""
    try:
        if isinstance(value, dict):
            return mark_safe(format_yaml_with_classes(value))
        return str(value)
    except Exception:
        return str(value)

def format_yaml_with_classes(obj, indent=0):
    """Format YAML with CSS classes for syntax highlighting"""
    result = ""
    indent_str = "  " * indent
    
    if isinstance(obj, dict):
        for key, value in obj.items():
            if isinstance(value, (dict, list)):
                result += f'{indent_str}<span class="yaml-key">{key}</span>:\n'
                result += format_yaml_with_classes(value, indent + 1)
            else:
                result += f'{indent_str}<span class="yaml-key">{key}</span>: <span class="yaml-value">{value}</span>\n'
    elif isinstance(obj, list):
        for item in obj:
            if isinstance(item, (dict, list)):
                result += f'{indent_str}- \n'
                result += format_yaml_with_classes(item, indent + 1)
            else:
                result += f'{indent_str}- <span class="yaml-value">{item}</span>\n'
    
    return result