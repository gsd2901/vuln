reboot_const = {
    "Catalyst": {
        "pre_check": {
            'show_version':"show version",
            'show_file_systems':"show file systems",
            'show_running_config_result':"show running-config",
            'show_ip_interface_brief':"show ip interface brief",
            'show_vlan':"show vlan",
            'show_spanning_tree':"show spanning-tree",
            'show_ip_route':"show ip route",
            'show_cdp_neighbors_detail':"show cdp neighbors detail",
            'show_interfaces_status':"show interfaces status",
            'show_logging':"show logging | include %ERR"
        },
        "post_check": {
            'show_version':"show version",
            'show_file_systems':"show file systems",
            'show_running_config_result':"show running-config",
            'show_ip_interface_brief':"show ip interface brief",
            'show_vlan':"show vlan",
            'show_spanning_tree':"show spanning-tree",
            'show_ip_route':"show ip route",
            'show_cdp_neighbors_detail':"show cdp neighbors detail",
            'show_interfaces_status':"show interfaces status",
            'show_logging':"show logging | include %ERR"
        },
        "reboot": [
            "write memory",
            "reload"
        ],
        "backup": [
            "show running-config | redirect flash:running-config-backup.txt"
        ],
    },

}
sender_email = "avinash.jecrc@gmail.com"
sender_password = "bmbv yztf qwnt yomx"
smtp_lib_server = "142.251.10.108"
smtp_port = 587
smtp_default_email_receiver = 'vidhiprakashb.sampa@hcltech.com'