import os
import datetime
from jinja2 import Environment, FileSystemLoader

class ConfigGenerator:
    """
    Class to generate network device configurations using Jinja2 templates.
    """
    
    def __init__(self, template_dir='naas/templates/naas'):
        """
        Initialize the configuration generator.
        
        Args:
            template_dir (str): Directory path containing the Jinja2 templates
        """
        self.env = Environment(
            loader=FileSystemLoader(template_dir),
            trim_blocks=True,
            lstrip_blocks=True
        )
    
    def generate_switch_config(self, switch_data, template_name='naas/switch_onboard.jinja2'):
        """
        Generate a switch configuration using the specified Jinja2 template.
        
        Args:
            switch_data (dict): Data dictionary containing switch configuration parameters
            template_name (str): Name of the Jinja2 template file
            
        Returns:
            str: The rendered configuration
        """
        template = self.env.get_template(template_name)
        
        # Add timestamp to the data
        config_data = switch_data.copy()
        config_data['timestamp'] = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        
         # Filter VLANs based on tags
        #filtered_vlans = [vlan for vlan in config_data['vlans'] if 'AMS01' in vlan['tags'] and 'PROD' in vlan['tags'] and 'VLAN' in vlan['tags']]
        #config_data['vlans'] = filtered_vlans
        print(config_data)
        # Render the template with the provided data
        return template.render(**config_data)
    
    def generate_bulk_switch_configs(self, switches_data, template_name='naas/switch_onboard.jinja2'):
        """
        Generate configurations for multiple switches.
        
        Args:
            switches_data (list): List of switch data dictionaries
            template_name (str): Name of the Jinja2 template file
            
        Returns:
            dict: Dictionary mapping switch names to their configurations
        """
        configs = {}
        
        for switch_data in switches_data:
            switch_name = switch_data.get('switch', {}).get('name', 'unnamed_switch')
            configs[switch_name] = self.generate_switch_config(switch_data, template_name)
        
        return configs
    
    def save_config_to_file(self, config, filename, output_dir='configs'):
        """
        Save a generated configuration to a file.
        
        Args:
            config (str): The configuration text
            filename (str): Name of the output file
            output_dir (str): Directory to save the configuration file
            
        Returns:
            str: Path to the saved configuration file
        """
        # Ensure the output directory exists
        os.makedirs(output_dir, exist_ok=True)
        
        # Create the full file path
        file_path = os.path.join(output_dir, filename)
        
        # Write the configuration to the file
        with open(file_path, 'w') as f:
            f.write(config)
        
        return file_path
    
    def save_bulk_configs(self, configs, output_dir='configs'):
        """
        Save multiple configurations to separate files.
        
        Args:
            configs (dict): Dictionary mapping switch names to configurations
            output_dir (str): Directory to save the configuration files
            
        Returns:
            dict: Dictionary mapping switch names to file paths
        """
        file_paths = {}
        
        for switch_name, config in configs.items():
            # Create a valid filename from the switch name
            filename = f"{switch_name.replace(' ', '_')}_config.txt"
            file_path = self.save_config_to_file(config, filename, output_dir)
            file_paths[switch_name] = file_path
        
        return file_paths


# Example usage:
if __name__ == "__main__":
    # Create a config generator instance
    generator = ConfigGenerator()
    
    # Example switch data
    switch_data = {
        'switch': {
            'name': 'SW-CORE-01',
            'location': 'Main Data Center',
            'management_ip': '192.168.1.1',
            'management_subnet': '255.255.255.0',
            'enable_aaa': True,
            'enable_snmp': True,
            'snmp_community': 'public',
            'contact': 'admin@example.com'
        },
        'organization_name': 'Example Corp',
        'vlans': [
            {'vid': 1, 'name': 'default'},
            {'vid': 10, 'name': 'DATA'},
            {'vid': 20, 'name': 'VOICE'},
            {'vid': 30, 'name': 'GUEST'}
        ],
        'interfaces': [
            {'name': 'GigabitEthernet0/1', 'description': 'Access Port 1', 'mode': 'access', 'vlan': 10},
            {'name': 'GigabitEthernet0/2', 'description': 'Access Port 2', 'mode': 'access', 'vlan': 20},
            {'name': 'GigabitEthernet0/3', 'description': 'Trunk Port 1', 'mode': 'trunk', 'allowed_vlans': '10,20,30', 'native_vlan': 1}
        ],
        'uplinks': [
            {'name': 'GigabitEthernet0/48', 'description': 'Uplink to Core'}
        ]
    }
    
    # Generate the configuration
    config = generator.generate_switch_config(switch_data)
    
    # Print the configuration
    print(config)
    
    # Save the configuration to a file
    file_path = generator.save_config_to_file(config, 'SW-CORE-01_config.txt')
    print(f"Configuration saved to: {file_path}")