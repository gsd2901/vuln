# tasks.py
import logging
import importlib
from nautobot.core.celery import nautobot_task
from nautobot.extras.models import JobResult
from nautobot.extras.jobs import get_job

logger = logging.getLogger(__name__)

@nautobot_task
def run_device_upgrade_task(job_id, device_ip, tftp_server, tftp_path, image_file, 
                      auth_method, credential_profile, primary_action, secondary_action,
                      dry_run=False, user_id=None):
    """
    Celery task to run the device upgrade job through Nautobot's job system
    """
    logger.info(f"Starting firmware upgrade task for device {device_ip} (dry run: {dry_run})")
    
    try:
        # Get the job class using the proper method
        DeviceUpgradeJob = get_job('naas.jobs.DeviceUpgradeJob')
        
        if not DeviceUpgradeJob:
            # Alternative approach - import the class directly
            module = importlib.import_module('naas.jobs')
            DeviceUpgradeJob = getattr(module, 'DeviceUpgradeJob')
        
        # Create the job data
        job_data = {
            'device_ip': device_ip,
            'tftp_server': tftp_server,
            'tftp_path': tftp_path,
            'image_file': image_file,
            'auth_method': auth_method,
            'credential_profile': credential_profile,
            'primary_action': primary_action,
            'secondary_action': secondary_action,
            'dry_run': dry_run
        }
        
        # Run the job
        job_result = JobResult.enqueue_job(
            DeviceUpgradeJob,
            job_data,
            request_id=job_id,
            user_id=user_id,
            commit=False  # Set to False for dry run through Nautobot's job system
        )
        
        logger.info(f"Queued job {job_id} with JobResult ID {job_result.pk}")
        
        return job_result.pk
    
    except Exception as e:
        logger.error(f"Error starting device upgrade job: {str(e)}")
        raise