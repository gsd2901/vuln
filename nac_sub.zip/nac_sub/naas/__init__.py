# naas/__init__.py
"""App declaration for NaaS."""

from nautobot.apps import NautobotAppConfig

__version__ = "1.0.0"

class NaaSConfig(NautobotAppConfig):
    name = "naas"
    verbose_name = "NaaS"
    description = "NaaS can replace hardware-centric VPNs, load balancers, firewall appliances, and Multiprotocol Label Switching (MPLS) connections.."
    author = "Avinash Sharma"
    author_email = "avinash_sharma@hcltech.com"
    base_url = "naas"
    required_settings = []
    default_settings = {}
    min_version = "1.0.0"
    max_version = "3.0.0"
    caching_config = {}

    def ready(self):
        """Callback when this app is loaded."""
        super().ready()
        
        # Import jobs to ensure they're registered with Nautobot
        try:
            from . import jobs
            
            # Explicitly register our jobs with the registry
            from nautobot.extras.registry import registry
            registry["jobs"]["naas.jobs.DeviceUpgradeJob"] = jobs.DeviceUpgradeJob
            registry["jobs"]["naas.jobs.DeviceRebootJob"] = jobs.DeviceRebootJob
            registry["jobs"]["naas.jobs.DeviceF5ConfigJob"] = jobs.DeviceF5ConfigJob
            registry["jobs"]["naas.jobs.ExtendedGoldenConfigJob"] = jobs.ExtendedGoldenConfigJob
            
            # Register the jobs in the database if they don't exist yet
            from django.apps import apps
            if apps.is_installed('nautobot.extras'):
                from nautobot.extras.models import Job, JobQueue
                
                try:
                    # Try to get an existing queue first
                    default_queue = JobQueue.objects.first()
                    
                    # If no queue exists, create one
                    if default_queue is None:
                        default_queue = JobQueue.objects.create(
                            name="Default", 
                            description="Default job queue"
                        )
                    
                    # Register DeviceUpgradeJob
                    upgrade_job_class = jobs.DeviceUpgradeJob
                    Job.objects.get_or_create(
                        job_class_name='DeviceUpgradeJob',
                        module_name='naas.jobs',
                        defaults={
                            'name': upgrade_job_class.name,
                            'grouping': upgrade_job_class.grouping,
                            'description': upgrade_job_class.description,
                            'installed': True,
                            'enabled': True,
                            'has_sensitive_variables': upgrade_job_class.has_sensitive_variables,
                            'default_job_queue': default_queue,
                        }
                    )
                    
                    # Register DeviceRebootJob (Fixed the job_class_name)
                    reboot_job_class = jobs.DeviceRebootJob
                    Job.objects.get_or_create(
                        job_class_name='DeviceRebootJob',  # Fixed: was 'DeviceUpgradeJob'
                        module_name='naas.jobs',
                        defaults={
                            'name': reboot_job_class.name,
                            'grouping': reboot_job_class.grouping,
                            'description': reboot_job_class.description,
                            'installed': True,
                            'enabled': True,
                            'has_sensitive_variables': reboot_job_class.has_sensitive_variables,
                            'default_job_queue': default_queue,
                        }
                    )
                    
                    # Register DeviceF5ConfigJob (NEW)
                    f5_job_class = jobs.DeviceF5ConfigJob
                    Job.objects.get_or_create(
                        job_class_name='DeviceF5ConfigJob',
                        module_name='naas.jobs',
                        defaults={
                            'name': f5_job_class.name,
                            'grouping': f5_job_class.grouping,
                            'description': f5_job_class.description,
                            'installed': True,
                            'enabled': True,
                            'has_sensitive_variables': f5_job_class.has_sensitive_variables,
                            'default_job_queue': default_queue,
                        }
                    )
                    # Register ExtendedGoldenConfigJob (NEW)
                    Extended_job_class = jobs.ExtendedGoldenConfigJob
                    Job.objects.get_or_create(
                        job_class_name='ExtendedGoldenConfigJob',
                        module_name='naas.jobs',
                        defaults={
                            'name': Extended_job_class.name,
                            'grouping': Extended_job_class.grouping,
                            'description': Extended_job_class.description,
                            'installed': True,
                            'enabled': True,
                            'has_sensitive_variables': Extended_job_class.has_sensitive_variables,
                            'default_job_queue': default_queue,
                        }
                    )
                    print("Successfully registered all NaaS jobs")
                    
                except Exception as e:
                    print(f"Error registering job models: {e}")
        except Exception as e:
            print(f"Error loading jobs: {e}")

config = NaaSConfig