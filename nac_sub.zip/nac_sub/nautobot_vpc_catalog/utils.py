import ipaddress
import json
from typing import List, Dict, Optional
from django.conf import settings

class IPAllocator:
    """Handles automatic IP allocation for VPC networks"""
    
    def __init__(self):
        self.reserved_networks = [
            '10.0.0.0/8',
            '172.16.0.0/12', 
            '192.168.0.0/16'
        ]
        # Start allocation from a designated range
        self.allocation_base = ipaddress.IPv4Network('10.100.0.0/16')
    
    def get_next_available_cidr(self, prefix_len: int = 24) -> Optional[str]:
        """Get the next available /24 CIDR block"""
        # Simple implementation - in production, check against database
        for subnet in self.allocation_base.subnets(new_prefix=prefix_len):
            # Check if this subnet is already in use
            if not self._is_cidr_in_use(str(subnet)):
                return str(subnet)
        
        return None
    
    def _is_cidr_in_use(self, cidr: str) -> bool:
        """Check if CIDR is already allocated"""
        # Import here to avoid circular imports
        from .models import VPCRequest
        return VPCRequest.objects.filter(
            vpc_cidr=cidr,
            status__in=['approved', 'provisioning', 'active']
        ).exists()
    
    def generate_public_subnets(self, vpc_cidr: str, count: int = 2) -> List[str]:
        """Generate public subnet CIDRs"""
        try:
            network = ipaddress.IPv4Network(vpc_cidr)
            # Split into 4 equal subnets, use first 2 for public
            subnets = list(network.subnets(new_prefix=network.prefixlen + 2))
            return [str(subnet) for subnet in subnets[:count]]
        except Exception as e:
            # Fallback to simple division
            return [vpc_cidr.replace('/24', '/26'), vpc_cidr.replace('/24', '/26')]
    
    def generate_private_subnets(self, vpc_cidr: str, count: int = 2) -> List[str]:
        """Generate private subnet CIDRs"""
        try:
            network = ipaddress.IPv4Network(vpc_cidr)
            # Split into 4 equal subnets, use last 2 for private
            subnets = list(network.subnets(new_prefix=network.prefixlen + 2))
            return [str(subnet) for subnet in subnets[count:]]
        except Exception as e:
            # Fallback to simple division
            return [vpc_cidr.replace('/24', '/26'), vpc_cidr.replace('/24', '/26')]

def generate_terraform_vars(vpc_request) -> Dict:
    """Generate Terraform variables from VPC request"""
    return {
        'vpc_name': vpc_request.vpc_name,
        'aws_region': vpc_request.aws_region,
        'vpc_cidr': vpc_request.vpc_cidr,
        'public_subnets': vpc_request.public_subnets or [],
        'private_subnets': vpc_request.private_subnets or [],
        'enable_nat_gateway': vpc_request.enable_nat_gateway,
        'enable_vpn_gateway': vpc_request.enable_vpn_gateway,
        'enable_dns_hostnames': vpc_request.enable_dns_hostnames,
        'enable_dns_support': vpc_request.enable_dns_support,
        'tags': {
            'Name': vpc_request.vpc_name,
            'Environment': vpc_request.custom_tags.get('Environment', 'dev') if vpc_request.custom_tags else 'dev',
            'Terraform': 'true',
            'ManagedBy': 'nautobot',
            'RequestID': str(vpc_request.request_id),
            **(vpc_request.custom_tags or {})
        }
    }

def create_terraform_tfvars_content(vpc_request) -> str:
    """Create terraform.tfvars file content"""
    vars_dict = generate_terraform_vars(vpc_request)
    
    content = []
    for key, value in vars_dict.items():
        if isinstance(value, bool):
            content.append(f'{key} = {str(value).lower()}')
        elif isinstance(value, (list, dict)):
            content.append(f'{key} = {json.dumps(value, indent=2)}')
        else:
            content.append(f'{key} = "{value}"')
    
    return '\n'.join(content)
