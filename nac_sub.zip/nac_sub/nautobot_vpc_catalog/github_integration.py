# import os
# import base64
# import requests
# from datetime import datetime
# from django.conf import settings
# from jinja2 import Environment, FileSystemLoader
# import json

# class GitHubIntegration:
#     def __init__(self):
#         self.github_token = getattr(settings, 'CLOUD_GITHUB_TOKEN', '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')
#         self.repo_owner = getattr(settings, 'CLOUD_GITHUB_REPO_OWNER', 'PythonwithAvinashSharma')
#         self.repo_name = getattr(settings, 'CLOUD_GITHUB_REPO_NAME', 'terraform-aws-vpc')
#         self.base_url = f"https://api.github.com/repos/{self.repo_owner}/{self.repo_name}"
        
#         if not self.github_token:
#             raise ValueError("GitHub token not configured")
    
#     def render_terraform_templates(self, vpc_request):
#         """Render Terraform files using Jinja2 templates"""
#         # Setup Jinja2 environment
#         template_dir = os.path.join(
#             os.path.dirname(__file__), 'templates', 'terraform'
#         )
#         jinja_env = Environment(loader=FileSystemLoader(template_dir))
        
#         # Prepare template context
#         context = {
#             'vpc_name': vpc_request.vpc_name,
#             'aws_region': vpc_request.aws_region,
#             'vpc_cidr': vpc_request.vpc_cidr,
#             'public_subnets': vpc_request.public_subnets or [],
#             'private_subnets': vpc_request.private_subnets or [],
#             'enable_nat_gateway': vpc_request.enable_nat_gateway,
#             'enable_vpn_gateway': vpc_request.enable_vpn_gateway,
#             'enable_dns_hostnames': vpc_request.enable_dns_hostnames,
#             'enable_dns_support': vpc_request.enable_dns_support,
#             'tags': {
#                 'Name': vpc_request.vpc_name,
#                 'Environment': vpc_request.custom_tags.get('Environment', 'dev') if vpc_request.custom_tags else 'dev',
#                 'Terraform': 'true',
#                 'ManagedBy': 'nautobot',
#                 'RequestID': str(vpc_request.request_id),
#                 'Template': vpc_request.template.template_type,
#                 **(vpc_request.custom_tags or {})
#             }
#         }
        
#         # Render templates
#         rendered_files = {}
#         template_files = [
#             'main.tf.j2',
#             'variables.tf.j2', 
#             'outputs.tf.j2',
#             'terraform.tfvars.j2'
#         ]
        
#         for template_file in template_files:
#             try:
#                 template = jinja_env.get_template(template_file)
#                 rendered_content = template.render(context)
#                 file_name = template_file.replace('.j2', '')
#                 rendered_files[file_name] = rendered_content
#             except Exception as e:
#                 print(f"Error rendering {template_file}: {e}")
        
#         return rendered_files
    
#     def create_branch(self, branch_name):
#         """Create a new branch for the VPC configuration"""
#         # Get main branch SHA
#         main_ref_url = f"{self.base_url}/git/ref/heads/master"
#         headers = {
#             'Authorization': f'token {self.github_token}',
#             'Accept': 'application/vnd.github.v3+json'
#         }
        
#         response = requests.get(main_ref_url, headers=headers)
#         if response.status_code != 200:
#             raise Exception(f"Failed to get main branch: {response.text}")
        
#         main_sha = response.json()['object']['sha']
        
#         # Create new branch
#         create_ref_url = f"{self.base_url}/git/refs"
#         branch_data = {
#             'ref': f'refs/heads/{branch_name}',
#             'sha': main_sha
#         }
        
#         response = requests.post(create_ref_url, json=branch_data, headers=headers)
#         if response.status_code not in [201, 422]:  # 422 if branch already exists
#             raise Exception(f"Failed to create branch: {response.text}")
        
#         return branch_name
    
#     def commit_files(self, branch_name, files, commit_message):
#         """Commit files to the specified branch"""
#         headers = {
#             'Authorization': f'token {self.github_token}',
#             'Accept': 'application/vnd.github.v3+json'
#         }
        
#         # Create/update each file
#         for file_path, content in files.items():
#             #file_url = f"{self.base_url}/contents/environments/{branch_name}/{file_path}"
#             file_url = f"{self.base_url}/contents/{file_path}"
#             # Check if file exists
#             response = requests.get(file_url, headers=headers)
            
#             file_data = {
#                 'message': commit_message,
#                 'content': base64.b64encode(content.encode()).decode(),
#                 'branch': branch_name
#             }
            
#             if response.status_code == 200:
#                 # File exists, update it
#                 file_data['sha'] = response.json()['sha']
#                 method = requests.put
#             else:
#                 # File doesn't exist, create it
#                 method = requests.put
            
#             response = method(file_url, json=file_data, headers=headers)
#             if response.status_code not in [200, 201]:
#                 raise Exception(f"Failed to commit {file_path}: {response.text}")
    
#     def create_pull_request(self, branch_name, vpc_request):
#         """Create a pull request for the VPC configuration"""
#         headers = {
#             'Authorization': f'token {self.github_token}',
#             'Accept': 'application/vnd.github.v3+json'
#         }
        
#         pr_data = {
#             'title': f"Add VPC configuration: {vpc_request.vpc_name}",
#             'head': branch_name,
#             'base': 'master',
#             'body': f"""
# ## VPC Configuration Request

# **VPC Name:** {vpc_request.vpc_name}  
# **Template:** {vpc_request.template.name}  
# **Region:** {vpc_request.aws_region}  
# **CIDR:** {vpc_request.vpc_cidr}  
# **Requester:** {vpc_request.requester_name}  

# ### Features Enabled:
# - NAT Gateway: {'✅' if vpc_request.enable_nat_gateway else '❌'}
# - VPN Gateway: {'✅' if vpc_request.enable_vpn_gateway else '❌'}
# - DNS Hostnames: {'✅' if vpc_request.enable_dns_hostnames else '❌'}
# - DNS Support: {'✅' if vpc_request.enable_dns_support else '❌'}


# **Request ID:** {vpc_request.request_id}
# **Generated by:** Nautobot VPC Catalog
# """
#         }
        
#         pr_url = f"{self.base_url}/pulls"
#         response = requests.post(pr_url, json=pr_data, headers=headers)
        
#         if response.status_code == 201:
#             return response.json()
#         else:
#             raise Exception(f"Failed to create PR: {response.text}")
    
#     def trigger_workflow(self, workflow_name, branch_name, vpc_request):
#         """Trigger GitHub Actions workflow"""
#         headers = {
#             'Authorization': f'token {self.github_token}',
#             'Accept': 'application/vnd.github.v3+json'
#         }
        
#         workflow_data = {
#             'ref': branch_name,
#             'inputs': {
#                 'vpc_request_id': str(vpc_request.request_id),
#                 'vpc_name': vpc_request.vpc_name,
#                 'aws_region': vpc_request.aws_region,
#                 'terraform_action': 'plan'
#             }
#         }
        
#         workflow_url = f"{self.base_url}/actions/workflows/{workflow_name}/dispatches"
#         response = requests.post(workflow_url, json=workflow_data, headers=headers)
        
#         if response.status_code == 204:
#             return True
#         else:
#             raise Exception(f"Failed to trigger workflow: {response.text}")

# def provision_vpc_to_github(vpc_request):
#     """Main function to provision VPC configuration to GitHub"""
#     try:
#         github = GitHubIntegration()
        
#         # Create branch name
#         timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")
#         branch_name = f"vpc-{vpc_request.vpc_name}-{timestamp}"
        
#         # Render Terraform templates
#         rendered_files = github.render_terraform_templates(vpc_request)
        
#         # Create branch
#         github.create_branch(branch_name)
        
#         # Commit files
#         commit_message = f"Add VPC configuration for {vpc_request.vpc_name}\n\nGenerated by Nautobot VPC Catalog\nRequest ID: {vpc_request.request_id}"
#         github.commit_files(branch_name, rendered_files, commit_message)
        
#         # Create pull request
#         pr_info = github.create_pull_request(branch_name, vpc_request)
        
#         # Update VPC request with GitHub info
#         vpc_request.git_branch = branch_name
#         vpc_request.status = 'submitted'
#         vpc_request.save()
        
#         return {
#             'success': True,
#             'branch': branch_name,
#             'pr_url': pr_info['html_url'],
#             'pr_number': pr_info['number'],
#             'files': list(rendered_files.keys())
#         }
        
#     except Exception as e:
#         return {
#             'success': False,
#             'error': str(e)
#         }

import os
import base64
import requests
from datetime import datetime
from django.conf import settings
from jinja2 import Environment, FileSystemLoader
import json

class GitHubIntegration:
    def __init__(self):
        self.github_token = getattr(settings, 'CLOUD_GITHUB_TOKEN', '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')
        self.repo_owner = getattr(settings, 'CLOUD_GITHUB_REPO_OWNER', 'PythonwithAvinashSharma')
        self.repo_name = getattr(settings, 'CLOUD_GITHUB_REPO_NAME', 'terraform-aws-vpc')
        self.base_url = f"https://api.github.com/repos/{self.repo_owner}/{self.repo_name}"
        
        if not self.github_token:
            raise ValueError("GitHub token not configured")
        
        # Cache the default branch
        self._default_branch = None
    
    def get_default_branch(self):
        """Get the default branch for the repository"""
        if self._default_branch:
            return self._default_branch
            
        headers = {
            'Authorization': f'token {self.github_token}',
            'Accept': 'application/vnd.github.v3+json'
        }
        
        # Get repository info to find default branch
        response = requests.get(self.base_url, headers=headers)
        if response.status_code == 200:
            self._default_branch = response.json().get('default_branch', 'main')
        else:
            # Fallback: try master first, then main
            for branch in ['master', 'main']:
                test_url = f"{self.base_url}/git/ref/heads/{branch}"
                test_response = requests.get(test_url, headers=headers)
                if test_response.status_code == 200:
                    self._default_branch = branch
                    break
            else:
                self._default_branch = 'main'  # Ultimate fallback
        
        return self._default_branch

    def render_terraform_tfvars(self, vpc_request):
        """Render only the terraform.tfvars file using Jinja2 template"""
        # Setup Jinja2 environment
        template_dir = os.path.join(
            os.path.dirname(__file__), 'templates', 'terraform'
        )
        jinja_env = Environment(loader=FileSystemLoader(template_dir))
        
        # Prepare template context
        context = {
            'vpc_name': vpc_request.vpc_name,
            'aws_region': vpc_request.aws_region,
            'vpc_cidr': vpc_request.vpc_cidr,
            'public_subnets': vpc_request.public_subnets or [],
            'private_subnets': vpc_request.private_subnets or [],
            'enable_nat_gateway': vpc_request.enable_nat_gateway,
            'enable_vpn_gateway': vpc_request.enable_vpn_gateway,
            'enable_dns_hostnames': vpc_request.enable_dns_hostnames,
            'enable_dns_support': vpc_request.enable_dns_support,
            'tags': {
                'Name': vpc_request.vpc_name,
                'Environment': vpc_request.custom_tags.get('Environment', 'dev') if vpc_request.custom_tags else 'dev',
                'Terraform': 'true',
                'ManagedBy': 'nautobot',
                'RequestID': str(vpc_request.request_id),
                'Template': vpc_request.template.template_type,
                **(vpc_request.custom_tags or {})
            }
        }
        
        # Render only terraform.tfvars template
        try:
            template = jinja_env.get_template('terraform.tfvars.j2')
            rendered_content = template.render(context)
            return {'terraform.tfvars': rendered_content}
        except Exception as e:
            print(f"Error rendering terraform.tfvars.j2: {e}")
            raise Exception(f"Failed to render terraform.tfvars template: {e}")
    
    def create_branch(self, branch_name):
        """Create a new branch for the VPC configuration"""
        # Get default branch SHA
        default_branch = self.get_default_branch()
        main_ref_url = f"{self.base_url}/git/ref/heads/{default_branch}"
        headers = {
            'Authorization': f'token {self.github_token}',
            'Accept': 'application/vnd.github.v3+json'
        }
        
        response = requests.get(main_ref_url, headers=headers)
        if response.status_code != 200:
            raise Exception(f"Failed to get {default_branch} branch: {response.text}")
        
        main_sha = response.json()['object']['sha']
        
        # Create new branch
        create_ref_url = f"{self.base_url}/git/refs"
        branch_data = {
            'ref': f'refs/heads/{branch_name}',
            'sha': main_sha
        }
        
        response = requests.post(create_ref_url, json=branch_data, headers=headers)
        if response.status_code not in [201, 422]:  # 422 if branch already exists
            raise Exception(f"Failed to create branch: {response.text}")
        
        return branch_name
    
    def commit_tfvars_file(self, branch_name, tfvars_content, commit_message):
        """Commit only the terraform.tfvars file to the specified branch"""
        headers = {
            'Authorization': f'token {self.github_token}',
            'Accept': 'application/vnd.github.v3+json'
        }
        
        # Commit terraform.tfvars file to root directory
        file_url = f"{self.base_url}/contents/terraform.tfvars"
        
        # Check if file exists
        response = requests.get(file_url, headers=headers)
        
        file_data = {
            'message': commit_message,
            'content': base64.b64encode(tfvars_content.encode()).decode(),
            'branch': branch_name
        }
        
        if response.status_code == 200:
            # File exists, update it
            file_data['sha'] = response.json()['sha']
        
        response = requests.put(file_url, json=file_data, headers=headers)
        if response.status_code not in [200, 201]:
            raise Exception(f"Failed to commit terraform.tfvars: {response.text}")
        
        print(f"Successfully committed terraform.tfvars to branch {branch_name}")
    
    def create_pull_request(self, branch_name, vpc_request):
        """Create a pull request for the VPC configuration"""
        headers = {
            'Authorization': f'token {self.github_token}',
            'Accept': 'application/vnd.github.v3+json'
        }
        
        # Use the correct default branch as the target
        default_branch = self.get_default_branch()
        
        pr_data = {
            'title': f"Update terraform.tfvars for VPC: {vpc_request.vpc_name}",
            'head': branch_name,
            'base': default_branch,
            'body': f"""
## VPC Configuration Update

**VPC Name:** {vpc_request.vpc_name}  
**Template:** {vpc_request.template.name}  
**Region:** {vpc_request.aws_region}  
**CIDR:** {vpc_request.vpc_cidr}  
**Requester:** {vpc_request.requester_name}  

### Features Enabled:
- NAT Gateway: {'✅' if vpc_request.enable_nat_gateway else '❌'}
- VPN Gateway: {'✅' if vpc_request.enable_vpn_gateway else '❌'}
- DNS Hostnames: {'✅' if vpc_request.enable_dns_hostnames else '❌'}
- DNS Support: {'✅' if vpc_request.enable_dns_support else '❌'}

### Files Updated:
- 📝 `terraform.tfvars` - VPC configuration variables


**Request ID:** {vpc_request.request_id}  
**Generated by:** Nautobot VPC Catalog
"""
        }
        
        pr_url = f"{self.base_url}/pulls"
        response = requests.post(pr_url, json=pr_data, headers=headers)
        
        if response.status_code == 201:
            return response.json()
        else:
            raise Exception(f"Failed to create PR: {response.text}")
    
    def trigger_workflow(self, workflow_name, branch_name, vpc_request):
        """Trigger GitHub Actions workflow"""
        headers = {
            'Authorization': f'token {self.github_token}',
            'Accept': 'application/vnd.github.v3+json'
        }
        
        workflow_data = {
            'ref': branch_name,
            'inputs': {
                'vpc_request_id': str(vpc_request.request_id),
                'vpc_name': vpc_request.vpc_name,
                'aws_region': vpc_request.aws_region,
                'terraform_action': 'plan'
            }
        }
        
        workflow_url = f"{self.base_url}/actions/workflows/{workflow_name}/dispatches"
        response = requests.post(workflow_url, json=workflow_data, headers=headers)
        
        if response.status_code == 204:
            return True
        else:
            raise Exception(f"Failed to trigger workflow: {response.text}")

def provision_vpc_to_github(vpc_request):
    """Main function to provision only terraform.tfvars to GitHub"""
    try:
        github = GitHubIntegration()
        
        # Create branch name
        timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")
        branch_name = f"vpc-{vpc_request.vpc_name}-{timestamp}"
        
        # Render only terraform.tfvars template
        tfvars_files = github.render_terraform_tfvars(vpc_request)
        tfvars_content = tfvars_files['terraform.tfvars']
        
        # Create branch
        github.create_branch(branch_name)
        
        # Commit only terraform.tfvars file
        commit_message = f"Update terraform.tfvars for VPC {vpc_request.vpc_name}\n\nGenerated by Nautobot VPC Catalog\nRequest ID: {vpc_request.request_id}"
        github.commit_tfvars_file(branch_name, tfvars_content, commit_message)
        
        # Create pull request
        pr_info = github.create_pull_request(branch_name, vpc_request)
        
        # Update VPC request with GitHub info
        vpc_request.git_branch = branch_name
        vpc_request.status = 'submitted'
        vpc_request.save()
        
        return {
            'success': True,
            'branch': branch_name,
            'pr_url': pr_info['html_url'],
            'pr_number': pr_info['number'],
            'files': ['terraform.tfvars']
        }
        
    except Exception as e:
        return {
            'success': False,
            'error': str(e)
        }