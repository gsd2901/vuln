from django.db import models
from nautobot.core.models import BaseModel
from nautobot.extras.models import StatusModel
from nautobot.extras.models import CustomFieldModel, RelationshipModel
from nautobot.extras.utils import extras_features
import uuid
import json

@extras_features(
    "custom_fields",
    "custom_links", 
    "export_templates",
    "relationships",
    "statuses",
    "webhooks"
)
class VPCTemplate(BaseModel, StatusModel):
    """VPC Templates for catalog"""
    
    TEMPLATE_TYPES = (
        ('onprem-connected', 'On-Premises Connected'),
        ('cloud-only', 'Cloud Only'),
    )
    
    name = models.CharField(max_length=100, unique=True)
    template_type = models.CharField(max_length=20, choices=TEMPLATE_TYPES)
    description = models.TextField(blank=True)
    
    # Default values
    default_cidr = models.CharField(max_length=18, default="10.0.0.0/24")
    default_public_subnets = models.JSONField(default=list)
    default_private_subnets = models.JSONField(default=list)
    default_tags = models.JSONField(default=dict)
    
    # Terraform configuration
    terraform_template_path = models.CharField(max_length=255)
    
    # Auto-fill rules
    auto_fill_enabled = models.BooleanField(default=True)
    
    created = models.DateTimeField(auto_now_add=True)
    last_updated = models.DateTimeField(auto_now=True)
    
    class Meta:
        ordering = ['name']
    
    def __str__(self):
        return f"{self.name} ({self.get_template_type_display()})"

@extras_features(
    "custom_fields",
    "custom_links",
    "export_templates", 
    "relationships",
    "statuses",
    "webhooks"
)
class VPCRequest(BaseModel, StatusModel):
    """VPC Provisioning Requests"""
    
    REQUEST_STATUS = (
        ('draft', 'Draft'),
        ('submitted', 'Submitted'),
        ('approved', 'Approved'),
        ('provisioning', 'Provisioning'),
        ('active', 'Active'),
        ('failed', 'Failed'),
        ('decommissioned', 'Decommissioned'),
    )
    
    # Request identification
    request_id = models.UUIDField(default=uuid.uuid4, unique=True)
    requester_name = models.CharField(max_length=100)
    requester_email = models.EmailField()
    
    # VPC Configuration
    template = models.ForeignKey(VPCTemplate, on_delete=models.CASCADE)
    vpc_name = models.CharField(max_length=100)
    aws_region = models.CharField(max_length=20, default='us-east-1')
    
    # Network Configuration
    vpc_cidr = models.CharField(max_length=18)
    public_subnets = models.JSONField(default=list)
    private_subnets = models.JSONField(default=list)
    
    # Features
    enable_nat_gateway = models.BooleanField(default=True)
    enable_vpn_gateway = models.BooleanField(default=False)
    enable_dns_hostnames = models.BooleanField(default=True)
    enable_dns_support = models.BooleanField(default=True)
    
    # Tags
    custom_tags = models.JSONField(default=dict)
    
    # Status tracking
    status = models.CharField(max_length=20, choices=REQUEST_STATUS, default='draft')
    approval_notes = models.TextField(blank=True)
    
    # CI/CD Integration
    pipeline_id = models.CharField(max_length=100, blank=True, null=True)
    git_branch = models.CharField(max_length=100, blank=True, null=True)
    
    # AWS Resource tracking (populated after provisioning)
    vpc_id = models.CharField(max_length=50, blank=True, null=True)
    resource_ids = models.JSONField(default=dict, blank=True)
    
    created = models.DateTimeField(auto_now_add=True)
    last_updated = models.DateTimeField(auto_now=True)
    
    class Meta:
        ordering = ['-created']
    
    def __str__(self):
        return f"{self.vpc_name} - {self.get_status_display()}"
    
    @property
    def estimated_monthly_cost(self):
        """Calculate estimated monthly AWS cost"""
        base_cost = 0.0
        if self.enable_nat_gateway:
            # NAT Gateway: ~$32/month per gateway
            nat_gateways = len(self.public_subnets) if self.public_subnets else 1
            base_cost += nat_gateways * 32.0
        return base_cost