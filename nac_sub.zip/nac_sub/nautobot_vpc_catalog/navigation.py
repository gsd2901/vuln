from nautobot.apps.ui import NavMenuAddButton, NavMenuGroup, NavMenuItem, NavMenuTab

menu_items = (
    NavMenuTab(
        name="VPC Catalog",
        groups=(
            NavMenuGroup(
                name="Provisioning",
                weight=100,
                items=(
                    NavMenuItem(
                        link="plugins:nautobot_vpc_catalog:vpc_catalog",
                        name="VPC Catalog",
                        permissions=["nautobot_vpc_catalog.view_vpcrequest"],
                        buttons=(
                            NavMenuAddButton(
                                link="plugins:nautobot_vpc_catalog:vpc_catalog",
                                title="Create VPC",
                                icon_class="fas fa-plus"
                            ),
                        ),
                    ),
                    NavMenuItem(
                        link="plugins:nautobot_vpc_catalog:vpc_requests_list",
                        name="My Requests",
                        permissions=["nautobot_vpc_catalog.view_vpcrequest"],
                    ),
                ),
            ),
            NavMenuGroup(
                name="Administration", 
                weight=200,
                items=(
                    NavMenuItem(
                        link="plugins:nautobot_vpc_catalog:vpc_templates_list",
                        name="VPC Templates",
                        permissions=["nautobot_vpc_catalog.view_vpctemplate"],
                        buttons=(
                            NavMenuAddButton(
                                link="admin:nautobot_vpc_catalog_vpctemplate_add",
                                title="Add Template"
                            ),
                        ),
                    ),
                ),
            ),
        ),
    ),
)