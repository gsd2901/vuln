from django.urls import path, include
from . import views

app_name = 'nautobot_vpc_catalog'

urlpatterns = [
    # Main catalog page
    path('', views.vpc_catalog_view, name='vpc_catalog'),
    
    # VPC request form
    path('request/<uuid:template_id>/', views.vpc_request_form_view, name='vpc_request_form'),
    
    # VPC request detail
    path('request/detail/<uuid:request_id>/', views.vpc_detail_view, name='vpc_detail'),
    
    # AJAX endpoints
    path('api/auto-fill/', views.auto_fill_network_config, name='auto_fill_network_config'),
    path('api/trigger-pipeline/<uuid:request_id>/', views.trigger_pipeline, name='trigger_pipeline'),
    
    # Management views
    path('requests/', views.vpc_requests_list_view, name='vpc_requests_list'),
    path('templates/', views.vpc_templates_list_view, name='vpc_templates_list'),
    
    # Include API URLs
    path('api/', include('nautobot_vpc_catalog.api.urls')),

    path('request/preview/<uuid:request_id>/', views.vpc_preview_view, name='vpc_preview'),
    path('api/submit-github/<uuid:request_id>/', views.submit_to_github, name='submit_to_github'),
    path('api/preview-terraform/', views.preview_terraform, name='preview_terraform'),
]