/**
 * VPC Catalog JavaScript functionality
 */

$(document).ready(function() {
    // Initialize tooltips
    $('[data-toggle="tooltip"]').tooltip();
    
    // Initialize cost calculator
    initializeCostCalculator();
    
    // Setup form validations
    setupFormValidation();
});

/**
 * Initialize cost calculator functionality
 */
function initializeCostCalculator() {
    // Update costs when checkboxes change
    $(document).on('change', 'input[type="checkbox"]', function() {
        updateCostCalculation();
    });
    
    // Update costs when region changes (different pricing)
    $(document).on('change', '#id_aws_region', function() {
        updateRegionalPricing();
    });
}

/**
 * Update cost calculation based on selected features
 */
function updateCostCalculation() {
    let totalCost = 0;
    let costBreakdown = [];
    
    // NAT Gateway cost (varies by region)
    if ($('#id_enable_nat_gateway').is(':checked')) {
        const region = $('#id_aws_region').val();
        const natCost = getNATGatewayCost(region);
        totalCost += natCost;
        costBreakdown.push(`NAT Gateway: $${natCost}`);
    }
    
    // VPN Gateway cost
    if ($('#id_enable_vpn_gateway').is(':checked')) {
        totalCost += 36;
        costBreakdown.push('VPN Gateway: $36');
    }
    
    // Update UI
    $('#estimatedCost').text('$' + totalCost);
    $('.cost-breakdown').html(costBreakdown.map(item => `<small>${item}</small>`).join('<br>'));
}

/**
 * Get NAT Gateway cost based on AWS region
 */
function getNATGatewayCost(region) {
    const pricing = {
        'us-east-1': 32,
        'us-west-2': 32,
        'eu-west-1': 36,
        'ap-southeast-1': 38
    };
    return pricing[region] || 32;
}

/**
 * Update regional pricing when region changes
 */
function updateRegionalPricing() {
    updateCostCalculation();
}

/**
 * Setup form validation
 */
function setupFormValidation() {
    // Real-time CIDR validation
    $(document).on('input', '#id_vpc_cidr', function() {
        validateCIDR($(this));
    });
    
    // VPC name validation
    $(document).on('input', '#id_vpc_name', function() {
        validateVPCName($(this));
    });
    
    // JSON tags validation
    $(document).on('blur', '#id_custom_tags', function() {
        validateJSON($(this));
    });
}

/**
 * Validate CIDR format
 */
function validateCIDR(input) {
    const cidr = input.val().trim();
    const cidrRegex = /^(\d{1,3}\.){3}\d{1,3}\/\d{1,2}$/;
    
    // Clear previous states
    input.removeClass('is-valid is-invalid');
    input.siblings('.feedback').remove();
    
    if (!cidr) return;
    
    if (!cidrRegex.test(cidr)) {
        input.addClass('is-invalid');
        input.after('<div class="invalid-feedback feedback">Invalid CIDR format</div>');
        return;
    }
    
    input.addClass('is-valid');
}

/**
 * Validate VPC name format
 */
function validateVPCName(input) {
    const name = input.val().trim();
    const nameRegex = /^[a-zA-Z][a-zA-Z0-9-]*$/;
    
    input.removeClass('is-valid is-invalid');
    input.siblings('.feedback').remove();
    
    if (!name) return;
    
    if (name.length < 3 || name.length > 50) {
        input.addClass('is-invalid');
        input.after('<div class="invalid-feedback feedback">Name must be 3-50 characters</div>');
        return;
    }
    
    if (!nameRegex.test(name)) {
        input.addClass('is-invalid');
        input.after('<div class="invalid-feedback feedback">Name must start with letter, contain only alphanumeric and hyphens</div>');
        return;
    }
    
    input.addClass('is-valid');
}

/**
 * Validate JSON format
 */
function validateJSON(input) {
    const jsonStr = input.val().trim();
    
    input.removeClass('is-valid is-invalid');
    input.siblings('.feedback').remove();
    
    if (!jsonStr) {
        input.addClass('is-valid');
        return;
    }
    
    try {
        const parsed = JSON.parse(jsonStr);
        if (typeof parsed !== 'object' || Array.isArray(parsed)) {
            throw new Error('Must be an object');
        }
        input.addClass('is-valid');
        input.after('<div class="valid-feedback feedback">Valid JSON format</div>');
    } catch (e) {
        input.addClass('is-invalid');
        input.after('<div class="invalid-feedback feedback">Invalid JSON format</div>');
    }
}

/**
 * Show notification messages
 */
function showNotification(message, type = 'info', duration = 5000) {
    const alertClass = {
        'success': 'alert-success',
        'error': 'alert-danger', 
        'warning': 'alert-warning',
        'info': 'alert-info'
    }[type] || 'alert-info';
    
    const notification = $(`
        <div class="alert ${alertClass} alert-dismissible fade show notification" role="alert">
            <i class="fas fa-${type === 'success' ? 'check-circle' : type === 'error' ? 'exclamation-triangle' : 'info-circle'}"></i>
            ${message}
            <button type="button" class="close" data-dismiss="alert">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    `);
    
    // Add to notification container or create one
    let container = $('.notification-container');
    if (container.length === 0) {
        container = $('<div class="notification-container"></div>').prependTo('body');
    }
    
    container.prepend(notification);
    
    // Auto-dismiss after duration
    if (duration > 0) {
        setTimeout(() => {
            notification.alert('close');
        }, duration);
    }
}

// Export functionality for other modules
window.VPCCatalog = {
    showNotification,
    updateCostCalculation,
    validateCIDR,
    validateJSON
};