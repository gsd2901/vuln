from django.shortcuts import render, get_object_or_404, redirect
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_http_methods
import json
import ipaddress

from .models import VPCTemplate, VPCRequest
from .forms import VPCRequestForm
from .utils import IPAllocator, generate_terraform_vars

# Add these functions to your existing views.py

from django.http import JsonResponse, HttpResponse
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_http_methods
import json

from .github_integration import GitHubIntegration, provision_vpc_to_github

@login_required
def vpc_catalog_view(request):
    """Main catalog page"""
    templates = VPCTemplate.objects.filter(status__name='Active')
    
    context = {
        'templates': templates,
        'user_requests': VPCRequest.objects.filter(
            requester_email=request.user.email
        )[:5]
    }
    return render(request, 'nautobot_vpc_catalog/vpc_catalog.html', context)

@login_required 
def vpc_request_form_view(request, template_id):
    """VPC Request Form"""
    template = get_object_or_404(VPCTemplate, id=template_id)
    
    if request.method == 'POST':
        print("DEBUG POST data:", request.POST)
        form = VPCRequestForm(request.POST, template=template)
        if form.is_valid():
            vpc_request = form.save(commit=False)
            vpc_request.template = template
            vpc_request.requester_email = request.user.email
            vpc_request.requester_name = request.user.get_full_name() or request.user.username
            vpc_request.save()
            
            messages.success(request, f'VPC request "{vpc_request.vpc_name}" created successfully!')
            return redirect('plugins:nautobot_vpc_catalog:vpc_preview', request_id=vpc_request.request_id)
    else:
        # Pre-populate form with template defaults
        initial_data = {
            'vpc_cidr': template.default_cidr,
            'public_subnets': template.default_public_subnets,
            'private_subnets': template.default_private_subnets,
            'custom_tags': template.default_tags,
        }
        
        # Auto-generate IP allocations for on-prem connected
        if template.template_type == 'onprem-connected':
            allocator = IPAllocator()
            allocated_cidr = allocator.get_next_available_cidr()
            if allocated_cidr:
                initial_data['vpc_cidr'] = allocated_cidr
                initial_data['public_subnets'] = allocator.generate_public_subnets(allocated_cidr)
                initial_data['private_subnets'] = allocator.generate_private_subnets(allocated_cidr)
        
        form = VPCRequestForm(initial=initial_data, template=template)

        print(f"DEBUG: Form aws_region choices: {form.fields['aws_region'].choices}")

    context = {
        'form': form,
        'template': template,
        'estimated_cost': 32.0  # Base NAT Gateway cost
    }
    return render(request, 'nautobot_vpc_catalog/vpc_request_form.html', context)

@login_required
def vpc_detail_view(request, request_id):
    """VPC Request Detail"""
    vpc_request = get_object_or_404(VPCRequest, request_id=request_id)
    
    context = {
        'vpc_request': vpc_request,
        'terraform_vars': generate_terraform_vars(vpc_request)
    }
    return render(request, 'nautobot_vpc_catalog/vpc_detail.html', context)

@csrf_exempt
@require_http_methods(["POST"])
def auto_fill_network_config(request):
    """AJAX endpoint for auto-filling network configuration"""
    try:
        data = json.loads(request.body)
        template_type = data.get('template_type')
        
        if template_type == 'onprem-connected':
            allocator = IPAllocator()
            cidr = allocator.get_next_available_cidr()
            
            if cidr:
                response_data = {
                    'vpc_cidr': cidr,
                    'public_subnets': allocator.generate_public_subnets(cidr),
                    'private_subnets': allocator.generate_private_subnets(cidr),
                    'tags': {
                        'Environment': 'onprem-connected',
                        'Terraform': 'true',
                        'ManagedBy': 'nautobot'
                    }
                }
                return JsonResponse(response_data)
        
        return JsonResponse({'error': 'Unable to auto-fill configuration'}, status=400)
        
    except Exception as e:
        return JsonResponse({'error': str(e)}, status=500)

@csrf_exempt 
@require_http_methods(["POST"])
def trigger_pipeline(request, request_id):
    """Trigger CI/CD pipeline for VPC provisioning"""
    vpc_request = get_object_or_404(VPCRequest, request_id=request_id)
    
    if vpc_request.status != 'approved':
        return JsonResponse({'error': 'Request must be approved first'}, status=400)
    
    try:
        # Update status
        vpc_request.status = 'provisioning'
        vpc_request.save()
        
        # Trigger CI/CD pipeline (implement based on your CI/CD system)
        pipeline_result = trigger_cicd_pipeline(vpc_request)
        
        if pipeline_result.get('success'):
            vpc_request.pipeline_id = pipeline_result.get('pipeline_id')
            vpc_request.git_branch = pipeline_result.get('branch')
            vpc_request.save()
            
            return JsonResponse({
                'success': True,
                'pipeline_id': pipeline_result.get('pipeline_id'),
                'pipeline_url': pipeline_result.get('url')
            })
        else:
            vpc_request.status = 'failed'
            vpc_request.save()
            return JsonResponse({'error': 'Failed to trigger pipeline'}, status=500)
            
    except Exception as e:
        vpc_request.status = 'failed'
        vpc_request.save()
        return JsonResponse({'error': str(e)}, status=500)

def trigger_cicd_pipeline(vpc_request):
    """Integrate with your CI/CD system"""
    # This would integrate with GitLab CI, GitHub Actions, Jenkins, etc.
    # Return pipeline details
    pass


def vpc_requests_list_view(request):
    """List view for VPC requests"""
    from .tables import VPCRequestTable
    from .filters import VPCRequestFilterSet
    
    queryset = VPCRequest.objects.all()
    
    # Filter by user if not staff
    if not request.user.is_staff:
        queryset = queryset.filter(requester_email=request.user.email)
    
    filterset = VPCRequestFilterSet(request.GET, queryset=queryset)
    table = VPCRequestTable(filterset.qs)
    
    context = {
        'table': table,
        'filter_form': filterset.form,
        'active_tab': 'vpc_requests'
    }
    return render(request, 'generic/object_list.html', context)

def vpc_templates_list_view(request):
    """List view for VPC templates"""
    from .tables import VPCTemplateTable
    from .filters import VPCTemplateFilterSet
    
    queryset = VPCTemplate.objects.all()
    filterset = VPCTemplateFilterSet(request.GET, queryset=queryset)
    table = VPCTemplateTable(filterset.qs)
    
    context = {
        'table': table,
        'filter_form': filterset.form,
        'active_tab': 'vpc_templates'
    }
    return render(request, 'generic/object_list.html', context)

# @login_required
# def vpc_preview_view(request, request_id):
#     """Preview VPC configuration before GitHub submission"""
#     vpc_request = get_object_or_404(VPCRequest, request_id=request_id)
    
#     # Check if user owns this request (unless admin)
#     if not request.user.is_staff and vpc_request.requester_email != request.user.email:
#         messages.error(request, "You don't have permission to view this request.")
#         return redirect('plugins:nautobot_vpc_catalog:vpc_catalog')
    
#     # Generate Terraform preview
#     try:
#         github = GitHubIntegration()
#         rendered_files = github.render_terraform_templates(vpc_request)
        
#         terraform_preview = rendered_files.get('main.tf', 'Error generating preview')
#         terraform_vars = rendered_files.get('terraform.tfvars', 'Error generating variables')
        
#     except Exception as e:
#         terraform_preview = f"Error generating Terraform preview: {str(e)}"
#         terraform_vars = "Error generating variables"
#         rendered_files = {}
    
#     context = {
#         'vpc_request': vpc_request,
#         'terraform_preview': terraform_preview,
#         'terraform_vars': terraform_vars,
#         'rendered_files': rendered_files,
#         'can_submit': vpc_request.status in ['draft', 'failed']
#     }
#     return render(request, 'nautobot_vpc_catalog/vpc_preview.html', context)


@login_required
def vpc_preview_view(request, request_id):
    """Preview VPC configuration before GitHub submission"""
    vpc_request = get_object_or_404(VPCRequest, request_id=request_id)
    
    # Check if user owns this request (unless admin)
    if not request.user.is_staff and vpc_request.requester_email != request.user.email:
        messages.error(request, "You don't have permission to view this request.")
        return redirect('plugins:nautobot_vpc_catalog:vpc_catalog')
    
    # Generate Terraform preview
    try:
        github = GitHubIntegration()
        # Use the correct method that actually exists
        rendered_files = github.render_terraform_tfvars(vpc_request)
        
        # Since you're only generating terraform.tfvars, adjust accordingly
        terraform_vars = rendered_files.get('terraform.tfvars', 'Error generating variables')
        terraform_preview = 'Only terraform.tfvars is generated for this workflow'
        
    except Exception as e:
        print(f"Error in vpc_preview_view: {e}")  # Debug output
        terraform_preview = f"Error generating Terraform preview: {str(e)}"
        terraform_vars = f"Error generating variables: {str(e)}"
        rendered_files = {}
    
    context = {
        'vpc_request': vpc_request,
        'terraform_preview': terraform_preview,
        'terraform_vars': terraform_vars,
        'rendered_files': rendered_files,
        'can_submit': vpc_request.status in ['draft', 'failed']
    }
    return render(request, 'nautobot_vpc_catalog/vpc_preview.html', context)

@csrf_exempt
@require_http_methods(["POST"])
@login_required
def submit_to_github(request, request_id):
    """Submit VPC configuration to GitHub"""
    vpc_request = get_object_or_404(VPCRequest, request_id=request_id)
    
    # Check permissions
    if not request.user.is_staff and vpc_request.requester_email != request.user.email:
        return JsonResponse({'error': 'Permission denied'}, status=403)
    
    if vpc_request.status not in ['draft', 'failed']:
        return JsonResponse({'error': 'Request cannot be submitted in current status'}, status=400)
    
    try:
        # Submit to GitHub
        result = provision_vpc_to_github(vpc_request)
        
        if result['success']:
            return JsonResponse({
                'success': True,
                'message': 'VPC configuration submitted to GitHub successfully!',
                'branch': result['branch'],
                'pr_url': result['pr_url'],
                'pr_number': result['pr_number'],
                'files': result['files']
            })
        else:
            return JsonResponse({
                'success': False,
                'error': result['error']
            }, status=500)
            
    except Exception as e:
        vpc_request.status = 'failed'
        vpc_request.save()
        return JsonResponse({'error': str(e)}, status=500)

@csrf_exempt
@require_http_methods(["POST"])
@login_required
def preview_terraform(request):
    """AJAX endpoint to preview Terraform configuration"""
    try:
        data = json.loads(request.body)
        
        # Create a temporary VPC request object for preview
        class TempVPCRequest:
            def __init__(self, data):
                self.vpc_name = data.get('vpc_name', 'preview-vpc')
                self.aws_region = data.get('aws_region', 'us-east-1')
                self.vpc_cidr = data.get('vpc_cidr', '10.0.0.0/24')
                self.enable_nat_gateway = data.get('enable_nat_gateway', True)
                self.enable_vpn_gateway = data.get('enable_vpn_gateway', False)
                self.enable_dns_hostnames = data.get('enable_dns_hostnames', True)
                self.enable_dns_support = data.get('enable_dns_support', True)
                self.custom_tags = data.get('custom_tags', {})
                self.request_id = 'preview-' + data.get('vpc_name', 'vpc')
                
                # Generate subnets
                allocator = IPAllocator()
                self.public_subnets = allocator.generate_public_subnets(self.vpc_cidr)
                self.private_subnets = allocator.generate_private_subnets(self.vpc_cidr)
                
                # Mock template
                class MockTemplate:
                    template_type = data.get('template_type', 'cloud-only')
                self.template = MockTemplate()
        
        temp_request = TempVPCRequest(data)
        
        # Generate preview
        github = GitHubIntegration()
        rendered_files = github.render_terraform_templates(temp_request)
        
        return JsonResponse({
            'success': True,
            'main_tf': rendered_files.get('main.tf', ''),
            'variables_tf': rendered_files.get('variables.tf', ''),
            'outputs_tf': rendered_files.get('outputs.tf', ''),
            'terraform_tfvars': rendered_files.get('terraform.tfvars', '')
        })
        
    except Exception as e:
        return JsonResponse({
            'success': False,
            'error': str(e)
        }, status=500)