from rest_framework import viewsets, status
from rest_framework.decorators import action, api_view, permission_classes
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from django.shortcuts import get_object_or_404
from django.db.models import Q
import json
import ipaddress

from ..models import VPCTemplate, VPCRequest
from ..utils import generate_terraform_vars, create_terraform_tfvars_content
from .serializers import (
    VPCTemplateSerializer, VPCRequestSerializer, TerraformConfigSerializer
)

class VPCTemplateViewSet(viewsets.ReadOnlyModelViewSet):
    """API endpoint for VPC Templates"""
    
    queryset = VPCTemplate.objects.filter(status__name='Active')
    serializer_class = VPCTemplateSerializer
    permission_classes = [IsAuthenticated]
    
    def get_queryset(self):
        queryset = super().get_queryset()
        template_type = self.request.query_params.get('type', None)
        if template_type:
            queryset = queryset.filter(template_type=template_type)
        return queryset

class VPCRequestViewSet(viewsets.ModelViewSet):
    """API endpoint for VPC Requests"""
    
    queryset = VPCRequest.objects.all()
    serializer_class = VPCRequestSerializer
    permission_classes = [IsAuthenticated]
    
    def get_queryset(self):
        queryset = super().get_queryset()
        
        # Filter by requester for non-admin users
        if not self.request.user.is_staff:
            queryset = queryset.filter(requester_email=self.request.user.email)
        
        # Filter by status
        status_filter = self.request.query_params.get('status', None)
        if status_filter:
            queryset = queryset.filter(status=status_filter)
        
        # Search by VPC name
        search = self.request.query_params.get('search', None)
        if search:
            queryset = queryset.filter(
                Q(vpc_name__icontains=search) | Q(vpc_cidr__icontains=search)
            )
        
        return queryset.order_by('-created')
    
    def perform_create(self, serializer):
        """Set requester information on create"""
        serializer.save(
            requester_email=self.request.user.email,
            requester_name=self.request.user.get_full_name() or self.request.user.username
        )
    
    @action(detail=True, methods=['get'])
    def terraform_config(self, request, pk=None):
        """Get Terraform configuration for a VPC request"""
        vpc_request = self.get_object()
        
        terraform_vars = generate_terraform_vars(vpc_request)
        terraform_tfvars = create_terraform_tfvars_content(vpc_request)
        
        # Estimate resources that will be created
        estimated_resources = self._estimate_resources(vpc_request)
        
        config_data = {
            'terraform_vars': terraform_vars,
            'terraform_tfvars': terraform_tfvars,
            'estimated_resources': estimated_resources
        }
        
        serializer = TerraformConfigSerializer(config_data)
        return Response(serializer.data)
    
    @action(detail=True, methods=['post'])
    def provision(self, request, pk=None):
        """Trigger provisioning for a VPC request"""
        vpc_request = self.get_object()
        
        if vpc_request.status != 'approved':
            return Response(
                {'error': 'Request must be approved before provisioning'},
                status=status.HTTP_400_BAD_REQUEST
            )
        
        try:
            # Update status
            vpc_request.status = 'provisioning'
            vpc_request.save()
            
            # Here you would trigger your CI/CD pipeline
            # For now, we'll just simulate success
            
            return Response({
                'message': 'Provisioning started successfully',
                'status': 'provisioning'
            })
            
        except Exception as e:
            vpc_request.status = 'failed'
            vpc_request.save()
            return Response(
                {'error': str(e)},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )
    
    @action(detail=True, methods=['post'])
    def update_resources(self, request, pk=None):
        """Update VPC request with provisioned resource information"""
        vpc_request = self.get_object()
        
        # Only allow updates from CI/CD systems or admins
        if not request.user.is_staff:
            return Response(
                {'error': 'Permission denied'},
                status=status.HTTP_403_FORBIDDEN
            )
        
        # Update resource information
        if 'vpc_id' in request.data:
            vpc_request.vpc_id = request.data['vpc_id']
        
        if 'resource_ids' in request.data:
            vpc_request.resource_ids = request.data['resource_ids']
        
        if 'status' in request.data:
            vpc_request.status = request.data['status']
        
        if 'pipeline_id' in request.data:
            vpc_request.pipeline_id = request.data['pipeline_id']
        
        vpc_request.save()
        
        serializer = self.get_serializer(vpc_request)
        return Response(serializer.data)
    
    def _estimate_resources(self, vpc_request):
        """Estimate AWS resources that will be created"""
        resources = {
            'vpc': 1,
            'internet_gateway': 1,
            'route_tables': 2,  # public and private
            'subnets': len(vpc_request.public_subnets or []) + len(vpc_request.private_subnets or []),
        }
        
        if vpc_request.enable_nat_gateway:
            resources['nat_gateways'] = len(vpc_request.public_subnets or [1])
            resources['elastic_ips'] = len(vpc_request.public_subnets or [1])
        
        if vpc_request.enable_vpn_gateway:
            resources['vpn_gateway'] = 1
        
        return resources

# Utility API endpoints
@api_view(['GET'])
@permission_classes([IsAuthenticated])
def check_cidr_availability(request):
    """Check if a CIDR block is available for use"""
    cidr = request.GET.get('cidr')
    if not cidr:
        return Response(
            {'error': 'CIDR parameter is required'},
            status=status.HTTP_400_BAD_REQUEST
        )
    
    try:
        # Validate CIDR format
        network = ipaddress.IPv4Network(cidr, strict=False)
        
        # Check if CIDR is already in use
        existing_vpcs = VPCRequest.objects.filter(
            vpc_cidr=str(network),
            status__in=['approved', 'provisioning', 'active']
        )
        
        # Check for overlapping CIDRs
        overlapping_vpcs = []
        for vpc in VPCRequest.objects.filter(status__in=['approved', 'provisioning', 'active']):
            try:
                existing_network = ipaddress.IPv4Network(vpc.vpc_cidr)
                if network.overlaps(existing_network):
                    overlapping_vpcs.append({
                        'vpc_name': vpc.vpc_name,
                        'vpc_cidr': vpc.vpc_cidr,
                        'status': vpc.status
                    })
            except:
                continue
        
        response_data = {
            'available': len(existing_vpcs) == 0 and len(overlapping_vpcs) == 0,
            'cidr': str(network),
            'existing_vpcs': list(existing_vpcs.values('vpc_name', 'vpc_cidr', 'status')),
            'overlapping_vpcs': overlapping_vpcs
        }
        
        return Response(response_data)
        
    except ipaddress.AddressValueError:
        return Response(
            {'error': 'Invalid CIDR format'},
            status=status.HTTP_400_BAD_REQUEST
        )

@api_view(['GET'])
@permission_classes([IsAuthenticated])
def get_vpc_costs(request):
    """Get estimated VPC costs based on configuration"""
    
    region = request.GET.get('region', 'us-east-1')
    enable_nat_gateway = request.GET.get('enable_nat_gateway', 'false').lower() == 'true'
    enable_vpn_gateway = request.GET.get('enable_vpn_gateway', 'false').lower() == 'true'
    public_subnets_count = int(request.GET.get('public_subnets_count', '2'))
    
    # Base costs (monthly, in USD)
    costs = {
        'base': 0,
        'nat_gateway': 0,
        'vpn_gateway': 0,
        'total': 0
    }
    
    # Regional pricing for NAT Gateway (per gateway per month)
    nat_gateway_pricing = {
        'us-east-1': 32.85,
        'us-west-2': 32.85,
        'eu-west-1': 36.14,
        'ap-southeast-1': 38.69
    }
    
    # VPN Gateway pricing (per month)
    vpn_gateway_cost = 36.00
    
    if enable_nat_gateway:
        nat_cost = nat_gateway_pricing.get(region, 32.85) * public_subnets_count
        costs['nat_gateway'] = nat_cost
    
    if enable_vpn_gateway:
        costs['vpn_gateway'] = vpn_gateway_cost
    
    costs['total'] = costs['base'] + costs['nat_gateway'] + costs['vpn_gateway']
    
    # Add data transfer estimates (basic)
    costs['estimated_data_transfer'] = 10.00  # $10/month estimated
    costs['total_with_data'] = costs['total'] + costs['estimated_data_transfer']
    
    return Response({
        'region': region,
        'costs': costs,
        'currency': 'USD',
        'period': 'monthly'
    })

@api_view(['GET'])
def health_check(request):
    """Health check endpoint for monitoring"""
    try:
        from django.db import connection
        
        # Check database connectivity
        with connection.cursor() as cursor:
            cursor.execute("SELECT 1")
        
        # Check if we can query models
        active_requests = VPCRequest.objects.filter(status='active').count()
        
        return Response({
            'status': 'healthy',
            'database': 'connected',
            'active_vpcs': active_requests,
            'version': '1.0.0'
        })
        
    except Exception as e:
        return Response(
            {
                'status': 'unhealthy',
                'error': str(e)
            },
            status=status.HTTP_500_INTERNAL_SERVER_ERROR
        )