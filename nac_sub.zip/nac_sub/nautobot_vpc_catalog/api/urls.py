from rest_framework.routers import DefaultRouter
from django.urls import path, include
from . import views
from .views import check_cidr_availability, get_vpc_costs, health_check

# Create router for viewsets
# router = DefaultRouter()
# router.register(r'templates', views.VPCTemplateViewSet)
# router.register(r'requests', views.VPCRequestViewSet)
# router.register(r'jobs', views.VPCProvisioningJobViewSet)

# URL patterns
urlpatterns = [
    # ViewSet URLs
    #path('', include(router.urls)),
    
    # Utility endpoints
    path('check-cidr/', check_cidr_availability, name='check_cidr_availability'),
    path('costs/', get_vpc_costs, name='get_vpc_costs'),
    path('health/', health_check, name='health_check'),
]