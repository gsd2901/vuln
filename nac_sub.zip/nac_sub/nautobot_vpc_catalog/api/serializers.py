# api/serializers.py
from rest_framework import serializers
from ..models import VPCTemplate, VPCRequest

class VPCTemplateSerializer(serializers.ModelSerializer):
    """Serializer for VPC Templates"""
    
    class Meta:
        model = VPCTemplate
        fields = [
            'id', 'name', 'template_type', 'description',
            'default_cidr', 'default_public_subnets', 'default_private_subnets',
            'default_tags', 'auto_fill_enabled', 'created', 'last_updated'
        ]
        read_only_fields = ['id', 'created', 'last_updated']

class VPCRequestSerializer(serializers.ModelSerializer):
    """Serializer for VPC Requests"""
    
    template_name = serializers.CharField(source='template.name', read_only=True)
    template_type = serializers.CharField(source='template.template_type', read_only=True)
    estimated_cost = serializers.SerializerMethodField()
    
    class Meta:
        model = VPCRequest
        fields = [
            'id', 'request_id', 'requester_name', 'requester_email',
            'template', 'template_name', 'template_type',
            'vpc_name', 'aws_region', 'vpc_cidr',
            'public_subnets', 'private_subnets',
            'enable_nat_gateway', 'enable_vpn_gateway',
            'enable_dns_hostnames', 'enable_dns_support',
            'custom_tags', 'status', 'estimated_cost',
            'vpc_id', 'resource_ids', 'pipeline_id', 'git_branch',
            'created', 'last_updated'
        ]
        read_only_fields = [
            'id', 'request_id', 'estimated_cost',
            'vpc_id', 'resource_ids', 'pipeline_id', 'git_branch',
            'created', 'last_updated'
        ]
    
    def get_estimated_cost(self, obj):
        """Calculate estimated monthly cost"""
        cost = 0
        if obj.enable_nat_gateway:
            # NAT Gateway: ~$32/month per gateway
            nat_gateways = len(obj.public_subnets) if obj.public_subnets else 1
            cost += nat_gateways * 32.0
        if obj.enable_vpn_gateway:
            cost += 36.0  # VPN Gateway cost
        return cost

class TerraformConfigSerializer(serializers.Serializer):
    """Serializer for Terraform configuration"""
    
    terraform_vars = serializers.JSONField()
    terraform_tfvars = serializers.CharField()
    estimated_resources = serializers.JSONField()