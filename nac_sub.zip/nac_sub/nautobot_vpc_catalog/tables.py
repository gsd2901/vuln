import django_tables2 as tables
from django_tables2.utils import A
from nautobot.utilities.tables import BaseTable, BooleanColumn, ButtonsColumn
from .models import VPCTemplate, VPCRequest

class VPCTemplateTable(BaseTable):
    """Table for displaying VPC templates"""
    
    pk = tables.Column(linkify=True, verbose_name="ID")
    name = tables.Column(linkify=True)
    template_type = tables.Column(verbose_name="Type")
    auto_fill_enabled = BooleanColumn()
    actions = ButtonsColumn(VPCTemplate)
    
    class Meta(BaseTable.Meta):
        model = VPCTemplate
        fields = ("pk", "name", "template_type", "description", "auto_fill_enabled", "created")
        default_columns = ("pk", "name", "template_type", "description", "auto_fill_enabled")

class VPCRequestTable(BaseTable):
    """Table for displaying VPC requests"""
    
    pk = tables.Column(linkify=True, verbose_name="ID")
    vpc_name = tables.Column(linkify=True)
    template = tables.Column(linkify=("plugins:nautobot_vpc_catalog:vpctemplate", [A("template.pk")]))
    requester_name = tables.Column()
    status = tables.Column()
    estimated_monthly_cost = tables.Column(verbose_name="Est. Cost")
    aws_region = tables.Column()
    created = tables.DateTimeColumn()
    actions = ButtonsColumn(VPCRequest)
    
    class Meta(BaseTable.Meta):
        model = VPCRequest
        fields = (
            "pk", "vpc_name", "template", "requester_name", 
            "status", "aws_region", "estimated_monthly_cost", "created"
        )
        default_columns = (
            "pk", "vpc_name", "template", "requester_name", 
            "status", "aws_region", "created"
        )