from django.apps import AppConfig


class CloudProvisioningConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'nautobot_vpc_catalog'
