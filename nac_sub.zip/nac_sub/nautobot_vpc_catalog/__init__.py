from nautobot.apps import NautobotAppConfig

class VPCCatalogConfig(NautobotAppConfig):
    name = "nautobot_vpc_catalog"
    verbose_name = "VPC Catalog"
    description = "Self-service VPC provisioning catalog"
    version = "1.0.0"
    author = "Avinash Sharma"
    author_email = "avinash_sharma@hcltech.com"
    base_url = "vpc-catalog"
    required_settings = []
    default_settings = {
        "enable_auto_tagging": True,
        "default_aws_region": "us-east-1",
        "cicd_webhook_url": None,
    }
    caching_config = {}

config = VPCCatalogConfig