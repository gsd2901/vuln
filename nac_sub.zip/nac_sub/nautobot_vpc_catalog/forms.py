# nautobot_vpc_catalog/forms.py - UPDATE YOUR EXISTING FILE
from django import forms
from django.core.exceptions import ValidationError
import ipaddress
import json

from .models import VPCRequest, VPCTemplate

class VPCRequestForm(forms.ModelForm):
    """Form for creating VPC requests"""
    
    # Add these fields for display purposes
    public_subnets = forms.CharField(
        widget=forms.Textarea(attrs={'rows': 3, 'class': 'form-control'}),
        required=False,
        help_text="Auto-generated public subnet CIDRs"
    )
    
    private_subnets = forms.CharField(
        widget=forms.Textarea(attrs={'rows': 3, 'class': 'form-control'}),
        required=False, 
        help_text="Auto-generated private subnet CIDRs"
    )
    
    class Meta:
        model = VPCRequest
        fields = [
            'vpc_name', 'aws_region', 'vpc_cidr',
            'enable_nat_gateway', 'enable_vpn_gateway',
            'enable_dns_hostnames', 'enable_dns_support',
            'custom_tags','public_subnets', 'private_subnets'
        ]
        
        widgets = {
            'vpc_name': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'my-vpc-name'
            }),
            'aws_region': forms.Select(attrs={'class': 'form-control'}),
            'vpc_cidr': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': '10.0.0.0/24'
            }),
            'enable_nat_gateway': forms.CheckboxInput(attrs={'class': 'form-check-input'}),
            'enable_vpn_gateway': forms.CheckboxInput(attrs={'class': 'form-check-input'}),
            'enable_dns_hostnames': forms.CheckboxInput(attrs={'class': 'form-check-input'}),
            'enable_dns_support': forms.CheckboxInput(attrs={'class': 'form-check-input'}),
            'custom_tags': forms.Textarea(attrs={
                'rows': 4,
                'class': 'form-control',
                'placeholder': '{"Environment": "dev", "Team": "platform"}'
            })
        }
    
    def __init__(self, *args, **kwargs):
        self.template = kwargs.pop('template', None)
        super().__init__(*args, **kwargs)
        
        # Set AWS region choices - THIS FIXES THE DROPDOWN
        self.fields['aws_region'].choices = [
            ('', 'Select AWS Region'),  # Default empty option
            ('us-east-1', 'US East (N. Virginia)'),
            ('us-east-2', 'US East (Ohio)'),
            ('us-west-1', 'US West (N. California)'),
            ('us-west-2', 'US West (Oregon)'),
            ('eu-west-1', 'Europe (Ireland)'),
            ('eu-west-2', 'Europe (London)'),
            ('eu-central-1', 'Europe (Frankfurt)'),
            ('ap-southeast-1', 'Asia Pacific (Singapore)'),
            ('ap-southeast-2', 'Asia Pacific (Sydney)'),
            ('ap-south-1', 'Asia Pacific (Mumbai)'),
        ]
        
        # Set default region
        if not self.initial.get('aws_region'):
            self.initial['aws_region'] = 'us-east-1'
        
        # Use subnets already provided in initial_data
        public_subnets = self.initial.get('public_subnets', [])
        private_subnets = self.initial.get('private_subnets', [])

        self.initial['public_subnets'] = "\n".join(public_subnets)
        self.initial['private_subnets'] = "\n".join(private_subnets)
        
        # Template-specific field modifications
        if self.template and self.template.template_type == 'onprem-connected':
            self.fields['enable_vpn_gateway'].initial = True
            self.fields['vpc_cidr'].help_text = "Auto-allocated /24 CIDR block"
        elif self.template and self.template.template_type == 'cloud-only':
            self.fields['enable_vpn_gateway'].initial = False
            self.fields['vpc_cidr'].help_text = "Specify your desired CIDR block"
    
    def clean_vpc_cidr(self):
        cidr = self.cleaned_data.get('vpc_cidr')
        try:
            network = ipaddress.IPv4Network(cidr, strict=False)
            if network.prefixlen > 28:
                raise ValidationError("CIDR prefix must be /28 or larger")
            return str(network)
        except ipaddress.AddressValueError:
            raise ValidationError("Invalid CIDR format")
    
    def clean_custom_tags(self):
        tags = self.cleaned_data.get('custom_tags')
        if isinstance(tags, str) and tags.strip():
            try:
                return json.loads(tags)
            except json.JSONDecodeError:
                raise ValidationError("Invalid JSON format for tags")
        return tags or {}
    
    def clean_public_subnets(self):
        value = self.cleaned_data.get("public_subnets", "")
        subnets = [line.strip() for line in value.splitlines() if line.strip()]
        return subnets

    def clean_private_subnets(self):
        value = self.cleaned_data.get("private_subnets", "")
        subnets = [line.strip() for line in value.splitlines() if line.strip()]
        return subnets