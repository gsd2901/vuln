import django_filters
from django import forms
from nautobot.utilities.filters import BaseFilterSet
from .models import VPCTemplate, VPCRequest

class VPCTemplateFilterSet(BaseFilterSet):
    """Filter set for VPC templates"""
    
    q = django_filters.CharFilter(
        method='search',
        label='Search',
    )
    
    template_type = django_filters.ChoiceFilter(
        choices=VPCTemplate.TEMPLATE_TYPES,
        widget=forms.Select(attrs={'class': 'form-control'})
    )
    
    auto_fill_enabled = django_filters.BooleanFilter(
        widget=forms.Select(
            choices=((True, 'Yes'), (False, 'No')),
            attrs={'class': 'form-control'}
        )
    )
    
    class Meta:
        model = VPCTemplate
        fields = ['q', 'template_type', 'auto_fill_enabled']
    
    def search(self, queryset, name, value):
        """Search across multiple fields"""
        return queryset.filter(
            models.Q(name__icontains=value) |
            models.Q(description__icontains=value)
        )

class VPCRequestFilterSet(BaseFilterSet):
    """Filter set for VPC requests"""
    
    q = django_filters.CharFilter(
        method='search',
        label='Search',
    )
    
    status = django_filters.ChoiceFilter(
        choices=VPCRequest.REQUEST_STATUS,
        widget=forms.Select(attrs={'class': 'form-control'})
    )
    
    template = django_filters.ModelChoiceFilter(
        queryset=VPCTemplate.objects.all(),
        widget=forms.Select(attrs={'class': 'form-control'})
    )
    
    aws_region = django_filters.CharFilter(
        lookup_expr='iexact',
        widget=forms.TextInput(attrs={'class': 'form-control'})
    )
    
    requester_email = django_filters.CharFilter(
        lookup_expr='icontains',
        widget=forms.TextInput(attrs={'class': 'form-control'})
    )
    
    class Meta:
        model = VPCRequest
        fields = ['q', 'status', 'template', 'aws_region', 'requester_email']
    
    def search(self, queryset, name, value):
        """Search across multiple fields"""
        return queryset.filter(
            models.Q(vpc_name__icontains=value) |
            models.Q(vpc_cidr__icontains=value) |
            models.Q(requester_name__icontains=value) |
            models.Q(requester_email__icontains=value)
        )