from nautobot.dcim.models import Device, Interface, Cable
from nautobot.dcim.choices import CableTypeChoices
from collections import defaultdict
from ..models import LocationTopologyView


class TopologyBuilder:
    """Builds topology data structure for a location."""
    
    def __init__(self, location):
        self.location = location
        self.devices = {}
        self.connections = []
        self.device_connections = defaultdict(list)
    
    def build_topology(self):
        """Build complete topology data structure."""
        self._get_devices()
        self._get_connections()
        self._build_connection_list()
        
        return {
            'devices': list(self.devices.values()),
            'connections': self.connections,
            'saved_layout': self._get_saved_layout()
        }
    
    def _get_devices(self):
        """Get all devices in the location."""
        devices = Device.objects.filter(location=self.location).select_related(
            'role', 'device_type__manufacturer', 'status', 'platform', 'tenant', 'rack', 'primary_ip4', 'primary_ip6'
        ).prefetch_related('interfaces')
        
        for device in devices:
            # Count connections for this device by checking interfaces
            connection_count = 0
            for interface in device.interfaces.all():
                if interface.cable is not None:
                    connection_count += 1
            
            # Get rack information
            rack_info = None
            if device.rack:
                rack_info = {
                    'name': device.rack.name,
                    'facility_id': device.rack.facility_id,
                    'position': device.position,
                    'face': device.face,
                    'asset_tag': device.rack.asset_tag
                }
            
            # Get primary IP information
            primary_ip4 = str(device.primary_ip4) if device.primary_ip4 else None
            primary_ip6 = str(device.primary_ip6) if device.primary_ip6 else None
            
            self.devices[device.id] = {
                'id': str(device.id),
                'name': device.name,
                'device_role': str(device.role),
                'device_type': str(device.device_type),
                'manufacturer': str(device.device_type.manufacturer),
                'platform': str(device.platform) if device.platform else None,
                'status': str(device.status),
                'serial': device.serial,
                'asset_tag': device.asset_tag,
                'tenant': str(device.tenant) if device.tenant else None,
                'location': str(device.location),
                'rack': rack_info,
                'primary_ip4': primary_ip4,
                'primary_ip6': primary_ip6,
                'connection_count': connection_count,
                'position': self._get_device_position(device.id)
            }
    
    def _get_connections(self):
        """Get all cable connections between devices in this location."""
        # Get all devices in this location
        devices_in_location = set(Device.objects.filter(location=self.location).values_list('id', flat=True))
        
        # Get cables where termination_a or termination_b is an Interface
        from django.contrib.contenttypes.models import ContentType
        interface_ct = ContentType.objects.get_for_model(Interface)
        
        cables = Cable.objects.filter(
            termination_a_type=interface_ct,
            termination_b_type=interface_ct
        ).select_related(
            'termination_a_type',
            'termination_b_type',
            'status'
        )
        
        for cable in cables:
            try:
                # Get the actual interface objects
                termination_a = cable.termination_a
                termination_b = cable.termination_b
                
                # Check if terminations are valid Interface objects
                if not termination_a or not termination_b:
                    continue
                    
                # Get devices from interfaces
                if not hasattr(termination_a, 'device') or not hasattr(termination_b, 'device'):
                    continue
                    
                device1 = termination_a.device
                device2 = termination_b.device
                
                # Skip if devices are None
                if not device1 or not device2:
                    continue
                
                # Only include connections where both devices are in this location
                if device1.id not in devices_in_location or device2.id not in devices_in_location:
                    continue
                
                # Skip self-connections
                if device1.id == device2.id:
                    continue
                
                connection = {
                    'id': f"cable_{cable.id}",
                    'source': str(device1.id),
                    'target': str(device2.id),
                    'cable_type': cable.type or '',
                    'cable_status': str(cable.status),
                    'source_interface': str(termination_a),
                    'target_interface': str(termination_b),
                    'cable_id': str(cable.id)
                }
                
                self.connections.append(connection)
                
                # Track device connections for layout algorithms
                self.device_connections[device1.id].append(device2.id)
                self.device_connections[device2.id].append(device1.id)
                
            except Exception as e:
                # Log and skip problematic cables
                import logging
                logger = logging.getLogger(__name__)
                logger.warning(f"Error processing cable {cable.id}: {e}")
                continue
    
    def _build_connection_list(self):
        """Build the final connection list with proper formatting."""
        # This method can be extended to add more connection metadata
        # or filter connections based on certain criteria
        pass
    
    def _get_device_position(self, device_id):
        """Get saved position for a device, or return None for auto-layout."""
        try:
            topology_view = LocationTopologyView.objects.get(
                location=self.location,
                name="Default View"
            )
            return topology_view.get_node_position(device_id)
        except LocationTopologyView.DoesNotExist:
            return None
    
    def _get_saved_layout(self):
        """Get saved layout data if it exists."""
        try:
            topology_view = LocationTopologyView.objects.get(
                location=self.location,
                name="Default View"
            )
            return {
                'nodes': topology_view.node_positions,
                'viewport': topology_view.viewport
            }
        except LocationTopologyView.DoesNotExist:
            return {
                'nodes': {},
                'viewport': {'zoom': 1.0, 'pan_x': 0, 'pan_y': 0}
            }
    
    def get_connection_type_class(self, cable_type):
        """Get CSS class for cable type."""
        type_mapping = {
            CableTypeChoices.TYPE_CAT3: 'cable-cat3',
            CableTypeChoices.TYPE_CAT5: 'cable-cat5',
            CableTypeChoices.TYPE_CAT5E: 'cable-cat5e',
            CableTypeChoices.TYPE_CAT6: 'cable-cat6',
            CableTypeChoices.TYPE_CAT6A: 'cable-cat6a',
            CableTypeChoices.TYPE_CAT7: 'cable-cat7',
            CableTypeChoices.TYPE_DAC_ACTIVE: 'cable-dac',
            CableTypeChoices.TYPE_DAC_PASSIVE: 'cable-dac',
            CableTypeChoices.TYPE_MOCA: 'cable-moca',
            CableTypeChoices.TYPE_MMF: 'cable-fiber',
            CableTypeChoices.TYPE_MMF_OM1: 'cable-fiber',
            CableTypeChoices.TYPE_MMF_OM2: 'cable-fiber',
            CableTypeChoices.TYPE_MMF_OM3: 'cable-fiber',
            CableTypeChoices.TYPE_MMF_OM4: 'cable-fiber',
            CableTypeChoices.TYPE_SMF: 'cable-fiber',
            CableTypeChoices.TYPE_SMF_OS1: 'cable-fiber',
            CableTypeChoices.TYPE_SMF_OS2: 'cable-fiber',
        }
        return type_mapping.get(cable_type, 'cable-unknown')

