from django.urls import path, include
from . import views
from .api import views as api_views

app_name = 'nautobot_topology_viewer'

urlpatterns = [
    path('viewer/', views.TopologyViewerView.as_view(), name='topology_viewer'),
    path('viewer/<uuid:location_id>/', views.TopologyViewerView.as_view(), name='topology_viewer_location'),
    path('viewer/discovery/<uuid:session_id>/', views.DiscoveryTopologyViewerView.as_view(), name='discovery_topology_viewer'),
    # API URLs integrated into main namespace
    path('api/topology/<uuid:location_id>/', api_views.get_topology_data, name='api_topology_data'),
    path('api/topology/<uuid:location_id>/save/', api_views.save_topology_layout, name='api_save_topology'),
    path('api/devices/<uuid:location_id>/', api_views.get_device_list, name='api_device_list'),
    path('api/locations/', api_views.get_locations_with_devices, name='api_locations_with_devices'),
]

# Legacy API URLs for backward compatibility
api_urlpatterns = [
    path('', include('nautobot_topology_viewer.api.urls')),
]
