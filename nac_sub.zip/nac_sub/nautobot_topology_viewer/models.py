from django.db import models
from django.contrib.auth import get_user_model
from nautobot.dcim.models import Location
import uuid

User = get_user_model()


class LocationTopologyView(models.Model):
    """Model to store topology view configurations for locations."""
    
    id = models.UUIDField(primary_key=True, default=uuid.uuid4)
    location = models.ForeignKey(
        Location,
        on_delete=models.CASCADE,
        related_name='topology_views',
        help_text="Location this topology view belongs to"
    )
    name = models.CharField(
        max_length=100,
        default="Default View",
        help_text="Name of this topology view"
    )
    topology_data = models.JSONField(
        default=dict,
        help_text="Stores node positions, zoom level, and custom styling"
    )
    created_by = models.ForeignKey(
        User,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        help_text="User who created this view"
    )
    created_at = models.DateTimeField(auto_now_add=True)
    last_modified = models.DateTimeField(auto_now=True)
    version = models.IntegerField(default=1, help_text="Version for future compatibility")
    
    class Meta:
        unique_together = ['location', 'name']
        ordering = ['-last_modified']
    
    def __str__(self):
        return f"{self.location.name} - {self.name}"
    
    @property
    def node_positions(self):
        """Get node positions from topology_data."""
        return self.topology_data.get('nodes', {})
    
    @property
    def viewport(self):
        """Get viewport settings from topology_data."""
        return self.topology_data.get('viewport', {'zoom': 1.0, 'pan_x': 0, 'pan_y': 0})
    
    def update_node_position(self, device_id, x, y, pinned=False):
        """Update position of a specific device node."""
        if 'nodes' not in self.topology_data:
            self.topology_data['nodes'] = {}
        
        self.topology_data['nodes'][str(device_id)] = {
            'x': x,
            'y': y,
            'pinned': pinned
        }
        self.save()
    
    def get_node_position(self, device_id):
        """Get saved position for a device node."""
        nodes = self.topology_data.get('nodes', {})
        return nodes.get(str(device_id))

