from nautobot.apps.ui import NavMenuAddButton, NavMenuGroup, NavMenuItem, NavMenuTab


menu_items = (
    NavMenuTab(
        name="Topology",
        weight=1000,
        groups=(
            NavMenuGroup(
                name="Network Visualization",
                weight=100,
                items=(
                    NavMenuItem(
                        link="plugins:nautobot_topology_viewer:topology_viewer",
                        name="Topology Viewer",
                        weight=100,
                        permissions=["nautobot_topology_viewer.view_locationtopologyview"],
                    ),
                ),
            ),
        ),
    ),
)

