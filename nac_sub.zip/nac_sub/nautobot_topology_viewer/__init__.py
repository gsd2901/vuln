from nautobot.apps import NautobotAppConfig


class TopologyViewerConfig(NautobotAppConfig):
    name = "nautobot_topology_viewer"
    verbose_name = "Network Topology Viewer"
    version = "1.0.0"
    author = "s-sameer@hcltech.com"
    description = "Interactive network topology visualization"
    base_url = "topology-viewer"
    required_settings = []
    default_settings = {
        'enable_location_integration': True,
        'enable_discovery_integration': True,
    }
    
    # Navigation menu
    navigation = "nautobot_topology_viewer.navigation.menu_items"
    
    # Template extensions
    template_extensions = "nautobot_topology_viewer.template_content.template_extensions"
    
    def ready(self):
        super().ready()


config = TopologyViewerConfig
