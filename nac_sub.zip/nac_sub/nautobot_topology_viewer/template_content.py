from nautobot.extras.plugins import PluginTemplateExtension


class LocationTopologyButtons(PluginTemplateExtension):
    """
    Extend the DCIM location template to include topology button.
    """
    model = 'dcim.location'

    def buttons(self):
        """Render the topology button template."""
        return self.render('nautobot_topology_viewer/location_topology_button.html')


# Register template extensions
template_extensions = [LocationTopologyButtons]
