from django.shortcuts import get_object_or_404
from rest_framework import status
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from nautobot.dcim.models import Location
from ..models import LocationTopologyView
from ..utils.topology_builder import TopologyBuilder
from .serializers import TopologyDataSerializer, SaveTopologySerializer, DeviceConnectionSerializer
import logging

logger = logging.getLogger(__name__)


# API Views
@api_view(['GET'])
@permission_classes([IsAuthenticated])
def get_topology_data(request, location_id):
    """Get topology data for a location."""
    try:
        location = get_object_or_404(Location, pk=location_id)
        
        # Build topology data
        builder = TopologyBuilder(location)
        topology_data = builder.build_topology()
        
        # Serialize devices
        device_serializer = DeviceConnectionSerializer(topology_data['devices'], many=True)
        
        return Response({
            'devices': device_serializer.data,
            'connections': topology_data['connections'],
            'saved_layout': topology_data['saved_layout']
        })
    except Exception as e:
        logger.exception(f"Error getting topology data for location {location_id}: {e}")
        return Response(
            {'error': str(e), 'detail': 'Failed to build topology data'},
            status=status.HTTP_500_INTERNAL_SERVER_ERROR
        )


@api_view(['POST'])
@permission_classes([IsAuthenticated])
def save_topology_layout(request, location_id):
    """Save topology layout (node positions and viewport)."""
    location = get_object_or_404(Location, pk=location_id)
    
    serializer = SaveTopologySerializer(data=request.data)
    if serializer.is_valid():
        # Get or create topology view
        topology_view, created = LocationTopologyView.objects.get_or_create(
            location=location,
            name="Default View",
            defaults={'created_by': request.user}
        )
        
        # Update topology data
        topology_view.topology_data.update({
            'nodes': serializer.validated_data['nodes'],
            'viewport': serializer.validated_data['viewport'],
            'layout_algorithm': serializer.validated_data['layout_algorithm']
        })
        topology_view.save()
        
        return Response({'status': 'saved'}, status=status.HTTP_200_OK)
    
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


@api_view(['GET'])
@permission_classes([IsAuthenticated])
def get_locations_with_devices(request):
    """Get list of locations that have devices for location selector."""
    try:
        # Get locations that have devices
        locations = Location.objects.filter(devices__isnull=False).distinct().order_by('name')
        
        location_data = []
        for location in locations:
            device_count = location.devices.count()
            location_data.append({
                'id': str(location.id),
                'name': location.name,
                'device_count': device_count,
                'full_name': location.name if not location.parent else f"{location.parent.name} > {location.name}"
            })
        
        return Response({'locations': location_data})
    except Exception as e:
        logger.exception(f"Error getting locations with devices: {e}")
        return Response(
            {'error': str(e), 'detail': 'Failed to get locations'},
            status=status.HTTP_500_INTERNAL_SERVER_ERROR
        )


@api_view(['GET'])
@permission_classes([IsAuthenticated])
def get_device_list(request, location_id):
    """Get list of devices in a location for the sidebar."""
    location = get_object_or_404(Location, pk=location_id)
    
    devices = location.devices.all().select_related(
        'role', 'device_type__manufacturer', 'status', 'platform', 'tenant', 'rack', 'primary_ip4', 'primary_ip6'
    )
    
    # Add connection counts
    device_data = []
    for device in devices:
        connection_count = device.interfaces.filter(
            cable_terminations__isnull=False
        ).count()
        
        # Get rack information
        rack_info = None
        if device.rack:
            rack_info = {
                'name': device.rack.name,
                'facility_id': device.rack.facility_id,
                'position': device.position,
                'face': device.face,
                'asset_tag': device.rack.asset_tag
            }
        
        # Get primary IP information
        primary_ip4 = str(device.primary_ip4) if device.primary_ip4 else None
        primary_ip6 = str(device.primary_ip6) if device.primary_ip6 else None
        
        device_data.append({
            'id': device.id,
            'name': device.name,
            'device_role': str(device.role),
            'device_type': str(device.device_type),
            'manufacturer': str(device.device_type.manufacturer),
            'platform': str(device.platform) if device.platform else 'Unknown',
            'status': str(device.status),
            'serial': device.serial,
            'asset_tag': device.asset_tag,
            'tenant': str(device.tenant) if device.tenant else None,
            'location': str(device.location),
            'rack': rack_info,
            'primary_ip4': primary_ip4,
            'primary_ip6': primary_ip6,
            'connection_count': connection_count
        })
    
    return Response(device_data)