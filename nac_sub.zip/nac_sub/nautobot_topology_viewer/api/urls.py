from django.urls import path
from . import views

app_name = 'nautobot_topology_viewer_api'

urlpatterns = [
    path('topology/<uuid:location_id>/', views.get_topology_data, name='api_topology_data'),
    path('topology/<uuid:location_id>/save/', views.save_topology_layout, name='api_save_topology'),
    path('devices/<uuid:location_id>/', views.get_device_list, name='api_device_list'),
    path('locations/', views.get_locations_with_devices, name='api_locations_with_devices'),
]
