from rest_framework import serializers
from nautobot.dcim.models import Device, Interface, Cable
from nautobot.dcim.api.serializers import DeviceSerializer
from ..models import LocationTopologyView


class DeviceConnectionSerializer(serializers.Serializer):
    """Serializer for device with connection information."""
    
    id = serializers.UUIDField()
    name = serializers.CharField()
    device_role = serializers.CharField()
    device_type = serializers.CharField()
    manufacturer = serializers.CharField()
    platform = serializers.CharField(required=False, allow_null=True, allow_blank=True)
    status = serializers.CharField()
    serial = serializers.CharField(required=False, allow_blank=True)
    asset_tag = serializers.CharField(required=False, allow_null=True, allow_blank=True)
    tenant = serializers.CharField(required=False, allow_null=True, allow_blank=True)
    location = serializers.CharField()
    rack = serializers.DictField(required=False, allow_null=True)
    primary_ip4 = serializers.CharField(required=False, allow_null=True, allow_blank=True)
    primary_ip6 = serializers.CharField(required=False, allow_null=True, allow_blank=True)
    connection_count = serializers.IntegerField()
    position = serializers.DictField(required=False, allow_null=True)


class TopologyDataSerializer(serializers.Serializer):
    """Serializer for topology data structure."""
    
    devices = DeviceConnectionSerializer(many=True)
    connections = serializers.ListField(
        child=serializers.DictField(),
        help_text="List of connections between devices"
    )
    saved_layout = serializers.DictField(
        required=False,
        help_text="Saved node positions and viewport settings"
    )


class SaveTopologySerializer(serializers.Serializer):
    """Serializer for saving topology layout."""
    
    nodes = serializers.DictField(
        help_text="Node positions: {device_id: {x, y, pinned}}"
    )
    viewport = serializers.DictField(
        help_text="Viewport settings: {zoom, pan_x, pan_y}"
    )
    layout_algorithm = serializers.CharField(
        default="manual",
        help_text="Layout algorithm used"
    )

