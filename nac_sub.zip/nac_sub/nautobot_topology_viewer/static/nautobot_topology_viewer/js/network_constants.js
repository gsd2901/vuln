/**
 * Network Layer Constants
 * Defines Cisco network hierarchy patterns and layer classifications
 */

class NetworkConstants {
    // Network layer hierarchy (0 = top, higher numbers = lower in hierarchy)
    static LAYER_HIERARCHY = {
        CORE: 0,
        DISTRIBUTION: 1,
        ACCESS: 2,
        UNKNOWN: 3
    };

    // Core layer patterns - highest priority
    static CORE_PATTERNS = [
        // Direct matches
        /\b(core)\b/i,
        /\b(cs)\b/i,
        /\b(core-switch)\b/i,
        /\b(core_switch)\b/i,
        /\b(core-sw)\b/i,
        /\b(core_sw)\b/i,
        
        // Position-based patterns (core is often in the middle or top)
        /^core/i,
        /^cs/i,
        /^c-/i,
        /^c_/i,
        
        // Common core naming conventions
        /\b(backbone)\b/i,
        /\b(spine)\b/i,
        /\b(aggregation)\b/i,
        /\b(agg)\b/i,
        /\b(central)\b/i,
        /\b(main)\b/i,
        /\b(primary)\b/i,
        /\b(primary-switch)\b/i,
        /\b(primary_switch)\b/i,
        
        // Cisco specific core patterns
        /\b(catalyst.*core)\b/i,
        /\b(nexus.*core)\b/i,
        /\b(6500.*core)\b/i,
        /\b(6800.*core)\b/i,
        /\b(9500.*core)\b/i,
        /\b(9600.*core)\b/i,
        
        // Data center core patterns
        /\b(dc-core)\b/i,
        /\b(dc_core)\b/i,
        /\b(datacenter.*core)\b/i,
        /\b(data.*center.*core)\b/i,
        
        // Building core patterns
        /\b(bldg.*core)\b/i,
        /\b(building.*core)\b/i,
        /\b(floor.*core)\b/i,
        /\b(level.*core)\b/i
    ];

    // Distribution layer patterns - medium priority
    static DISTRIBUTION_PATTERNS = [
        // Direct matches
        /\b(distribution)\b/i,
        /\b(dist)\b/i,
        /\b(ds)\b/i,
        /\b(distribution-switch)\b/i,
        /\b(distribution_switch)\b/i,
        /\b(dist-sw)\b/i,
        /\b(dist_sw)\b/i,
        
        // Position-based patterns
        /^dist/i,
        /^ds/i,
        /^d-/i,
        /^d_/i,
        
        // Common distribution naming conventions
        /\b(aggregation)\b/i,
        /\b(agg)\b/i,
        /\b(consolidation)\b/i,
        /\b(consol)\b/i,
        /\b(intermediate)\b/i,
        /\b(inter)\b/i,
        /\b(middle)\b/i,
        /\b(secondary)\b/i,
        /\b(secondary-switch)\b/i,
        /\b(secondary_switch)\b/i,
        
        // Cisco specific distribution patterns
        /\b(catalyst.*dist)\b/i,
        /\b(nexus.*dist)\b/i,
        /\b(4500.*dist)\b/i,
        /\b(3850.*dist)\b/i,
        /\b(9300.*dist)\b/i,
        
        // Data center distribution patterns
        /\b(dc-dist)\b/i,
        /\b(dc_dist)\b/i,
        /\b(datacenter.*dist)\b/i,
        /\b(data.*center.*dist)\b/i,
        
        // Building distribution patterns
        /\b(bldg.*dist)\b/i,
        /\b(building.*dist)\b/i,
        /\b(floor.*dist)\b/i,
        /\b(level.*dist)\b/i,
        
        // Layer 3 distribution patterns
        /\b(l3.*dist)\b/i,
        /\b(layer3.*dist)\b/i,
        /\b(routing.*dist)\b/i
    ];

    // Access layer patterns - lowest priority
    static ACCESS_PATTERNS = [
        // Direct matches
        /\b(access)\b/i,
        /\b(as)\b/i,
        /\b(access-switch)\b/i,
        /\b(access_switch)\b/i,
        /\b(access-sw)\b/i,
        /\b(access_sw)\b/i,
        
        // Position-based patterns
        /^access/i,
        /^as/i,
        /^a-/i,
        /^a_/i,
        
        // Common access naming conventions
        /\b(edge)\b/i,
        /\b(endpoint)\b/i,
        /\b(end-user)\b/i,
        /\b(end_user)\b/i,
        /\b(desktop)\b/i,
        /\b(workstation)\b/i,
        /\b(floor)\b/i,
        /\b(level)\b/i,
        /\b(room)\b/i,
        /\b(office)\b/i,
        /\b(cubicle)\b/i,
        /\b(terminal)\b/i,
        /\b(port)\b/i,
        /\b(port-switch)\b/i,
        /\b(port_switch)\b/i,
        
        // Cisco specific access patterns
        /\b(catalyst.*access)\b/i,
        /\b(nexus.*access)\b/i,
        /\b(2960.*access)\b/i,
        /\b(3750.*access)\b/i,
        /\b(3850.*access)\b/i,
        /\b(9300.*access)\b/i,
        
        // Data center access patterns
        /\b(dc-access)\b/i,
        /\b(dc_access)\b/i,
        /\b(datacenter.*access)\b/i,
        /\b(data.*center.*access)\b/i,
        /\b(rack.*access)\b/i,
        /\b(server.*access)\b/i,
        
        // Building access patterns
        /\b(bldg.*access)\b/i,
        /\b(building.*access)\b/i,
        /\b(floor.*access)\b/i,
        /\b(level.*access)\b/i,
        /\b(room.*access)\b/i,
        /\b(office.*access)\b/i,
        
        // Layer 2 access patterns
        /\b(l2.*access)\b/i,
        /\b(layer2.*access)\b/i,
        /\b(switching.*access)\b/i,
        
        // Wireless access patterns
        /\b(wireless.*access)\b/i,
        /\b(wifi.*access)\b/i,
        /\b(wap.*access)\b/i,
        /\b(ap.*access)\b/i,
        /\b(access.*point)\b/i,
        /\b(access_point)\b/i
    ];

    // Additional patterns that might indicate layer hierarchy
    static LAYER_INDICATORS = {
        // High-level indicators (likely core/distribution)
        HIGH_LEVEL: [
            /\b(backbone)\b/i,
            /\b(spine)\b/i,
            /\b(aggregation)\b/i,
            /\b(consolidation)\b/i,
            /\b(central)\b/i,
            /\b(main)\b/i,
            /\b(primary)\b/i,
            /\b(secondary)\b/i,
            /\b(intermediate)\b/i,
            /\b(middle)\b/i
        ],
        
        // Low-level indicators (likely access)
        LOW_LEVEL: [
            /\b(edge)\b/i,
            /\b(endpoint)\b/i,
            /\b(desktop)\b/i,
            /\b(workstation)\b/i,
            /\b(terminal)\b/i,
            /\b(port)\b/i,
            /\b(room)\b/i,
            /\b(office)\b/i,
            /\b(cubicle)\b/i
        ],
        
        // Connection count indicators
        HIGH_CONNECTIONS: 8,  // Devices with 8+ connections likely core/distribution
        LOW_CONNECTIONS: 2    // Devices with 2 or fewer connections likely access
    };

    // Device role mappings to network layers
    static ROLE_TO_LAYER = {
        'core-switch': this.LAYER_HIERARCHY.CORE,
        'core_switch': this.LAYER_HIERARCHY.CORE,
        'core': this.LAYER_HIERARCHY.CORE,
        'cs': this.LAYER_HIERARCHY.CORE,
        'backbone': this.LAYER_HIERARCHY.CORE,
        'spine': this.LAYER_HIERARCHY.CORE,
        'aggregation': this.LAYER_HIERARCHY.DISTRIBUTION,
        'distribution': this.LAYER_HIERARCHY.DISTRIBUTION,
        'distribution-switch': this.LAYER_HIERARCHY.DISTRIBUTION,
        'distribution_switch': this.LAYER_HIERARCHY.DISTRIBUTION,
        'dist': this.LAYER_HIERARCHY.DISTRIBUTION,
        'ds': this.LAYER_HIERARCHY.DISTRIBUTION,
        'access': this.LAYER_HIERARCHY.ACCESS,
        'access-switch': this.LAYER_HIERARCHY.ACCESS,
        'access_switch': this.LAYER_HIERARCHY.ACCESS,
        'as': this.LAYER_HIERARCHY.ACCESS,
        'edge': this.LAYER_HIERARCHY.ACCESS,
        'endpoint': this.LAYER_HIERARCHY.ACCESS
    };

    /**
     * Determine the network layer of a device based on its name and role
     * @param {Object} device - Device object with name, device_role, etc.
     * @param {number} connectionCount - Number of connections for this device
     * @returns {number} Layer hierarchy level (0=core, 1=distribution, 2=access, 3=unknown)
     */
    static getDeviceLayer(device, connectionCount = 0) {
        const deviceName = (device.hostname || device.name || '').toLowerCase();
        const deviceRole = (device.device_role || '').toLowerCase();
        const platform = (device.platform || '').toLowerCase();
        const model = (device.model || '').toLowerCase();
        
        // First check device role for explicit layer mapping
        if (deviceRole) {
            for (const [role, layer] of Object.entries(this.ROLE_TO_LAYER)) {
                if (deviceRole.includes(role)) {
                    return layer;
                }
            }
        }
        
        // Enhanced device classification based on name, platform, and model
        const deviceInfo = `${deviceName} ${platform} ${model}`;
        
        // Check device name against core patterns
        for (const pattern of this.CORE_PATTERNS) {
            if (pattern.test(deviceInfo)) {
                return this.LAYER_HIERARCHY.CORE;
            }
        }
        
        // Check device name against distribution patterns
        for (const pattern of this.DISTRIBUTION_PATTERNS) {
            if (pattern.test(deviceInfo)) {
                return this.LAYER_HIERARCHY.DISTRIBUTION;
            }
        }
        
        // Check device name against access patterns
        for (const pattern of this.ACCESS_PATTERNS) {
            if (pattern.test(deviceInfo)) {
                return this.LAYER_HIERARCHY.ACCESS;
            }
        }
        
        // Enhanced classification based on device characteristics
        return this.getLayerByDeviceCharacteristics(deviceName, platform, model, connectionCount);
    }

    /**
     * Enhanced device classification based on device characteristics
     * @param {string} deviceName - Device name in lowercase
     * @param {string} platform - Device platform in lowercase
     * @param {string} model - Device model in lowercase
     * @param {number} connectionCount - Number of connections
     * @returns {number} Layer hierarchy level
     */
    static getLayerByDeviceCharacteristics(deviceName, platform, model, connectionCount) {
        // Analyze device type and capabilities
        const deviceInfo = `${deviceName} ${platform} ${model}`;
        
        // Core device indicators (high-end switches and routers)
        if (this.isCoreDevice(deviceInfo, connectionCount)) {
            return this.LAYER_HIERARCHY.CORE;
        }
        
        // Distribution device indicators (mid-range devices with moderate connections)
        if (this.isDistributionDevice(deviceInfo, connectionCount)) {
            return this.LAYER_HIERARCHY.DISTRIBUTION;
        }
        
        // Access device indicators (edge devices, customer sites)
        if (this.isAccessDevice(deviceInfo, connectionCount)) {
            return this.LAYER_HIERARCHY.ACCESS;
        }
        
        // Fallback based on connection count
        return this.getLayerByConnectionCount(deviceName, connectionCount);
    }

    /**
     * Determine if device is a core device
     */
    static isCoreDevice(deviceInfo, connectionCount) {
        // High-end Cisco platforms typically used in core
        const corePlatforms = [
            /catalyst.*6[5-9][0-9][0-9]/i,  // Catalyst 6500, 6800, 6900 series
            /catalyst.*9[5-9][0-9][0-9]/i,  // Catalyst 9500, 9600 series
            /nexus.*[79][0-9][0-9][0-9]/i,  // Nexus 7000, 9000 series
            /csr1000v/i,                    // CSR1000V (virtual core router)
            /asr[19][0-9][0-9][0-9]/i,      // ASR 1000, 9000 series
        ];
        
        // Check for core naming patterns
        const coreNames = [
            /\b(hq.*core|core.*sw|core.*router)\b/i,
            /\b(backbone|spine|aggregation)\b/i,
            /\b(central|main|primary)\b/i
        ];
        
        // High connection count suggests core role
        const hasHighConnections = connectionCount >= 6;
        
        return corePlatforms.some(pattern => pattern.test(deviceInfo)) ||
               coreNames.some(pattern => pattern.test(deviceInfo)) ||
               (hasHighConnections && !this.isAccessDevice(deviceInfo, connectionCount));
    }

    /**
     * Determine if device is a distribution device
     */
    static isDistributionDevice(deviceInfo, connectionCount) {
        // Mid-range platforms typically used in distribution
        const distributionPlatforms = [
            /catalyst.*3[5-9][0-9][0-9]/i,  // Catalyst 3500, 3750, 3850 series
            /catalyst.*4[5-9][0-9][0-9]/i,  // Catalyst 4500, 4900 series
            /nexus.*[35][0-9][0-9][0-9]/i,  // Nexus 3000, 5000 series
            /3725/i,                        // Cisco 3725 router
        ];
        
        // Check for distribution naming patterns
        const distributionNames = [
            /\b(dist|distribution|agg|aggregation)\b/i,
            /\b(mpls.*router|wan.*router)\b/i,
            /\b(branch|regional)\b/i
        ];
        
        // Moderate connection count suggests distribution role
        const hasModerateConnections = connectionCount >= 3 && connectionCount < 6;
        
        return distributionPlatforms.some(pattern => pattern.test(deviceInfo)) ||
               distributionNames.some(pattern => pattern.test(deviceInfo)) ||
               hasModerateConnections;
    }

    /**
     * Determine if device is an access device
     */
    static isAccessDevice(deviceInfo, connectionCount) {
        // Access/edge device indicators
        const accessPatterns = [
            /\b(customer.*site|site.*router)\b/i,
            /\b(branch|remote|edge)\b/i,
            /\b(access|endpoint|terminal)\b/i,
            /\b(workstation|desktop|floor)\b/i
        ];
        
        // Low-end platforms typically used for access
        const accessPlatforms = [
            /catalyst.*2[0-9][0-9][0-9]/i,  // Catalyst 2000 series
            /catalyst.*3[0-4][0-9][0-9]/i,  // Catalyst 3000-3400 series
        ];
        
        // Low connection count suggests access role
        const hasLowConnections = connectionCount <= 3;
        
        return accessPatterns.some(pattern => pattern.test(deviceInfo)) ||
               accessPlatforms.some(pattern => pattern.test(deviceInfo)) ||
               hasLowConnections;
    }

    /**
     * Determine layer based on connection count and other indicators (fallback method)
     * @param {string} deviceName - Device name in lowercase
     * @param {number} connectionCount - Number of connections
     * @returns {number} Layer hierarchy level
     */
    static getLayerByConnectionCount(deviceName, connectionCount) {
        // Check for high-level indicators
        for (const pattern of this.LAYER_INDICATORS.HIGH_LEVEL) {
            if (pattern.test(deviceName)) {
                return connectionCount >= this.LAYER_INDICATORS.HIGH_CONNECTIONS 
                    ? this.LAYER_HIERARCHY.CORE 
                    : this.LAYER_HIERARCHY.DISTRIBUTION;
            }
        }
        
        // Check for low-level indicators
        for (const pattern of this.LAYER_INDICATORS.LOW_LEVEL) {
            if (pattern.test(deviceName)) {
                return this.LAYER_HIERARCHY.ACCESS;
            }
        }
        
        // Use connection count as final fallback
        if (connectionCount >= this.LAYER_INDICATORS.HIGH_CONNECTIONS) {
            return this.LAYER_HIERARCHY.CORE; // High connections likely core
        } else if (connectionCount >= 4) {
            return this.LAYER_HIERARCHY.DISTRIBUTION; // Medium connections likely distribution
        } else {
            return this.LAYER_HIERARCHY.ACCESS; // Low connections likely access
        }
    }

    /**
     * Get layer name for display purposes
     * @param {number} layer - Layer hierarchy level
     * @returns {string} Human-readable layer name
     */
    static getLayerName(layer) {
        switch (layer) {
            case this.LAYER_HIERARCHY.CORE:
                return 'Core';
            case this.LAYER_HIERARCHY.DISTRIBUTION:
                return 'Distribution';
            case this.LAYER_HIERARCHY.ACCESS:
                return 'Access';
            default:
                return 'Unknown';
        }
    }

    /**
     * Get layer color for visualization
     * @param {number} layer - Layer hierarchy level
     * @returns {string} CSS color value
     */
    static getLayerColor(layer) {
        switch (layer) {
            case this.LAYER_HIERARCHY.CORE:
                return '#dc3545'; // Red for core
            case this.LAYER_HIERARCHY.DISTRIBUTION:
                return '#fd7e14'; // Orange for distribution
            case this.LAYER_HIERARCHY.ACCESS:
                return '#28a745'; // Green for access
            default:
                return '#6c757d'; // Gray for unknown
        }
    }
}

// Export for global use
window.NetworkConstants = NetworkConstants;

