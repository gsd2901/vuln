/**
 * Topology Viewer Main Class
 * Interactive network topology visualization for Nautobot
 */

class TopologyViewer {
    constructor(config) {
        this.config = config;
        this.svg = null;
        this.devices = [];
        this.connections = [];
        this.deviceElements = new Map();
        this.selectedDevice = null;
        this.isLoading = false;
        
        // Initialize components
        this.dragging = null;
        this.connectionRenderer = null;
        this.autoLayout = null;
        this.zoomPan = null;
        
        // Management connections mode: 'all', 'only', 'none'
        this.managementMode = 'all';
        
        // Event handlers
        this.onPositionChange = this.onPositionChange.bind(this);
        this.onDeviceSelect = this.onDeviceSelect.bind(this);
    }

    async init() {
        try {
            this.setupUI();
            this.showLoading(true);
            await this.loadTopologyData();
            this.renderTopology();
            // Load saved layout if available, otherwise apply hierarchical layout
            this.loadSavedLayout();
            this.setupEventListeners();
            this.showLoading(false);
        } catch (error) {
            console.error('Failed to initialize topology viewer:', error);
            this.showError('Failed to load topology data');
        }
    }

    async loadTopologyData() {
        let response;
        
        // Check if we're loading discovery topology data
        if (this.config.discoverySessionId) {
            response = await fetch(`/plugins/inventory/api/topology/${this.config.discoverySessionId}/`);
        } else {
            response = await fetch(this.config.apiUrls.topology);
        }
        
        if (!response.ok) {
            throw new Error(`HTTP ${response.status}: ${response.statusText}`);
        }
        
        const data = await response.json();
        
        if (this.config.discoverySessionId) {
            // Handle discovery topology data format
            this.devices = data.devices || [];
            this.connections = data.connections || [];
            this.sessionInfo = data.session_info || {};
            
            // Filter out disconnected devices
            this.devices = this.devices.filter(device => 
                !device.metadata?.disconnected && 
                device.status !== 'disconnected'
            );
            
            // Filter out connections to disconnected devices
            this.connections = this.connections.filter(connection => {
                const sourceExists = this.devices.some(device => device.id === connection.source);
                const targetExists = this.devices.some(device => device.id === connection.target);
                return sourceExists && targetExists;
            });
            
            console.log(`Loaded discovery topology: ${this.devices.length} devices and ${this.connections.length} connections`);
            console.log('Session info:', this.sessionInfo);
        } else {
            // Handle standard topology data format
            this.devices = data.devices || [];
            this.connections = data.connections || [];
            
            console.log(`Loaded ${this.devices.length} devices and ${this.connections.length} connections`);
        }
        
        // Enhance devices with detailed interface information
        await this.enhanceDevicesWithInterfaceData();
    }

    async enhanceDevicesWithInterfaceData() {
        // For discovery mode, fetch detailed device information including interface data
        if (this.config.discoverySessionId) {
            const devicePromises = this.devices.map(async (device) => {
                try {
                    // Fetch detailed device information using correct API format
                    // The API expects: /plugins/inventory/api/device-detail/{session_id}/{device_ip}/
                    const deviceIp = device.ip_address || device.id.replace('device_', '').replace(/_/g, '.');
                    const response = await fetch(`/plugins/inventory/api/device-detail/${this.config.discoverySessionId}/${deviceIp}/`);
                    if (response.ok) {
                        const deviceData = await response.json();
                        if (deviceData.status === 'success' && deviceData.device) {
                            // Enhance device with interface analysis
                            device.interface_analysis = deviceData.device.interface_analysis;
                            device.neighbors = deviceData.device.neighbors;
                            device.command_outputs = deviceData.device.command_outputs;
                            
                            // Extract connected interfaces
                            device.connected_interfaces = this.extractConnectedInterfaces(deviceData.device);
                            
                            console.log(`Enhanced device ${device.name} with interface data:`, device.connected_interfaces);
                        }
                    } else {
                        console.warn(`Failed to fetch device details for ${device.name} (${deviceIp}): HTTP ${response.status}`);
                    }
                } catch (error) {
                    console.warn(`Failed to fetch interface data for device ${device.id}:`, error);
                }
                return device;
            });
            
            this.devices = await Promise.all(devicePromises);
        }
    }

    extractConnectedInterfaces(deviceData) {
        const connectedInterfaces = [];
        
        if (deviceData.interface_analysis && deviceData.interface_analysis.interfaces) {
            deviceData.interface_analysis.interfaces.forEach(interfaceInfo => {
                // Skip interfaces that are explicitly down in status
                if (interfaceInfo.status === 'down') {
                    return;
                }
                
                // Skip loopback interfaces (they're virtual)
                if (interfaceInfo.name && interfaceInfo.name.toLowerCase().includes('loopback')) {
                    return;
                }
                
                // Parse interface name for better structure
                const parsedInterface = NetworkUtils.parseInterfaceName(interfaceInfo.name);
                const ipInfo = NetworkUtils.extractIPFromConfig(
                    deviceData.command_outputs?.show_running_config, 
                    interfaceInfo.name
                );
                
                // Include the interface if it's up
                connectedInterfaces.push({
                    name: interfaceInfo.name,
                    status: interfaceInfo.status,
                    protocol: interfaceInfo.protocol,
                    description: interfaceInfo.description,
                    is_trunk: this.isTrunkInterface(interfaceInfo),
                    vlan: this.extractVlanFromDescription(interfaceInfo.description),
                    // Enhanced interface information
                    short_name: parsedInterface.shortName || this.getShortInterfaceName(interfaceInfo.name),
                    display_name: this.getDisplayInterfaceName(interfaceInfo.name),
                    interface_type: parsedInterface.type || this.getInterfaceType(interfaceInfo.name),
                    speed: NetworkConstants.getInterfaceSpeed(interfaceInfo.name),
                    slot: parsedInterface.slot,
                    port: parsedInterface.port,
                    ip_address: ipInfo?.ip,
                    subnet_mask: ipInfo?.mask,
                    duplex: 'unknown' // Will be updated from neighbor data
                });
            });
        }
        
        // Enhance with neighbor data for duplex and connection info
        if (deviceData.neighbors) {
            deviceData.neighbors.forEach(neighbor => {
                const localInterface = connectedInterfaces.find(iface => iface.name === neighbor.local_interface);
                if (localInterface) {
                    localInterface.connected_to = {
                        device: neighbor.hostname,
                        interface: neighbor.remote_interface,
                        ip_address: neighbor.ip_address,
                        platform: neighbor.platform,
                        capabilities: neighbor.capabilities
                    };
                    localInterface.duplex = NetworkUtils.getDuplexStatus(neighbor);
                    
                    // Extract VLAN from neighbor data if available
                    if (neighbor.vlan_id && !localInterface.vlan) {
                        localInterface.vlan = neighbor.vlan_id;
                    }
                }
            });
        }
        
        console.log(`Extracted ${connectedInterfaces.length} connected interfaces from device`, deviceData.hostname, connectedInterfaces);
        return connectedInterfaces;
    }

    isTrunkInterface(interfaceInfo) {
        // Check if interface is configured as trunk based on description or name patterns
        const description = (interfaceInfo.description || '').toLowerCase();
        const name = (interfaceInfo.name || '').toLowerCase();
        
        // Common trunk indicators
        const trunkIndicators = [
            'trunk', 'uplink', 'backbone', 'core', 'distribution',
            'te1/', 'te2/', 'fo1/', 'fo2/', 'twentyfivegig', 'fortygig'
        ];
        
        return trunkIndicators.some(indicator => 
            description.includes(indicator) || name.includes(indicator)
        );
    }

    extractVlanFromDescription(description) {
        if (!description) return null;
        
        // Look for VLAN patterns in description
        const vlanMatch = description.match(/vlan\s*(\d+)/i);
        return vlanMatch ? vlanMatch[1] : null;
    }

    getShortInterfaceName(interfaceName) {
        if (!interfaceName) return null;
        
        // Return original interface name without truncation
        return interfaceName;
    }

    getDisplayInterfaceName(interfaceName) {
        if (!interfaceName) return null;
        
        // Return original interface name without truncation
        return interfaceName;
    }

    getInterfaceType(interfaceName) {
        if (!interfaceName) return 'unknown';
        
        const name = interfaceName.toLowerCase();
        
        if (name.includes('gigabit') || name.includes('gi')) return 'gigabit';
        if (name.includes('fast') || name.includes('fa')) return 'fast';
        if (name.includes('ten') || name.includes('te')) return 'ten-gigabit';
        if (name.includes('forty') || name.includes('fo')) return 'forty-gigabit';
        if (name.includes('twentyfive') || name.includes('25gi')) return 'twentyfive-gigabit';
        if (name.includes('loopback') || name.includes('lo')) return 'loopback';
        if (name.includes('vlan') || name.includes('vl')) return 'vlan';
        if (name.includes('port-channel') || name.includes('po')) return 'port-channel';
        if (name.includes('serial') || name.includes('se')) return 'serial';
        if (name.includes('app') || name.includes('ap')) return 'app-hosting';
        if (name.includes('bluetooth') || name.includes('bt')) return 'bluetooth';
        
        return 'ethernet';
    }

    getInterfaceCapacitySummary(interfaces) {
        if (!interfaces || interfaces.length === 0) return 'Unknown';
        
        const capacityCounts = {};
        
        interfaces.forEach(iface => {
            const type = this.getInterfaceType(iface.name);
            const capacity = this.getInterfaceCapacity(type);
            
            if (capacityCounts[capacity]) {
                capacityCounts[capacity]++;
            } else {
                capacityCounts[capacity] = 1;
            }
        });
        
        // Create summary string
        const summaryParts = [];
        Object.entries(capacityCounts).forEach(([capacity, count]) => {
            summaryParts.push(`${capacity}×${count}`);
        });
        
        return summaryParts.join(', ');
    }

    getInterfaceCapacity(interfaceType) {
        const capacityMap = {
            'fast': '100M',
            'gigabit': '1G',
            'ten-gigabit': '10G',
            'forty-gigabit': '40G',
            'twentyfive-gigabit': '25G',
            'loopback': 'N/A',
            'vlan': 'N/A',
            'port-channel': 'Aggregated',
            'serial': 'Serial',
            'app-hosting': 'App',
            'bluetooth': 'BT',
            'ethernet': '1G',
            'unknown': 'Unknown'
        };
        
        return capacityMap[interfaceType] || 'Unknown';
    }

    setupUI() {
        this.svg = document.getElementById('topology-svg');
        if (!this.svg) {
            throw new Error('Topology SVG element not found');
        }

        // Set SVG viewBox to match container dimensions
        this.updateSVGViewBox();

        // Check if TopologyUtils is available
        if (typeof window.TopologyUtils === 'undefined') {
            throw new Error('TopologyUtils not loaded. Make sure topology_utils.js is loaded before topology_viewer.js');
        }

        // Initialize components
        this.dragging = new TopologyUtils.TopologyDragging(this.svg, this.onPositionChange);
        this.connectionRenderer = new TopologyUtils.ConnectionRenderer(this.svg);
        this.autoLayout = new TopologyUtils.AutoLayout(this.svg);
        this.zoomPan = new TopologyUtils.ZoomPan(this.svg, document.getElementById('topology-canvas'));
        
        // Connect dragging and zoomPan to resolve coordinate space issues
        this.dragging.setZoomPan(this.zoomPan);

        // Load saved layout if available
        this.loadSavedLayout();

        // Add resize listener to update viewBox when window resizes
        window.addEventListener('resize', () => {
            this.updateSVGViewBox();
            // Re-render connections after viewBox update
            setTimeout(() => {
                this.connectionRenderer.renderConnections(this.connections);
            }, 100);
        });
    }

    updateSVGViewBox() {
        const container = document.getElementById('topology-canvas');
        if (!container || !this.svg) return;

        const rect = container.getBoundingClientRect();
        const containerWidth = rect.width;
        const containerHeight = rect.height;

        // Use a much larger coordinate space for topology visualization
        // This provides more room for device positioning and prevents cramped layouts
        const viewBoxWidth = Math.max(2000, containerWidth * 2);
        const viewBoxHeight = Math.max(1500, containerHeight * 2);

        // Set viewBox to provide adequate coordinate space
        this.svg.setAttribute('viewBox', `0 0 ${viewBoxWidth} ${viewBoxHeight}`);
        
        console.log(`Updated SVG viewBox to: 0 0 ${viewBoxWidth} ${viewBoxHeight} (container: ${containerWidth}x${containerHeight})`);
    }

    renderTopology() {
        // Don't clear layer indicators here - they should persist after layout is applied
        // Layer indicators are managed by the layout algorithms themselves
        
        this.renderDevices();
        // Pass devices array to connection renderer for enhanced labeling
        this.connectionRenderer.setDevices(this.devices);
        
        // Use setTimeout to ensure DOM elements are fully created before rendering connections
        setTimeout(() => {
            this.connectionRenderer.renderConnections(this.connections);
        }, 0);
        
        // Update device count badge
        const deviceCountBadge = document.getElementById('device-count-badge');
        if (deviceCountBadge) {
            deviceCountBadge.textContent = `${this.devices.length} devices`;
        }
    }

    clearLayerIndicators() {
        // Remove existing layer indicators
        const layersGroup = this.svg?.querySelector('#layers-group');
        if (layersGroup) {
            layersGroup.remove();
        }
    }

    renderDevices() {
        const devicesLayer = this.svg.querySelector('#devices-layer');
        if (!devicesLayer) return;

        // Clear existing devices
        devicesLayer.innerHTML = '';

        this.devices.forEach(device => {
            console.log(`Rendering device: ${device.id} (${device.name})`);
            const deviceElement = this.createDeviceElement(device);
            devicesLayer.appendChild(deviceElement);
            this.deviceElements.set(device.id, deviceElement);
        });
    }

    createDeviceElement(device) {
        const group = document.createElementNS('http://www.w3.org/2000/svg', 'g');
        group.setAttribute('class', 'device-node');
        group.setAttribute('data-device-id', device.id);
        group.setAttribute('data-x', device.position?.x || 0);
        group.setAttribute('data-y', device.position?.y || 0);

        // Add discovery-specific attributes
        if (device.discovery_depth !== undefined) {
            group.setAttribute('data-discovery-depth', device.discovery_depth);
        }
        if (device.discovered_via) {
            group.setAttribute('data-discovered-via', device.discovered_via);
        }
        if (device.ip_address) {
            group.setAttribute('data-ip-address', device.ip_address);
        }
        
        // Add network layer information
        if (device.networkLayer) {
            group.setAttribute('data-layer', device.networkLayer);
        }
        
        // Add disconnected device indicator
        if (device.metadata && device.metadata.disconnected) {
            group.setAttribute('data-disconnected', 'true');
            group.classList.add('disconnected-device');
        }

        // Apply saved position
        if (device.position) {
            group.style.transform = `translate(${device.position.x}px, ${device.position.y}px)`;
        }

        // Create device icon
        const icon = this.createDeviceIcon(device);
        group.appendChild(icon);

        // Create device label
        const label = this.createDeviceLabel(device);
        group.appendChild(label);

        // Add discovery status indicator if applicable
        if (this.config.discoverySessionId && device.status) {
            const statusIndicator = this.createDiscoveryStatusIndicator(device);
            group.appendChild(statusIndicator);
        }
        
        // Add interface information if available
        if (device.connected_interfaces && device.connected_interfaces.length > 0) {
            const interfaceInfo = this.createInterfaceInfo(device);
            group.appendChild(interfaceInfo);
        }
        
        // Add disconnected device indicator
        if (device.metadata && device.metadata.disconnected) {
            const disconnectedIndicator = this.createDisconnectedIndicator(device);
            group.appendChild(disconnectedIndicator);
        }

        // Add click handler
        group.addEventListener('click', (e) => {
            e.stopPropagation();
            this.onDeviceSelect(device);
        });

        return group;
    }

    createDeviceIcon(device) {
        const group = document.createElementNS('http://www.w3.org/2000/svg', 'g');
        
        // Determine device type for icon selection
        const deviceType = this.getDeviceTypeForIcon(device);
        const useImageIcon = (deviceType === 'router' || deviceType === 'switch');

        // Use PNG images for routers and switches, regardless of disconnection status
            // Use PNG image for router/switch - larger size since no circle background
            const image = document.createElementNS('http://www.w3.org/2000/svg', 'image');
            const imagePath = deviceType === 'router' 
                ? '/static/nautobot_topology_viewer/router.png' 
                : '/static/nautobot_topology_viewer/switch.png';
            
            console.log(`Using image icon for ${device.name}: ${imagePath} (detected type: ${deviceType})`);
            
            image.setAttribute('href', imagePath);
            image.setAttribute('x', '-35');
            image.setAttribute('y', '-35');
            image.setAttribute('width', '70');
            image.setAttribute('height', '70');
            image.setAttribute('class', 'device-image-icon');
            
            // Add disconnected styling if applicable
                image.setAttribute('class', 'device-image-icon disconnected-device-icon');
                // Add a semi-transparent overlay for disconnected devices
                const overlay = document.createElementNS('http://www.w3.org/2000/svg', 'rect');
                overlay.setAttribute('x', '-35');
                overlay.setAttribute('y', '-35');
                overlay.setAttribute('width', '70');
                overlay.setAttribute('height', '70');
                overlay.setAttribute('fill', 'rgba(255, 255, 255, 0.7)');
                overlay.setAttribute('class', 'disconnected-overlay');
                group.appendChild(overlay);
            
            group.appendChild(image);

        return group;
    }
    
    getDeviceTypeForIcon(device) {
        // Debug logging for device type detection
        console.log(`Detecting device type for ${device.name}:`, {
            device_type: device.device_type,
            device_role: device.device_role,
            platform: device.platform,
            model: device.model,
            name: device.name,
            hostname: device.hostname
        });
        
        // For discovery data, check device_type first (this comes from the backend analysis)
        if (device.device_type) {
            const type = device.device_type.toLowerCase();
            console.log(`Using device_type field: ${type}`);
            
            if (type.includes('router') || type === 'router') return 'router';
            if (type.includes('switch') || type === 'switch') return 'switch';
            if (type.includes('firewall')) return 'firewall';
            if (type.includes('server')) return 'server';
            if (type.includes('access-point') || type.includes('wireless')) return 'access-point';
            if (type.includes('load-balancer')) return 'load-balancer';
        }
        
        // Check device role (for standard Nautobot devices) - enhanced patterns
        const role = (device.device_role || '').toLowerCase();
        if (role) {
            console.log(`Checking device_role: ${role}`);
            if (role.includes('router') || role.includes('rtr')) return 'router';
            if (role.includes('switch') || role.includes('sw') || role.includes('access') || role.includes('distribution') || role.includes('core')) return 'switch';
            if (role.includes('firewall') || role.includes('fw')) return 'firewall';
            if (role.includes('server') || role.includes('srv')) return 'server';
            if (role.includes('wireless') || role.includes('ap') || role.includes('access-point')) return 'access-point';
            if (role.includes('load') && role.includes('balancer')) return 'load-balancer';
        }
        
        // Check device name/hostname for common patterns
        const deviceName = (device.name || device.hostname || '').toLowerCase();
        if (deviceName) {
            console.log(`Checking device name: ${deviceName}`);
            if (deviceName.includes('router') || deviceName.includes('rtr') || deviceName.includes('-r-') || deviceName.includes('-r1') || deviceName.includes('-r2')) return 'router';
            if (deviceName.includes('switch') || deviceName.includes('sw') || deviceName.includes('-s-') || deviceName.includes('-s1') || deviceName.includes('-s2') || 
                deviceName.includes('access') || deviceName.includes('dist') || deviceName.includes('core')) return 'switch';
            if (deviceName.includes('firewall') || deviceName.includes('fw') || deviceName.includes('asa')) return 'firewall';
            if (deviceName.includes('server') || deviceName.includes('srv') || deviceName.includes('host')) return 'server';
            if (deviceName.includes('ap') || deviceName.includes('wireless') || deviceName.includes('wlc')) return 'access-point';
        }
        
        // Check platform for additional clues
        const platform = (device.platform || '').toLowerCase();
        if (platform) {
            console.log(`Checking platform: ${platform}`);
            
            // Cisco platform detection
            if (platform.includes('cisco')) {
                if (platform.includes('asa') || platform.includes('ftd')) return 'firewall';
                if (platform.includes('isr') || platform.includes('asr')) return 'router';
                if (platform.includes('catalyst') || platform.includes('nexus')) return 'switch';
            }
            
            // Other vendor detection
            if (platform.includes('aruba') || platform.includes('hp')) return 'switch';
            if (platform.includes('juniper')) {
                if (platform.includes('srx')) return 'firewall';
                if (platform.includes('mx') || platform.includes('acx')) return 'router';
                if (platform.includes('ex') || platform.includes('qfx')) return 'switch';
            }
            if (platform.includes('arista')) return 'switch';
            if (platform.includes('fortinet') || platform.includes('fortigate')) return 'firewall';
            if (platform.includes('palo alto') || platform.includes('pan-os')) return 'firewall';
            if (platform.includes('f5')) return 'load-balancer';
            
            // Generic platform keywords
            if (platform.includes('router')) return 'router';
            if (platform.includes('switch')) return 'switch';
            if (platform.includes('firewall')) return 'firewall';
            if (platform.includes('server')) return 'server';
        }
        
        // Check model for additional clues
        const model = (device.model || '').toLowerCase();
        if (model) {
            console.log(`Checking model: ${model}`);
            
            // Cisco model patterns
            if (model.includes('catalyst') || model.includes('c9300') || model.includes('c9200') || 
                model.includes('c3850') || model.includes('c2960') || model.includes('nexus')) return 'switch';
            if (model.includes('isr') || model.includes('asr') || model.includes('c19') || 
                model.includes('c29') || model.includes('c39')) return 'router';
            if (model.includes('asa') || model.includes('ftd')) return 'firewall';
            
            // Generic model keywords
            if (model.includes('switch')) return 'switch';
            if (model.includes('router')) return 'router';
            if (model.includes('firewall')) return 'firewall';
        }
        
        console.log(`No specific device type detected for ${device.name}, defaulting to 'other'`);
        return 'other';
    }
    
    getDeviceFontAwesomeIcon(device) {
        // Get normalized values (handle null/undefined safely)
        const platform = (device.platform || '').toLowerCase();
        const manufacturer = (device.manufacturer || '').toLowerCase();
        const role = (device.device_role || '').toLowerCase();
        const deviceType = (device.device_type || '').toLowerCase();
        const model = (device.model || '').toLowerCase();
        
        // First, use the device type detection result
        const detectedType = this.getDeviceTypeForIcon(device);
        console.log(`Using detected device type '${detectedType}' for icon selection for ${device.name}`);
        
        // Map detected types to Font Awesome icons
        switch (detectedType) {
            case 'router':
                return 'fas fa-route';
            case 'switch':
                return 'fas fa-network-wired';
            case 'firewall':
                return 'fas fa-shield-alt';
            case 'server':
                return 'fas fa-server';
            case 'access-point':
                return 'fas fa-wifi';
            case 'load-balancer':
                return 'fas fa-balance-scale';
        }
        
        // Fallback: Check device_type for specific model patterns (e.g., "Catalyst 8500-12X")
        if (deviceType) {
            // Check for specific device type keywords
            if (deviceType.includes('router') || deviceType.includes('asr') || deviceType.includes('isr')) {
                return 'fas fa-route';
            }
            if (deviceType.includes('switch') || deviceType.includes('catalyst') || deviceType.includes('nexus')) {
                return 'fas fa-network-wired';
            }
            if (deviceType.includes('firewall') || deviceType.includes('asa') || deviceType.includes('ftd')) {
                return 'fas fa-shield-alt';
            }
            if (deviceType.includes('server')) {
                return 'fas fa-server';
            }
            if (deviceType.includes('access-point') || deviceType.includes('ap')) {
                return 'fas fa-wifi';
            }
            if (deviceType.includes('load-balancer')) {
                return 'fas fa-balance-scale';
            }
            if (deviceType.includes('storage')) {
                return 'fas fa-hdd';
            }
        }
        
        // Cisco-specific icons based on device role and platform
        if (platform.includes('cisco') || manufacturer.includes('cisco')) {
            if (role.includes('router')) {
                return 'fas fa-route';
            } else if (role.includes('switch') || role.includes('access')) {
                return 'fas fa-sitemap';
            } else if (role.includes('firewall')) {
                return 'fas fa-shield-alt';
            } else {
                return 'fas fa-network-wired'; // Default Cisco icon
            }
        }
        
        // Other vendor-specific icons
        if (platform.includes('arista') || manufacturer.includes('arista')) {
            return 'fas fa-project-diagram';
        }
        if (platform.includes('juniper') || manufacturer.includes('juniper')) {
            return 'fas fa-sitemap';
        }
        if (platform.includes('aruba') || manufacturer.includes('aruba') || manufacturer.includes('hp')) {
            return 'fas fa-network-wired';
        }
        if (platform.includes('nokia') || manufacturer.includes('nokia')) {
            return 'fas fa-broadcast-tower';
        }
        if (platform.includes('fortinet') || manufacturer.includes('fortinet')) {
            return 'fas fa-shield-alt';
        }
        if (platform.includes('palo alto') || manufacturer.includes('palo alto')) {
            return 'fas fa-fire';
        }
        
        // Fallback to device role
        if (role.includes('router')) return 'fas fa-route';
        if (role.includes('switch') || role.includes('access')) return 'fas fa-network-wired';
        if (role.includes('server')) return 'fas fa-server';
        if (role.includes('firewall')) return 'fas fa-shield-alt';
        if (role.includes('wireless') || role.includes('ap')) return 'fas fa-wifi';
        if (role.includes('load balancer')) return 'fas fa-balance-scale';
        
        // Ultimate fallback
        return 'fas fa-cube';
    }

    getPlatformClass(device) {
        const platform = (device.platform || '').toLowerCase();
        const manufacturer = (device.manufacturer || '').toLowerCase();
        
        if (platform.includes('cisco') || manufacturer.includes('cisco')) return 'platform-cisco';
        if (platform.includes('aruba') || manufacturer.includes('aruba')) return 'platform-aruba';
        if (platform.includes('juniper') || manufacturer.includes('juniper')) return 'platform-juniper';
        if (platform.includes('hp') || manufacturer.includes('hp') || platform.includes('procurve')) return 'platform-hp';
        if (platform.includes('arista') || manufacturer.includes('arista')) return 'platform-arista';
        if (platform.includes('nokia') || manufacturer.includes('nokia')) return 'platform-nokia';
        if (platform.includes('fortinet') || manufacturer.includes('fortinet')) return 'platform-fortinet';
        return '';
    }

    createDeviceLabel(device) {
        const text = document.createElementNS('http://www.w3.org/2000/svg', 'text');
        text.setAttribute('x', '0');
        text.setAttribute('y', '50');
        text.setAttribute('text-anchor', 'middle');
        text.setAttribute('class', 'device-label');
        text.textContent = device.name;

        return text;
    }

    getDeviceTypeClass(device) {
        const role = device.device_role?.toLowerCase() || 'unknown';
        if (role.includes('router')) return 'router';
        if (role.includes('switch')) return 'switch';
        if (role.includes('server')) return 'server';
        if (role.includes('firewall')) return 'firewall';
        return 'unknown';
    }

    getStatusClass(device) {
        const status = device.status?.toLowerCase() || 'unknown';
        
        // Handle discovery-specific statuses
        if (status === 'connected') return 'active';
        if (status === 'disconnected') return 'offline';
        if (status === 'discovering') return 'discovering';
        
        // Handle standard statuses
        if (status.includes('active')) return 'active';
        if (status.includes('planned')) return 'planned';
        if (status.includes('offline')) return 'offline';
        return 'unknown';
    }

    getDeviceIcon(device) {
        const role = device.device_role?.toLowerCase() || 'unknown';
        if (role.includes('router')) return 'R';
        if (role.includes('switch')) return 'S';
        if (role.includes('server')) return 'H';
        if (role.includes('firewall')) return 'F';
        return '?';
    }

    createDiscoveryStatusIndicator(device) {
        const status = device.status?.toLowerCase() || 'unknown';
        
        // Create status indicator circle
        const indicator = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
        indicator.setAttribute('cx', '25');
        indicator.setAttribute('cy', '-25');
        indicator.setAttribute('r', '8');
        indicator.setAttribute('class', `discovery-status-indicator status-${status}`);
        
        // Add status text
        const text = document.createElementNS('http://www.w3.org/2000/svg', 'text');
        text.setAttribute('x', '25');
        text.setAttribute('y', '-20');
        text.setAttribute('text-anchor', 'middle');
        text.setAttribute('class', 'discovery-status-text');
        text.setAttribute('font-size', '10');
        text.setAttribute('fill', 'white');
        
        // Set status symbol
        let statusSymbol = '?';
        if (status === 'connected') statusSymbol = '✓';
        else if (status === 'disconnected') statusSymbol = '✗';
        else if (status === 'discovering') statusSymbol = '⟳';
        
        text.textContent = statusSymbol;
        
        const group = document.createElementNS('http://www.w3.org/2000/svg', 'g');
        group.appendChild(indicator);
        group.appendChild(text);
        
        return group;
    }
    
    createDisconnectedIndicator(device) {
        // Create disconnected device indicator
        const group = document.createElementNS('http://www.w3.org/2000/svg', 'g');
        group.setAttribute('class', 'disconnected-indicator');
        
        // Create dashed circle around device
        const dashedCircle = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
        dashedCircle.setAttribute('cx', '0');
        dashedCircle.setAttribute('cy', '0');
        dashedCircle.setAttribute('r', '40');
        dashedCircle.setAttribute('fill', 'none');
        dashedCircle.setAttribute('stroke', '#ff4444');
        dashedCircle.setAttribute('stroke-width', '3');
        dashedCircle.setAttribute('stroke-dasharray', '5,5');
        dashedCircle.setAttribute('opacity', '0.8');
        
        // Create "DISCONNECTED" text
        const text = document.createElementNS('http://www.w3.org/2000/svg', 'text');
        text.setAttribute('x', '0');
        text.setAttribute('y', '60');
        text.setAttribute('text-anchor', 'middle');
        text.setAttribute('class', 'disconnected-text');
        text.setAttribute('font-size', '9');
        text.setAttribute('fill', '#ff4444');
        text.setAttribute('font-weight', 'bold');
        text.textContent = 'DISCONNECTED';
        
        group.appendChild(dashedCircle);
        group.appendChild(text);
        
        return group;
    }
    
    createInterfaceInfo(device) {
        const group = document.createElementNS('http://www.w3.org/2000/svg', 'g');
        group.setAttribute('class', 'interface-info');
        
        // Count trunk and access interfaces
        const trunkInterfaces = device.connected_interfaces.filter(iface => iface.is_trunk);
        const accessInterfaces = device.connected_interfaces.filter(iface => !iface.is_trunk);
        
        // Create interface summary
        const summary = document.createElementNS('http://www.w3.org/2000/svg', 'text');
        summary.setAttribute('x', '0');
        summary.setAttribute('y', '70');
        summary.setAttribute('text-anchor', 'middle');
        summary.setAttribute('class', 'interface-summary');
        summary.setAttribute('font-size', '20');
        summary.setAttribute('fill', '#666');
        
        let summaryText = '';
        if (trunkInterfaces.length > 0) {
            summaryText += `T:${trunkInterfaces.length}`;
        }
        if (accessInterfaces.length > 0) {
            if (summaryText) summaryText += ' ';
            summaryText += `A:${accessInterfaces.length}`;
        }
        
        summary.textContent = summaryText;
        group.appendChild(summary);
        
        // Add trunk/access indicators around the device
        this.addInterfaceIndicators(group, device.connected_interfaces);
        
        return group;
    }
    
    addInterfaceIndicators(group, interfaces) {
        const trunkInterfaces = interfaces.filter(iface => iface.is_trunk);
        const accessInterfaces = interfaces.filter(iface => !iface.is_trunk);
        
        // Position indicators around the device circle
        const radius = 50; // Slightly outside the device circle
        const angleStep = (2 * Math.PI) / Math.max(interfaces.length, 1);
        
        // Add trunk interface indicators (red)
        trunkInterfaces.forEach((iface, index) => {
            const angle = (index * angleStep) - (Math.PI / 2); // Start from top
            const x = Math.cos(angle) * radius;
            const y = Math.sin(angle) * radius;
            
            const indicator = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
            indicator.setAttribute('cx', x);
            indicator.setAttribute('cy', y);
            indicator.setAttribute('r', '4');
            indicator.setAttribute('fill', '#dc3545');
            indicator.setAttribute('stroke', 'white');
            indicator.setAttribute('stroke-width', '1');
            indicator.setAttribute('class', 'trunk-indicator');
            indicator.setAttribute('title', `Trunk: ${iface.name}`);
            
            group.appendChild(indicator);
        });
        
        // Add access interface indicators (blue)
        accessInterfaces.forEach((iface, index) => {
            const angle = ((trunkInterfaces.length + index) * angleStep) - (Math.PI / 2);
            const x = Math.cos(angle) * radius;
            const y = Math.sin(angle) * radius;
            
            const indicator = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
            indicator.setAttribute('cx', x);
            indicator.setAttribute('cy', y);
            indicator.setAttribute('r', '4');
            indicator.setAttribute('fill', '#007bff');
            indicator.setAttribute('stroke', 'white');
            indicator.setAttribute('stroke-width', '1');
            indicator.setAttribute('class', 'access-indicator');
            indicator.setAttribute('title', `Access: ${iface.name}`);
            
            group.appendChild(indicator);
        });
    }

    populateDeviceDetails(device) {
        // Populate overview tab
        this.populateOverviewTab(device);
        
        // Populate interfaces tab
        this.populateInterfacesTab(device);
        
        // Populate connections tab
        this.populateConnectionsTab(device);
        
        // Populate system info tab
        this.populateSystemTab(device);
        
        // Populate status tab (only for location topology, not discovery mode)
        if (!this.config.discoverySessionId) {
            this.populateStatusTab(device);
        }
        
        // Populate config tab (only for location topology, not discovery mode)
        if (!this.config.discoverySessionId) {
            this.populateConfigTab(device);
        }
        
        // Make sure overview tab is active by default
        this.switchTab('overview');
    }

    populateOverviewTab(device) {
        const overviewPane = document.getElementById('tab-overview');
        if (!overviewPane) return;

        const platform = device.platform || 'Unknown';
        const role = device.device_role || 'Unknown';
        const status = device.status || 'Unknown';
        const connections = device.connection_count || 0;

        overviewPane.innerHTML = `
            <div class="device-overview-grid">
                <div class="overview-card">
                    <h6><i class="fas fa-info-circle"></i> Basic Information</h6>
                    <div class="card-content">
                        <div class="overview-item">
                            <span class="overview-label">Hostname</span>
                            <span class="overview-value">${device.hostname || device.name || 'Unknown'}</span>
                        </div>
                        <div class="overview-item">
                            <span class="overview-label">Device Type</span>
                            <span class="overview-value">${device.device_type || 'Unknown'}</span>
                        </div>
                        <div class="overview-item">
                            <span class="overview-label">Role</span>
                            <span class="overview-value">${role}</span>
                        </div>
                        <div class="overview-item">
                            <span class="overview-label">Status</span>
                            <span class="status-badge ${this.getStatusClass(device)}">${status}</span>
                        </div>
                    </div>
                </div>
                
                <div class="overview-card">
                    <h6><i class="fas fa-network-wired"></i> Network Information</h6>
                    <div class="card-content">
                        <div class="overview-item">
                            <span class="overview-label">Platform</span>
                            <span class="overview-value">${platform}</span>
                        </div>
                        <div class="overview-item">
                            <span class="overview-label">Primary IP</span>
                            <span class="overview-value">${device.primary_ip4 || device.primary_ip6 || 'Not assigned'}</span>
                        </div>
                        <div class="overview-item">
                            <span class="overview-label">Connections</span>
                            <span class="overview-value">${connections}</span>
                        </div>
                        <div class="overview-item">
                            <span class="overview-label">Location</span>
                            <span class="overview-value">${device.location || 'Unknown'}</span>
                        </div>
                    </div>
                </div>
                
                <div class="overview-card">
                    <h6><i class="fas fa-server"></i> Hardware Information</h6>
                    <div class="card-content">
                        <div class="overview-item">
                            <span class="overview-label">Manufacturer</span>
                            <span class="overview-value">${device.manufacturer || 'Unknown'}</span>
                        </div>
                        <div class="overview-item">
                            <span class="overview-label">Model</span>
                            <span class="overview-value">${device.model || 'Unknown'}</span>
                        </div>
                        <div class="overview-item">
                            <span class="overview-label">Serial Number</span>
                            <span class="overview-value">${device.serial || 'Unknown'}</span>
                        </div>
                        <div class="overview-item">
                            <span class="overview-label">Asset Tag</span>
                            <span class="overview-value">${device.asset_tag || 'Not assigned'}</span>
                        </div>
                    </div>
                </div>
            </div>
        `;
    }

    populateInterfacesTab(device) {
        const interfacesPane = document.getElementById('tab-interfaces');
        if (!interfacesPane) return;

        const interfaces = device.connected_interfaces || [];
        
        if (interfaces.length === 0) {
            interfacesPane.innerHTML = '<p>No interface information available.</p>';
            return;
        }

        interfacesPane.innerHTML = `
            <h5>Connected Interfaces (${interfaces.length})</h5>
            <div class="interfaces-detailed-list">
                ${interfaces.map(iface => `
                    <div class="interface-detailed-item ${iface.status === 'up' ? 'up' : 'down'}">
                        <div class="interface-main-info">
                            <div class="interface-name-section">
                                <span class="interface-name">${iface.name}</span>
                                <span class="interface-type">${iface.type || 'Ethernet'}</span>
                                ${iface.speed ? `<span class="interface-speed">${iface.speed} Mbps</span>` : ''}
                            </div>
                            <div class="interface-status-section">
                                <span class="interface-status ${iface.status === 'up' ? 'up' : 'down'}">${iface.status || 'Unknown'}</span>
                                ${iface.duplex ? `<span class="duplex">${iface.duplex}</span>` : ''}
                            </div>
                        </div>
                        ${iface.ip_address ? `
                            <div class="interface-ip-info">
                                <i class="fas fa-globe"></i>
                                <span>${iface.ip_address}${iface.subnet_mask ? '/' + iface.subnet_mask : ''}</span>
                            </div>
                        ` : ''}
                        ${iface.vlan ? `
                            <div class="interface-vlan-info">
                                <i class="fas fa-tags"></i>
                                <span>VLAN ${iface.vlan}</span>
                                ${iface.is_trunk ? '<span class="trunk-indicator">TRUNK</span>' : ''}
                            </div>
                        ` : ''}
                        ${iface.connected_device ? `
                            <div class="interface-connection-info">
                                <i class="fas fa-link"></i>
                                <span class="connected-device">${iface.connected_device}</span>
                                ${iface.connected_interface ? `<span class="connected-interface">${iface.connected_interface}</span>` : ''}
                                ${iface.connected_ip ? `<span class="connected-ip">${iface.connected_ip}</span>` : ''}
                            </div>
                        ` : ''}
                        ${iface.description ? `
                            <div class="interface-description">${iface.description}</div>
                        ` : ''}
                    </div>
                `).join('')}
            </div>
        `;
    }

    populateConnectionsTab(device) {
        const connectionsPane = document.getElementById('tab-connections');
        if (!connectionsPane) return;

        // Find connections for this device
        const deviceConnections = this.connections.filter(conn => 
            conn.source === device.id || conn.target === device.id
        );

        if (deviceConnections.length === 0) {
            connectionsPane.innerHTML = '<p>No connections found for this device.</p>';
            return;
        }

        connectionsPane.innerHTML = `
            <h5>Network Connections (${deviceConnections.length})</h5>
            <div class="connections-list">
                ${deviceConnections.map(conn => {
                    const isSource = conn.source === device.id;
                    const remoteDeviceId = isSource ? conn.target : conn.source;
                    const remoteDevice = this.devices.find(d => d.id === remoteDeviceId);
                    const localInterface = isSource ? conn.source_interface : conn.target_interface;
                    const remoteInterface = isSource ? conn.target_interface : conn.source_interface;
                    
                    return `
                        <div class="connection-item">
                            <div class="connection-header">
                                <span class="local-interface">${localInterface || 'Unknown'}</span>
                                <i class="fas fa-arrows-alt-h"></i>
                                <span class="remote-device">${remoteDevice?.hostname || remoteDevice?.name || 'Unknown Device'}</span>
                            </div>
                            <div class="connection-details">
                                <span class="remote-interface">${remoteInterface || 'Unknown'}</span>
                                ${conn.cable_type ? `<span class="cable-type">${conn.cable_type}</span>` : ''}
                                ${conn.vlan ? `<span class="vlan">VLAN ${conn.vlan}</span>` : ''}
                            </div>
                        </div>
                    `;
                }).join('')}
            </div>
        `;
    }

    populateSystemTab(device) {
        const systemPane = document.getElementById('tab-system');
        if (!systemPane) return;

        systemPane.innerHTML = `
            <div class="system-details">
                <h5>System Information</h5>
                <div class="system-item">
                    <label>Device ID:</label>
                    <span>${device.id}</span>
                </div>
                <div class="system-item">
                    <label>Created:</label>
                    <span>${device.created ? new Date(device.created).toLocaleString() : 'Unknown'}</span>
                </div>
                <div class="system-item">
                    <label>Last Updated:</label>
                    <span>${device.last_updated ? new Date(device.last_updated).toLocaleString() : 'Unknown'}</span>
                </div>
                ${device.tenant ? `
                    <div class="system-item">
                        <label>Tenant:</label>
                        <span>${device.tenant}</span>
                    </div>
                ` : ''}
                ${device.rack ? `
                    <div class="system-item">
                        <label>Rack:</label>
                        <span>${device.rack}</span>
                    </div>
                ` : ''}
                ${device.position ? `
                    <div class="system-item">
                        <label>Rack Position:</label>
                        <span>U${device.position}</span>
                    </div>
                ` : ''}
            </div>
        `;
    }

    async populateStatusTab(device) {
        const statusPane = document.getElementById('tab-status');
        if (!statusPane) return;

        // Show loading state
        statusPane.innerHTML = `
            <div class="loading-container">
                <div class="loading-spinner"></div>
                <p>Loading device status...</p>
            </div>
        `;

        try {
            // Make NAPALM API call for device facts and environment
            const response = await fetch(`/api/dcim/devices/${device.id}/napalm/?method=get_facts&method=get_environment`);
            
            if (!response.ok) {
                throw new Error(`HTTP ${response.status}: ${response.statusText}`);
            }

            const data = await response.json();
            
            // Build status content
            let statusContent = '<div class="status-details">';
            
            // Device Facts Section
            statusContent += '<div class="status-section">';
            statusContent += '<h5><i class="fas fa-info-circle"></i> Device Facts</h5>';
            
            if (data.get_facts && !data.get_facts.error) {
                const facts = data.get_facts;
                statusContent += `
                    <div class="facts-grid">
                        <div class="fact-card">
                            <div class="fact-header">
                                <i class="fas fa-server"></i>
                                <span>System Information</span>
                            </div>
                            <div class="fact-content">
                                <div class="fact-item">
                                    <label>Hostname:</label>
                                    <span class="fact-value">${facts.hostname || 'N/A'}</span>
                                </div>
                                <div class="fact-item">
                                    <label>FQDN:</label>
                                    <span class="fact-value">${facts.fqdn || 'N/A'}</span>
                                </div>
                                <div class="fact-item">
                                    <label>Vendor:</label>
                                    <span class="fact-value vendor-badge">${facts.vendor || 'N/A'}</span>
                                </div>
                                <div class="fact-item">
                                    <label>Model:</label>
                                    <span class="fact-value model-badge">${facts.model || 'N/A'}</span>
                                </div>
                            </div>
                        </div>
                        
                        <div class="fact-card">
                            <div class="fact-header">
                                <i class="fas fa-microchip"></i>
                                <span>Hardware Details</span>
                            </div>
                            <div class="fact-content">
                                <div class="fact-item">
                                    <label>Serial Number:</label>
                                    <span class="fact-value serial-number">${facts.serial_number || 'N/A'}</span>
                                </div>
                                <div class="fact-item">
                                    <label>Uptime:</label>
                                    <span class="fact-value uptime-badge">${this.formatUptime(facts.uptime)}</span>
                                </div>
                            </div>
                        </div>
                        
                        <div class="fact-card full-width">
                            <div class="fact-header">
                                <i class="fas fa-code"></i>
                                <span>Software Information</span>
                            </div>
                            <div class="fact-content">
                                <div class="fact-item os-version-item">
                                    <label>OS Version:</label>
                                    <div class="os-version-content">
                                        ${this.formatOSVersion(facts.os_version)}
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                `;
            } else {
                statusContent += `<div class="status-error">Failed to retrieve device facts: ${data.get_facts?.error || 'Unknown error'}</div>`;
            }
            statusContent += '</div>';

            // Environment Section
            statusContent += '<div class="status-section">';
            statusContent += '<h5><i class="fas fa-tachometer-alt"></i> Environment Monitoring</h5>';
            
            if (data.get_environment && !data.get_environment.error) {
                const env = data.get_environment;
                statusContent += '<div class="environment-grid">';
                
                // CPU Information
                if (env.cpu && Object.keys(env.cpu).length > 0) {
                    statusContent += '<div class="env-card">';
                    statusContent += '<div class="env-header"><i class="fas fa-microchip"></i> CPU Usage</div>';
                    statusContent += '<div class="env-content">';
                    Object.entries(env.cpu).forEach(([name, data]) => {
                        const usage = data['%usage'] || 0;
                        const statusClass = usage > 80 ? 'critical' : usage > 60 ? 'warning' : 'normal';
                        statusContent += `
                            <div class="metric-item ${statusClass}">
                                <div class="metric-label">CPU ${name}</div>
                                <div class="metric-value">
                                    <div class="usage-bar">
                                        <div class="usage-fill" style="width: ${usage}%"></div>
                                    </div>
                                    <span class="usage-text">${usage}%</span>
                                </div>
                            </div>
                        `;
                    });
                    statusContent += '</div></div>';
                }

                // Memory Information
                if (env.memory && (env.memory.available_ram || env.memory.used_ram)) {
                    const usedRam = env.memory.used_ram || 0;
                    const availableRam = env.memory.available_ram || 0;
                    const totalRam = usedRam + availableRam;
                    const usagePercent = totalRam > 0 ? Math.round((usedRam / totalRam) * 100) : 0;
                    const statusClass = usagePercent > 85 ? 'critical' : usagePercent > 70 ? 'warning' : 'normal';
                    
                    statusContent += '<div class="env-card">';
                    statusContent += '<div class="env-header"><i class="fas fa-memory"></i> Memory Usage</div>';
                    statusContent += '<div class="env-content">';
                    statusContent += `
                        <div class="metric-item ${statusClass}">
                            <div class="metric-label">RAM Usage</div>
                            <div class="metric-value">
                                <div class="usage-bar">
                                    <div class="usage-fill" style="width: ${usagePercent}%"></div>
                                </div>
                                <span class="usage-text">${usagePercent}%</span>
                            </div>
                        </div>
                        <div class="memory-details">
                            <div class="memory-stat">
                                <span class="memory-label">Used:</span>
                                <span class="memory-value">${this.formatBytes(usedRam)}</span>
                            </div>
                            <div class="memory-stat">
                                <span class="memory-label">Available:</span>
                                <span class="memory-value">${this.formatBytes(availableRam)}</span>
                            </div>
                            <div class="memory-stat">
                                <span class="memory-label">Total:</span>
                                <span class="memory-value">${this.formatBytes(totalRam)}</span>
                            </div>
                        </div>
                    `;
                    statusContent += '</div></div>';
                }

                // Temperature Information
                if (env.temperature && Object.keys(env.temperature).length > 0) {
                    statusContent += '<div class="env-card">';
                    statusContent += '<div class="env-header"><i class="fas fa-thermometer-half"></i> Temperature Sensors</div>';
                    statusContent += '<div class="env-content">';
                    Object.entries(env.temperature).forEach(([name, data]) => {
                        const temp = data.temperature;
                        const statusClass = data.is_critical ? 'critical' : data.is_alert ? 'warning' : 'normal';
                        const tempIcon = data.is_critical ? 'fas fa-exclamation-triangle' : 
                                        data.is_alert ? 'fas fa-exclamation-circle' : 'fas fa-check-circle';
                        statusContent += `
                            <div class="sensor-item ${statusClass}">
                                <div class="sensor-info">
                                    <i class="${tempIcon}"></i>
                                    <span class="sensor-name">${this.capitalizeFirst(name)}</span>
                                </div>
                                <div class="sensor-value">
                                    <span class="temperature">${temp}°C</span>
                                </div>
                            </div>
                        `;
                    });
                    statusContent += '</div></div>';
                }

                // Power and Fans Information (only if valid data)
                const validPowerEntries = env.power ? Object.entries(env.power).filter(([name, data]) => 
                    name !== 'invalid' && data.status !== undefined && (data.output !== -1 || data.capacity !== -1)
                ) : [];
                
                const validFanEntries = env.fans ? Object.entries(env.fans).filter(([name, data]) => 
                    name !== 'invalid' && data.status !== undefined
                ) : [];

                if (validPowerEntries.length > 0 || validFanEntries.length > 0) {
                    statusContent += '<div class="env-card">';
                    statusContent += '<div class="env-header"><i class="fas fa-bolt"></i> Power & Cooling</div>';
                    statusContent += '<div class="env-content">';
                    
                    // Power supplies
                    validPowerEntries.forEach(([name, data]) => {
                        const statusClass = data.status ? 'normal' : 'critical';
                        const statusIcon = data.status ? 'fas fa-check-circle' : 'fas fa-times-circle';
                        statusContent += `
                            <div class="power-item ${statusClass}">
                                <div class="power-info">
                                    <i class="${statusIcon}"></i>
                                    <span class="power-name">PSU ${name}</span>
                                </div>
                                <div class="power-details">
                                    <span class="power-status">${data.status ? 'OK' : 'Failed'}</span>
                                    ${data.output > 0 ? `<span class="power-output">${data.output}W</span>` : ''}
                                </div>
                            </div>
                        `;
                    });
                    
                    // Fans
                    validFanEntries.forEach(([name, data]) => {
                        const statusClass = data.status ? 'normal' : 'critical';
                        const statusIcon = data.status ? 'fas fa-check-circle' : 'fas fa-times-circle';
                        statusContent += `
                            <div class="fan-item ${statusClass}">
                                <div class="fan-info">
                                    <i class="${statusIcon}"></i>
                                    <span class="fan-name">Fan ${name}</span>
                                </div>
                                <div class="fan-status">
                                    <span>${data.status ? 'OK' : 'Failed'}</span>
                                </div>
                            </div>
                        `;
                    });
                    
                    statusContent += '</div></div>';
                }
                
                statusContent += '</div>'; // Close environment-grid
            } else {
                statusContent += `<div class="status-error">Failed to retrieve environment data: ${data.get_environment?.error || 'Unknown error'}</div>`;
            }
            statusContent += '</div>';
            statusContent += '</div>';

            statusPane.innerHTML = statusContent;

        } catch (error) {
            console.error('Error fetching device status:', error);
            statusPane.innerHTML = `
                <div class="error-container">
                    <div class="error-message">
                        <i class="fas fa-exclamation-triangle"></i>
                        <h6>Failed to Load Device Status</h6>
                        <p>${error.message}</p>
                        <small>This feature requires NAPALM to be configured for this device's platform.</small>
                    </div>
                </div>
            `;
        }
    }

    async populateConfigTab(device) {
        const configPane = document.getElementById('tab-config');
        if (!configPane) return;

        // Show loading state
        configPane.innerHTML = `
            <div class="loading-container">
                <div class="loading-spinner"></div>
                <p>Loading device configuration...</p>
            </div>
        `;

        try {
            // Make NAPALM API call for device configuration
            const response = await fetch(`/api/dcim/devices/${device.id}/napalm/?method=get_config`);
            
            if (!response.ok) {
                throw new Error(`HTTP ${response.status}: ${response.statusText}`);
            }

            const data = await response.json();
            
            if (data.get_config && !data.get_config.error) {
                const config = data.get_config;
                
                configPane.innerHTML = `
                    <div class="config-details">
                        <div class="config-tabs">
                            <button class="config-tab-button active" data-config-tab="running">Running Config</button>
                            <button class="config-tab-button" data-config-tab="startup">Startup Config</button>
                            <button class="config-tab-button" data-config-tab="candidate">Candidate Config</button>
                        </div>
                        <div class="config-content">
                            <div id="config-running" class="config-pane active">
                                <pre class="config-text">${this.escapeHtml(config.running || 'No running configuration available')}</pre>
                            </div>
                            <div id="config-startup" class="config-pane">
                                <pre class="config-text">${this.escapeHtml(config.startup || 'No startup configuration available')}</pre>
                            </div>
                            <div id="config-candidate" class="config-pane">
                                <pre class="config-text">${this.escapeHtml(config.candidate || 'No candidate configuration available')}</pre>
                            </div>
                        </div>
                    </div>
                `;

                // Add event listeners for config tabs
                const configTabButtons = configPane.querySelectorAll('.config-tab-button');
                configTabButtons.forEach(button => {
                    button.addEventListener('click', (e) => {
                        const tabName = e.target.getAttribute('data-config-tab');
                        this.switchConfigTab(tabName);
                    });
                });

            } else {
                throw new Error(data.get_config?.error || 'Failed to retrieve configuration');
            }

        } catch (error) {
            console.error('Error fetching device config:', error);
            configPane.innerHTML = `
                <div class="error-container">
                    <div class="error-message">
                        <i class="mdi mdi-alert-circle"></i>
                        <h6>Failed to Load Device Configuration</h6>
                        <p>${error.message}</p>
                        <small>This feature requires NAPALM to be configured for this device's platform.</small>
                    </div>
                </div>
            `;
        }
    }

    formatUptime(uptimeSeconds) {
        if (!uptimeSeconds) return 'Unknown';
        
        const days = Math.floor(uptimeSeconds / 86400);
        const hours = Math.floor((uptimeSeconds % 86400) / 3600);
        const minutes = Math.floor((uptimeSeconds % 3600) / 60);
        
        if (days > 0) {
            return `${days}d ${hours}h ${minutes}m`;
        } else if (hours > 0) {
            return `${hours}h ${minutes}m`;
        } else {
            return `${minutes}m`;
        }
    }

    formatOSVersion(osVersion) {
        if (!osVersion) return 'N/A';
        
        // Extract version number if it's a long Cisco string
        const versionMatch = osVersion.match(/Version\s+([^,\s]+)/i);
        const softwareMatch = osVersion.match(/^([^,]+)/);
        
        if (versionMatch && softwareMatch) {
            const version = versionMatch[1];
            const software = softwareMatch[1].replace(/\s*Software.*$/, '').trim();
            
            return `
                <div class="os-version-main">
                    <span class="software-name">${software}</span>
                    <span class="version-number">${version}</span>
                </div>
                
            `;
        }
        
        // For shorter version strings, display as-is
        if (osVersion.length < 50) {
            return `<span class="version-simple">${osVersion}</span>`;
        }
        
        // For other long strings, provide expandable view
        return `
            <div class="os-version-full">
                <div class="version-preview">${osVersion.substring(0, 50)}...</div>
            </div>
        `;
    }

    formatBytes(bytes) {
        if (!bytes || bytes === 0) return '0 B';
        
        const k = 1024;
        const sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        
        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    }

    capitalizeFirst(str) {
        if (!str) return '';
        return str.charAt(0).toUpperCase() + str.slice(1);
    }

    escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }

    switchConfigTab(tabName) {
        // Remove active class from all config tabs and panes
        document.querySelectorAll('.config-tab-button').forEach(btn => btn.classList.remove('active'));
        document.querySelectorAll('.config-pane').forEach(pane => pane.classList.remove('active'));
        
        // Add active class to selected config tab and pane
        const selectedTab = document.querySelector(`[data-config-tab="${tabName}"]`);
        const selectedPane = document.getElementById(`config-${tabName}`);
        
        if (selectedTab && selectedPane) {
            selectedTab.classList.add('active');
            selectedPane.classList.add('active');
        }
    }

    createDeviceListItem(device) {
        const item = document.createElement('div');
        item.className = 'device-item';
        item.setAttribute('data-device-id', device.id);

        const platform = device.platform || 'Unknown';
        const role = device.device_role || 'Unknown';
        const status = device.status || 'Unknown';
        const connections = device.connection_count || 0;

        // Create device name with icon
        const deviceName = document.createElement('div');
        deviceName.className = 'device-name';
        deviceName.innerHTML = `<i class="fas fa-${this.getDeviceIconClass(device)}"></i> ${device.name}`;

        // Create device details container
        const deviceDetails = document.createElement('div');
        deviceDetails.className = 'device-details';
        
        if (this.config.discoverySessionId) {
            // Discovery mode - structured information
            this.createDiscoveryDeviceDetails(device, deviceDetails);
        } else {
            // Standard mode - structured information
            this.createStandardDeviceDetails(device, deviceDetails);
        }

        item.appendChild(deviceName);
        item.appendChild(deviceDetails);

        item.addEventListener('click', () => {
            this.selectDevice(device.id);
        });

        return item;
    }

    createDiscoveryDeviceDetails(device, container) {
            const ipAddress = device.ip_address || 'Unknown';
            const discoveryDepth = device.discovery_depth !== undefined ? device.discovery_depth : 'Unknown';
            const discoveredVia = device.discovered_via || 'Unknown';
            const model = device.model || 'Unknown';
        const platform = device.platform || 'Unknown';

        // Basic Information Section
        const basicInfo = document.createElement('div');
        basicInfo.className = 'device-info-section';
        basicInfo.innerHTML = `
            <h6><i class="fas fa-info-circle"></i> Basic Information</h6>
            <div class="device-info-grid">
                <div class="device-info-item">
                    <div class="device-info-label">IP Address</div>
                    <div class="device-info-value">${ipAddress}</div>
                </div>
                <div class="device-info-item">
                    <div class="device-info-label">Platform</div>
                    <div class="device-info-value">${platform}</div>
                </div>
                <div class="device-info-item">
                    <div class="device-info-label">Model</div>
                    <div class="device-info-value">${model}</div>
                </div>
                <div class="device-info-item">
                    <div class="device-info-label">Status</div>
                    <div class="device-info-value">
                        <span class="device-status-badge ${device.status?.toLowerCase() || 'unknown'}">${device.status || 'Unknown'}</span>
                    </div>
                </div>
            </div>
        `;

        // Network Layer Information Section
        const networkLayerInfo = document.createElement('div');
        networkLayerInfo.className = 'device-info-section';
        
        // Determine network layer
        const connectionCount = this.devices.reduce((count, d) => {
            return count + (this.connections.filter(conn => 
                conn.source === device.id || conn.target === device.id
            ).length);
        }, 0);
        
        const networkLayer = NetworkConstants.getDeviceLayer(device, connectionCount);
        const layerName = NetworkConstants.getLayerName(networkLayer);
        const layerColor = NetworkConstants.getLayerColor(networkLayer);
        
        networkLayerInfo.innerHTML = `
            <h6><i class="fas fa-sitemap"></i> Network Layer</h6>
            <div class="device-info-grid">
                <div class="device-info-item">
                    <div class="device-info-label">Layer</div>
                    <div class="device-info-value">
                        <span class="network-layer-badge" style="background-color: ${layerColor}; color: white; padding: 2px 8px; border-radius: 12px; font-size: 11px; font-weight: 600;">
                            ${layerName}
                        </span>
                    </div>
                </div>
                <div class="device-info-item">
                    <div class="device-info-label">Connections</div>
                    <div class="device-info-value">${connectionCount}</div>
                </div>
            </div>
        `;

        // Discovery Information Section
        const discoveryInfo = document.createElement('div');
        discoveryInfo.className = 'device-info-section';
        discoveryInfo.innerHTML = `
            <h6><i class="fas fa-search"></i> Discovery Information</h6>
            <div class="device-info-grid">
                <div class="device-info-item">
                    <div class="device-info-label">Depth</div>
                    <div class="device-info-value">${discoveryDepth}</div>
                </div>
                <div class="device-info-item">
                    <div class="device-info-label">Discovered Via</div>
                    <div class="device-info-value">${discoveredVia}</div>
                </div>
            </div>
        `;

        container.appendChild(basicInfo);
        container.appendChild(networkLayerInfo);
        container.appendChild(discoveryInfo);

        // Interface Information Section
        if (device.connected_interfaces && device.connected_interfaces.length > 0) {
            // Use enhanced interface section for discovery mode with rich data
            const interfaceInfo = this.config.discoverySessionId && device.command_outputs ? 
                this.createEnhancedInterfaceSection(device) : 
                this.createInterfaceInfoSection(device);
            container.appendChild(interfaceInfo);
            
            // Add system information if available (discovery mode only)
            if (this.config.discoverySessionId) {
                const systemInfo = this.createSystemInfoSection(device);
                if (systemInfo) {
                    container.appendChild(systemInfo);
                }
            }
        }
    }

    createStandardDeviceDetails(device, container) {
        const platform = device.platform || 'Unknown';
            const manufacturer = device.manufacturer || 'Unknown';
            const model = device.device_type || 'Unknown';
            const serial = device.serial || 'Unknown';
            const assetTag = device.asset_tag || 'Unknown';
            const location = device.location || 'Unknown';
            const tenant = device.tenant || 'Unknown';
        const role = device.device_role || 'Unknown';
            const primaryIp4 = device.primary_ip4 || 'None';
            const primaryIp6 = device.primary_ip6 || 'None';
        const connections = device.connection_count || 0;

        // Basic Information Section
        const basicInfo = document.createElement('div');
        basicInfo.className = 'device-info-section';
        basicInfo.innerHTML = `
            <h6><i class="fas fa-info-circle"></i> Basic Information</h6>
            <div class="device-info-grid">
                <div class="device-info-item">
                    <div class="device-info-label">Platform</div>
                    <div class="device-info-value">${platform}</div>
                </div>
                <div class="device-info-item">
                    <div class="device-info-label">Manufacturer</div>
                    <div class="device-info-value">${manufacturer}</div>
                </div>
                <div class="device-info-item">
                    <div class="device-info-label">Model</div>
                    <div class="device-info-value">${model}</div>
                </div>
                <div class="device-info-item">
                    <div class="device-info-label">Role</div>
                    <div class="device-info-value">${role}</div>
                </div>
                <div class="device-info-item">
                    <div class="device-info-label">Serial</div>
                    <div class="device-info-value">${serial}</div>
                </div>
                <div class="device-info-item">
                    <div class="device-info-label">Asset Tag</div>
                    <div class="device-info-value">${assetTag}</div>
                </div>
                <div class="device-info-item">
                    <div class="device-info-label">Status</div>
                    <div class="device-info-value">
                        <span class="device-status-badge ${device.status?.toLowerCase() || 'unknown'}">${device.status || 'Unknown'}</span>
                    </div>
                </div>
                <div class="device-info-item">
                    <div class="device-info-label">Connections</div>
                    <div class="device-info-value">${connections}</div>
                </div>
            </div>
        `;

        // Location Information Section
        const locationInfo = document.createElement('div');
        locationInfo.className = 'device-info-section';
        locationInfo.innerHTML = `
            <h6><i class="fas fa-map-marker-alt"></i> Location Information</h6>
            <div class="device-info-grid">
                <div class="device-info-item">
                    <div class="device-info-label">Location</div>
                    <div class="device-info-value">${location}</div>
                </div>
                <div class="device-info-item">
                    <div class="device-info-label">Tenant</div>
                    <div class="device-info-value">${tenant}</div>
                </div>
            </div>
        `;

        container.appendChild(basicInfo);
        container.appendChild(locationInfo);

        // Network Layer Information Section
        const networkLayerInfo = document.createElement('div');
        networkLayerInfo.className = 'device-info-section';
        
        // Determine network layer
        const connectionCount = this.devices.reduce((count, d) => {
            return count + (this.connections.filter(conn => 
                conn.source === device.id || conn.target === device.id
            ).length);
        }, 0);
        
        const networkLayer = NetworkConstants.getDeviceLayer(device, connectionCount);
        const layerName = NetworkConstants.getLayerName(networkLayer);
        const layerColor = NetworkConstants.getLayerColor(networkLayer);
        
        networkLayerInfo.innerHTML = `
            <h6><i class="fas fa-sitemap"></i> Network Layer</h6>
            <div class="device-info-grid">
                <div class="device-info-item">
                    <div class="device-info-label">Layer</div>
                    <div class="device-info-value">
                        <span class="network-layer-badge" style="background-color: ${layerColor}; color: white; padding: 2px 8px; border-radius: 12px; font-size: 11px; font-weight: 600;">
                            ${layerName}
                        </span>
                    </div>
                </div>
                <div class="device-info-item">
                    <div class="device-info-label">Connections</div>
                    <div class="device-info-value">${connectionCount}</div>
                </div>
            </div>
        `;
        
        container.appendChild(networkLayerInfo);

        // Rack Information Section
            if (device.rack) {
            const rackInfo = this.createRackInfoSection(device);
            container.appendChild(rackInfo);
        }

        // IP Information Section
        if (primaryIp4 !== 'None' || primaryIp6 !== 'None') {
            const ipInfo = this.createIPInfoSection(device);
            container.appendChild(ipInfo);
        }

        // Interface Information Section
        if (device.connected_interfaces && device.connected_interfaces.length > 0) {
            // Use enhanced interface section for discovery mode with rich data
            const interfaceInfo = this.config.discoverySessionId && device.command_outputs ? 
                this.createEnhancedInterfaceSection(device) : 
                this.createInterfaceInfoSection(device);
            container.appendChild(interfaceInfo);
            
            // Add system information if available (discovery mode only)
            if (this.config.discoverySessionId) {
                const systemInfo = this.createSystemInfoSection(device);
                if (systemInfo) {
                    container.appendChild(systemInfo);
                }
            }
        }
    }

    createRackInfoSection(device) {
        const rackInfo = document.createElement('div');
        rackInfo.className = 'device-info-section';
        
                const rackName = device.rack.name || 'Unknown';
                const rackPosition = device.rack.position || 'Unknown';
                const rackFace = device.rack.face || 'Unknown';
                const rackFacilityId = device.rack.facility_id || '';
                
        rackInfo.innerHTML = `
            <h6><i class="fas fa-server"></i> Rack Information</h6>
            <div class="device-info-grid">
                <div class="device-info-item">
                    <div class="device-info-label">Rack Name</div>
                    <div class="device-info-value">${rackName}${rackFacilityId ? ` (${rackFacilityId})` : ''}</div>
                </div>
                <div class="device-info-item">
                    <div class="device-info-label">Position</div>
                    <div class="device-info-value">U${rackPosition} (${rackFace})</div>
                </div>
            </div>
        `;
        
        return rackInfo;
    }

    createIPInfoSection(device) {
        const ipInfo = document.createElement('div');
        ipInfo.className = 'device-info-section';
        
        const primaryIp4 = device.primary_ip4 || 'None';
        const primaryIp6 = device.primary_ip6 || 'None';
        
        let ipContent = '<div class="device-info-grid">';
        
                if (primaryIp4 !== 'None') {
            ipContent += `
                <div class="device-info-item">
                    <div class="device-info-label">IPv4</div>
                    <div class="device-info-value">${primaryIp4}</div>
                </div>
            `;
        }
        
                if (primaryIp6 !== 'None') {
            ipContent += `
                <div class="device-info-item">
                    <div class="device-info-label">IPv6</div>
                    <div class="device-info-value">${primaryIp6}</div>
                </div>
            `;
        }
        
        ipContent += '</div>';
        
        ipInfo.innerHTML = `
            <h6><i class="fas fa-network-wired"></i> IP Information</h6>
            ${ipContent}
        `;
        
        return ipInfo;
    }

    createInterfaceInfoSection(device) {
        const interfaceInfo = document.createElement('div');
        interfaceInfo.className = 'device-info-section';
        
        const trunkInterfaces = device.connected_interfaces.filter(iface => iface.is_trunk);
        const accessInterfaces = device.connected_interfaces.filter(iface => !iface.is_trunk);
        
        // Get interface capacity summary for standard mode
        let capacityInfo = '';
        if (!this.config.discoverySessionId) {
            const interfaceCapacities = this.getInterfaceCapacitySummary(device.connected_interfaces);
            capacityInfo = `
                <div class="device-info-item">
                    <div class="device-info-label">Capacity</div>
                    <div class="device-info-value">${interfaceCapacities}</div>
                </div>
            `;
        }
        
        interfaceInfo.innerHTML = `
            <h6><i class="fas fa-network-wired"></i> Interface Information</h6>
            <div class="device-info-grid">
                <div class="device-info-item">
                    <div class="device-info-label">Total Interfaces</div>
                    <div class="device-info-value">${device.connected_interfaces.length}</div>
            </div>
                <div class="device-info-item">
                    <div class="device-info-label">Trunk</div>
                    <div class="device-info-value">${trunkInterfaces.length}</div>
                </div>
                <div class="device-info-item">
                    <div class="device-info-label">Access</div>
                    <div class="device-info-value">${accessInterfaces.length}</div>
                </div>
                ${capacityInfo}
            </div>
            <div class="interface-summary">
                <i class="fas fa-network-wired"></i>
                <span>Interface Summary</span>
            </div>
            <div class="interface-counts">
                <div class="interface-count trunk">
                    <i class="fas fa-circle"></i>
                    <span>Trunk: ${trunkInterfaces.length}</span>
                </div>
                <div class="interface-count access">
                    <i class="fas fa-circle"></i>
                    <span>Access: ${accessInterfaces.length}</span>
                </div>
            </div>
        `;

        return interfaceInfo;
    }

    getDeviceIconClass(device) {
        const role = device.device_role?.toLowerCase() || '';
        if (role.includes('router')) return 'route';
        if (role.includes('switch')) return 'network-wired';
        if (role.includes('server')) return 'server';
        if (role.includes('firewall')) return 'shield-alt';
        return 'hdd';
    }

    selectDevice(deviceId) {
        // If clicking the same device, deselect it
        if (this.selectedDevice === deviceId) {
            this.deselectDevice();
            return;
        }

        // Remove previous selection
        if (this.selectedDevice) {
            this.deselectDevice();
        }

        // Select new device
        this.selectedDevice = deviceId;
        const deviceElement = this.deviceElements.get(deviceId);
        const device = this.devices.find(d => d.id === deviceId);

        if (deviceElement) {
            deviceElement.classList.add('selected');
            // Add elegant highlight animation
            this.addDeviceHighlight(deviceElement);
        }

        // Highlight connected devices and connections
        this.highlightConnectedDevices(deviceId);
        
        // Show device details in panel
        if (device) {
            this.showDevicePanel(device);
        }
    }

    deselectDevice() {
        if (!this.selectedDevice) return;

        const deviceElement = this.deviceElements.get(this.selectedDevice);

        if (deviceElement) {
            deviceElement.classList.remove('selected');
            this.removeDeviceHighlight(deviceElement);
        }

        // Remove connection highlights
        this.removeConnectionHighlights();

        // Hide device details panel
        this.closeDevicePanel();

        this.selectedDevice = null;
    }

    toggleManagementConnections() {
        // Cycle through three states: all connections -> management only -> no management -> all connections
        if (this.managementMode === undefined) {
            this.managementMode = 'all'; // Initialize if not set
        }
        
        const toggleBtn = document.getElementById('btn-toggle-management');
        
        switch (this.managementMode) {
            case 'all':
                this.managementMode = 'only';
                if (toggleBtn) {
                    toggleBtn.classList.add('management-only');
                    toggleBtn.classList.remove('inactive');
                    toggleBtn.title = 'Show Management Only (Click to hide management)';
                    // Update button content
                    const btnText = toggleBtn.querySelector('.btn-text');
                    const btnIcon = toggleBtn.querySelector('i');
                    if (btnText) btnText.textContent = 'Mgmt Only';
                    if (btnIcon) btnIcon.className = 'fas fa-eye';
                }
                break;
            case 'only':
                this.managementMode = 'none';
                if (toggleBtn) {
                    toggleBtn.classList.remove('management-only');
                    toggleBtn.classList.add('inactive');
                    toggleBtn.title = 'Hide Management Connections (Click to show all)';
                    // Update button content
                    const btnText = toggleBtn.querySelector('.btn-text');
                    const btnIcon = toggleBtn.querySelector('i');
                    if (btnText) btnText.textContent = 'Hide Mgmt';
                    if (btnIcon) btnIcon.className = 'fas fa-eye-slash';
                }
                break;
            case 'none':
                this.managementMode = 'all';
                if (toggleBtn) {
                    toggleBtn.classList.remove('inactive', 'management-only');
                    toggleBtn.title = 'Show All Connections (Click for management only)';
                    // Update button content
                    const btnText = toggleBtn.querySelector('.btn-text');
                    const btnIcon = toggleBtn.querySelector('i');
                    if (btnText) btnText.textContent = 'Show All';
                    if (btnIcon) btnIcon.className = 'fas fa-network-wired';
                }
                break;
        }
        
        // Re-render connections with updated management mode
        this.connectionRenderer.setManagementMode(this.managementMode);
        this.connectionRenderer.renderConnections(this.connections);
    }


    setupEventListeners() {
        // Toolbar buttons
        document.getElementById('btn-auto-layout')?.addEventListener('click', () => {
            this.applyAutoLayout('hierarchical');
            setTimeout(() => this.zoomFit(), 100);
        });

        document.getElementById('btn-force-layout')?.addEventListener('click', () => {
            this.applyAutoLayout('force');
            setTimeout(() => this.zoomFit(), 100);
        });

        document.getElementById('btn-reset-view')?.addEventListener('click', () => {
            this.resetView();
        });

        document.getElementById('btn-save-layout')?.addEventListener('click', () => {
            this.saveLayout();
        });

        document.getElementById('btn-zoom-in')?.addEventListener('click', () => {
            this.zoomIn();
        });

        document.getElementById('btn-zoom-out')?.addEventListener('click', () => {
            this.zoomOut();
        });

        document.getElementById('btn-zoom-fit')?.addEventListener('click', () => {
            this.zoomFit();
        });

        document.getElementById('btn-toggle-legend')?.addEventListener('click', () => {
            this.toggleLegend();
        });

        document.getElementById('btn-show-device-list')?.addEventListener('click', () => {
            this.showDeviceListModal();
        });

        document.getElementById('btn-toggle-management')?.addEventListener('click', () => {
            this.toggleManagementConnections();
        });

        document.getElementById('btn-change-location')?.addEventListener('click', () => {
            this.showLocationSelectorModal();
        });

        // Close buttons
        document.getElementById('btn-close-legend')?.addEventListener('click', () => {
            this.toggleLegend();
        });

        // Device details panel controls
        document.getElementById('btn-toggle-panel-size')?.addEventListener('click', () => {
            this.togglePanelSize();
        });

        document.getElementById('btn-close-panel')?.addEventListener('click', () => {
            this.closeDevicePanel();
        });

        // Tab switching
        const tabButtons = document.querySelectorAll('.tab-button');
        tabButtons.forEach(button => {
            button.addEventListener('click', (e) => {
                this.switchTab(e.target.dataset.tab);
            });
        });

        // Canvas click handler for deselection
        this.svg.addEventListener('click', (e) => {
            // Only deselect if clicking on empty space (not on devices or connections)
            if (e.target === this.svg || 
                (e.target.tagName === 'svg' && !e.target.closest('.device-node')) ||
                (e.target.closest('#connections-layer') && !e.target.closest('.connection-line'))) {
                this.deselectDevice();
            }
        });

        // Also add deselection on Escape key
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape' && this.selectedDevice) {
                this.deselectDevice();
            }
        });
    }

    applyAutoLayout(algorithm = 'hierarchical') {
        // Clear existing layer indicators before applying new layout
        this.clearLayerIndicators();
        
        // First, identify connected components (separate network segments)
        const components = this.identifyConnectedComponents();
        
        console.log(`Found ${components.length} separate network components`);
        
        // Get SVG dimensions for layout planning
        const viewBox = this.svg.getAttribute('viewBox');
        if (!viewBox) return;
        const [, , width, height] = viewBox.split(' ').map(Number);
        
        // Calculate layout for each component separately
        let allPositions = new Map();
        
        if (components.length === 1) {
            // Single connected component - use full canvas
            const positions = this.autoLayout.applyLayout(this.devices, this.connections, algorithm);
            allPositions = positions;
        } else {
            // Multiple components - layout each separately and position them side by side
            allPositions = this.layoutMultipleComponents(components, algorithm, width, height);
        }
        
        // Apply calculated positions to device elements
        allPositions.forEach((position, deviceId) => {
            const deviceElement = this.deviceElements.get(deviceId);
            if (deviceElement) {
                deviceElement.setAttribute('data-x', position.x);
                deviceElement.setAttribute('data-y', position.y);
                deviceElement.style.transform = `translate(${position.x}px, ${position.y}px)`;
                
                // Update network layer information
                if (position.layer) {
                    deviceElement.setAttribute('data-layer', position.layer);
                    
                    // Update device object with layer information
                    const device = this.devices.find(d => d.id === deviceId);
                    if (device) {
                        device.networkLayer = position.layer;
                    }
                }
            }
        });

        // Update connections after a brief delay to ensure DOM elements are updated
        setTimeout(() => {
            this.connectionRenderer.renderConnections(this.connections);
        }, 0);
        
        // Ensure all nodes are within bounds and visible
        this.ensureNodesInBounds();
    }
    
    identifyConnectedComponents() {
        // Use Union-Find (Disjoint Set) to identify connected components
        const deviceIds = this.devices.map(d => d.id);
        const parent = new Map();
        const rank = new Map();
        
        // Initialize each device as its own component
        deviceIds.forEach(id => {
            parent.set(id, id);
            rank.set(id, 0);
        });
        
        // Find root of component
        const find = (id) => {
            if (parent.get(id) !== id) {
                parent.set(id, find(parent.get(id))); // Path compression
            }
            return parent.get(id);
        };
        
        // Union two components
        const union = (id1, id2) => {
            const root1 = find(id1);
            const root2 = find(id2);
            
            if (root1 !== root2) {
                // Union by rank
                if (rank.get(root1) < rank.get(root2)) {
                    parent.set(root1, root2);
                } else if (rank.get(root1) > rank.get(root2)) {
                    parent.set(root2, root1);
                } else {
                    parent.set(root2, root1);
                    rank.set(root1, rank.get(root1) + 1);
                }
            }
        };
        
        // Connect all devices that have connections between them
        this.connections.forEach(conn => {
            if (parent.has(conn.source) && parent.has(conn.target)) {
                union(conn.source, conn.target);
            }
        });
        
        // Group devices by their root component
        const componentMap = new Map();
        deviceIds.forEach(id => {
            const root = find(id);
            if (!componentMap.has(root)) {
                componentMap.set(root, []);
            }
            componentMap.get(root).push(id);
        });
        
        // Convert to array of components, sorted by size (largest first)
        const components = Array.from(componentMap.values())
            .sort((a, b) => b.length - a.length);
        
        return components.map(deviceIds => ({
            devices: this.devices.filter(d => deviceIds.includes(d.id)),
            connections: this.connections.filter(c => 
                deviceIds.includes(c.source) && deviceIds.includes(c.target)
            )
        }));
    }
    
    layoutMultipleComponents(components, algorithm, canvasWidth, canvasHeight) {
        const allPositions = new Map();
        const componentCount = components.length;
        
        // Calculate grid layout for components
        const cols = Math.ceil(Math.sqrt(componentCount));
        const rows = Math.ceil(componentCount / cols);
        
        // Calculate available space for each component
        const componentWidth = canvasWidth / cols;
        const componentHeight = canvasHeight / rows;
        const margin = 100; // Margin between components
        
        console.log(`Laying out ${componentCount} components in ${cols}x${rows} grid`);
        
        components.forEach((component, index) => {
            const row = Math.floor(index / cols);
            const col = index % cols;
            
            // Calculate offset for this component
            const offsetX = col * componentWidth + margin;
            const offsetY = row * componentHeight + margin;
            
            // Available space for this component (with margins)
            const availableWidth = componentWidth - 2 * margin;
            const availableHeight = componentHeight - 2 * margin;
            
            console.log(`Component ${index + 1}: ${component.devices.length} devices, offset (${offsetX}, ${offsetY})`);
            
            // Layout this component in its own coordinate space
            // Skip layer indicators for individual components - we'll create unified indicators later
            const componentPositions = this.autoLayout.applyLayout(
                component.devices, 
                component.connections, 
                algorithm,
                true // skipLayerIndicators = true
            );
            
            // Find bounds of component layout
            let minX = Infinity, minY = Infinity;
            let maxX = -Infinity, maxY = -Infinity;
            
            componentPositions.forEach(pos => {
                minX = Math.min(minX, pos.x);
                minY = Math.min(minY, pos.y);
                maxX = Math.max(maxX, pos.x);
                maxY = Math.max(maxY, pos.y);
            });
            
            // Calculate scale to fit component in available space
            const componentContentWidth = maxX - minX || 100;
            const componentContentHeight = maxY - minY || 100;
            const scaleX = availableWidth / componentContentWidth;
            const scaleY = availableHeight / componentContentHeight;
            const scale = Math.min(scaleX, scaleY, 1); // Don't scale up, only down if needed
            
            // Center component in its allocated space
            const scaledWidth = componentContentWidth * scale;
            const scaledHeight = componentContentHeight * scale;
            const centerOffsetX = offsetX + (availableWidth - scaledWidth) / 2;
            const centerOffsetY = offsetY + (availableHeight - scaledHeight) / 2;
            
            // Apply scaling and offset to all positions
            componentPositions.forEach((pos, deviceId) => {
                const scaledX = (pos.x - minX) * scale + centerOffsetX;
                const scaledY = (pos.y - minY) * scale + centerOffsetY;
                
                allPositions.set(deviceId, {
                    x: scaledX,
                    y: scaledY,
                    layer: pos.layer,
                    component: index
                });
            });
        });
        
        // After laying out all components, create unified layer indicators
        this.createUnifiedLayerIndicators(allPositions, canvasWidth);
        
        return allPositions;
    }
    
    createUnifiedLayerIndicators(allPositions, canvasWidth) {
        // Group devices by Y position ranges to create logical rows
        const yPositions = Array.from(allPositions.values()).map(pos => pos.y).sort((a, b) => a - b);
        const rowGroups = this.groupByYPosition(allPositions, yPositions);
        
        // Create layer indicators for each row
        const layersGroup = document.createElementNS('http://www.w3.org/2000/svg', 'g');
        layersGroup.setAttribute('id', 'layers-group');
        
        rowGroups.forEach((group, index) => {
            // Check if this is a traditional hierarchy or multi-row flat layout
            const isTraditionalHierarchy = this.isTraditionalHierarchy(rowGroups);
            
            let layerDisplayName, layerColor;
            
            if (isTraditionalHierarchy) {
                // Use traditional network layer names
                switch (index) {
                    case 0:
                        layerDisplayName = 'Core Layer';
                        layerColor = '#dc3545';
                        break;
                    case 1:
                        layerDisplayName = 'Distribution Layer';
                        layerColor = '#fd7e14';
                        break;
                    case 2:
                        layerDisplayName = 'Access Layer';
                        layerColor = '#28a745';
                        break;
                    default:
                        layerDisplayName = `Layer ${index + 1}`;
                        layerColor = this.getRowColor(index);
                        break;
                }
            } else {
                // Use row-based naming for flat topologies
                if (rowGroups.length === 1) {
                    layerDisplayName = 'Network Devices';
                    layerColor = '#6c757d';
                } else {
                    layerDisplayName = `Row ${index + 1}`;
                    layerColor = this.getRowColor(index);
                }
            }
            
            // Create horizontal separator line
            const separatorLine = document.createElementNS('http://www.w3.org/2000/svg', 'line');
            separatorLine.setAttribute('x1', '0');
            separatorLine.setAttribute('y1', group.avgY - 30);
            separatorLine.setAttribute('x2', canvasWidth);
            separatorLine.setAttribute('y2', group.avgY - 30);
            separatorLine.setAttribute('stroke', layerColor);
            separatorLine.setAttribute('stroke-width', '2');
            separatorLine.setAttribute('opacity', '0.3');
            separatorLine.setAttribute('stroke-dasharray', '5,5');
            
            // Create layer label
            const layerLabel = document.createElementNS('http://www.w3.org/2000/svg', 'text');
            layerLabel.setAttribute('x', '20');
            layerLabel.setAttribute('y', group.avgY - 20);
            layerLabel.setAttribute('class', 'layer-label');
            layerLabel.setAttribute('font-size', '24');
            layerLabel.setAttribute('font-weight', 'bold');
            layerLabel.setAttribute('fill', layerColor);
            layerLabel.textContent = layerDisplayName;
            
            // Create device count
            const deviceCount = document.createElementNS('http://www.w3.org/2000/svg', 'text');
            deviceCount.setAttribute('x', '20');
            deviceCount.setAttribute('y', group.avgY - 5);
            deviceCount.setAttribute('class', 'layer-count');
            deviceCount.setAttribute('font-size', '22');
            deviceCount.setAttribute('fill', '#666');
            deviceCount.textContent = `${group.count} device${group.count !== 1 ? 's' : ''}`;
            
            layersGroup.appendChild(separatorLine);
            layersGroup.appendChild(layerLabel);
            layersGroup.appendChild(deviceCount);
        });
        
        // Add to SVG
        if (this.svg) {
            this.svg.appendChild(layersGroup);
        }
    }

    groupByYPosition(allPositions, yPositions) {
        // Group devices by similar Y positions (within 50px tolerance)
        const groups = [];
        const tolerance = 50;
        
        yPositions.forEach(y => {
            // Find existing group within tolerance
            let group = groups.find(g => Math.abs(g.avgY - y) <= tolerance);
            
            if (!group) {
                // Create new group
                group = {
                    avgY: y,
                    yPositions: [y],
                    count: 0
                };
                groups.push(group);
            } else {
                // Add to existing group and update average
                group.yPositions.push(y);
                group.avgY = group.yPositions.reduce((sum, pos) => sum + pos, 0) / group.yPositions.length;
            }
        });
        
        // Count devices in each group
        allPositions.forEach((pos) => {
            const group = groups.find(g => Math.abs(g.avgY - pos.y) <= tolerance);
            if (group) {
                group.count++;
            }
        });
        
        // Sort groups by Y position
        return groups.sort((a, b) => a.avgY - b.avgY);
    }

    isTraditionalHierarchy(rowGroups) {
        // Check if this looks like a traditional network hierarchy
        // Traditional hierarchy typically has fewer devices at the top
        if (rowGroups.length < 2) return false;
        
        // Check if first row has fewer devices than subsequent rows
        const firstRowCount = rowGroups[0].count;
        const subsequentRowsAvg = rowGroups.slice(1).reduce((sum, group) => sum + group.count, 0) / (rowGroups.length - 1);
        
        return firstRowCount <= subsequentRowsAvg;
    }

    getRowColor(rowIndex) {
        // Generate colors for multi-row layouts
        const colors = [
            '#007bff', // Blue
            '#28a745', // Green  
            '#ffc107', // Yellow
            '#dc3545', // Red
            '#6f42c1', // Purple
            '#fd7e14', // Orange
            '#20c997', // Teal
            '#e83e8c', // Pink
            '#6c757d', // Gray
            '#17a2b8'  // Cyan
        ];
        return colors[rowIndex % colors.length];
    }
    
    ensureNodesInBounds() {
        // Calculate bounding box of all nodes
        let minX = Infinity, minY = Infinity;
        let maxX = -Infinity, maxY = -Infinity;
        
        this.deviceElements.forEach((element, deviceId) => {
            const x = parseFloat(element.getAttribute('data-x')) || 0;
            const y = parseFloat(element.getAttribute('data-y')) || 0;
            
            minX = Math.min(minX, x);
            minY = Math.min(minY, y);
            maxX = Math.max(maxX, x);
            maxY = Math.max(maxY, y);
        });
        
        // Get current SVG viewBox dimensions
        const viewBox = this.svg.getAttribute('viewBox');
        if (!viewBox) return;
        
        const [, , width, height] = viewBox.split(' ').map(Number);
        
        // If any nodes are outside bounds, adjust all nodes
        const margin = 100; // Increased margin for better spacing
        
        if (minX < margin || minY < margin || maxX > width - margin || maxY > height - margin) {
            // Calculate scale factor to fit all nodes
            const contentWidth = maxX - minX;
            const contentHeight = maxY - minY;
            const scaleX = (width - 2 * margin) / (contentWidth || 1);
            const scaleY = (height - 2 * margin) / (contentHeight || 1);
            const scale = Math.min(scaleX, scaleY, 1); // Don't scale up
            
            // Calculate offset to center content
            const offsetX = margin - minX * scale + (width - 2 * margin - contentWidth * scale) / 2;
            const offsetY = margin - minY * scale + (height - 2 * margin - contentHeight * scale) / 2;
            
            // Apply adjustments to all nodes
            this.deviceElements.forEach((element, deviceId) => {
                const x = parseFloat(element.getAttribute('data-x')) || 0;
                const y = parseFloat(element.getAttribute('data-y')) || 0;
                
                const newX = x * scale + offsetX;
                const newY = y * scale + offsetY;
                
                element.setAttribute('data-x', newX);
                element.setAttribute('data-y', newY);
                element.style.transform = `translate(${newX}px, ${newY}px)`;
            });
            
            // Update connections after repositioning
            setTimeout(() => {
                this.connectionRenderer.renderConnections(this.connections);
            }, 0);
        }
    }

    resetView() {
        this.zoomPan.reset();
    }

    zoomIn() {
        this.zoomPan.scale = Math.min(5, this.zoomPan.scale * 1.2);
        this.zoomPan.updateTransform();
    }

    zoomOut() {
        this.zoomPan.scale = Math.max(0.1, this.zoomPan.scale * 0.8);
        this.zoomPan.updateTransform();
    }

    zoomFit() {
        this.zoomPan.fitToScreen();
    }

    toggleLegend() {
        const legend = document.getElementById('topology-legend');
        const toggleBtn = document.getElementById('btn-toggle-legend');
        
        if (legend) {
            const isHidden = legend.style.display === 'none' || 
                           (legend.style.display === '' && window.getComputedStyle(legend).display === 'none');
            
            if (isHidden) {
                // Show legend
                legend.style.display = 'block';
                legend.style.opacity = '0';
                legend.style.transform = 'translateX(20px)';
                
                // Animate in
                requestAnimationFrame(() => {
                    legend.style.transition = 'opacity 0.3s ease, transform 0.3s ease';
                    legend.style.opacity = '1';
                    legend.style.transform = 'translateX(0)';
                });
                
                if (toggleBtn) {
                    toggleBtn.classList.add('active');
                }
            } else {
                // Hide legend
                legend.style.transition = 'opacity 0.3s ease, transform 0.3s ease';
                legend.style.opacity = '0';
                legend.style.transform = 'translateX(20px)';
                
                setTimeout(() => {
                    legend.style.display = 'none';
                }, 300);
                
                if (toggleBtn) {
                    toggleBtn.classList.remove('active');
                }
            }
        }
    }

    showDevicePanel(device) {
        const panel = document.getElementById('device-details-panel');
        const topologyContent = document.querySelector('.topology-content');
        const deviceNameEl = document.getElementById('selected-device-name');
        
        if (panel && topologyContent) {
            // Update panel title
            if (deviceNameEl) {
                deviceNameEl.textContent = device.hostname || device.name || 'Unknown Device';
            }
            
            // Populate device details first
            this.populateDeviceDetails(device);
            
            // First show as collapsed bar
            panel.classList.add('show-bar');
            
            // Then expand to full panel after a short delay
            setTimeout(() => {
                panel.classList.add('visible');
                topologyContent.classList.add('panel-visible');
            }, 200);
            
            // Add click handler for collapsed state
            this.setupPanelClickHandler(panel);
        }
    }

    setupPanelClickHandler(panel) {
        const panelHeader = panel.querySelector('.panel-header');
        if (panelHeader) {
            // Remove existing click handler
            panelHeader.removeEventListener('click', this.handlePanelHeaderClick);
            
            // Add new click handler
            this.handlePanelHeaderClick = () => {
                if (panel.classList.contains('show-bar') && !panel.classList.contains('visible')) {
                    panel.classList.add('visible');
                    document.querySelector('.topology-content').classList.add('panel-visible');
                }
            };
            
            panelHeader.addEventListener('click', this.handlePanelHeaderClick);
        }
    }

    closeDevicePanel() {
        const panel = document.getElementById('device-details-panel');
        const topologyContent = document.querySelector('.topology-content');
        
        if (panel && topologyContent) {
            panel.classList.remove('visible', 'expanded', 'show-bar');
            topologyContent.classList.remove('panel-visible', 'panel-expanded');
            
            // Remove click handler
            const panelHeader = panel.querySelector('.panel-header');
            if (panelHeader && this.handlePanelHeaderClick) {
                panelHeader.removeEventListener('click', this.handlePanelHeaderClick);
            }
        }
    }

    togglePanelSize() {
        const panel = document.getElementById('device-details-panel');
        const topologyContent = document.querySelector('.topology-content');
        const toggleBtn = document.getElementById('btn-toggle-panel-size');
        
        if (panel && topologyContent) {
            const isExpanded = panel.classList.contains('expanded');
            
            if (isExpanded) {
                panel.classList.remove('expanded');
                topologyContent.classList.remove('panel-expanded');
                if (toggleBtn) {
                    toggleBtn.innerHTML = '<i class="mdi mdi-arrow-expand-up"></i>';
                    toggleBtn.title = 'Expand Panel';
                }
            } else {
                panel.classList.add('expanded');
                topologyContent.classList.add('panel-expanded');
                if (toggleBtn) {
                    toggleBtn.innerHTML = '<i class="mdi mdi-arrow-collapse-down"></i>';
                    toggleBtn.title = 'Collapse Panel';
                }
            }
        }
    }

    switchTab(tabName) {
        // Remove active class from all tabs and panes
        document.querySelectorAll('.tab-button').forEach(btn => btn.classList.remove('active'));
        document.querySelectorAll('.tab-pane').forEach(pane => pane.classList.remove('active'));
        
        // Add active class to selected tab and pane
        const selectedTab = document.querySelector(`[data-tab="${tabName}"]`);
        const selectedPane = document.getElementById(`tab-${tabName}`);
        
        if (selectedTab && selectedPane) {
            selectedTab.classList.add('active');
            selectedPane.classList.add('active');
        }
    }

    showDeviceListModal() {
        // Create a simple modal showing device list
        const modal = document.createElement('div');
        modal.className = 'device-list-modal';
        modal.innerHTML = `
            <div class="modal-backdrop" onclick="this.parentElement.remove()"></div>
            <div class="modal-content">
                <div class="modal-header">
                    <h4><i class="fas fa-server"></i> Network Devices</h4>
                    <button class="btn-close" onclick="this.closest('.device-list-modal').remove()">
                        <i class="mdi mdi-close"></i>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="device-grid">
                        ${this.devices.map(device => `
                            <div class="device-card" onclick="window.topologyViewer.selectDeviceFromModal('${device.id}')">
                                <div class="device-icon ${this.getDeviceTypeClass(device)}">
                                    <i class="${this.getDeviceIcon(device)}"></i>
                                </div>
                                <div class="device-info">
                                    <div class="device-name">${device.hostname || device.name}</div>
                                    <div class="device-type">${device.device_type || 'Unknown'}</div>
                                    <div class="device-status ${this.getStatusClass(device)}">${device.status || 'Unknown'}</div>
                                </div>
                            </div>
                        `).join('')}
                    </div>
                </div>
            </div>
        `;
        
        // Add modal styles
        const style = document.createElement('style');
        style.textContent = `
            .device-list-modal {
                position: fixed;
                top: 0;
                left: 0;
                right: 0;
                bottom: 0;
                z-index: 10000 !important;
                display: flex;
                align-items: center;
                justify-content: center;
                pointer-events: all;
            }
            .modal-backdrop {
                position: absolute;
                top: 0;
                left: 0;
                right: 0;
                bottom: 0;
                background: rgba(0, 0, 0, 0.5);
                z-index: 9999;
            }
            .modal-content {
                background: white;
                border-radius: 12px;
                width: 90%;
                max-width: 800px;
                max-height: 80vh;
                position: relative;
                z-index: 10001;
                pointer-events: all;
                box-shadow: 0 10px 40px rgba(0, 0, 0, 0.2);
            }
            .modal-header {
                padding: 20px;
                border-bottom: 1px solid var(--border-color);
                display: flex;
                justify-content: space-between;
                align-items: center;
            }
            .modal-body {
                padding: 20px;
                max-height: 60vh;
                overflow-y: auto;
            }
            .device-grid {
                display: grid;
                grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
                gap: 16px;
            }
            .device-card {
                display: flex;
                align-items: center;
                gap: 12px;
                padding: 16px;
                border: 1px solid var(--border-color);
                border-radius: 8px;
                cursor: pointer;
                transition: all 0.2s ease;
            }
            .device-card:hover {
                border-color: var(--primary-color);
                box-shadow: 0 4px 12px rgba(64, 128, 245, 0.15);
            }
            .device-card .device-icon {
                width: 40px;
                height: 40px;
                border-radius: 50%;
                display: flex;
                align-items: center;
                justify-content: center;
                color: white;
                font-size: 18px;
            }
            .device-card .device-info {
                flex: 1;
            }
            .device-card .device-name {
                font-weight: 600;
                margin-bottom: 4px;
            }
            .device-card .device-type {
                font-size: 12px;
                color: #6c757d;
                margin-bottom: 2px;
            }
            .device-card .device-status {
                font-size: 11px;
                padding: 2px 6px;
                border-radius: 4px;
                text-transform: uppercase;
                font-weight: 600;
            }
        `;
        
        document.head.appendChild(style);
        document.body.appendChild(modal);
        
        // Store reference for cleanup
        window.topologyViewer = this;
    }

    selectDeviceFromModal(deviceId) {
        // Close modal
        const modal = document.querySelector('.device-list-modal');
        if (modal) {
            modal.remove();
        }
        
        // Select device
        this.selectDevice(deviceId);
        
        // Zoom to device
        const deviceElement = this.deviceElements.get(deviceId);
        if (deviceElement) {
            const x = parseFloat(deviceElement.getAttribute('data-x')) || 0;
            const y = parseFloat(deviceElement.getAttribute('data-y')) || 0;
            
            // Center the view on the selected device
            const containerRect = document.getElementById('topology-canvas').getBoundingClientRect();
            this.zoomPan.panX = containerRect.width / 2 - x * this.zoomPan.scale;
            this.zoomPan.panY = containerRect.height / 2 - y * this.zoomPan.scale;
            this.zoomPan.updateTransform();
        }
    }

    onPositionChange(deviceId, x, y) {
        // Update position in local data
        const device = this.devices.find(d => d.id === deviceId);
        if (device) {
            device.position = { x, y, pinned: true };
        }
    }

    onDeviceSelect(device) {
        this.selectDevice(device.id);
    }

    addDeviceHighlight(deviceElement) {
        // Remove any existing highlight
        this.removeDeviceHighlight(deviceElement);
        
        // Create elegant pulsing highlight ring
        const highlightRing = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
        highlightRing.setAttribute('class', 'device-highlight-ring');
        highlightRing.setAttribute('cx', '0');
        highlightRing.setAttribute('cy', '0');
        highlightRing.setAttribute('r', '50');
        highlightRing.setAttribute('fill', 'none');
        highlightRing.setAttribute('stroke', '#007bff');
        highlightRing.setAttribute('stroke-width', '3');
        highlightRing.setAttribute('opacity', '0.8');
        highlightRing.setAttribute('stroke-dasharray', '8,4');
        
        // Add subtle glow effect
        const glowRing = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
        glowRing.setAttribute('class', 'device-glow-ring');
        glowRing.setAttribute('cx', '0');
        glowRing.setAttribute('cy', '0');
        glowRing.setAttribute('r', '45');
        glowRing.setAttribute('fill', 'none');
        glowRing.setAttribute('stroke', '#007bff');
        glowRing.setAttribute('stroke-width', '1');
        glowRing.setAttribute('opacity', '0.3');
        
        // Insert at the beginning so it appears behind the device
        deviceElement.insertBefore(highlightRing, deviceElement.firstChild);
        deviceElement.insertBefore(glowRing, deviceElement.firstChild);
        
        // Add CSS animation classes
        highlightRing.style.animation = 'devicePulse 2s ease-in-out infinite';
        glowRing.style.animation = 'deviceGlow 3s ease-in-out infinite alternate';
    }

    removeDeviceHighlight(deviceElement) {
        const highlightRing = deviceElement.querySelector('.device-highlight-ring');
        const glowRing = deviceElement.querySelector('.device-glow-ring');
        
        if (highlightRing) {
            highlightRing.remove();
        }
        if (glowRing) {
            glowRing.remove();
        }
    }

    highlightConnectedDevices(deviceId) {
        // Remove any existing connection highlights
        this.removeConnectionHighlights();
        
        // Find all connections involving this device
        const connectedDeviceIds = new Set();
        const highlightedConnections = [];
        
        this.connections.forEach(connection => {
            if (connection.source === deviceId || connection.target === deviceId) {
                const otherDeviceId = connection.source === deviceId ? connection.target : connection.source;
                connectedDeviceIds.add(otherDeviceId);
                highlightedConnections.push(connection);
            }
        });
        
        // Highlight connected devices with subtle effect
        connectedDeviceIds.forEach(connectedDeviceId => {
            const connectedElement = this.deviceElements.get(connectedDeviceId);
            if (connectedElement) {
                connectedElement.classList.add('connected-device');
                
                // Add subtle connected device indicator
                const connectedRing = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
                connectedRing.setAttribute('class', 'connected-device-ring');
                connectedRing.setAttribute('cx', '0');
                connectedRing.setAttribute('cy', '0');
                connectedRing.setAttribute('r', '42');
                connectedRing.setAttribute('fill', 'none');
                connectedRing.setAttribute('stroke', '#28a745');
                connectedRing.setAttribute('stroke-width', '2');
                connectedRing.setAttribute('opacity', '0.6');
                connectedRing.setAttribute('stroke-dasharray', '4,2');
                
                connectedElement.insertBefore(connectedRing, connectedElement.firstChild);
            }
        });
        
        // Highlight connections
        this.highlightConnections(highlightedConnections);
    }

    highlightConnections(connections) {
        connections.forEach(connection => {
            // Find connection elements in the SVG
            const connectionElements = this.svg.querySelectorAll(
                `.connection-line[data-source="${connection.source}"][data-target="${connection.target}"], ` +
                `.connection-line[data-source="${connection.target}"][data-target="${connection.source}"]`
            );
            
            connectionElements.forEach(element => {
                element.classList.add('highlighted-connection');
                // Temporarily increase stroke width and opacity
                const originalWidth = element.getAttribute('stroke-width') || '2';
                const originalOpacity = element.getAttribute('opacity') || '0.8';
                
                element.setAttribute('data-original-width', originalWidth);
                element.setAttribute('data-original-opacity', originalOpacity);
                element.setAttribute('stroke-width', parseFloat(originalWidth) + 2);
                element.setAttribute('opacity', '1');
                element.style.filter = 'drop-shadow(0 0 4px rgba(0, 123, 255, 0.5))';
            });
        });
    }

    removeConnectionHighlights() {
        // Remove connected device highlights
        this.svg.querySelectorAll('.connected-device').forEach(element => {
            element.classList.remove('connected-device');
            const connectedRing = element.querySelector('.connected-device-ring');
            if (connectedRing) {
                connectedRing.remove();
            }
        });
        
        // Remove connection highlights
        this.svg.querySelectorAll('.highlighted-connection').forEach(element => {
            element.classList.remove('highlighted-connection');
            
            // Restore original properties
            const originalWidth = element.getAttribute('data-original-width');
            const originalOpacity = element.getAttribute('data-original-opacity');
            
            if (originalWidth) {
                element.setAttribute('stroke-width', originalWidth);
                element.removeAttribute('data-original-width');
            }
            if (originalOpacity) {
                element.setAttribute('opacity', originalOpacity);
                element.removeAttribute('data-original-opacity');
            }
            
            element.style.filter = '';
        });
    }
    
    async saveLayout() {
        try {
            const nodes = {};
            const devicesLayer = this.svg.querySelector('#devices-layer');
            
            devicesLayer.querySelectorAll('.device-node').forEach(node => {
                const deviceId = node.getAttribute('data-device-id');
                const x = parseFloat(node.getAttribute('data-x')) || 0;
                const y = parseFloat(node.getAttribute('data-y')) || 0;
                nodes[deviceId] = { x, y, pinned: true };
            });

            const viewport = this.zoomPan.getViewport();

            const response = await fetch(this.config.apiUrls.save, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRFToken': this.getCSRFToken()
                },
                body: JSON.stringify({
                    nodes,
                    viewport,
                    layout_algorithm: 'manual'
                })
            });

            if (response.ok) {
                this.showNotification('Layout saved successfully', 'success');
            } else {
                throw new Error(`HTTP ${response.status}: ${response.statusText}`);
            }
        } catch (error) {
            console.error('Failed to save layout:', error);
            this.showNotification('Failed to save layout', 'error');
        }
    }

    loadSavedLayout() {
        const savedLayout = this.config.savedLayout;
        if (!savedLayout || !savedLayout.nodes) {
            this.applyHierarchicalLayout();
        }
    }
    
    applyHierarchicalLayout() {
        if (this.devices.length === 0) {
            console.log('No devices to layout');
            return;
        }
        
        this.applyAutoLayout('hierarchical');
    }
    
    applyDefaultLayout() {
        // Simple grid layout for devices when no saved layout exists
        const devicesLayer = this.svg.querySelector('#devices-layer');
        if (!devicesLayer) return;
        
        const deviceCount = this.devices.length;
        if (deviceCount === 0) return;
        
        // Calculate grid dimensions
        const cols = Math.ceil(Math.sqrt(deviceCount));
        const rows = Math.ceil(deviceCount / cols);
        
        // Get SVG dimensions
        const viewBox = this.svg.getAttribute('viewBox');
        if (!viewBox) return;
        
        const [, , width, height] = viewBox.split(' ').map(Number);
        const centerX = width / 2;
        const centerY = height / 2;
        
        // Calculate spacing - increased for less crowding
        const spacingX = Math.min(300, (width - 100) / Math.max(cols - 1, 1));
        const spacingY = Math.min(250, (height - 100) / Math.max(rows - 1, 1));
        
        // Position devices in grid
        this.devices.forEach((device, index) => {
            const row = Math.floor(index / cols);
            const col = index % cols;
            
            const x = centerX + (col - (cols - 1) / 2) * spacingX;
            const y = centerY + (row - (rows - 1) / 2) * spacingY;
            
            // Update device position
            device.position = { x, y, pinned: false };
            
            // Update DOM element
            const deviceElement = this.deviceElements.get(device.id);
            if (deviceElement) {
                deviceElement.setAttribute('data-x', x);
                deviceElement.setAttribute('data-y', y);
                deviceElement.style.transform = `translate(${x}px, ${y}px)`;
            }
        });
        
        // Render connections after positioning
        setTimeout(() => {
            this.connectionRenderer.renderConnections(this.connections);
        }, 0);
    }

    showLoading(show) {
        this.isLoading = show;
        const canvas = document.getElementById('topology-canvas');
        if (canvas) {
            if (show) {
                // Add loading overlay if it doesn't exist
                let loadingOverlay = canvas.querySelector('.topology-loading-overlay');
                if (!loadingOverlay) {
                    loadingOverlay = document.createElement('div');
                    loadingOverlay.className = 'topology-loading-overlay';
                    loadingOverlay.innerHTML = `
                        <div class="topology-loading">
                            <div class="spinner"></div>
                            <div style="margin-top: 16px; font-size: 16px; font-weight: 600;">Loading topology...</div>
                        </div>
                    `;
                    canvas.appendChild(loadingOverlay);
                }
                loadingOverlay.style.display = 'flex';
            } else {
                // Remove loading overlay
                const loadingOverlay = canvas.querySelector('.topology-loading-overlay');
                if (loadingOverlay) {
                    loadingOverlay.style.display = 'none';
                }
            }
        }
    }

    showError(message) {
        const container = document.getElementById('topology-container');
        if (container) {
            container.innerHTML = `
                <div class="welcome-message" style="color: var(--error-color);">
                    <div class="welcome-icon" style="background: linear-gradient(304deg, #dc3545, #ef4444);">
                        <i class="fas fa-exclamation-triangle"></i>
                    </div>
                    <h3>Error Loading Topology</h3>
                    <p>${message}</p>
                    <button class="btn primary" onclick="location.reload()" style="margin-top: 20px;">
                        <i class="fas fa-redo"></i> Retry
                    </button>
                </div>
            `;
        }
    }

    showNotification(message, type = 'info') {
        // Simple notification system
        const notification = document.createElement('div');
        notification.className = `alert alert-${type === 'success' ? 'success' : 'danger'}`;
        notification.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            z-index: 9999;
            min-width: 300px;
        `;
        notification.textContent = message;
        
        document.body.appendChild(notification);
        
        setTimeout(() => {
            if (notification.parentNode) {
                notification.parentNode.removeChild(notification);
            }
        }, 3000);
    }

    getCSRFToken() {
        const cookieValue = document.cookie
            .split('; ')
            .find(row => row.startsWith('csrftoken='))
            ?.split('=')[1];
        return cookieValue || '';
    }

    // Enhanced device detail functions for richer data display
    createEnhancedInterfaceSection(device) {
        if (!device.connected_interfaces || device.connected_interfaces.length === 0) {
            return this.createInterfaceInfoSection(device);
        }

        const interfaces = device.connected_interfaces;
        
        const interfaceInfo = document.createElement('div');
        interfaceInfo.className = 'device-info-section enhanced-interfaces';
        
        interfaceInfo.innerHTML = `
            <h6><i class="fas fa-network-wired"></i> Enhanced Interface Details</h6>
            <div class="interface-summary-enhanced">
                <div class="summary-stats">
                    <div class="stat-item">
                        <label>Active Interfaces:</label>
                        <span>${interfaces.length}</span>
                    </div>
                    <div class="stat-item">
                        <label>Connected:</label>
                        <span>${interfaces.filter(i => i.connected_to).length}</span>
                    </div>
                    <div class="stat-item">
                        <label>Trunk Ports:</label>
                        <span>${interfaces.filter(i => i.is_trunk).length}</span>
                    </div>
                </div>
            </div>
            <div class="interfaces-detailed-list">
                ${interfaces.map(iface => `
                    <div class="interface-detailed-item ${iface.status}">
                        <div class="interface-main-info">
                            <div class="interface-name-section">
                                <span class="interface-name">${iface.name}</span>
                                <span class="interface-type">${iface.interface_type}</span>
                                ${iface.speed ? `<span class="interface-speed">${iface.speed} Mbps</span>` : ''}
                            </div>
                            <div class="interface-status-section">
                                <span class="interface-status ${iface.status}">${iface.status}/${iface.protocol}</span>
                                ${iface.duplex !== 'unknown' ? `<span class="duplex">${iface.duplex}</span>` : ''}
                            </div>
                        </div>
                        ${iface.ip_address ? `
                            <div class="interface-ip-info">
                                <i class="fas fa-network-wired"></i>
                                <span>${iface.ip_address}${iface.subnet_mask ? '/' + iface.subnet_mask : ''}</span>
                            </div>
                        ` : ''}
                        ${iface.vlan ? `
                            <div class="interface-vlan-info">
                                <i class="fas fa-tag"></i>
                                <span>VLAN ${iface.vlan}</span>
                                ${iface.is_trunk ? '<span class="trunk-indicator">TRUNK</span>' : ''}
                            </div>
                        ` : ''}
                        ${iface.connected_to ? `
                            <div class="interface-connection-info">
                                <i class="fas fa-link"></i>
                                <span class="connected-device">${iface.connected_to.device}</span>
                                <span class="connected-interface">${iface.connected_to.interface}</span>
                                ${iface.connected_to.ip_address ? `<span class="connected-ip">(${iface.connected_to.ip_address})</span>` : ''}
                            </div>
                        ` : ''}
                        ${iface.description ? `<div class="interface-description">${iface.description}</div>` : ''}
                    </div>
                `).join('')}
            </div>
        `;
        
        return interfaceInfo;
    }

    createSystemInfoSection(device) {
        if (!device.command_outputs) {
            return null;
        }

        const version = device.command_outputs.show_version;
        const inventory = device.command_outputs.show_inventory;
        
        if (!version && !inventory) {
            return null;
        }
        
        const systemInfo = document.createElement('div');
        systemInfo.className = 'device-info-section';
        
        let systemDetails = '';
        let inventoryDetails = '';
        
        if (version) {
            // Extract key system information from version output
            const uptimeMatch = version.match(/uptime is (.+?)(?:\n|$)/i);
            const memoryMatch = version.match(/(\d+)K\/(\d+)K bytes of memory/i);
            const configRegMatch = version.match(/Configuration register is (0x[0-9A-Fa-f]+)/i);
            
            systemDetails = `
                <div class="system-details">
                    ${uptimeMatch ? `<div class="system-item"><label>Uptime:</label><span>${NetworkUtils.formatUptime(uptimeMatch[1])}</span></div>` : ''}
                    ${memoryMatch ? `<div class="system-item"><label>Memory:</label><span>${memoryMatch[1]}K/${memoryMatch[2]}K</span></div>` : ''}
                    ${configRegMatch ? `<div class="system-item"><label>Config Register:</label><span>${configRegMatch[1]}</span></div>` : ''}
                </div>
            `;
        }
        
        if (inventory) {
            // Parse inventory for hardware components
            const components = inventory.split('\n\n').filter(comp => comp.trim());
            inventoryDetails = `
                <div class="inventory-details">
                    <h6>Hardware Inventory</h6>
                    ${components.map(comp => {
                        const nameMatch = comp.match(/NAME: "([^"]+)"/);
                        const descrMatch = comp.match(/DESCR: "([^"]+)"/);
                        const pidMatch = comp.match(/PID: ([^,\s]+)/);
                        const snMatch = comp.match(/SN: ([^\s\n]+)/);
                        
                        if (nameMatch) {
                            return `
                                <div class="inventory-item">
                                    <div class="component-name">${nameMatch[1]}</div>
                                    ${descrMatch ? `<div class="component-description">${descrMatch[1]}</div>` : ''}
                                    <div class="component-details">
                                        ${pidMatch ? `<span class="pid">PID: ${pidMatch[1]}</span>` : ''}
                                        ${snMatch ? `<span class="serial">SN: ${snMatch[1]}</span>` : ''}
                                    </div>
                                </div>
                            `;
                        }
                        return '';
                    }).join('')}
                </div>
            `;
        }
        
        systemInfo.innerHTML = `
            <h6><i class="fas fa-server"></i> System Information</h6>
            ${systemDetails}
            ${inventoryDetails}
        `;
        
        return systemInfo;
    }

    // Location Selector Methods
    async showLocationSelectorModal() {
        const modal = document.getElementById('location-selector-modal');
        const locationList = document.getElementById('location-list');
        const searchInput = document.getElementById('location-search');
        
        if (!modal) return;
        
        // Show modal
        modal.style.display = 'flex';
        
        // Load locations
        try {
            const response = await fetch(this.config.apiUrls.locations);
            if (!response.ok) {
                throw new Error(`HTTP ${response.status}: ${response.statusText}`);
            }
            
            const data = await response.json();
            this.renderLocationList(data.locations);
            
            // Setup search functionality
            searchInput.addEventListener('input', (e) => {
                this.filterLocations(data.locations, e.target.value);
            });
            
        } catch (error) {
            console.error('Failed to load locations:', error);
            locationList.innerHTML = `
                <div class="error-container" style="padding: 40px; text-align: center; color: #dc3545;">
                    <i class="fas fa-exclamation-triangle" style="font-size: 24px; margin-bottom: 12px;"></i>
                    <p>Failed to load locations</p>
                    <small>${error.message}</small>
                </div>
            `;
        }
    }

    renderLocationList(locations) {
        const locationList = document.getElementById('location-list');
        
        if (locations.length === 0) {
            locationList.innerHTML = `
                <div style="padding: 40px; text-align: center; color: #666;">
                    <i class="fas fa-info-circle" style="font-size: 24px; margin-bottom: 12px;"></i>
                    <p>No locations with devices found</p>
                </div>
            `;
            return;
        }
        
        locationList.innerHTML = locations.map(location => `
            <div class="location-item" onclick="selectLocation('${location.id}')">
                <div class="location-info">
                    <div class="location-name">${location.name}</div>
                    <div class="location-details">${location.full_name}</div>
                </div>
                <div class="device-count">${location.device_count} device${location.device_count !== 1 ? 's' : ''}</div>
            </div>
        `).join('');
    }

    filterLocations(locations, searchTerm) {
        const filtered = locations.filter(location => 
            location.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
            location.full_name.toLowerCase().includes(searchTerm.toLowerCase())
        );
        this.renderLocationList(filtered);
    }
}

// Export for global use
window.TopologyViewer = TopologyViewer;

