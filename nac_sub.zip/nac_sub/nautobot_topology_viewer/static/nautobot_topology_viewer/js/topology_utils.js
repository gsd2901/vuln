/**
 * Topology Viewer Utilities
 * Extracted and adapted from digital_twin.js
 */

// Global variables
let nodePositions = new Map();
let dragState = new Map();
let isDeviceDragging = false; // Global flag to prevent pan during device dragging
let lastDeviceDragEndTime = 0; // Timestamp to prevent race conditions

// Network Constants and Utilities
class NetworkConstants {
    // Network layer hierarchy for proper topology organization
    static LAYER_HIERARCHY = {
        CORE: 1,
        DISTRIBUTION: 2,
        ACCESS: 3,
        UNKNOWN: 4
    };

    // Connection types for proper network classification
    static CONNECTION_TYPES = {
        POINT_TO_POINT: 'P2P',
        LAYER3: 'L3',
        TRUNK: 'TRUNK',
        ACCESS: 'ACCESS',
        MANAGEMENT: 'MGMT',
        UPLINK: 'UPLINK',
        UNKNOWN: 'UNKNOWN'
    };

    // Interface speed mappings (in Mbps)
    static INTERFACE_SPEEDS = {
        'FastEthernet': 100,
        'GigabitEthernet': 1000,
        'TenGigabitEthernet': 10000,
        'FortyGigabitEthernet': 40000,
        'HundredGigE': 100000,
        'Ethernet': 10
    };

    // Device type patterns for classification
    static DEVICE_PATTERNS = {
        ROUTER: ['router', 'csr', '3725', '2900', '1900', 'asr', 'isr'],
        SWITCH: ['switch', 'catalyst', '2960', '3560', '3750', '4500', '6500', 'nexus'],
        FIREWALL: ['firewall', 'asa', 'pix', 'fortigate', 'checkpoint'],
        WIRELESS: ['wireless', 'wlc', 'ap', 'access-point', 'aironet'],
        SERVER: ['server', 'host', 'vm', 'linux', 'windows'],
        LOAD_BALANCER: ['f5', 'bigip', 'load-balancer', 'lb']
    };

    // Management interface patterns
    static MANAGEMENT_PATTERNS = [
        /\bmgmt\b/i, /\bmanagement\b/i, /\bmgmt0\b/i, /\bme0\b/i,
        /\bfxp0\b/i, /\bem0\b/i, /\boob\b/i, /\bout-of-band\b/i,
        /\bconsole\b/i, /\bcon0\b/i, /\baux\b/i, /\baux0\b/i,
        /\bvty\b/i, /\btelnet\b/i, /\bssh\b/i, /\bserial\b/i
    ];

    // L3 interface patterns (typically routed interfaces)
    static L3_INTERFACE_PATTERNS = [
        /^(Serial|Se)\d+/i,           // Serial interfaces (WAN links)
        /^(Tunnel|Tu)\d+/i,           // Tunnel interfaces
        /^(Loopback|Lo)\d+/i,         // Loopback interfaces
        /^(Dialer|Di)\d+/i,           // Dialer interfaces
        /^(BRI|PRI)\d+/i,             // ISDN interfaces
        /^(ATM)\d+/i,                 // ATM interfaces
        /^(Frame-Relay|FR)\d+/i,      // Frame Relay interfaces
        /^(Multilink|Mu)\d+/i,        // Multilink interfaces
        /^(Virtual-Template|Vt)\d+/i, // Virtual Template interfaces
        /^(Cellular|Ce)\d+/i,         // Cellular interfaces
        /^(Satellite|Sa)\d+/i         // Satellite interfaces
    ];

    // Router interface patterns that are typically L3 even when Ethernet-based
    static ROUTER_L3_PATTERNS = [
        /\bwan\b/i,                   // WAN in interface name/description
        /\bp2p\b/i,                   // Point-to-point in name/description
        /\bpoint.*to.*point\b/i,      // Point-to-point spelled out
        /\brouted\b/i,                // Explicitly routed interface
        /\bl3\b/i,                    // L3 in name/description
        /\binterconnect\b/i,          // Interconnect links
        /\buplink\b/i,                // Uplink (when on routers, usually L3)
        /\btransit\b/i,               // Transit links
        /\bbackbone\b/i               // Backbone links
    ];

    static getDeviceLayer(device, connectionCount = 0) {
        const hostname = (device.hostname || device.name || '').toLowerCase();
        const platform = (device.platform || '').toLowerCase();
        const model = (device.model || '').toLowerCase();
        const role = (device.device_role || '').toLowerCase();

        // Check for explicit role indicators
        if (role.includes('core') || hostname.includes('core')) {
            return this.LAYER_HIERARCHY.CORE;
        }
        if (role.includes('distribution') || hostname.includes('dist')) {
            return this.LAYER_HIERARCHY.DISTRIBUTION;
        }
        if (role.includes('access') || hostname.includes('access')) {
            return this.LAYER_HIERARCHY.ACCESS;
        }

        // Use connection count as a heuristic
        if (connectionCount >= 8) return this.LAYER_HIERARCHY.CORE;
        if (connectionCount >= 4) return this.LAYER_HIERARCHY.DISTRIBUTION;
        if (connectionCount >= 1) return this.LAYER_HIERARCHY.ACCESS;

        return this.LAYER_HIERARCHY.UNKNOWN;
    }

    static getLayerName(layer) {
        switch (layer) {
            case this.LAYER_HIERARCHY.CORE: return 'Core';
            case this.LAYER_HIERARCHY.DISTRIBUTION: return 'Distribution';
            case this.LAYER_HIERARCHY.ACCESS: return 'Access';
            default: return 'Unknown';
        }
    }

    static getLayerColor(layer) {
        switch (layer) {
            case this.LAYER_HIERARCHY.CORE: return '#dc3545'; // Red for core
            case this.LAYER_HIERARCHY.DISTRIBUTION: return '#fd7e14'; // Orange for distribution
            case this.LAYER_HIERARCHY.ACCESS: return '#28a745'; // Green for access
            default: return '#6c757d'; // Gray for unknown
        }
    }

    static getDeviceType(device) {
        const hostname = (device.hostname || device.name || '').toLowerCase();
        const platform = (device.platform || '').toLowerCase();
        const model = (device.model || '').toLowerCase();
        const capabilities = device.capabilities || [];

        // Check capabilities first (most reliable for discovery data)
        if (capabilities.includes('Router')) return 'router';
        if (capabilities.includes('Switch')) return 'switch';

        // Check device patterns
        for (const [type, patterns] of Object.entries(this.DEVICE_PATTERNS)) {
            if (patterns.some(pattern => 
                hostname.includes(pattern) || 
                platform.includes(pattern) || 
                model.includes(pattern)
            )) {
                return type.toLowerCase().replace('_', '-');
            }
        }

        return 'unknown';
    }

    static determineConnectionType(connection, sourceInterface, targetInterface) {
        // Check if it's a management connection
        if (this.isManagementConnection(connection, sourceInterface, targetInterface)) {
            return this.CONNECTION_TYPES.MANAGEMENT;
        }

        // Check for trunk connection
        if (this.isTrunkConnection(connection, sourceInterface, targetInterface)) {
            return this.CONNECTION_TYPES.TRUNK;
        }

        // Check for L3/routed connections (enhanced detection)
        if (this.isLayer3Connection(connection, sourceInterface, targetInterface)) {
            return this.CONNECTION_TYPES.LAYER3;
        }

        // Check for point-to-point router connections (fallback for older detection)
        if (this.isPointToPointConnection(connection, sourceInterface, targetInterface)) {
            return this.CONNECTION_TYPES.POINT_TO_POINT;
        }

        // Default to access for switch ports
        return this.CONNECTION_TYPES.ACCESS;
    }

    static isManagementConnection(connection, sourceInterface, targetInterface) {
        const sourceInterfaceName = sourceInterface?.name || connection.source_interface || '';
        const targetInterfaceName = targetInterface?.name || connection.target_interface || '';
        const description = connection.description || '';
        
        return this.MANAGEMENT_PATTERNS.some(pattern => 
            pattern.test(sourceInterfaceName) || 
            pattern.test(targetInterfaceName) || 
            pattern.test(description)
        );
    }

    static isTrunkConnection(connection, sourceInterface, targetInterface) {
        // Check explicit trunk indicators
        if (connection.trunk || sourceInterface?.is_trunk || targetInterface?.is_trunk) {
            return true;
        }

        // Check for VLAN information indicating trunk
        if (connection.native_vlan || connection.allowed_vlans?.length > 1) {
            return true;
        }

        // Check interface names for trunk indicators
        const trunkPatterns = ['trunk', 'uplink', 'backbone'];
        const sourceName = (sourceInterface?.name || connection.source_interface || '').toLowerCase();
        const targetName = (targetInterface?.name || connection.target_interface || '').toLowerCase();
        
        return trunkPatterns.some(pattern => 
            sourceName.includes(pattern) || targetName.includes(pattern)
        );
    }

    static isLayer3Connection(connection, sourceInterface, targetInterface) {
        // Enhanced detection for Layer 3 (routed) connections
        
        // 1. Check device capabilities for router-to-router connections
        const sourceCapabilities = connection.source_capabilities || [];
        const targetCapabilities = connection.target_capabilities || [];
        const isRouterToRouter = sourceCapabilities.includes('Router') && 
                                targetCapabilities.includes('Router');
        
        // 2. Check for device types using device patterns
        const sourceDevice = connection.source_device || {};
        const targetDevice = connection.target_device || {};
        const isRouterToRouterByType = this.isRouterDevice(sourceDevice) && this.isRouterDevice(targetDevice);
        
        // 3. Check interface types for L3 patterns
        const sourceInterfaceName = sourceInterface?.name || connection.source_interface || '';
        const targetInterfaceName = targetInterface?.name || connection.target_interface || '';
        const hasL3Interfaces = this.isL3Interface(sourceInterfaceName) || this.isL3Interface(targetInterfaceName);
        
        // 4. Check for L3 indicators in interface descriptions
        const sourceDescription = sourceInterface?.description || connection.source_description || '';
        const targetDescription = targetInterface?.description || connection.target_description || '';
        const hasL3Description = this.hasL3Description(sourceDescription) || this.hasL3Description(targetDescription);
        
        // 5. Check for point-to-point subnets (typically /30 or /31)
        const hasP2PSubnet = connection.subnet && 
                           (connection.subnet.includes('/30') || connection.subnet.includes('/31'));
        
        // 6. Check for IP addresses on interfaces (indicates L3)
        const hasSourceIP = sourceInterface?.ip_address || connection.source_ip;
        const hasTargetIP = targetInterface?.ip_address || connection.target_ip;
        const hasIPAddresses = hasSourceIP && hasTargetIP;
        
        return isRouterToRouter || isRouterToRouterByType || hasL3Interfaces || 
               hasL3Description || hasP2PSubnet || hasIPAddresses;
    }

    static isPointToPointConnection(connection, sourceInterface, targetInterface) {
        // Fallback method for older P2P detection
        const sourceCapabilities = connection.source_capabilities || [];
        const targetCapabilities = connection.target_capabilities || [];
        
        const isRouterToRouter = sourceCapabilities.includes('Router') && 
                                targetCapabilities.includes('Router');
        
        // Check for point-to-point subnets (typically /30 or /31)
        const hasP2PSubnet = connection.subnet && 
                           (connection.subnet.includes('/30') || connection.subnet.includes('/31'));
        
        return isRouterToRouter || hasP2PSubnet;
    }

    static isRouterDevice(device) {
        if (!device) return false;
        
        const hostname = (device.hostname || device.name || '').toLowerCase();
        const platform = (device.platform || '').toLowerCase();
        const model = (device.model || '').toLowerCase();
        const deviceType = (device.device_type || '').toLowerCase();
        
        // Check against router patterns
        return this.DEVICE_PATTERNS.ROUTER.some(pattern => 
            hostname.includes(pattern) || 
            platform.includes(pattern) || 
            model.includes(pattern) ||
            deviceType.includes(pattern)
        );
    }

    static isL3Interface(interfaceName) {
        if (!interfaceName) return false;
        
        // Check against L3 interface patterns
        return this.L3_INTERFACE_PATTERNS.some(pattern => pattern.test(interfaceName));
    }

    static hasL3Description(description) {
        if (!description) return false;
        
        // Check description for L3/router indicators
        return this.ROUTER_L3_PATTERNS.some(pattern => pattern.test(description));
    }

    static getInterfaceSpeed(interfaceName) {
        if (!interfaceName) return 0;
        
        for (const [type, speed] of Object.entries(this.INTERFACE_SPEEDS)) {
            if (interfaceName.includes(type)) {
                return speed;
            }
        }
        return 0;
    }
}

// Network parsing utilities
class NetworkUtils {
    static parseInterfaceName(interfaceName) {
        if (!interfaceName) return { type: 'unknown', slot: null, port: null };
        
        // Common interface name patterns
        const patterns = [
            /^(GigabitEthernet|Gi)(\d+)\/(\d+)$/,
            /^(FastEthernet|Fa)(\d+)\/(\d+)$/,
            /^(TenGigabitEthernet|Te)(\d+)\/(\d+)$/,
            /^(Ethernet|Et)(\d+)\/(\d+)$/,
            /^(Serial|Se)(\d+)\/(\d+)$/
        ];

        for (const pattern of patterns) {
            const match = interfaceName.match(pattern);
            if (match) {
                return {
                    type: match[1],
                    slot: parseInt(match[2]),
                    port: parseInt(match[3]),
                    shortName: `${match[1].substring(0, 2)}${match[2]}/${match[3]}`
                };
            }
        }

        return { type: interfaceName, slot: null, port: null, shortName: interfaceName };
    }

    static extractIPFromConfig(configOutput, interfaceName) {
        if (!configOutput || !interfaceName) return null;
        
        const lines = configOutput.split('\n');
        let inInterface = false;
        
        for (const line of lines) {
            const trimmed = line.trim();
            if (trimmed.startsWith(`interface ${interfaceName}`)) {
                inInterface = true;
                continue;
            }
            if (inInterface && trimmed.startsWith('interface ')) {
                break;
            }
            if (inInterface && trimmed.startsWith('ip address ')) {
                const match = trimmed.match(/ip address (\d+\.\d+\.\d+\.\d+) (\d+\.\d+\.\d+\.\d+)/);
                if (match) {
                    return { ip: match[1], mask: match[2] };
                }
            }
        }
        return null;
    }

    static parseVlanFromDescription(description) {
        if (!description) return null;
        
        const vlanMatch = description.match(/vlan[\s-]*([0-9]+)/i);
        return vlanMatch ? vlanMatch[1] : null;
    }

    static getDuplexStatus(connection) {
        const duplex = connection.duplex || 'unknown';
        return duplex === 'full' ? 'Full' : duplex === 'half' ? 'Half' : 'Unknown';
    }

    static formatUptime(uptimeString) {
        if (!uptimeString) return 'Unknown';
        
        // Parse uptime from various formats
        const match = uptimeString.match(/(\d+)\s*week[s]?,\s*(\d+)\s*day[s]?,\s*(\d+)\s*hour[s]?,\s*(\d+)\s*minute[s]?/);
        if (match) {
            const [, weeks, days, hours, minutes] = match;
            return `${weeks}w ${days}d ${hours}h ${minutes}m`;
        }
        return uptimeString;
    }
}

// Enhanced Utility Classes
class DOMUtils {
    static showModal(modalElement) {
        if (modalElement) {
            modalElement.style.display = 'flex';
            modalElement.style.alignItems = 'center';
            modalElement.style.justifyContent = 'center';
            document.body.classList.add('modal-open');
        }
    }

    static hideModal(modalElement) {
        if (modalElement) {
            modalElement.style.display = 'none';
            document.body.classList.remove('modal-open');
        }
    }

    static clearContainer(container) {
        if (container) {
            while (container.firstChild) {
                container.removeChild(container.firstChild);
            }
        }
    }

    static showElement(element) {
        if (element) element.style.display = 'block';
    }

    static hideElement(element) {
        if (element) element.style.display = 'none';
    }

    static createElement(tag, className, attributes = {}) {
        const element = document.createElement(tag);
        if (className) element.className = className;
        Object.entries(attributes).forEach(([key, value]) => {
            element.setAttribute(key, value);
        });
        return element;
    }
}

class TopologyDragging {
    constructor(svg, onPositionChange, zoomPan = null) {
        this.svg = svg;
        this.onPositionChange = onPositionChange;
        this.zoomPan = zoomPan; // Reference to ZoomPan instance for coordinate transformation
        this.isDragging = false;
        this.dragData = null;
        this.setupEventListeners();
    }
    
    // Set the ZoomPan instance after initialization (allows for circular dependency resolution)
    setZoomPan(zoomPan) {
        this.zoomPan = zoomPan;
    }

    setupEventListeners() {
        this.svg.addEventListener('mousedown', this.handleMouseDown.bind(this));
        document.addEventListener('mousemove', this.handleMouseMove.bind(this));
        document.addEventListener('mouseup', this.handleMouseUp.bind(this));
    }

    handleMouseDown(event) {
        const deviceNode = event.target.closest('.device-node');
        if (!deviceNode) return;

        this.isDragging = true;
        isDeviceDragging = true; // Set global flag to prevent panning
        
        // Ensure ZoomPan is not in panning state when device drag starts
        if (this.zoomPan) {
            this.zoomPan.isPanning = false;
            this.zoomPan.panStart = null;
            if (this.zoomPan.container) {
                this.zoomPan.container.style.cursor = 'grab';
            }
        }
        
        this.dragData = {
            element: deviceNode,
            deviceId: deviceNode.getAttribute('data-device-id'),
            startX: event.clientX,
            startY: event.clientY,
            initialX: parseFloat(deviceNode.getAttribute('data-x')) || 0,
            initialY: parseFloat(deviceNode.getAttribute('data-y')) || 0
        };

        deviceNode.style.cursor = 'grabbing';
        deviceNode.classList.add('dragging');
        
        // Stop event propagation to prevent canvas panning
        event.preventDefault();
        event.stopPropagation();
    }

    handleMouseMove(event) {
        if (!this.isDragging || !this.dragData) return;

        // Calculate raw delta in screen coordinates
        let deltaX = event.clientX - this.dragData.startX;
        let deltaY = event.clientY - this.dragData.startY;
        
        // If we have a zoomPan instance, account for the SVG's current scale
        // The device node exists in SVG coordinate space, but mouse events are in screen space
        if (this.zoomPan) {
            deltaX = deltaX / this.zoomPan.scale;
            deltaY = deltaY / this.zoomPan.scale;
        }

        const newX = this.dragData.initialX + deltaX;
        const newY = this.dragData.initialY + deltaY;

        this.dragData.element.style.transform = `translate(${newX}px, ${newY}px)`;
        this.dragData.element.setAttribute('data-x', newX);
        this.dragData.element.setAttribute('data-y', newY);

        // Update connections during drag
        this.updateConnections();
        
        // Prevent any other handlers from processing this event
        event.preventDefault();
        event.stopPropagation();
    }

    handleMouseUp(event) {
        if (!this.isDragging || !this.dragData) return;

        const deviceId = this.dragData.deviceId;
        const x = parseFloat(this.dragData.element.getAttribute('data-x')) || 0;
        const y = parseFloat(this.dragData.element.getAttribute('data-y')) || 0;

        // Store position
        nodePositions.set(deviceId, { x, y, pinned: true });

        // Notify position change
        if (this.onPositionChange) {
            this.onPositionChange(deviceId, x, y);
        }

        this.dragData.element.style.cursor = 'grab';
        this.dragData.element.classList.remove('dragging');

        // Ensure ZoomPan state is clean before clearing device drag flag
        if (this.zoomPan) {
            this.zoomPan.isPanning = false;
            this.zoomPan.panStart = null;
            if (this.zoomPan.container) {
                this.zoomPan.container.style.cursor = 'grab';
            }
        }

        this.isDragging = false;
        isDeviceDragging = false; // Clear global flag
        lastDeviceDragEndTime = Date.now(); // Set timestamp to prevent race conditions
        console.log('TopologyDragging: Device drag completed, cleared global flag');
        this.dragData = null;
        
        // Stop event propagation to prevent other handlers (like ZoomPan) from processing this
        event.preventDefault();
        event.stopPropagation();
    }

    updateConnections() {
        // Update connection lines during drag
        // Group connections by source-target pairs to maintain proper offsets
        const connectionGroups = this.svg.querySelectorAll('.connection-group');
        connectionGroups.forEach(group => {
            const connections = group.querySelectorAll('.connection-line');
            if (connections.length > 0) {
                const sourceId = connections[0].getAttribute('data-source');
                const targetId = connections[0].getAttribute('data-target');
                
                const sourceNode = this.svg.querySelector(`[data-device-id="${sourceId}"]`);
                const targetNode = this.svg.querySelector(`[data-device-id="${targetId}"]`);
                
                if (sourceNode && targetNode) {
                    const sourcePos = this.getNodeCenter(sourceNode);
                    const targetPos = this.getNodeCenter(targetNode);
                    
                    // Update each connection in the group with proper offset
                    connections.forEach((connection, index) => {
                        this.updateConnectionLineInGroup(connection, sourcePos, targetPos, connections.length, index);
                    });
                    
                    // Update connection labels once per group (use the first connection for label positioning)
                    this.updateConnectionLabel(connections[0], sourcePos, targetPos);
                }
            }
        });
    }

    updateConnectionLineInGroup(connection, sourcePos, targetPos, totalConnections, connectionIndex) {
        // Get connection positions using helper method
        const positions = this.getConnectionPositions(sourcePos, targetPos, totalConnections, connectionIndex);
        
        connection.setAttribute('x1', positions.source.x);
        connection.setAttribute('y1', positions.source.y);
        connection.setAttribute('x2', positions.target.x);
        connection.setAttribute('y2', positions.target.y);
    }

    updateConnectionLine(connection) {
        const sourceId = connection.getAttribute('data-source');
        const targetId = connection.getAttribute('data-target');
        
        const sourceNode = this.svg.querySelector(`[data-device-id="${sourceId}"]`);
        const targetNode = this.svg.querySelector(`[data-device-id="${targetId}"]`);
        
        if (sourceNode && targetNode) {
            const sourcePos = this.getNodeCenter(sourceNode);
            const targetPos = this.getNodeCenter(targetNode);
            
            // Find the connection group to get offset information
            const connectionGroup = connection.closest('.connection-group');
            if (connectionGroup) {
                // Get all connections in this group to calculate offset
                const allConnections = connectionGroup.querySelectorAll('.connection-line');
                const connectionIndex = Array.from(allConnections).indexOf(connection);
                const totalConnections = allConnections.length;
                
                // Use the new method for grouped connections
                this.updateConnectionLineInGroup(connection, sourcePos, targetPos, totalConnections, connectionIndex);
            } else {
                // Fallback for single connections
                connection.setAttribute('x1', sourcePos.x);
                connection.setAttribute('y1', sourcePos.y);
                connection.setAttribute('x2', targetPos.x);
                connection.setAttribute('y2', targetPos.y);
                
                // Update the connection label position
                this.updateConnectionLabel(connection, sourcePos, targetPos);
            }
        }
    }
    
    updateConnectionLabel(connection, sourcePos, targetPos) {
        // Find the connection group and its label
        const connectionGroup = connection.closest('.connection-group');
        if (!connectionGroup) {
            console.warn('No connection group found for connection:', connection);
            return;
        }
        
        const labelGroup = connectionGroup.querySelector('.connection-label-group');
        if (!labelGroup) {
            console.warn('No label group found in connection group:', connectionGroup);
            return;
        }
        
        // Calculate new position along the line
        const dx = targetPos.x - sourcePos.x;
        const dy = targetPos.y - sourcePos.y;
        const distance = Math.sqrt(dx * dx + dy * dy);
        const angle = Math.atan2(dy, dx);
        
        // Calculate perpendicular angle for offsets
        const perpAngle = angle + Math.PI / 2; // 90 degrees perpendicular
        const perpendicularOffset = 12;
        
        // Convert angle to degrees for SVG rotation
        let angleDegrees = (angle * 180) / Math.PI;
        
        // Ensure text is always readable (not upside down)
        if (angleDegrees > 90 || angleDegrees < -90) {
            angleDegrees += 180;
        }
        
        // Update all labels in the group
        const interfaceLabels = labelGroup.querySelectorAll('.interface-label');
        const centerLabels = labelGroup.querySelectorAll('.center-label');
        
        // Update interface labels (source at 25%, target at 75%)
        if (interfaceLabels.length >= 1) {
            // Source label at 25%
            const sourceRatio = 0.25;
            const sourceLabelX = sourcePos.x + dx * sourceRatio;
            const sourceLabelY = sourcePos.y + dy * sourceRatio;
            const sourceFinalX = sourceLabelX + Math.cos(perpAngle) * perpendicularOffset;
            const sourceFinalY = sourceLabelY + Math.sin(perpAngle) * perpendicularOffset;
            interfaceLabels[0].setAttribute('transform', `translate(${sourceFinalX}, ${sourceFinalY}) rotate(${angleDegrees})`);
        }
        
        if (interfaceLabels.length >= 2) {
            // Target label at 75%
            const targetRatio = 0.75;
            const targetLabelX = sourcePos.x + dx * targetRatio;
            const targetLabelY = sourcePos.y + dy * targetRatio;
            const targetFinalX = targetLabelX + Math.cos(perpAngle) * perpendicularOffset;
            const targetFinalY = targetLabelY + Math.sin(perpAngle) * perpendicularOffset;
            interfaceLabels[1].setAttribute('transform', `translate(${targetFinalX}, ${targetFinalY}) rotate(${angleDegrees})`);
        }
        
        // Update center label (trunk/access at 50%)
        if (centerLabels.length >= 1) {
            const centerRatio = 0.5;
            const centerLabelX = sourcePos.x + dx * centerRatio;
            const centerLabelY = sourcePos.y + dy * centerRatio;
            const centerAboveX = centerLabelX + Math.cos(perpAngle) * perpendicularOffset;
            const centerAboveY = centerLabelY + Math.sin(perpAngle) * perpendicularOffset;
            centerLabels[0].setAttribute('transform', `translate(${centerAboveX}, ${centerAboveY}) rotate(${angleDegrees})`);
        }
    }

    getNodeCenter(node) {
        // Use data attributes for position, but also account for CSS transforms during drag
        let x = parseFloat(node.getAttribute('data-x')) || 0;
        let y = parseFloat(node.getAttribute('data-y')) || 0;
        
        // Check if the node has a CSS transform applied (during drag operations)
        const transform = node.style.transform;
        if (transform && transform.includes('translate')) {
            // Extract translate values from CSS transform
            const translateMatch = transform.match(/translate\(([^,]+)px,\s*([^)]+)px\)/);
            if (translateMatch) {
                x = parseFloat(translateMatch[1]) || x;
                y = parseFloat(translateMatch[2]) || y;
            }
        }
        
        return { x, y };
    }

    getConnectionPositions(sourcePos, targetPos, totalConnections, connectionIndex) {
        // Helper method to calculate connection positions (centered or offset)
        if (totalConnections <= 1) {
            return {
                source: { x: sourcePos.x, y: sourcePos.y },
                target: { x: targetPos.x, y: targetPos.y }
            };
        }
        
        const offset = this.calculateConnectionOffset(sourcePos, targetPos, totalConnections, connectionIndex);
        return {
            source: {
                x: sourcePos.x + offset.sourceOffset.x,
                y: sourcePos.y + offset.sourceOffset.y
            },
            target: {
                x: targetPos.x + offset.targetOffset.x,
                y: targetPos.y + offset.targetOffset.y
            }
        };
    }

    calculateConnectionOffset(sourcePos, targetPos, totalConnections, connectionIndex) {
        if (totalConnections <= 1) {
            return { sourceOffset: { x: 0, y: 0 }, targetOffset: { x: 0, y: 0 } };
        }
        
        // Calculate the perpendicular vector to the connection line
        const dx = targetPos.x - sourcePos.x;
        const dy = targetPos.y - sourcePos.y;
        const length = Math.sqrt(dx * dx + dy * dy);
        
        if (length === 0) {
            return { sourceOffset: { x: 0, y: 0 }, targetOffset: { x: 0, y: 0 } };
        }
        
        // Normalize the direction vector
        const unitX = dx / length;
        const unitY = dy / length;
        
        // Calculate perpendicular vector (90 degrees counterclockwise)
        const perpX = -unitY;
        const perpY = unitX;
        
        // Calculate offset distance based on number of connections
        const baseOffset = 10; // Increased base offset distance
        const offsetStep = 5; // Increased additional offset per connection
        const totalOffset = baseOffset + (totalConnections - 1) * offsetStep;
        
        // Calculate which side of the line this connection should be on
        const sideMultiplier = connectionIndex % 2 === 0 ? 1 : -1;
        const offsetDistance = Math.ceil(connectionIndex / 2) * totalOffset * sideMultiplier;
        
        return {
            sourceOffset: {
                x: perpX * offsetDistance,
                y: perpY * offsetDistance
            },
            targetOffset: {
                x: perpX * offsetDistance,
                y: perpY * offsetDistance
            }
        };
    }
}

class ConnectionRenderer {
    constructor(svg) {
        this.svg = svg;
        this.connectionsLayer = svg.querySelector('#connections-layer');
        this.managementMode = 'all'; // 'all', 'only', 'none'
    }

    setManagementMode(mode) {
        this.managementMode = mode;
    }

    isManagementConnection(connection) {
        // Use NetworkConstants for consistent management connection detection
        return NetworkConstants.isManagementConnection(connection);
    }

    getConnectionPositions(sourcePos, targetPos, totalConnections, connectionIndex) {
        // Helper method to calculate connection positions (centered or offset)
        if (totalConnections <= 1) {
            return {
                source: { x: sourcePos.x, y: sourcePos.y },
                target: { x: targetPos.x, y: targetPos.y }
            };
        }
        
        const offset = this.calculateConnectionOffset(sourcePos, targetPos, totalConnections, connectionIndex);
        return {
            source: {
                x: sourcePos.x + offset.sourceOffset.x,
                y: sourcePos.y + offset.sourceOffset.y
            },
            target: {
                x: targetPos.x + offset.targetOffset.x,
                y: targetPos.y + offset.targetOffset.y
            }
        };
    }

    renderConnections(connections) {
        // Clear existing connections
        this.clearConnections();

        console.log('Rendering connections:', connections);
        
        // Filter connections based on management mode
        const filteredConnections = connections.filter(connection => {
            const isManagement = this.isManagementConnection(connection);
            
            switch (this.managementMode) {
                case 'all':
                    return true; // Show all connections
                case 'only':
                    return isManagement; // Show only management connections
                case 'none':
                    return !isManagement; // Hide management connections
                default:
                    return true;
            }
        });
        
        const connectionGroups = this.groupConnectionsByPair(filteredConnections);
        connectionGroups.forEach(group => {
            this.createConnectionGroup(group);
        });
    }

    clearConnections() {
        if (this.connectionsLayer) {
            this.connectionsLayer.innerHTML = '';
        }
    }

    groupConnectionsByPair(connections) {
        const groups = new Map();
        
        connections.forEach(connection => {
            // Create a consistent key for source-target pairs (both directions)
            const key1 = `${connection.source}-${connection.target}`;
            const key2 = `${connection.target}-${connection.source}`;
            const key = groups.has(key1) ? key1 : (groups.has(key2) ? key2 : key1);
            
            if (!groups.has(key)) {
                groups.set(key, {
                    source: connection.source,
                    target: connection.target,
                    connections: []
                });
            }
            
            groups.get(key).connections.push(connection);
        });
        
        return Array.from(groups.values());
    }

    calculateConnectionOffset(sourcePos, targetPos, totalConnections, connectionIndex) {
        if (totalConnections <= 1) {
            return { sourceOffset: { x: 0, y: 0 }, targetOffset: { x: 0, y: 0 } };
        }
        
        // Calculate the perpendicular vector to the connection line
        const dx = targetPos.x - sourcePos.x;
        const dy = targetPos.y - sourcePos.y;
        const length = Math.sqrt(dx * dx + dy * dy);
        
        if (length === 0) {
            return { sourceOffset: { x: 0, y: 0 }, targetOffset: { x: 0, y: 0 } };
        }
        
        // Normalize the direction vector
        const unitX = dx / length;
        const unitY = dy / length;
        
        // Calculate perpendicular vector (90 degrees counterclockwise)
        const perpX = -unitY;
        const perpY = unitX;
        
        // Calculate offset distance based on number of connections
        const baseOffset = 10; // Increased base offset distance
        const offsetStep = 5; // Increased additional offset per connection
        const totalOffset = baseOffset + (totalConnections - 1) * offsetStep;
        
        // Calculate which side of the line this connection should be on
        const sideMultiplier = connectionIndex % 2 === 0 ? 1 : -1;
        const offsetDistance = Math.ceil(connectionIndex / 2) * totalOffset * sideMultiplier;
        
        return {
            sourceOffset: {
                x: perpX * offsetDistance,
                y: perpY * offsetDistance
            },
            targetOffset: {
                x: perpX * offsetDistance,
                y: perpY * offsetDistance
            }
        };
    }

    createConnectionGroup(group) {
        const sourceNode = this.svg.querySelector(`[data-device-id="${group.source}"]`);
        const targetNode = this.svg.querySelector(`[data-device-id="${group.target}"]`);
        
        if (!sourceNode || !targetNode) {
            console.warn(`Could not find nodes for connection group: ${group.source} -> ${group.target}`);
            return;
        }

        const sourcePos = this.getNodeCenter(sourceNode);
        const targetPos = this.getNodeCenter(targetNode);
        
        // Create main connection group
        const connectionGroup = document.createElementNS('http://www.w3.org/2000/svg', 'g');
        connectionGroup.setAttribute('class', 'connection-group');
        connectionGroup.setAttribute('data-source', group.source);
        connectionGroup.setAttribute('data-target', group.target);

        // Create all connections in this group
        group.connections.forEach((connection, index) => {
            this.createConnectionLineInGroup(connection, connectionGroup, sourcePos, targetPos, group.connections.length, index);
        });

        // Create connection label once per group (use the first connection for label info)
        if (group.connections.length > 0) {
            const label = this.createConnectionLabel(group.connections[0], sourcePos, targetPos);
            if (label) {
                connectionGroup.appendChild(label);
            }
        }

        this.connectionsLayer.appendChild(connectionGroup);
    }

    createConnectionLineInGroup(connection, connectionGroup, sourcePos, targetPos, totalConnections, connectionIndex) {
        const sourceNode = this.svg.querySelector(`[data-device-id="${connection.source}"]`);
        const targetNode = this.svg.querySelector(`[data-device-id="${connection.target}"]`);
        
        if (!sourceNode || !targetNode) {
            console.warn(`Could not find nodes for connection: ${connection.source} -> ${connection.target}`);
            return;
        }

        // Use the passed sourcePos and targetPos parameters instead of recalculating
        // const sourcePos = this.getNodeCenter(sourceNode);
        // const targetPos = this.getNodeCenter(targetNode);
        
        // Calculate offset for multiple connections
        const offset = this.calculateConnectionOffset(sourcePos, targetPos, totalConnections, connectionIndex);

        // Use the passed connectionGroup parameter instead of creating a new one
        connectionGroup.setAttribute('data-connection-id', connection.id || '');

        // Get connection positions (centered or offset)
        const positions = this.getConnectionPositions(sourcePos, targetPos, totalConnections, connectionIndex);
        const offsetSourcePos = positions.source;
        const offsetTargetPos = positions.target;

        // Create main connection line
        const line = document.createElementNS('http://www.w3.org/2000/svg', 'line');
        line.setAttribute('class', 'connection-line');
        line.setAttribute('data-source', connection.source);
        line.setAttribute('data-target', connection.target);
        line.setAttribute('x1', offsetSourcePos.x);
        line.setAttribute('y1', offsetSourcePos.y);
        line.setAttribute('x2', offsetTargetPos.x);
        line.setAttribute('y2', offsetTargetPos.y);
        line.setAttribute('stroke', this.getConnectionColor(connection));
        line.setAttribute('stroke-width', this.getConnectionWidth(connection));
        line.setAttribute('stroke-dasharray', this.getConnectionPattern(connection));
        line.setAttribute('opacity', this.getConnectionOpacity(connection));

        // Add title for tooltip
        const title = document.createElementNS('http://www.w3.org/2000/svg', 'title');
        title.textContent = this.buildConnectionTooltip(connection);
        line.appendChild(title);

        // Add hover effects
        line.addEventListener('mouseenter', () => {
            line.setAttribute('stroke-width', this.getConnectionWidth(connection) + 2);
            line.style.opacity = '0.9';
            line.style.cursor = 'pointer';
        });

        line.addEventListener('mouseleave', () => {
            line.setAttribute('stroke-width', this.getConnectionWidth(connection));
            line.style.opacity = this.getConnectionOpacity(connection);
        });

        // Add click handler for connection details
        line.addEventListener('click', (e) => {
            e.stopPropagation();
        });

        // Add VLAN indicators if trunk connection
        if (connection.trunk && connection.vlan) {
            const vlanIndicator = this.createVlanIndicator(connection, offsetSourcePos, offsetTargetPos);
            if (vlanIndicator) {
                connectionGroup.appendChild(vlanIndicator);
            }
        }

        connectionGroup.appendChild(line);
    }

    getNodeCenter(node) {
        // Use data attributes for position, but also account for CSS transforms during drag
        let x = parseFloat(node.getAttribute('data-x')) || 0;
        let y = parseFloat(node.getAttribute('data-y')) || 0;
        
        // Check if the node has a CSS transform applied (during drag operations)
        const transform = node.style.transform;
        if (transform && transform.includes('translate')) {
            // Extract translate values from CSS transform
            const translateMatch = transform.match(/translate\(([^,]+)px,\s*([^)]+)px\)/);
            if (translateMatch) {
                x = parseFloat(translateMatch[1]) || x;
                y = parseFloat(translateMatch[2]) || y;
            }
        }
        
        // Return center of the node (assuming 60x60 size as in the circle radius)
        return { x, y };
    }
    
    getConnectionColor(connection) {
        // Enhanced coloring based on connection status, type, VLAN, and cable properties
        // Priority order: Status > Cable Color > Trunk > VLAN > Interface Type > Cable Type
        
        // 1. Status-based coloring (highest priority)
        if (connection.status === 'disconnected' || connection.cable_status === 'disconnected') {
            return '#dc3545'; // Bootstrap danger red for disconnected
        }
        
        if (connection.status === 'discovering') {
            return '#fd7e14'; // Bootstrap warning orange for discovering
        }
        
        if (connection.status === 'planned') {
            return '#00000'; // Bootstrap secondary gray for planned
        }
        
        // 2. Use cable color if available and valid
        if (connection.cable_color && connection.cable_color !== 'Unknown' && connection.cable_color !== '') {
            // Validate that it's a proper color value
            if (connection.cable_color.match(/^#[0-9A-Fa-f]{6}$/) || 
                connection.cable_color.match(/^rgb\(/) || 
                connection.cable_color.match(/^hsl\(/)) {
                return connection.cable_color;
            }
        }
        
        // 3. Trunk connections get special coloring
        if (connection.trunk) {
            if (connection.native_vlan) {
                // Color based on native VLAN for trunk
                const vlanNum = parseInt(connection.native_vlan);
                if (vlanNum && vlanNum > 0) {
                    const hue = (vlanNum * 137.5) % 360;
                    return `hsl(${hue}, 75%, 55%)`;
                }
            }
            return '#e83e8c'; // Bootstrap pink for trunk connections
        }
        
        // 4. VLAN-based coloring
        if (connection.vlan && connection.vlan !== 'Unknown') {
            const vlanNum = parseInt(connection.vlan);
            if (vlanNum && vlanNum > 0) {
                const hue = (vlanNum * 137.5) % 360; // Golden angle for good distribution
                return `hsl(${hue}, 65%, 50%)`;
            }
        }
        
        // 5. Management connection coloring (high priority)
        if (this.isManagementConnection(connection)) {
            // Use different shades for management connections with VLANs
            const mgmtVlan = this.getManagementVlan(connection);
            if (mgmtVlan) {
                const vlanNum = parseInt(mgmtVlan);
                if (vlanNum && vlanNum > 1) {
                    // Use purple-blue spectrum for management VLANs (better visibility)
                    const hue = 260 + (vlanNum * 8) % 40; // Purple to blue range (260-300 degrees)
                    return `hsl(${hue}, 75%, 50%)`;
                }
            }
            return '#6f42c1'; // Bootstrap purple for management connections (better visibility)
        }
        
        // 6. Interface type based coloring
        if (connection.interface_type) {
            const typeColorMap = {
                'ethernet': '#0d6efd',        // Bootstrap primary blue
                'gigabitethernet': '#0d6efd', // Bootstrap primary blue
                'fastethernet': '#6f42c1',    // Bootstrap purple
                'tengigabitethernet': '#0dcaf0', // Bootstrap info cyan
                'fiber': '#fd7e14',           // Bootstrap warning orange
                'serial': '#000',          // Bootstrap secondary gray
                'loopback': '#198754',        // Bootstrap success green
                'vlan': '#ffc107',            // Bootstrap warning yellow
                'port-channel': '#dc3545'     // Bootstrap danger red
            };
            const baseType = connection.interface_type.toLowerCase().replace(/[0-9]/g, '');
            if (typeColorMap[baseType]) {
                return typeColorMap[baseType];
            }
        }
        
        // 7. Cable type based coloring (lowest priority)
        const colorMap = {
            'cat5': '#6c757d',    // Bootstrap secondary gray
            'cat5e': '#6c757d',   // Bootstrap secondary gray
            'cat6': '#0d6efd',    // Bootstrap primary blue
            'cat6a': '#0d6efd',   // Bootstrap primary blue
            'cat7': '#6f42c1',    // Bootstrap purple
            'fiber': '#fd7e14',   // Bootstrap warning orange
            'fiber-optic': '#fd7e14', // Bootstrap warning orange
            'dac': '#e83e8c',     // Bootstrap pink
            'twinax': '#e83e8c',  // Bootstrap pink
            'discovered': '#198754', // Bootstrap success green
            'unknown': '#6c757d'  // Bootstrap secondary gray
        };
        
        return colorMap[connection.cable_type] || '#495057';
    }

    getConnectionWidth(connection) {
        // Width based on connection status and importance
        if (connection.status === 'disconnected' || connection.cable_status === 'disconnected') {
            return 1; // Very thin for disconnected
        }
        
        if (connection.status === 'discovering') {
            return 2; // Medium width for discovering
        }
        
        if (connection.status === 'planned') {
            return 1.5; // Slightly thicker for planned
        }
        
        // Management connections get special width
        if (this.isManagementConnection(connection)) {
            return 2.5; // Medium-thick for management connections
        }
        
        // Trunk connections are important, make them thicker
        if (connection.trunk) {
            return 4; // Thick for trunk connections
        }
        
        // Width based on speed (if available)
        if (connection.speed && connection.speed !== 'Unknown') {
            const speed = parseInt(connection.speed);
            if (speed >= 100000) return 5; // 100G+
            if (speed >= 40000) return 4;  // 40G
            if (speed >= 10000) return 3;  // 10G
            if (speed >= 1000) return 2.5; // 1G
            if (speed >= 100) return 2;    // 100M
            return 1.5; // 10M or unknown
        }
        
        // Width based on interface type
        if (connection.interface_type) {
            const typeWidthMap = {
                'tengigabitethernet': 3.5,
                'gigabitethernet': 2.5,
                'fastethernet': 2,
                'ethernet': 2,
                'fiber': 3,
                'serial': 1.5,
                'loopback': 1,
                'vlan': 2,
                'port-channel': 3
            };
            const baseType = connection.interface_type.toLowerCase().replace(/[0-9]/g, '');
            if (typeWidthMap[baseType]) {
                return typeWidthMap[baseType];
            }
        }
        
        // Width based on cable type
        if (connection.cable_type) {
            const cableWidthMap = {
                'cat5': 1.5,
                'cat5e': 2,
                'cat6': 2.5,
                'cat6a': 2.5,
                'cat7': 3,
                'fiber': 3,
                'fiber-optic': 3,
                'dac': 2.5,
                'twinax': 2.5,
                'discovered': 2,
                'unknown': 1.5
            };
            if (cableWidthMap[connection.cable_type]) {
                return cableWidthMap[connection.cable_type];
            }
        }
        
        return 2; // Default width
    }

    getConnectionOpacity(connection) {
        if (connection.status === 'disconnected') {
            return 0.5; // Semi-transparent for disconnected
        }
        
        if (connection.status === 'active') {
            return 0.8; // Slightly transparent for active
        }
        
        return 1.0; // Fully opaque
    }

    getConnectionPattern(connection) {
        // Pattern based on connection status (highest priority)
        if (connection.status === 'disconnected' || connection.cable_status === 'disconnected') {
            return '8,4'; // Long dashes for disconnected
        }
        
        if (connection.status === 'discovering') {
            return '4,4'; // Medium dashes for discovering
        }
        
        if (connection.status === 'planned') {
            return '2,6'; // Short dashes for planned
        }
        
        // Pattern based on management status (highest priority after disconnected/discovering)
        if (this.isManagementConnection(connection)) {
            return '6,2,2,2'; // Dash-dot pattern for management
        }
        
        // Pattern based on trunk status
        if (connection.trunk) {
            return '12,3'; // Very long dashes for trunk
        }
        
        // Pattern based on cable type
        const cableType = connection.cable_type || connection.connection_type || 'unknown';
        const patternMap = {
            'cat5': '6,3',
            'cat5e': '6,3',
            'cat6': '4,2',
            'cat6a': '4,2',
            'cat7': '2,1',
            'fiber': '10,5',
            'fiber-optic': '10,5',
            'dac': '3,2',
            'twinax': '3,2',
            'discovered': '4,4',
            'ethernet': '4,2',
            'serial': '2,8',
            'loopback': '1,1',
            'unknown': '4,2'
        };
        
        return patternMap[cableType] || '4,2';
    }

    buildConnectionTooltip(connection) {
        // Get enhanced interface information
        const sourceInterfaces = this.getConnectedInterfacesForDevice(connection.source);
        const targetInterfaces = this.getConnectedInterfacesForDevice(connection.target);
        const sourceInterface = this.findMatchingInterface(connection.source_interface, sourceInterfaces);
        const targetInterface = this.findMatchingInterface(connection.target_interface, targetInterfaces);
        
        // Use enhanced interface data if available
        const sourceName = sourceInterface?.name || connection.source_interface || 'Unknown';
        const targetName = targetInterface?.name || connection.target_interface || 'Unknown';
        
        // Determine connection type using NetworkConstants
        const connectionType = NetworkConstants.determineConnectionType(connection, sourceInterface, targetInterface);
        
        let tooltip = `Connection: ${sourceName} ↔ ${targetName}`;
        
        // Connection type information
        switch (connectionType) {
            case NetworkConstants.CONNECTION_TYPES.MANAGEMENT:
                tooltip += `\n\nConnection Type: Management`;
                const mgmtVlan = this.getManagementVlan(connection, sourceInterface, targetInterface);
                if (mgmtVlan) {
                    tooltip += `\nManagement VLAN: ${mgmtVlan}`;
                }
                break;
            case NetworkConstants.CONNECTION_TYPES.TRUNK:
                tooltip += `\n\nConnection Type: Trunk`;
                const trunkVlan = this.getTrunkVlan(connection, sourceInterface, targetInterface);
                if (trunkVlan) {
                    tooltip += `\nNative VLAN: ${trunkVlan}`;
                }
                break;
            case NetworkConstants.CONNECTION_TYPES.LAYER3:
                tooltip += `\n\nConnection Type: Layer 3 (Routed)`;
                const subnet = connection.subnet || connection.network;
                if (subnet) {
                    tooltip += `\nSubnet: ${subnet}`;
                }
                // Add IP addresses if available
                const sourceIP = sourceInterface?.ip_address || connection.source_ip;
                const targetIP = targetInterface?.ip_address || connection.target_ip;
                if (sourceIP) {
                    tooltip += `\nSource IP: ${sourceIP}`;
                }
                if (targetIP) {
                    tooltip += `\nTarget IP: ${targetIP}`;
                }
                break;
            case NetworkConstants.CONNECTION_TYPES.POINT_TO_POINT:
                tooltip += `\n\nConnection Type: Point-to-Point (Router Link)`;
                break;
            case NetworkConstants.CONNECTION_TYPES.ACCESS:
                tooltip += `\n\nConnection Type: Access Port`;
                const accessVlan = connection.vlan || connection.access_vlan;
                if (accessVlan && accessVlan !== '1') {
                    tooltip += `\nAccess VLAN: ${accessVlan}`;
                }
                break;
            default:
                tooltip += `\n\nConnection Type: Network Link`;
        }
        
        // Enhanced interface information
        if (sourceInterface) {
            tooltip += `\n\nSource Interface:`;
            tooltip += `\n  Name: ${sourceInterface.name}`;
            tooltip += `\n  Status: ${sourceInterface.status}/${sourceInterface.protocol}`;
            if (sourceInterface.ip_address) {
                tooltip += `\n  IP: ${sourceInterface.ip_address}${sourceInterface.subnet_mask ? '/' + sourceInterface.subnet_mask : ''}`;
            }
            if (sourceInterface.speed) {
                tooltip += `\n  Speed: ${sourceInterface.speed} Mbps`;
            }
            if (sourceInterface.duplex !== 'unknown') {
                tooltip += `\n  Duplex: ${sourceInterface.duplex}`;
            }
            if (sourceInterface.description) {
                tooltip += `\n  Description: ${sourceInterface.description}`;
            }
        }
        
        if (targetInterface) {
            tooltip += `\n\nTarget Interface:`;
            tooltip += `\n  Name: ${targetInterface.name}`;
            tooltip += `\n  Status: ${targetInterface.status}/${targetInterface.protocol}`;
            if (targetInterface.ip_address) {
                tooltip += `\n  IP: ${targetInterface.ip_address}${targetInterface.subnet_mask ? '/' + targetInterface.subnet_mask : ''}`;
            }
            if (targetInterface.speed) {
                tooltip += `\n  Speed: ${targetInterface.speed} Mbps`;
            }
            if (targetInterface.duplex !== 'unknown') {
                tooltip += `\n  Duplex: ${targetInterface.duplex}`;
            }
            if (targetInterface.description) {
                tooltip += `\n  Description: ${targetInterface.description}`;
            }
        }
        
        // Discovery information
        if (connection.discovery_method) {
            tooltip += `\n\nDiscovery Method: ${connection.discovery_method.toUpperCase()}`;
        }
        
        // Connection properties from neighbor data
        if (connection.duplex) {
            tooltip += `\nDuplex: ${NetworkUtils.getDuplexStatus(connection)}`;
        }
        
        if (connection.platform) {
            tooltip += `\nRemote Platform: ${connection.platform}`;
        }
        
        if (connection.capabilities && connection.capabilities.length > 0) {
            tooltip += `\nCapabilities: ${connection.capabilities.join(', ')}`;
        }
        
        // VLAN information
        if (connection.vlan_id) {
            tooltip += `\nVLAN ID: ${connection.vlan_id}`;
        }
        
        if (connection.native_vlan) {
            tooltip += `\nNative VLAN: ${connection.native_vlan}`;
        }
        
        if (connection.allowed_vlans && connection.allowed_vlans.length > 0) {
            tooltip += `\nAllowed VLANs: ${connection.allowed_vlans.join(', ')}`;
        }
        
        // Additional network information
        if (connection.software_version) {
            tooltip += `\nSoftware Version: ${connection.software_version}`;
        }
        
        return tooltip;
    }

    createConnectionLabel(connection, sourcePos, targetPos) {
        // Always show labels for all connections - remove zoom level restriction
        const zoomLevel = this.getCurrentZoomLevel();
        
        const labelGroup = document.createElementNS('http://www.w3.org/2000/svg', 'g');
        labelGroup.setAttribute('class', 'connection-label-group');
        
        // Calculate connection angle and distance
        const dx = targetPos.x - sourcePos.x;
        const dy = targetPos.y - sourcePos.y;
        const distance = Math.sqrt(dx * dx + dy * dy);
        const angle = Math.atan2(dy, dx);
        
        // Calculate perpendicular angle for offsets
        const perpAngle = angle + Math.PI / 2; // 90 degrees perpendicular
        
        // Get enhanced interface information from devices
        const sourceDevice = this.getDeviceById(connection.source);
        const targetDevice = this.getDeviceById(connection.target);
        
        // Helper function to get interface name - keep original name without truncation
        const getInterfaceName = (interfaceName) => {
            if (!interfaceName || interfaceName === 'Unknown') return null;
            return interfaceName; // Return the original interface name as-is
        };
        
        // Get enhanced interface information from devices using the new interface data
        const sourceInterfaces = this.getConnectedInterfacesForDevice(connection.source);
        const targetInterfaces = this.getConnectedInterfacesForDevice(connection.target);
        
        // Try to match interfaces based on connection data or infer from connected interfaces
        let sourceInterface = this.findMatchingInterface(connection.source_interface, sourceInterfaces);
        let targetInterface = this.findMatchingInterface(connection.target_interface, targetInterfaces);
        
        // Enhanced interface matching using device details API data
        if (!sourceInterface && sourceDevice && sourceDevice.connected_interfaces) {
            // Use the enhanced interface data from device details API
            sourceInterface = sourceDevice.connected_interfaces.find(iface => 
                iface.name === connection.source_interface || 
                iface.short_name === connection.source_interface ||
                iface.display_name === connection.source_interface
            ) || sourceDevice.connected_interfaces[0];
        }
        
        if (!targetInterface && targetDevice && targetDevice.connected_interfaces) {
            // Use the enhanced interface data from device details API
            targetInterface = targetDevice.connected_interfaces.find(iface => 
                iface.name === connection.target_interface || 
                iface.short_name === connection.target_interface ||
                iface.display_name === connection.target_interface
            ) || targetDevice.connected_interfaces[0];
        }
        
        // Fallback to first connected interface if still not found
        if (!sourceInterface && sourceInterfaces.length > 0) {
            sourceInterface = sourceInterfaces[0];
        }
        
        if (!targetInterface && targetInterfaces.length > 0) {
            targetInterface = targetInterfaces[0];
        }
        
        // Determine if this is a trunk connection based on interface data
        const isTrunkConnection = this.isTrunkConnection(connection, sourceInterface, targetInterface);
        const trunkVlan = this.getTrunkVlan(connection, sourceInterface, targetInterface);
        
        // Get interface names
        let sourceName = null;
        let targetName = null;
        
        if (sourceInterface) {
            sourceName = getInterfaceName(sourceInterface.name) || 
                        sourceInterface.name || 
                        sourceInterface.display_name;
        } else if (connection.source_interface) {
            sourceName = getInterfaceName(connection.source_interface);
        }
        
        if (targetInterface) {
            targetName = getInterfaceName(targetInterface.name) || 
                        targetInterface.name || 
                        targetInterface.display_name;
        } else if (connection.target_interface) {
            targetName = getInterfaceName(connection.target_interface);
        }
        
        // Create labels:
        // 1. Source interface name near source device (15% along the line)
        // 2. Target interface name near target device (85% along the line)
        // 3. Trunk/Access label in the center (50% along the line)
        
        const perpendicularOffset = 12;
        
        // Position 1: Source interface label (25% from source - moved further from node)
        if (sourceName) {
            const sourceRatio = 0.25;
            const sourceLabelX = sourcePos.x + dx * sourceRatio;
            const sourceLabelY = sourcePos.y + dy * sourceRatio;
            const sourceFinalX = sourceLabelX + Math.cos(perpAngle) * perpendicularOffset;
            const sourceFinalY = sourceLabelY + Math.sin(perpAngle) * perpendicularOffset;
            
            const sourceLabel = this.createInterfaceLabel(
                sourceName,
                sourceFinalX,
                sourceFinalY,
                angle,
                zoomLevel,
                connection
            );
            labelGroup.appendChild(sourceLabel);
        }
        
        // Position 2: Target interface label (75% from source, i.e., 25% from target - moved further from node)
        if (targetName) {
            const targetRatio = 0.75;
            const targetLabelX = sourcePos.x + dx * targetRatio;
            const targetLabelY = sourcePos.y + dy * targetRatio;
            const targetFinalX = targetLabelX + Math.cos(perpAngle) * perpendicularOffset;
            const targetFinalY = targetLabelY + Math.sin(perpAngle) * perpendicularOffset;
            
            const targetLabel = this.createInterfaceLabel(
                targetName,
                targetFinalX,
                targetFinalY,
                angle,
                zoomLevel,
                connection
            );
            labelGroup.appendChild(targetLabel);
        }
        
        // Position 3: Connection type label in the center (50% along the line)
        let connectionType;
        
        // Use NetworkConstants to determine proper connection type
        const detectedType = NetworkConstants.determineConnectionType(connection, sourceInterface, targetInterface);
        
        switch (detectedType) {
            case NetworkConstants.CONNECTION_TYPES.MANAGEMENT:
                const mgmtVlan = this.getManagementVlan(connection, sourceInterface, targetInterface);
                connectionType = mgmtVlan ? `MGMT-${mgmtVlan}` : 'MGMT';
                break;
            case NetworkConstants.CONNECTION_TYPES.TRUNK:
                const trunkVlan = this.getTrunkVlan(connection, sourceInterface, targetInterface);
                connectionType = trunkVlan ? `TRUNK-${trunkVlan}` : 'TRUNK';
                break;
            case NetworkConstants.CONNECTION_TYPES.LAYER3:
                // For router-to-router L3 connections, show L3 with subnet if available
                const subnet = connection.subnet || connection.network;
                connectionType = subnet ? `L3-${subnet}` : 'L3';
                break;
            case NetworkConstants.CONNECTION_TYPES.POINT_TO_POINT:
                // For legacy P2P connections, show P2P
                connectionType = 'P2P';
                break;
            case NetworkConstants.CONNECTION_TYPES.ACCESS:
                // Only show ACCESS for actual switch access ports
                const vlan = connection.vlan || connection.access_vlan;
                connectionType = vlan && vlan !== '1' ? `VLAN-${vlan}` : 'ACCESS';
                break;
            default:
                connectionType = 'LINK';
        }
        
        const centerRatio = 0.5;
        const centerLabelX = sourcePos.x + dx * centerRatio;
        const centerLabelY = sourcePos.y + dy * centerRatio;
        
        // Position above the line
        const centerAboveX = centerLabelX + Math.cos(perpAngle) * perpendicularOffset;
        const centerAboveY = centerLabelY + Math.sin(perpAngle) * perpendicularOffset;
        
        const centerLabel = this.createCenterLabel(
            connectionType,
            centerAboveX,
            centerAboveY,
            angle,
            zoomLevel,
            connection,
            detectedType === NetworkConstants.CONNECTION_TYPES.TRUNK,
            detectedType === NetworkConstants.CONNECTION_TYPES.MANAGEMENT,
            detectedType === NetworkConstants.CONNECTION_TYPES.LAYER3
        );
        labelGroup.appendChild(centerLabel);
        
        return labelGroup;
    }

    createInterfaceLabel(text, x, y, angle, zoomLevel, connection) {
        const labelGroup = document.createElementNS('http://www.w3.org/2000/svg', 'g');
        labelGroup.setAttribute('class', 'floating-label interface-label');
        
        // Convert angle to degrees for SVG rotation
        let angleDegrees = (angle * 180) / Math.PI;
        
        // Ensure text is always readable (not upside down)
        if (angleDegrees > 90 || angleDegrees < -90) {
            angleDegrees += 180;
        }
        
        // Get connection color for text - use enhanced colors for management
        let labelColor = this.getConnectionColor(connection);
        
        // Use primary/secondary color derivatives for management labels
        if (this.isManagementConnection(connection)) {
            labelColor = '#495057'; // Bootstrap secondary dark for better readability
        }
        
        // Create label text
        const textElement = document.createElementNS('http://www.w3.org/2000/svg', 'text');
        textElement.setAttribute('x', '0');
        textElement.setAttribute('y', '4');
        textElement.setAttribute('text-anchor', 'middle');
        textElement.setAttribute('font-size', zoomLevel >= 1.0 ? '20' : '18');
        textElement.setAttribute('font-family', 'Segoe UI, Arial, sans-serif');
        textElement.setAttribute('fill', labelColor);
        textElement.setAttribute('font-weight', '600');
        textElement.setAttribute('stroke', 'white');
        textElement.setAttribute('stroke-width', '2');
        textElement.setAttribute('paint-order', 'stroke fill');
        textElement.textContent = text;
        
        // Apply transform to position and rotate the label
        labelGroup.setAttribute('transform', `translate(${x}, ${y}) rotate(${angleDegrees})`);
        labelGroup.appendChild(textElement);
        
        return labelGroup;
    }

    createCenterLabel(text, x, y, angle, zoomLevel, connection, isTrunk, isManagement = false, isL3 = false) {
        const labelGroup = document.createElementNS('http://www.w3.org/2000/svg', 'g');
        labelGroup.setAttribute('class', 'floating-label center-label');
        
        // Convert angle to degrees for SVG rotation
        let angleDegrees = (angle * 180) / Math.PI;
        
        // Ensure text is always readable (not upside down)
        if (angleDegrees > 90 || angleDegrees < -90) {
            angleDegrees += 180;
        }
        
        // Create background rectangle for better visibility
        const bgRect = document.createElementNS('http://www.w3.org/2000/svg', 'rect');
        const textWidth = text.length * 5 + 8;
        const textHeight = 14;
        bgRect.setAttribute('x', -textWidth);
        bgRect.setAttribute('y', -textHeight);
        bgRect.setAttribute('width', textWidth * 2);
        bgRect.setAttribute('height', textHeight * 2);
        bgRect.setAttribute('rx', '3');
        
        // Set color based on connection type
        let bgColor;
        if (isManagement) {
            bgColor = '#6f42c1'; // Bootstrap purple for management (better visibility)
        } else if (isTrunk) {
            bgColor = '#e83e8c'; // Pink for trunk
        } else if (isL3) {
            bgColor = '#007bff'; // Blue for L3/routed connections
        } else {
            bgColor = '#28a745'; // Green for access
        }
        
        bgRect.setAttribute('fill', bgColor);
        bgRect.setAttribute('opacity', '0.9');
        
        // Create label text
        const textElement = document.createElementNS('http://www.w3.org/2000/svg', 'text');
        textElement.setAttribute('x', '0');
        textElement.setAttribute('y', '3');
        textElement.setAttribute('text-anchor', 'middle');
        textElement.setAttribute('font-size', zoomLevel >= 1.0 ? '9' : '8');
        textElement.setAttribute('font-family', 'Segoe UI, Arial, sans-serif');
        textElement.setAttribute('fill', 'white');
        textElement.setAttribute('font-weight', 'bold');
        textElement.textContent = text;
        
        // Apply transform to position and rotate the label
        labelGroup.setAttribute('transform', `translate(${x}, ${y}) rotate(${angleDegrees})`);
        labelGroup.appendChild(bgRect);
        labelGroup.appendChild(textElement);
        
        return labelGroup;
    }

    calculateOptimalLabelPositions(sourcePos, targetPos, distance) {
        const positions = [];
        
        // Calculate multiple potential positions along the connection line
        const positions_along_line = [
            { ratio: 0.3, offset: 0 }, // 1/3 along line, no perpendicular offset for inline
            { ratio: 0.5, offset: 0 },  // midpoint, no perpendicular offset for inline
            { ratio: 0.7, offset: 0 }, // 2/3 along line, no perpendicular offset for inline
        ];
        
        const angle = Math.atan2(targetPos.y - sourcePos.y, targetPos.x - sourcePos.x);
        
        positions_along_line.forEach(({ ratio, offset }) => {
            // Position along the line
            const lineX = sourcePos.x + (targetPos.x - sourcePos.x) * ratio;
            const lineY = sourcePos.y + (targetPos.y - sourcePos.y) * ratio;
            
            positions.push(
                { x: lineX, y: lineY, priority: ratio === 0.5 ? 1 : 2 }
            );
        });
        
        // Sort by priority (midpoint first, then others)
        return positions.sort((a, b) => a.priority - b.priority);
    }

    isPositionOverlappingDevice(x, y) {
        // Check if the position overlaps with any device
        const deviceRadius = 35; // Device circle radius + margin
        
        if (this.devices) {
            return this.devices.some(device => {
                const deviceElement = document.querySelector(`[data-device-id="${device.id}"]`);
                if (deviceElement) {
                    const deviceX = parseFloat(deviceElement.getAttribute('data-x')) || 0;
                    const deviceY = parseFloat(deviceElement.getAttribute('data-y')) || 0;
                    const distance = Math.sqrt((x - deviceX) ** 2 + (y - deviceY) ** 2);
                    return distance < deviceRadius;
                }
                return false;
            });
        }
        return false;
    }

    createFloatingLabel(text, x, y, angle, width, height, zoomLevel, connection) {
        const labelGroup = document.createElementNS('http://www.w3.org/2000/svg', 'g');
        
        // Add CSS class for styling - this will be the floating-label that gets updated
        labelGroup.setAttribute('class', 'floating-label connection-line-label inline-label');
        
        // Convert angle to degrees for SVG rotation
        let angleDegrees = (angle * 180) / Math.PI;
        
        // Ensure text is always readable (not upside down)
        // If the angle would make text appear upside down, flip it 180 degrees
        if (angleDegrees > 90 || angleDegrees < -90) {
            angleDegrees += 180;
        }
        
        // Get connection color for text - use enhanced colors for management
        let labelColor = this.getConnectionColor(connection);
        
        // Use primary/secondary color derivatives for management labels
        if (this.isManagementConnection(connection)) {
            labelColor = '#495057'; // Bootstrap secondary dark for better readability
        }
        
        // Create inline label with dashes on both sides
        const dashLength = Math.max(8, text.length * 3); // Dynamic dash length based on text
        const totalWidth = dashLength * 2 + text.length * 6; // Total width for dashes + text
        
        // // Create left dashes
        // const leftDashes = document.createElementNS('http://www.w3.org/2000/svg', 'line');
        // leftDashes.setAttribute('x1', -totalWidth / 2);
        // leftDashes.setAttribute('y1', '0');
        // leftDashes.setAttribute('x2', -totalWidth / 2 + dashLength);
        // leftDashes.setAttribute('y2', '0');
        // leftDashes.setAttribute('stroke', connectionColor);
        // leftDashes.setAttribute('stroke-width', '2');
        // leftDashes.setAttribute('stroke-dasharray', '3,2');
        
        // // Create right dashes
        // const rightDashes = document.createElementNS('http://www.w3.org/2000/svg', 'line');
        // rightDashes.setAttribute('x1', totalWidth / 2 - dashLength);
        // rightDashes.setAttribute('y1', '0');
        // rightDashes.setAttribute('x2', totalWidth / 2);
        // rightDashes.setAttribute('y2', '0');
        // rightDashes.setAttribute('stroke', connectionColor);
        // rightDashes.setAttribute('stroke-width', '2');
        // rightDashes.setAttribute('stroke-dasharray', '3,2');
        
        // Create label text with enhanced readability
        const textElement = document.createElementNS('http://www.w3.org/2000/svg', 'text');
        textElement.setAttribute('x', '0');
        textElement.setAttribute('y', '4');
        textElement.setAttribute('text-anchor', 'middle');
        textElement.setAttribute('font-size', zoomLevel >= 1.0 ? '10' : '9');
        textElement.setAttribute('font-family', 'Segoe UI, Arial, sans-serif');
        textElement.setAttribute('fill', labelColor);
        textElement.setAttribute('font-weight', 'bold');
        textElement.setAttribute('stroke', 'white');
        textElement.setAttribute('stroke-width', '1');
        textElement.setAttribute('paint-order', 'stroke fill');
        textElement.setAttribute('letter-spacing', '0.5px');
        textElement.textContent = text;
        
        // Apply transform to position and rotate the label
        labelGroup.setAttribute('transform', `translate(${x}, ${y}) rotate(${angleDegrees})`);
        
        // labelGroup.appendChild(leftDashes);
        labelGroup.appendChild(textElement);
        // labelGroup.appendChild(rightDashes);
        
        return labelGroup;
    }

    createVlanIndicator(connection, sourcePos, targetPos) {
        if (!connection.vlan && !connection.trunk) return null;
        
        const midX = (sourcePos.x + targetPos.x) / 2;
        const midY = (sourcePos.y + targetPos.y) / 2;
        
        const group = document.createElementNS('http://www.w3.org/2000/svg', 'g');
        group.setAttribute('class', 'vlan-indicator-group');
        
        // Create VLAN indicator circle
        const circle = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
        circle.setAttribute('cx', midX);
        circle.setAttribute('cy', midY - 20);
        circle.setAttribute('r', '10');
        circle.setAttribute('fill', this.getConnectionColor(connection));
        circle.setAttribute('stroke', '#fff');
        circle.setAttribute('stroke-width', '2');
        
        // Create VLAN number text
        const text = document.createElementNS('http://www.w3.org/2000/svg', 'text');
        text.setAttribute('x', midX);
        text.setAttribute('y', midY - 15);
        text.setAttribute('text-anchor', 'middle');
        text.setAttribute('font-size', '8');
        text.setAttribute('fill', '#fff');
        text.setAttribute('font-weight', 'bold');
        
        let vlanText = '';
        if (connection.trunk && connection.native_vlan) {
            vlanText = `T${connection.native_vlan}`;
        } else if (connection.vlan) {
            vlanText = connection.vlan;
        }
        
        text.textContent = vlanText;
        
        group.appendChild(circle);
        group.appendChild(text);
        
        // Add trunk indicator if it's a trunk connection
        if (connection.trunk) {
            const trunkIndicator = document.createElementNS('http://www.w3.org/2000/svg', 'rect');
            trunkIndicator.setAttribute('x', midX - 12);
            trunkIndicator.setAttribute('y', midY - 32);
            trunkIndicator.setAttribute('width', '24');
            trunkIndicator.setAttribute('height', '6');
            trunkIndicator.setAttribute('fill', '#ff6600');
            trunkIndicator.setAttribute('stroke', '#fff');
            trunkIndicator.setAttribute('stroke-width', '1');
            trunkIndicator.setAttribute('rx', '2');
            
            const trunkText = document.createElementNS('http://www.w3.org/2000/svg', 'text');
            trunkText.setAttribute('x', midX);
            trunkText.setAttribute('y', midY - 28);
            trunkText.setAttribute('text-anchor', 'middle');
            trunkText.setAttribute('font-size', '6');
            trunkText.setAttribute('fill', '#fff');
            trunkText.setAttribute('font-weight', 'bold');
            trunkText.textContent = 'TRUNK';
            
            group.appendChild(trunkIndicator);
            group.appendChild(trunkText);
        }
        
        return group;
    }

    getCurrentZoomLevel() {
        // Get current zoom level from the SVG transform
        const transform = this.svg.style.transform;
        if (transform) {
            const scaleMatch = transform.match(/scale\(([^)]+)\)/);
            if (scaleMatch) {
                return parseFloat(scaleMatch[1]);
            }
        }
        return 1;
    }

    getDeviceById(deviceId) {
        // This method needs to be called from the TopologyViewer instance
        // We'll need to pass the devices array to the ConnectionRenderer
        if (this.devices) {
            return this.devices.find(device => device.id === deviceId);
        }
        return null;
    }

    setDevices(devices) {
        this.devices = devices;
    }

    getConnectedInterfacesForDevice(deviceId) {
        const device = this.getDeviceById(deviceId);
        if (device && device.connected_interfaces) {
            return device.connected_interfaces;
        }
        return [];
    }

    findMatchingInterface(interfaceName, connectedInterfaces) {
        if (!interfaceName || !connectedInterfaces.length) return null;
        
        // Try exact match first
        let match = connectedInterfaces.find(iface => 
            iface.name === interfaceName || 
            iface.name.toLowerCase() === interfaceName.toLowerCase()
        );
        
        if (match) return match;
        
        // Try partial match for interface names
        const normalizedName = interfaceName.toLowerCase().replace(/[^a-z0-9]/g, '');
        match = connectedInterfaces.find(iface => {
            const normalizedIfaceName = iface.name.toLowerCase().replace(/[^a-z0-9]/g, '');
            return normalizedIfaceName.includes(normalizedName) || 
                   normalizedName.includes(normalizedIfaceName);
        });
        
        if (match) return match;
        
        // Try to match by extracting slot/port numbers
        const slotPortMatch = interfaceName.match(/(\d+(?:\/\d+)*)/);
        if (slotPortMatch) {
            const slotPort = slotPortMatch[1];
            match = connectedInterfaces.find(iface => {
                const ifaceSlotPortMatch = iface.name.match(/(\d+(?:\/\d+)*)/);
                return ifaceSlotPortMatch && ifaceSlotPortMatch[1] === slotPort;
            });
            
            if (match) return match;
        }
        
        // Try to match by interface type (e.g., GigabitEthernet, FastEthernet, etc.)
        const interfaceTypeMatch = interfaceName.match(/^(GigabitEthernet|FastEthernet|TenGigabitEthernet|Ethernet|Serial|Loopback|Vlan|Port-channel|Gi|Fa|Te|Eth|Se|Lo|Vl|Po)/i);
        if (interfaceTypeMatch) {
            const interfaceType = interfaceTypeMatch[1];
            match = connectedInterfaces.find(iface => {
                const ifaceTypeMatch = iface.name.match(/^(GigabitEthernet|FastEthernet|TenGigabitEthernet|Ethernet|Serial|Loopback|Vlan|Port-channel|Gi|Fa|Te|Eth|Se|Lo|Vl|Po)/i);
                return ifaceTypeMatch && ifaceTypeMatch[1].toLowerCase() === interfaceType.toLowerCase();
            });
            
            if (match) return match;
        }
        
        return null;
    }

    isTrunkConnection(connection, sourceInterface, targetInterface) {
        // Use NetworkConstants for consistent trunk detection
        return NetworkConstants.isTrunkConnection(connection, sourceInterface, targetInterface);
    }

    getTrunkVlan(connection, sourceInterface, targetInterface) {
        // Check connection data first
        if (connection.native_vlan) return connection.native_vlan;
        if (connection.vlan && connection.vlan !== 'Unknown') return connection.vlan;
        
        // Check interface data
        if (sourceInterface && sourceInterface.vlan) return sourceInterface.vlan;
        if (targetInterface && targetInterface.vlan) return targetInterface.vlan;
        
        return null;
    }

    getManagementVlan(connection, sourceInterface, targetInterface) {
        // Get VLAN for management connections
        if (connection.mgmt_vlan) return connection.mgmt_vlan;
        if (connection.vlan && connection.vlan !== 'Unknown' && connection.vlan !== '1') return connection.vlan;
        
        // Check interface data for management VLAN
        if (sourceInterface && sourceInterface.vlan && sourceInterface.vlan !== '1') return sourceInterface.vlan;
        if (targetInterface && targetInterface.vlan && targetInterface.vlan !== '1') return targetInterface.vlan;
        
        // Extract VLAN from description if available
        const description = connection.description || '';
        const vlanMatch = description.match(/vlan[\s-]*([0-9]+)/i);
        if (vlanMatch && vlanMatch[1] !== '1') return vlanMatch[1];
        
        return null;
    }
}

class AutoLayout {
    constructor(svg) {
        this.svg = svg;
    }

    applyLayout(devices, connections, algorithm = 'force', skipLayerIndicators = false) {
        switch (algorithm) {
            case 'force':
                return this.forceDirectedLayout(devices, connections);
            case 'grid':
                return this.gridLayout(devices);
            case 'hierarchical':
                return this.hierarchicalLayout(devices, connections, skipLayerIndicators);
            default:
                return this.forceDirectedLayout(devices, connections);
        }
    }

    forceDirectedLayout(devices, connections) {
        const positions = new Map();
        // Use SVG viewBox dimensions for layout space
        const viewBox = this.svg.getAttribute('viewBox');
        let width = 2000, height = 1500; // Default fallback
        if (viewBox) {
            const [, , vbWidth, vbHeight] = viewBox.split(' ').map(Number);
            width = vbWidth;
            height = vbHeight;
        }
        
        // Initialize positions randomly
        devices.forEach(device => {
            positions.set(device.id, {
                x: Math.random() * (width - 100) + 50,
                y: Math.random() * (height - 100) + 50,
                vx: 0,
                vy: 0
            });
        });

        // Force simulation - increased spacing constant for less crowding and better visibility
        const iterations = 100;
        const k = Math.sqrt((width * height) / devices.length) * 2.2; // Multiplied by 2.2 for more space and visibility
        
        for (let i = 0; i < iterations; i++) {
            // Repulsion forces
            devices.forEach(device1 => {
                const pos1 = positions.get(device1.id);
                devices.forEach(device2 => {
                    if (device1.id === device2.id) return;
                    
                    const pos2 = positions.get(device2.id);
                    const dx = pos1.x - pos2.x;
                    const dy = pos1.y - pos2.y;
                    const distance = Math.sqrt(dx * dx + dy * dy) || 1;
                    
                    const force = (k * k) / distance;
                    const fx = (dx / distance) * force;
                    const fy = (dy / distance) * force;
                    
                    pos1.vx += fx;
                    pos1.vy += fy;
                });
            });

            // Attraction forces (for connected devices)
            connections.forEach(connection => {
                const pos1 = positions.get(connection.source);
                const pos2 = positions.get(connection.target);
                
                if (pos1 && pos2) {
                    const dx = pos2.x - pos1.x;
                    const dy = pos2.y - pos1.y;
                    const distance = Math.sqrt(dx * dx + dy * dy) || 1;
                    
                    const force = (distance * distance) / k;
                    const fx = (dx / distance) * force;
                    const fy = (dy / distance) * force;
                    
                    pos1.vx += fx;
                    pos1.vy += fy;
                    pos2.vx -= fx;
                    pos2.vy -= fy;
                }
            });

            // Apply forces and damping
            devices.forEach(device => {
                const pos = positions.get(device.id);
                pos.vx *= 0.9; // damping
                pos.vy *= 0.9;
                pos.x += pos.vx;
                pos.y += pos.vy;
                
                // Keep within bounds
                pos.x = Math.max(50, Math.min(width - 50, pos.x));
                pos.y = Math.max(50, Math.min(height - 50, pos.y));
            });
        }

        // Convert to final positions
        const result = new Map();
        devices.forEach(device => {
            const pos = positions.get(device.id);
            result.set(device.id, { x: pos.x, y: pos.y, pinned: false });
        });

        return result;
    }

    gridLayout(devices) {
        const positions = new Map();
        const cols = Math.ceil(Math.sqrt(devices.length));
        const cellWidth = 300; // Further increased for more space and visibility
        const cellHeight = 250; // Further increased for more space and visibility
        
        devices.forEach((device, index) => {
            const row = Math.floor(index / cols);
            const col = index % cols;
            
            positions.set(device.id, {
                x: col * cellWidth + 100,
                y: row * cellHeight + 100,
                pinned: false
            });
        });

        return positions;
    }

    hierarchicalLayout(devices, connections, skipLayerIndicators = false) {
        // Advanced hierarchical layout with proper topology analysis
        const positions = new Map();
        // Use SVG viewBox dimensions for layout space
        const viewBox = this.svg.getAttribute('viewBox');
        let width = 2000, height = 1500; // Default fallback
        if (viewBox) {
            const [, , vbWidth, vbHeight] = viewBox.split(' ').map(Number);
            width = vbWidth;
            height = vbHeight;
        }
        
        // Build adjacency map for topology analysis
        const adjacency = new Map();
        devices.forEach(device => {
            const deviceId = device.id || device.hostname || device.ip_address;
            adjacency.set(deviceId, []);
        });
        connections.forEach(conn => {
            if (adjacency.has(conn.source)) adjacency.get(conn.source).push(conn.target);
            if (adjacency.has(conn.target)) adjacency.get(conn.target).push(conn.source);
        });
        
        // Calculate layers based on network hierarchy
        const layers = this.calculateHierarchicalLayers(devices, connections, adjacency);
        
        // Define layout parameters - increased for better visibility of layer info and nodes
        const padding = 150;
        const verticalSpacing = 400; // Further increased for better layer separation and visibility
        const horizontalSpacing = 600; // Further increased to prevent horizontal crowding and show layer info
        const usableWidth = width - (padding * 2);
        const usableHeight = height - (padding * 2);
        
        // Calculate positions for each layer
        let currentY = padding;
        const maxLayerHeight = usableHeight / Math.max(layers.length, 1);
        
        layers.forEach((layerDevices, layerIndex) => {
            const layerWidth = layerDevices.length * horizontalSpacing;
            let startX = (width - layerWidth) / 2 + (horizontalSpacing / 2);
            
            // If layer is too wide, compress horizontally
            if (layerWidth > usableWidth) {
                const actualSpacing = usableWidth / layerDevices.length;
                startX = padding + (actualSpacing / 2);
                
                layerDevices.forEach((device, index) => {
                    positions.set(device.id, {
                        x: startX + (index * actualSpacing),
                        y: currentY,
                        pinned: false,
                        layer: this.getLayerFromIndex(layerIndex, layers.length)
                    });
                });
            } else {
                layerDevices.forEach((device, index) => {
                    positions.set(device.id, {
                        x: startX + (index * horizontalSpacing),
                        y: currentY,
                        pinned: false,
                        layer: this.getLayerFromIndex(layerIndex, layers.length)
                    });
                });
            }
            
            // Add layer labels and visual indicators (only if not skipped)
            if (!skipLayerIndicators) {
                this.addLayerVisualIndicators(layerDevices, layerIndex, layers.length, currentY, width);
            }
            
            currentY += Math.min(verticalSpacing, maxLayerHeight);
        });
        
        return positions;
    }

    getLayerFromIndex(layerIndex, totalLayers) {
        // Map layer index to network layer type
        if (totalLayers === 1) return 'single';
        if (layerIndex === 0) return 'core';
        if (layerIndex === 1) return 'distribution';
        if (layerIndex === 2) return 'access';
        return 'unknown';
    }

    addLayerVisualIndicators(layerDevices, layerIndex, totalLayers, currentY, width) {
        if (!layerDevices || layerDevices.length === 0) return;
        
        // Determine layer name and color based on context
        let layerName, layerColor;
        
        // Check if this is a multi-row flat topology
        const isMultiRowFlat = totalLayers > 3 && layerDevices.every(device => 
            !device.device_role || !device.device_role.toLowerCase().includes('core')
        );
        
        if (isMultiRowFlat) {
            // For multi-row flat topologies, use row-based naming
            layerName = `Row ${layerIndex + 1}`;
            layerColor = this.getRowColor(layerIndex);
        } else if (totalLayers === 1) {
            layerName = 'Network Devices';
            layerColor = '#6c757d';
        } else if (layerIndex === 0) {
            layerName = 'Core Layer';
            layerColor = '#dc3545';
        } else if (layerIndex === 1) {
            layerName = 'Distribution Layer';
            layerColor = '#fd7e14';
        } else if (layerIndex === 2) {
            layerName = 'Access Layer';
            layerColor = '#28a745';
        } else {
            layerName = `Layer ${layerIndex + 1}`;
            layerColor = this.getRowColor(layerIndex);
        }
        
        // Add layer label
        const layerLabel = document.createElementNS('http://www.w3.org/2000/svg', 'text');
        layerLabel.setAttribute('x', '20');
        layerLabel.setAttribute('y', currentY - 20);
        layerLabel.setAttribute('class', 'layer-label');
        layerLabel.setAttribute('font-size', '24');
        layerLabel.setAttribute('font-weight', 'bold');
        layerLabel.setAttribute('fill', layerColor);
        layerLabel.textContent = layerName;
        
        // Add device count
        const deviceCount = document.createElementNS('http://www.w3.org/2000/svg', 'text');
        deviceCount.setAttribute('x', '20');
        deviceCount.setAttribute('y', currentY - 5);
        deviceCount.setAttribute('class', 'layer-count');
        deviceCount.setAttribute('font-size', '22');
        deviceCount.setAttribute('fill', '#666');
        deviceCount.textContent = `${layerDevices.length} device${layerDevices.length !== 1 ? 's' : ''}`;
        
        // Add horizontal line to separate layers
        const separatorLine = document.createElementNS('http://www.w3.org/2000/svg', 'line');
        separatorLine.setAttribute('x1', '0');
        separatorLine.setAttribute('y1', currentY - 30);
        separatorLine.setAttribute('x2', width);
        separatorLine.setAttribute('y2', currentY - 30);
        separatorLine.setAttribute('stroke', layerColor);
        separatorLine.setAttribute('stroke-width', '2');
        separatorLine.setAttribute('opacity', '0.3');
        separatorLine.setAttribute('stroke-dasharray', '5,5');
        
        // Add elements to the SVG
        const svg = this.svg;
        if (svg) {
            // Find or create layers group
            let layersGroup = svg.querySelector('#layers-group');
            if (!layersGroup) {
                layersGroup = document.createElementNS('http://www.w3.org/2000/svg', 'g');
                layersGroup.setAttribute('id', 'layers-group');
                svg.appendChild(layersGroup);
            }
            
            layersGroup.appendChild(separatorLine);
            layersGroup.appendChild(layerLabel);
            layersGroup.appendChild(deviceCount);
        }
    }

    getRowColor(rowIndex) {
        // Generate colors for multi-row layouts
        const colors = [
            '#007bff', // Blue
            '#28a745', // Green  
            '#ffc107', // Yellow
            '#dc3545', // Red
            '#6f42c1', // Purple
            '#fd7e14', // Orange
            '#20c997', // Teal
            '#e83e8c', // Pink
            '#6c757d', // Gray
            '#17a2b8'  // Cyan
        ];
        return colors[rowIndex % colors.length];
    }
    
    calculateHierarchicalLayers(devices, connections, adjacency) {
        // Check if we have discovery data with depth information
        const hasDiscoveryDepth = devices.some(device => device.discovery_depth !== undefined);
        
        if (hasDiscoveryDepth) {
            // For discovery mode, use enhanced topology analysis instead of just depth
            const enhancedLayers = this.calculateEnhancedDiscoveryLayers(devices, connections, adjacency);
            
            // Check if we have a flat topology (all devices in same layer)
            if (this.isFlatTopology(enhancedLayers)) {
                return this.calculateDiscoveryDepthLayers(devices);
            }
            
            return enhancedLayers;
        }
        
        // Use Cisco network hierarchy based on device names and roles
        const ciscoLayers = this.calculateCiscoHierarchicalLayers(devices, connections, adjacency);
        
        // Check if we have a flat topology (all devices in same layer)
        if (this.isFlatTopology(ciscoLayers)) {
            return this.calculateMultiRowLayout(devices, connections, adjacency);
        }
        
        return ciscoLayers;
    }

    calculateCiscoHierarchicalLayers(devices, connections, adjacency) {
        // Calculate connection counts for each device
        const connectionCount = new Map();
        devices.forEach(device => {
            const deviceId = device.id || device.hostname || device.ip_address;
            connectionCount.set(deviceId, (adjacency.get(deviceId) || []).length);
        });
        
        // Determine network layer for each device using NetworkConstants
        const deviceLayers = new Map();
        devices.forEach(device => {
            const deviceId = device.id || device.hostname || device.ip_address;
            const layer = NetworkConstants.getDeviceLayer(device, connectionCount.get(deviceId) || 0);
            deviceLayers.set(deviceId, layer);
        });
        
        // Group devices by their determined layer
        const layerGroups = new Map();
        devices.forEach(device => {
            const deviceId = device.id || device.hostname || device.ip_address;
            const layer = deviceLayers.get(deviceId);
            if (!layerGroups.has(layer)) {
                layerGroups.set(layer, []);
            }
            layerGroups.get(layer).push(device);
        });
        
        // Sort devices within each layer by connection count (descending)
        layerGroups.forEach(devicesInLayer => {
            devicesInLayer.sort((a, b) => {
                const deviceIdA = a.id || a.hostname || a.ip_address;
                const deviceIdB = b.id || b.hostname || b.ip_address;
                const countA = connectionCount.get(deviceIdA) || 0;
                const countB = connectionCount.get(deviceIdB) || 0;
                return countB - countA;
            });
        });
        
        // Create layers array in hierarchical order: Core -> Distribution -> Access -> Unknown
        const layers = [];
        const layerOrder = [
            NetworkConstants.LAYER_HIERARCHY.CORE,
            NetworkConstants.LAYER_HIERARCHY.DISTRIBUTION,
            NetworkConstants.LAYER_HIERARCHY.ACCESS,
            NetworkConstants.LAYER_HIERARCHY.UNKNOWN
        ];
        
        layerOrder.forEach(layerLevel => {
            if (layerGroups.has(layerLevel) && layerGroups.get(layerLevel).length > 0) {
                layers.push(layerGroups.get(layerLevel));
            }
        });
        
        // If no devices were classified, fall back to connection-based grouping
        if (layers.length === 0) {
            return this.calculateConnectionBasedLayers(devices, connectionCount);
        }
        
        return layers;
    }

    calculateConnectionBasedLayers(devices, connectionCount) {
        // Fallback method when device names don't match known patterns
        const layers = [[], [], []]; // Core, Distribution, Access
        
        devices.forEach(device => {
            const deviceId = device.id || device.hostname || device.ip_address;
            const connections = connectionCount.get(deviceId) || 0;
            
            if (connections >= 8) {
                layers[0].push(device); // Core
            } else if (connections >= 4) {
                layers[1].push(device); // Distribution
            } else {
                layers[2].push(device); // Access
            }
        });
        
        // Sort devices within each layer by connection count
        layers.forEach(layerDevices => {
            layerDevices.sort((a, b) => {
                const countA = connectionCount.get(a.id) || 0;
                const countB = connectionCount.get(b.id) || 0;
                return countB - countA;
            });
        });
        
        return layers.filter(layer => layer.length > 0);
    }
    
    getRoleLevel(deviceRole, roleHierarchy) {
        if (!deviceRole) return 6;
        
        const role = deviceRole.toLowerCase();
        for (const [key, value] of Object.entries(roleHierarchy)) {
            if (role.includes(key)) return value;
        }
        return 6;
    }
    
    calculateEnhancedDiscoveryLayers(devices, connections, adjacency) {
        // Calculate connection counts for each device
        const connectionCount = new Map();
        devices.forEach(device => {
            const deviceId = device.id || device.hostname || device.ip_address;
            connectionCount.set(deviceId, (adjacency.get(deviceId) || []).length);
        });
        
        // Use NetworkConstants to determine proper network layers
        const deviceLayers = new Map();
        devices.forEach(device => {
            const deviceId = device.id || device.hostname || device.ip_address;
            const connCount = connectionCount.get(deviceId) || 0;
            const layer = NetworkConstants.getDeviceLayer(device, connCount);
            deviceLayers.set(deviceId, layer);
        });
        
        // Group devices by their determined layer (not discovery depth)
        const layerGroups = new Map();
        devices.forEach(device => {
            const deviceId = device.id || device.hostname || device.ip_address;
            const layer = deviceLayers.get(deviceId);
            if (!layerGroups.has(layer)) {
                layerGroups.set(layer, []);
            }
            layerGroups.get(layer).push(device);
        });
        
        // Sort devices within each layer by connection count (descending) and then by name
        layerGroups.forEach(devicesInLayer => {
            devicesInLayer.sort((a, b) => {
                const deviceIdA = a.id || a.hostname || a.ip_address;
                const deviceIdB = b.id || b.hostname || b.ip_address;
                const countA = connectionCount.get(deviceIdA) || 0;
                const countB = connectionCount.get(deviceIdB) || 0;
                if (countA !== countB) {
                    return countB - countA; // Higher connections first
                }
                return (a.hostname || a.name || '').localeCompare(b.hostname || b.name || '');
            });
        });
        
        // Create layers array in hierarchical order: Core -> Distribution -> Access -> Unknown
        const layers = [];
        const layerOrder = [
            NetworkConstants.LAYER_HIERARCHY.CORE,
            NetworkConstants.LAYER_HIERARCHY.DISTRIBUTION,
            NetworkConstants.LAYER_HIERARCHY.ACCESS,
            NetworkConstants.LAYER_HIERARCHY.UNKNOWN
        ];
        
        layerOrder.forEach(layerLevel => {
            if (layerGroups.has(layerLevel) && layerGroups.get(layerLevel).length > 0) {
                layers.push(layerGroups.get(layerLevel));
            }
        });
        
        // If no devices were classified, fall back to discovery depth
        if (layers.length === 0) {
            return this.calculateDiscoveryDepthLayers(devices);
        }
        
        return layers;
    }

    calculateDiscoveryDepthLayers(devices) {
        // Group devices by discovery depth
        const depthGroups = new Map();
        
        devices.forEach(device => {
            const depth = device.discovery_depth || 0;
            if (!depthGroups.has(depth)) {
                depthGroups.set(depth, []);
            }
            depthGroups.get(depth).push(device);
        });
        
        // Sort depths and create layers
        const sortedDepths = Array.from(depthGroups.keys()).sort((a, b) => a - b);
        const layers = [];
        
        sortedDepths.forEach(depth => {
            const devicesAtDepth = depthGroups.get(depth);
            
            // If a single depth has many devices, split into multiple rows for better layout
            if (devicesAtDepth.length > 6) {
                const rowSize = Math.ceil(Math.sqrt(devicesAtDepth.length));
                const sortedDevices = devicesAtDepth.sort((a, b) => 
                    (a.hostname || a.name || '').localeCompare(b.hostname || b.name || '')
                );
                
                // Split into multiple rows
                for (let i = 0; i < sortedDevices.length; i += rowSize) {
                    const row = sortedDevices.slice(i, i + rowSize);
                    layers.push(row);
                }
            } else {
                // Sort devices within each depth by name for consistent ordering
                devicesAtDepth.sort((a, b) => (a.hostname || a.name || '').localeCompare(b.hostname || b.name || ''));
                layers.push(devicesAtDepth);
            }
        });
        
        return layers;
    }

    isFlatTopology(layers) {
        // Check if all devices are in a single layer or if layers are very unbalanced
        if (layers.length <= 1) {
            return true;
        }
        
        // Check if one layer contains most devices (>80%)
        const totalDevices = layers.reduce((sum, layer) => sum + layer.length, 0);
        const maxLayerSize = Math.max(...layers.map(layer => layer.length));
        
        return (maxLayerSize / totalDevices) > 0.8;
    }

    calculateMultiRowLayout(devices, connections, adjacency) {
        // Create a multi-row layout for flat topologies
        // Group devices by connection count for better visual hierarchy
        const connectionCount = new Map();
        devices.forEach(device => {
            const deviceId = device.id || device.hostname || device.ip_address;
            connectionCount.set(deviceId, (adjacency.get(deviceId) || []).length);
        });
        
        // Sort devices by connection count (descending) then by name
        const sortedDevices = devices.sort((a, b) => {
            const deviceIdA = a.id || a.hostname || a.ip_address;
            const deviceIdB = b.id || b.hostname || b.ip_address;
            const countA = connectionCount.get(deviceIdA) || 0;
            const countB = connectionCount.get(deviceIdB) || 0;
            
            if (countA !== countB) {
                return countB - countA; // Higher connections first
            }
            return (a.hostname || a.name || '').localeCompare(b.hostname || b.name || '');
        });
        
        // Calculate optimal row size based on device count
        const deviceCount = sortedDevices.length;
        let rowSize;
        
        if (deviceCount <= 4) {
            rowSize = deviceCount; // Single row for small counts
        } else if (deviceCount <= 9) {
            rowSize = Math.ceil(deviceCount / 2); // Two rows
        } else if (deviceCount <= 16) {
            rowSize = Math.ceil(deviceCount / 3); // Three rows
        } else {
            rowSize = Math.ceil(Math.sqrt(deviceCount)); // Square-ish layout
        }
        
        // Split devices into rows
        const layers = [];
        for (let i = 0; i < sortedDevices.length; i += rowSize) {
            const row = sortedDevices.slice(i, i + rowSize);
            layers.push(row);
        }
        return layers;
    }
    
    assignToLayer(device, adjacency, assigned, deviceToLayer) {
        const neighbors = adjacency.get(device.id) || [];
        if (neighbors.length === 0) return 0;
        
        // Find minimum layer of already assigned neighbors
        let minNeighborLayer = Infinity;
        let hasAssignedNeighbor = false;
        
        neighbors.forEach(neighborId => {
            if (assigned.has(neighborId)) {
                hasAssignedNeighbor = true;
                const neighborLayer = deviceToLayer.get(neighborId) || 0;
                minNeighborLayer = Math.min(minNeighborLayer, neighborLayer);
            }
        });
        
        if (hasAssignedNeighbor) {
            return minNeighborLayer + 1;
        }
        
        return 0;
    }
}

class ZoomPan {
    constructor(svg, container) {
        this.svg = svg;
        this.container = container;
        this.scale = 1;
        this.panX = 0;
        this.panY = 0;
        this.isPanning = false;
        this.panStart = null;
        
        // Ensure SVG starts with no transforms - matches container exactly
        this.svg.style.transform = '';
        
        this.setupEventListeners();
    }

    setupEventListeners() {
        // Mouse wheel zoom
        this.container.addEventListener('wheel', this.handleWheel.bind(this));
        
        // Mouse pan
        this.container.addEventListener('mousedown', this.handleMouseDown.bind(this));
        document.addEventListener('mousemove', this.handleMouseMove.bind(this));
        document.addEventListener('mouseup', this.handleMouseUp.bind(this));
    }

    handleWheel(event) {
        event.preventDefault();
        
        const delta = event.deltaY > 0 ? 0.9 : 1.1;
        const newScale = Math.max(0.1, Math.min(5, this.scale * delta));
        
        const rect = this.container.getBoundingClientRect();
        const mouseX = event.clientX - rect.left;
        const mouseY = event.clientY - rect.top;
        
        // Zoom towards mouse position
        const scaleChange = newScale / this.scale;
        this.panX = mouseX - (mouseX - this.panX) * scaleChange;
        this.panY = mouseY - (mouseY - this.panY) * scaleChange;
        this.scale = newScale;
        
        this.updateTransform();
    }

    handleMouseDown(event) {
        if (isDeviceDragging || event.target.closest('.device-node')) {
            return;
        }
        
        if (event.target === this.svg || event.target.closest('svg')) {
            this.isPanning = true;
            this.panStart = { x: event.clientX - this.panX, y: event.clientY - this.panY };
            this.container.style.cursor = 'grabbing';
            event.preventDefault();
        }
    }

    handleMouseMove(event) {
        const timeSinceLastDrag = Date.now() - lastDeviceDragEndTime;
        if (isDeviceDragging || timeSinceLastDrag < 50) {
            if (this.isPanning) {
                this.isPanning = false;
                this.panStart = null;
                this.container.style.cursor = 'grab';
            }
            return;
        }
        
        if (this.isPanning && this.panStart) {
            this.panX = event.clientX - this.panStart.x;
            this.panY = event.clientY - this.panStart.y;
            this.updateTransform();
        }
    }

    handleMouseUp(event) {
        if (isDeviceDragging) {
            return;
        }
        
        if (!this.isPanning) return; 
        
        this.isPanning = false;
        this.panStart = null;
        this.container.style.cursor = 'grab';
    }

    updateTransform() {
        // Don't update transform if a device is being dragged or just finished dragging
        const timeSinceLastDrag = Date.now() - lastDeviceDragEndTime;
        if (isDeviceDragging || timeSinceLastDrag < 50) {
            return;
        }
        
        const transform = `translate(${this.panX}px, ${this.panY}px) scale(${this.scale})`;
        this.svg.style.transform = transform;
    }

    reset() {
        this.scale = 1;
        this.panX = 0;
        this.panY = 0;
        this.updateTransform();
    }

    fitToScreen() {
        // Reset scale and pan first
        this.scale = 1;
        this.panX = 0;
        this.panY = 0;
        this.updateTransform();
        
        // Calculate bounding box of all device nodes
        const deviceNodes = this.svg.querySelectorAll('.device-node');
        if (deviceNodes.length === 0) return;
        
        let minX = Infinity, minY = Infinity;
        let maxX = -Infinity, maxY = -Infinity;
        
        deviceNodes.forEach(node => {
            const x = parseFloat(node.getAttribute('data-x')) || 0;
            const y = parseFloat(node.getAttribute('data-y')) || 0;
            
            // Add padding for node size (approximate 50px radius)
            minX = Math.min(minX, x - 50);
            minY = Math.min(minY, y - 50);
            maxX = Math.max(maxX, x + 50);
            maxY = Math.max(maxY, y + 50);
        });
        
        const contentWidth = maxX - minX;
        const contentHeight = maxY - minY;
        const containerRect = this.container.getBoundingClientRect();
        
        // Ensure we have valid container dimensions
        if (containerRect.width === 0 || containerRect.height === 0) {
            console.warn('Container has zero dimensions, using fallback');
            return;
        }
        
        // Calculate scale to fit content with padding
        const padding = 40;
        const scaleX = (containerRect.width - padding * 2) / contentWidth;
        const scaleY = (containerRect.height - padding * 2) / contentHeight;
        this.scale = Math.min(scaleX, scaleY, 1.5); // Cap at 1.5x to avoid over-zooming
        
        // Calculate pan to center content
        const contentCenterX = (minX + maxX) / 2;
        const contentCenterY = (minY + maxY) / 2;
        
        this.panX = containerRect.width / 2 - contentCenterX * this.scale;
        this.panY = containerRect.height / 2 - contentCenterY * this.scale;
        
        this.updateTransform();
    }

    getViewport() {
        return {
            zoom: this.scale,
            pan_x: this.panX,
            pan_y: this.panY
        };
    }

    setViewport(viewport) {
        this.scale = viewport.zoom || 1;
        this.panX = viewport.pan_x || 0;
        this.panY = viewport.pan_y || 0;
        this.updateTransform();
    }
}

window.TopologyUtils = {
    DOMUtils,
    TopologyDragging,
    ConnectionRenderer,
    AutoLayout,
    ZoomPan
};

window.DOMUtils = DOMUtils;
window.TopologyDragging = TopologyDragging;
window.ConnectionRenderer = ConnectionRenderer;
window.AutoLayout = AutoLayout;
window.ZoomPan = ZoomPan;

