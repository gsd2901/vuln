from django.shortcuts import render, get_object_or_404
from django.contrib.auth.mixins import LoginRequiredMixin
from django.views.generic import TemplateView
from django.views.decorators.clickjacking import xframe_options_sameorigin
from django.utils.decorators import method_decorator
from nautobot.dcim.models import Location
from nautobot_inventory.models import InventoryDiscoverySession


@method_decorator(xframe_options_sameorigin, name='dispatch')
class TopologyViewerView(LoginRequiredMixin, TemplateView):
    """Main topology viewer page."""
    
    template_name = 'nautobot_topology_viewer/topology_viewer.html'
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        location_id = kwargs.get('location_id')
        
        if location_id:
            location = get_object_or_404(Location, pk=location_id)
            context['location'] = location
            context['location_id'] = location_id
        else:
            # Show location selector if no location specified
            context['locations'] = Location.objects.filter(devices__isnull=False).distinct()
        
        return context


class DiscoveryTopologyViewerView(LoginRequiredMixin, TemplateView):
    """Topology viewer for discovery sessions."""
    
    template_name = 'nautobot_topology_viewer/topology_viewer.html'
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        session_id = kwargs.get('session_id')
        
        if session_id:
            try:
                session = get_object_or_404(InventoryDiscoverySession, session_id=session_id)
                context['session'] = session
                context['session_id'] = session_id
                context['is_discovery_mode'] = True
                # Count connected devices (exclude failed/unreachable ones)
                connected_devices = session.devices.filter(
                    hostname__isnull=False
                ).exclude(
                    hostname__startswith='unreachable-'
                ).exclude(
                    hostname__startswith='failed-'
                ).exclude(
                    hostname__startswith='error-'
                ).exclude(
                    hostname__startswith='timeout-'
                )
                context['device_count'] = connected_devices.count()
            except Exception as e:
                context['error'] = f"Invalid discovery session: {str(e)}"
        else:
            context['error'] = "No discovery session specified"
        
        return context
