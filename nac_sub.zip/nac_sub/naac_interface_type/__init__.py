from nautobot.extras.plugins import PluginConfig
 
__version__ = "0.1.0"
 
class NaacInterfaceTypeConfig(PluginConfig):
    """Plugin entry point for Interface Type Assignment."""
 
    name = "naac_interface_type"
    verbose_name = "NAAC Interface Type Assignment"
    version = __version__
    author = "Riya"
    description = "Assign interface type (physical/logical/others) to interfaces."
    base_url = "naac-interface-type"
    required_settings = []
    default_settings = {}
    caching_config = {}
 
    def ready(self):
        super().ready()
 
        try:
            from nautobot.extras.models import Job as JobModel, JobQueue
            from nautobot.extras.registry import registry
            from naac_interface_type.jobs import InterfaceTypeAssignmentJob
            job_path = "naac_interface_type.jobs.InterfaceTypeAssignmentJob"
            registry["jobs"][job_path] = InterfaceTypeAssignmentJob
            default_queue, _ = JobQueue.objects.get_or_create(name="default")
            JobModel.objects.update_or_create(
                module_name="naac_interface_type.jobs",
                job_class_name="InterfaceTypeAssignmentJob",
                defaults={
                    "name": InterfaceTypeAssignmentJob.name,
                    "grouping": "Interface Management",
                    "description": getattr(InterfaceTypeAssignmentJob, "description", ""),
                    "installed": True,
                    "enabled": True,
                    "has_sensitive_variables": False,
                    "default_job_queue": default_queue,
                },
            )
            print("[NAAC Interface Type] Job registered successfully.") 
        except Exception as exc:
            print(f"[NAAC Interface Type] Error loading jobs: {exc}")
 
config = NaacInterfaceTypeConfig