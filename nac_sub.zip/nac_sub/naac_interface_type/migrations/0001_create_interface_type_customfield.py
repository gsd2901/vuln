from django.db import migrations 
 
def create_interface_type_custom_field(apps, schema_editor):
    """Create Interface Type custom field with dropdown choices."""
    ContentType = apps.get_model("contenttypes", "ContentType")
    CustomField = apps.get_model("extras", "CustomField")
    CustomFieldChoice = apps.get_model("extras", "CustomFieldChoice")
 
    # Get Interface content type
    interface_ct = ContentType.objects.get(app_label="dcim", model="interface")
 
    # Create Custom Field 
    cf, _ = CustomField.objects.update_or_create(
        key="interface_type",
        defaults={
            "label": "Interface Type",
            "type": "select",  
            "grouping": "Interface Data",
            "description": "Physical / Logical / Others classification",
            "required": False,
            "filter_logic": "loose",
            "weight": 100,
        },
    )
 
    cf.content_types.add(interface_ct)
 
    # Create Choices 
    choices = [
        {"value": "physical", "weight": 100},
        {"value": "logical", "weight": 100},
        {"value": "others", "weight": 100},
    ]
 
    for choice in choices:
        CustomFieldChoice.objects.update_or_create(
            custom_field=cf,
            value=choice["value"],
            defaults={
                "weight": choice["weight"],
            },
        )
 
 
def delete_interface_type_custom_field(apps, schema_editor):
    """Delete Interface Type custom field."""
    CustomField = apps.get_model("extras", "CustomField")
    CustomField.objects.filter(key="interface_type").delete()
 
 
class Migration(migrations.Migration):
 
    dependencies = []
 
    operations = [
        migrations.RunPython(
            create_interface_type_custom_field,
            delete_interface_type_custom_field,
        ),
    ]