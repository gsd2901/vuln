"""Nautobot job to assign interface type based on naming patterns."""
 
from __future__ import annotations
from typing import Dict
from django.db import transaction
from nautobot.apps.jobs import Job, ObjectVar
from nautobot.dcim.models import Interface, Location
from nautobot.apps.jobs import register_jobs
 
def classify_interface(name: str) -> str:
    """Classify interface into physical, logical, or others."""
 
    if not name:
        return "others"
    name = name.lower()
    physical_patterns = (
        "ethernet", "gi", "tengig", "fortygig", "hundredgig",
        "xe-", "ge-", "et-", "mgmt"
    )
    logical_patterns = (
        "loopback", "vlan", "tunnel", "port-channel",
        "bundle-ether", "ae", "irb", "bdi"
    )
    if any(name.startswith(p) for p in physical_patterns):
        return "physical"
    if any(name.startswith(p) for p in logical_patterns):
        return "logical"
    if "." in name:
        return "logical"
    return "others"
 
class InterfaceTypeAssignmentJob(Job):
    """Assign interface type to all interfaces in a location."""
 
    class Meta:
        name = "Interface Type Assignment"
        description = "Assign interface type (physical/logical/others) to interfaces."
    location = ObjectVar(
        model=Location,
        required=True,
        description="Select location to process interfaces.",
    )
    def run(self, *, location):
        """Execute job."""
        interfaces = Interface.objects.filter(
            device__location=location
        ).select_related("device")
        self.logger.info(
            "Starting interface classification for %s interfaces in %s",
            interfaces.count(),
            location.name,
        )
        stats: Dict[str, int] = {
            "processed": 0,
            "updated": 0,
            "failed": 0,
        }
        for interface in interfaces:
            stats["processed"] += 1
            try:
                intf_type = classify_interface(interface.name)
                interface.cf["interface_type"] = intf_type
                with transaction.atomic():
                    interface.save()
                stats["updated"] += 1
            except Exception as exc:
                stats["failed"] += 1
                self.logger.error(
                    "Failed for %s (%s): %s",
                    interface.name,
                    interface.device.name,
                    exc,
                )
 
        self.logger.info("Completed Interface Type Assignment: %s", stats)
        return stats
 
jobs = [InterfaceTypeAssignmentJob]
register_jobs(*jobs) 