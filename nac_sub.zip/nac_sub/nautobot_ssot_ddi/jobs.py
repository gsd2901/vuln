from diffsync.logging import enable_console_logging
from nautobot.core.celery import register_jobs
from nautobot_ssot.jobs.base import DataSource
from nautobot_ssot_ddi.diffsync.adapters.ddi import DdiAdapter
from nautobot_ssot_ddi.diffsync.adapters.nautobot import DdiSSOtNautobotAdapter
from nautobot.dcim.models import Controller
from nautobot.apps.jobs import BooleanVar, ObjectVar, Job
from diffsync.enum import DiffSyncFlags
from nautobot.extras.models import Status, Role
from nautobot.ipam.models import Namespace, Prefix, IPAddress, VLAN
from django.contrib.contenttypes.models import ContentType

name = "DDI SSoT" #pylint: disable-invalid-name

class DdiSSOTJob(DataSource):
    """Synchronize device data from ddi into Nautobot safely (no deletions)."""
    dryrun = BooleanVar(description="Run in dry run mode (no database changes)")
    debug = BooleanVar(description="Enable verbose debug logging",default=False)
    namespace = ObjectVar(
        model=Namespace,
        required=True,
        label="Namespace",
        description="Namespace to be applied to all synced Prefixes and IP Addresses.",
    )
    role = ObjectVar(
        model=Role,
        required=True,
        label="DDI Role",
        description="Role to be applied to all synced Prefixes, VLANs and IP Addresses.",
    )
    prefix_status = ObjectVar(
        model=Status,
        required=True,
        label="Prefix Status",
        description="Status to be applied to all synced Prefixes.",
    )

    ddi_controller = ObjectVar(
        model= Controller,
        required = True,
        description="Select the ddi Controller instance to sync from."
    )
    
    class Meta:
        name = "ddi -> Nautobot Device Sync"
        description = "Synchronize device and related data from ddi with Nautobot code models."
        approval_required = False
        has_sensitive_variables = False

    def validate_content_types(self):

        required_models = {"ipaddress", "prefix", "vlan"}
        role_models = {ct.model for ct in self.selected_role.content_types.all()}
        missing = required_models - role_models

        if missing:
            self.logger.error("Role '%s' is missing content types: %s",self.selected_role,", ".join(sorted(missing)),)
            raise ValueError(
                f"Role '{self.selected_role}' is missing content types: "
                f"{', '.join(sorted(missing))}"
            )

    def debug_log(self, msg, *args):
        if self.debug:
            self.logger.debug(msg, *args)
    
    def load_source_adapter(self):
        """Initialize ddi data source adapter using instance context"""
        self.debug_log("loading ddi source adapter for : %s", self.ddi_controller)
        self.source_adapter = DdiAdapter(ddi = self.ddi_controller, job=self,debug=self.debug)
        self.debug_log(f"the object and it dir :{dir(self.source_adapter)}")
        self.source_adapter.load()
        self.debug_log("loading ddi source adapter for :")
        
    def load_target_adapter(self):
        """Initialize Nautobot data target adapter"""
        self.debug_log("Loading nautobot target adapter.")
        self.target_adapter = DdiSSOtNautobotAdapter(ddi = self.ddi_controller,job=self,debug=self.debug)
        self.target_adapter.load()
        self.debug_log("Finished loading Nautobot target adapter.")

        # --- Diff preview with current Diff API ---
        diff = self.target_adapter.diff_from(
            self.source_adapter, flags=self.diffsync_flags
        )
        # summary() returns a dict keyed by modelname with counts[web:219][web:151]
        summary = diff.summary()
        self.logger.info("Diff summary: %s", summary)

        # --- Log VLANs from SOURCE (DDI) ---
        self.logger.info("=== VLANs FROM SOURCE (DDI) ===")
        for vlan_obj in self.source_adapter.get_all("vlan"):
            self.logger.info(
                "SRC VLAN: id=%s vid=%s name=%s status=%s",
                vlan_obj.get_unique_id(),
                getattr(vlan_obj, "vid", None),
                getattr(vlan_obj, "name", None),
                getattr(vlan_obj, "status", None)
                or getattr(vlan_obj, "status__name", None),
            )

        # --- Log VLANs from TARGET (Nautobot) ---
        self.logger.info("=== VLANs FROM TARGET (Nautobot) ===")
        for vlan_obj in self.target_adapter.get_all("vlan"):
            self.logger.info(
                "DST VLAN: id=%s vid=%s name=%s status=%s",
                vlan_obj.get_unique_id(),
                getattr(vlan_obj, "vid", None),
                getattr(vlan_obj, "name", None),
                getattr(vlan_obj, "status__name", None),
            )

        
        # DataSource.execute_sync() will recompute and apply the diff later.

        
    def run(self, ddi_controller:Controller,namespace=None,role=None,prefix_status=None, dryrun: bool = False, debug: bool = False, **kwargs):
        """Standard SSoT job entrypoint."""
        self.ddi_controller = ddi_controller
        self.selected_namespace = namespace
        self.selected_role = role
        self.selected_prefix_status = prefix_status
        self.validate_content_types()
        self.diffsync_flags = DiffSyncFlags.SKIP_UNMATCHED_DST
        self.dryrun = dryrun
        self.debug = debug
        return super().run(ddi_controller=self.ddi_controller,dryrun=self.dryrun,flags=DiffSyncFlags.SKIP_UNMATCHED_DST, **kwargs)

jobs = [DdiSSOTJob]
register_jobs(*jobs)