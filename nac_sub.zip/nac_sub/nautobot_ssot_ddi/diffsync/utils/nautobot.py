from __future__ import annotations
from typing import Dict, Any, List, Optional
from django.db import transaction


class Nautobot:
    """Helper collection that encapsulates Nautobot CRM interactions used by DiffSync Models."""

    # ------------------ DeviceType ---------------
    @staticmethod
    def create_device_type(adapter, ids: Dict[str, Any], attrs: Dict[str, Any]):
        from nautobot.dcim.models import DeviceType, Manufacturer

        model = ids.get("model")
        manufacturer_name = (
            attrs.get("manufacturer") or attrs.get("manufacturer_name") or "opengear"
        )
        manufacturer = Manufacturer.objects.filter(nane=manufacturer_name).first()

        if not manufacturer:
            manufacturer = Manufacturer.objects.create(name=manufacturer_name)
        DeviceType.objects.get_or_create(model=model, manufacturer=manufacturer)
        adapter.job.logger.info(
            "Ensured Device Type:  %s (manufacturer - %s)", model, manufacturer_name
        )

    @staticmethod
    def update_device_type(adapter, attrs: Dict[str, Any]):
        from nautobot.dcim.models import DeviceType

        model = adapter.model
        obj = DeviceType.objects.filter(model=model).first()
        if not obj:
            adapter.adapter.job.logger.warning(
                "Device Type %s missing for update", model
            )
            return

        if attrs.get("model") and attrs["model"] != obj.model:
            obj.model = attrs["model"]
        obj.save()
        adapter.adapter.job.logger.info("Updated DeviceType: %s", obj.model)

    @staticmethod
    def create_platform(adapter, ids: Dict[str, Any], attrs: Dict[str, Any]):
        from nautobot.dcim.models import Platform

        name = ids.get("name")
        if not name:
            return
        Platform.objects.get_or_create(name=name)
        adapter.job.logger.info("Ensured Platform: %s", name)

    @staticmethod
    def update_platform(adapter, attrs: Dict[str, Any]):
        pass

    # -----------Prefix---------------
    @staticmethod
    def create_prefix(adapter, ids: Dict[str, Any], attrs: Dict[str, Any]):
        from nautobot.ipam.models import Prefix, Namespace,VLAN
        from nautobot.extras.models import Role, Status
        from nautobot.dcim.models import Location
        defaults = {}
        prefix = ids.get("prefix")
        namespace = adapter.job.selected_namespace
        if attrs.get("vlan__name"):
            vlan_obj = VLAN.objects.filter(name=attrs.get("vlan__name")).first()
            if vlan_obj:
                defaults['vlan'] = vlan_obj
        defaults["role"] = adapter.job.selected_role
        defaults["status"] = adapter.job.selected_prefix_status
        prefix_obj, _ = Prefix.objects.get_or_create(prefix=prefix,namespace=namespace,defaults=defaults)
        return prefix_obj
        
        
    
    @staticmethod
    def update_prefix(adapter, attrs: Dict[str, Any]):
        from nautobot.ipam.models import Prefix, Namespace,VLAN
        prefix = adapter.prefix
        namespace = adapter.adapter.job.selected_namespace
        obj = Prefix.objects.filter(prefix=prefix, namespace=namespace).first()
        if not obj:
            adapter.adapter.job.logger.warning("Prefix %s missing for update", prefix)
            return
        
        #only status / role changes done here
        obj.status = adapter.adapter.job.selected_prefix_status

        if attrs.get("vlan__name"):
            vlan_obj = VLAN.objects.filter(name=attrs.get("vlan__name")).first()
            if vlan_obj:
                obj.vlan = vlan_obj

        obj.role = adapter.adapter.job.selected_role
        obj.save()
        adapter.adapter.job.logger.info("Updated Prefix: %s",prefix)
    
    #  ----------Vlan------------
    @staticmethod
    def create_vlan(adapter, ids: Dict[str, Any], attrs: Dict[str, Any]):
        from nautobot.ipam.models import VLAN
        from nautobot.extras.models import Role, Status
        from nautobot.dcim.models import Location
        vid = ids.get('vid')
        if vid is None:
            adapter.job.logger.warning("VLAN create called without vid")
            return
        defaults = {"name": attrs.get("name", f"vlan{vid}")}
        defaults["role"] = adapter.job.selected_role   
        vlan, _ = VLAN.objects.get_or_create(vid=vid, defaults=defaults)
        adapter.job.logger.info(f"the vlans are added :{vlan}")
    #     # if attrs.get("locations"):
    #     #     loc_objs = [Location.objects.filter(name=l).first() for l in attrs["locations"]]
    #     #     vlan.locations.set([l for l in loc_objs if l])
    #     # adapter.job.logger.info("Ensured VLAN: %s",vid)
        
    @staticmethod
    def update_vlan(adapter, attrs: Dict[str, Any]):
        from nautobot.ipam.models import VLAN
        vid = adapter.vid
        obj = VLAN.objects.filter(vid=vid).first()
        if not obj:
            adapter.adapter.job.logger.warning("VLAN %s missing for update", vid)
            return
        if attrs.get("name"):
            obj.name = attrs["name"]
        obj.save()
        adapter.adapter.job.logger.info("Updated VLAN: %s", vid)
        
    # --------------- VRF --------------
    @staticmethod
    def create_vrf(adapter, ids: Dict[str, Any], attrs: Dict[str, Any]):
        from nautobot.ipam.models import VRF, Namespace
        from nautobot.tenancy.models import Tenant
        
        name = ids.get("name")
        namespace_name = ids.get("namespace") or attrs.get("namespace")
        namespace = Namespace.objects.filter(name=namespace_name).first() or Tenant.objects.create(name=namespace_name)
        tenant = None
        if attrs.get("tenant_name"):
            tenant = Tenant.objets.filter(name=attrs["tenant_name"]).first() or Tenant.objects.create(name=attrs["tenant_name"])
        defaults={}
        if attrs.get("rd"):
            defaults["rd"] = attrs["rd"]
        if tenant:
            defaults["tenant"] = tenant
        VRF.objects.get_or_create(name=name,namespace=namespace, defaults=defaults)
        adapter.job.logger.info("Ensured VRF: %s",name)
    
    @staticmethod
    def update_vrf(adapter, attrs:Dict[str, Any]):
        from nautobot.ipam.models import VRF
        name = adapter.name
        obj = VRF.objects.filter(name=name, namespace=adapter.namespace).first()
        if not obj:
            adapter.adapter.job.logger.warning("VRF %s missing for update", name)
            return
        if attrs.get("rd"):
            obj.rd = attrs["rd"]
        obj.save()
        adapter.adapter.job.logger.info("Updated VRF: %s", name)
        
    
    #  ----------Device------------
    
    @staticmethod 
    def create_device(adapter, ids: Dict[str, Any], attrs: Dict[str, Any]):
        from nautobot.dcim.models import Device, DeviceType, Platform, Location
        from nautobot.extras.models import Status, Role
        
        from nautobot.ipam.models import IPAddress
        name = ids.get("name")
        if not name:
            adapter.job.logger.warning("Device create called without name")
            return
        
        # Resolve references safely (no expections unless critical)
        dt = DeviceType.objects.filter(model=attrs.get("device_type")).first() if attrs.get("device_type") else None
        loc = Location.objects.filter(model=attrs.get("location")).first() if attrs.get("location") else None
        pl = Platform.objects.filter(model=attrs.get("platform")).first() if attrs.get("platform") else None
        st = Status.objects.filter(model=attrs.get("status")).first() if attrs.get("status") else None
        role = Role.objects.filter(model=attrs.get("role")).first() if attrs.get("role") else None
        
        if not role:
            role, _ = Role.objects.get_or_create(name=attrs.get("role") or attrs.get("role_name") or "default")
        primary_ip_obj = None
        if attrs.get("primary_ip4"):
            primary_ip_obj - IPAddress.objects.filter(address=attrs["primary_ip4"]).first()
            
        defaults = {
            "device_type__model": dt,
            "location__name": loc,
            "platform__name": pl,
            "status__name": st,
            "role__name": role,
            "primary_ip4__host": primary_ip_obj,
            "primary_ip6__host": primary_ip_obj,
            "serial":attrs.get("serial"),
        }
        
        Device.objects.get_or_create(name=name, defaults=defaults)
        adapter.job.logger.info("Ensured Device: %s",name)
        
    @staticmethod
    def update_device(adapter, attrs: Dict[str, Any]):
        from nautobot.dcim.models import Device, DeviceType, Location, Platform
        from nautobot.extras.models import Status
        from nautobot.ipam.models import IPAddress
        
        name = adapter.name
        obj = Device.objects.filter(name=name).first()
        if not obj:
            adapter.adapter.job.logger.warning("Device %s missing for update", name)
            return

        if "serial" in attrs:
            obj.serial = attrs["serial"]
        
        if "device_type__model" in attrs:
            dt = DeviceType.objects.filter(model=attrs["device_type__model"]).first()
            if dt:
                obj.device_type = dt
        
        if "platform__name" in attrs:
            pl = Platform.objects.filter(model=attrs["platform__name"]).first()
            if pl:
                obj.platform = pl
        
        if "status__name" in attrs:
            st = Status.objects.filter(model=attrs["status__name"]).first()
            if st:
                obj.status = st
        
        if "primary_ip4__host" in attrs:
            ip = IPAddress.objects.filter(model=attrs["primary_ip4__host"]).first()
            if ip:
                obj.primary_ip4 = ip
        
        obj.save()
        adapter.adapter.job.logger.info("Updated Device %s", name)
        

    # ----------- Interface--------------
    @staticmethod 
    def create_interface(adapter, ids: Dict[str, Any], attrs: Dict[str, Any]):
        from nautobot.dcim.models import Device, Interface
        from nautobot.extras.models import Status
        
        dev_name = ids.get("device__name")
        iface_name = ids.get("name")
        if not dev_name or not iface_name:
            adapter.job.logger.warning("Interface create missing device_name or name")
            return
        device = Device.objects.filter(name=dev_name).first()
        if not device:
            adapter.job.logger.warning("Interface create skiped: device not found %s",dev_name)
            return
        defaults = {
            "enabled": attrs.get("enabled", True),
            "type": attrs.get("type", "other"),
            "description": attrs.get("description", ""),
        }
        if attrs.get("status"):
            status_obj = Status.objects.filter(name=attrs["status"]).first()
            if status_obj:
                defaults["status"] = status_obj
        
        Interface.objects.get_or_create(device=device,name=iface_name, defaults=defaults)
        adapter.job.logger.info("Ensured Interface: %s on %s",iface_name,dev_name)
        
    @staticmethod
    def update_interface(adapter, attrs: Dict[str, Any]):
        from nautobot.dcim.models import Device, Interface
        from nautobot.extras.models import Status
        
        dev_name = adapter.device__name
        iface_name = adapter.name
        device = Device.objects.filter(name=dev_name).filter()
        if not device:
            adapter.adapter.job.logger.warning("Interface update skipped: Device not found %s", dev_name)
            return
        iface = Interface.objects.filter(name=iface_name).filter()
        if not iface:
            adapter.adapter.job.logger.warning("Interface update skipped: interface not found %s on %s", iface_name,dev_name)
            return

        if "enabled" in attrs:
            iface.enabled = attrs["enabled"]
            
        if "type" in attrs:
            iface.type = attrs["type"]
            
        if "description" in attrs:
            iface.description = attrs["description"]
                
        if "status" in attrs:
            st = Status.objects.filter(model=attrs["status"]).first()
            if st:
                iface.status = st
                
        iface.save()
        adapter.adapter.job.logger.info("Updated Interface  %s on %s",iface_name, dev_name)
        
        
    # ----------- IPAddress --------------

    @staticmethod 
    def create_ipaddress(adapter, ids: Dict[str, Any], attrs: Dict[str, Any]):
        from nautobot.ipam.models import IPAddress, Namespace
        from nautobot.extras.models import Status, Role
        from django.contrib.contenttypes.models import ContentType
        from nautobot.dcim.models import Device, Interface
        
        addr = ids.get("host")
        try:
            if not addr:
                adapter.job.logger.info("skipping IP create: empty address")
                return False
            existing = IPAddress.objects.filter(host=addr).first()
            if existing:
                adapter.job.logger.info("IPAddress alreadyt exist: %s", addr)
                return True

            namespace_obj = adapter.job.selected_namespace
            status_name = attrs.get("status")
            status_obj = None
            if status_name:
                status_obj = Status.objects.filter(name=status_name).first()
                if status_name and not status_obj:
                    adapter.job.logger.warning("Status '%s' not found in Nautobot",status_name,)
            adapter.job.debug_log(f"the status is {status_obj}")
            role_obj = adapter.job.selected_role
            ip_defaults = {
                "namespace": namespace_obj,
                "role": role_obj,
            }
            if status_obj:
                ip_defaults["status"] = status_obj
            ip = IPAddress.objects.create(address=addr, **ip_defaults)
            adapter.job.debug_log("Created IPAddress: %s",addr)
            return True
        except Exception as e:
            adapter.job.logger.error("Error in IPAddress Creation: %s", e)
            return False
        
    @staticmethod
    def update_ipaddress(adapter, attrs: Dict[str, Any]):
        from nautobot.ipam.models import IPAddress, Namespace
        from nautobot.extras.models import Status, Role
        from django.contrib.contenttypes.models import ContentType
        addr = adapter.host
        obj = IPAddress.objects.filter(host=addr).first()

        try:
            if not obj:
                adapter.adapter.job.logger.warning("IPAddress %s missing for update",addr)
                return False

            obj.role = adapter.adapter.job.selected_role
            status_name = attrs.get("status")
            if status_name:
                status_obj = Status.objects.filter(name=status_name).first()
                if status_obj:
                    obj.status = status_obj
            obj.save()
            adapter.adapter.job.logger.info("Updated IPAddress: %s",addr)
            return True

        except Exception as e:
            adapter.adapter.job.logger.error(f"Failed updating IPAddress {addr}: {e}")
            return False