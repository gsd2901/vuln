import uuid
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
from nautobot.extras.choices import (
    SecretsGroupAccessTypeChoices,
    SecretsGroupSecretTypeChoices,
)
 
DEFAULT_TIMEOUT = 10
RETRY_STRATEGY = Retry(
    total=3,
    backoff_factor=0.5,
    status_forcelist=(429, 500, 502, 503, 504),
    allowed_methods=frozenset(["GET", "POST", "PUT", "DELETE", "PATCH"]),
)
 
class DdiAdapterError(Exception):
    """Base exception for DdiAdapter errors."""
 
class DdiAPIError(DdiAdapterError):
    """Raised when the Ddi API returns an error or unexpected payload"""
 
class ValidationError(DdiAdapterError):
    """Raised when a record fails basic validation."""
 
class Ddi:
    """
    Updated adapter to authenticate with Ddi Central (OAuth2)
    instead of Lighthouse.
    """
 
    def __init__(self, controller=None, job=None, base_url=None):
        self.ddi = controller
        self.job = job
 
        # Ddi API host (example: "apigw-uswest4.central.ddinetworks.com")
        self.api_host = self._get_ddi_host()
 
        # Refresh token login creds
        self.creds = self._get_creds_from_controller()  
        self.session = self._build_session()
 
        self.base_url = f"{self.api_host}"
 
        self.job.logger.info("Initialized DdiAdapter (api host: %s)", self.api_host)
 
    def _get_ddi_host(self):
        """Return Ddi Central API host stored in Nautobot secrets."""
        try:
            val = self.ddi.external_integration.remote_url
            if not val:
                raise DdiAdapterError("Empty Ddi API Host in secrets.")
            return val
        except Exception as exc:
            self.job.logger.exception("Failed to get ddi API Host")
            raise DdiAdapterError("Failed to get Ddi API Host") from exc
 
 
    def _get_creds_from_controller(self):
        """Fetch client_id, client_secret, refresh_token from controller."""
        try:
            secrets = {}
            secrets['username']=self.ddi.external_integration.secrets_group.get_secret_value(
                access_type = SecretsGroupAccessTypeChoices.TYPE_HTTP,
                secret_type = SecretsGroupSecretTypeChoices.TYPE_USERNAME
            )
            secrets['password']=self.ddi.external_integration.secrets_group.get_secret_value(
                access_type = SecretsGroupAccessTypeChoices.TYPE_HTTP,
                secret_type = SecretsGroupSecretTypeChoices.TYPE_PASSWORD
            )
           
            return secrets
        except Exception as exc:
            self.job.logger.exception(f"Failed to load Ddi Central secrets with error {exc}")
            raise DdiAdapterError(f"Failed to load Ddi Central secrets with {exc}") from exc
 
 
    # ---------------------------------------------------------------------
    # Build Requests session
    # ---------------------------------------------------------------------
    def _build_session(self) -> requests.Session:
        s = requests.Session()
        adapter = HTTPAdapter(max_retries=RETRY_STRATEGY)
        s.mount("https://", adapter)
        s.mount("http://", adapter)
        s.headers.update({"User-Agent": f"nautobot-ddi-adapter/{uuid.uuid4()}"})
        if getattr(self, "creds", None):
            s.auth = (self.creds["username"], self.creds["password"])
 
        return s
 
 
 