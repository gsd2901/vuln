from typing import Dict, Any
from nautobot_ssot_ddi.diffsync.utils.ddi import ValidationError

def debug_log(logger, debug, msg, *args):
    if debug:
        logger.debug(msg, *args)

def transform_record(raw: Dict[str, Any], logger,debug: bool = False) -> Dict[str, Any]:
    """
    Transform Ddi Central devices (Switches + APs)
    into unified DiffSync internal structure.
    """

    try:
        device_type = raw.get("device_type", "switch")  # default to switch

        # -------------------------
        # Shared fields
        # -------------------------
        record = {
            # "manufacturer": "Ddi",
            # "namespace": "Ddi",
            "prefix": raw.get("prefix"),
            "ip_address": raw.get("ip"),
            "internet_facing": False,
            # "role": raw.get("role"),
            "operational_status": raw.get("ip_status"),
            "vlanName":raw.get("vlanName")
        }

        # logger.debug(f" the record is {record}")
        debug_log(logger,debug,"the record is %s",record,)
        return record

    except Exception as exc:
        logger.exception("Failed to transform record: %s", raw)
        raise ValidationError("Failed to transform Ddi Central record") from exc
