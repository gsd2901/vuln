

# import xml.etree.ElementTree as ET
# import random

# def fetch_ddi_data(session, api_host, logger):
#     """
#     Fetch prefixes, VLANs, and IPv4 addresses from Infoblox.

#     Returns: list[dict] with keys:
#       prefix, vlanName, vid, ip, namespace, tenant, role, ip_status
#     """
#     records = []
#     namespace = "DDI"
#     tenant = "DDI"
#     role = "DDI"

#     # 1) Prefixes (networks)
#     net_url = f"{api_host}/wapi/v2.7/network?_return_fields=network&_max_results=1000"
#     logger.info(f"Fetching Infoblox prefixes: {net_url}")
#     resp = session.get(net_url, verify=False, timeout=10)
#     resp.raise_for_status()
#     networks = resp.json()  # JSON array

#     prefixes = [n["network"] for n in networks if "network" in n]
#     logger.info(f"Found {len(prefixes)} prefixes")

#     # 2) VLANs (flat list) – keep if you need mapping later
#     vlan_url = f"{api_host}/wapi/v2.7/vlan?_return_fields=id,name,parent,description&_max_results=1000"
#     logger.info(f"Fetching Infoblox VLANs: {vlan_url}")
#     resp = session.get(vlan_url, verify=False, timeout=10)
#     resp.raise_for_status()
#     vlans = resp.json()

#     vlan_map = {
#         int(v["id"]): v.get("name") or f"VLAN-{v['id']}"
#         for v in vlans
#         if "id" in v
#     }
#     logger.info(f"Found {len(vlan_map)} VLANs")

#     # 3) IPv4 addresses per prefix
#     for prefix in prefixes:
#         ip_url = (
#             f"{api_host}/wapi/v2.7/ipv4address"
#             f"?network_view=default&network={prefix}&_max_results=1000"
#         )
#         logger.info(f"Fetching IPs for prefix {prefix}: {ip_url}")
#         resp = session.get(ip_url, verify=False, timeout=10)
#         resp.raise_for_status()
#         ips = resp.json()

#         for ip_obj in ips:
#             ip = ip_obj.get("ip_address")
#             status = ip_obj.get("status")  # USED / UNUSED
#             if not ip:
#                 continue

#             records.append(
#                 {
#                     "prefix": prefix,
#                     # FIXED random.choice syntax:
#                     "vlanName": random.choice(
#                         ["Data-Site1", "Data-Site2", "Server-Vlan", "server-room"]
#                     ),
#                     "vid": None,
#                     "ip": ip,
#                     "ip_status": status or "UNUSED",
#                     "namespace": namespace,
#                     "tenant": tenant,
#                     "role": role,
#                 }
#             )

#     logger.info(f"Total Infoblox records built: {len(records)}")
#     return records

import logging
import re

import requests


NETWORK_RE = re.compile(r".*:(?P<cidr>[0-9\.]+/\d+)/default$")


def fetch_ddi_data(session: requests.Session, api_host: str, logger: logging.Logger,):
    """
    Fetch prefixes, VLANs, and IPv4 addresses from Infoblox.

    Returns: list[dict] with keys:
      prefix, vlanName, vid, ip, namespace, role, ip_status
    """
    records = []
    namespace = "DDI"
    role = "DDI"

    # 1) Prefixes (networks)
    net_url = f"{api_host}/wapi/v2.7/network?_return_fields=network&_max_results=1000"
    logger.info("Fetching Infoblox prefixes: %s", net_url)
    resp = session.get(net_url, verify=False, timeout=10)
    resp.raise_for_status()
    networks = resp.json()  # JSON array

    prefixes = [n["network"] for n in networks if "network" in n]

    # # 2) VLANs with assigned_to (for mapping to networks)
    # vlan_url = (
    #     f"{api_host}/wapi/v2.7/vlan"
    #     f"?_return_fields=id,name,parent,description,assigned_to&_max_results=1000"
    # )
    # logger.info("Fetching Infoblox VLANs: %s", vlan_url)
    # resp = session.get(vlan_url, verify=False, timeout=10)
    # resp.raise_for_status()
    # vlans = resp.json()  # list of VLAN objects

    # # Build mapping: network CIDR string -> (vlan_name, vlan_id) 

    network_to_vlan = {}
    vlans = []

    try:
        vlan_url = (
            f"{api_host}/wapi/v2.7/vlan"
            f"?_return_fields=id,name,parent,description,assigned_to&_max_results=1000"
        )

        logger.info("Fetching Infoblox VLANs: %s", vlan_url)

        resp = session.get(vlan_url, verify=False, timeout=10)

        if resp.status_code == 200:
            vlans = resp.json()

            for v in vlans:
                vlan_id = v.get("id")
                vlan_name = v.get("name") or f"VLAN-{vlan_id}"
                assigned_list = v.get("assigned_to") or []

                for assigned in assigned_list:
                    match = NETWORK_RE.match(assigned)
                    if match:
                        cidr = match.group("cidr")
                        network_to_vlan[cidr] = (vlan_name, vlan_id)

    except Exception as exc:
        logger.warning(
            "VLAN API not supported by this Infoblox instance. Skipping VLAN sync. Error: %s",
            exc,
        )

    # for v in vlans:
    #     vlan_id = v.get("id")
    #     vlan_name = v.get("name") or (f"VLAN-{vlan_id}" if vlan_id is not None else None)
    #     assigned_list = v.get("assigned_to") or []

    #     # Each assigned_to entry looks like:
    #     # "network/...:192.168.5.0/24/default"
    #     for assigned in assigned_list:
    #         match = NETWORK_RE.match(assigned)
    #         if not match:
    #             continue
    #         cidr = match.group("cidr")  # e.g. "192.168.5.0/24"
    #         # In case multiple VLANs somehow reference the same network,
    #         # first one wins; adjust if you want last-wins behavior.
    #         if cidr not in network_to_vlan:
    #             network_to_vlan[cidr] = (vlan_name, vlan_id)

    # 3) IPv4 addresses per prefix
    for prefix in prefixes:
        ip_url = (
            f"{api_host}/wapi/v2.7/ipv4address"
            f"?network_view=default&network={prefix}&_max_results=1000"
        )
        logger.info("Fetching IPs for prefix %s: %s", prefix, ip_url)
        resp = session.get(ip_url, verify=False, timeout=10)
        resp.raise_for_status()
        ips = resp.json()

        # Look up VLAN for this prefix, if any
        vlan_name = None
        vlan_id = None
        if prefix in network_to_vlan:
            vlan_name, vlan_id = network_to_vlan[prefix]

        for ip_obj in ips:
            ip = ip_obj.get("ip_address")
            status = ip_obj.get("status")  # USED / UNUSED
            if not ip:
                continue

            records.append(
                {
                    "prefix": prefix,
                    "vlanName": vlan_name,      # dynamically mapped or None
                    "vid": vlan_id,             # VLAN ID if available
                    "ip": ip,
                    "ip_status": status or "UNUSED",
                    "namespace": namespace,
                    "role": role,
                }
            )

    logger.info("Total Infoblox records built: %d", len(records))
    return records


# def fetch_vlan_data(session, api_host, logger):
#     records = []

#     vlan_url = f"{api_host}/wapi/v2.7/vlan?_return_fields=id,name,parent,description&_max_results=1000"
#     logger.info(f"Fetching Infoblox VLANs: {vlan_url}")
#     resp = session.get(vlan_url, verify=False, timeout=10)
#     resp.raise_for_status()
#     vlans = resp.json()

#     for v in vlans:
#         vid = v.get("id")
#         name = v.get("name")
#         if not vid:
#             continue
#         records.append(
#             {
#                 "vid": vid,
#                 "vlan_name": name or f"VLAN-{vid}",
#                 "status": "Active",
#             }
#         )

#     logger.info(f"Found {len(records)} VLANs")
#     return records


def fetch_vlan_data(session, api_host, logger):
    logger.warning(
        "VLAN API not supported by this Infoblox instance. Skipping VLAN sync."
    )
    return []