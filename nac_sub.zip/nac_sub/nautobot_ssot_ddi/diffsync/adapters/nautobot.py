from __future__ import annotations
import logging
from typing import Any, Dict, Iterable, List, Optional, Set
from django.db import transaction
from django.db.models import Prefetch
from diffsync import DiffSync
from nautobot.dcim.models import Device, DeviceType, Manufacturer, Interface, Platform, SoftwareVersion
from nautobot.ipam.models import IPAddress, Prefix, Namespace, VLAN, VRF
from nautobot.extras.models import Status, Role
from nautobot_ssot.contrib import NautobotAdapter

from nautobot_ssot_ddi.diffsync.models.nautobot import (
    NautobotDevice,
    NautobotDeviceType,
    NautobotManufacturer,
    NautobotIPAddress,
    NautobotInterface,
    NautobotStatus,
    NautobotPlatform,
    NautobotNameSpace,
    NautobotRole,
    NautobotPrefix,
    NautobotVlan,
    NautobotSoftwareVersion,
)

DEFAULT_BATCH_SIZE = 1000


def _safe_str(obj: Optional[object]) -> str:
    return str(obj) if obj is not None else ""


class DdiSSOtNautobotAdapter(NautobotAdapter):
    """
    DiffSync adapter that loads Nautobot data into DiffSync models.

    This adapter performs *read-only* operations against the Nautobot ORM
    and converts database objects into DiffSync-compatible models.

    Key responsibilities:
        - Extract objects from Nautobot database
        - Normalize relationships into string-based references
        - Populate DiffSync graph for comparison/synchronization

    Notes:
        - Relationships that cannot be resolved are skipped.
        - Exceptions during object transformation are logged and ignored.
    """

    device = NautobotDevice
    device_type = NautobotDeviceType
    manufacturer = NautobotManufacturer
    ipaddress = NautobotIPAddress
    interface = NautobotInterface
    status = NautobotStatus
    platform = NautobotPlatform
    namespace = NautobotNameSpace
    role = NautobotRole
    prefix = NautobotPrefix
    vlan = NautobotVlan
    software_version = NautobotSoftwareVersion

    top_level = {
        "status",
        "vlan",
        "prefix",
        "ipaddress",
        "platform", 
        "interface",
        "manufacturer",
        "device_type",
    }

    def __init__(self, ddi, debug=False, *args, batch_size: int = DEFAULT_BATCH_SIZE, **kwargs):
        
        """
        Initialize the Nautobot DiffSync adapter.

        Args:
            mobilityconductor (Optional[Controller]): Controller used to filter managed devices.
            debug (bool): Enable debug logging.
            batch_size (int, optional): Number of records to process in batches.
            *args: Additional positional args passed to parent.
            **kwargs: Additional keyword args passed to parent.
        """

        super().__init__(*args, **kwargs)
        self._backend = "Nautobot"
        self.batch_size = batch_size
        self.ddi = ddi
        self.debug = debug

    def debug_log(self, message, *args):
        if self.debug:
            self.job.logger.debug(message, *args)

    def load_manufacturers(self):
        for mfg in Manufacturer.objects.all():
            self.add(self.manufacturer(name=mfg.name))

    def load_device_type(self):
        for dt in DeviceType.objects.select_related("manufacturer"):
            self.add(
                self.device_type(
                    model=dt.model,
                    manufacturere__name=dt.manufacturer.name if dt.manufacturer else None,
                    device_family=dt.device_family.name if dt.device_family else None,
                )
            )

    def load_statuses(self):
        for st in Status.objects.all():
            self.add(self.status(name=st.name))

    def load_platforms(self):
        for platform_obj in Platform.objects.all():
            self.add(self.platform(name=platform_obj.name))
            
    def load_devices(self):
        # If controller selected, filter based on its managed device group
        if self.ddi:
            try:
                md_group = self.ddi.managed_device_group
                qs = Device.objects.filter(managed_device_group=md_group)
            except Exception:
                qs = Device.objects.none()
        else:
            qs = Device.objects.all()

        qs = qs.select_related("device_type", "platform", "status")

        for device_obj in qs:
            self.add(
                self.device(
                    name=device_obj.name,
                    serial=device_obj.serial,
                    device_type__model=device_obj.device_type.model if device_obj.device_type else None,
                    platform__name=device_obj.platform.name if device_obj.platform else None,
                    status__name=device_obj.status.name if device_obj.status else None,
                    primary_ip4__host=str(device_obj.primary_ip4) if device_obj.primary_ip4 else None,
                    primary_ip6__host=str(device_obj.primary_ip6) if device_obj.primary_ip6 else None,
                )
            )

    def load_interfaces(self):
        for intf in Interface.objects.select_related("device", "status"):
            try:
                self.add(
                    self.interface(
                        device__name=intf.device.name if intf.device else None,
                        name=intf.name,
                        enabled=intf.enabled,
                        type=intf.type,
                        description=intf.description,
                        status=intf.status.name if intf.status else None,
                    )
                    )
            except Exception as e:
                continue
        

    # def load_ipaddresss(self):
    #     self.debug_log(f"here is the load of nautobot")
    #     for ip in IPAddress.objects.select_related(
    #         "parent",  "status", "role"
    #     ):
    #         try:
    #             interface_name = None
    #             device_name = None
    #             self.job.logger.info(f"the device_name is  {device_name}")
    #             if hasattr(ip, "assigned_object") and isinstance(
    #                 ip.assigned_object, Interface
    #             ):
    #                 interface_name = ip.assigned_object.name
    #                 device_name = (
    #                     ip.assigned_object.device.name
    #                     if ip.assigned_object.device
    #                     else None
    #                 )
    #             elif hasattr(ip, "device") and ip.device:
    #                 device_name = ip.device.name
    #             self.job.logger.info(f"the device_name is  {device_name}")
    #             self.add(
    #                 self.ipaddress(
    #                     host=str(ip.host),
    #                     mask_length=ip.mask_length,
    #                     namespace=(
    #                         ip.parent.namespace.name
    #                         if getattr(ip, "parent", None) and ip.parent.namespace
    #                         else None
    #                     ),
    #                     status=ip.status.name if ip.status else None,
    #                     role__name=ip.role.name if ip.role else None,
    #                     interface__name=interface_name,
    #                     device__name=device_name,
    #                     tenant=ip.tenant.name if getattr(ip, "tenant", None) else None,
    #                 )
    #             )
    #         except Exception as e:
    #             self.job.logger.info(f"the errpr is : {e}")

    def load_ipaddresss(self):
        self.debug_log("here is the load of nautobot")
        for ip in IPAddress.objects.select_related(
            "status", "role", "parent", "nat_inside"
        ):
            try:
                interface_name = None
                device_name = None
                
                if hasattr(ip, "assigned_object") and isinstance(ip.assigned_object, Interface):
                    interface_name = ip.assigned_object.name
                    device_name = ip.assigned_object.device.name if ip.assigned_object.device else None
                elif hasattr(ip, "device") and ip.device:
                    device_name = ip.device.name

                # As before, namespace safe check
                namespace_name = (
                    ip.parent.namespace.name
                    if getattr(ip, "parent", None)
                    and getattr(ip.parent, "namespace", None)
                    else None
                )

                self.add(
                    self.ipaddress(
                        host=str(ip.host),
                        mask_length=ip.mask_length,
                        status=ip.status.name if ip.status else None,
                    )
                )
                self.job.logger.info("Loaded IP Address: %s",ip.host,)
            except Exception as e:
                self.job.logger.error(f"the error is : {e}")




    # def load_ipaddresss(self):
    #     self.debug_log(f"here is the load of nautobot")
    #     qs = (
    #         IPAddress.objects.select_related(
    #             "parent",
    #             "parent_namespace",
    #             "status",
    #             "role",
    #             "tenant",
    #         )
    #         .prefetch_related(
    #             "interfaces__device",
    #             "vm_interfaces__virtual_machine",
    #             "primary_ip4_for",
    #             "primary_ip6_for",
    #         )
    #     )

    #     for ip in qs:
    #         self.debug_log(f"here is the load of nautobot {ip}")
    #         try:
    #             interface_name = None
    #             device_name = None

    #             # 1) Physical interfaces (preferred)
    #             self.debug_log(f"here is the load of nautobot 263")
    #             if hasattr(ip, "interfaces") and ip.interfaces.exists():
    #                 iface = ip.interfaces.first()
    #                 if isinstance(iface, Interface) and iface.device:
    #                     interface_name = iface.name
    #                     device_name = iface.device.name

    #             # 2) VM interfaces if no physical interface
    #             self.debug_log(f"here is the load of nautobot 271")
    #             if not device_name and hasattr(ip, "vm_interfaces") and ip.vm_interfaces.exists():
    #                 vm_iface = ip.vm_interfaces.first()
    #                 if vm_iface and vm_iface.virtual_machine:
    #                     interface_name = vm_iface.name
    #                     device_name = vm_iface.virtual_machine.name

    #             # 3) Fallback: devices/VMs for which this is primary IP
    #             if not device_name and hasattr(ip, "primary_ip4_for") and ip.primary_ip4_for.exists():
    #                 primary4 = ip.primary_ip4_for.first()
    #                 if primary4:
    #                     device_name = primary4.name

    #             if not device_name and hasattr(ip, "primary_ip6_for") and ip.primary_ip6_for.exists():
    #                 primary6 = ip.primary_ip6_for.first()
    #                 if primary6:
    #                     device_name = primary6.name

    #             self.job.logger.info(f"IP {ip.host}: device={device_name}, interface={interface_name}")
    #             self.debug_log(f"here is the load of nautobot 290")
    #             self.add(
    #                 self.ipaddress(
    #                     host=str(ip.host),
    #                     mask_length=ip.mask_length,
    #                     namespace=(
    #                         ip.parent.namespace.name
    #                         if getattr(ip, "parent", None) and getattr(ip.parent, "namespace", None)
    #                         else None
    #                     ),
    #                     status=ip.status.name if ip.status else None,
    #                     role__name=ip.role.name if ip.role else None,
    #                     interface__name=interface_name,
    #                     device__name=device_name,  # This is SAFE now
    #                     tenant=ip.tenant.name if getattr(ip, "tenant", None) else None,
    #                 )
    #             )
    #         except Exception as e:
    #             self.job.logger.error(f"Failed IP {getattr(ip, 'host', 'unknown')}: {e}")
    #             continue

    def load_prefixs(self):
        """
            Load Prefix objects from Nautobot into NautobotPrefix DiffSync models.
        """
        # Adjust select_related fields to your actual Prefix model fields
        qs = Prefix.objects.select_related("namespace", "vlan", "status")

        for pfx in qs:
            try:
                self.add(
                    self.prefix(
                        prefix=str(pfx.prefix) if pfx.prefix else None,
                        vlan__name=pfx.vlan.name if getattr(pfx, "vlan", None) else None,
                    )
                )
                self.job.logger.info("Loaded Prefix: %s",pfx.prefix,)
            except Exception as e:
                # Optional logging
                self.job.logger.info(f"the error message is : {e}")
                if hasattr(self, "job") and self.job:
                    self.job.logger.error(f"Failed to load prefix {getattr(pfx, 'prefix', None)}: {e}")
                continue

    def load_vlans(self):
        """
        Load VLAN objects from Nautobot into NautobotVlan DiffSync models.
        """
        qs = VLAN.objects.select_related("status")
        
        self.job.logger.info(f"the vlans coming in db")
        for vlan in qs:
            try:
                self.add(
                    self.vlan(
                        vid=vlan.vid,
                        name=vlan.name,
                        status_id=str(vlan.status.pk) if getattr(vlan, "status", None) else None,
                    )
                )
                self.job.logger.info("Loaded VLAN: vid=%s name=%s",vlan.vid,vlan.name,)
            except Exception as e:
                self.job.logger.info(f"the error message in vlan is {e}")
                if hasattr(self, "job") and self.job:
                    self.job.logger.error(f"Failed to load VLAN {getattr(vlan, 'vid', None)}: {e}")
                continue


    def load(self):
        self.debug_log(f"here is the load of nautobot")
        for model_name in self.top_level:
            self.debug_log(f"here is the load of nautobot with model {model_name}")
            loader = getattr(self, f"load_{model_name}s", None)
            if loader:
                loader()
            else:
                self.debug_log(f"here is the load of nautobot with model {model_name} in else block")
                diffsync_cls = getattr(self, model_name)
                self._load_objects(diffsync_cls)
