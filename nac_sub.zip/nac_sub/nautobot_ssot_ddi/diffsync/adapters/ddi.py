from __future__ import annotations
from typing import Any, Dict, Iterable, Optional, Set
import ipaddress

from diffsync import Adapter
from nautobot.dcim.models import Controller

from nautobot_ssot_ddi.diffsync.utils.ddi import fetch_devices as fetch
from nautobot_ssot_ddi.diffsync.utils.ddi import transformer as transform
from nautobot_ssot_ddi.diffsync.utils.ddi import Ddi

from nautobot_ssot_ddi.diffsync.models.ddi import (
    DdiDevice,
    DdiDeviceType,
    DdiManufacturer,
    DdiIPAddress,
    DdiInterface,
    DdiStatus,
    DdiPlatform,
    DdiNameSpace,
    DdiRole,
    DdiPrefix,
    DdiVlan,
)

class DdiAdapterError(Exception):
    """Base exception for DdiAdapter errors."""
 
class DdiAPIError(DdiAdapterError):
    """
    Exception raised when the Mobility Conductor API returns:
    - An error response
    - Unexpected or malformed payload
    """
    pass


class ValidationError(DdiAdapterError):
    """
    Exception raised when input or transformed data fails validation checks.
    """
    pass

class DdiAdapter(Adapter):
    """
    DiffSync adapter for DDI -> Nautobot.
    """

    def debug_log(self, message, *args):
        if self.debug:
            self.job.logger.debug(message, *args)

    def ensure_manufacturer(self, name: str):
        name = name or "unknown"
        self._add_if_missing(self.manufacturer, "name", name, name=name)

    def ensure_device_type(self, model: str):
        model = model or "unknown"
        self._add_if_missing(self.device_type, "model", model, model=model)

    device = DdiDevice
    device_type = DdiDeviceType
    manufacturer = DdiManufacturer
    ipaddress = DdiIPAddress
    interface = DdiInterface
    status = DdiStatus
    platform = DdiPlatform
    namespace = DdiNameSpace
    role = DdiRole
    prefix = DdiPrefix
    vlan = DdiVlan

    top_level = {
        "status",
        "vlan",
        "prefix",
        "ipaddress",
    }

    def __init__(self, **kwargs):
        name = kwargs.get('name', 'ddi')
        super().__init__(name)
        self.job = kwargs.get('job')
        self.ddi = kwargs.get('ddi')
        self.debug = kwargs.get("debug", False)
        base_url = kwargs.get('base_url')
        self.ddi_object = Ddi(self.ddi, self.job, base_url)
        self.session = self.ddi_object.session
        self.url = self.ddi_object.base_url

    def debug_log(self, message, *args):
        if self.debug:
            self.job.logger.debug(message, *args)

    # ------------------ Fetch/transform ------------------

    import requests
    def fetch_from_ddi(self):
        self.debug_log("Here we are calling fetch_from_ddi")
        return fetch.fetch_ddi_data(self.session, self.url, self.job.logger)

    def fetch_vlan_from_ddi(self):
        return fetch.fetch_vlan_data(self.session, self.url, self.job.logger)

    def transform_ddi_record(self, raw):
        return transform.transform_record(raw, self.job.logger, self.debug)

    # ------------------ Helpers ------------------

    def _get_objects_of_type(self, obj_type_callable) -> Iterable:
        try:
            type_name = obj_type_callable.__name__
            objs = []
            if hasattr(self, "_objects") and type_name in self._objects:
                objs = list(self._objects[type_name].values())
            return objs
        except Exception:
            return []

    def _add_if_missing(
        self, obj_type_callable, identifier_field: str, identifier_value: Any, **kwargs
    ):
        existing_values = {
            getattr(o, identifier_field)
            for o in self._get_objects_of_type(obj_type_callable)
        }
        if identifier_value in existing_values:
            self.debug_log(
                "Skipping add of %s-%s; already present",
                identifier_field,
                identifier_value,
            )
            return
        self.debug_log("Adding object %s-%s", identifier_field, identifier_value)
        self.add(obj_type_callable(**kwargs))

    # ------------------ Entity helpers ------------------

    def ensure_status(self, name: str):
        name = name or "unknown"
        self._add_if_missing(self.status, "name", name, name=name)

    def ensure_platform(self, name: str):
        name = name or "unknown"
        self._add_if_missing(self.platform, "name", name, name=name)

    def ensure_prefix(
        self,
        prefix: str,
        vlan: str,
    ):
        """
        Create a DdiPrefix object with a simple 'prefix' string and related metadata.
        DdiPrefix on the source side can keep 'prefix' as a single field; the Nautobot
        adapter will split it into network/prefix_length later.[web:175][web:166]
        """
        prefix = prefix or "0.0.0.0/0"
        self._add_if_missing(
            self.prefix,
            "prefix",
            prefix,
            prefix=prefix,
            vlan__name=vlan,
        )

    def add_ip_if_new(
        self,
        ip_address: str,
        status: str,
    ):
        if not ip_address:
            return
        existing_addrs = {
            getattr(x, "address", None)
            for x in self._get_objects_of_type(self.ipaddress)
        }
        if ip_address in existing_addrs:
            self.debug_log("Skipping ip %s (already added)", ip_address)
            return

        # ip_address should include prefix length, e.g. "192.168.1.1/24".[web:236]
        self.add(
            self.ipaddress(
                host=ip_address,
                status=status,
                
            )
        )

    # ------------------ Main load flow ------------------

    def load(self):
        """
        Fetch DDI data and seed DiffSync objects.
        """
        self.debug_log("Calling DdiAdapter.load()")
        nodes = self.fetch_from_ddi()
        vlans = self.fetch_vlan_from_ddi()
        # self.debug_log(f"the vlans are {vlans}")
        records = [self.transform_ddi_record(n) for n in nodes]

        seen_statuses: Set[str] = set()
        seen_prefixes: Set[str] = set()
        seen_ipaddresses: Set[str] = set()
        seen_vlans: Set[str] = set()

        for r in records:
            if r["operational_status"] not in seen_statuses:
                self.ensure_status(r["operational_status"])
                seen_statuses.add(r["operational_status"])

            # Prefix from DDI
            if r["prefix"] not in seen_prefixes:
                self.ensure_prefix(
                    prefix=r["prefix"],
                    vlan=r["vlanName"],
                )
                seen_prefixes.add(r["prefix"])

            # IPs from DDI
            if r["ip_address"] not in seen_ipaddresses:
                self.debug_log(f"the ******* ip_address is : {r['ip_address']}")
                try:
                    self.add_ip_if_new(
                        ip_address=r["ip_address"],
                        status=r["operational_status"],
                    )
                    seen_ipaddresses.add(r["ip_address"])
                except:
                    continue

        # VLANs from DDI (flat)
        if vlans:
            for vr in vlans:
                self.job.logger.info(f"the vlan is {vr}")
                if vr["vlan_name"] not in seen_vlans:

                    try:
                        self.add(
                            self.vlan(
                                vid=vr["vid"],
                                name=vr["vlan_name"],
                                status_id=vr["status"],
                            )
                        )
                        seen_vlans.add(vr["vlan_name"])
                        self.job.logger.info(f"the vlans are added in ddi adapter")
                    except Exception as e:
                        self.job.logger.warning(
                            "Failed to add VLAN %s: %s", vr["vlan_name"], e
                        )
                        continue
                else:
                    self.job.logger.info(f"the vlan is not added due to :{seen_vlans} {vr}")
        else:
            self.job.logger.info(f"there are no vlans :******************************")

        self.job.logger.info("DDI load complete: %d records processed", len(records))
