from typing import ClassVar, Optional

from diffsync.enum import DiffSyncModelFlags
from nautobot_ssot.contrib import NautobotModel

from nautobot.dcim.models import (
    Device,
    DeviceType,
    Interface,
    Manufacturer,
    Platform,
    SoftwareVersion,
)

from nautobot.extras.models import Role, Status

from nautobot.ipam.models import (
    IPAddress,
    Namespace,
    Prefix,
    VLAN,
)


# ==================================================
# MANUFACTURER
# ==================================================

class NautobotManufacturer(NautobotModel):
    flags: ClassVar = DiffSyncModelFlags.SKIP_UNMATCHED_DST

    _model = Manufacturer
    _modelname = "manufacturer"

    _identifiers = ("name",)
    _attributes = ()

    name: Optional[str] = None

# ==================================================
# DEVICE
# ==================================================

class NautobotDevice(NautobotModel):
    flags: ClassVar = DiffSyncModelFlags.SKIP_UNMATCHED_DST

    _model = Device
    _modelname = "device"

    _identifiers = ("name",)

    _attributes = (
        "serial",
        "device_type__model",
        "platform__name",
        "status__name",
        "primary_ip4__host",
        "primary_ip6__host",
    )

    name: Optional[str] = None
    serial: Optional[str] = None

    device_type__model: Optional[str] = None
    platform__name: Optional[str] = None
    status__name: Optional[str] = None

    primary_ip4__host: Optional[str] = None
    primary_ip6__host: Optional[str] = None


# ==================================================
# DEVICE TYPE
# ==================================================

class NautobotDeviceType(NautobotModel):
    flags: ClassVar = DiffSyncModelFlags.SKIP_UNMATCHED_DST

    _model = DeviceType
    _modelname = "device_type"

    _identifiers = ("model",)
    _attributes = ()

    model: str


# ==================================================
# STATUS
# ==================================================

class NautobotStatus(NautobotModel):
    flags: ClassVar = DiffSyncModelFlags.SKIP_UNMATCHED_DST

    _model = Status
    _modelname = "status"

    _identifiers = ("name",)
    _attributes = ()

    name: str


# ==================================================
# PLATFORM
# ==================================================

class NautobotPlatform(NautobotModel):
    flags: ClassVar = DiffSyncModelFlags.SKIP_UNMATCHED_DST

    _model = Platform
    _modelname = "platform"

    _identifiers = ("name",)
    _attributes = ()

    name: str


# ==================================================
# ROLE
# ==================================================

class NautobotRole(NautobotModel):
    flags: ClassVar = DiffSyncModelFlags.SKIP_UNMATCHED_DST

    _model = Role
    _modelname = "role"

    _identifiers = ("name",)
    _attributes = ()

    name: str


# ==================================================
# SOFTWARE VERSION
# ==================================================

class NautobotSoftwareVersion(NautobotModel):
    """
    Represents a unique software version.
    Example: 8.10.0.17_92670
    """

    flags: ClassVar = DiffSyncModelFlags.SKIP_UNMATCHED_DST

    _model = SoftwareVersion
    _modelname = "software_version"

    _identifiers = (
        "version",
        "platform__name",
    )

    _attributes = ("status",)

    version: str
    platform__name: str
    status: Optional[str] = None


# ==================================================
# NAMESPACE
# ==================================================

class NautobotNameSpace(NautobotModel):
    """
    Namespace model.
    """

    flags: ClassVar = DiffSyncModelFlags.SKIP_UNMATCHED_DST

    _model = Namespace
    _modelname = "namespace"

    _identifiers = ("name",)
    _attributes = ()

    name: str


# ==================================================
# IP ADDRESS
# ==================================================

class NautobotIPAddress(NautobotModel):
    flags: ClassVar = DiffSyncModelFlags.SKIP_UNMATCHED_DST

    _model = IPAddress
    _modelname = "ipaddress"

    _identifiers = ("host",)

    _attributes = (
        "status",
    )

    host: Optional[str] = None
    status: Optional[str] = None
    role__name: Optional[str] = None
    namespace: Optional[str] = None


# ==================================================
# PREFIX
# ==================================================

class NautobotPrefix(NautobotModel):
    """
    Prefix model.
    """

    flags: ClassVar = DiffSyncModelFlags.SKIP_UNMATCHED_DST

    _model = Prefix
    _modelname = "prefix"

    _identifiers = (
        "prefix",
    )

    _attributes = (
        "vlan__name",
    )

    prefix: Optional[str] = None
    namespace: Optional[str] = None
    vlan__name: Optional[str] = None
    status: Optional[str] = None


# ==================================================
# VLAN
# ==================================================

class NautobotVlan(NautobotModel):
    """
    VLAN model.
    """

    flags: ClassVar = DiffSyncModelFlags.SKIP_UNMATCHED_DST

    _model = VLAN
    _modelname = "vlan"

    _identifiers = ("vid",)

    _attributes = (
        "name",
        "status_id",
    )

    vid: int
    name: str
    status_id: str


# ==================================================
# INTERFACE
# ==================================================

class NautobotInterface(NautobotModel):
    flags: ClassVar = DiffSyncModelFlags.SKIP_UNMATCHED_DST

    _model = Interface
    _modelname = "interface"

    _identifiers = (
        "device__name",
        "name",
    )

    _attributes = (
        "enabled",
        "type",
        "description",
        "status",
    )

    device__name: Optional[str] = None
    name: str
    enabled: bool
    type: str
    description: str
    status: str

