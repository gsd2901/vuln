from nautobot_ssot_ddi.diffsync.models.base import (
    NautobotDevice,
    NautobotDeviceType,
    NautobotManufacturer,
    NautobotIPAddress,
    NautobotInterface,
    NautobotStatus,
    NautobotPlatform,
    NautobotNameSpace,
    NautobotRole,
    NautobotPrefix,
    NautobotVlan,
    NautobotSoftwareVersion,
)


class DdiDevice(NautobotDevice):
    """DDI implementation of Device model."""


class DdiDeviceType(NautobotDeviceType):
    """DDI implementation of DeviceType model."""


class DdiManufacturer(NautobotManufacturer):
    """DDI implementation of Manufacturer model."""


class DdiIPAddress(NautobotIPAddress):
    """DDI implementation of IPAddress model."""


class DdiInterface(NautobotInterface):
    """DDI implementation of Interface model."""


class DdiStatus(NautobotStatus):
    """DDI implementation of Status model."""


class DdiPlatform(NautobotPlatform):
    """DDI implementation of Platform model."""


class DdiNameSpace(NautobotNameSpace):
    """DDI implementation of Namespace model."""


class DdiRole(NautobotRole):
    """DDI implementation of Role model."""


class DdiPrefix(NautobotPrefix):
    """DDI implementation of Prefix model."""


class DdiVlan(NautobotVlan):
    """DDI implementation of VLAN model."""


class DdiSoftwareVersion(NautobotSoftwareVersion):
    """DDI implementation of Software Version model."""
