"""
nautobot.py

Target DiffSync models that implement create/update operations.

All database operations are delegated to:
    nautobot_ssot_ddi.diffsync.utils.nautobot
"""

from __future__ import annotations

from typing import Any, Dict

from diffsync import exceptions as diffsync_exceptions

from nautobot_ssot_ddi.diffsync.models.base import (
    NautobotDevice,
    NautobotDeviceType,
    NautobotManufacturer,
    NautobotIPAddress,
    NautobotInterface,
    NautobotStatus,
    NautobotPlatform,
    NautobotRole,
    NautobotNameSpace,
    NautobotPrefix,
    NautobotVlan,
    NautobotSoftwareVersion,
)

from nautobot_ssot_ddi.diffsync.utils.nautobot import Nautobot

Nautobot = Nautobot()


# # ==================================================
# # MANUFACTURER
# # ==================================================

# class NautobotManufacturer(NautobotManufacturer):
#     _modelname = "manufacturer"

#     @classmethod
#     def create(cls, adapter, ids: Dict[str, Any], attrs: Dict[str, Any]):
#         try:
#             Nautobot.create_manufacturer(adapter, ids, attrs)
#             return cls(**ids, **attrs)
#         except Exception as exc:
#             adapter.job.logger.error(
#                 "Manufacturer creation failed: %s", exc
#             )
#             raise diffsync_exceptions.ObjectNotCreated

#     def update(self, attrs: Dict[str, Any]):
#         try:
#             Nautobot.update_manufacturer(self, attrs)
#             return self
#         except Exception as exc:
#             self.adapter.job.logger.error(
#                 "Manufacturer update failed: %s", exc
#             )
#             raise diffsync_exceptions.ObjectNotCreated

# # ==================================================
# # DEVICE
# # ==================================================
# class NautobotDevice(NautobotDevice):
#     _modelname = "device"

#     @classmethod
#     def create(cls, adapter, ids: Dict[str, Any], attrs: Dict[str, Any]):
#         try:
#             dev = Nautobot.create_device(adapter, ids, attrs)
#             if dev :
#                 return cls(**ids,**attrs)
#             else:
#                 adapter.job.logger.error(f"Device Creation failed")
#         except Exception as e:
#             # adapter.job.logger.error(f"Execution failed with following exception : {e}")
#             raise diffsync_exceptions.ObjectNotCreated(f" Device creation failed {str(e)} ") from e

#     def update(self, attrs: Dict[str, Any]):
#         try:
#             dev = Nautobot.update_device(self, attrs)
#             if dev:
#                 return self
#             else:
#                 self.adapter.job.logger.error(f"Device updation failed")
#         except Exception as e:
#             # adapter.job.logger.error(f"Execution failed with following exception : {e}")
#             raise diffsync_exceptions.ObjectNotCreated(f" Device creation failed {str(e)} ") from e
        
# # ==================================================
# # DEVICE TYPE
# # ==================================================

# class NautobotDeviceType(NautobotDeviceType):
#     _modelname = "device_type"

#     @classmethod
#     def create(cls, adapter, ids: Dict[str, Any], attrs: Dict[str, Any]):
#         try:
#             Nautobot.create_device_type(adapter, ids, attrs)
#             return cls(**ids)
#         except Exception:
#             raise diffsync_exceptions.ObjectNotCreated

#     def update(self, attrs: Dict[str, Any]):
#         try:
#             Nautobot.update_device_type(self, attrs)
#             return self
#         except Exception:
#             raise diffsync_exceptions.ObjectNotCreated


# # ==================================================
# # STATUS
# # ==================================================

# class NautobotStatus(NautobotStatus):
#     _modelname = "status"

#     @classmethod
#     def create(cls, adapter, ids: Dict[str, Any], attrs: Dict[str, Any]):
#         try:
#             Nautobot.create_status(adapter, ids, attrs)
#             return cls(**ids, **attrs)
#         except Exception as exc:
#             adapter.job.logger.error(
#                 "Status creation failed: %s", exc
#             )
#             raise diffsync_exceptions.ObjectNotCreated

#     def update(self, attrs: Dict[str, Any]):
#         try:
#             Nautobot.update_status(self, attrs)
#             return self
#         except Exception as exc:
#             self.adapter.job.logger.error(
#                 "Status update failed: %s", exc
#             )
#             raise diffsync_exceptions.ObjectNotCreated


# # ==================================================
# # PLATFORM
# # ==================================================

# class NautobotPlatform(NautobotPlatform):
#     _modelname = "platform"

#     @classmethod
#     def create(cls, adapter, ids: Dict[str, Any], attrs: Dict[str, Any]):
#         try:
#             Nautobot.create_platform(adapter, ids, attrs)
#             return cls(**ids)
#         except Exception as exc:
#             adapter.job.logger.error(
#                 "Platform creation failed: %s", exc
#             )
#             raise diffsync_exceptions.ObjectNotCreated

#     def update(self, attrs: Dict[str, Any]):
#         try:
#             Nautobot.update_platform(self, attrs)
#             return self
#         except Exception:
#             raise diffsync_exceptions.ObjectNotCreated


# # ==================================================
# # ROLE
# # ==================================================

# class NautobotRole(NautobotRole):
#     _modelname = "role"

#     @classmethod
#     def create(cls, adapter, ids: Dict[str, Any], attrs: Dict[str, Any]):
#         try:
#             Nautobot.create_role(adapter, ids, attrs)
#             return cls(**ids)
#         except Exception:
#             raise diffsync_exceptions.ObjectNotCreated

#     def update(self, attrs: Dict[str, Any]):
#         try:
#             Nautobot.update_role(self, attrs)
#             return self
#         except Exception:
#             raise diffsync_exceptions.ObjectNotCreated


# # ==================================================
# # SOFTWARE VERSION
# # ==================================================

# class NautobotSoftwareVersion(NautobotSoftwareVersion):
#     _modelname = "software_version"

#     @classmethod
#     def create(cls, adapter, ids: Dict[str, Any], attrs: Dict[str, Any]):
#         try:
#             Nautobot.create_software_version(
#                 adapter,
#                 ids,
#                 attrs,
#             )
#             return cls(**ids)
#         except Exception:
#             raise diffsync_exceptions.ObjectNotCreated


# # ==================================================
# # NAMESPACE
# # ==================================================

# class NautobotNameSpace(NautobotNameSpace):
#     _modelname = "namespace"

#     @classmethod
#     def create(cls, adapter, ids: Dict[str, Any], attrs: Dict[str, Any]):
#         try:
#             Nautobot.create_namespace(
#                 adapter,
#                 ids,
#                 attrs,
#             )
#             return cls(**ids)
#         except Exception:
#             raise diffsync_exceptions.ObjectNotCreated

#     def update(self, attrs: Dict[str, Any]):
#         try:
#             Nautobot.update_namespace(
#                 self,
#                 attrs,
#             )
#             return self
#         except Exception:
#             raise diffsync_exceptions.ObjectNotCreated

# # ==================================================
# # PREFIX
# # ==================================================

# class NautobotPrefix(NautobotPrefix):
#     _modelname = "prefix"

#     @classmethod
#     def create(cls, adapter, ids: Dict[str, Any], attrs: Dict[str, Any]):
#         try:
#             Nautobot.create_prefix(
#                 adapter,
#                 ids,
#                 attrs,
#             )
#             return cls(**ids)
#         except Exception:
#             raise diffsync_exceptions.ObjectNotCreated

#     def update(self, attrs: Dict[str, Any]):
#         try:
#             Nautobot.update_prefix(
#                 self,
#                 attrs,
#             )
#             return self
#         except Exception:
#             raise diffsync_exceptions.ObjectNotCreated

# # ==================================================
# # IP ADDRESS
# # ==================================================

# class NautobotIPAddress(NautobotIPAddress):
#     _modelname = "ipaddress"

#     @classmethod
#     def create(cls, adapter, ids: Dict[str, Any], attrs: Dict[str, Any]):
#         try:
#             ip = Nautobot.create_ipaddress(adapter, ids, attrs)
#             if ip:
#                 return cls(**ids,**attrs)
#             else:
#                 adapter.job.logger.error(f'Failed to create IP Address {ids.get("host")}')
#                 #raise diffsync_exceptions.ObjectNotCreated("Ip Address creation failed ")
#             adapter.job.logger.info(f"the ipaddress created")
#         except Exception as e:
#             cls.adapter.job.logger.error(f"Execution failed with following exception : {e}")
#             raise diffsync_exceptions.ObjectNotCreated(f"Ip address creation failed {str(e)}") from e

#     def update(self, attrs: Dict[str, Any]):
#         try:
#             ip = Nautobot.update_ipaddress(self, attrs)
#             if ip:
#                 return self
#             else:
#                 self.adapter.job.logger.error("failed to update Ip address")
#         except Exception as e:
#             # adapter.job.logger.error(f"Execution failed with following exception : {e}")
#             raise diffsync_exceptions.ObjectNotCreated(f"ip address updation failed {str(e)}") from e


# # ==================================================
# # VLAN
# # ==================================================

# class NautobotVlan(NautobotVlan):
#     _modelname = "vlan"

#     @classmethod
#     def create(cls, adapter, ids: Dict[str, Any], attrs: Dict[str, Any]):
#         try:
#             Nautobot.create_vlan(
#                 adapter,
#                 ids,
#                 attrs,
#             )
#             return cls(**ids)
#         except Exception:
#             raise diffsync_exceptions.ObjectNotCreated

#     def update(self, attrs: Dict[str, Any]):
#         try:
#             Nautobot.update_vlan(
#                 self,
#                 attrs,
#             )
#             return self
#         except Exception:
#             raise diffsync_exceptions.ObjectNotCreated

class NautobotManufacturer(NautobotManufacturer):
    _modelname = "manufacturer"

    @classmethod
    def create(cls, adapter, ids: Dict[str, Any], attrs: Dict[str, Any]):
        try:
            Nautobot.create_manufacturer(adapter, ids, attrs)
            return cls(**ids,**attrs)
        except Exception as e:
            adapter.job.logger.error(f"Execution failed with following exception : {e}")
            raise diffsync_exceptions.ObjectNotCreated

    def update(self, attrs: Dict[str, Any]):
        try:
            Nautobot.update_manufacturer(self, attrs)
            return self
        except Exception as e:
            self.adapter.job.logger.error(f"Execution failed with following exception : {e}")
            raise diffsync_exceptions.ObjectNotCreated


class NautobotDeviceType(NautobotDeviceType):
    _modelname = "device_type"

    @classmethod
    def create(cls, adapter, ids: Dict[str, Any], attrs: Dict[str, Any]):
        try:
            Nautobot.create_device_type(adapter, ids, attrs)
            return cls(**ids)
        except Exception as e:
            raise diffsync_exceptions.ObjectNotCreated

    def update(self, attrs: Dict[str, Any]):
        try:
            Nautobot.update_device_type(self, attrs)
            return self
        except Exception as e:
            self.adapter.job.logger.error(f"Execution failed with following exception : {e}")
            raise diffsync_exceptions.ObjectNotCreated


class NautobotStatus(NautobotStatus):
    _modelname = "status"

    @classmethod
    def create(cls, adapter, ids: Dict[str, Any], attrs: Dict[str, Any]):
        try:
            Nautobot.create_status(adapter, ids, attrs)
            return cls(**ids,**attrs)
        except Exception as e:
            adapter.job.logger.error(f"Execution failed with following exception : {e}")
            raise diffsync_exceptions.ObjectNotCreated


    def update(self, attrs: Dict[str, Any]):
        try:
            Nautobot.update_status(self, attrs)
            return self
        except Exception as e:
            self.adapter.job.logger.error(f"Execution failed with following exception : {e}")
            raise diffsync_exceptions.ObjectNotCreated


class NautobotPlatform(NautobotPlatform):
    _modelname = "platform"
 
    @classmethod
    def create(cls, adapter, ids: Dict[str, Any], attrs: Dict[str, Any]):
        try:
            Nautobot.create_platform(adapter, ids, attrs)
            return cls(**ids)
        except Exception as e:
            adapter.job.logger.error(f"Execution failed with following exception : {e}")
            raise diffsync_exceptions.ObjectNotCreated
 
    def update(self, attrs: Dict[str, Any]):
        Nautobot.update_platform(self, attrs)
        return self

class NautobotSoftwareVersion(NautobotSoftwareVersion):
    _modelname = "software_version"

    @classmethod
    def create(cls, adapter, ids: Dict[str, Any], attrs: Dict[str, Any]):
        try:
            Nautobot.create_software_version(
                adapter,
                ids,
                attrs,
            )
            return cls(**ids)
        except Exception:
            raise diffsync_exceptions.ObjectNotCreated

class NautobotRole(NautobotRole):
    _modelname = "role"

    def create(cls, adapter, ids: Dict[str, Any], attrs: Dict[str, Any]):
        try:
            Nautobot.create_role(adapter, ids, attrs)
            return cls(**ids)
        except Exception:
            raise diffsync_exceptions.ObjectNotCreated

    def update(self, attrs: Dict[str, Any]):
        try:
            Nautobot.update_role(self, attrs)
            return self
        except Exception:
            raise diffsync_exceptions.ObjectNotCreated


class NautobotNameSpace(NautobotNameSpace):
    _modelname = "namespace"

    @classmethod
    def create(cls, adapter, ids: Dict[str, Any], attrs: Dict[str, Any]):
        try:
            nspace = Nautobot.create_namespace(adapter, ids, attrs)
            if nspace :
                return cls(**ids,**attrs)
            else:
                adapter.job.logger.error(f"Namespace Creation failed")
        except Exception as e:
            cls.adapter.job.logger.error(f"Execution failed with following exception : {e}")
            raise diffsync_exceptions.ObjectNotCreated(f" Namespace creation failed {str(e)} ") from e

    def update(self, attrs: Dict[str, Any]):
        try:
            nspace = Nautobot.update_namespace(self, attrs)
            if nspace:
                return self
            else:
                self.adapter.job.logger.error(f"Namespace updation failed")
        except Exception as e:
            # adapter.job.logger.error(f"Execution failed with following exception : {e}")
            raise diffsync_exceptions.ObjectNotCreated(f"Namespace creation failed {str(e)} ") from e

class NautobotPrefix(NautobotPrefix):
    _modelname = "prefix"

    @classmethod
    def create(cls, adapter, ids: Dict[str, Any], attrs: Dict[str, Any]):
        try:
            pre = Nautobot.create_prefix(adapter, ids, attrs)
            if pre :
                return cls(**ids,**attrs)
            else:
                adapter.job.logger.error(f"Prefix Creation failed")
        except Exception as e:
            cls.adapter.job.logger.error(f"Execution failed with following exception : {e}")
            raise diffsync_exceptions.ObjectNotCreated(f" Prefix creation failed {str(e)} ") from e

    def update(self, attrs: Dict[str, Any]):
        try:
            pre = Nautobot.update_prefix(self, attrs)
            if pre:
                return self
            else:
                self.adapter.job.logger.error(f"Prefix updation failed")
        except Exception as e:
            # adapter.job.logger.error(f"Execution failed with following exception : {e}")
            raise diffsync_exceptions.ObjectNotCreated(f" Prefix creation failed {str(e)} ") from e

class NautobotIPAddress(NautobotIPAddress):
    _modelname = "ipaddress"

    @classmethod
    def create(cls, adapter, ids: Dict[str, Any], attrs: Dict[str, Any]):
        try:
            ip = Nautobot.create_ipaddress(adapter, ids, attrs)
            if ip:
                return cls(**ids,**attrs)
            else:
                adapter.job.logger.error(f'Failed to create IP Address {ids.get("host")}')
                #raise diffsync_exceptions.ObjectNotCreated("Ip Address creation failed ")
            adapter.job.logger.info(f"the ipaddress created")
        except Exception as e:
            cls.adapter.job.logger.error(f"Execution failed with following exception : {e}")
            raise diffsync_exceptions.ObjectNotCreated(f"Ip address creation failed {str(e)}") from e

    def update(self, attrs: Dict[str, Any]):
        try:
            ip = Nautobot.update_ipaddress(self, attrs)
            if ip:
                return self
            else:
                self.adapter.job.logger.error("failed to update Ip address")
        except Exception as e:
            # adapter.job.logger.error(f"Execution failed with following exception : {e}")
            raise diffsync_exceptions.ObjectNotCreated(f"ip address updation failed {str(e)}") from e
        

class NautobotVlan(NautobotVlan):
    _modelname = "vlan"

    @classmethod
    def create(cls, adapter, ids: Dict[str, Any], attrs: Dict[str, Any]):
        try:
            vlan = Nautobot.create_vlan(adapter, ids, attrs)
            if vlan :
                return cls(**ids,**attrs)
            else:
                adapter.job.logger.error(f"Vlan Creation failed")
        except Exception as e:
            cls.adapter.job.logger.error(f"Execution failed with following exception : {e}")
            raise diffsync_exceptions.ObjectNotCreated(f" Vlan creation failed {str(e)} ") from e

    def update(self, attrs: Dict[str, Any]):
        try:
            vlan = Nautobot.update_vlan(self, attrs)
            if vlan:
                return self
            else:
                self.adapter.job.logger.error(f"Vlan updation failed")
        except Exception as e:
            # adapter.job.logger.error(f"Execution failed with following exception : {e}")
            raise diffsync_exceptions.ObjectNotCreated(f" Vlan creation failed {str(e)} ") from e
        

class NautobotDevice(NautobotDevice):
    _modelname = "device"

    @classmethod
    def create(cls, adapter, ids: Dict[str, Any], attrs: Dict[str, Any]):
        try:
            dev = Nautobot.create_device(adapter, ids, attrs)
            if dev :
                return cls(**ids,**attrs)
            else:
                adapter.job.logger.error(f"Device Creation failed")
        except Exception as e:
            # adapter.job.logger.error(f"Execution failed with following exception : {e}")
            raise diffsync_exceptions.ObjectNotCreated(f" Device creation failed {str(e)} ") from e

    def update(self, attrs: Dict[str, Any]):
        try:
            dev = Nautobot.update_device(self, attrs)
            if dev:
                return self
            else:
                self.adapter.job.logger.error(f"Device updation failed")
        except Exception as e:
            # adapter.job.logger.error(f"Execution failed with following exception : {e}")
            raise diffsync_exceptions.ObjectNotCreated(f" Device creation failed {str(e)} ") from e

class NautobotInterface(NautobotInterface):
    _modelname = "interface"
 
    @classmethod
    def create(cls, adapter, ids: Dict[str, Any], attrs: Dict[str, Any]):
        try:
            iface = Nautobot.create_interface(adapter, ids, attrs)
            if iface:
                return cls(**ids,**attrs)
            else:
                adapter.job.logger.error(f"Interface creation failed")
        except Exception as e:
            adapter.job.logger.error(f"Execution failed with following exception : {e}")
            raise diffsync_exceptions.ObjectNotCreated(f"Interface creation failed {str(e)}") from e

    def update(self, attrs: Dict[str, Any]):
        try:
            iface = Nautobot.update_interface(self, attrs)
            if iface:
                return self
            else:
                self.adapter.job.logger.error(f"Interface updation failed")
        except Exception as e:
            # adapter.job.logger.error(f"Execution failed with following exception : {e}")
            raise diffsync_exceptions.ObjectNotCreated(f"Interface updation failed ") from e
