import pytest

def test_django_can_start():
    import django
    django.setup()
    assert True
