from django.test import TestCase
from nautobot_ssot_ddi.diffsync.utils.ddi import transformer
from nautobot_ssot_ddi.diffsync.utils.ddi import ValidationError

class TestTransformer(TestCase):
    def test_transform_record_success(self):
        raw = {
            "device_type": "switch",
            "prefix": "10.0.0.0/24",
            "ip": "10.0.0.1",
            "role": "core",
            "ip_status": "active",
            "vlanName": "VLAN10"
        }
        logger = type("Logger", (), {"debug": lambda self, msg: None})()
        result = transformer.transform_record(raw, logger)
        self.assertEqual(result["manufacturer"], "Ddi")
        self.assertEqual(result["namespace"], "Ddi")
        self.assertEqual(result["tenant"], "DDI")
        self.assertEqual(result["prefix"], "10.0.0.0/24")
        self.assertEqual(result["ip_address"], "10.0.0.1")
        self.assertEqual(result["role"], "core")
        self.assertEqual(result["operational_status"], "active")
        self.assertEqual(result["vlanName"], "VLAN10")

    def test_transform_record_failure(self):
        logger = type("Logger", (), {"debug": lambda self, msg: None, "exception": lambda self, msg, raw=None: None})()
        with self.assertRaises(ValidationError):
            transformer.transform_record(None, logger)

    def test_transform_record_logger_debug_called(self):
        class Logger:
            def __init__(self):
                self.debug_called = False
            def debug(self, msg):
                self.debug_called = True
        logger = Logger()
        raw = {
            "device_type": "switch",
            "prefix": "10.0.0.0/24",
            "ip": "10.0.0.1",
            "role": "core",
            "ip_status": "active",
            "vlanName": "VLAN10"
        }
        transformer.transform_record(raw, logger)
        self.assertTrue(logger.debug_called)

    def test_transform_record_logger_exception_called(self):
        class Logger:
            def __init__(self):
                self.exception_called = False
            def debug(self, msg):
                pass
            def exception(self, msg, raw=None):
                self.exception_called = True
        logger = Logger()
        with self.assertRaises(ValidationError):
            transformer.transform_record(None, logger)
        self.assertTrue(logger.exception_called)

    def test_transform_record_with_missing_logger_methods(self):
        class Logger:
            pass
        logger = Logger()
        raw = {
            "device_type": "switch",
            "prefix": "10.0.0.0/24",
            "ip": "10.0.0.1",
            "role": "core",
            "ip_status": "active",
            "vlanName": "VLAN10"
        }
        # Should raise AttributeError because logger lacks 'debug' and 'exception'
        with self.assertRaises(AttributeError):
            transformer.transform_record(raw, logger)

    def test_transform_record_with_non_dict_raw(self):
        logger = type("Logger", (), {"debug": lambda self, msg: None, "exception": lambda self, msg, raw=None: None})()
        with self.assertRaises(ValidationError):
            transformer.transform_record([], logger)
