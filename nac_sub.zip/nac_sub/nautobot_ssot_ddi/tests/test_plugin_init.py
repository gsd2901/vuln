
from django.test import TestCase
from unittest.mock import patch


class TestPluginConfig(TestCase):
    def test_plugin_config_attributes(self):
        from nautobot_ssot_ddi import NautobotSSOTDdiConfig, __version__
        config = NautobotSSOTDdiConfig
        self.assertEqual(config.name, "nautobot_ssot_ddi")
        self.assertEqual(config.verbose_name, "Nautobot SSoT Ddi")
        self.assertEqual(config.version, __version__)
        self.assertEqual(config.author, "Akhil Shaik")
        self.assertEqual(config.author_email, "shikm@gmail.com")
        self.assertEqual(config.base_url, "nautobot-ssot-ddi")
        self.assertIsInstance(config.required_settings, list)
        self.assertIsInstance(config.default_settings, dict)
        self.assertIsInstance(config.caching_config, dict)

    def test_plugin_ready_calls_super(self):
        from nautobot_ssot_ddi import NautobotSSOTDdiConfig
        with patch.object(NautobotSSOTDdiConfig, 'ready', autospec=True) as mock_ready:
            # Patch AppConfig.__init__ to avoid missing arguments error
            patcher = patch("django.apps.AppConfig.__init__", return_value=None)
            patcher.start()
            class DummyConfig(NautobotSSOTDdiConfig):
                def __init__(self, *args, **kwargs):
                    super().__init__(*args, **kwargs)
                    self.label = "nautobot_ssot_ddi"
                    self.apps = type("MockApps", (), {"check_models_ready": lambda self: None})()
                    self.models = {}
            plugin = DummyConfig("nautobot_ssot_ddi", None)
            plugin.ready()
            patcher.stop()
            self.assertTrue(mock_ready.called)
