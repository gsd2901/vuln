from django.test import TestCase
from unittest.mock import MagicMock, patch
from nautobot_ssot_ddi.diffsync.utils.ddi import Ddi, DdiAdapterError, DdiAPIError, ValidationError

class TestDdiInit(TestCase):
    def test_ddi_exceptions(self):
        self.assertTrue(issubclass(DdiAPIError, DdiAdapterError))
        self.assertTrue(issubclass(ValidationError, DdiAdapterError))

    def test_ddi_init_and_host(self):
        mock_controller = MagicMock()
        mock_controller.external_integration.remote_url = "https://api.example.com"
        mock_job = MagicMock()
        with patch.object(Ddi, "_get_creds_from_controller", return_value={}), \
             patch.object(Ddi, "_build_session", return_value=MagicMock()):
            ddi = Ddi(controller=mock_controller, job=mock_job)
            self.assertEqual(ddi.api_host, "https://api.example.com")
            self.assertEqual(ddi.base_url, "https://api.example.com")
            self.assertIsNotNone(ddi.session)
            self.assertEqual(ddi.creds, {})
            self.assertIs(ddi.job, mock_job)
            self.assertIs(ddi.ddi, mock_controller)

