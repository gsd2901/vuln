from django.test import TestCase
from nautobot_ssot_ddi.diffsync.models import base

class TestNautobotBaseModels(TestCase):
    def test_model_instantiation(self):
        test_cases = [
            (base.NautobotManufacturer, {"name": "TestManufacturer"}),
            (base.NautobotDeviceType, {"model": "TestDeviceType"}),
            (base.NautobotStatus, {"name": "Active"}),
            (base.NautobotPlatform, {"name": "TestPlatform"}),
            (base.NautobotRole, {"name": "TestRole"}),
            (base.NautobotTenant, {"name": "TestTenant"}),
            (base.NautobotNameSpace, {"name": "TestNamespace"}),
            (base.NautobotLocation, {"name": "TestLocation", "status__name": "Active"}),
            (base.NautobotIPAddress, {"host": "192.0.2.1", "status": "active", "role__name": "mgmt", "namespace": "ns1"}),
            (base.NautobotPrefix, {"prefix": "192.0.2.0/24", "namespace": "ns1", "vlan__name": "VLAN1", "tenant_name": "Tenant1", "status": "active"}),
            (base.NautobotVlan, {"vid": 100, "name": "VLAN100", "status_id": "active"}),
            (base.NautobotDevice, {"name": "Device1", "serial": "SN123", "device_type__model": "ModelX", "location__name": "Loc1", "platform__name": "Plat1", "status__name": "active", "primary_ip4__host": "192.0.2.1", "primary_ip6__host": "2001:db8::1"}),
            (base.NautobotInterface, {"device__name": "Device1", "name": "eth0", "enabled": True, "type": "ethernet", "description": "Uplink", "status": "active"}),
        ]
        for model_class, kwargs in test_cases:
            instance = model_class(**kwargs)
            for key, value in kwargs.items():
                self.assertEqual(getattr(instance, key), value)
