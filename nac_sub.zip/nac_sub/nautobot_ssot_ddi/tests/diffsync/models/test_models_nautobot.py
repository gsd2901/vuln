from django.test import TestCase
from unittest.mock import patch, MagicMock
from nautobot_ssot_ddi.diffsync.models import nautobot

class TestNautobotModels(TestCase):
    def test_create_and_update_methods(self):
        test_cases = [
            (nautobot.NautobotManufacturer, "create_manufacturer", "update_manufacturer", {"name": "TestManufacturer"}, {"name": "TestManufacturer"}),
            (nautobot.NautobotDeviceType, "create_device_type", "update_device_type", {"model": "TestDeviceType"}, {"model": "TestDeviceType"}),
            (nautobot.NautobotStatus, "create_status", "update_status", {"name": "Active"}, {"name": "Active"}),
            (nautobot.NautobotPlatform, "create_platform", "update_platform", {"name": "TestPlatform"}, {"name": "TestPlatform"}),
            (nautobot.NautobotRole, "create_role", "update_role", {"name": "TestRole"}, {"name": "TestRole"}),
            (nautobot.NautobotTenant, "create_tenant", "update_tenant", {"name": "TestTenant"}, {"name": "TestTenant"}),
            (nautobot.NautobotNameSpace, "create_namespace", "update_namespace", {"name": "TestNamespace"}, {"name": "TestNamespace"}),
            (nautobot.NautobotLocation, "create_location", "update_location", {"name": "TestLocation", "status__name": "Active"}, {"status__name": "Active"}),
            (nautobot.NautobotIPAddress, "create_ipaddress", "update_ipaddress", {"host": "192.0.2.1", "status": "active", "role__name": "mgmt", "namespace": "ns1"}, {"status": "active"}),
            (nautobot.NautobotPrefix, "create_prefix", "update_prefix", {"prefix": "192.0.2.0/24", "namespace": "ns1", "vlan__name": "VLAN1", "tenant_name": "Tenant1", "status": "active"}, {"status": "active"}),
            (nautobot.NautobotVlan, "create_vlan", "update_vlan", {"vid": 100, "name": "VLAN100", "status_id": "active"}, {"status_id": "active"}),
            (nautobot.NautobotDevice, "create_device", "update_device", {"name": "Device1", "serial": "SN123", "device_type__model": "ModelX", "location__name": "Loc1", "platform__name": "Plat1", "status__name": "active", "primary_ip4__host": "192.0.2.1", "primary_ip6__host": "2001:db8::1"}, {"serial": "SN123"}),
            (nautobot.NautobotInterface, "create_interface", "update_interface", {"device__name": "Device1", "name": "eth0", "enabled": True, "type": "ethernet", "description": "Uplink", "status": "active"}, {"enabled": True}),
        ]
        for model_class, create_func, update_func, ids, attrs in test_cases:
            with patch(f"nautobot_ssot_ddi.diffsync.utils.nautobot.Nautobot.{create_func}") as mock_create:
                mock_create.return_value = None
                self.assertIsNone(model_class.create(MagicMock(), ids, attrs))
                mock_create.assert_called_once()
            instance = model_class(**ids)
            with patch(f"nautobot_ssot_ddi.diffsync.utils.nautobot.Nautobot.{update_func}") as mock_update:
                mock_update.return_value = None
                instance.update(attrs)
                mock_update.assert_called_once()
