from django.test import TestCase
from nautobot_ssot_ddi.diffsync.models import ddi

class TestDdiModels(TestCase):
    def test_ddi_device_inheritance(self):
        obj = ddi.DdiDevice(name="Device1")
        self.assertIsInstance(obj, ddi.DdiDevice)

    def test_ddi_devicetype_inheritance(self):
        obj = ddi.DdiDeviceType(model="ModelX")
        self.assertIsInstance(obj, ddi.DdiDeviceType)

    def test_ddi_manufacturer_inheritance(self):
        obj = ddi.DdiManufacturer(name="ManufacturerX")
        self.assertIsInstance(obj, ddi.DdiManufacturer)

    def test_ddi_location_inheritance(self):
        obj = ddi.DdiLocation(name="Loc1", status__name="active")
        self.assertIsInstance(obj, ddi.DdiLocation)

    def test_ddi_ipaddress_inheritance(self):
        obj = ddi.DdiIPAddress(host="192.0.2.1")
        self.assertIsInstance(obj, ddi.DdiIPAddress)

    def test_ddi_interface_inheritance(self):
        obj = ddi.DdiInterface(device__name="Device1", name="eth0", enabled=True, type="ethernet", description="desc", status="active")
        self.assertIsInstance(obj, ddi.DdiInterface)

    def test_ddi_status_inheritance(self):
        obj = ddi.DdiStatus(name="active")
        self.assertIsInstance(obj, ddi.DdiStatus)

    def test_ddi_platform_inheritance(self):
        obj = ddi.DdiPlatform(name="Plat1")
        self.assertIsInstance(obj, ddi.DdiPlatform)

    def test_ddi_namespace_inheritance(self):
        obj = ddi.DdiNameSpace(name="ns1")
        self.assertIsInstance(obj, ddi.DdiNameSpace)

    def test_ddi_role_inheritance(self):
        obj = ddi.DdiRole(name="role1")
        self.assertIsInstance(obj, ddi.DdiRole)

    def test_ddi_tenant_inheritance(self):
        obj = ddi.DdiTenant(name="tenant1")
        self.assertIsInstance(obj, ddi.DdiTenant)
