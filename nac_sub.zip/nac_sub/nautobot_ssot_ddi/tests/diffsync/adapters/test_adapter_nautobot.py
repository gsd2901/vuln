from django.test import TestCase
from unittest.mock import MagicMock, patch
from nautobot_ssot_ddi.diffsync.adapters.nautobot import DdiSSOtNautobotAdapter

class TestDdiSSOtNautobotAdapter(TestCase):
    def test_real_load_manufacturers(self):
        from nautobot.dcim.models import Manufacturer
        Manufacturer.objects.create(name="RealMFG")
        adapter = DdiSSOtNautobotAdapter(ddi=None, job=MagicMock())
        # Call the real method, do not mock add
        adapter.load_manufacturers()
        # The adapter should now have a NautobotManufacturer object in its internal state
        found = any(getattr(obj, "name", None) == "RealMFG" for obj in adapter.get_all("manufacturer"))
        self.assertTrue(found, "Manufacturer 'RealMFG' should be loaded into the adapter's state.")

    def test_integration_load_manufacturers(self):
        # Create a real Manufacturer object in the test database
        from nautobot.dcim.models import Manufacturer
        Manufacturer.objects.create(name="TestMFG")
        # Use the real adapter and call the real method
        adapter = DdiSSOtNautobotAdapter(ddi=None, job=MagicMock())
        adapter.add = MagicMock()  # Only mock add to observe calls, not the ORM
        adapter.load_manufacturers()
        adapter.add.assert_called_once()
        args, _ = adapter.add.call_args
        self.assertEqual(args[0].name, "TestMFG")

    def setUp(self):
        self.adapter = DdiSSOtNautobotAdapter(ddi=MagicMock(), job=MagicMock())

    def test_load_devices(self):
        dev_obj = MagicMock()
        dev_obj.name = "dev1"
        dev_obj.serial = "SN1"
        dev_obj.device_type = MagicMock()
        dev_obj.device_type.model = "DT1"
        dev_obj.location = MagicMock()
        dev_obj.location.name = "Loc1"
        dev_obj.platform = MagicMock()
        dev_obj.platform.name = "Plat1"
        dev_obj.status = MagicMock()
        dev_obj.status.name = "active"
        dev_obj.primary_ip4 = MagicMock()
        dev_obj.primary_ip6 = MagicMock()

        qs_mock = MagicMock()
        qs_mock.select_related.return_value = [dev_obj]

        with patch("nautobot.dcim.models.Device.objects.all", return_value=qs_mock):
            with patch.object(self.adapter, "add") as mock_add:
                self.adapter.ddi = None
                self.adapter.load_devices()
                mock_add.assert_called_once()
                args, _ = mock_add.call_args
                self.assertEqual(args[0].name, "dev1")
                self.assertEqual(args[0].serial, "SN1")
                self.assertEqual(args[0].device_type__model, "DT1")
                self.assertEqual(args[0].location__name, "Loc1")
                self.assertEqual(args[0].platform__name, "Plat1")
                self.assertEqual(args[0].status__name, "active")

    def test_load_manufacturers(self):
        mfg_obj = MagicMock()
        mfg_obj.name = "MFG1"
        with patch("nautobot.dcim.models.Manufacturer.objects.all", return_value=[mfg_obj]):
            with patch.object(self.adapter, "add") as mock_add:
                self.adapter.load_manufacturers()
                mock_add.assert_called_once()

    def test_load_device_type(self):
        dt_obj = MagicMock()
        dt_obj.model = "DT1"
        dt_obj.manufacturer = MagicMock()
        dt_obj.manufacturer.name = "MFG1"
        with patch("nautobot.dcim.models.DeviceType.objects.select_related", return_value=[dt_obj]):
            with patch.object(self.adapter, "add") as mock_add:
                self.adapter.load_device_type()
                mock_add.assert_called_once()

    def test_load_statuses(self):
        st_obj = MagicMock()
        st_obj.name = "active"
        with patch("nautobot.extras.models.Status.objects.all", return_value=[st_obj]):
            with patch.object(self.adapter, "add") as mock_add:
                self.adapter.load_statuses()
                mock_add.assert_called_once()

    def test_load_roles(self):
        role_obj = MagicMock()
        role_obj.name = "role1"
        with patch("nautobot.extras.models.Role.objects.all", return_value=[role_obj]):
            with patch.object(self.adapter, "add") as mock_add:
                self.adapter.load_roles()
                mock_add.assert_called_once()

    def test_load_interfaces(self):
        iface_obj = MagicMock()
        iface_obj.device = MagicMock()
        iface_obj.device.name = "dev1"
        iface_obj.name = "eth0"
        iface_obj.enabled = True
        iface_obj.type = "ethernet"
        iface_obj.description = "desc"
        iface_obj.status = MagicMock()
        iface_obj.status.name = "active"
        with patch("nautobot.dcim.models.Interface.objects.select_related", return_value=[iface_obj]):
            with patch.object(self.adapter, "add") as mock_add:
                self.adapter.load_interfaces()
                mock_add.assert_called_once()
                args, _ = mock_add.call_args
                self.assertEqual(args[0].device__name, "dev1")
                self.assertEqual(args[0].name, "eth0")
                self.assertTrue(args[0].enabled)
                self.assertEqual(args[0].type, "ethernet")
                self.assertEqual(args[0].description, "desc")
                self.assertEqual(args[0].status, "active")

    def test_load_locations(self):
        loc_obj = MagicMock()
        loc_obj.name = "loc1"
        loc_obj.status = MagicMock()
        loc_obj.status.name = "active"
        with patch("nautobot.dcim.models.Location.objects.select_related", return_value=[loc_obj]):
            with patch.object(self.adapter, "add") as mock_add:
                self.adapter.load_locations()
                mock_add.assert_called_once()
                args, _ = mock_add.call_args
                self.assertEqual(args[0].name, "loc1")
                self.assertEqual(args[0].status__name, "active")
    # Removed duplicate pytest-style functions at the end of the file