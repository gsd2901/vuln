from django.test import TestCase
from unittest.mock import MagicMock, patch
from nautobot_ssot_ddi.diffsync.utils import nautobot

class TestNautobotCRUD3(TestCase):
    def setUp(self):
        self.adapter = MagicMock()
        self.adapter.job.logger = MagicMock()
        self.adapter.adapter = MagicMock()
        self.adapter.adapter.job.logger = MagicMock()
        self.adapter.name = "TestName"
        self.adapter.model = "TestModel"
        self.adapter.vid = 100
        self.adapter.prefix = "192.0.2.0/24"
        self.adapter.namespace = "ns1"
        self.adapter.device__name = "Device1"

    def test_create_vlan_success(self):
        with patch("nautobot.ipam.models.VLAN.objects.get_or_create") as mock_get_or_create, \
             patch("nautobot.extras.models.Status.objects.filter") as mock_status_filter:
            mock_status_filter.return_value.first.return_value = MagicMock()
            ids = {"vid": 100}
            attrs = {"name": "VLAN100", "status_id": "active"}
            nautobot.Nautobot.create_vlan(self.adapter, ids, attrs)
            mock_get_or_create.assert_called()
            self.adapter.job.logger.debug.assert_called()

    def test_update_vlan_success(self):
        mock_obj = MagicMock()
        with patch("nautobot.ipam.models.VLAN.objects.filter") as mock_filter:
            mock_filter.return_value.first.return_value = mock_obj
            attrs = {"name": "VLAN100"}
            nautobot.Nautobot.update_vlan(self.adapter, attrs)
            self.assertEqual(mock_obj.name, "VLAN100")
            mock_obj.save.assert_called_once()
            self.adapter.adapter.job.logger.debug.assert_called()

    def test_update_vlan_missing(self):
        with patch("nautobot.ipam.models.VLAN.objects.filter") as mock_filter:
            mock_filter.return_value.first.return_value = None
            attrs = {"name": "VLAN100"}
            nautobot.Nautobot.update_vlan(self.adapter, attrs)
            self.adapter.adapter.job.logger.warning.assert_called_with(
                "VLAN %s missing for update", self.adapter.vid
            )

    def test_create_vrf_success(self):
        with patch("nautobot.ipam.models.VRF.objects.get_or_create") as mock_get_or_create, \
             patch("nautobot.ipam.models.Namespace.objects.filter") as mock_ns_filter, \
             patch("nautobot.tenancy.models.Tenant.objects.create") as mock_tenant_create:
            mock_ns_filter.return_value.first.return_value = None
            mock_tenant_create.return_value = MagicMock()
            ids = {"name": "VRF1", "namespace": "ns1"}
            attrs = {"rd": "1:1"}
            nautobot.Nautobot.create_vrf(self.adapter, ids, attrs)
            mock_get_or_create.assert_called()
            self.adapter.job.logger.debug.assert_called()

    def test_update_vrf_success(self):
        mock_obj = MagicMock()
        with patch("nautobot.ipam.models.VRF.objects.filter") as mock_filter:
            mock_filter.return_value.first.return_value = mock_obj
            attrs = {"rd": "1:1"}
            nautobot.Nautobot.update_vrf(self.adapter, attrs)
            self.assertEqual(mock_obj.rd, "1:1")
            mock_obj.save.assert_called_once()
            self.adapter.adapter.job.logger.debug.assert_called()

    def test_update_vrf_missing(self):
        with patch("nautobot.ipam.models.VRF.objects.filter") as mock_filter:
            mock_filter.return_value.first.return_value = None
            attrs = {"rd": "1:1"}
            nautobot.Nautobot.update_vrf(self.adapter, attrs)
            self.adapter.adapter.job.logger.warning.assert_called_with(
                "VRF %s missing for update", self.adapter.name
            )

    def test_create_prefix_success(self):
        with patch("nautobot.ipam.models.Prefix.objects.get_or_create") as mock_get_or_create, \
             patch("nautobot.ipam.models.Namespace.objects.filter") as mock_ns_filter:
            mock_ns_filter.return_value.first.return_value = MagicMock()
            ids = {"prefix": "192.0.2.0/24", "namespace": "ns1"}
            attrs = {"status": "active"}
            nautobot.Nautobot.create_prefix(self.adapter, ids, attrs)
            mock_get_or_create.assert_called()

    def test_update_prefix_success(self):
        mock_obj = MagicMock()
        with patch("nautobot.ipam.models.Prefix.objects.filter") as mock_filter, \
             patch("nautobot.ipam.models.Namespace.objects.filter") as mock_ns_filter:
            mock_filter.return_value.first.return_value = mock_obj
            mock_ns_filter.return_value.first.return_value = MagicMock()
            attrs = {"status": "active"}
            nautobot.Nautobot.update_prefix(self.adapter, attrs)
            mock_obj.save.assert_called_once()
            self.adapter.adapter.job.logger.debug.assert_called()

    def test_update_prefix_missing(self):
        with patch("nautobot.ipam.models.Prefix.objects.filter") as mock_filter, \
             patch("nautobot.ipam.models.Namespace.objects.filter") as mock_ns_filter:
            mock_filter.return_value.first.return_value = None
            mock_ns_filter.return_value.first.return_value = MagicMock()
            attrs = {"status": "active"}
            nautobot.Nautobot.update_prefix(self.adapter, attrs)
            self.adapter.adapter.job.logger.warning.assert_called_with(
                "Prefix %s missing for update", self.adapter.prefix
            )
