
from django.test import TestCase
from unittest.mock import MagicMock, patch
from nautobot_ssot_ddi.diffsync.utils import nautobot


class TestNautobotUtils(TestCase):
    def setUp(self):
        self.adapter = MagicMock()
        self.adapter.name = "TestName"
        self.adapter.model = "TestModel"
        self.adapter.adapter = MagicMock()
        self.adapter.job = MagicMock()
    def test_update_device_type(self):
        with patch("nautobot.dcim.models.DeviceType.objects.filter") as mock_filter:
            mock_obj = MagicMock()
            mock_filter.return_value.first.return_value = mock_obj
            nautobot.Nautobot.update_device_type(self.adapter, {"model": "NewModel"})
            self.assertTrue(mock_obj.save.called)

    def test_create_device(self):
        with patch("nautobot.dcim.models.DeviceType.objects.filter") as dt_filter, \
             patch("nautobot.dcim.models.Location.objects.filter") as loc_filter, \
             patch("nautobot.dcim.models.Platform.objects.filter") as pl_filter, \
             patch("nautobot.extras.models.Status.objects.filter") as st_filter, \
             patch("nautobot.extras.models.Role.objects.filter") as role_filter, \
             patch("nautobot.extras.models.Role.objects.get_or_create") as role_create, \
             patch("nautobot.ipam.models.IPAddress.objects.filter") as ip_filter, \
             patch("nautobot.dcim.models.Device.objects.get_or_create") as dev_create:

            dt_filter.return_value.first.return_value = MagicMock()
            loc_filter.return_value.first.return_value = MagicMock()
            pl_filter.return_value.first.return_value = MagicMock()
            st_filter.return_value.first.return_value = MagicMock()

            role_filter.return_value.first.return_value = None
            role_create.return_value = (MagicMock(), True)

            ip_filter.return_value.first.return_value = MagicMock()
            dev_create.return_value = (MagicMock(), True)

            nautobot.Nautobot.create_device(
                self.adapter,
                {"name": "Device1"},
                {
                    "device_type": "DT",
                    "location": "Loc",
                    "platform": "Plat",
                    "status": "Stat",
                    "role": "Role",
                    "serial": "SN"
                }
            )

            self.assertTrue(dev_create.called)

    def test_update_device(self):
           with patch("nautobot.dcim.models.Device.objects.filter") as dev_filter, \
               patch("nautobot.dcim.models.DeviceType.objects.filter") as dt_filter, \
               patch("nautobot.dcim.models.Location.objects.filter") as loc_filter, \
               patch("nautobot.dcim.models.Platform.objects.filter") as pl_filter, \
               patch("nautobot.extras.models.Status.objects.filter") as st_filter, \
               patch("nautobot.ipam.models.IPAddress.objects.filter") as ip_filter:
              dev_obj = MagicMock()
              dev_filter.return_value.first.return_value = dev_obj
              dt_filter.return_value.first.return_value = MagicMock()
              loc_filter.return_value.first.return_value = MagicMock()
              pl_filter.return_value.first.return_value = MagicMock()
              st_filter.return_value.first.return_value = MagicMock()
              ip_filter.return_value.first.return_value = MagicMock()
              nautobot.Nautobot.update_device(self.adapter, {"name": "Device1"})
              self.assertTrue(dev_obj.save.called)
    def setUp(self):
        self.adapter = MagicMock()
        self.adapter.name = "TestName"
        self.adapter.model = "TestModel"
        self.adapter.adapter = MagicMock()
        self.adapter.job = MagicMock()


# ----------------------------
# Manufacturer
# ----------------------------


    def test_create_manufacturer(self):
        with patch("nautobot.dcim.models.Manufacturer.objects.get_or_create") as mock_get_or_create:
            nautobot.Nautobot.create_manufacturer(self.adapter, {"name": "TestName"}, {})
            mock_get_or_create.assert_called_once_with(name="TestName")



    def test_update_manufacturer(self):
        with patch("nautobot.dcim.models.Manufacturer.objects.filter") as mock_filter:
            mock_obj = MagicMock()
            mock_filter.return_value.first.return_value = mock_obj
            nautobot.Nautobot.update_manufacturer(self.adapter, {"name": "NewName"})
            self.assertTrue(mock_obj.save.called)


# ----------------------------
# Device Type
# ----------------------------


    def test_create_device_type(self):
        with patch("nautobot.dcim.models.DeviceType.objects.get_or_create") as mock_get_or_create, \
             patch("nautobot.dcim.models.Manufacturer.objects.filter") as mock_filter, \
             patch("nautobot.dcim.models.Manufacturer.objects.create") as mock_create:

            mock_filter.return_value.first.return_value = None
            mock_create.return_value = MagicMock()

            nautobot.Nautobot.create_device_type(
                self.adapter,
                {"model": "TestModel"},
                {"manufacturer": "TestManu"}
            )

            self.assertTrue(mock_get_or_create.called)


def test_update_device_type(adapter):
    with patch("nautobot.dcim.models.DeviceType.objects.filter") as mock_filter:
        mock_obj = MagicMock()
        mock_filter.return_value.first.return_value = mock_obj

        nautobot.Nautobot.update_device_type(adapter, {"model": "NewModel"})

        assert mock_obj.save.called


# ----------------------------
# Device
# ----------------------------

def test_create_device(adapter):
    with patch("nautobot.dcim.models.DeviceType.objects.filter") as dt_filter, \
         patch("nautobot.dcim.models.Location.objects.filter") as loc_filter, \
         patch("nautobot.dcim.models.Platform.objects.filter") as pl_filter, \
         patch("nautobot.extras.models.Status.objects.filter") as st_filter, \
         patch("nautobot.extras.models.Role.objects.filter") as role_filter, \
         patch("nautobot.extras.models.Role.objects.get_or_create") as role_create, \
         patch("nautobot.ipam.models.IPAddress.objects.filter") as ip_filter, \
         patch("nautobot.dcim.models.Device.objects.get_or_create") as dev_create:

        dt_filter.return_value.first.return_value = MagicMock()
        loc_filter.return_value.first.return_value = MagicMock()
        pl_filter.return_value.first.return_value = MagicMock()
        st_filter.return_value.first.return_value = MagicMock()

        role_filter.return_value.first.return_value = None
        role_create.return_value = (MagicMock(), True)

        ip_filter.return_value.first.return_value = MagicMock()
        dev_create.return_value = (MagicMock(), True)

        nautobot.Nautobot.create_device(
            adapter,
            {"name": "Device1"},
            {
                "device_type": "DT",
                "location": "Loc",
                "platform": "Plat",
                "status": "Stat",
                "role": "Role",
                "serial": "SN"
            }
        )

        assert dev_create.called


def test_update_device(adapter):
    with patch("nautobot.dcim.models.Device.objects.filter") as dev_filter, \
         patch("nautobot.dcim.models.DeviceType.objects.filter") as dt_filter, \
         patch("nautobot.dcim.models.Location.objects.filter") as loc_filter, \
         patch("nautobot.dcim.models.Platform.objects.filter") as pl_filter, \
         patch("nautobot.extras.models.Status.objects.filter") as st_filter, \
         patch("nautobot.ipam.models.IPAddress.objects.filter") as ip_filter:

        dev_obj = MagicMock()
        dev_filter.return_value.filter.return_value = dev_obj

        dt_filter.return_value.first.return_value = MagicMock()
        loc_filter.return_value.first.return_value = MagicMock()
        pl_filter.return_value.first.return_value = MagicMock()
        st_filter.return_value.first.return_value = MagicMock()
        ip_filter.return_value.first.return_value = MagicMock()

        nautobot.Nautobot.update_device(
            adapter,
            {
                "serial": "SN",
                "device_type__model": "DT",
                "location__name": "Loc",
                "platform__name": "Plat",
                "status__name": "Stat",
                "primary_ip4__host": "192.0.2.1"
            }
        )

        assert dev_obj.save.called


# ----------------------------
# Interface
# ----------------------------

def test_create_interface(adapter):
    with patch("nautobot.dcim.models.Device.objects.filter") as dev_filter, \
         patch("nautobot.dcim.models.Interface.objects.get_or_create") as iface_create, \
         patch("nautobot.extras.models.Status.objects.filter") as st_filter:

        dev_filter.return_value.first.return_value = MagicMock()
        st_filter.return_value.first.return_value = MagicMock()
        iface_create.return_value = (MagicMock(), True)

        nautobot.Nautobot.create_interface(
            adapter,
            {"device__name": "Device1", "name": "eth0"},
            {"enabled": True, "type": "ethernet", "description": "desc", "status": "active"}
        )

        assert iface_create.called


def test_update_interface(adapter):
    with patch("nautobot.dcim.models.Device.objects.filter") as dev_filter, \
         patch("nautobot.dcim.models.Interface.objects.filter") as iface_filter, \
         patch("nautobot.extras.models.Status.objects.filter") as st_filter:

        dev_filter.return_value.filter.return_value = MagicMock()

        iface_obj = MagicMock()
        iface_filter.return_value.filter.return_value = iface_obj

        st_filter.return_value.first.return_value = MagicMock()

        nautobot.Nautobot.update_interface(
            adapter,
            {"enabled": True, "type": "ethernet", "description": "desc", "status": "active"}
        )

        assert iface_obj.save.called


# ----------------------------
# IP Address
# ----------------------------

def test_create_ipaddress(adapter):
    with patch("nautobot.ipam.models.IPAddress.objects.filter") as ip_filter, \
         patch("nautobot.ipam.models.IPAddress.objects.create") as ip_create, \
         patch("nautobot.ipam.models.Namespace.objects.filter") as ns_filter, \
         patch("nautobot.extras.models.Status.objects.filter") as st_filter, \
         patch("nautobot.extras.models.Status.objects.create") as st_create, \
         patch("nautobot.extras.models.Role.objects.filter") as role_filter, \
         patch("nautobot.extras.models.Role.objects.create") as role_create:

        ip_filter.return_value.first.return_value = None
        ns_filter.return_value.first.return_value = MagicMock()
        st_filter.return_value.first.return_value = MagicMock()
        st_create.return_value = MagicMock()
        role_filter.return_value.first.return_value = MagicMock()
        role_create.return_value = MagicMock()
        ip_create.return_value = MagicMock()

        nautobot.Nautobot.create_ipaddress(
            adapter,
            {"host": "192.0.2.1"},
            {"namespace": "default", "status": "active", "role": "core"}
        )

        assert ip_create.called


def test_update_ipaddress(adapter):
    with patch("nautobot.ipam.models.IPAddress.objects.filter") as ip_filter, \
         patch("nautobot.extras.models.Status.objects.filter") as st_filter:

        ip_obj = MagicMock()
        ip_filter.return_value.first.return_value = ip_obj
        st_filter.return_value.first.return_value = MagicMock()

        nautobot.Nautobot.update_ipaddress(adapter, {"status_id": "active"})

        assert ip_obj.save.called