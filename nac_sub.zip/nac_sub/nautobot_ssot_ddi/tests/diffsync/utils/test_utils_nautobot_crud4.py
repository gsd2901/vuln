from django.test import TestCase
from unittest.mock import MagicMock, patch
from nautobot_ssot_ddi.diffsync.utils import nautobot

class TestNautobotCRUD4(TestCase):
    def setUp(self):
        self.adapter = MagicMock()
        self.adapter.job.logger = MagicMock()
        self.adapter.adapter = MagicMock()
        self.adapter.adapter.job.logger = MagicMock()
        self.adapter.name = "Device1"
        self.adapter.model = "TestModel"
        self.adapter.device__name = "Device1"
        self.adapter.prefix = "192.0.2.0/24"
        self.adapter.namespace = "ns1"
        self.adapter.vid = 100

    def test_create_device_success(self):
        with patch("nautobot.dcim.models.DeviceType.objects.filter") as dt_filter, \
             patch("nautobot.dcim.models.Location.objects.filter") as loc_filter, \
             patch("nautobot.dcim.models.Platform.objects.filter") as pl_filter, \
             patch("nautobot.extras.models.Status.objects.filter") as st_filter, \
             patch("nautobot.extras.models.Role.objects.filter") as role_filter, \
             patch("nautobot.extras.models.Role.objects.get_or_create") as role_create, \
             patch("nautobot.ipam.models.IPAddress.objects.filter") as ip_filter, \
             patch("nautobot.dcim.models.Device.objects.get_or_create") as dev_create:
            dt_filter.return_value.first.return_value = MagicMock()
            loc_filter.return_value.first.return_value = MagicMock()
            pl_filter.return_value.first.return_value = MagicMock()
            st_filter.return_value.first.return_value = MagicMock()
            role_filter.return_value.first.return_value = None
            role_create.return_value = (MagicMock(), True)
            ip_filter.return_value.first.return_value = MagicMock()
            dev_create.return_value = (MagicMock(), True)
            ids = {"name": "Device1"}
            attrs = {"device_type": "DT", "location": "Loc", "platform": "Plat", "status": "Stat", "role": "Role", "serial": "SN"}
            nautobot.Nautobot.create_device(self.adapter, ids, attrs)
            dev_create.assert_called()
            self.adapter.job.logger.debug.assert_called()

    def test_update_device_success(self):
        mock_obj = MagicMock()
        with patch("nautobot.dcim.models.Device.objects.filter") as dev_filter, \
             patch("nautobot.dcim.models.DeviceType.objects.filter") as dt_filter, \
             patch("nautobot.dcim.models.Location.objects.filter") as loc_filter, \
             patch("nautobot.dcim.models.Platform.objects.filter") as pl_filter, \
             patch("nautobot.extras.models.Status.objects.filter") as st_filter, \
             patch("nautobot.ipam.models.IPAddress.objects.filter") as ip_filter:
            dev_filter.return_value.first.return_value = mock_obj
            dt_filter.return_value.first.return_value = MagicMock()
            loc_filter.return_value.first.return_value = MagicMock()
            pl_filter.return_value.first.return_value = MagicMock()
            st_filter.return_value.first.return_value = MagicMock()
            ip_filter.return_value.first.return_value = MagicMock()
            attrs = {"serial": "SN", "device_type__model": "DT", "location__name": "Loc", "platform__name": "Plat", "status__name": "Stat", "primary_ip4__host": "1.2.3.4"}
            nautobot.Nautobot.update_device(self.adapter, attrs)
            mock_obj.save.assert_called_once()
            self.adapter.adapter.job.logger.debug.assert_called()

    def test_update_device_missing(self):
        with patch("nautobot.dcim.models.Device.objects.filter") as dev_filter:
            dev_filter.return_value.first.return_value = None
            attrs = {"serial": "SN"}
            nautobot.Nautobot.update_device(self.adapter, attrs)
            self.adapter.adapter.job.logger.warning.assert_called_with(
                "Device %s missing for update", self.adapter.name
            )

    def test_create_interface_success(self):
        with patch("nautobot.dcim.models.Device.objects.filter") as dev_filter, \
             patch("nautobot.dcim.models.Interface.objects.get_or_create") as iface_create, \
             patch("nautobot.extras.models.Status.objects.filter") as st_filter:
            dev_filter.return_value.first.return_value = MagicMock()
            st_filter.return_value.first.return_value = MagicMock()
            ids = {"device__name": "Device1", "name": "eth0"}
            attrs = {"enabled": True, "type": "ethernet", "description": "desc", "status": "active"}
            nautobot.Nautobot.create_interface(self.adapter, ids, attrs)
            iface_create.assert_called()
            self.adapter.job.logger.debug.assert_called()

    def test_update_interface_success(self):
        mock_iface = MagicMock()
        with patch("nautobot.dcim.models.Device.objects.filter") as dev_filter, \
             patch("nautobot.dcim.models.Interface.objects.filter") as iface_filter, \
             patch("nautobot.extras.models.Status.objects.filter") as st_filter:
            dev_filter.return_value.first.return_value = MagicMock()
            iface_filter.return_value.first.return_value = mock_iface
            st_filter.return_value.first.return_value = MagicMock()
            attrs = {"enabled": False, "type": "mgmt", "description": "mgmt iface", "status": "down"}
            nautobot.Nautobot.update_interface(self.adapter, attrs)
            mock_iface.save.assert_called_once()
            self.adapter.adapter.job.logger.debug.assert_called()

    def test_update_interface_missing(self):
        with patch("nautobot.dcim.models.Device.objects.filter") as dev_filter, \
             patch("nautobot.dcim.models.Interface.objects.filter") as iface_filter:
            dev_filter.return_value.first.return_value = MagicMock()
            iface_filter.return_value.first.return_value = None
            attrs = {"enabled": True}
            nautobot.Nautobot.update_interface(self.adapter, attrs)
            self.adapter.adapter.job.logger.warning.assert_called()

    def test_create_ipaddress_success(self):
        with patch("nautobot.ipam.models.IPAddress.objects.filter") as ip_filter, \
             patch("nautobot.ipam.models.IPAddress.objects.get_or_create") as ip_create, \
             patch("nautobot.ipam.models.Namespace.objects.filter") as ns_filter, \
             patch("nautobot.extras.models.Status.objects.filter") as st_filter, \
             patch("nautobot.extras.models.Status.objects.create") as st_create:
            ip_filter.return_value.first.return_value = None
            ns_filter.return_value.first.return_value = MagicMock()
            st_filter.return_value.first.return_value = None
            st_create.return_value = MagicMock()
            ids = {"host": "1.2.3.4"}
            attrs = {"namespace": "ns1", "status": "active"}
            nautobot.Nautobot.create_ipaddress(self.adapter, ids, attrs)
            ip_create.assert_called()

    def test_update_ipaddress_noop(self):
        nautobot.Nautobot.update_ipaddress(self.adapter, {})
