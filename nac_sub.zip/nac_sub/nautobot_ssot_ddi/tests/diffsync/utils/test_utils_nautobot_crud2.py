from django.test import TestCase
from unittest.mock import MagicMock, patch
from nautobot_ssot_ddi.diffsync.utils import nautobot

class TestNautobotCRUD2(TestCase):
    def setUp(self):
        self.adapter = MagicMock()
        self.adapter.job.logger = MagicMock()
        self.adapter.adapter = MagicMock()
        self.adapter.adapter.job.logger = MagicMock()
        self.adapter.name = "TestName"
        self.adapter.model = "TestModel"

    def test_create_location_success(self):
        with patch("nautobot.dcim.models.LocationType.objects.get_or_create") as mock_lt_get_or_create, \
             patch("nautobot.extras.models.Status.objects.filter") as mock_status_filter, \
             patch("nautobot.dcim.models.Location.object.get_or_create") as mock_loc_get_or_create:
            mock_status_filter.return_value.first.return_value = None
            mock_lt_get_or_create.return_value = (MagicMock(), True)
            ids = {"name": "Loc1"}
            attrs = {"status__name": "active"}
            nautobot.Nautobot.create_location(self.adapter, ids, attrs)
            mock_loc_get_or_create.assert_called()
            self.adapter.job.logger.debug.assert_called()

    def test_update_location_success(self):
        mock_obj = MagicMock()
        with patch("nautobot.dcim.models.Location.objects.filter") as mock_filter, \
             patch("nautobot.extras.models.Status.objects.filter") as mock_status_filter:
            mock_filter.return_value.first.return_value = mock_obj
            mock_status_filter.return_value.first.return_value = MagicMock()
            attrs = {"name": "NewLoc", "status__name": "active"}
            nautobot.Nautobot.update_location(self.adapter, attrs)
            mock_obj.save.assert_called_once()
            self.adapter.adapter.job.logger.debug.assert_called()

    def test_update_location_missing(self):
        with patch("nautobot.dcim.models.Location.objects.filter") as mock_filter:
            mock_filter.return_value.first.return_value = None
            attrs = {"name": "NewLoc"}
            nautobot.Nautobot.update_location(self.adapter, attrs)
            self.adapter.adapter.job.logger.warning.assert_called_with(
                "Location %s missing for update", self.adapter.name
            )

    def test_create_status_success(self):
        with patch("nautobot.extras.models.Status.objects.get_or_create") as mock_get_or_create:
            ids = {"name": "active"}
            attrs = {}
            nautobot.Nautobot.create_status(self.adapter, ids, attrs)
            mock_get_or_create.assert_called_once_with(name="active")
            self.adapter.job.logger.debug.assert_called()

    def test_update_status_noop(self):
        # update_status is a pass-through (no-op)
        nautobot.Nautobot.update_status(self.adapter, {})

    def test_create_platform_success(self):
        with patch("nautobot.dcim.models.Platform.objects.get_or_create") as mock_get_or_create:
            ids = {"name": "Plat1"}
            attrs = {}
            nautobot.Nautobot.create_platform(self.adapter, ids, attrs)
            mock_get_or_create.assert_called_once_with(name="Plat1")
            self.adapter.job.logger.debug.assert_called()

    def test_update_platform_noop(self):
        nautobot.Nautobot.update_platform(self.adapter, {})

    def test_create_role_success(self):
        with patch("nautobot.extras.models.Role.objects.get_or_create") as mock_get_or_create:
            ids = {"name": "Role1"}
            attrs = {}
            nautobot.Nautobot.create_role(self.adapter, ids, attrs)
            mock_get_or_create.assert_called_once_with(name="Role1")
            self.adapter.job.logger.debug.assert_called()

    def test_update_role_noop(self):
        nautobot.Nautobot.update_role(self.adapter, {})

    def test_create_namespace_success(self):
        with patch("nautobot.ipam.models.Namespace.objects.get_or_create") as mock_get_or_create:
            ids = {"name": "ns1"}
            attrs = {}
            nautobot.Nautobot.create_namespace(self.adapter, ids, attrs)
            mock_get_or_create.assert_called_once_with(name="ns1")
            self.adapter.job.logger.debug.assert_called()

    def test_update_namespace_noop(self):
        nautobot.Nautobot.update_namespace(self.adapter, {})

    def test_create_tenant_success(self):
        with patch("nautobot.tenancy.models.Tenant.objects.get_or_create") as mock_get_or_create:
            ids = {"name": "Tenant1"}
            attrs = {}
            nautobot.Nautobot.create_tenant(self.adapter, ids, attrs)
            mock_get_or_create.assert_called_once_with(name="Tenant1")
            self.adapter.job.logger.debug.assert_called()

    def test_update_tenant_noop(self):
        nautobot.Nautobot.update_tenant(self.adapter, {})