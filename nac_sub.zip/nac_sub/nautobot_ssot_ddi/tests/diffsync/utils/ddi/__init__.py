# Ensures test discovery for this package
