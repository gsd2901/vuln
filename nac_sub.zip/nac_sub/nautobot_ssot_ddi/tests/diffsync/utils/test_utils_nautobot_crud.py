from django.test import TestCase
from unittest.mock import MagicMock, patch
from nautobot_ssot_ddi.diffsync.utils import nautobot

class TestNautobotCRUD(TestCase):
    def setUp(self):
        self.adapter = MagicMock()
        self.adapter.job.logger = MagicMock()
        self.adapter.adapter = MagicMock()
        self.adapter.adapter.job.logger = MagicMock()
        self.adapter.name = "TestManufacturer"
        self.adapter.model = "TestDeviceType"

    def test_create_manufacturer_success(self):
        with patch("nautobot.dcim.models.Manufacturer.objects.get_or_create") as mock_get_or_create:
            ids = {"name": "TestManufacturer"}
            attrs = {}
            nautobot.Nautobot.create_manufacturer(self.adapter, ids, attrs)
            mock_get_or_create.assert_called_once_with(name="TestManufacturer")
            self.adapter.job.logger.debug.assert_called()

    def test_create_manufacturer_no_name(self):
        ids = {"name": None}
        attrs = {}
        nautobot.Nautobot.create_manufacturer(self.adapter, ids, attrs)
        self.adapter.job.logger.warning.assert_called_with("Manufacturer create called without name")

    def test_update_manufacturer_success(self):
        mock_obj = MagicMock()
        mock_obj.name = "TestManufacturer"
        with patch("nautobot.dcim.models.Manufacturer.objects.filter") as mock_filter:
            mock_filter.return_value.first.return_value = mock_obj
            attrs = {"name": "NewName"}
            nautobot.Nautobot.update_manufacturer(self.adapter, attrs)
            self.assertEqual(mock_obj.name, "NewName")
            mock_obj.save.assert_called_once()
            self.adapter.adapter.job.logger.debug.assert_called()

    def test_update_manufacturer_missing(self):
        with patch("nautobot.dcim.models.Manufacturer.objects.filter") as mock_filter:
            mock_filter.return_value.first.return_value = None
            attrs = {"name": "NewName"}
            nautobot.Nautobot.update_manufacturer(self.adapter, attrs)
            self.adapter.adapter.job.logger.warning.assert_called_with(
                "Manufacturer %s missing for update", self.adapter.name
            )

    def test_create_device_type_success(self):
        with patch("nautobot.dcim.models.DeviceType.objects.get_or_create") as mock_get_or_create, \
             patch("nautobot.dcim.models.Manufacturer.objects.filter") as mock_filter, \
             patch("nautobot.dcim.models.Manufacturer.objects.create") as mock_create:
            mock_filter.return_value.first.return_value = None
            mock_create.return_value = MagicMock()
            ids = {"model": "TestDeviceType"}
            attrs = {"manufacturer": "TestManufacturer"}
            nautobot.Nautobot.create_device_type(self.adapter, ids, attrs)
            mock_create.assert_called_once_with(name="TestManufacturer")
            mock_get_or_create.assert_called_once()
            self.adapter.job.logger.debug.assert_called()

    def test_update_device_type_success(self):
        mock_obj = MagicMock()
        mock_obj.model = "TestDeviceType"
        with patch("nautobot.dcim.models.DeviceType.objects.filter") as mock_filter:
            mock_filter.return_value.first.return_value = mock_obj
            attrs = {"model": "NewModel"}
            nautobot.Nautobot.update_device_type(self.adapter, attrs)
            self.assertEqual(mock_obj.model, "NewModel")
            mock_obj.save.assert_called_once()
            self.adapter.adapter.job.logger.debug.assert_called()

    def test_update_device_type_missing(self):
        with patch("nautobot.dcim.models.DeviceType.objects.filter") as mock_filter:
            mock_filter.return_value.first.return_value = None
            attrs = {"model": "NewModel"}
            nautobot.Nautobot.update_device_type(self.adapter, attrs)
            self.adapter.adapter.job.logger.warning.assert_called_with(
                "Device Type %s missing for update", self.adapter.model
            )
