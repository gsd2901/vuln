from django.test import TestCase
from unittest.mock import MagicMock, patch
from nautobot_ssot_ddi.diffsync.utils import nautobot

class TestNautobotUtils(TestCase):
    @patch('nautobot.dcim.models.Manufacturer')
    def test_create_manufacturer(self, MockManufacturer):
        adapter = MagicMock()
        adapter.job.logger = MagicMock()
        ids = {'name': 'TestManu'}
        attrs = {}
        MockManufacturer.objects.get_or_create.return_value = (MagicMock(), True)
        nautobot.Nautobot.create_manufacturer(adapter, ids, attrs)
        MockManufacturer.objects.get_or_create.assert_called_with(name='TestManu')
        adapter.job.logger.debug.assert_called()

    @patch('nautobot.dcim.models.Manufacturer')
    def test_update_manufacturer(self, MockManufacturer):
        adapter = MagicMock()
        adapter.name = 'TestManu'
        adapter.adapter.job.logger = MagicMock()
        attrs = {'name': 'TestManuUpdated'}
        obj = MagicMock()
        MockManufacturer.objects.filter.return_value.first.return_value = obj
        nautobot.Nautobot.update_manufacturer(adapter, attrs)
        self.assertEqual(obj.name, 'TestManuUpdated')
        obj.save.assert_called()
        adapter.adapter.job.logger.debug.assert_called()

    @patch('nautobot.dcim.models.DeviceType')
    @patch('nautobot.dcim.models.Manufacturer')
    def test_create_device_type(self, MockManufacturer, MockDeviceType):
        adapter = MagicMock()
        adapter.job.logger = MagicMock()
        ids = {'model': 'TestModel'}
        attrs = {'manufacturer': 'TestManu'}
        MockManufacturer.objects.filter.return_value.first.return_value = None
        MockManufacturer.objects.create.return_value = MagicMock()
        MockDeviceType.objects.get_or_create.return_value = (MagicMock(), True)
        nautobot.Nautobot.create_device_type(adapter, ids, attrs)
        MockDeviceType.objects.get_or_create.assert_called()
        adapter.job.logger.debug.assert_called()

    @patch('nautobot.dcim.models.DeviceType')
    def test_update_device_type(self, MockDeviceType):
        adapter = MagicMock()
        adapter.model = 'TestModel'
        adapter.adapter.job.logger = MagicMock()
        attrs = {'model': 'TestModelUpdated'}
        obj = MagicMock()
        MockDeviceType.objects.filter.return_value.first.return_value = obj
        nautobot.Nautobot.update_device_type(adapter, attrs)
        self.assertEqual(obj.model, 'TestModelUpdated')
        obj.save.assert_called()
        adapter.adapter.job.logger.debug.assert_called()

    @patch('nautobot.dcim.models.LocationType')
    @patch('nautobot.dcim.models.Location')
    @patch('nautobot.extras.models.Status')
    def test_create_location(self, MockStatus, MockLocation, MockLocationType):
        adapter = MagicMock()
        adapter.job.logger = MagicMock()
        ids = {'name': 'TestLoc'}
        attrs = {'status__name': 'Active'}
        MockLocationType.objects.get_or_create.return_value = (MagicMock(), True)
        MockStatus.objects.filter.return_value.first.return_value = None
        MockStatus.objects.create.return_value = MagicMock()
        MockLocation.object.get_or_create.return_value = (MagicMock(), True)
        nautobot.Nautobot.create_location(adapter, ids, attrs)
        MockLocation.object.get_or_create.assert_called()
        adapter.job.logger.debug.assert_called()

    @patch('nautobot.dcim.models.Location')
    @patch('nautobot.extras.models.Status')
    def test_update_location(self, MockStatus, MockLocation):
        adapter = MagicMock()
        adapter.name = 'TestLoc'
        adapter.adapter.job.logger = MagicMock()
        attrs = {'name': 'TestLocUpdated', 'status__name': 'Active'}
        obj = MagicMock()
        MockLocation.objects.filter.return_value.first.return_value = obj
        MockStatus.objects.filter.return_value.first.return_value = MagicMock()
        nautobot.Nautobot.update_location(adapter, attrs)
        self.assertEqual(obj.name, 'TestLocUpdated')
        obj.save.assert_called()
        adapter.adapter.job.logger.debug.assert_called()

    @patch('nautobot.extras.models.Status')
    def test_create_status(self, MockStatus):
        adapter = MagicMock()
        adapter.job.logger = MagicMock()
        ids = {'name': 'Active'}
        attrs = {}
        MockStatus.objects.get_or_create.return_value = (MagicMock(), True)
        nautobot.Nautobot.create_status(adapter, ids, attrs)
        MockStatus.objects.get_or_create.assert_called_with(name='Active')
        adapter.job.logger.debug.assert_called()

    @patch('nautobot.dcim.models.Platform')
    def test_create_platform(self, MockPlatform):
        adapter = MagicMock()
        adapter.job.logger = MagicMock()
        ids = {'name': 'TestPlatform'}
        attrs = {}
        MockPlatform.objects.get_or_create.return_value = (MagicMock(), True)
        nautobot.Nautobot.create_platform(adapter, ids, attrs)
        MockPlatform.objects.get_or_create.assert_called_with(name='TestPlatform')
        adapter.job.logger.debug.assert_called()

    @patch('nautobot.extras.models.Role')
    def test_create_role(self, MockRole):
        adapter = MagicMock()
        adapter.job.logger = MagicMock()
        ids = {'name': 'TestRole'}
        attrs = {}
        MockRole.objects.get_or_create.return_value = (MagicMock(), True)
        nautobot.Nautobot.create_role(adapter, ids, attrs)
        MockRole.objects.get_or_create.assert_called_with(name='TestRole')
        adapter.job.logger.debug.assert_called()

    @patch('nautobot.ipam.models.Namespace')
    def test_create_namespace(self, MockNamespace):
        adapter = MagicMock()
        adapter.job.logger = MagicMock()
        ids = {'name': 'TestNS'}
        attrs = {}
        MockNamespace.objects.get_or_create.return_value = (MagicMock(), True)
        nautobot.Nautobot.create_namespace(adapter, ids, attrs)
        MockNamespace.objects.get_or_create.assert_called_with(name='TestNS')
        adapter.job.logger.debug.assert_called()

    @patch('nautobot.ipam.models.VLAN')
    @patch('nautobot.extras.models.Status')
    def test_create_vlan(self, MockStatus, MockVLAN):
        adapter = MagicMock()
        adapter.job.logger = MagicMock()
        ids = {'vid': 100}
        attrs = {'name': 'TestVLAN', 'status_id': 'Active'}
        MockStatus.objects.filter.return_value.first.return_value = MagicMock()
        MockVLAN.objects.get_or_create.return_value = (MagicMock(), True)
        nautobot.Nautobot.create_vlan(adapter, ids, attrs)
        MockVLAN.objects.get_or_create.assert_called()
        adapter.job.logger.debug.assert_called()

    @patch('nautobot.ipam.models.VLAN')
    def test_update_vlan(self, MockVLAN):
        adapter = MagicMock()
        adapter.vid = 100
        adapter.adapter.job.logger = MagicMock()
        attrs = {'name': 'TestVLANUpdated'}
        obj = MagicMock()
        MockVLAN.objects.filter.return_value.first.return_value = obj
        nautobot.Nautobot.update_vlan(adapter, attrs)
        self.assertEqual(obj.name, 'TestVLANUpdated')
        obj.save.assert_called()
        adapter.adapter.job.logger.debug.assert_called()

    @patch('nautobot.ipam.models.VRF')
    @patch('nautobot.ipam.models.Namespace')
    @patch('nautobot.tenancy.models.Tenant')
    def test_create_vrf(self, MockTenant, MockNamespace, MockVRF):
        adapter = MagicMock()
        adapter.job.logger = MagicMock()
        ids = {'name': 'TestVRF', 'namespace': 'TestNS'}
        attrs = {'rd': '12345', 'tenant_name': 'TestTenant'}
        MockNamespace.objects.filter.return_value.first.return_value = None
        MockTenant.objects.create.return_value = MagicMock()
        MockVRF.objects.get_or_create.return_value = (MagicMock(), True)
        nautobot.Nautobot.create_vrf(adapter, ids, attrs)
        MockVRF.objects.get_or_create.assert_called()
        adapter.job.logger.debug.assert_called()

    @patch('nautobot.ipam.models.VRF')
    def test_update_vrf(self, MockVRF):
        adapter = MagicMock()
        adapter.name = 'TestVRF'
        adapter.namespace = 'TestNS'
        adapter.adapter.job.logger = MagicMock()
        attrs = {'rd': '54321'}
        obj = MagicMock()
        MockVRF.objects.filter.return_value.first.return_value = obj
        nautobot.Nautobot.update_vrf(adapter, attrs)
        self.assertEqual(obj.rd, '54321')
        obj.save.assert_called()
        adapter.adapter.job.logger.debug.assert_called()

    @patch('nautobot.ipam.models.Prefix')
    @patch('nautobot.ipam.models.Namespace')
    @patch('nautobot.ipam.models.VLAN')
    @patch('nautobot.extras.models.Status')
    def test_create_prefix(self, MockStatus, MockVLAN, MockNamespace, MockPrefix):
        adapter = MagicMock()
        adapter.job.logger = MagicMock()
        ids = {'prefix': '10.0.0.0/24', 'namespace': 'TestNS'}
        attrs = {'status': 'Active', 'vlan__name': 'TestVLAN'}
        MockNamespace.objects.filter.return_value.first.return_value = MagicMock()
        MockStatus.objects.filter.return_value.first.return_value = MagicMock()
        MockVLAN.objects.filter.return_value.first.return_value = MagicMock()
        MockPrefix.objects.get_or_create.return_value = (MagicMock(), True)
        nautobot.Nautobot.create_prefix(adapter, ids, attrs)
        MockPrefix.objects.get_or_create.assert_called()

    @patch('nautobot.ipam.models.Prefix')
    @patch('nautobot.ipam.models.Namespace')
    @patch('nautobot.ipam.models.VLAN')
    @patch('nautobot.extras.models.Status')
    def test_update_prefix(self, MockStatus, MockVLAN, MockNamespace, MockPrefix):
        adapter = MagicMock()
        adapter.prefix = '10.0.0.0/24'
        adapter.namespace = 'TestNS'
        adapter.adapter.job.logger = MagicMock()
        attrs = {'status': 'Active', 'vlan__name': 'TestVLAN'}
        namespace_obj = MagicMock()
        MockNamespace.objects.filter.return_value.first.return_value = namespace_obj
        obj = MagicMock()
        MockPrefix.objects.filter.return_value.first.return_value = obj
        MockStatus.objects.filter.return_value.first.return_value = MagicMock()
        MockVLAN.objects.filter.return_value.first.return_value = MagicMock()
        nautobot.Nautobot.update_prefix(adapter, attrs)
        obj.save.assert_called()
        adapter.adapter.job.logger.debug.assert_called()

    @patch('nautobot.dcim.models.Device')
    @patch('nautobot.dcim.models.DeviceType')
    @patch('nautobot.dcim.models.Location')
    @patch('nautobot.dcim.models.Platform')
    @patch('nautobot.extras.models.Status')
    @patch('nautobot.ipam.models.IPAddress')
    def test_update_device(self, MockIPAddress, MockStatus, MockPlatform, MockLocation, MockDeviceType, MockDevice):
        adapter = MagicMock()
        adapter.name = 'TestDevice'
        adapter.adapter.job.logger = MagicMock()
        attrs = {
            'serial': 'ABC123',
            'device_type__model': 'TestModel',
            'location__name': 'TestLoc',
            'platform__name': 'TestPlatform',
            'status__name': 'Active',
            'primary_ip4__host': '10.0.0.1'
        }
        obj = MagicMock()
        MockDevice.objects.filter.return_value.first.return_value = obj
        MockDeviceType.objects.filter.return_value.first.return_value = MagicMock()
        MockLocation.objects.filter.return_value.first.return_value = MagicMock()
        MockPlatform.objects.filter.return_value.first.return_value = MagicMock()
        MockStatus.objects.filter.return_value.first.return_value = MagicMock()
        MockIPAddress.objects.filter.return_value.first.return_value = MagicMock()
        nautobot.Nautobot.update_device(adapter, attrs)
        obj.save.assert_called()
        adapter.adapter.job.logger.debug.assert_called()

    @patch('nautobot.dcim.models.Device')
    @patch('nautobot.dcim.models.Interface')
    @patch('nautobot.extras.models.Status')
    def test_create_interface(self, MockStatus, MockInterface, MockDevice):
        adapter = MagicMock()
        adapter.job.logger = MagicMock()
        ids = {'device__name': 'TestDevice', 'name': 'TestIface'}
        attrs = {'enabled': True, 'type': 'other', 'description': 'desc', 'status': 'Active'}
        device_obj = MagicMock()
        MockDevice.objects.filter.return_value.first.return_value = device_obj
        MockStatus.objects.filter.return_value.first.return_value = MagicMock()
        MockInterface.objects.get_or_create.return_value = (MagicMock(), True)
        nautobot.Nautobot.create_interface(adapter, ids, attrs)
        MockInterface.objects.get_or_create.assert_called()
        adapter.job.logger.debug.assert_called()

    @patch('nautobot.dcim.models.Device')
    @patch('nautobot.dcim.models.Interface')
    @patch('nautobot.extras.models.Status')
    def test_update_interface(self, MockStatus, MockInterface, MockDevice):
        adapter = MagicMock()
        adapter.device__name = 'TestDevice'
        adapter.name = 'TestIface'
        adapter.adapter.job.logger = MagicMock()
        attrs = {'status': 'Active'}
        device_obj = MagicMock()
        MockDevice.objects.filter.return_value.first.return_value = device_obj
        iface_obj = MagicMock()
        MockInterface.objects.filter.return_value.first.return_value = iface_obj
        MockStatus.objects.filter.return_value.first.return_value = MagicMock()
        # Ensure iface_obj is returned by Interface.objects.filter(name=iface_name).filter()
        MockInterface.objects.filter.return_value.filter.return_value = iface_obj
        nautobot.Nautobot.update_interface(adapter, attrs)
        iface_obj.save.assert_called()
        adapter.adapter.job.logger.debug.assert_called()

    @patch('nautobot.ipam.models.IPAddress')
    @patch('nautobot.ipam.models.Namespace')
    @patch('nautobot.extras.models.Status')
    @patch('nautobot.extras.models.Role')
    def test_create_ipaddress(self, MockRole, MockStatus, MockNamespace, MockIPAddress):
        adapter = MagicMock()
        adapter.job.logger = MagicMock()
        ids = {'host': '10.0.0.1'}
        attrs = {'namespace': 'TestNS', 'status': 'Active', 'role': 'TestRole'}
        MockNamespace.objects.filter.return_value.first.return_value = MagicMock()
        MockStatus.objects.filter.return_value.first.return_value = MagicMock()
        MockRole.objects.filter.return_value.first.return_value = MagicMock()
        MockIPAddress.objects.filter.return_value.first.return_value = None
        MockIPAddress.objects.create.return_value = MagicMock()
        nautobot.Nautobot.create_ipaddress(adapter, ids, attrs)
        MockIPAddress.objects.create.assert_called()
        adapter.job.logger.info.assert_called()

    @patch('nautobot.ipam.models.IPAddress')
    @patch('nautobot.extras.models.Status')
    def test_update_ipaddress(self, MockStatus, MockIPAddress):
        adapter = MagicMock()
        adapter.host = '10.0.0.1'
        adapter.adapter.job.logger = MagicMock()
        attrs = {'status_id': 'Active'}
        obj = MagicMock()
        MockIPAddress.objects.filter.return_value.first.return_value = obj
        MockStatus.objects.filter.return_value.first.return_value = MagicMock()
        nautobot.Nautobot.update_ipaddress(adapter, attrs)
        obj.save.assert_called()
        adapter.adapter.job.logger.debug.assert_called()
