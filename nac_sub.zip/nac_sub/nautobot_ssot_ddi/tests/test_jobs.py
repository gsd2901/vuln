from django.test import TestCase
from unittest.mock import MagicMock, patch
from nautobot_ssot_ddi.jobs import DdiSSOTJob, jobs

class TestDdiSSOTJob(TestCase):
    def setUp(self):
        self.job = DdiSSOTJob()
        self.job.logger = MagicMock()
        self.job.ddi_controller = MagicMock()
        self.job.diffsync_flags = MagicMock()
        self.job.dryrun = False

    def test_load_source_adapter(self):
        with patch("nautobot_ssot_ddi.diffsync.adapters.ddi.DdiAdapter") as mock_adapter:
            instance = mock_adapter.return_value
            instance.load.return_value = None
            self.job.load_source_adapter()
            mock_adapter.assert_called_once_with(ddi=self.job.ddi_controller, job=self.job)
            instance.load.assert_called_once()
            # Should be called 4 times for all debug logs in load_source_adapter
            self.assertGreaterEqual(self.job.logger.debug.call_count, 4)

    def test_load_target_adapter(self):
        with patch("nautobot_ssot_ddi.diffsync.adapters.nautobot.DdiSSOtNautobotAdapter") as mock_adapter:
            source_adapter = MagicMock()
            target_adapter = mock_adapter.return_value
            target_adapter.load.return_value = None
            target_adapter.diff_from.return_value.summary.return_value = {"Device": 1}
            self.job.source_adapter = source_adapter
            self.job.target_adapter = target_adapter
            # Add VLANs to both source and target to trigger all VLAN logs
            source_vlan = MagicMock(get_unique_id=lambda: 1, vid=100, name="VLAN100", status="active", status__name=None)
            target_vlan = MagicMock(get_unique_id=lambda: 2, vid=200, name="VLAN200", status__name="active")
            source_adapter.get_all.return_value = [source_vlan]
            target_adapter.get_all.return_value = [target_vlan]
            self.job.load_target_adapter()
            mock_adapter.assert_called_once_with(ddi=self.job.ddi_controller, job=self.job)
            target_adapter.load.assert_called_once()
            target_adapter.diff_from.assert_called_once_with(source_adapter, flags=self.job.diffsync_flags)
            self.job.logger.info.assert_any_call("Diff summary: %s", {"Device": 1})
            self.job.logger.info.assert_any_call("=== VLANs FROM SOURCE (DDI) ===")
            self.job.logger.info.assert_any_call("=== VLANs FROM TARGET (Nautobot) ===")
            # Check the DST VLAN log is called
            self.job.logger.info.assert_any_call(
                "DST VLAN: id=%s vid=%s name=%s status=%s",
                2, 200, "VLAN200", "active"
            )

    def test_run(self):
        # Patch super().run to avoid actual execution
        with patch("nautobot_ssot_ddi.jobs.DataSource.run", return_value="result") as mock_run:
            ddi_controller = MagicMock()
            result = DdiSSOTJob.run(self.job, ddi_controller=ddi_controller, dryrun=True, extra=1)
            mock_run.assert_called_once()
            self.assertEqual(result, "result")
            # Check assignments
            self.assertIs(self.job.ddi_controller, ddi_controller)
            self.assertTrue(self.job.dryrun)
            from diffsync.enum import DiffSyncFlags
            self.assertEqual(self.job.diffsync_flags, DiffSyncFlags.SKIP_UNMATCHED_DST)

    def test_jobs_registration(self):
        from nautobot_ssot_ddi import jobs as jobs_module
        self.assertIn(DdiSSOTJob, jobs_module.jobs)
