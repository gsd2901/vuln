from django.test import TestCase
from unittest.mock import MagicMock, patch
from nautobot_ssot_ddi.diffsync.adapters.ddi import DdiAdapter

class TestDdiAdapter(TestCase):
    def setUp(self):
        self.mock_controller = MagicMock()
        self.mock_job = MagicMock()
        self.mock_logger = MagicMock()
        self.mock_job.logger = self.mock_logger
        self.mock_ddi = MagicMock()
        self.mock_ddi.session = MagicMock()
        self.mock_ddi.base_url = 'http://mock-url/'
        patcher = patch('nautobot_ssot_ddi.diffsync.utils.ddi.Ddi', return_value=self.mock_ddi)
        self.addCleanup(patcher.stop)
        self.mock_ddi_class = patcher.start()
        self.adapter = DdiAdapter(name='ddi', ddi=self.mock_controller, job=self.mock_job, base_url='http://mock-url/')

    def test_init_sets_attributes(self):
        self.assertEqual(self.adapter.job, self.mock_job)
        self.assertEqual(self.adapter.ddi, self.mock_controller)
        self.assertEqual(self.adapter.url, 'http://mock-url/')

    @patch('nautobot_ssot_ddi.diffsync.utils.ddi.fetch_devices.fetch_ddi_data')
    def test_fetch_from_ddi(self, mock_fetch):
        mock_fetch.return_value = {'result': 'ok'}
        result = self.adapter.fetch_from_ddi()
        self.mock_logger.debug.assert_called_with('Here we are calling fetch_from_ddi')
        self.assertEqual(result, {'result': 'ok'})

    @patch('nautobot_ssot_ddi.diffsync.utils.ddi.fetch_devices.fetch_vlan_data')
    def test_fetch_vlan_from_ddi(self, mock_fetch_vlan):
        mock_fetch_vlan.return_value = {'vlans': []}
        result = self.adapter.fetch_vlan_from_ddi()
        self.assertEqual(result, {'vlans': []})

    @patch('nautobot_ssot_ddi.diffsync.utils.ddi.transformer.transform_record')
    def test_transform_ddi_record(self, mock_transform):
        mock_transform.return_value = {'transformed': True}
        result = self.adapter.transform_ddi_record({'raw': 1})
        self.assertEqual(result, {'transformed': True})

    def test_add_if_missing_adds_and_skips(self):
        class Dummy:
            def __init__(self, name):
                self.name = name
        self.adapter._objects = {'Dummy': {'foo': Dummy('foo')}}
        self.adapter.add = MagicMock()
        self.adapter._add_if_missing(Dummy, 'name', 'bar', name='bar')
        self.adapter.add.assert_called_once()
        self.adapter.add.reset_mock()
        self.adapter._add_if_missing(Dummy, 'name', 'foo', name='foo')
        self.adapter.add.assert_not_called()

    def test_get_objects_of_type(self):
        class Dummy:
            __name__ = 'Dummy'
        dummy_obj = Dummy()
        self.adapter._objects = {'Dummy': {'foo': dummy_obj}}
        objs = self.adapter._get_objects_of_type(Dummy)
        self.assertIn(dummy_obj, objs)

    def test_entity_convenience_methods(self):
        self.adapter._add_if_missing = MagicMock()
        self.adapter.ensure_manufacturer('test')
        self.adapter._add_if_missing.assert_called_with(self.adapter.manufacturer, 'name', 'test', name='test')
        self.adapter.ensure_device_type('model')
        self.adapter._add_if_missing.assert_called_with(self.adapter.device_type, 'model', 'model', model='model')
        self.adapter.add = MagicMock()
        self.adapter.ensure_location('loc', 'active')
        self.adapter.add.assert_called()
        self.adapter.ensure_status('active')
        self.adapter._add_if_missing.assert_called_with(self.adapter.status, 'name', 'active', name='active')
        self.adapter.ensure_platform('plat')
        self.adapter._add_if_missing.assert_called_with(self.adapter.platform, 'name', 'plat', name='plat')
        self.adapter.ensure_role('role')
        self.adapter._add_if_missing.assert_called_with(self.adapter.role, 'name', 'role', name='role')
        self.adapter.ensure_namespace('ns')
        self.adapter._add_if_missing.assert_called_with(self.adapter.namespace, 'name', 'ns', name='ns')
        self.adapter.ensure_tenant('tenant')
        self.adapter._add_if_missing.assert_called_with(self.adapter.tenant, 'name', 'tenant', name='tenant')
        self.adapter.ensure_prefix('1.2.3.0/24', 'ns', 'active', 'vlan', 'tenant')
        self.adapter._add_if_missing.assert_called_with(self.adapter.prefix, 'prefix', '1.2.3.0/24', prefix='1.2.3.0/24', namespace='ns', status='active', vlan__name='vlan', tenant_name='tenant')
