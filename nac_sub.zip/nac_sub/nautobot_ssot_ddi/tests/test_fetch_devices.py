from django.test import TestCase
from unittest.mock import MagicMock
from nautobot_ssot_ddi.diffsync.utils.ddi import fetch_devices

class TestFetchDdiData(TestCase):
    def setUp(self):
        self.session = MagicMock()
        self.logger = MagicMock()
        self.api_host = "http://mock-api"

    def test_fetch_ddi_data_empty(self):
        self.session.get.side_effect = [
            MagicMock(json=lambda: [], raise_for_status=lambda: None),
            MagicMock(json=lambda: [], raise_for_status=lambda: None),
        ] + [MagicMock(json=lambda: [], raise_for_status=lambda: None)] * 1
        result = fetch_devices.fetch_ddi_data(self.session, self.api_host, self.logger)
        self.assertEqual(result, [])

    def test_fetch_ddi_data_with_prefix_vlan_ip(self):
        self.session.get.side_effect = [
            MagicMock(json=lambda: [{"network": "10.0.0.0/24"}], raise_for_status=lambda: None),
            MagicMock(json=lambda: [{"id": 1, "name": "VLAN1", "assigned_to": ["network/...:10.0.0.0/24/default"]}], raise_for_status=lambda: None),
            MagicMock(json=lambda: [{"ip_address": "10.0.0.1", "status": "USED"}], raise_for_status=lambda: None),
        ]
        result = fetch_devices.fetch_ddi_data(self.session, self.api_host, self.logger)
        self.assertEqual(len(result), 1)
        self.assertEqual(result[0]["prefix"], "10.0.0.0/24")
        self.assertEqual(result[0]["vlanName"], "VLAN1")
        self.assertEqual(result[0]["vid"], 1)
        self.assertEqual(result[0]["ip"], "10.0.0.1")
        self.assertEqual(result[0]["ip_status"], "USED")
        self.assertEqual(result[0]["namespace"], "DDI")
        self.assertEqual(result[0]["tenant"], "DDI")
        self.assertEqual(result[0]["role"], "DDI")

    def test_fetch_ddi_data_ip_missing(self):
        self.session.get.side_effect = [
            MagicMock(json=lambda: [{"network": "10.0.0.0/24"}], raise_for_status=lambda: None),
            MagicMock(json=lambda: [{"id": 1, "name": "VLAN1", "assigned_to": ["network/...:10.0.0.0/24/default"]}], raise_for_status=lambda: None),
            MagicMock(json=lambda: [{"status": "USED"}], raise_for_status=lambda: None),
        ]
        result = fetch_devices.fetch_ddi_data(self.session, self.api_host, self.logger)
        self.assertEqual(result, [])

    def test_fetch_ddi_data_vlan_no_assigned(self):
        self.session.get.side_effect = [
            MagicMock(json=lambda: [{"network": "10.0.0.0/24"}], raise_for_status=lambda: None),
            MagicMock(json=lambda: [{"id": 1, "name": "VLAN1"}], raise_for_status=lambda: None),
            MagicMock(json=lambda: [{"ip_address": "10.0.0.1", "status": "USED"}], raise_for_status=lambda: None),
        ]
        result = fetch_devices.fetch_ddi_data(self.session, self.api_host, self.logger)
        self.assertEqual(result[0]["vlanName"], None)
        self.assertEqual(result[0]["vid"], None)
