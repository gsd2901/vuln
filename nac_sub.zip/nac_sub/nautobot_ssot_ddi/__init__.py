from nautobot.apps import NautobotAppConfig

__version__ = "0.1.0"

class NautobotSSOTDdiConfig(NautobotAppConfig):
    name = "nautobot_ssot_ddi"
    verbose_name = "Nautobot SSoT Ddi"
    version = __version__
    author = "Akhil Shaik"
    author_email = "shikm@gmail.com"
    description = "Plugin to sync Ddi devices into Nautobot using SSoT DiffSync."
    base_url = "nautobot-ssot-ddi"
    required_settings = []
    default_settings = {}
    caching_config = {}

    def ready(self):
        """Called when the plugin is loaded."""
        super().ready()

config = NautobotSSOTDdiConfig