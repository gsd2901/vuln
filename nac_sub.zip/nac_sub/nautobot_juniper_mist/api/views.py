# nautobot_juniper_mist/api/views.py
"""
REST API views for Mist plugin
"""

from rest_framework import viewsets, status
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from django_filters.rest_framework import DjangoFilterBackend
from nautobot.apps.api import NautobotModelViewSet

from ..models import (
    MistOrganization, MistSite, MistDevice, 
    MistTemplate, SiteOnboardingRequest
)
from .serializers import (
    MistOrganizationSerializer, MistSiteSerializer, MistDeviceSerializer,
    MistTemplateSerializer, SiteOnboardingRequestSerializer
)


class MistOrganizationViewSet(NautobotModelViewSet):
    """API viewset for Mist Organizations"""
    queryset = MistOrganization.objects.all()
    serializer_class = MistOrganizationSerializer
    filterset_fields = ['name', 'mist_id']


class MistSiteViewSet(NautobotModelViewSet):
    """API viewset for Mist Sites"""
    queryset = MistSite.objects.select_related('organization', 'nautobot_site')
    serializer_class = MistSiteSerializer
    filterset_fields = ['name', 'organization', 'country_code', 'timezone']


class MistDeviceViewSet(NautobotModelViewSet):
    """API viewset for Mist Devices"""
    queryset = MistDevice.objects.select_related('site', 'nautobot_device')
    serializer_class = MistDeviceSerializer
    filterset_fields = ['name', 'device_type', 'connected', 'site']


class MistTemplateViewSet(NautobotModelViewSet):
    """API viewset for Mist Templates"""
    queryset = MistTemplate.objects.select_related('organization')
    serializer_class = MistTemplateSerializer
    filterset_fields = ['name', 'template_type', 'organization']


class SiteOnboardingRequestViewSet(NautobotModelViewSet):
    """API viewset for Site Onboarding Requests"""
    queryset = SiteOnboardingRequest.objects.select_related(
        'nautobot_site', 'target_organization', 'created_mist_site'
    )
    serializer_class = SiteOnboardingRequestSerializer
    filterset_fields = ['status', 'target_organization', 'requested_by']