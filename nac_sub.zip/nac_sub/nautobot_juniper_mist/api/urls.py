# nautobot_juniper_mist/api/urls.py
"""
API URL configuration for Mist plugin
"""

from rest_framework.routers import DefaultRouter
from . import views

router = DefaultRouter()
router.register(r'organizations', views.MistOrganizationViewSet)
router.register(r'sites', views.MistSiteViewSet)
router.register(r'devices', views.MistDeviceViewSet)
router.register(r'templates', views.MistTemplateViewSet)
router.register(r'onboarding-requests', views.SiteOnboardingRequestViewSet)

app_name = 'nautobot_juniper_mist-api'
urlpatterns = router.urls