"""
Django tables for Mist plugin
"""

import django_tables2 as tables
from nautobot.apps.tables import BaseTable, BooleanColumn, TagColumn
from .models import MistOrganization, MistSite, MistDevice, MistTemplate


class MistOrganizationTable(BaseTable):
    """
    Table for MistOrganization
    """
    name = tables.LinkColumn()
    site_count = tables.Column(
        accessor='sites__count',
        verbose_name='Sites'
    )
    
    class Meta(BaseTable.Meta):
        model = MistOrganization
        fields = ('name', 'mist_id', 'site_count', 'created', 'last_updated')


class MistSiteTable(BaseTable):
    """
    Table for MistSite
    """
    name = tables.LinkColumn()
    organization = tables.LinkColumn()
    nautobot_site = tables.LinkColumn()
    device_count = tables.Column(
        accessor='devices__count',
        verbose_name='Devices'
    )
    
    class Meta(BaseTable.Meta):
        model = MistSite
        fields = (
            'name', 'organization', 'nautobot_site', 'country_code', 
            'device_count', 'last_sync', 'created'
        )


class MistDeviceTable(BaseTable):
    """
    Table for MistDevice
    """
    name = tables.LinkColumn()
    site = tables.LinkColumn()
    nautobot_device = tables.LinkColumn()
    connected = BooleanColumn()
    
    class Meta(BaseTable.Meta):
        model = MistDevice
        fields = (
            'name', 'device_type', 'site', 'nautobot_device', 'connected', 
            'model', 'mac_address', 'last_sync'
        )


class MistTemplateTable(BaseTable):
    """
    Table for MistTemplate
    """
    name = tables.LinkColumn()
    organization = tables.LinkColumn()
    template_type = tables.Column()
    
    class Meta(BaseTable.Meta):
        model = MistTemplate
        fields = (
            'name', 'template_type', 'organization', 'description', 
            'created_time', 'last_sync'
        )
