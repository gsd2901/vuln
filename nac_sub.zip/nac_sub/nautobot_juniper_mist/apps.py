from django.apps import AppConfig


class JuniperMistConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'juniper_mist'
