"""
Health check command for Mist integration
"""

from django.core.management.base import BaseCommand
from django.conf import settings
from ...api import MistAPIClient
from ...models import MistOrganization, MistSite, MistDevice


class Command(BaseCommand):
    help = 'Perform health check on Mist integration'

    def add_arguments(self, parser):
        parser.add_argument(
            '--detailed',
            action='store_true',
            help='Show detailed health information',
        )

    def handle(self, *args, **options):
        self.stdout.write(self.style.SUCCESS('=== Mist Integration Health Check ===\n'))
        
        # Check configuration
        self._check_configuration()
        
        # Check API connectivity
        self._check_api_connectivity()
        
        # Check data consistency
        self._check_data_consistency()
        
        # Show statistics
        self._show_statistics(options['detailed'])

    def _check_configuration(self):
        """Check plugin configuration"""
        self.stdout.write('1. Configuration Check:')
        
        config = getattr(settings, 'PLUGINS_CONFIG', {}).get('nautobot_juniper_mist', {})
        
        # Check required settings
        mist_host = config.get('mist_host')
        api_token = config.get('mist_api_token')
        
        if mist_host:
            self.stdout.write(f'   ✓ Mist Host: {mist_host}')
        else:
            self.stdout.write('   ✗ Mist Host: Not configured')
        
        if api_token:
            self.stdout.write(f'   ✓ API Token: {"*" * (len(api_token) - 8)}{api_token[-8:]}')
        else:
            self.stdout.write('   ✗ API Token: Not configured')
        
        # Check optional settings
        settings_check = [
            ('sync_interval', 'Sync Interval'),
            ('auto_create_sites', 'Auto Create Sites'),
            ('auto_create_devices', 'Auto Create Devices'),
        ]
        
        for setting_key, setting_name in settings_check:
            value = config.get(setting_key)
            if value is not None:
                self.stdout.write(f'   ✓ {setting_name}: {value}')
            else:
                self.stdout.write(f'   - {setting_name}: Using default')
        
        self.stdout.write('')

    def _check_api_connectivity(self):
        """Check API connectivity"""
        self.stdout.write('2. API Connectivity Check:')
        
        try:
            client = MistAPIClient()
            if client.connect():
                self.stdout.write('   ✓ API Connection: Success')
                
                # Test API call
                orgs = client.get_organizations()
                self.stdout.write(f'   ✓ API Access: Found {len(orgs)} organizations')
                
                # Test specific org access
                if orgs:
                    test_org = orgs[0]
                    sites = client.get_sites(test_org['id'])
                    self.stdout.write(f'   ✓ Site Access: Found {len(sites)} sites in first org')
                
            else:
                self.stdout.write('   ✗ API Connection: Failed')
                
        except Exception as e:
            self.stdout.write(f'   ✗ API Error: {str(e)}')
        
        self.stdout.write('')

    def _check_data_consistency(self):
        """Check data consistency"""
        self.stdout.write('3. Data Consistency Check:')
        
        # Check for orphaned records
        sites_without_org = MistSite.objects.filter(organization__isnull=True).count()
        if sites_without_org:
            self.stdout.write(f'   ⚠ Sites without organization: {sites_without_org}')
        else:
            self.stdout.write('   ✓ All sites have valid organizations')
        
        devices_without_site = MistDevice.objects.filter(site__isnull=True).count()
        if devices_without_site:
            self.stdout.write(f'   ⚠ Devices without site: {devices_without_site}')
        else:
            self.stdout.write('   ✓ All devices have valid sites')
        
        # Check for stale sync data
        from django.utils import timezone
        from datetime import timedelta
        
        week_ago = timezone.now() - timedelta(days=7)
        stale_sites = MistSite.objects.filter(last_sync__lt=week_ago).count()
        if stale_sites:
            self.stdout.write(f'   ⚠ Sites not synced in 7 days: {stale_sites}')
        else:
            self.stdout.write('   ✓ All sites synced within 7 days')
        
        self.stdout.write('')

    def _show_statistics(self, detailed=False):
        """Show system statistics"""
        self.stdout.write('4. System Statistics:')
        
        org_count = MistOrganization.objects.count()
        site_count = MistSite.objects.count()
        device_count = MistDevice.objects.count()
        
        self.stdout.write(f'   • Organizations: {org_count}')
        self.stdout.write(f'   • Sites: {site_count}')
        self.stdout.write(f'   • Devices: {device_count}')
        
        if detailed:
            # Device type breakdown
            device_types = MistDevice.objects.values('device_type').distinct()
            for dt in device_types:
                count = MistDevice.objects.filter(device_type=dt['device_type']).count()
                self.stdout.write(f'     - {dt["device_type"]}: {count}')
            
            # Connected vs disconnected devices
            connected_count = MistDevice.objects.filter(connected=True).count()
            disconnected_count = device_count - connected_count
            self.stdout.write(f'   • Connected Devices: {connected_count}')
            self.stdout.write(f'   • Disconnected Devices: {disconnected_count}')
            
            # Sites by country
            from django.db.models import Count
            countries = MistSite.objects.values('country_code').annotate(
                count=Count('country_code')
            ).order_by('-count')[:5]
            
            if countries:
                self.stdout.write('   • Top 5 Countries:')
                for country in countries:
                    code = country['country_code'] or 'Unknown'
                    self.stdout.write(f'     - {code}: {country["count"]}')
        
        self.stdout.write('')

