"""
Export Mist data to CSV/JSON
"""

import json
import csv
from django.core.management.base import BaseCommand
from django.core.serializers.json import DjangoJSONEncoder
from ...models import MistOrganization, MistSite, MistDevice, MistTemplate


class Command(BaseCommand):
    help = 'Export Mist data to CSV or JSON format'

    def add_arguments(self, parser):
        parser.add_argument(
            '--format',
            choices=['csv', 'json'],
            default='json',
            help='Output format (csv or json)',
        )
        parser.add_argument(
            '--output-file',
            type=str,
            help='Output file path (if not specified, prints to stdout)',
        )
        parser.add_argument(
            '--data-type',
            choices=['sites', 'devices', 'templates', 'all'],
            default='all',
            help='Type of data to export',
        )
        parser.add_argument(
            '--org-id',
            type=str,
            help='Export data for specific organization only',
        )

    def handle(self, *args, **options):
        data = {}
        
        # Filter by organization if specified
        org_filter = {}
        if options['org_id']:
            try:
                org = MistOrganization.objects.get(mist_id=options['org_id'])
                org_filter = {'organization': org}
            except MistOrganization.DoesNotExist:
                self.stdout.write(self.style.ERROR(f'Organization {options["org_id"]} not found'))
                return
        
        # Export data based on type
        if options['data_type'] in ['sites', 'all']:
            data['sites'] = self._export_sites(**org_filter)
        
        if options['data_type'] in ['devices', 'all']:
            data['devices'] = self._export_devices(**org_filter)
        
        if options['data_type'] in ['templates', 'all']:
            data['templates'] = self._export_templates(**org_filter)
        
        # Add metadata
        data['metadata'] = {
            'export_format': options['format'],
            'data_type': options['data_type'],
            'organization_filter': options.get('org_id'),
            'exported_at': str(timezone.now()),
        }
        
        # Output data
        if options['format'] == 'json':
            self._output_json(data, options.get('output_file'))
        else:
            self._output_csv(data, options.get('output_file'), options['data_type'])

    def _export_sites(self, **filters):
        """Export sites data"""
        sites = MistSite.objects.filter(**filters).select_related('organization', 'nautobot_site')
        
        return [
            {
                'mist_id': site.mist_id,
                'name': site.name,
                'organization': site.organization.name,
                'organization_mist_id': site.organization.mist_id,
                'nautobot_site': site.nautobot_site.name if site.nautobot_site else None,
                'address': site.address,
                'country_code': site.country_code,
                'timezone': site.timezone,
                'latitude': site.latitude,
                'longitude': site.longitude,
                'device_count': site.devices.count(),
                'last_sync': site.last_sync.isoformat() if site.last_sync else None,
            }
            for site in sites
        ]

    def _export_devices(self, **filters):
        """Export devices data"""
        # Filter devices by site organization if org filter specified
        device_filters = {}
        if 'organization' in filters:
            device_filters['site__organization'] = filters['organization']
        
        devices = MistDevice.objects.filter(**device_filters).select_related('site', 'nautobot_device')
        
        return [
            {
                'mist_id': device.mist_id,
                'name': device.name,
                'device_type': device.device_type,
                'mac_address': device.mac_address,
                'model': device.model,
                'serial_number': device.serial_number,
                'connected': device.connected,
                'site': device.site.name,
                'site_mist_id': device.site.mist_id,
                'nautobot_device': device.nautobot_device.name if device.nautobot_device else None,
                'uptime': device.uptime,
                'version': device.version,
                'x': device.x,
                'y': device.y,
                'last_sync': device.last_sync.isoformat() if device.last_sync else None,
            }
            for device in devices
        ]

    def _export_templates(self, **filters):
        """Export templates data"""
        templates = MistTemplate.objects.filter(**filters).select_related('organization')
        
        return [
            {
                'mist_id': template.mist_id,
                'name': template.name,
                'template_type': template.template_type,
                'organization': template.organization.name,
                'organization_mist_id': template.organization.mist_id,
                'description': template.description,
                'config': template.config,
                'created_time': template.created_time.isoformat() if template.created_time else None,
                'modified_time': template.modified_time.isoformat() if template.modified_time else None,
                'last_sync': template.last_sync.isoformat() if template.last_sync else None,
            }
            for template in templates
        ]

    def _output_json(self, data, output_file):
        """Output data as JSON"""
        json_str = json.dumps(data, indent=2, cls=DjangoJSONEncoder)
        
        if output_file:
            with open(output_file, 'w') as f:
                f.write(json_str)
            self.stdout.write(self.style.SUCCESS(f'Data exported to {output_file}'))
        else:
            self.stdout.write(json_str)

    def _output_csv(self, data, output_file, data_type):
        """Output data as CSV"""
        if data_type == 'all':
            self.stdout.write(self.style.ERROR('CSV format not supported for --data-type=all. Use specific type or JSON format.'))
            return
        
        if data_type not in data or not data[data_type]:
            self.stdout.write(self.style.WARNING(f'No {data_type} data to export'))
            return
        
        # Get field names from first record
        records = data[data_type]
        fieldnames = list(records[0].keys())
        
        if output_file:
            with open(output_file, 'w', newline='') as f:
                writer = csv.DictWriter(f, fieldnames=fieldnames)
                writer.writeheader()
                writer.writerows(records)
            self.stdout.write(self.style.SUCCESS(f'Data exported to {output_file}'))
        else:
            writer = csv.DictWriter(self.stdout, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerows(records)