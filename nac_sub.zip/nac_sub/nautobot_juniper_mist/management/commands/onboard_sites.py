from django.core.management.base import BaseCommand, CommandError
from django.db import transaction
from nautobot.dcim.models import Site
from ...models import MistOrganization
from ...onboarding import SiteOnboardingManager


class Command(BaseCommand):
    help = 'Onboard Nautobot sites to Mist'

    def add_arguments(self, parser):
        parser.add_argument(
            '--org-id',
            type=str,
            required=True,
            help='Mist Organization ID to onboard sites to',
        )
        parser.add_argument(
            '--site-names',
            nargs='+',
            help='Specific site names to onboard',
        )
        parser.add_argument(
            '--all-sites',
            action='store_true',
            help='Onboard all sites in Nautobot',
        )
        parser.add_argument(
            '--dry-run',
            action='store_true',
            help='Show what would be onboarded without making changes',
        )

    def handle(self, *args, **options):
        try:
            organization = MistOrganization.objects.get(mist_id=options['org_id'])
        except MistOrganization.DoesNotExist:
            raise CommandError(f'Mist Organization {options["org_id"]} not found')
        
        # Get sites to onboard
        if options['all_sites']:
            sites = Site.objects.all()
        elif options['site_names']:
            sites = Site.objects.filter(name__in=options['site_names'])
            if sites.count() != len(options['site_names']):
                found_names = list(sites.values_list('name', flat=True))
                missing = set(options['site_names']) - set(found_names)
                self.stdout.write(
                    self.style.WARNING(f'Sites not found: {", ".join(missing)}')
                )
        else:
            raise CommandError('Must specify either --all-sites or --site-names')
        
        if not sites.exists():
            self.stdout.write(self.style.WARNING('No sites to onboard'))
            return
        
        self.stdout.write(f'Found {sites.count()} sites to onboard to {organization.name}')
        
        if options['dry_run']:
            self.stdout.write(self.style.WARNING('DRY RUN MODE - No changes will be made'))
            for site in sites:
                self.stdout.write(f'  - {site.name}')
            return
        
        # Proceed with onboarding
        manager = SiteOnboardingManager()
        site_ids = list(sites.values_list('id', flat=True))
        
        self.stdout.write('Starting bulk onboarding...')
        
        with transaction.atomic():
            results = manager.bulk_onboard_sites(organization.id, site_ids)
        
        # Print results
        self.stdout.write(
            self.style.SUCCESS(f'Successfully onboarded: {results["success"]} sites')
        )
        
        if results['failed'] > 0:
            self.stdout.write(
                self.style.ERROR(f'Failed to onboard: {results["failed"]} sites')
            )
            for error in results['errors']:
                self.stdout.write(f'  - {error}')