"""
Bulk onboarding management command
"""

import csv
from django.core.management.base import BaseCommand, CommandError
from django.db import transaction
from nautobot.dcim.models import Site
from ...models import MistOrganization, SiteOnboardingRequest
from ...onboarding import SiteOnboardingManager


class Command(BaseCommand):
    help = 'Bulk onboard sites from CSV file'

    def add_arguments(self, parser):
        parser.add_argument(
            '--csv-file',
            type=str,
            required=True,
            help='CSV file path with site data',
        )
        parser.add_argument(
            '--org-id',
            type=str,
            required=True,
            help='Mist Organization ID to onboard sites to',
        )
        parser.add_argument(
            '--dry-run',
            action='store_true',
            help='Show what would be processed without making changes',
        )

    def handle(self, *args, **options):
        try:
            organization = MistOrganization.objects.get(mist_id=options['org_id'])
        except MistOrganization.DoesNotExist:
            raise CommandError(f'Mist Organization {options["org_id"]} not found')
        
        csv_file = options['csv_file']
        
        try:
            with open(csv_file, 'r', newline='', encoding='utf-8') as file:
                reader = csv.DictReader(file)
                
                # Expected CSV columns:
                # site_name, nautobot_site_name, address, country_code, timezone, latitude, longitude, notes
                
                rows = list(reader)
                self.stdout.write(f'Found {len(rows)} rows in CSV file')
                
                if options['dry_run']:
                    self.stdout.write(self.style.WARNING('DRY RUN MODE - No changes will be made'))
                    for row in rows:
                        self.stdout.write(f"  - {row.get('site_name', 'Unnamed')} -> {organization.name}")
                    return
                
                # Process rows
                success_count = 0
                error_count = 0
                
                with transaction.atomic():
                    for row_num, row in enumerate(rows, 1):
                        try:
                            self._process_row(row, organization, row_num)
                            success_count += 1
                        except Exception as e:
                            error_count += 1
                            self.stdout.write(
                                self.style.ERROR(f'Row {row_num} error: {str(e)}')
                            )
                
                self.stdout.write(
                    self.style.SUCCESS(f'Successfully processed: {success_count} rows')
                )
                if error_count > 0:
                    self.stdout.write(
                        self.style.ERROR(f'Failed to process: {error_count} rows')
                    )
                
        except FileNotFoundError:
            raise CommandError(f'CSV file not found: {csv_file}')
        except Exception as e:
            raise CommandError(f'Error reading CSV file: {str(e)}')
    
    def _process_row(self, row, organization, row_num):
        """
        Process a single CSV row
        """
        site_name = row.get('site_name', '').strip()
        nautobot_site_name = row.get('nautobot_site_name', '').strip()
        
        if not site_name:
            raise ValueError(f'site_name is required')
        
        # Find Nautobot site
        nautobot_site = None
        if nautobot_site_name:
            try:
                nautobot_site = Site.objects.get(name=nautobot_site_name)
            except Site.DoesNotExist:
                raise ValueError(f'Nautobot site "{nautobot_site_name}" not found')
        
        # Create onboarding request
        request = SiteOnboardingRequest.objects.create(
            nautobot_site=nautobot_site,
            target_organization=organization,
            site_name=site_name,
            address=row.get('address', '').strip(),
            country_code=row.get('country_code', '').strip(),
            timezone=row.get('timezone', '').strip(),
            latitude=float(row['latitude']) if row.get('latitude', '').strip() else None,
            longitude=float(row['longitude']) if row.get('longitude', '').strip() else None,
            notes=row.get('notes', '').strip(),
            requested_by='bulk_import',
        )
        
        # Process immediately
        manager = SiteOnboardingManager()
        result = manager.process_request(request)
        
        if not result['success']:
            raise Exception(f'Failed to onboard site: {result["error"]}')
        
        self.stdout.write(f'Row {row_num}: Successfully onboarded "{site_name}"')