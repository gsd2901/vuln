from django.core.management.base import BaseCommand
from ...template_manager import TemplateManager


class Command(BaseCommand):
    help = 'Sync templates from Mist'

    def add_arguments(self, parser):
        parser.add_argument(
            '--org-id',
            type=str,
            help='Sync templates from specific organization only',
        )

    def handle(self, *args, **options):
        self.stdout.write('Starting template synchronization...')
        
        manager = TemplateManager()
        result = manager.sync_all_templates()
        
        if result['success']:
            self.stdout.write(
                self.style.SUCCESS(f'Successfully synced {result["synced"]} templates')
            )
            
            if result['errors']:
                self.stdout.write(self.style.WARNING('Warnings:'))
                for error in result['errors']:
                    self.stdout.write(f'  - {error}')
        else:
            self.stdout.write(
                self.style.ERROR(f'Sync failed: {result["error"]}')
            )