"""
Management command to sync Mist data
"""

from django.core.management.base import BaseCommand
from ...sync import MistNautobotSync


class Command(BaseCommand):
    help = 'Synchronize data from Juniper Mist to Nautobot'

    def add_arguments(self, parser):
        parser.add_argument(
            '--org-id',
            type=str,
            help='Sync only specific organization ID',
        )
        parser.add_argument(
            '--site-id',
            type=str,
            help='Sync only specific site ID',
        )
        parser.add_argument(
            '--dry-run',
            action='store_true',
            help='Show what would be synced without making changes',
        )

    def handle(self, *args, **options):
        sync = MistNautobotSync()
        
        if options['dry_run']:
            self.stdout.write(
                self.style.WARNING('DRY RUN MODE - No changes will be made')
            )
            return
        
        self.stdout.write('Starting Mist synchronization...')
        
        try:
            sync_job = sync.sync_all()
            
            if sync_job.status == 'completed':
                self.stdout.write(
                    self.style.SUCCESS(
                        f'Sync completed successfully!\n'
                        f'Sites synced: {sync_job.sites_synced}\n'
                        f'Devices synced: {sync_job.devices_synced}'
                    )
                )
            else:
                self.stdout.write(
                    self.style.ERROR(
                        f'Sync failed: {sync_job.error_message}'
                    )
                )
        except Exception as e:
            self.stdout.write(
                self.style.ERROR(f'Sync error: {str(e)}')
            )