from django import forms
from django.forms import ModelForm
from nautobot.dcim.models.locations import Location as Site
from .models import MistOrganization, MistTemplate, SiteOnboardingRequest


class SiteOnboardingForm(ModelForm):
    """
    Form for onboarding sites to Mist
    """
    
    class Meta:
        model = SiteOnboardingRequest
        fields = [
            'nautobot_site',
            'target_organization',
            'site_name',
            'address',
            'country_code', 
            'timezone',
            'latitude',
            'longitude',
            'notes',
            'rf_template',
            'network_template',
            'gateway_template',
        ]
        widgets = {
            'notes': forms.Textarea(attrs={'rows': 3}),
            'address': forms.Textarea(attrs={'rows': 2}),
        }
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        
        # Pre-populate site data if nautobot_site is selected
        if 'nautobot_site' in self.data:
            try:
                site_id = self.data['nautobot_site']
                site = Site.objects.get(id=site_id)
                
                if not self.data.get('site_name'):
                    self.fields['site_name'].initial = site.name
                if not self.data.get('address') and site.physical_address:
                    self.fields['address'].initial = site.physical_address
                if not self.data.get('latitude') and site.latitude:
                    self.fields['latitude'].initial = site.latitude
                if not self.data.get('longitude') and site.longitude:
                    self.fields['longitude'].initial = site.longitude
                    
            except Site.DoesNotExist:
                pass
        
        # Filter templates by organization
        if 'target_organization' in self.data:
            try:
                org_id = self.data['target_organization']
                org = MistOrganization.objects.get(id=org_id)
                
                self.fields['rf_template'].queryset = MistTemplate.objects.filter(
                    organization=org, template_type='rf'
                )
                self.fields['network_template'].queryset = MistTemplate.objects.filter(
                    organization=org, template_type='network'
                )
                self.fields['gateway_template'].queryset = MistTemplate.objects.filter(
                    organization=org, template_type='gateway'
                )
            except MistOrganization.DoesNotExist:
                pass


class RFTemplateForm(ModelForm):
    """
    Form for creating RF templates
    """
    
    # Basic RF settings
    band_24 = forms.BooleanField(required=False, initial=True, label="2.4 GHz Band")
    band_5 = forms.BooleanField(required=False, initial=True, label="5 GHz Band")
    band_6 = forms.BooleanField(required=False, initial=False, label="6 GHz Band")
    
    # Power settings
    power_2g = forms.IntegerField(
        required=False, 
        min_value=1, 
        max_value=20, 
        initial=17,
        label="2.4G Power (dBm)"
    )
    power_5g = forms.IntegerField(
        required=False, 
        min_value=1, 
        max_value=20, 
        initial=17,
        label="5G Power (dBm)"
    )
    
    # Channel settings
    channel_width_24 = forms.ChoiceField(
        choices=[('20', '20 MHz'), ('40', '40 MHz')],
        initial='20',
        label="2.4G Channel Width"
    )
    channel_width_5 = forms.ChoiceField(
        choices=[('20', '20 MHz'), ('40', '40 MHz'), ('80', '80 MHz'), ('160', '160 MHz')],
        initial='80',
        label="5G Channel Width"
    )
    
    class Meta:
        model = MistTemplate
        fields = ['organization', 'name', 'description']
        widgets = {
            'description': forms.Textarea(attrs={'rows': 3}),
        }
    
    def save(self, commit=True):
        instance = super().save(commit=False)
        instance.template_type = 'rf'
        
        # Build RF config from form data
        config = {
            'band_24': self.cleaned_data.get('band_24', True),
            'band_5': self.cleaned_data.get('band_5', True),
            'band_6': self.cleaned_data.get('band_6', False),
            'power_2g': self.cleaned_data.get('power_2g', 17),
            'power_5g': self.cleaned_data.get('power_5g', 17),
            'channel_width_24': self.cleaned_data.get('channel_width_24', '20'),
            'channel_width_5': self.cleaned_data.get('channel_width_5', '80'),
        }
        instance.config = config
        
        if commit:
            instance.save()
        return instance
    
class NetworkTemplateForm(ModelForm):
    """
    Form for creating Network templates
    """
    
    # VLAN settings
    mgmt_vlan = forms.IntegerField(
        required=False,
        min_value=1,
        max_value=4094,
        initial=1,
        label="Management VLAN"
    )
    
    # Additional VLANs
    additional_vlans = forms.CharField(
        required=False,
        widget=forms.Textarea(attrs={'rows': 3, 'placeholder': 'Enter VLANs (one per line)\nFormat: VLAN_ID:Name\nExample: 100:Users\n200:Guests'}),
        label="Additional VLANs"
    )
    
    class Meta:
        model = MistTemplate
        fields = ['organization', 'name', 'description']
        widgets = {
            'description': forms.Textarea(attrs={'rows': 3}),
        }
    
    def save(self, commit=True):
        instance = super().save(commit=False)
        instance.template_type = 'network'
        
        # Parse additional VLANs
        vlans = {}
        if self.cleaned_data.get('additional_vlans'):
            for line in self.cleaned_data['additional_vlans'].split('\n'):
                line = line.strip()
                if ':' in line:
                    vlan_id, name = line.split(':', 1)
                    try:
                        vlans[int(vlan_id.strip())] = name.strip()
                    except ValueError:
                        continue
        
        config = {
            'mgmt_vlan': self.cleaned_data.get('mgmt_vlan', 1),
            'additional_vlans': vlans,
        }
        instance.config = config
        
        if commit:
            instance.save()
        return instance