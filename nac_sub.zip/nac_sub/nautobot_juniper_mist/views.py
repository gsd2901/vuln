# nautobot_juniper_mist/views.py
"""
Views for Mist plugin
"""

from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from django.views.generic import TemplateView, ListView, CreateView, FormView, DetailView, UpdateView, DeleteView
from django.contrib.auth.mixins import LoginRequiredMixin
from django.urls import reverse_lazy
from django.http import JsonResponse

from .forms import NetworkTemplateForm
from .template_manager import TemplateManager

# Corrected imports for your Nautobot version
from nautobot.apps.views import NautobotViewSetMixin

from .models import (
    MistOrganization, MistSite, MistDevice, MistSyncJob, 
    MistTemplate, SiteOnboardingRequest
)

from .forms import RFTemplateForm

class HomeView(LoginRequiredMixin, TemplateView):
    """
    Main dashboard for Mist plugin
    """
    template_name = 'nautobot_juniper_mist/home.html'
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context.update({
            'org_count': MistOrganization.objects.count(),
            'site_count': MistSite.objects.count(),
            'device_count': MistDevice.objects.count(),
            'recent_jobs': MistSyncJob.objects.order_by('-started_at')[:5],
        })
        return context


class SyncView(LoginRequiredMixin, TemplateView):
    """
    Manual sync trigger view
    """
    template_name = 'nautobot_juniper_mist/sync.html'
    
    def post(self, request, *args, **kwargs):
        try:
            from .sync import MistNautobotSync
            sync = MistNautobotSync()
            sync_job = sync.sync_all()
            if sync_job.status == 'completed':
                messages.success(
                    request,
                    f'Sync completed! {sync_job.sites_synced} sites and '
                    f'{sync_job.devices_synced} devices synchronized.'
                )
            else:
                messages.error(request, f'Sync failed: {sync_job.error_message}')
        except Exception as e:
            messages.error(request, f'Sync error: {str(e)}')
        
        return redirect('plugins:nautobot_juniper_mist:home')


class SiteOnboardingView(LoginRequiredMixin, CreateView):
    """
    View for onboarding sites to Mist
    """
    model = SiteOnboardingRequest
    template_name = 'nautobot_juniper_mist/site_onboarding.html'
    success_url = reverse_lazy('plugins:nautobot_juniper_mist:onboarding_list')
    fields = [
        'nautobot_site', 'target_organization', 'site_name', 'address',
        'country_code', 'timezone', 'latitude', 'longitude', 'notes',
        'rf_template', 'network_template', 'gateway_template'
    ]
    
    def form_valid(self, form):
        # Set the user who made the request
        form.instance.requested_by = self.request.user.username
        response = super().form_valid(form)
        
        messages.success(
            self.request,
            f'Site onboarding request created for {form.instance.site_name}. '
            f'Processing will begin shortly.'
        )
        return response


class OnboardingListView(LoginRequiredMixin, ListView):
    """
    List view for site onboarding requests
    """
    model = SiteOnboardingRequest
    template_name = 'nautobot_juniper_mist/onboarding_list.html'
    context_object_name = 'requests'
    paginate_by = 20
    
    def get_queryset(self):
        # Debug: print all requests
        all_requests = SiteOnboardingRequest.objects.all()
        print(f"DEBUG: Found {all_requests.count()} total requests")
        for req in all_requests:
            print(f"DEBUG: Request {req.id} - {req.site_name} - {req.status}")
        
        return SiteOnboardingRequest.objects.select_related(
            'target_organization',
            'created_mist_site'
        ).order_by('-requested_at')


class ProcessOnboardingView(LoginRequiredMixin, TemplateView):
    """
    Process a specific onboarding request
    """
    def post(self, request, pk):
        onboarding_request = get_object_or_404(SiteOnboardingRequest, pk=pk)
        
        if onboarding_request.status != 'pending':
            messages.error(request, 'This request has already been processed.')
            return redirect('plugins:nautobot_juniper_mist:onboarding_list')
        
        try:
            from .onboarding import SiteOnboardingManager
            manager = SiteOnboardingManager()
            result = manager.process_request(onboarding_request)
            
            if result['success']:
                messages.success(request, f'Site {onboarding_request.site_name} created successfully in Mist!')
            else:
                messages.error(request, f'Failed to create site: {result["error"]}')
                
        except Exception as e:
            messages.error(request, f'Error processing request: {str(e)}')
        
        return redirect('plugins:nautobot_juniper_mist:onboarding_list')


class TemplateListView(LoginRequiredMixin, ListView):
    """
    List view for Mist templates
    """
    model = MistTemplate
    template_name = 'nautobot_juniper_mist/template_list.html'
    context_object_name = 'templates'
    paginate_by = 8
    
    def get_queryset(self):
        queryset = MistTemplate.objects.select_related('organization')
        
        # Filter by template type if specified
        template_type = self.request.GET.get('type')
        if template_type:
            queryset = queryset.filter(template_type=template_type)
        
        # Filter by organization if specified
        org_id = self.request.GET.get('org')
        if org_id:
            queryset = queryset.filter(organization_id=org_id)
        
        return queryset.order_by('organization__name', 'template_type', 'name')
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['organizations'] = MistOrganization.objects.all()
        context['template_types'] = MistTemplate.TEMPLATE_TYPE_CHOICES
        context['current_type'] = self.request.GET.get('type', '')
        context['current_org'] = self.request.GET.get('org', '')
        return context


class OrganizationListView(LoginRequiredMixin, ListView):
    """
    List view for Mist organizations
    """
    model = MistOrganization
    template_name = 'nautobot_juniper_mist/organization_list.html'
    context_object_name = 'organizations'
    paginate_by = 20


class SiteListView(LoginRequiredMixin, ListView):
    """
    List view for Mist sites
    """
    model = MistSite
    template_name = 'nautobot_juniper_mist/site_list.html'
    context_object_name = 'sites'
    paginate_by = 20
    
    def get_queryset(self):
        return MistSite.objects.select_related('organization').order_by('name')


class DeviceListView(LoginRequiredMixin, ListView):
    """
    List view for Mist devices
    """
    model = MistDevice
    template_name = 'nautobot_juniper_mist/device_list.html'
    context_object_name = 'devices'
    paginate_by = 20
    
    def get_queryset(self):
        return MistDevice.objects.select_related('site').order_by('name')


class SyncJobListView(LoginRequiredMixin, ListView):
    """
    List view for sync jobs
    """
    model = MistSyncJob
    template_name = 'nautobot_juniper_mist/sync_job_list.html'
    context_object_name = 'sync_jobs'
    paginate_by = 20
    
    def get_queryset(self):
        return MistSyncJob.objects.order_by('-started_at')


# AJAX endpoint for dynamic form updates
class GetTemplatesAjaxView(LoginRequiredMixin, TemplateView):
    """
    AJAX endpoint to get templates for an organization
    """
    def get(self, request):
        org_id = request.GET.get('org_id')
        template_type = request.GET.get('template_type')
        
        if not org_id:
            return JsonResponse({'templates': []})
        
        try:
            templates = MistTemplate.objects.filter(
                organization_id=org_id,
                template_type=template_type
            ).values('id', 'name')
            
            return JsonResponse({
                'templates': list(templates)
            })
            
        except Exception as e:
            return JsonResponse({'error': str(e)}, status=500)



from django.http import JsonResponse
from .api_client import MistAPIClient

def test_api_connection(request):
    """Debug view to test API connection"""
    client = MistAPIClient()
    
    result = {
        'base_url': client.base_url,
        'has_token': bool(client.api_token),
        'org_id': client.org_id,
        'connection_test': client.connect()
    }
    
    return JsonResponse(result)


class CreateRFTemplateView(LoginRequiredMixin, TemplateView):
    template_name = 'nautobot_juniper_mist/create_rf_template.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        if 'form' not in context:
            context['form'] = RFTemplateForm()
        return context

    def post(self, request, *args, **kwargs):
        form = RFTemplateForm(request.POST)
        if form.is_valid():
            # Prepare template data dict like TemplateManager expects
            cd = form.cleaned_data
            template_data = {
                'name': cd['name'],
                'description': cd['description'],
                'organization_id': cd['organization'].id,
                'template_type': 'rf',
                'config': {
                    'band_24': {
                        'power': cd['power_2g'],
                        'channels': [],  # Provide channels if your form collects them
                    },
                    'band_5': {
                        'power': cd['power_5g'],
                        'channels': [],
                    },
                    'band_6': {'enabled': cd['band_6']},
                },
            }
            from .template_manager import TemplateManager
            manager = TemplateManager()
            result = manager.create_template(template_data)

            if result['success']:
                messages.success(request, f'RF Template "{template_data["name"]}" created successfully in Mist!')
                return redirect('plugins:nautobot_juniper_mist:template_list')
            else:
                messages.error(request, f'Failed to create template in Mist: {result["error"]}')
        else:
            messages.error(request, "There were errors in your form.")
        return self.render_to_response(self.get_context_data(form=form))

class CreateNetworkTemplateView(LoginRequiredMixin, TemplateView):
    template_name = 'nautobot_juniper_mist/create_network_template.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        if 'form' not in context:
            context['form'] = NetworkTemplateForm()
        return context

    def post(self, request, *args, **kwargs):
        form = NetworkTemplateForm(request.POST)
        if form.is_valid():
            cd = form.cleaned_data
            template_data = {
                'name': cd['name'],
                'description': cd['description'],
                'organization_id': cd['organization'].id,
                'template_type': 'network',
                'config': {
                    'mgmt_vlan': cd['mgmt_vlan'],
                    'additional_vlans': cd['additional_vlans'],  # already parsed in the form's save if you like
                    # You can add handling to parse raw field to dict/list here if needed
                },
            }
            manager = TemplateManager()
            result = manager.create_template(template_data)
            if result['success']:
                messages.success(request, f'Network Template "{template_data["name"]}" created successfully in Mist!')
                return redirect('plugins:nautobot_juniper_mist:template_list')
            else:
                messages.error(request, f'Failed to create template in Mist: {result["error"]}')
        else:
            messages.error(request, "There were errors in your form.")
        return self.render_to_response(self.get_context_data(form=form))


class CreateGatewayTemplateView(LoginRequiredMixin, TemplateView):
    """
    View for creating Gateway templates
    """
    template_name = 'nautobot_juniper_mist/create_gateway_template.html'
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['organizations'] = MistOrganization.objects.all()
        return context
    
    def post(self, request, *args, **kwargs):
        # Handle Gateway template creation
        try:
            from .template_manager import TemplateManager
            manager = TemplateManager()
            
            template_data = {
                'name': request.POST.get('name'),
                'description': request.POST.get('description'),
                'organization_id': request.POST.get('organization'),
                'template_type': 'gateway',
                'config': {
                    'wan_config': {
                        'type': request.POST.get('wan_type', 'dhcp'),
                        'ip': request.POST.get('wan_ip', ''),
                        'netmask': request.POST.get('wan_netmask', ''),
                        'gateway': request.POST.get('wan_gateway', '')
                    },
                    'firewall': {
                        'enabled': request.POST.get('firewall_enabled') == 'on',
                        'policies': []
                    }
                }
            }
            
            result = manager.create_template(template_data)
            
            if result['success']:
                messages.success(request, f'Gateway Template "{template_data["name"]}" created successfully!')
                return redirect('plugins:nautobot_juniper_mist:template_list')
            else:
                messages.error(request, f'Failed to create template: {result["error"]}')
                
        except Exception as e:
            messages.error(request, f'Error creating template: {str(e)}')
        
        return self.get(request, *args, **kwargs)


class SyncTemplatesView(LoginRequiredMixin, TemplateView):
    def post(self, request, *args, **kwargs):
        import logging
        import threading
        import time
        
        logger = logging.getLogger(__name__)
        
        try:
            logger.info("Starting template sync...")
            
            from .template_manager import TemplateManager
            manager = TemplateManager()
            
            # Use threading instead of signal for timeout
            result = {'success': False, 'error': 'Timeout'}
            
            def sync_worker():
                try:
                    result.update(manager.sync_templates_from_mist())
                except Exception as e:
                    result.update({'success': False, 'error': str(e)})
            
            # Start sync in a separate thread with timeout
            sync_thread = threading.Thread(target=sync_worker)
            sync_thread.daemon = True
            sync_thread.start()
            sync_thread.join(timeout=60)  # 60 second timeout
            
            if sync_thread.is_alive():
                messages.error(request, 'Sync operation timed out after 60 seconds. Check sync jobs page for status.')
            elif result['success']:
                messages.success(request, f'Successfully synced {result["synced"]} templates!')
            else:
                messages.error(request, f'Sync failed: {result["error"]}')
                
        except Exception as e:
            logger.error(f"Sync exception: {str(e)}")
            messages.error(request, f'Error syncing templates: {str(e)}')
        
        return redirect('plugins:nautobot_juniper_mist:template_list')


class TemplateDetailView(LoginRequiredMixin, DetailView):
    """
    Detail view for templates
    """
    model = MistTemplate
    template_name = 'nautobot_juniper_mist/template_detail.html'
    context_object_name = 'template'


class TemplateEditView(LoginRequiredMixin, UpdateView):
    """
    Edit view for templates
    """
    model = MistTemplate
    template_name = 'nautobot_juniper_mist/template_edit.html'
    fields = ['name', 'description', 'config']
    success_url = reverse_lazy('plugins:nautobot_juniper_mist:template_list')
    
    def form_valid(self, form):
        messages.success(self.request, f'Template "{form.instance.name}" updated successfully!')
        return super().form_valid(form)


class TemplateDeleteView(LoginRequiredMixin, DeleteView):
    """
    Delete view for templates
    """
    model = MistTemplate
    template_name = 'nautobot_juniper_mist/template_delete.html'
    success_url = reverse_lazy('plugins:nautobot_juniper_mist:template_list')
    
    def delete(self, request, *args, **kwargs):
        template = self.get_object()
        messages.success(request, f'Template "{template.name}" deleted successfully!')
        return super().delete(request, *args, **kwargs)
    

def debug_onboarding(request):
    """Debug view to check onboarding requests"""
    from .models import SiteOnboardingRequest
    
    all_requests = SiteOnboardingRequest.objects.all()
    
    result = {
        'total_requests': len(all_requests),
        'requests': []
    }
    
    for req in all_requests:
        result['requests'].append({
            'id': str(req.id),
            'site_name': req.site_name,
            'status': req.status,
            'requested_at': req.requested_at.isoformat(),
            'processed_at': req.processed_at.isoformat() if req.processed_at else None,
            'error_message': req.error_message,
        })
    
    return JsonResponse(result, indent=2)