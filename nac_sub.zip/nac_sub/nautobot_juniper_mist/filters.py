"""
Django filters for Mist plugin
"""

import django_filters
from nautobot.apps.filters import NautobotFilterSet
from .models import MistOrganization, MistSite, MistDevice, MistTemplate


class MistOrganizationFilterSet(NautobotFilterSet):
    """
    Filter set for MistOrganization
    """
    name = django_filters.CharFilter(
        field_name='name',
        lookup_expr='icontains',
        label='Name'
    )
    
    class Meta:
        model = MistOrganization
        fields = ['name', 'mist_id']


class MistSiteFilterSet(NautobotFilterSet):
    """
    Filter set for MistSite
    """
    name = django_filters.CharFilter(
        field_name='name',
        lookup_expr='icontains',
        label='Name'
    )
    organization = django_filters.ModelChoiceFilter(
        queryset=MistOrganization.objects.all(),
        label='Organization'
    )
    country_code = django_filters.CharFilter(
        field_name='country_code',
        lookup_expr='iexact',
        label='Country Code'
    )
    
    class Meta:
        model = MistSite
        fields = ['name', 'organization', 'country_code', 'timezone']


class MistDeviceFilterSet(NautobotFilterSet):
    """
    Filter set for MistDevice
    """
    name = django_filters.CharFilter(
        field_name='name',
        lookup_expr='icontains',
        label='Name'
    )
    site = django_filters.ModelChoiceFilter(
        queryset=MistSite.objects.all(),
        label='Site'
    )
    device_type = django_filters.ChoiceFilter(
        choices=MistDevice.DEVICE_TYPE_CHOICES,
        label='Device Type'
    )
    connected = django_filters.BooleanFilter(
        label='Connected'
    )
    
    class Meta:
        model = MistDevice
        fields = ['name', 'site', 'device_type', 'connected', 'model']


class MistTemplateFilterSet(NautobotFilterSet):
    """
    Filter set for MistTemplate
    """
    name = django_filters.CharFilter(
        field_name='name',
        lookup_expr='icontains',
        label='Name'
    )
    organization = django_filters.ModelChoiceFilter(
        queryset=MistOrganization.objects.all(),
        label='Organization'
    )
    template_type = django_filters.ChoiceFilter(
        choices=MistTemplate.TEMPLATE_TYPE_CHOICES,
        label='Template Type'
    )
    
    class Meta:
        model = MistTemplate
        fields = ['name', 'organization', 'template_type']