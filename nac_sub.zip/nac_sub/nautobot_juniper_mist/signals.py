"""
Signal handlers for Mist plugin
"""

from django.db.models.signals import post_save, post_delete
from django.dispatch import receiver
from nautobot.dcim.models import Site, Device
from .models import MistSite, MistDevice


@receiver(post_save, sender=Site)
def sync_site_to_mist(sender, instance, created, **kwargs):
    """
    Sync site changes back to Mist if needed
    """
    # This could be extended to push changes back to Mist
    pass


@receiver(post_delete, sender=Site)
def handle_site_deletion(sender, instance, **kwargs):
    """
    Handle when a Nautobot site is deleted
    """
    try:
        mist_site = MistSite.objects.get(nautobot_site=instance)
        mist_site.nautobot_site = None
        mist_site.save()
    except MistSite.DoesNotExist:
        pass
