# nautobot_juniper_mist/sync.py - Fixed version

import logging
from datetime import datetime
from django.utils import timezone
from django.conf import settings

# Fixed imports for Nautobot 2.x
try:
    from nautobot.dcim.models import Location, LocationType, Device, DeviceType, Manufacturer
    Site = Location  # In Nautobot 2.x, Site is now Location
except ImportError:
    # Fallback for older versions
    from nautobot.dcim.models import Site, Device, DeviceType, Manufacturer
    LocationType = None

from nautobot.extras.models import Status, Role
from .models import MistOrganization, MistSite, MistDevice, MistSyncJob
from .api_client import MistAPIClient

logger = logging.getLogger(__name__)


class MistNautobotSync:
    """
    Handles synchronization between Mist and Nautobot
    """
    
    def __init__(self):
        self.api_client = MistAPIClient()
        self.plugin_config = getattr(settings, 'PLUGINS_CONFIG', {}).get(
            'nautobot_juniper_mist', {}
        )
        
        # Get or create default objects
        self.manufacturer, _ = Manufacturer.objects.get_or_create(
            name=self.plugin_config.get('default_manufacturer', 'Juniper')
        )
        
        # Get or create Active status
        self.active_status, _ = Status.objects.get_or_create(
            name='Active',
            defaults={'color': '4caf50'}
        )
        
        # Get or create default device role
        role_name = self.plugin_config.get('default_device_role', 'access-point')
        self.device_role, _ = Role.objects.get_or_create(
            name=role_name,
            defaults={
                'color': '2196f3',
            }
        )
        
        # Get or create default location type (for Nautobot 2.x)
        self.location_type = None
        if LocationType:
            self.location_type, _ = LocationType.objects.get_or_create(
                name='Site',
                defaults={
                    'description': 'Site location type for Mist sync',
                    'nestable': True,
                }
            )
        
    def sync_all(self) -> MistSyncJob:
        """
        Synchronize all organizations, sites, and devices
        """
        sync_job = MistSyncJob.objects.create(
            job_type="full_sync",
            status="running"
        )
        
        try:
            logger.info("Starting full Mist synchronization")
            
            # Connect to Mist API
            if not self.api_client.connect():
                raise Exception("Failed to connect to Mist API")
            
            # Get the configured organization
            org_id = self.plugin_config.get('MIST_ORG_ID')
            if org_id:
                # Get specific organization
                org_data = self.api_client.get_organization(org_id)
                if org_data:
                    org = self._sync_organization(org_data)
                    # Process this single organization
                    sites = self.api_client.get_sites(org_data['id'])
                    logger.info(f"Found {len(sites)} sites in org {org.name}")
                    
                    for site_data in sites:
                        try:
                            site = self._sync_site(org, site_data)
                            sync_job.sites_synced += 1
                            
                            # Sync devices for this site
                            devices = self.api_client.get_site_devices(site.mist_id)
                            logger.info(f"Found {len(devices)} devices in site {site.name}")
                            
                            for device_data in devices:
                                try:
                                    self._sync_device(site, device_data)
                                    sync_job.devices_synced += 1
                                except Exception as e:
                                    logger.error(f"Failed to sync device {device_data.get('id', 'unknown')}: {str(e)}")
                                    continue
                                    
                        except Exception as e:
                            logger.error(f"Failed to sync site {site_data.get('id', 'unknown')}: {str(e)}")
                            continue
                else:
                    raise Exception(f"Could not fetch organization {org_id}")
            else:
                # Get all organizations
                orgs_data = self.api_client.get_organizations()
                if not orgs_data:
                    raise Exception("No organizations found or accessible")
                
                # Process each organization
                for org_data in orgs_data:
                    org = self._sync_organization(org_data)
                    
                    # Get sites for this organization
                    sites = self.api_client.get_sites(org_data['id'])
                    logger.info(f"Found {len(sites)} sites in org {org.name}")
                
                    for site_data in sites:
                        try:
                            site = self._sync_site(org, site_data)
                            sync_job.sites_synced += 1
                            
                            # Sync devices for this site
                            devices = self.api_client.get_site_devices(site.mist_id)
                            logger.info(f"Found {len(devices)} devices in site {site.name}")
                            
                            for device_data in devices:
                                try:
                                    self._sync_device(site, device_data)
                                    sync_job.devices_synced += 1
                                except Exception as e:
                                    logger.error(f"Failed to sync device {device_data.get('id', 'unknown')}: {str(e)}")
                                    continue
                                    
                        except Exception as e:
                            logger.error(f"Failed to sync site {site_data.get('id', 'unknown')}: {str(e)}")
                            continue
            
            sync_job.status = "completed"
            sync_job.completed_at = timezone.now()
            logger.info("Full synchronization completed successfully")
            
        except Exception as e:
            logger.error(f"Sync failed: {str(e)}")
            sync_job.status = "failed" 
            sync_job.error_message = str(e)
            sync_job.completed_at = timezone.now()
        
        sync_job.save()
        return sync_job
    
    def _sync_organization(self, org_data: dict) -> MistOrganization:
        """
        Sync a single organization
        """
        org, created = MistOrganization.objects.update_or_create(
            mist_id=org_data['id'],
            defaults={
                'name': org_data['name'],
            }
        )
        
        if created:
            logger.info(f"Created new organization: {org.name}")
        else:
            logger.info(f"Updated organization: {org.name}")
        
        return org
    
    def _sync_site(self, org: MistOrganization, site_data: dict) -> MistSite:
        """
        Sync a single site
        """
        # Get or create Nautobot site/location
        nautobot_site = None
        if self.plugin_config.get('auto_create_sites', True):
            site_defaults = {
                'status': self.active_status,
                'description': f"Synced from Mist - {site_data.get('address', '')}",
            }
            
            # Add location_type for Nautobot 2.x
            if self.location_type:
                site_defaults['location_type'] = self.location_type
                
            nautobot_site, site_created = Site.objects.get_or_create(
                name=site_data['name'],
                defaults=site_defaults
            )
            
            if site_created:
                logger.info(f"Created new Nautobot site: {nautobot_site.name}")
        
        # Update or create Mist site
        mist_site, created = MistSite.objects.update_or_create(
            mist_id=site_data['id'],
            defaults={
                'organization': org,
                'nautobot_site': nautobot_site,
                'name': site_data['name'],
                'address': site_data.get('address', ''),
                'country_code': site_data.get('country_code', ''),
                'timezone': site_data.get('timezone', ''),
                'latitude': site_data.get('latlng', {}).get('lat') if site_data.get('latlng') else None,
                'longitude': site_data.get('latlng', {}).get('lng') if site_data.get('latlng') else None,
                'rf_template_id': site_data.get('rftemplate_id'),
                'ap_template_id': site_data.get('aptemplate_id'),
                'network_template_id': site_data.get('networktemplate_id'),
                'gateway_template_id': site_data.get('gatewaytemplate_id'),
                'site_template_id': site_data.get('sitetemplate_id'),
                'last_sync': timezone.now(),
            }
        )
        
        if created:
            logger.info(f"Created new Mist site: {mist_site.name}")
        else:
            logger.info(f"Updated Mist site: {mist_site.name}")
        
        return mist_site
    
    def _sync_device(self, site: MistSite, device_data: dict) -> MistDevice:
        """
        Sync a single device
        """
        nautobot_device = None
        
        # Get or create device type
        if self.plugin_config.get('auto_create_devices', True):
            model_name = device_data.get('model', f"Unknown {device_data.get('type', 'Device')}")
            device_type, _ = DeviceType.objects.get_or_create(
                model=model_name,
                manufacturer=self.manufacturer,
                defaults={
                    'u_height': 1,
                }
            )
            
            # Create Nautobot device
            device_name = device_data.get('name', f"Device-{device_data['id'][:8]}")
            nautobot_device, device_created = Device.objects.get_or_create(
                name=device_name,
                defaults={
                    'device_type': device_type,
                    'role': self.device_role,
                    'location': site.nautobot_site,  # Use location instead of site for Nautobot 2.x
                    'status': self.active_status,
                    'serial': device_data.get('serial', ''),
                }
            )
            
            if device_created:
                logger.info(f"Created new Nautobot device: {nautobot_device.name}")
        
        # Update or create Mist device
        mist_device, created = MistDevice.objects.update_or_create(
            mist_id=device_data['id'],
            defaults={
                'site': site,
                'nautobot_device': nautobot_device,
                'name': device_data.get('name', f"Device-{device_data['id'][:8]}"),
                'mac_address': device_data.get('mac', ''),
                'device_type': device_data.get('type', 'unknown'),
                'model': device_data.get('model', ''),
                'serial_number': device_data.get('serial', ''),
                'connected': device_data.get('status') == 'connected',
                'uptime': device_data.get('uptime'),
                'version': device_data.get('version', ''),
                'x': device_data.get('x'),
                'y': device_data.get('y'),
                'last_sync': timezone.now(),
            }
        )
        
        if created:
            logger.info(f"Created new Mist device: {mist_device.name}")
        else:
            logger.info(f"Updated Mist device: {mist_device.name}")
        
        return mist_device