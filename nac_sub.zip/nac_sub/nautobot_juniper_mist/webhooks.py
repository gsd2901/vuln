"""
Webhook handlers for Mist events
"""

import json
import logging
from django.http import HttpResponse, HttpResponseBadRequest
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_http_methods
from django.utils.decorators import method_decorator
from django.views import View
from .models import MistSite, MistDevice
from .sync import MistNautobotSync


logger = logging.getLogger(__name__)


@method_decorator(csrf_exempt, name='dispatch')
class MistWebhookView(View):
    """
    Handle incoming webhooks from Mist
    """
    
    def post(self, request):
        try:
            payload = json.loads(request.body)
            event_type = payload.get('type')
            
            logger.info(f"Received Mist webhook: {event_type}")
            
            if event_type == 'device-events':
                self._handle_device_event(payload)
            elif event_type == 'site-events':
                self._handle_site_event(payload)
            elif event_type == 'audit':
                self._handle_audit_event(payload)
            else:
                logger.warning(f"Unknown webhook event type: {event_type}")
            
            return HttpResponse('OK')
            
        except json.JSONDecodeError:
            logger.error("Invalid JSON in webhook payload")
            return HttpResponseBadRequest('Invalid JSON')
        except Exception as e:
            logger.error(f"Error processing webhook: {str(e)}")
            return HttpResponseBadRequest(str(e))
    
    def _handle_device_event(self, payload):
        """
        Handle device-related events
        """
        events = payload.get('events', [])
        
        for event in events:
            device_mac = event.get('ap')  # or 'switch', 'gateway'
            event_type = event.get('type')
            
            if not device_mac:
                continue
            
            try:
                device = MistDevice.objects.get(mac_address=device_mac)
                
                if event_type in ['AP_CONNECTED', 'AP_DISCONNECTED']:
                    device.connected = event_type == 'AP_CONNECTED'
                    device.save()
                    logger.info(f"Updated device {device.name} connection status: {device.connected}")
                
                elif event_type == 'AP_CONFIG_CHANGED':
                    # Trigger a device sync
                    sync = MistNautobotSync()
                    site_devices = sync.api_client.get_site_devices(device.site.mist_id)
                    for device_data in site_devices:
                        if device_data.get('mac') == device_mac:
                            sync._sync_device(device.site, device_data)
                            break
                
            except MistDevice.DoesNotExist:
                logger.warning(f"Device with MAC {device_mac} not found in Nautobot")
    
    def _handle_site_event(self, payload):
        """
        Handle site-related events
        """
        events = payload.get('events', [])
        
        for event in events:
            site_id = event.get('site_id')
            event_type = event.get('type')
            
            if not site_id:
                continue
            
            try:
                site = MistSite.objects.get(mist_id=site_id)
                
                if event_type == 'SITE_CONFIG_CHANGED':
                    # Trigger a site sync
                    sync = MistNautobotSync()
                    org_sites = sync.api_client.get_sites(site.organization.mist_id)
                    for site_data in org_sites:
                        if site_data['id'] == site_id:
                            sync._sync_site(site.organization, site_data)
                            break
                
            except MistSite.DoesNotExist:
                logger.warning(f"Site with ID {site_id} not found in Nautobot")
    
    def _handle_audit_event(self, payload):
        """
        Handle audit events (config changes, etc.)
        """
        # Log audit events for compliance/tracking
        admin_name = payload.get('admin_name')
        message = payload.get('message')
        site_id = payload.get('site_id')
        org_id = payload.get('org_id')
        
        logger.info(f"Mist audit event - Admin: {admin_name}, Message: {message}, "
                   f"Site: {site_id}, Org: {org_id}")
