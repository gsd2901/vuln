# nautobot_juniper_mist/api_client.py

import logging
import requests
import time
from typing import Dict, List, Optional
from django.conf import settings

logger = logging.getLogger(__name__)


class MistAPIClient:
    """
    Client for interacting with the Juniper Mist API
    """
    
    def __init__(self):
        # Get plugin configuration
        self.plugin_config = getattr(settings, 'PLUGINS_CONFIG', {}).get(
            'nautobot_juniper_mist', {}
        )
        
        # API Configuration
        self.base_url = self.plugin_config.get('mist_host', 'https://api.ac2.mist.com')
        self.api_token = self.plugin_config.get('mist_api_token')
        self.org_id = self.plugin_config.get('MIST_ORG_ID')
        
        # Remove trailing slash from base_url
        self.base_url = self.base_url.rstrip('/')
        
        # Request configuration
        self.session = requests.Session()
        self.session.headers.update({
            'Authorization': f'Token {self.api_token}',
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        })
        
        # Rate limiting
        self.rate_limit_delay = 0.1  # 100ms between requests
        self.last_request_time = 0
        
        logger.info(f"Initialized Mist API Client - Base URL: {self.base_url}")
        if self.plugin_config.get('debug_api_calls', False):
            logger.debug(f"Using API Token: {self.api_token[:20]}...")
    
    def _make_request(self, method: str, endpoint: str, **kwargs) -> Optional[Dict]:
        """
        Make an HTTP request to the Mist API with error handling and rate limiting
        """
        # Rate limiting
        current_time = time.time()
        time_since_last = current_time - self.last_request_time
        if time_since_last < self.rate_limit_delay:
            time.sleep(self.rate_limit_delay - time_since_last)
        
        url = f"{self.base_url}{endpoint}"
        
        try:
            if self.plugin_config.get('debug_api_calls', False):
                logger.debug(f"Making {method} request to: {url}")
            
            response = self.session.request(method, url, **kwargs)
            self.last_request_time = time.time()
            
            if response.status_code == 401:
                logger.error("Failed to authenticate with Mist API: 401")
                logger.error(f"Using URL: {url}")
                logger.error(f"Using token: {self.api_token[:20]}...")
                return None
                
            elif response.status_code == 429:
                logger.warning("Rate limited by Mist API, waiting 60 seconds")
                time.sleep(60)
                return self._make_request(method, endpoint, **kwargs)
                
            elif not response.ok:
                logger.error(f"API request failed: {response.status_code} - {response.text}")
                return None
            
            return response.json()
            
        except requests.exceptions.RequestException as e:
            logger.error(f"Request failed: {str(e)}")
            return None
    
    def connect(self) -> bool:
        """
        Test connection to Mist API
        """
        if not self.api_token:
            logger.error("No API token configured")
            return False
            
        logger.info("Testing connection to Mist API...")
        
        # Test with /api/v1/self endpoint
        result = self._make_request('GET', '/api/v1/self')
        
        if result:
            logger.info(f"Successfully connected to Mist API as: {result.get('email', 'Unknown')}")
            return True
        else:
            logger.error("Failed to connect to Mist API")
            return False
    
    def get_organizations(self) -> List[Dict]:
        """
        Get list of organizations the user has access to
        """
        logger.info("Fetching organizations...")
        
        result = self._make_request('GET', '/api/v1/orgs')
        
        if result:
            logger.info(f"Found {len(result)} organizations")
            return result
        else:
            logger.error("Failed to fetch organizations")
            return []
    
    def get_organization(self, org_id: str = None) -> Optional[Dict]:
        """
        Get specific organization details
        """
        if not org_id:
            org_id = self.org_id
            
        if not org_id:
            logger.error("No organization ID provided")
            return None
            
        logger.info(f"Fetching organization: {org_id}")
        
        result = self._make_request('GET', f'/api/v1/orgs/{org_id}')
        
        if result:
            logger.info(f"Found organization: {result.get('name', 'Unknown')}")
            return result
        else:
            logger.error(f"Failed to fetch organization: {org_id}")
            return None
    
    def get_sites(self, org_id: str = None) -> List[Dict]:
        """
        Get list of sites for an organization
        """
        if not org_id:
            org_id = self.org_id
            
        if not org_id:
            logger.error("No organization ID provided")
            return []
            
        logger.info(f"Fetching sites for organization: {org_id}")
        
        result = self._make_request('GET', f'/api/v1/orgs/{org_id}/sites')
        
        if result:
            logger.info(f"Found {len(result)} sites")
            return result
        else:
            logger.error("Failed to fetch sites")
            return []
    
    def get_site(self, site_id: str) -> Optional[Dict]:
        """
        Get specific site details
        """
        org_id = self.org_id
        if not org_id:
            logger.error("No organization ID configured")
            return None
            
        logger.info(f"Fetching site: {site_id}")
        
        result = self._make_request('GET', f'/api/v1/orgs/{org_id}/sites/{site_id}')
        
        if result:
            logger.info(f"Found site: {result.get('name', 'Unknown')}")
            return result
        else:
            logger.error(f"Failed to fetch site: {site_id}")
            return None
    
    def get_site_devices(self, site_id: str) -> List[Dict]:
        """
        Get list of devices for a site
        """
        logger.info(f"Fetching devices for site: {site_id}")
        
        # Get devices from site inventory
        result = self._make_request('GET', f'/api/v1/sites/{site_id}/devices')
        
        if result:
            logger.info(f"Found {len(result)} devices")
            return result
        else:
            logger.error(f"Failed to fetch devices for site: {site_id}")
            return []
    
    def get_device(self, device_id: str) -> Optional[Dict]:
        """
        Get specific device details
        """
        logger.info(f"Fetching device: {device_id}")
        
        result = self._make_request('GET', f'/api/v1/sites/{device_id}/devices')
        
        if result:
            logger.info(f"Found device: {result.get('name', 'Unknown')}")
            return result
        else:
            logger.error(f"Failed to fetch device: {device_id}")
            return None
    
    def get_device_stats(self, site_id: str, device_id: str) -> Optional[Dict]:
        """
        Get device statistics
        """
        logger.info(f"Fetching stats for device: {device_id}")
        
        result = self._make_request('GET', f'/api/v1/sites/{site_id}/stats/devices/{device_id}')
        
        if result:
            return result
        else:
            logger.error(f"Failed to fetch stats for device: {device_id}")
            return None
    
    def get_inventory(self, org_id: str = None) -> List[Dict]:
        """
        Get organization inventory
        """
        if not org_id:
            org_id = self.org_id
            
        if not org_id:
            logger.error("No organization ID provided")
            return []
            
        logger.info(f"Fetching inventory for organization: {org_id}")
        
        result = self._make_request('GET', f'/api/v1/orgs/{org_id}/inventory')
        
        if result:
            logger.info(f"Found {len(result)} inventory items")
            return result
        else:
            logger.error("Failed to fetch inventory")
            return []
    
    def create_site(self, org_id: str, site_data: Dict) -> Optional[Dict]:
        """
        Create a new site in Mist
        """
        logger.info(f"Creating site in organization: {org_id}")
        logger.info(f"Site data: {site_data}")
        
        result = self._make_request('POST', f'/api/v1/orgs/{org_id}/sites', json=site_data)
        
        if result:
            logger.info(f"Successfully created site: {result.get('name', 'Unknown')}")
            return result
        else:
            logger.error("Failed to create site")
            return None
    
    def update_site(self, site_id: str, site_data: Dict) -> Optional[Dict]:
        """
        Update an existing site in Mist
        """
        logger.info(f"Updating site: {site_id}")
        
        result = self._make_request('PUT', f'/api/v1/sites/{site_id}', json=site_data)
        
        if result:
            logger.info(f"Successfully updated site: {result.get('name', 'Unknown')}")
            return result
        else:
            logger.error(f"Failed to update site: {site_id}")
            return None
    
    def delete_site(self, site_id: str) -> bool:
        """
        Delete a site in Mist
        """
        logger.info(f"Deleting site: {site_id}")
        
        result = self._make_request('DELETE', f'/api/v1/sites/{site_id}')
        
        if result is not None:  # DELETE might return empty response
            logger.info(f"Successfully deleted site: {site_id}")
            return True
        else:
            logger.error(f"Failed to delete site: {site_id}")
            return False
    
    # Template API methods
    def get_rf_templates(self, org_id: str) -> List[Dict]:
        """
        Get RF templates for an organization
        """
        logger.info(f"Fetching RF templates for organization: {org_id}")
        
        result = self._make_request('GET', f'/api/v1/orgs/{org_id}/rftemplates')
        
        if result:
            logger.info(f"Found {len(result)} RF templates")
            return result
        else:
            logger.error("Failed to fetch RF templates")
            return []
    
    def get_network_templates(self, org_id: str) -> List[Dict]:
        """
        Get Network templates for an organization
        """
        logger.info(f"Fetching Network templates for organization: {org_id}")
        
        result = self._make_request('GET', f'/api/v1/orgs/{org_id}/networktemplates')
        
        if result:
            logger.info(f"Found {len(result)} Network templates")
            return result
        else:
            logger.error("Failed to fetch Network templates")
            return []
    
    def get_gateway_templates(self, org_id: str) -> List[Dict]:
        """
        Get Gateway templates for an organization
        """
        logger.info(f"Fetching Gateway templates for organization: {org_id}")
        
        result = self._make_request('GET', f'/api/v1/orgs/{org_id}/gatewaytemplates')
        
        if result:
            logger.info(f"Found {len(result)} Gateway templates")
            return result
        else:
            logger.error("Failed to fetch Gateway templates")
            return []
    
    def create_rf_template(self, org_id: str, template_data: Dict) -> Optional[Dict]:
        """
        Create RF template
        """
        logger.info(f"Creating RF template in organization: {org_id}")
        
        result = self._make_request('POST', f'/api/v1/orgs/{org_id}/rftemplates', json=template_data)
        
        if result:
            logger.info(f"Successfully created RF template: {result.get('name', 'Unknown')}")
            return result
        else:
            logger.error("Failed to create RF template")
            return None
    
    def create_network_template(self, org_id: str, template_data: Dict) -> Optional[Dict]:
        """
        Create Network template
        """
        logger.info(f"Creating Network template in organization: {org_id}")
        
        result = self._make_request('POST', f'/api/v1/orgs/{org_id}/networktemplates', json=template_data)
        
        if result:
            logger.info(f"Successfully created Network template: {result.get('name', 'Unknown')}")
            return result
        else:
            logger.error("Failed to create Network template")
            return None
    
    def create_gateway_template(self, org_id: str, template_data: Dict) -> Optional[Dict]:
        """
        Create Gateway template
        """
        logger.info(f"Creating Gateway template in organization: {org_id}")
        
        result = self._make_request('POST', f'/api/v1/orgs/{org_id}/gatewaytemplates', json=template_data)
        
        if result:
            logger.info(f"Successfully created Gateway template: {result.get('name', 'Unknown')}")
            return result
        else:
            logger.error("Failed to create Gateway template")
            return None