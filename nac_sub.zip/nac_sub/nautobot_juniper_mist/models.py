"""
Nautobot Juniper Mist Models
"""

from django.db import models
from django.core.validators import RegexValidator
import uuid
from nautobot.core.models.generics import BaseModel
# Corrected imports for Nautobot 2.0+
try:
    # Try new import structure (Nautobot 2.0+)
    from nautobot.dcim.models.locations import Location as Site
    from nautobot.dcim.models.devices import Device, DeviceType, Manufacturer
except ImportError:
    try:
        # Fallback for older versions
        from nautobot.dcim.models import Site, Device, DeviceType, Manufacturer
    except ImportError:
        # Alternative import structure
        from nautobot.dcim.models import Location as Site, Device, DeviceType, Manufacturer

from nautobot.ipam.models import IPAddress


class MistOrganization(BaseModel):
    """
    Represents a Mist Organization
    """
    mist_id = models.CharField(
        max_length=36,
        unique=True,
        validators=[RegexValidator(
            regex=r'^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$',
            message='Must be a valid UUID'
        )],
        help_text="Mist Organization UUID"
    )
    name = models.CharField(max_length=255)
    
    class Meta:
        verbose_name = "Mist Organization"
        verbose_name_plural = "Mist Organizations"

    def __str__(self):
        return self.name


class MistSite(BaseModel):
    """
    Represents a Mist Site with link to Nautobot Site/Location
    """
    mist_id = models.CharField(
        max_length=36,
        unique=True,
        validators=[RegexValidator(
            regex=r'^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$',
            message='Must be a valid UUID'
        )],
        help_text="Mist Site UUID"
    )
    organization = models.ForeignKey(
        MistOrganization,
        on_delete=models.CASCADE,
        related_name="sites"
    )
    nautobot_site = models.OneToOneField(
        Site,
        on_delete=models.CASCADE,
        related_name="mist_site",
        null=True,
        blank=True
    )
    name = models.CharField(max_length=255)
    address = models.TextField(blank=True)
    country_code = models.CharField(max_length=2, blank=True)
    timezone = models.CharField(max_length=50, blank=True)
    latitude = models.FloatField(null=True, blank=True)
    longitude = models.FloatField(null=True, blank=True)
    notes = models.TextField(blank=True)
    
    # Template associations
    rf_template_id = models.CharField(max_length=36, blank=True, null=True)
    ap_template_id = models.CharField(max_length=36, blank=True, null=True)
    network_template_id = models.CharField(max_length=36, blank=True, null=True)
    gateway_template_id = models.CharField(max_length=36, blank=True, null=True)
    site_template_id = models.CharField(max_length=36, blank=True, null=True)
    
    last_sync = models.DateTimeField(null=True, blank=True)

    class Meta:
        verbose_name = "Mist Site"
        verbose_name_plural = "Mist Sites"

    def __str__(self):
        return self.name


class MistDevice(BaseModel):
    """
    Represents a Mist Device with link to Nautobot Device
    """
    DEVICE_TYPE_CHOICES = [
        ('ap', 'Access Point'),
        ('switch', 'Switch'), 
        ('gateway', 'Gateway'),
        ('mxedge', 'MX Edge'),
    ]
    
    mist_id = models.CharField(
        max_length=36,
        unique=True,
        validators=[RegexValidator(
            regex=r'^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$',
            message='Must be a valid UUID'
        )],
        help_text="Mist Device UUID"
    )
    site = models.ForeignKey(
        MistSite,
        on_delete=models.CASCADE,
        related_name="devices"
    )
    nautobot_device = models.OneToOneField(
        Device,
        on_delete=models.CASCADE,
        related_name="mist_device",
        null=True,
        blank=True
    )
    name = models.CharField(max_length=255)
    mac_address = models.CharField(max_length=17)
    device_type = models.CharField(max_length=20, choices=DEVICE_TYPE_CHOICES)
    model = models.CharField(max_length=100, blank=True)
    serial_number = models.CharField(max_length=100, blank=True)
    
    # Status information
    connected = models.BooleanField(default=False)
    uptime = models.IntegerField(null=True, blank=True, help_text="Uptime in seconds")
    version = models.CharField(max_length=50, blank=True)
    
    # Location on map
    x = models.FloatField(null=True, blank=True, help_text="X coordinate on floorplan")
    y = models.FloatField(null=True, blank=True, help_text="Y coordinate on floorplan")
    
    last_sync = models.DateTimeField(null=True, blank=True)

    class Meta:
        verbose_name = "Mist Device"
        verbose_name_plural = "Mist Devices"

    def __str__(self):
        return f"{self.name} ({self.device_type})"

class MistTemplate(BaseModel):
    """
    Mist template (RF, Network, Gateway, etc.)
    """
    TEMPLATE_TYPE_CHOICES = [
        ('rf', 'RF Template'),
        ('network', 'Network Template'), 
        ('gateway', 'Gateway Template'),
        ('ap', 'AP Template'),
        ('switch', 'Switch Template'),
    ]
    
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    mist_id = models.CharField(max_length=100, unique=True, null=True, blank=True)
    organization = models.ForeignKey('MistOrganization', on_delete=models.CASCADE)
    name = models.CharField(max_length=255)
    description = models.TextField(blank=True)
    template_type = models.CharField(max_length=20, choices=TEMPLATE_TYPE_CHOICES)
    config = models.JSONField(default=dict, blank=True)
    created_time = models.DateTimeField(null=True, blank=True)
    modified_time = models.DateTimeField(null=True, blank=True)  
    last_sync = models.DateTimeField(null=True, blank=True)
    
    class Meta:
        db_table = 'nautobot_juniper_mist_misttemplate'
        unique_together = [['organization', 'name', 'template_type']]
    
    def __str__(self):
        return f"{self.name} ({self.get_template_type_display()})"
    
    @property
    def display_name(self):
        """Human readable display name"""
        return f"{self.name} - {self.get_template_type_display()}"

class SiteOnboardingRequest(BaseModel):
    """
    Track site onboarding requests to Mist
    """
    STATUS_CHOICES = [
        ('pending', 'Pending'),
        ('processing', 'Processing'),
        ('completed', 'Completed'),
        ('failed', 'Failed'),
        ('cancelled', 'Cancelled'),
    ]
    
    nautobot_site = models.ForeignKey(
        Site,
        on_delete=models.CASCADE,
        related_name="mist_onboarding_requests"
    )
    target_organization = models.ForeignKey(
        MistOrganization,
        on_delete=models.CASCADE,
        related_name="onboarding_requests"
    )
    
    # Site configuration
    site_name = models.CharField(max_length=255)
    address = models.TextField(blank=True)
    country_code = models.CharField(max_length=2, blank=True)
    timezone = models.CharField(max_length=50, blank=True)
    latitude = models.FloatField(null=True, blank=True)
    longitude = models.FloatField(null=True, blank=True)
    notes = models.TextField(blank=True)
    
    # Template assignments
    rf_template = models.ForeignKey(
        MistTemplate,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="rf_onboarding_requests",
        limit_choices_to={'template_type': 'rf'}
    )
    network_template = models.ForeignKey(
        MistTemplate,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="network_onboarding_requests",
        limit_choices_to={'template_type': 'network'}
    )
    gateway_template = models.ForeignKey(
        MistTemplate,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="gateway_onboarding_requests",
        limit_choices_to={'template_type': 'gateway'}
    )
    
    # Request tracking
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='pending')
    requested_by = models.CharField(max_length=100, blank=True)
    requested_at = models.DateTimeField(auto_now_add=True)
    processed_at = models.DateTimeField(null=True, blank=True)
    error_message = models.TextField(blank=True)
    
    # Result
    created_mist_site = models.OneToOneField(
        MistSite,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="onboarding_request"
    )

    class Meta:
        verbose_name = "Site Onboarding Request"
        verbose_name_plural = "Site Onboarding Requests"
        ordering = ['-requested_at']

    def __str__(self):
        return f"Onboard {self.site_name} to {self.target_organization.name}"


class MistSyncJob(BaseModel):
    """
    Track synchronization jobs between Mist and Nautobot
    """
    STATUS_CHOICES = [
        ('pending', 'Pending'),
        ('running', 'Running'),
        ('completed', 'Completed'),
        ('failed', 'Failed'),
    ]
    
    job_type = models.CharField(max_length=50, help_text="Type of sync job")
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='pending')
    started_at = models.DateTimeField(auto_now_add=True)
    completed_at = models.DateTimeField(null=True, blank=True)
    error_message = models.TextField(blank=True)
    
    # Statistics
    sites_synced = models.IntegerField(default=0)
    devices_synced = models.IntegerField(default=0)
    sites_created = models.IntegerField(default=0)
    devices_created = models.IntegerField(default=0)

    class Meta:
        verbose_name = "Mist Sync Job"
        verbose_name_plural = "Mist Sync Jobs"
        ordering = ['-started_at']

    def __str__(self):
        return f"{self.job_type} - {self.status} ({self.started_at})"
    