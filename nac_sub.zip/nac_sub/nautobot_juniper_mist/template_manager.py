import logging
from datetime import datetime
from django.utils import timezone
from django.conf import settings
from typing import Dict, List, Optional

from .models import MistOrganization, MistTemplate
from .api_client import MistAPIClient

logger = logging.getLogger(__name__)


class TemplateManager:
    """
    Handles Mist template operations
    """
    
    def __init__(self):
        self.api_client = MistAPIClient()
        self.plugin_config = getattr(settings, 'PLUGINS_CONFIG', {}).get(
            'nautobot_juniper_mist', {}
        )
    
    def create_template(self, template_data: Dict) -> Dict:
        """
        Create a new template in Mist
        """
        try:
            # Get organization
            org = MistOrganization.objects.get(id=template_data['organization_id'])
            
            # Prepare Mist template data
            mist_data = {
                'name': template_data['name'],
                'description': template_data.get('description', ''),
            }
            
            # Add type-specific configuration
            template_type = template_data['template_type']
            if template_type == 'rf':
                mist_data.update(self._build_rf_config(template_data['config']))
            elif template_type == 'network':
                mist_data.update(self._build_network_config(template_data['config']))
            elif template_type == 'gateway':
                mist_data.update(self._build_gateway_config(template_data['config']))
            
            # Create template in Mist
            logger.info(f"Creating {template_type} template in Mist: {template_data['name']}")
            
            # Call appropriate API endpoint based on template type
            if template_type == 'rf':
                result = self.api_client.create_rf_template(org.mist_id, mist_data)
            elif template_type == 'network':
                result = self.api_client.create_network_template(org.mist_id, mist_data)
            elif template_type == 'gateway':
                result = self.api_client.create_gateway_template(org.mist_id, mist_data)
            else:
                raise ValueError(f"Unsupported template type: {template_type}")
            
            logger.debug(f'API response for create_template: {result}')

            if not result:
                raise Exception("Failed to create template in Mist - no data returned")
            
            # Create MistTemplate record
            template = MistTemplate.objects.create(
                mist_id=result['id'],
                organization=org,
                name=result['name'],
                description=result.get('description', ''),
                template_type=template_type,
                config=template_data['config'],
                created_time=timezone.now(),
                last_sync=timezone.now(),
            )
            
            logger.info(f"Successfully created template: {template.name}")
            
            return {
                'success': True,
                'template_id': template.id,
                'mist_template_id': template.mist_id
            }
            
        except Exception as e:
            logger.error(f"Error creating template: {str(e)}")
            return {
                'success': False,
                'error': str(e)
            }
    
    def sync_templates_from_mist(self) -> Dict:
        """
        Sync all templates from Mist organizations
        """
        synced_count = 0
        error_count = 0
        errors = []
        
        try:
            if not self.api_client.connect():
                raise Exception("Failed to connect to Mist API")
            
            # Get all organizations
            organizations = MistOrganization.objects.all()
            
            for org in organizations:
                logger.info(f"Syncing templates for organization: {org.name}")
                
                # Sync each template type
                for template_type in ['rf', 'network', 'gateway']:
                    try:
                        templates = self._fetch_templates_by_type(org.mist_id, template_type)
                        
                        for template_data in templates:
                            try:
                                template, created = MistTemplate.objects.update_or_create(
                                    mist_id=template_data['id'],
                                    defaults={
                                        'organization': org,
                                        'name': template_data['name'],
                                        'description': template_data.get('description', ''),
                                        'template_type': template_type,
                                        'config': self._extract_config(template_data, template_type),
                                        'created_time': self._parse_mist_time(template_data.get('created_time')),
                                        'modified_time': self._parse_mist_time(template_data.get('modified_time')),
                                        'last_sync': timezone.now(),
                                    }
                                )
                                
                                if created:
                                    logger.info(f"Created new template: {template.name}")
                                else:
                                    logger.info(f"Updated template: {template.name}")
                                
                                synced_count += 1
                                
                            except Exception as e:
                                error_count += 1
                                error_msg = f"Failed to sync template {template_data.get('name', 'unknown')}: {str(e)}"
                                logger.error(error_msg)
                                errors.append(error_msg)
                                
                    except Exception as e:
                        error_count += 1
                        error_msg = f"Failed to fetch {template_type} templates for {org.name}: {str(e)}"
                        logger.error(error_msg)
                        errors.append(error_msg)
            
            if synced_count > 0:
                return {
                    'success': True,
                    'synced': synced_count,
                    'errors': error_count,
                    'error_details': errors
                }
            else:
                return {
                    'success': False,
                    'error': f'No templates synced. Errors: {errors[:3]}'  # Show first 3 errors
                }
                
        except Exception as e:
            logger.error(f"Template sync failed: {str(e)}")
            return {
                'success': False,
                'error': str(e)
            }
    
    def _fetch_templates_by_type(self, org_id: str, template_type: str) -> List[Dict]:
        """
        Fetch templates of a specific type from Mist
        """
        if template_type == 'rf':
            return self.api_client.get_rf_templates(org_id)
        elif template_type == 'network':
            return self.api_client.get_network_templates(org_id)
        elif template_type == 'gateway':
            return self.api_client.get_gateway_templates(org_id)
        else:
            return []
    
    def _build_rf_config(self, config: Dict) -> Dict:
        """
        Build RF template configuration for Mist API
        """
        return {
            'band_24': config.get('band_24', {}),
            'band_5': config.get('band_5', {}),
            'band_6': config.get('band_6', {}),
        }
    
    def _build_network_config(self, config: Dict) -> Dict:
        """
        Build Network template configuration for Mist API
        """
        return {
            'vlans': config.get('vlans', []),
            'dns_servers': config.get('dns_servers', []),
            'ntp_servers': config.get('ntp_servers', []),
            'networks': config.get('networks', {}),
        }
    
    def _build_gateway_config(self, config: Dict) -> Dict:
        """
        Build Gateway template configuration for Mist API
        """
        return {
            'wan_config': config.get('wan_config', {}),
            'firewall': config.get('firewall', {}),
            'routing': config.get('routing', {}),
        }
    
    def _extract_config(self, template_data: Dict, template_type: str) -> Dict:
        """
        Extract relevant configuration from Mist template data
        """
        if template_type == 'rf':
            return {
                'band_24': template_data.get('band_24', {}),
                'band_5': template_data.get('band_5', {}),
                'band_6': template_data.get('band_6', {}),
            }
        elif template_type == 'network':
            return {
                'vlans': template_data.get('vlans', []),
                'dns_servers': template_data.get('dns_servers', []),
                'ntp_servers': template_data.get('ntp_servers', []),
                'networks': template_data.get('networks', {}),
            }
        elif template_type == 'gateway':
            return {
                'wan_config': template_data.get('wan_config', {}),
                'firewall': template_data.get('firewall', {}),
                'routing': template_data.get('routing', {}),
            }
        else:
            return {}
    
    def _parse_mist_time(self, timestamp) -> Optional[datetime]:
        """
        Parse Mist timestamp to datetime
        """
        if not timestamp:
            return None
            
        try:
            if isinstance(timestamp, (int, float)):
                return datetime.fromtimestamp(timestamp, tz=timezone.utc)
            else:
                return datetime.fromisoformat(str(timestamp))
        except (ValueError, TypeError):
            return None