# nautobot_juniper_mist/__init__.py
"""
Nautobot Juniper Mist Plugin Configuration
"""

from nautobot.apps import NautobotAppConfig


class NautobotJuniperMistConfig(NautobotAppConfig):
    name = "nautobot_juniper_mist"
    verbose_name = "Juniper Mist Integration"
    version = "1.0.0"
    author = "Avinash Sharma"
    description = "Nautobot plugin for Juniper Mist cloud integration"
    base_url = "juniper-mist"
    min_version = "2.0.0"
    max_version = "2.9999"
    required_settings = []
    default_settings = {
        "mist_host": "https://api.ac2.mist.com",
        "mist_api_token": "hevEzU8sV85rVm0mq4hohdfBo0SyGOPYpWYdlL3DQSkUkyaYnvc4QiScrLWSMYrQdcWFIihXltTbkQwjJwUslB8bpGjk6zfc",
        "sync_interval": 3600,
        "auto_create_sites": True,
        "auto_create_devices": True,
        "default_device_role": "access-point",
        "default_manufacturer": "Juniper",
        "MIST_ORG_ID":"c4df29da-5277-48c0-b294-16253723dafa"
    }

    def ready(self):
        super().ready()
        # Import signal handlers only if they exist
        try:
            from . import signals
        except ImportError:
            pass


config = NautobotJuniperMistConfig