"""
Celery tasks for background processing
"""

from celery import shared_task
from .sync import MistNautobotSync


@shared_task(bind=True)
def sync_mist_data(self):
    """
    Background task to sync Mist data
    """
    sync = MistNautobotSync()
    try:
        sync_job = sync.sync_all()
        return {
            'status': sync_job.status,
            'sites_synced': sync_job.sites_synced,
            'devices_synced': sync_job.devices_synced,
        }
    except Exception as e:
        return {
            'status': 'failed',
            'error': str(e)
        }