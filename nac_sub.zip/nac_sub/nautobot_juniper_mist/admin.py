# nautobot_juniper_mist/admin.py
"""
Django admin configuration for Mist models
"""

from django.contrib import admin
from .models import MistOrganization, MistSite, MistDevice, MistSyncJob, MistTemplate, SiteOnboardingRequest


@admin.register(MistOrganization)
class MistOrganizationAdmin(admin.ModelAdmin):
    list_display = ('name', 'mist_id')
    search_fields = ('name', 'mist_id')
    list_filter = ('name',)


@admin.register(MistSite)
class MistSiteAdmin(admin.ModelAdmin):
    list_display = ('name', 'organization', 'country_code', 'timezone', 'last_sync')
    list_filter = ('organization', 'country_code', 'timezone')
    search_fields = ('name', 'mist_id', 'address')
    readonly_fields = ('last_sync', 'mist_id')
    raw_id_fields = ('nautobot_site',)


@admin.register(MistDevice)
class MistDeviceAdmin(admin.ModelAdmin):
    list_display = ('name', 'device_type', 'site', 'connected', 'last_sync')
    list_filter = ('device_type', 'connected', 'site__organization')
    search_fields = ('name', 'mist_id', 'mac_address', 'serial_number')
    readonly_fields = ('last_sync', 'mist_id')
    raw_id_fields = ('nautobot_device',)


@admin.register(MistTemplate)
class MistTemplateAdmin(admin.ModelAdmin):
    list_display = ('name', 'template_type', 'organization', 'last_sync')
    list_filter = ('template_type', 'organization')
    search_fields = ('name', 'mist_id', 'description')
    readonly_fields = ('last_sync', 'mist_id', 'created_time', 'modified_time')


@admin.register(SiteOnboardingRequest)
class SiteOnboardingRequestAdmin(admin.ModelAdmin):
    list_display = ('site_name', 'target_organization', 'status', 'requested_by', 'requested_at')
    list_filter = ('status', 'target_organization')
    search_fields = ('site_name', 'requested_by')
    readonly_fields = ('requested_at', 'processed_at')
    
    def has_add_permission(self, request):
        return True  # Allow creation through admin
    
    def has_change_permission(self, request, obj=None):
        return True  # Allow editing


@admin.register(MistSyncJob)
class MistSyncJobAdmin(admin.ModelAdmin):
    list_display = ('job_type', 'status', 'started_at', 'completed_at', 'sites_synced', 'devices_synced')
    list_filter = ('status', 'job_type')
    readonly_fields = ('started_at', 'completed_at')
    
    def has_add_permission(self, request):
        return False  # Don't allow manual creation of sync jobs