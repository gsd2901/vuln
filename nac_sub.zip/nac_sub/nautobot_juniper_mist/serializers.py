"""
REST API serializers for Mist plugin
"""

from rest_framework import serializers
from nautobot.apps.api import NautobotModelSerializer
from .models import MistOrganization, MistSite, MistDevice, MistTemplate, SiteOnboardingRequest


class MistOrganizationSerializer(NautobotModelSerializer):
    """
    Serializer for MistOrganization
    """
    site_count = serializers.SerializerMethodField()
    
    class Meta:
        model = MistOrganization
        fields = '__all__'
    
    def get_site_count(self, obj):
        return obj.sites.count()


class MistSiteSerializer(NautobotModelSerializer):
    """
    Serializer for MistSite
    """
    organization_name = serializers.CharField(source='organization.name', read_only=True)
    nautobot_site_name = serializers.CharField(source='nautobot_site.name', read_only=True)
    device_count = serializers.SerializerMethodField()
    
    class Meta:
        model = MistSite
        fields = '__all__'
    
    def get_device_count(self, obj):
        return obj.devices.count()


class MistDeviceSerializer(NautobotModelSerializer):
    """
    Serializer for MistDevice
    """
    site_name = serializers.CharField(source='site.name', read_only=True)
    nautobot_device_name = serializers.CharField(source='nautobot_device.name', read_only=True)
    
    class Meta:
        model = MistDevice
        fields = '__all__'


class MistTemplateSerializer(NautobotModelSerializer):
    """
    Serializer for MistTemplate
    """
    organization_name = serializers.CharField(source='organization.name', read_only=True)
    
    class Meta:
        model = MistTemplate
        fields = '__all__'


class SiteOnboardingRequestSerializer(NautobotModelSerializer):
    """
    Serializer for SiteOnboardingRequest
    """
    nautobot_site_name = serializers.CharField(source='nautobot_site.name', read_only=True)
    organization_name = serializers.CharField(source='target_organization.name', read_only=True)
    
    class Meta:
        model = SiteOnboardingRequest
        fields = '__all__'
