import logging
from datetime import datetime
from django.utils import timezone
from .models import SiteOnboardingRequest, MistSite
from .api_client import MistAPIClient 


logger = logging.getLogger(__name__)


class SiteOnboardingManager:
    """
    Handles site onboarding to Mist
    """
    
    def __init__(self):
        self.api_client = MistAPIClient()
    
    def process_request(self, request: SiteOnboardingRequest) -> dict:
        """
        Process a site onboarding request
        """
        if request.status != 'pending':
            return {
                'success': False,
                'error': f'Request status is {request.status}, expected pending'
            }
        
        # Mark as processing
        request.status = 'processing'
        request.save()
        
        try:
            # Build site data for Mist API
            site_data = {
                'name': request.site_name,
                'address': request.address,
                'country_code': request.country_code,
                'timezone': request.timezone,
                'notes': request.notes,
            }
            
            # Add location data if provided
            if request.latitude is not None and request.longitude is not None:
                site_data['latlng'] = {
                    'lat': request.latitude,
                    'lng': request.longitude
                }
            
            # Add template assignments
            if request.rf_template:
                site_data['rftemplate_id'] = request.rf_template.mist_id
            if request.network_template:
                site_data['networktemplate_id'] = request.network_template.mist_id
            if request.gateway_template:
                site_data['gatewaytemplate_id'] = request.gateway_template.mist_id
            
            # Create site in Mist
            logger.info(f"Creating site in Mist: {request.site_name}")
            mist_site_data = self.api_client.create_site(
                request.target_organization.mist_id,
                site_data
            )
            
            if not mist_site_data:
                raise Exception("Failed to create site in Mist - no data returned")
            
            # Create MistSite record
            mist_site = MistSite.objects.create(
                mist_id=mist_site_data['id'],
                organization=request.target_organization,
                nautobot_site=request.nautobot_site,
                name=mist_site_data['name'],
                address=mist_site_data.get('address', ''),
                country_code=mist_site_data.get('country_code', ''),
                timezone=mist_site_data.get('timezone', ''),
                latitude=mist_site_data.get('latlng', {}).get('lat'),
                longitude=mist_site_data.get('latlng', {}).get('lng'),
                notes=mist_site_data.get('notes', ''),
                rf_template_id=mist_site_data.get('rftemplate_id'),
                network_template_id=mist_site_data.get('networktemplate_id'),
                gateway_template_id=mist_site_data.get('gatewaytemplate_id'),
                last_sync=timezone.now(),
            )
            
            # Update request status
            request.status = 'completed'
            request.processed_at = timezone.now()
            request.created_mist_site = mist_site
            request.save()
            
            logger.info(f"Successfully onboarded site: {request.site_name}")
            
            return {
                'success': True,
                'mist_site_id': mist_site.mist_id,
                'nautobot_mist_site_id': mist_site.id
            }
            
        except Exception as e:
            logger.error(f"Error processing onboarding request {request.id}: {str(e)}")
            
            # Update request with error
            request.status = 'failed'
            request.processed_at = timezone.now()
            request.error_message = str(e)
            request.save()
            
            return {
                'success': False,
                'error': str(e)
            }
    
    def bulk_onboard_sites(self, organization_id: str, site_ids: list) -> dict:
        """
        Bulk onboard multiple Nautobot sites to Mist
        """
        from nautobot.dcim.models import Site
        
        results = {
            'success': 0,
            'failed': 0,
            'errors': []
        }
        
        organization = MistOrganization.objects.get(id=organization_id)
        
        for site_id in site_ids:
            try:
                site = Site.objects.get(id=site_id)
                
                # Create onboarding request
                request = SiteOnboardingRequest.objects.create(
                    nautobot_site=site,
                    target_organization=organization,
                    site_name=site.name,
                    address=site.physical_address or '',
                    latitude=site.latitude,
                    longitude=site.longitude,
                    requested_by='system',
                )
                
                # Process immediately
                result = self.process_request(request)
                
                if result['success']:
                    results['success'] += 1
                else:
                    results['failed'] += 1
                    results['errors'].append(f"{site.name}: {result['error']}")
                    
            except Exception as e:
                results['failed'] += 1
                results['errors'].append(f"Site {site_id}: {str(e)}")
        
        return results