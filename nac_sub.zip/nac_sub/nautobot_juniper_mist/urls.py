# nautobot_juniper_mist/urls.py

from django.urls import path
from . import views

app_name = 'nautobot_juniper_mist'

urlpatterns = [
    # Main views
    path('', views.HomeView.as_view(), name='home'),
    path('sync/', views.SyncView.as_view(), name='sync'),
    
    # Organization views
    path('organizations/', views.OrganizationListView.as_view(), name='organization_list'),
    
    # Site views
    path('sites/', views.SiteListView.as_view(), name='site_list'),
    
    # Device views
    path('devices/', views.DeviceListView.as_view(), name='device_list'),
    
    # Sync job views
    path('sync-jobs/', views.SyncJobListView.as_view(), name='sync_job_list'),
    
    # Site onboarding views
    # Site onboarding
    path('onboard-site/', views.SiteOnboardingView.as_view(), name='site_onboarding'),
    path('onboarding-requests/', views.OnboardingListView.as_view(), name='onboarding_list'),
    path('process-onboarding/<uuid:pk>/', views.ProcessOnboardingView.as_view(), name='process_onboarding'),
    
    # Template views
    path('templates/', views.TemplateListView.as_view(), name='template_list'),
    path('templates/create/rf/', views.CreateRFTemplateView.as_view(), name='create_rf_template'),
    path('templates/create/network/', views.CreateNetworkTemplateView.as_view(), name='create_network_template'),
    path('templates/create/gateway/', views.CreateGatewayTemplateView.as_view(), name='create_gateway_template'),
    path('templates/sync/', views.SyncTemplatesView.as_view(), name='sync_templates'),
    path('templates/<uuid:pk>/', views.TemplateDetailView.as_view(), name='template_detail'),
    path('templates/<uuid:pk>/edit/', views.TemplateEditView.as_view(), name='template_edit'),
    path('templates/<uuid:pk>/delete/', views.TemplateDeleteView.as_view(), name='template_delete'),
    
    # AJAX endpoints
    path('ajax/get-templates/', views.GetTemplatesAjaxView.as_view(), name='get_templates_ajax'),
    
    # Debug views
    path('test-api/', views.test_api_connection, name='test_api_connection'),
    path('debug-onboarding/', views.debug_onboarding, name='debug_onboarding'),
]