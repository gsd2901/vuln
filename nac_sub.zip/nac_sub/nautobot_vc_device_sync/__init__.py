from nautobot.apps import NautobotAppConfig

__version__ = "1.0.0"


class VCDeviceSyncConfig(NautobotAppConfig):
    name = "nautobot_vc_device_sync"
    verbose_name = "VC Device Sync"
    version = __version__
    author = "Akash Sharma"
    description = "Sync VC member devices with master device"
    base_url = "vc-device-sync"

    required_settings = []
    default_settings = {}
    caching_config = {}

    def ready(self):
        super().ready()

        # # ✅ SAFE imports here (Django is ready now)
        # from nautobot.extras.models import Job as JobModel, JobQueue
        # from nautobot.extras.registry import registry
        # from .jobs import SyncExistingVCDevices

        # # ✅ Register job manually (if you really want this way)
        # registry["jobs"]["nautobot_vc_device_sync.jobs.SyncExistingVCDevices"] = SyncExistingVCDevices

        # default_queue, _ = JobQueue.objects.get_or_create(name="default")

        # JobModel.objects.get_or_create(
        #     job_class_name="SyncExistingVCDevices",
        #     module_name="nautobot_vc_device_sync.jobs",
        #     defaults={
        #         "name": "Sync Existing VC Devices",
        #         "description": "Sync VC members from master",
        #         "installed": True,
        #         "enabled": True,
        #         "default_job_queue": default_queue,
        #     },
        # )

        # ✅ Load signals here as well
        import nautobot_vc_device_sync.signals  # noqa


config = VCDeviceSyncConfig