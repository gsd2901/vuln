from nautobot.apps.jobs import Job, BooleanVar, register_jobs
from nautobot.dcim.models import VirtualChassis


class SyncExistingVCDevices(Job):
    """
    Sync all existing VC member devices with their master device.
    Supports dry-run mode.
    """

    dry_run = BooleanVar(
        description="If enabled, no changes will be applied. Only preview.",
        default=True,
    )

    class Meta:
        name = "Sync Existing VC Devices"
        description = "Sync VC members with master (supports dry-run)"

    def run(self, dry_run):
        total_vcs = 0
        total_devices = 0
        total_changes = 0

        for vc in VirtualChassis.objects.all():
            master = vc.master

            if not master:
                self.logger.warning(f"VC '{vc.name}' has no master")
                continue

            total_vcs += 1

            for device in vc.members.exclude(id=master.id):
                total_devices += 1
                changes = []

                if device.device_type != master.device_type:
                    changes.append("device_type")

                if hasattr(device, "software_version"):
                    if device.software_version != master.software_version:
                        changes.append("software_version")

                if not changes:
                    continue

                total_changes += 1

                if dry_run:
                    self.logger.info(
                        f"[DRY-RUN] {device.name} would be updated from {master.name}: {changes}"
                    )
                else:
                    if "device_type" in changes:
                        device.device_type = master.device_type

                    if "software_version" in changes:
                        device.software_version = master.software_version

                    device.save(update_fields=changes)

                    self.logger.info(
                        f"{device.name} updated from {master.name}: {changes}"
                    )

        self.logger.info(f"Mode: {'DRY-RUN' if dry_run else 'EXECUTION'}")
        self.logger.info(f"VCs processed: {total_vcs}")
        self.logger.info(f"Devices checked: {total_devices}")
        self.logger.info(f"Devices needing update: {total_changes}")