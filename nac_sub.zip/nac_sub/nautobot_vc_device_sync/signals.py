import logging
from django.db.models.signals import post_save
from django.dispatch import receiver
from nautobot.dcim.models import Device

logger = logging.getLogger(__name__)


@receiver(post_save, sender=Device)
def sync_device_with_vc_master(sender, instance, **kwargs):
    device = instance

    # ✅ Prevent recursion
    if getattr(device, "_vc_sync_done", False):
        return

    vc = device.virtual_chassis
    if not vc:
        return

    # ✅ Skip master
    if vc.master_id == device.id:
        return

    master = vc.master
    if not master:
        return

    updated_fields = []

    if device.device_type != master.device_type:
        device.device_type = master.device_type
        updated_fields.append("device_type")

    if hasattr(device, "software_version"):
        if device.software_version != master.software_version:
            device.software_version = master.software_version
            updated_fields.append("software_version")

    if not updated_fields:
        return

    try:
        device._vc_sync_done = True
        device.save(update_fields=updated_fields)

        logger.info(
            "[VC Sync] Device=%s updated from master=%s fields=%s",
            device.name,
            master.name,
            updated_fields,
        )

    except Exception as e:
        logger.error(f"[VC Sync ERROR] {device.name}: {str(e)}")