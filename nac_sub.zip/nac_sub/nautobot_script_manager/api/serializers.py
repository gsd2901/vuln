from rest_framework import serializers
from nautobot.core.api.serializers import ValidatedModelSerializer
from ..models import Script, ScriptCategory, ScriptSchedule
from nautobot.extras.api.serializers import JobResultSerializer

class ScriptSerializer(ValidatedModelSerializer):
    url = serializers.HyperlinkedIdentityField(
        view_name='plugins-api:nautobot_script_manager-api:script-detail'
    )
    run_url = serializers.HyperlinkedIdentityField(
        view_name='plugins-api:nautobot_script_manager-api:script-run'
    )
    source_type_display = serializers.CharField(source='get_source_type_display', read_only=True)
    
    class Meta:
        model = Script
        fields = [
            'id', 'url', 'name', 'description', 'source_type', 'source_type_display', 
            'git_url', 'git_branch', 'enabled', 'run_url', 'created', 'last_updated'
        ]

class ScriptRunSerializer(serializers.Serializer):
    """Serializer for running scripts via API"""
    commit = serializers.BooleanField(default=True, help_text="Commit changes to the database")
    # Dynamic fields will be added based on the script's variables

class ScriptCategorySerializer(ValidatedModelSerializer):
    url = serializers.HyperlinkedIdentityField(
        view_name='plugins-api:nautobot_script_manager-api:scriptcategory-detail'
    )
    script_count = serializers.IntegerField(source='scripts.count', read_only=True)
    
    class Meta:
        model = ScriptCategory
        fields = ['id', 'url', 'name', 'description', 'script_count', 'created', 'last_updated']

class ScriptScheduleSerializer(ValidatedModelSerializer):
    url = serializers.HyperlinkedIdentityField(
        view_name='plugins-api:nautobot_script_manager-api:scriptschedule-detail'
    )
    script = serializers.HyperlinkedRelatedField(
        view_name='plugins-api:nautobot_script_manager-api:script-detail',
        queryset=Script.objects.all()
    )
    
    class Meta:
        model = ScriptSchedule
        fields = ['id', 'url', 'name', 'script', 'description', 'crontab', 'parameters', 'enabled', 'created', 'last_updated']