from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework import status
from django.contrib.contenttypes.models import ContentType
import threading

from nautobot.core.api.views import ModelViewSet
from django.shortcuts import get_object_or_404
from nautobot.extras.models import JobResult
from nautobot.extras.api.serializers import JobResultSerializer

from ..models import Script, ScriptCategory, ScriptSchedule
from ..views import ScriptRunView
from .serializers import ScriptSerializer, ScriptRunSerializer, ScriptCategorySerializer, ScriptScheduleSerializer

class ScriptViewSet(ModelViewSet):
    queryset = Script.objects.all()
    serializer_class = ScriptSerializer
    
    @action(detail=True, methods=['get', 'post'])
    def run(self, request, pk=None):
        """Run a script via API"""
        script = get_object_or_404(Script, pk=pk)
        
        if not script.enabled:
            return Response(
                {"error": "This script is disabled"},
                status=status.HTTP_400_BAD_REQUEST
            )
        
        # Get form fields from script
        try:
            script_run_view = ScriptRunView()
            form_fields = script_run_view.get_form_fields(script)
            
            # For GET requests, return the form fields
            if request.method == 'GET':
                fields_data = []
                for field in form_fields:
                    fields_data.append({
                        'name': field['name'],
                        'type': field['type'],
                        'required': field.get('required', True),
                        'default': field.get('default'),
                        'description': field.get('description', ''),
                    })
                return Response({
                    'script': ScriptSerializer(script, context={'request': request}).data,
                    'fields': fields_data
                })
            
            # For POST requests, run the script
            if request.method == 'POST':
                # Validate form data
                serializer = ScriptRunSerializer(data=request.data)
                serializer.is_valid(raise_exception=True)
                
                # Create a JobResult
                job_result = JobResult.objects.create(
                    name=script.name,
                    obj_type=ContentType.objects.get_for_model(Script),
                    obj_id=script.pk,
                    status=JobResult.STATUS_PENDING,
                    user=request.user,
                )
                
                # Process form data
                form_data = {}
                for field in form_fields:
                    field_name = field['name']
                    if field_name in request.data:
                        form_data[field_name] = request.data[field_name]
                    elif field.get('required', True) and field.get('default') is None:
                        return Response(
                            {f"error": f"Missing required field: {field_name}"},
                            status=status.HTTP_400_BAD_REQUEST
                        )
                    else:
                        form_data[field_name] = field.get('default')
                
                # Start execution in a background thread
                thread = threading.Thread(
                    target=script_run_view.execute_script,
                    args=(script, form_data, job_result, serializer.validated_data.get('commit', True))
                )
                thread.daemon = True
                thread.start()
                
                return Response(
                    JobResultSerializer(job_result, context={'request': request}).data,
                    status=status.HTTP_202_ACCEPTED
                )
                
        except Exception as e:
            return Response(
                {"error": str(e)},
                status=status.HTTP_400_BAD_REQUEST
            )

class ScriptCategoryViewSet(ModelViewSet):
    queryset = ScriptCategory.objects.all()
    serializer_class = ScriptCategorySerializer

class ScriptScheduleViewSet(ModelViewSet):
    queryset = ScriptSchedule.objects.all()
    serializer_class = ScriptScheduleSerializer