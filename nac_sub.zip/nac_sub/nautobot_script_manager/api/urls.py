from nautobot.core.api.routers import OrderedDefaultRouter
from . import views

app_name = 'nautobot_script_manager-api'

router = OrderedDefaultRouter()
router.register('scripts', views.ScriptViewSet)
router.register('categories', views.ScriptCategoryViewSet)
router.register('schedules', views.ScriptScheduleViewSet)

urlpatterns = router.urls