# tables.py
import django_tables2 as tables
from nautobot.core.tables import BaseTable, ToggleColumn
from django.utils.safestring import mark_safe

from .models import Script, ScriptCategory, ScriptSchedule

class ScriptTable(BaseTable):
    pk = ToggleColumn()
    name = tables.Column(linkify=True)
    source_type = tables.Column()
    enabled = tables.BooleanColumn()
    actions = tables.TemplateColumn(
        template_code="""
        {% if record.enabled %}
        <a href="{% url 'plugins:nautobot_script_manager:script_run' pk=record.pk %}" class="btn btn-sm btn-success">
            <i class="fa fa-play"></i>
        </a>
        {% endif %}
        <a href="{% url 'plugins:nautobot_script_manager:script_test' pk=record.pk %}" class="btn btn-sm btn-info">
            <i class="fa fa-check-circle"></i>
        </a>
        """,
        verbose_name=''
    )
    
    class Meta(BaseTable.Meta):
        model = Script
        fields = ('pk', 'name', 'description', 'source_type', 'enabled', 'actions')

class ScriptCategoryTable(BaseTable):
    pk = ToggleColumn()
    name = tables.Column(linkify=True)
    
    class Meta(BaseTable.Meta):
        model = ScriptCategory
        fields = ('pk', 'name', 'description')

class ScriptScheduleTable(BaseTable):
    pk = ToggleColumn()
    name = tables.Column(linkify=True)
    script = tables.Column(linkify=True)
    enabled = tables.BooleanColumn()
    
    class Meta(BaseTable.Meta):
        model = ScriptSchedule
        fields = ('pk', 'name', 'script', 'crontab', 'enabled')