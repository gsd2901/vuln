# filters.py
import django_filters
from django.db.models import Q
from nautobot.core.filters import BaseFilterSet, NameSlugSearchFilterSet

from .models import Script, ScriptCategory, ScriptSchedule

class ScriptFilterSet(BaseFilterSet):
    q = django_filters.CharFilter(
        method='search',
        label='Search',
    )
    
    class Meta:
        model = Script
        fields = ['id', 'name', 'description', 'category', 'enabled', 'source_type']
    
    def search(self, queryset, name, value):
        if not value.strip():
            return queryset
        return queryset.filter(
            Q(name__icontains=value) | 
            Q(description__icontains=value)
        )

class ScriptCategoryFilterSet(NameSlugSearchFilterSet):
    class Meta:
        model = ScriptCategory
        fields = ['id', 'name', 'description']

class ScriptScheduleFilterSet(BaseFilterSet):
    q = django_filters.CharFilter(
        method='search',
        label='Search',
    )
    
    class Meta:
        model = ScriptSchedule
        fields = ['id', 'name', 'script', 'enabled']
    
    def search(self, queryset, name, value):
        if not value.strip():
            return queryset
        return queryset.filter(
            Q(name__icontains=value) | 
            Q(description__icontains=value)
        )