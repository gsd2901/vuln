# tasks.py
from django.contrib.auth import get_user_model
from django.contrib.contenttypes.models import ContentType
from nautobot.extras.models import JobResult
from nautobot.extras.choices import LogLevelChoices

from .models import ScriptSchedule, Script
from .views import ScriptRunView

User = get_user_model()

def run_scheduled_script(schedule_id):
    """Run a scheduled script"""
    try:
        schedule = ScriptSchedule.objects.get(id=schedule_id)
        script = schedule.script
        
        if not script.enabled or not schedule.enabled:
            return False
        
        # Get admin user or first superuser
        try:
            user = User.objects.filter(is_superuser=True).first()
        except:
            user = None
            
        # Create a JobResult
        job_result = JobResult.objects.create(
            name=f"[Scheduled] {script.name}",
            obj_type=ContentType.objects.get_for_model(Script),
            obj_id=script.pk,
            status=JobResult.STATUS_RUNNING,
            user=user,
        )
        
        # Get parameters from schedule
        form_data = schedule.parameters or {}
        
        # Run the script
        script_run_view = ScriptRunView()
        script_run_view.execute_script(script, form_data, job_result, commit=True)
        
        return True
        
    except Exception as e:
        # Log error
        import logging
        logger = logging.getLogger(__name__)
        logger.error(f"Error running scheduled script {schedule_id}: {str(e)}")
        return False