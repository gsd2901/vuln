import ast
import importlib.util
import sys
import tempfile
import os
import git
from pathlib import Path
from django.utils import timezone
from django.conf import settings

from django.contrib import messages
from django.shortcuts import get_object_or_404, redirect, render
from django.urls import reverse
from django.views.generic import View

from django_tables2 import RequestConfig
from django.db.models.deletion import ProtectedError

from nautobot.core.views import generic
from nautobot.extras.jobs import StringVar, IntegerVar, BooleanVar, ObjectVar, MultiObjectVar, FileVar, IPNetworkVar, IPAddressVar
from nautobot.extras.models import Job, JobResult, JobQueue
from nautobot.extras.choices import JobResultStatusChoices
import threading
from django.utils.safestring import mark_safe
from django.contrib.contenttypes.models import ContentType
from nautobot.extras.choices import LogLevelChoices
from .tables import ScriptTable, ScriptCategoryTable, ScriptScheduleTable
from .forms import ScriptCategoryForm, ScriptCategoryForm, ScriptScheduleForm, ScriptUploadForm
from .models import Script, ScriptCategory, ScriptSchedule
from django_filters.views import FilterView
from django_filters import CharFilter, BooleanFilter, ModelChoiceFilter

from django_filters import FilterSet, CharFilter, BooleanFilter
from django.db.models import Q

class ScriptManagerListView(generic.ObjectListView):
    """Base class for all list views in the script manager app"""
    
    def get_filterset(self, filterset_class, queryset, request):
        """
        Return an instance of the filterset to be used in this view.
        This is needed to work around template issues.
        """
        if filterset_class is None:
            return None
            
        kwargs = self.get_filterset_kwargs(filterset_class, queryset, request)
        return filterset_class(**kwargs)
    
    def get_template_names(self):
        """
        Returns a list of template names to be used for rendering the response.
        """
        return [
            f"nautobot_script_manager/{self.queryset.model._meta.model_name}_list.html",
            "nautobot_script_manager/object_list.html",
            "generic/object_list.html",
        ]

class ScriptFilterSet(FilterSet):
    q = CharFilter(method='search', label='Search')
    enabled = BooleanFilter()
    
    class Meta:
        model = Script
        fields = ['name', 'enabled', 'source_type']
    
    def search(self, queryset, name, value):
        if not value.strip():
            return queryset
        return queryset.filter(
            Q(name__icontains=value) | 
            Q(description__icontains=value)
        )

# class ScriptListView(ScriptManagerListView):
#     queryset = Script.objects.all()
#     filterset_class = ScriptFilterSet
#     table = ScriptTable
#     action_buttons = ('add',)

# class ScriptView(generic.ObjectView):
#     queryset = Script.objects.all()
#     template_name = 'nautobot_script_manager/script_list.html'

# class ScriptCreateView(generic.ObjectEditView):
#     model = Script
#     queryset = Script.objects.all()
#     form = ScriptCategoryForm
#     template_name = 'nautobot_script_manager/script_upload.html'

class ScriptListView(generic.ObjectListView):
    queryset = Script.objects.all()
    filterset_class = ScriptFilterSet
    table = ScriptTable
    action_buttons = ('add',)
    template_name = 'nautobot_script_manager/script_list.html'  # Explicitly set template

    def get_extra_context(self, request, instance=None):
        context = super().get_extra_context(request, instance)
        context['model'] = Script
        context['content_type'] = ContentType.objects.get_for_model(Script)
        context['filter_form'] = self.filterset_class(request.GET, queryset=self.queryset).form
        return context

class ScriptView(generic.ObjectView):
    queryset = Script.objects.all()
    template_name = 'nautobot_script_manager/script_detail.html'

class ScriptCreateView(generic.ObjectEditView):
    model = Script
    queryset = Script.objects.all()
    model_form = ScriptUploadForm
    template_name = 'nautobot_script_manager/script_upload.html'

class ScriptEditView(ScriptCreateView):
    template_name = 'nautobot_script_manager/script_edit.html'

class ScriptDeleteView(generic.ObjectDeleteView):
    queryset = Script.objects.all()
    # Use the generic object delete template
    template_name = 'generic/object_delete.html'  
    default_return_url = 'plugins:nautobot_script_manager:script_list'
    
    def get_extra_context(self, request, instance):
        """Add extra context data to the view."""
        context = super().get_extra_context(request, instance)
        return context
    

class ScriptRunView(View):
    """View to parse script and generate a form for execution"""
    
    def get(self, request, pk):
        script = get_object_or_404(Script, pk=pk)
        
        if not script.enabled:
            messages.error(request, "This script is disabled")
            return redirect('plugins:nautobot_script_manager:script', pk=script.pk)
        
        # Get form fields from script
        try:
            form_fields = self.get_form_fields(script)
            form = self.generate_dynamic_form(form_fields)
            
            return render(request, 'nautobot_script_manager/script_run.html', {
                'script': script,
                'form': form,
            })
        except Exception as e:
            messages.error(request, f"Error parsing script: {str(e)}")
            return redirect('plugins:nautobot_script_manager:script', pk=script.pk)
    
    def post(self, request, pk):
        script = get_object_or_404(Script, pk=pk)
        
        if not script.enabled:
            messages.error(request, "This script is disabled")
            return redirect('plugins:nautobot_script_manager:script', pk=script.pk)

        try:
            # Get or create the Job object
            try:
                job = Job.objects.get(name=script.name)
            except Job.DoesNotExist:
                # Create Job if it doesn't exist
                try:
                    default_queue = JobQueue.objects.get(name=settings.CELERY_TASK_DEFAULT_QUEUE)
                except:
                    default_queue = JobQueue.objects.first()
                    
                job = Job.objects.create(
                    module_name=f"nautobot_script_manager.scripts.{script.pk}",
                    job_class_name=f"Script{script.pk}",
                    grouping="Script Manager",
                    name=script.name,
                    description=script.description or "Script from Script Manager",
                    installed=True,
                    enabled=True,
                    default_job_queue=default_queue,
                )
                job.job_queues.add(default_queue)
            
            # Parse script to get form fields
            form_fields = self.get_form_fields(script)
            form_class = self.generate_dynamic_form_class(form_fields)
            form = form_class(request.POST, request.FILES)
            
            if form.is_valid():
                # Create a JobResult - note we don't set the 'started' field as it doesn't exist
                # The model will automatically set date_created
                job_result = JobResult.objects.create(
                    name=script.name,
                    job_model=job,
                    status=JobResultStatusChoices.STATUS_STARTED,
                    user=request.user,
                )
                
                # Get commit value
                commit = request.POST.get('commit') == 'on'
                
                try:
                    # Set up logger
                    class JobResultLogger:
                        def __init__(self, job_result):
                            self.job_result = job_result
                        
                        def info(self, message):
                            self.job_result.log(message)
                        
                        def warning(self, message):
                            self.job_result.log(message, level_choice=LogLevelChoices.LOG_WARNING)
                        
                        def error(self, message):
                            self.job_result.log(message, level_choice=LogLevelChoices.LOG_ERROR)
                    
                    logger = JobResultLogger(job_result)
                    logger.info(f"Script execution started at {job_result.date_created}")
                    
                    # Create namespace for script execution
                    namespace = {
                        'data': form.cleaned_data,
                        'commit': commit,
                        'logger': logger,
                    }
                    
                    # Execute the script
                    compiled_code = compile(script.script_content, f"script_{script.pk}", 'exec')
                    exec(compiled_code, namespace)
                    
                    # Call the run function
                    result = False
                    if 'run' in namespace and callable(namespace['run']):
                        result = namespace['run'](form.cleaned_data, commit, logger)
                    else:
                        # Try to find a Job class
                        job_class = None
                        for name, obj in namespace.items():
                            if (isinstance(obj, type) and 
                                hasattr(obj, 'run') and 
                                name != 'Job' and 
                                callable(getattr(obj, 'run', None))):
                                job_class = obj
                                break
                        
                        if job_class is not None:
                            job_instance = job_class()
                            job_instance.log_info = logger.info
                            job_instance.log_warning = logger.warning
                            job_instance.log_error = logger.error
                            result = job_instance.run(form.cleaned_data, commit)
                        else:
                            raise ValueError("No run function or Job class found")
                    
                    # Set final status based on result
                    from django.utils import timezone
                    completed_now = timezone.now()
                    
                    if result is True:
                        logger.info(f"Script completed successfully at {completed_now}")
                        job_result.status = JobResultStatusChoices.STATUS_SUCCESS
                    else:
                        logger.warning(f"Script failed at {completed_now}")
                        job_result.status = JobResultStatusChoices.STATUS_FAILURE
                    
                    # Important: Always set completion time using the correct field name
                    job_result.date_done = completed_now
                    job_result.save()
                    
                except Exception as e:
                    import traceback
                    error_msg = f"Error executing script: {str(e)}"
                    job_result.log(error_msg, level_choice=LogLevelChoices.LOG_ERROR)
                    job_result.log(traceback.format_exc(), level_choice=LogLevelChoices.LOG_ERROR)
                    job_result.status = JobResultStatusChoices.STATUS_FAILURE
                    job_result.date_done = timezone.now()
                    job_result.save()
                
                # Redirect to job result
                return redirect('extras:jobresult', pk=job_result.pk)
            else:
                return render(request, 'nautobot_script_manager/script_run.html', {
                    'script': script,
                    'form': form,
                })
        except Exception as e:
            messages.error(request, f"Error setting up script: {str(e)}")
            return redirect('plugins:nautobot_script_manager:script', pk=script.pk)
    
    def get_form_fields(self, script):
        """Get form fields from script content"""
        if script.source_type == 'upload':
            script_content = script.script_content
            return self.parse_script_content(script_content)
        else:
            # Clone git repo to temp directory
            with tempfile.TemporaryDirectory() as tmpdirname:
                try:
                    repo = git.Repo.clone_from(script.git_url, tmpdirname)
                    if script.git_branch:
                        repo.git.checkout(script.git_branch)
                    
                    # Find Python files
                    py_files = list(Path(tmpdirname).glob("**/*.py"))
                    if not py_files:
                        raise ValueError("No Python files found in the repository")
                    
                    # For simplicity, use the first Python file found
                    script_path = py_files[0]
                    with open(script_path, 'r') as f:
                        script_content = f.read()
                    
                    # Cache the script content for execution
                    script.script_content = script_content
                    script.save()
                    
                    return self.parse_script_content(script_content)
                except Exception as e:
                    raise ValueError(f"Error fetching script from Git: {e}")
    
    def parse_script_content(self, content):
        """Parse script content to identify variables using both formats"""
        form_fields = []
        
        try:
            # First try to parse using the variables list approach
            namespace = {}
            exec(content, namespace)
            
            # Look for variables list format
            if 'variables' in namespace:
                for var in namespace['variables']:
                    field = {
                        'name': var.get('name', ''),
                        'type': self._map_var_type(var.get('type', 'string')),
                        'required': var.get('required', False),
                        'default': var.get('default'),
                        'description': var.get('description', ''),
                        'label': var.get('label', ''),
                    }
                    
                    # Add any additional attributes
                    for key, value in var.items():
                        if key not in ['name', 'type', 'required', 'default', 'description', 'label']:
                            field[key] = value
                    
                    form_fields.append(field)
            
            # If no fields found yet, try the Job class approach
            if not form_fields:
                # Parse the Python code
                tree = ast.parse(content)
                
                # Find all Job classes
                for node in ast.walk(tree):
                    if isinstance(node, ast.ClassDef):
                        # Check if this class inherits from Job
                        for base in node.bases:
                            if isinstance(base, ast.Name) and base.id == 'Job':
                                # This is a Job class, now look for variable definitions
                                for child_node in node.body:
                                    if isinstance(child_node, ast.Assign):
                                        for target in child_node.targets:
                                            if isinstance(target, ast.Name) and isinstance(child_node.value, ast.Call):
                                                var_name = target.id
                                                var_type = getattr(child_node.value.func, 'id', None)
                                                
                                                if var_type in ['StringVar', 'IntegerVar', 'BooleanVar', 'ObjectVar', 
                                                            'MultiObjectVar', 'FileVar', 'IPNetworkVar', 'IPAddressVar',
                                                            'TextVar', 'ChoiceVar']:
                                                    # Extract arguments from the variable definition
                                                    kwargs = {
                                                        'name': var_name,
                                                        'type': var_type,
                                                        'required': True,  # Default
                                                        'default': None,
                                                        'description': '',
                                                        'label': var_name.replace('_', ' ').title(),
                                                    }
                                                    
                                                    for keyword in child_node.value.keywords:
                                                        if keyword.arg in ['description', 'required', 'default', 'label', 'model', 'query_params']:
                                                            if isinstance(keyword.value, ast.Constant):
                                                                kwargs[keyword.arg] = keyword.value.value
                                                    
                                                    form_fields.append(kwargs)
            
            return form_fields
        except Exception as e:
            # Log the error but return any fields we managed to parse
            raise ValueError(f"Error parsing script: {e}")

    def _map_var_type(self, var_type):
        """Map script variable types to form field types"""
        mapping = {
            'string': 'StringVar',
            'text': 'TextVar',
            'integer': 'IntegerVar',
            'boolean': 'BooleanVar',
            'choice': 'ChoiceVar',
            'object': 'ObjectVar',
            'multiobject': 'MultiObjectVar',
            'file': 'FileVar',
            'ipnetwork': 'IPNetworkVar',
            'ipaddress': 'IPAddressVar',
        }
        return mapping.get(var_type.lower(), 'StringVar')
    
    def generate_dynamic_form_class(self, form_fields):
        """Generate a dynamic form class based on parsed fields"""
        from django import forms
        from nautobot.dcim.models import Device, Location, Rack
        from nautobot.ipam.models import IPAddress, Prefix
        
        model_map = {
            'Device': Device,
            'Site': Location,
            'Rack': Rack,
            'IPAddress': IPAddress,
            'Prefix': Prefix,
        }
        
        form_class = type('DynamicScriptForm', (forms.Form,), {})
        
        for field in form_fields:
            field_type = forms.CharField  # Default
            field_kwargs = {
                'label': field.get('label', field['name']),
                'help_text': field.get('description', ''),
                'required': field.get('required', True),
            }
            
            if 'default' in field and field['default'] is not None:
                field_kwargs['initial'] = field['default']
            
            if field['type'] == 'IntegerVar':
                field_type = forms.IntegerField
            elif field['type'] == 'BooleanVar':
                field_type = forms.BooleanField
                field_kwargs['required'] = False
            elif field['type'] == 'ObjectVar':
                field_type = forms.ModelChoiceField
                model_name = field.get('model')
                if isinstance(model_name, str) and model_name in model_map:
                    field_kwargs['queryset'] = model_map[model_name].objects.all()
                else:
                    # Generic fallback for unknown models
                    field_kwargs['queryset'] = Device.objects.none()
                    field_kwargs['help_text'] += " (Warning: Model not recognized)"
            elif field['type'] == 'MultiObjectVar':
                field_type = forms.ModelMultipleChoiceField
                model_name = field.get('model')
                if isinstance(model_name, str) and model_name in model_map:
                    field_kwargs['queryset'] = model_map[model_name].objects.all()
                else:
                    # Generic fallback
                    field_kwargs['queryset'] = Device.objects.none()
                    field_kwargs['help_text'] += " (Warning: Model not recognized)"
            elif field['type'] == 'FileVar':
                field_type = forms.FileField
            elif field['type'] == 'IPNetworkVar':
                field_type = forms.GenericIPAddressField
            elif field['type'] == 'IPAddressVar':
                field_type = forms.GenericIPAddressField
            elif field['type'] == 'TextVar':
                field_type = forms.CharField
                field_kwargs['widget'] = forms.Textarea
            elif field['type'] == 'ChoiceVar':
                field_type = forms.ChoiceField
                choices = field.get('choices', [])
                field_kwargs['choices'] = [(c, c) for c in choices] if choices else [('', '----------')]
            
            form_class.base_fields[field['name']] = field_type(**field_kwargs)
        
        return form_class
    
    def generate_dynamic_form(self, form_fields):
        """Generate a form instance from form fields"""
        form_class = self.generate_dynamic_form_class(form_fields)
        return form_class()
    
    def execute_script(self, script, form_data, job_result, commit=True):
        """Execute the script in a sandboxed environment with improved error handling and timeout"""
        from nautobot.extras.context_managers import JobResultStatusSetter
        import time
        import traceback
        
        # Create a custom logger
        class JobResultLogger:
            def __init__(self, job_result):
                self.job_result = job_result
            
            def info(self, message):
                self.job_result.log(message)
            
            def warning(self, message):
                self.job_result.log(message, level_choice=LogLevelChoices.LOG_WARNING)
            
            def error(self, message):
                self.job_result.log(message, level_choice=LogLevelChoices.LOG_ERROR)
        
        logger = JobResultLogger(job_result)
        
        # Maximum script execution time (in seconds)
        MAX_EXECUTION_TIME = 300  # 5 minutes
        start_time = time.time()
        
        try:
            # Record the start time and initialize result
            logger.info(f"Script execution started at {time.strftime('%H:%M:%S')}")
            logger.info(f"Dry run mode: {'Yes' if not commit else 'No'}")
            
            # Create a namespace for the script
            namespace = {
                'data': form_data,
                'commit': commit,
                'logger': logger,
            }
            
            script_content = script.script_content
            
            # Compile and execute the script
            compiled_code = compile(script_content, f"script_{script.pk}", 'exec')
            exec(compiled_code, namespace)
            
            # Try both execution approaches
            result = False
            
            # First, check for a run function (arbitrary script format)
            if 'run' in namespace and callable(namespace['run']):
                logger.info("Executing script using 'run' function")
                result = namespace['run'](form_data, commit, logger)
            else:
                # Look for Job class (Nautobot format)
                job_class = None
                for name, obj in namespace.items():
                    if (isinstance(obj, type) and 
                        hasattr(obj, 'run') and 
                        name != 'Job' and  # Skip the base Job class
                        callable(getattr(obj, 'run', None))):
                        job_class = obj
                        break
                
                if job_class is not None:
                    # Instantiate the job
                    logger.info(f"Executing script using Job class '{job_class.__name__}'")
                    job_instance = job_class()
                    
                    # Attach the logger
                    job_instance.log_info = logger.info
                    job_instance.log_warning = logger.warning
                    job_instance.log_error = logger.error
                    
                    # Run the job
                    result = job_instance.run(form_data, commit)
                else:
                    raise ValueError("No run function or Job class found in the script")
            
            # Check if the script has been running for too long
            elapsed_time = time.time() - start_time
            if elapsed_time > MAX_EXECUTION_TIME:
                logger.warning(f"Script execution timed out after {elapsed_time:.1f} seconds")
                job_result.status = JobResultStatusChoices.STATUS_FAILURE
                job_result.save()
                return
                
            # Explicitly log the result and execution time
            elapsed_time = time.time() - start_time
            logger.info(f"Script execution completed in {elapsed_time:.1f} seconds")
            logger.info(f"Script returned: {result}")
            
            # Update job status based on result
            if result is True:
                logger.info("Script executed successfully")
                job_result.status = JobResultStatusChoices.STATUS_SUCCESS
            else:
                logger.warning("Script execution failed or returned False")
                job_result.status = JobResultStatusChoices.STATUS_FAILURE
                
        except Exception as e:
            # Get full stack trace
            stack_trace = traceback.format_exc()
            
            # Log the detailed error and update job status
            logger.error(f"Error executing script: {str(e)}")
            logger.error(f"Stack trace: {stack_trace}")
            job_result.status = JobResultStatusChoices.STATUS_FAILURE
        
        # Always save the status at the end, outside the context manager
        job_result.completed = timezone.now()
        job_result.save()
        logger.info(f"Final job status: {job_result.status}")


class ScriptTestView(View):
    """View to test a script without executing it"""
    
    def get(self, request, pk):
        script = get_object_or_404(Script, pk=pk)
        
        if not script.enabled:
            messages.error(request, "This script is disabled")
            return redirect('plugins:nautobot_script_manager:script', pk=script.pk)
        
        try:
            # Try to parse the script
            script_run_view = ScriptRunView()
            form_fields = script_run_view.get_form_fields(script)
            
            # Basic validation passed
            messages.success(request, "Script validation passed. Found the following variables:")
            
            # Display the variables found
            variable_list = "<ul>"
            for field in form_fields:
                variable_list += f"<li><strong>{field['name']}</strong>: {field['type']}</li>"
            variable_list += "</ul>"
            
            messages.info(request, mark_safe(variable_list))
            
            return redirect('plugins:nautobot_script_manager:script', pk=script.pk)
            
        except Exception as e:
            messages.error(request, f"Script validation failed: {str(e)}")
            return redirect('plugins:nautobot_script_manager:script', pk=script.pk)
        
class ScriptCategoryFilterSet(FilterSet):
    name = CharFilter(lookup_expr='icontains')
    description = CharFilter(lookup_expr='icontains')

    class Meta:
        model = ScriptCategory
        fields = ['name', 'description']

class ScriptCategoryListView(generic.ObjectListView):
    queryset = ScriptCategory.objects.all()
    filterset_class = ScriptCategoryFilterSet
    table = ScriptCategoryTable
    action_buttons = ('add',)
    template_name = 'nautobot_script_manager/script_category_list.html'

    def get_extra_context(self, request, instance=None):
        context = super().get_extra_context(request, instance)
        context['model'] = ScriptCategory
        context['content_type'] = ContentType.objects.get_for_model(ScriptCategory)
        # Ensure the filter form is passed to the context
        context['filter_form'] = self.filterset_class(request.GET, queryset=self.queryset).form
        return context

class ScriptScheduleFilterSet(FilterSet):
    name = CharFilter(lookup_expr='icontains')
    script = ModelChoiceFilter(queryset=Script.objects.all())
    enabled = BooleanFilter()
    
    class Meta:
        model = ScriptSchedule
        fields = ['name', 'script', 'enabled']

class ScriptCategoryView(generic.ObjectView):
    queryset = ScriptCategory.objects.all()
    template_name = 'nautobot_script_manager/script_category_detail.html'

class ScriptCategoryCreateView(generic.ObjectEditView):
    model = ScriptCategory
    queryset = ScriptCategory.objects.all()
    form = ScriptCategoryForm
    
class ScriptCategoryEditView(ScriptCategoryCreateView):
    pass

class ScriptCategoryDeleteView(generic.ObjectDeleteView):
    queryset = ScriptCategory.objects.all()
    default_return_url = 'plugins:nautobot_script_manager:script_category_list'

class ScriptScheduleListView(ScriptManagerListView):
    queryset = ScriptSchedule.objects.all()
    filterset_class = ScriptScheduleFilterSet
    table = ScriptScheduleTable
    action_buttons = ('add',)

class ScriptScheduleView(generic.ObjectView):
    queryset = ScriptSchedule.objects.all()
    template_name = 'nautobot_script_manager/script_schedule_list.html'

class ScriptScheduleCreateView(generic.ObjectEditView):
    model = ScriptSchedule
    queryset = ScriptSchedule.objects.all()
    form = ScriptScheduleForm
    
class ScriptScheduleEditView(ScriptScheduleCreateView):
    pass

class ScriptScheduleDeleteView(generic.ObjectDeleteView):
    queryset = ScriptSchedule.objects.all()
    default_return_url = 'plugins:nautobot_script_manager:script_schedule_list'


class ScriptHelpView(View):
    """View for script writing help"""
    
    def get(self, request):
        return render(request, 'nautobot_script_manager/help.html')