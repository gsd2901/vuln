from nautobot.core.apps import NavMenuTab, NavMenuGroup, NavMenuItem

menu_items = (
    # NavMenuTab(
    #     name="Plugins",
    #     groups=(
    #         NavMenuGroup(
    #             name="Script Manager",
    #             items=(
    #                 NavMenuItem(
    #                     link="plugins:nautobot_script_manager:script_list",
    #                     name="Scripts",
    #                     permissions=["nautobot_script_manager.view_script"],
    #                 ),
    #                 NavMenuItem(
    #                     link="plugins:nautobot_script_manager:script_category_list",
    #                     name="Categories",
    #                     permissions=["nautobot_script_manager.view_scriptcategory"],
    #                 ),
    #                 NavMenuItem(
    #                     link="plugins:nautobot_script_manager:script_schedule_list",
    #                     name="Schedules",
    #                     permissions=["nautobot_script_manager.view_scriptschedule"],
    #                 ),
    #                 NavMenuItem(
    #                     link="plugins:nautobot_script_manager:script_help",
    #                     name="Help",
    #                 ),
    #             ),
    #         ),
    #     ),
    # ),
)