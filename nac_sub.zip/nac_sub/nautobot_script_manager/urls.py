from django.urls import path, include
from . import views

urlpatterns = [
    path('scripts/', views.ScriptListView.as_view(), name='script_list'),
    path('scripts/add/', views.ScriptCreateView.as_view(), name='script_add'),
    path('scripts/<uuid:pk>/', views.ScriptView.as_view(), name='script'),
    path('scripts/<uuid:pk>/edit/', views.ScriptEditView.as_view(), name='script_edit'),
    path('scripts/<uuid:pk>/delete/', views.ScriptDeleteView.as_view(), name='script_delete'),
    path('scripts/<uuid:pk>/run/', views.ScriptRunView.as_view(), name='script_run'),
    path('scripts/<uuid:pk>/test/', views.ScriptTestView.as_view(), name='script_test'),
    
    path('categories/', views.ScriptCategoryListView.as_view(), name='script_category_list'),
    path('categories/add/', views.ScriptCategoryCreateView.as_view(), name='script_category_add'),
    path('categories/<uuid:pk>/', views.ScriptCategoryView.as_view(), name='script_category'),
    path('categories/<uuid:pk>/edit/', views.ScriptCategoryEditView.as_view(), name='script_category_edit'),
    path('categories/<uuid:pk>/delete/', views.ScriptCategoryDeleteView.as_view(), name='script_category_delete'),
    
    path('schedules/', views.ScriptScheduleListView.as_view(), name='script_schedule_list'),
    path('schedules/add/', views.ScriptScheduleCreateView.as_view(), name='script_schedule_add'),
    path('schedules/<uuid:pk>/', views.ScriptScheduleView.as_view(), name='script_schedule'),
    path('schedules/<uuid:pk>/edit/', views.ScriptScheduleEditView.as_view(), name='script_schedule_edit'),
    path('schedules/<uuid:pk>/delete/', views.ScriptScheduleDeleteView.as_view(), name='script_schedule_delete'),
    
    path('help/', views.ScriptHelpView.as_view(), name='script_help'),
    
    path('api/', include('nautobot_script_manager.api.urls')),
]