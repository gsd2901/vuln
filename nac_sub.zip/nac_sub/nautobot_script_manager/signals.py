# signals.py
from django.db.models.signals import post_save
from django.dispatch import receiver
from .models import ScriptSchedule

@receiver(post_save, sender=ScriptSchedule)
def handle_schedule_changes(sender, instance, created, **kwargs):
    """Handle updates to script schedules"""
    if instance.enabled:
        # Register or update the cron job
        try:
            from django_q.tasks import schedule
            from django_q.models import Schedule
            
            # Create or update a django_q schedule
            schedule_name = f'script_manager_{instance.pk}'
            
            # Delete any existing schedule with this name
            Schedule.objects.filter(name=schedule_name).delete()
            
            # Create new schedule
            if instance.enabled:
                schedule(
                    'nautobot_script_manager.tasks.run_scheduled_script',
                    instance.pk,
                    name=schedule_name,
                    schedule_type='cron',
                    cron=instance.crontab
                )
        except ImportError:
            # Django-Q not installed, log a warning
            import logging
            logger = logging.getLogger(__name__)
            logger.warning("Django-Q not installed. Script scheduling is disabled.")
    else:
        # Disable the cron job
        try:
            from django_q.models import Schedule
            schedule_name = f'script_manager_{instance.pk}'
            Schedule.objects.filter(name=schedule_name).delete()
        except ImportError:
            pass