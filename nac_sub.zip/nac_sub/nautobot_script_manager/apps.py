from django.apps import AppConfig


class NautobotScriptManagerConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'nautobot_script_manager'
