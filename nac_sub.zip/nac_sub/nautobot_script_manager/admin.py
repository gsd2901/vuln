from django.contrib import admin
from .models import Script

@admin.register(Script)
class ScriptAdmin(admin.ModelAdmin):
    list_display = ('name', 'source_type', 'enabled', 'created', 'last_updated')
    list_filter = ('source_type', 'enabled')
    search_fields = ('name', 'description', 'git_url')
    readonly_fields = ('created', 'last_updated')