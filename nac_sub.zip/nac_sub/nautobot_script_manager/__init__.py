from nautobot.apps import NautobotAppConfig

class ScriptManagerConfig(NautobotAppConfig):
    name = 'nautobot_script_manager'
    verbose_name = 'Script Manager'
    description = 'Upload and run custom scripts in Nautobot'
    version = '0.1'
    author = 'Avinash Sharma'
    author_email = 'avinash_sharma@hcltech.com'
    base_url = 'script-manager'
    required_settings = []
    default_settings = {
        'script_execution_timeout': 300,
    }
    
    def ready(self):
        super().ready()
        
        # Import and register jobs
        from django.db.migrations.loader import MigrationLoader
        loader = MigrationLoader(None, ignore_no_migrations=True)
        
        # Register with admin
        from django.contrib import admin
        from . import admin as app_admin
    
        # Register signals
        from django.db.models.signals import post_save
        from . import signals
    
config = ScriptManagerConfig