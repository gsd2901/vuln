# utils.py
import ast


def validate_script_content(content):
    """
    Validate script content for security issues.
    Returns (is_valid, message)
    """
    import re
    
    # List of potentially dangerous patterns (for regex search)
    dangerous_patterns = [
        r'\bos\.system\b', r'\bsubprocess\b', r'\bpty\b', r'\bsocket\b',
        r'\bshutil\.rmtree\b', r'\bdelete\b', r'\bremove\b', r'\brmdir\b', r'\brmtree\b'
    ]
    
    # List of dangerous imports (for AST checking)
    dangerous_imports = [
        'os.system', 'subprocess', 'pty', 'socket',
        'shutil.rmtree', 'delete', 'remove', 'rmdir', 'rmtree'
    ]
    
    # Check for dangerous imports using regex to match whole words
    for dangerous_pattern in dangerous_patterns:
        if re.search(dangerous_pattern, content):
            if dangerous_pattern == r'\bpty\b':
                # Log a warning instead of blocking
                print(f"Warning: Script contains potentially dangerous code: {dangerous_pattern}")
            else:
                return False, f"Script contains potentially dangerous code: {dangerous_pattern}"
            
    # Parse the script to check imports more accurately
    try:
        tree = ast.parse(content)
        
        # Check for dangerous imports by looking at actual import statements
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for name in node.names:
                    if name.name in dangerous_imports:
                        return False, f"Script contains potentially dangerous import: {name.name}"
            elif isinstance(node, ast.ImportFrom):
                if node.module in dangerous_imports:
                    return False, f"Script contains potentially dangerous import: {node.module}"
                # Check 'from x import y' style imports
                for name in node.names:
                    full_import = f"{node.module}.{name.name}" if node.module else name.name
                    if full_import in dangerous_imports:
                        return False, f"Script contains potentially dangerous import: {full_import}"
        
        # Check for syntax validity
        compile(content, '<string>', 'exec')
        
        # Compile and execute to check for variables and run function
        namespace = {}
        exec(content, namespace)
        
        # Check for required elements in the arbitrary script format
        has_arbitrary_format = ('variables' in namespace and 
                                isinstance(namespace.get('variables'), list) and 
                                'run' in namespace and 
                                callable(namespace.get('run')))
        
        # Check for Job class structure
        has_job_class = False
        for node in ast.walk(tree):
            if isinstance(node, ast.ClassDef):
                for base in node.bases:
                    if isinstance(base, ast.Name) and base.id == 'Job':
                        has_job_class = True
                        break
        
        # Script is valid if it has either format
        if has_arbitrary_format or has_job_class:
            return True, "Script validation passed"
        else:
            return False, "Script must either contain a class that inherits from Job or have a 'variables' list and a 'run' function"
        
    except SyntaxError as e:
        return False, f"Script contains syntax errors: {str(e)}"
    except Exception as e:
        return False, f"Error validating script: {str(e)}"
