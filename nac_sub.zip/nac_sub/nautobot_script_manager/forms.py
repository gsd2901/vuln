from django import forms
from nautobot.core.forms import BootstrapMixin
from nautobot.core.forms import BulkEditForm, CSVModelForm
from .models import Script, ScriptCategory, ScriptSchedule

from django import forms
from nautobot.core.forms import BootstrapMixin
from .models import Script, ScriptCategory, ScriptSchedule
from .utils import validate_script_content

class ScriptUploadForm(BootstrapMixin, forms.ModelForm):
    script_file = forms.FileField(
        required=False, 
        help_text="Upload a Python script file",
        widget=forms.FileInput(attrs={'accept': '.py'})
    )
    
    class Meta:
        model = Script
        fields = ['name', 'description', 'category', 'source_type', 'script_content', 'git_url', 'git_branch', 'enabled']
        widgets = {
            'script_content': forms.HiddenInput(),
            'description': forms.Textarea(attrs={'rows': 3}),
        }
    
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        
        # For new instances, allow the name to be autofilled
        if not kwargs.get('instance'):
            self.fields['name'].required = False
            
        # If editing an existing script, make the name read-only
        instance = kwargs.get('instance')
        if instance and instance.pk:
            self.fields['name'].widget.attrs['readonly'] = True
            if instance.source_type == 'upload':
                self.fields['script_file'].help_text += " (Leave empty to keep the current script)"
    
    def clean_name(self):
        """Custom validation for the name field"""
        # If name is provided, return it
        name = self.cleaned_data.get('name')
        if name:
            return name
            
        # Otherwise, check if we're processing a file upload
        # Note: We'll extract the name from the file in the main clean method
        # This prevents the 'required' validation from triggering
        if self.files.get('script_file'):
            # Return a temporary placeholder - we'll replace it in clean()
            return "_pending_extraction_"
            
        # If no name and no file, let the standard validation apply
        return name

    def clean(self):
        cleaned_data = super().clean()
        source_type = cleaned_data.get('source_type')
        
        if source_type == 'upload':
            script_file = self.files.get('script_file')
            
            if not self.instance.pk or script_file:
                if not script_file:
                    self.add_error('script_file', "File upload is required when source type is 'File Upload'")
                else:
                    try:
                        script_content = script_file.read().decode('utf-8')
                        # Reset file pointer for later use if needed
                        script_file.seek(0)
                        
                        cleaned_data['script_content'] = script_content
                        
                        # Extract name from script content
                        extracted_name = self.extract_script_name(script_content, script_file.name)
                        if extracted_name:
                            # Replace the placeholder or empty name
                            cleaned_data['name'] = extracted_name
                            
                            # Try to update the form data as well for display purposes
                            if hasattr(self, 'data') and not getattr(self.data, '_mutable', False):
                                self.data = self.data.copy()
                                self.data['name'] = extracted_name
                        
                        # Debug information
                        print(f"Extracted script name: {extracted_name}")
                        print(f"Final name value: {cleaned_data.get('name')}")
                        
                        # Validate script for security
                        is_valid, message = validate_script_content(script_content)
                        if not is_valid:
                            self.add_error('script_file', message)
                    except Exception as e:
                        self.add_error('script_file', f"Error reading script file: {str(e)}")
        
        elif source_type == 'git':
            if not cleaned_data.get('git_url'):
                self.add_error('git_url', "Git URL is required when source type is 'Git Repository'")
        
        return cleaned_data

    def extract_script_name(self, content, filename):
        """Extract a name from script content or fallback to filename"""
        try:
            # First try to execute the script to get the 'name' variable
            namespace = {}
            exec(content, namespace)
            
            # Check for name in the arbitrary script format
            if 'name' in namespace and isinstance(namespace['name'], str):
                return namespace['name']
            
            # Check for Job class with Meta.name
            for name, obj in namespace.items():
                if isinstance(obj, type) and hasattr(obj, 'Meta') and hasattr(obj.Meta, 'name'):
                    return obj.Meta.name
            
            # Fallback to using the filename without extension
            if filename.endswith('.py'):
                name = filename[:-3]  # Remove .py extension
            else:
                name = filename
                
            # Format the name nicely
            return name.replace('_', ' ').title()
        except Exception:
            # If all else fails, use the filename
            if filename.endswith('.py'):
                name = filename[:-3]
            else:
                name = filename
            return name.replace('_', ' ').title()

class ScriptBulkEditForm(BootstrapMixin, BulkEditForm):
    pk = forms.ModelMultipleChoiceField(
        queryset=Script.objects.all(),
        widget=forms.MultipleHiddenInput
    )
    enabled = forms.NullBooleanField(
        required=False,
        widget=forms.Select(choices=(
            ('', '---------'),
            ('true', 'Yes'),
            ('false', 'No'),
        ))
    )
    description = forms.CharField(
        required=False,
        max_length=200
    )

    class Meta:
        nullable_fields = ['description']

class ScriptCategoryForm(BootstrapMixin, forms.ModelForm):
    class Meta:
        model = ScriptCategory
        fields = ['name', 'description']
        widgets = {
            'description': forms.Textarea(attrs={'rows': 3}),
        }
        
class ScriptScheduleForm(BootstrapMixin, forms.ModelForm):
    class Meta:
        model = ScriptSchedule
        fields = ['name', 'script', 'description', 'crontab', 'parameters', 'enabled']
        widgets = {
            'parameters': forms.Textarea(attrs={'rows': 3}),
            'description': forms.Textarea(attrs={'rows': 3}),
        }
        
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['script'].queryset = Script.objects.filter(enabled=True)