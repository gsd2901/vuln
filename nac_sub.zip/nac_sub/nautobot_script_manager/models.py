from django.db import models
from django.urls import reverse
from nautobot.core.models.generics import PrimaryModel
from nautobot.extras.utils import extras_features
from nautobot.extras.models import JobResult


class ScriptCategory(PrimaryModel):
    is_saved_view_model = False

    name = models.CharField(max_length=100, unique=True)
    description = models.TextField(blank=True)
    
    class Meta:
        ordering = ['name']
        verbose_name = "Script Category"
        verbose_name_plural = "Script Categories"
    
    def __str__(self):
        return self.name
    
    def get_absolute_url(self):
        return reverse('plugins:nautobot_script_manager:script_category', args=[self.pk])

@extras_features('custom_fields', 'custom_links', 'export_templates', 'webhooks')
class Script(PrimaryModel):
    is_saved_view_model = False
    
    name = models.CharField(max_length=100, unique=True)
    description = models.TextField(blank=True)
    source_type = models.CharField(
        max_length=10,
        choices=(('upload', 'File Upload'), ('git', 'Git Repository')),
    )
    script_content = models.TextField(blank=True)
    git_url = models.URLField(blank=True)
    git_branch = models.CharField(max_length=100, blank=True, default='main')
    enabled = models.BooleanField(default=True)
    category = models.ForeignKey(
        to=ScriptCategory,
        on_delete=models.SET_NULL,
        related_name='scripts',
        blank=True,
        null=True
    )
    
    class Meta:
        ordering = ['name']
        verbose_name = "Script"
        verbose_name_plural = "Scripts"
        permissions = [
            ('run_script', 'Can run scripts'),
        ]
        
    def __str__(self):
        return self.name
    
    def get_absolute_url(self):
        return reverse('plugins:nautobot_script_manager:script', args=[self.pk])
    
    def get_job_results(self):
        """Return JobResult objects for this script"""
        return JobResult.objects.filter(
            obj_type__app_label='nautobot_script_manager',
            obj_type__model='script',
            name=self.name
        ).order_by('-created')
    
class ScriptSchedule(PrimaryModel):
    is_saved_view_model = False
    
    script = models.ForeignKey(
        to=Script, 
        on_delete=models.CASCADE,
        related_name='schedules'
    )
    name = models.CharField(max_length=100)
    description = models.TextField(blank=True)
    enabled = models.BooleanField(default=True)
    
    # Schedule fields
    crontab = models.CharField(
        max_length=100,
        help_text="Crontab-style schedule (e.g. '0 0 * * *' for daily at midnight)"
    )
    parameters = models.JSONField(
        blank=True, 
        null=True,
        help_text="Parameters to pass to the script"
    )
    
    class Meta:
        ordering = ['name']
        verbose_name = "Script Schedule"
        verbose_name_plural = "Script Schedules"
    
    def __str__(self):
        return self.name