/**
 * Device Console JavaScript
 * Handles console session management, command execution, and UI interactions
 */

class DeviceConsole {
    constructor() {
        this.sessions = new Map(); // sessionId -> session data
        this.currentSession = null;
        this.commandHistory = []; // Array for current session command history
        this.historyIndex = 0; // Current history index
        this.isConnected = false;
        this.autoScroll = true;
        this.sessionCounter = 0;
        this.initialized = false; // Flag to prevent multiple initializations
        this.modalEventsInitialized = false; // Flag to prevent duplicate modal event listeners
        this.sessionTerminalOutputs = new Map(); // sessionId -> terminal output HTML
        this.sessionCommandHistories = new Map(); // sessionId -> command history array
    }

    async init() {
        // Prevent multiple initializations
        if (this.initialized) {
            console.log('DeviceConsole already initialized, skipping...');
            return;
        }
        
        this.initialized = true;
        
        // Initialize UI state first to prevent flashing
        this.updateUI();
        
        this.bindEvents();
        this.initModalEvents();
        this.loadDevices();
        await this.loadSessions();
        
        // Update UI again after sessions are loaded
        this.updateUI();
    }

    bindEvents() {
        // Device selection
        const deviceSelect = document.getElementById('deviceSelect');
        if (deviceSelect) {
            deviceSelect.addEventListener('change', (e) => this.onDeviceSelect(e));
        }

        // Device refresh
        const refreshBtn = document.getElementById('refreshDevices');
        if (refreshBtn) {
            refreshBtn.addEventListener('click', () => this.loadDevices());
        }

        // Connection controls
        const connectBtn = document.getElementById('connectBtn');
        const connectDeviceBtn = document.getElementById('connectDeviceBtn');
        const disconnectBtn = document.getElementById('disconnectBtn');
        
        if (connectBtn) {
            connectBtn.addEventListener('click', () => this.connect());
        }
        
        if (connectDeviceBtn) {
            connectDeviceBtn.addEventListener('click', () => this.showDeviceConnectionModal());
        }
        
        if (disconnectBtn) {
            disconnectBtn.addEventListener('click', () => this.disconnect());
        }

        // Command input
        const commandInput = document.getElementById('commandInput');
        if (commandInput) {
            commandInput.addEventListener('keydown', (e) => this.onCommandKeyDown(e));
            commandInput.addEventListener('keypress', (e) => this.onCommandKeyPress(e));
        }

        // Clear button
        const clearBtn = document.getElementById('clearBtn');
        if (clearBtn) {
            clearBtn.addEventListener('click', () => this.clearTerminal());
        }

        // Fullscreen button
        const fullscreenBtn = document.getElementById('fullscreenBtn');
        if (fullscreenBtn) {
            fullscreenBtn.addEventListener('click', () => this.toggleFullscreen());
        }

        // Session management
        const sessionModal = document.getElementById('sessionModal');
        if (sessionModal) {
            sessionModal.addEventListener('show.bs.modal', () => this.loadSessions());
        }

        // View sessions button
        const viewSessionsBtn = document.getElementById('viewSessionsBtn');
        if (viewSessionsBtn) {
            viewSessionsBtn.addEventListener('click', () => this.showSessions());
        }

        // Connection type change
        const connectionType = document.getElementById('connectionType');
        if (connectionType) {
            connectionType.addEventListener('change', (e) => this.onConnectionTypeChange(e));
        }

        // Port validation
        const port = document.getElementById('port');
        if (port) {
            port.addEventListener('input', () => this.validateForm());
            port.addEventListener('blur', () => this.validateForm());
        }

        // New feature buttons
        const templatesBtn = document.getElementById('templatesBtn');
        if (templatesBtn) {
            templatesBtn.addEventListener('click', () => this.showTemplates());
        }

        // Connect to device button in no sessions message
        const connectToDeviceBtn = document.querySelector('#noSessionsMessage button');
        if (connectToDeviceBtn) {
            connectToDeviceBtn.addEventListener('click', () => this.focusDeviceSelect());
        }

        const compareBtn = document.getElementById('compareBtn');
        if (compareBtn) {
            compareBtn.addEventListener('click', () => this.showComparison());
        }

        const multiSessionBtn = document.getElementById('multiSessionBtn');
        if (multiSessionBtn) {
            multiSessionBtn.addEventListener('click', () => this.toggleMultiSession());
        }

        // Connection cleanup buttons
        const cleanupBtn = document.getElementById('cleanupConnectionsBtn');
        if (cleanupBtn) {
            cleanupBtn.addEventListener('click', () => this.cleanupConnections());
        }

        const forceCleanupBtn = document.getElementById('forceCleanupConnectionsBtn');
        if (forceCleanupBtn) {
            forceCleanupBtn.addEventListener('click', () => this.forceCleanupConnections());
        }

        // Session dropdown
        const sessionDropdown = document.getElementById('sessionDropdown');
        if (sessionDropdown) {
            sessionDropdown.addEventListener('change', (e) => this.onSessionDropdownChange(e));
        }

        // Template management
        const createTemplateBtn = document.getElementById('createTemplateBtn');
        if (createTemplateBtn) {
            createTemplateBtn.addEventListener('click', () => this.showCreateTemplate());
        }

        const saveTemplateBtn = document.getElementById('saveTemplateBtn');
        if (saveTemplateBtn) {
            saveTemplateBtn.addEventListener('click', () => this.saveTemplate());
        }

        const runComparisonBtn = document.getElementById('runComparisonBtn');
        if (runComparisonBtn) {
            runComparisonBtn.addEventListener('click', () => this.runComparison());
        }
    }

    onDeviceSelect(event) {
        const deviceId = event.target.value;
        const connectBtn = document.getElementById('connectBtn');
        
        if (connectBtn) {
            connectBtn.disabled = !deviceId;
        }
        
        if (deviceId) {
            this.updateDeviceInfo(deviceId);
            this.validateForm();
        } else {
            this.hideDeviceInfo();
        }
    }

    validateForm() {
        const deviceSelect = document.getElementById('deviceSelect');
        const port = document.getElementById('port');
        const connectBtn = document.getElementById('connectBtn');
        
        const isDeviceSelected = deviceSelect && deviceSelect.value;
        const isPortValid = port && port.value && parseInt(port.value) > 0 && parseInt(port.value) <= 65535;
        
        if (connectBtn) {
            connectBtn.disabled = !(isDeviceSelected && isPortValid);
        }
        
        // Add visual feedback for validation
        if (port) {
            if (isPortValid) {
                port.classList.remove('error');
                port.classList.add('valid');
            } else if (port.value) {
                port.classList.remove('valid');
                port.classList.add('error');
            } else {
                port.classList.remove('error', 'valid');
            }
        }
    }

    onConnectionTypeChange(event) {
        const port = document.getElementById('port');
        if (port) {
            port.value = event.target.value === 'ssh' ? '22' : '23';
        }
    }

    updateDeviceInfo(deviceId) {
        // Get device information from the selected option
        const deviceSelect = document.getElementById('deviceSelect');
        const selectedOption = deviceSelect.options[deviceSelect.selectedIndex];
        
        const deviceInfo = {
            id: deviceId,
            name: selectedOption.text,
            ip: selectedOption.dataset.ip,
            platform: selectedOption.dataset.platform,
            status: selectedOption.dataset.status
        };
        
        this.showDeviceInfo(deviceInfo);
        this.updateStatus(`Selected device: ${deviceInfo.name} (${deviceInfo.ip})`, 'info');
    }

    showDeviceInfo(deviceInfo) {
        const deviceInfoDiv = document.getElementById('deviceDetails');
        const deviceIp = document.getElementById('deviceIp');
        const devicePlatform = document.getElementById('devicePlatform');
        const deviceStatus = document.getElementById('deviceStatus');

        if (deviceInfoDiv && deviceIp && devicePlatform && deviceStatus) {
            deviceIp.textContent = deviceInfo.ip || 'No IP';
            devicePlatform.textContent = deviceInfo.platform || 'Unknown';
            deviceStatus.textContent = deviceInfo.status || 'Unknown';
            deviceInfoDiv.style.display = 'block';
        }
        
        // Also update the detailed device info panel
        this.updateDeviceInfoDisplay(deviceInfo);
    }

    updateDeviceInfoDisplay(deviceInfo) {
        const currentDevice = document.getElementById('currentDevice');
        const currentIp = document.getElementById('currentIp');
        const currentSession = document.getElementById('currentSession');
        const statusDetails = document.getElementById('statusDetails');
        
        if (currentDevice) currentDevice.textContent = deviceInfo.name;
        if (currentIp) currentIp.textContent = deviceInfo.ip || 'No IP';
        if (currentSession) currentSession.textContent = 'Not connected';
        if (statusDetails) statusDetails.style.display = 'block';
    }

    updateConnectedDeviceInfo(sessionData) {
        const currentDevice = document.getElementById('currentDevice');
        const currentIp = document.getElementById('currentIp');
        const currentSession = document.getElementById('currentSession');
        const statusDetails = document.getElementById('statusDetails');
        const statusActions = document.getElementById('statusActions');
        
        if (currentDevice) currentDevice.textContent = sessionData.device_name;
        if (currentIp) currentIp.textContent = sessionData.device_ip || 'No IP';
        if (currentSession) currentSession.textContent = sessionData.session_id;
        if (statusDetails) statusDetails.style.display = 'block';
        if (statusActions) statusActions.style.display = 'block';
    }

    hideDeviceInfo() {
        const deviceInfoDiv = document.getElementById('deviceDetails');
        if (deviceInfoDiv) {
            deviceInfoDiv.style.display = 'none';
        }
    }

    async loadDevices() {
        try {
            const response = await fetch('/plugins/device-console/api/devices/');
            const data = await response.json();
            
            if (data.success) {
                this.populateDeviceSelect(data.devices);
                this.updateStatus('Devices loaded successfully', 'success');
            } else {
                this.updateStatus('Failed to load devices: ' + data.error, 'error');
            }
        } catch (error) {
            console.error('Error loading devices:', error);
            this.updateStatus('Failed to load devices', 'error');
        }
    }

    populateDeviceSelect(devices) {
        const deviceSelect = document.getElementById('deviceSelect');
        const currentValue = deviceSelect.value;
        
        // Clear existing options except the first one
        deviceSelect.innerHTML = '<option value="">Choose a device...</option>';
        
        devices.forEach(device => {
            const option = document.createElement('option');
            option.value = device.id;
            option.dataset.ip = device.ip || '';
            option.dataset.platform = device.platform || '';
            option.dataset.status = device.status || '';
            option.textContent = `${device.name}${device.ip ? ` (${device.ip})` : ''}`;
            deviceSelect.appendChild(option);
        });
        
        // Restore selection if it still exists
        if (currentValue) {
            deviceSelect.value = currentValue;
        }
    }

    showSessions() {
        // Open session list modal
        this.loadSessions();
        this.showModal('sessionModal');
    }

    async connect() {
        const deviceId = document.getElementById('deviceSelect').value;
        const connectionType = document.getElementById('connectionType').value;
        const port = document.getElementById('port').value;
        const secretsGroup = document.getElementById('secretsGroup').value;
        
        if (!deviceId) {
            this.updateStatus('Please select a device first', 'error');
            return;
        }

        try {
            this.updateStatus('Starting session...', 'info');
            this.setConnectionState('connecting');

            // Start new session
            const sessionData = await this.startSession({
                device_id: deviceId,
                connection_type: connectionType,
                port: parseInt(port),
                secrets_group_id: secretsGroup || null
            });

            if (sessionData.success) {
                this.currentSession = sessionData.session_id;
                this.updateStatus('Connecting to device...', 'info');
                
                // Connect to device
                const connectResult = await this.connectSession(this.currentSession);
                
                if (connectResult.success) {
                    // Sanitize and store session data
                    const sanitizedSession = this.sanitizeSessionData({
                        ...sessionData,
                        status: 'connected'
                    }, sessionData.session_id);
                    
                    if (sanitizedSession) {
                        this.sessions.set(sessionData.session_id, sanitizedSession);
                        
                        // Update connection state
                        this.isConnected = true;
                        this.setConnectionState('connected');
                        this.updateStatus(connectResult.message || `Connected to ${sessionData.device_name}`, 'success');
                        this.enableCommandInput();
                        
                        // Update device info display with session details
                        this.updateConnectedDeviceInfo(sanitizedSession);
                        
                        // Update UI state
                        this.updateNoSessionsMessage();
                        this.updateSessionTabs();
                        
                        // Update session dropdown
                        this.updateSessionDropdown();
                        
                        // Close the device connection modal
                        this.closeModal('deviceConnectionModal');
                        
                        // Initialize session-specific terminal output
                        this.initializeSessionTerminal(sessionData.session_id);
                        
                        // Update terminal prompt for the new session
                        this.updateTerminalPrompt(sanitizedSession);
                    } else {
                        throw new Error('Invalid session data received from server');
                    }
                } else {
                    this.displayConnectionError(connectResult);
                    throw new Error(connectResult.error || 'Connection failed');
                }
            } else {
                throw new Error(sessionData.error || 'Failed to start session');
            }
        } catch (error) {
            console.error('Connection error:', error);
            this.updateStatus(`Connection failed: ${error.message}`, 'error');
            this.setConnectionState('disconnected');
        }
    }

    async disconnect() {
        if (!this.currentSession) {
            return;
        }

        try {
            this.updateStatus('Disconnecting...', 'info');
            
            const result = await this.disconnectSession(this.currentSession);
            
            if (result.success) {
                // Update session state to disconnected instead of removing
                if (this.currentSession) {
                    this.updateSessionState(this.currentSession, 'disconnected');
                }
                
                // Clear current session
                this.currentSession = null;
                this.isConnected = false;
                this.setConnectionState('disconnected');
                this.updateStatus('Disconnected', 'success');
                this.disableCommandInput();
                
                // Clear command history for current session
                if (this.currentSession) {
                    this.sessionCommandHistories.set(this.currentSession, []);
                    // Save the current terminal state before clearing
                    this.saveCurrentSessionTerminalOutput();
                }
                this.commandHistory = [];
                this.historyIndex = 0;
                
                // Update UI state
                this.updateNoSessionsMessage();
                this.updateSessionTabs();
                
                // Update session dropdown
                this.updateSessionDropdown();
            } else {
                throw new Error(result.error || 'Disconnect failed');
            }
        } catch (error) {
            console.error('Disconnect error:', error);
            this.updateStatus(`Disconnect failed: ${error.message}`, 'error');
        }
    }

    async executeCommand(command) {
        if (!this.currentSession || !this.isConnected) {
            this.updateStatus('Not connected to any device', 'error');
            return;
        }

        if (!command.trim()) {
            return;
        }

        try {
            // Add command prompt
            this.addTerminalOutput(`<span class="terminal-prompt">${this.getDevicePrompt()}</span><span class="terminal-command">${command}</span>`);
            
            const result = await this.sendCommand(this.currentSession, command);
            
            if (result.success) {
                // Add output with proper formatting
                this.addTerminalOutput(result.output);
                this.addToHistory(command);
            } else {
                this.addTerminalOutput(`Error: ${result.error}`, 'error');
            }
        } catch (error) {
            console.error('Command execution error:', error);
            this.addTerminalOutput(`Error: ${error.message}`, 'error');
        }
    }

    getDevicePrompt() {
        // Return a device-specific prompt based on current session
        if (this.currentSession) {
            const session = this.sessions.get(this.currentSession);
            if (session && session.device_name) {
                return `${session.device_name}@console:~$`;
            }
            return `device@console:~$`;
        }
        return `console@nautobot:~$`;
    }

    updateTerminalPrompt(session) {
        const terminalPrompt = document.getElementById('terminalPrompt');
        if (terminalPrompt && session) {
            const prompt = session.device_name ? `${session.device_name}@console:~$` : 'device@console:~$';
            terminalPrompt.textContent = prompt;
        }
    }

    onCommandKeyDown(event) {
        switch (event.key) {
            case 'ArrowUp':
                event.preventDefault();
                this.navigateHistory(-1);
                break;
            case 'ArrowDown':
                event.preventDefault();
                this.navigateHistory(1);
                break;
            case 'Tab':
                event.preventDefault();
                // TODO: Implement command completion
                break;
        }
    }

    onCommandKeyPress(event) {
        if (event.key === 'Enter') {
            event.preventDefault();
            const command = event.target.value.trim();
            if (command) {
                this.executeCommand(command);
                event.target.value = '';
            }
        }
    }

    navigateHistory(direction) {
        if (!this.currentSession) return;
        
        // Get session-specific command history
        const sessionHistory = this.sessionCommandHistories.get(this.currentSession) || [];
        
        if (sessionHistory.length === 0) {
            return;
        }

        this.historyIndex += direction;
        
        if (this.historyIndex < 0) {
            this.historyIndex = 0;
        } else if (this.historyIndex >= sessionHistory.length) {
            this.historyIndex = sessionHistory.length;
        }

        const commandInput = document.getElementById('commandInput');
        if (commandInput) {
            commandInput.value = sessionHistory[this.historyIndex] || '';
        }
    }

    addToHistory(command) {
        if (!this.currentSession) return;
        
        // Get session-specific command history
        let sessionHistory = this.sessionCommandHistories.get(this.currentSession) || [];
        
        if (command && command !== sessionHistory[sessionHistory.length - 1]) {
            sessionHistory.push(command);
            if (sessionHistory.length > 1000) { // Max history from config
                sessionHistory.shift();
            }
            // Update session-specific history
            this.sessionCommandHistories.set(this.currentSession, sessionHistory);
        }
        
        // Update global history for backward compatibility
        this.commandHistory = sessionHistory;
        this.historyIndex = this.commandHistory.length;
    }

    addTerminalOutput(text, type = 'normal') {
        const output = document.getElementById('terminalOutput');
        if (!output) return;

        // Handle HTML content (like command prompts)
        if (text.includes('<span')) {
            const lineDiv = document.createElement('div');
            lineDiv.className = 'terminal-line';
            lineDiv.innerHTML = text;
            output.appendChild(lineDiv);
        } else {
            // Split text into lines for better formatting
            const lines = text.split('\n');
            
            lines.forEach((line, index) => {
                const lineDiv = document.createElement('div');
                lineDiv.className = 'terminal-line';
                
                // Preserve whitespace and formatting
                const formattedLine = line.replace(/ /g, '&nbsp;').replace(/\t/g, '&nbsp;&nbsp;&nbsp;&nbsp;');
                
                if (type === 'error') {
                    lineDiv.innerHTML = `<span class="terminal-text error-message">${formattedLine}</span>`;
                } else if (type === 'success') {
                    lineDiv.innerHTML = `<span class="terminal-text success-message">${formattedLine}</span>`;
                } else {
                    lineDiv.innerHTML = `<span class="terminal-text">${formattedLine}</span>`;
                }
                
                output.appendChild(lineDiv);
            });
        }
        
        // Store the output for the current session
        if (this.currentSession) {
            this.saveSessionTerminalOutput(this.currentSession, output.innerHTML);
        }
        
        if (this.autoScroll) {
            output.scrollTop = output.scrollHeight;
        }
    }

    initializeSessionTerminal(sessionId) {
        // Initialize empty terminal output for new session
        this.sessionTerminalOutputs.set(sessionId, '');
        this.sessionCommandHistories.set(sessionId, []);
        
        // Clear current terminal and show welcome message
        this.clearTerminalForSession(sessionId);
        
        // Update terminal prompt for the new session
        const session = this.sessions.get(sessionId);
        if (session) {
            this.updateTerminalPrompt(session);
        }
    }

    saveSessionTerminalOutput(sessionId, outputHtml) {
        this.sessionTerminalOutputs.set(sessionId, outputHtml);
    }

    saveCurrentSessionTerminalOutput() {
        if (this.currentSession) {
            const output = document.getElementById('terminalOutput');
            if (output) {
                this.saveSessionTerminalOutput(this.currentSession, output.innerHTML);
            }
        }
    }

    loadSessionTerminalOutput(sessionId) {
        const output = document.getElementById('terminalOutput');
        if (!output) return;

        const savedOutput = this.sessionTerminalOutputs.get(sessionId);
        if (savedOutput) {
            output.innerHTML = savedOutput;
        } else {
            // Initialize with welcome message if no saved output
            this.clearTerminalForSession(sessionId);
        }
        
        if (this.autoScroll) {
            output.scrollTop = output.scrollHeight;
        }
    }

    clearTerminalForSession(sessionId) {
        const output = document.getElementById('terminalOutput');
        if (!output) return;

        const session = this.sessions.get(sessionId);
        const deviceName = session ? session.device_name : 'Unknown Device';
        
        output.innerHTML = `
            <div class="terminal-line welcome-message">
                <span class="terminal-prompt">console@nautobot:~$</span>
                <span class="terminal-text">Welcome to Nautobot Device Console</span>
            </div>
            <div class="terminal-line">
                <span class="terminal-prompt">console@nautobot:~$</span>
                <span class="terminal-text">Connected to ${deviceName}</span>
            </div>
        `;
        
        this.saveSessionTerminalOutput(sessionId, output.innerHTML);
    }

    loadSessionCommandHistory(sessionId) {
        if (!sessionId) return;
        
        // Get session-specific command history
        const sessionHistory = this.sessionCommandHistories.get(sessionId) || [];
        
        // Update global history for backward compatibility
        this.commandHistory = sessionHistory;
        this.historyIndex = this.commandHistory.length;
        
        console.log(`Loaded command history for session ${sessionId}: ${sessionHistory.length} commands`);
    }

    async loadSessionCommandHistoryFromServer(sessionId) {
        if (!sessionId) return;
        
        try {
            // This would be a new API endpoint to get command history for a session
            // For now, we'll use the existing command logs endpoint
            const response = await fetch(`/plugins/device-console/api/sessions/${sessionId}/command-logs/`);
            if (response.ok) {
                const data = await response.json();
                if (data.success && data.commands) {
                    // Extract commands from command logs
                    const commands = data.commands.map(log => log.command).filter(cmd => cmd && cmd.trim());
                    this.sessionCommandHistories.set(sessionId, commands);
                    console.log(`Loaded ${commands.length} commands from server for session ${sessionId}`);
                }
            }
        } catch (error) {
            console.warn(`Failed to load command history from server for session ${sessionId}:`, error);
        }
    }

    clearTerminal() {
        const output = document.getElementById('terminalOutput');
        if (output) {
            const session = this.currentSession ? this.sessions.get(this.currentSession) : null;
            const deviceName = session ? session.device_name : 'Unknown Device';
            const prompt = session ? `${deviceName}@console:~$` : 'console@nautobot:~$';
            
            output.innerHTML = `<div class="terminal-line"><span class="terminal-prompt">${prompt}</span><span class="terminal-text">Terminal cleared.</span></div>`;
            
            // Save cleared terminal for current session
            if (this.currentSession) {
                this.saveSessionTerminalOutput(this.currentSession, output.innerHTML);
            }
        }
    }

    updateStatus(message, type) {
        const statusDiv = document.getElementById('consoleStatus');
        
        if (statusDiv) {
            const statusText = statusDiv.querySelector('span');
            if (statusText) {
                statusText.textContent = message;
            }
            
            // Remove any existing loading class first
            statusDiv.classList.remove('loading');
            
            // Update icon based on status
            const icon = statusDiv.querySelector('i');
            if (icon) {
                switch (type) {
                    case 'success':
                    case 'connected':
                        icon.className = 'fas fa-circle';
                        statusDiv.className = 'status success';
                        break;
                    case 'warning':
                        icon.className = 'fas fa-circle';
                        statusDiv.className = 'status warning';
                        break;
                    case 'connecting':
                    case 'info':
                        icon.className = 'fas fa-circle';
                        statusDiv.className = 'status loading';
                        // Add loading class for spinning animation
                        statusDiv.classList.add('loading');
                        break;
                    case 'danger':
                    case 'error':
                        icon.className = 'fas fa-circle';
                        statusDiv.className = 'status error';
                        break;
                    default:
                        icon.className = 'fas fa-circle';
                        statusDiv.className = 'status';
                }
            }
        }
    }

    setConnectionState(state) {
        const connectBtn = document.getElementById('connectBtn');
        const disconnectBtn = document.getElementById('disconnectBtn');
        const commandInput = document.getElementById('commandInput');
        
        switch (state) {
            case 'connecting':
                if (connectBtn) connectBtn.disabled = true;
                if (disconnectBtn) disconnectBtn.disabled = true;
                if (commandInput) commandInput.disabled = true;
                break;
            case 'connected':
                if (connectBtn) connectBtn.disabled = true;
                if (disconnectBtn) disconnectBtn.disabled = false;
                if (commandInput) commandInput.disabled = false;
                break;
            case 'disconnected':
                if (connectBtn) connectBtn.disabled = false;
                if (disconnectBtn) disconnectBtn.disabled = true;
                if (commandInput) commandInput.disabled = true;
                break;
        }
    }

    enableCommandInput() {
        const commandInput = document.getElementById('commandInput');
        if (commandInput) {
            commandInput.disabled = false;
            commandInput.focus();
        }
    }

    disableCommandInput() {
        const commandInput = document.getElementById('commandInput');
        if (commandInput) {
            commandInput.disabled = true;
        }
    }

    async loadSessions() {
        try {
            const response = await fetch('/plugins/device-console/api/sessions/');
            const data = await response.json();
            
            if (data.success) {
                // Clear existing sessions
                this.sessions.clear();
                
                // Process and validate each session
                let validSessionsCount = 0;
                data.sessions.forEach(session => {
                    const sanitizedSession = this.sanitizeSessionData(session, session.session_id);
                    if (sanitizedSession) {
                        this.sessions.set(session.session_id, sanitizedSession);
                        validSessionsCount++;
                    } else {
                        console.warn(`Skipping invalid session data:`, session);
                    }
                });
                
                // Display sessions (use original data for display, but validated data for internal tracking)
                this.displaySessions(data.sessions);
                
                // Update UI state
                this.updateNoSessionsMessage();
                this.updateSessionTabs();
                
                console.log(`Loaded ${validSessionsCount} valid sessions out of ${data.sessions.length} total`);
            } else {
                console.error('Failed to load sessions:', data.error);
                this.updateStatus('Failed to load sessions: ' + data.error, 'error');
            }
        } catch (error) {
            console.error('Failed to load sessions:', error);
            this.updateStatus('Failed to load sessions', 'error');
        }
    }

    displaySessions(sessions) {
        const sessionList = document.getElementById('sessionList');
        if (!sessionList) return;

        if (sessions.length === 0) {
            sessionList.innerHTML = '<p style="color: var(--text-muted); text-align: center; padding: 20px;">No active sessions</p>';
            return;
        }

        const html = sessions.map(session => `
            <div class="session-item">
                <div class="session-info">
                    <h6>${session.device_name}</h6>
                    <small>${session.device_ip} - ${session.connection_type.toUpperCase()}</small>
                </div>
                <div class="session-actions">
                    <span class="badge bg-${this.getStatusColor(session.status)}">${session.status}</span>
                    <button class="btn secondary" onclick="deviceConsole.switchToSession('${session.session_id}')">
                        Switch
                    </button>
                </div>
            </div>
        `).join('');

        sessionList.innerHTML = html;
    }

    getStatusColor(status) {
        switch (status) {
            case 'connected': return 'success';
            case 'connecting': return 'warning';
            case 'pending': return 'info';
            case 'disconnected': return 'secondary';
            case 'failed': return 'danger';
            default: return 'secondary';
        }
    }



    // API Methods
    async startSession(data) {
        const response = await fetch('/plugins/device-console/api/sessions/start/', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRFToken': this.getCSRFToken()
            },
            body: JSON.stringify(data)
        });
        return await response.json();
    }

    async connectSession(sessionId) {
        const response = await fetch(`/plugins/device-console/api/sessions/${sessionId}/connect/`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRFToken': this.getCSRFToken()
            }
        });
        return await response.json();
    }

    async disconnectSession(sessionId) {
        const response = await fetch(`/plugins/device-console/api/sessions/${sessionId}/disconnect/`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRFToken': this.getCSRFToken()
            }
        });
        return await response.json();
    }

    async sendCommand(sessionId, command) {
        try {
            const response = await fetch(`/plugins/device-console/api/sessions/${sessionId}/execute/`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRFToken': this.getCSRFToken()
                },
                body: JSON.stringify({ command })
            });
            
            const result = await response.json();
            
            if (!response.ok) {
                // Handle HTTP error responses
                if (response.status === 400) {
                    // Bad request - show detailed error message
                    const errorMsg = result.details || result.error || 'Bad request';
                    const suggestions = result.suggestions || [];
                    let errorText = `Error: ${errorMsg}`;
                    if (suggestions.length > 0) {
                        errorText += '\n\nSuggestions:\n' + suggestions.map(s => `• ${s}`).join('\n');
                    }
                    return { success: false, error: errorText };
                } else if (response.status === 404) {
                    return { success: false, error: 'Session not found. Please reconnect to the device.' };
                } else if (response.status === 403) {
                    return { success: false, error: 'Permission denied. You do not have access to execute commands.' };
                } else {
                    return { success: false, error: result.error || `HTTP ${response.status}: ${response.statusText}` };
                }
            }
            
            return result;
        } catch (error) {
            console.error('Network error sending command:', error);
            return { success: false, error: `Network error: ${error.message}` };
        }
    }

    getCSRFToken() {
        const token = document.querySelector('[name=csrfmiddlewaretoken]');
        return token ? token.value : '';
    }

    updateUI() {
        // Update UI based on current state
        this.setConnectionState('disconnected');
        this.updateNoSessionsMessage();
    }

    updateNoSessionsMessage() {
        const noSessionsMessage = document.getElementById('noSessionsMessage');
        const consoleTerminal = document.getElementById('consoleTerminal');
        
        if (!noSessionsMessage || !consoleTerminal) {
            console.warn('Required DOM elements not found for updateNoSessionsMessage');
            return;
        }

        try {
            // Get current session state
            const currentSessionState = this.getCurrentSessionState();
            
            // Determine if we should show the no sessions message
            const shouldShowNoSessions = this.shouldShowNoSessionsMessage(currentSessionState);
            
            // Update UI elements with proper state management
            this.updateSessionUI(shouldShowNoSessions, currentSessionState);
            
        } catch (error) {
            console.error('Error in updateNoSessionsMessage:', error);
            // Fallback to safe state
            this.updateSessionUI(true, { hasConnectedSessions: false, isConnected: false });
        }
    }

    getCurrentSessionState() {
        // Validate sessions data structure
        if (!this.sessions || typeof this.sessions.size === 'undefined') {
            console.warn('Sessions Map is not properly initialized');
            return { hasConnectedSessions: false, isConnected: false, sessionCount: 0 };
        }

        // Count sessions by status
        const sessionStates = {
            connected: 0,
            connecting: 0,
            pending: 0,
            disconnected: 0,
            failed: 0,
            total: this.sessions.size
        };

        // Safely iterate through sessions
        try {
            this.sessions.forEach((session, sessionId) => {
                if (!session || typeof session.status !== 'string') {
                    console.warn(`Invalid session data for sessionId: ${sessionId}`);
                    return;
                }
                
                const status = session.status.toLowerCase();
                if (sessionStates.hasOwnProperty(status)) {
                    sessionStates[status]++;
                } else {
                    console.warn(`Unknown session status: ${status} for sessionId: ${sessionId}`);
                    sessionStates.disconnected++; // Default to disconnected
                }
            });
        } catch (error) {
            console.error('Error iterating through sessions:', error);
            return { hasConnectedSessions: false, isConnected: false, sessionCount: 0 };
        }

        return {
            hasConnectedSessions: sessionStates.connected > 0,
            isConnected: this.isConnected && this.currentSession && sessionStates.connected > 0,
            sessionCount: sessionStates.total,
            sessionStates: sessionStates
        };
    }

    shouldShowNoSessionsMessage(sessionState) {
        // Show no sessions message when:
        // 1. Not currently connected AND no connected sessions exist
        // 2. No sessions exist at all
        // 3. All sessions are in failed/disconnected state
        
        const { hasConnectedSessions, isConnected, sessionCount } = sessionState;
        
        // If no sessions exist at all, show the message
        if (sessionCount === 0) {
            return true;
        }
        
        // If not connected and no connected sessions, show the message
        if (!isConnected && !hasConnectedSessions) {
            return true;
        }
        
        // If we have sessions but none are connected, show the message
        if (sessionCount > 0 && !hasConnectedSessions) {
            return true;
        }
        
        return false;
    }

    updateSessionUI(shouldShowNoSessions, sessionState) {
        const noSessionsMessage = document.getElementById('noSessionsMessage');
        const consoleTerminal = document.getElementById('consoleTerminal');
        
        // Update no sessions message visibility
        if (noSessionsMessage) {
            noSessionsMessage.style.display = shouldShowNoSessions ? 'block' : 'none';
        }
        
        // Update console terminal visibility
        if (consoleTerminal) {
            consoleTerminal.style.display = shouldShowNoSessions ? 'none' : 'flex';
        }
        
        // Update terminal subtitle based on state
        this.updateTerminalSubtitle(sessionState);
    }

    updateTerminalSubtitle(sessionState) {
        const terminalSubtitle = document.getElementById('terminalSubtitle');
        if (!terminalSubtitle) return;
        
        const { isConnected, hasConnectedSessions, sessionCount } = sessionState;
        
        if (isConnected && this.currentSession) {
            const currentSession = this.sessions.get(this.currentSession);
            if (currentSession) {
                terminalSubtitle.textContent = `Connected to ${currentSession.device_name || 'Unknown Device'}`;
            } else {
                terminalSubtitle.textContent = 'Connected to device';
            }
        } else if (hasConnectedSessions) {
            terminalSubtitle.textContent = `${sessionState.sessionStates.connected} active session(s)`;
        } else if (sessionCount > 0) {
            terminalSubtitle.textContent = 'Sessions available - click to connect';
        } else {
            terminalSubtitle.textContent = 'Ready to connect';
        }
    }

    validateSessionData(session, sessionId) {
        if (!session) {
            console.warn(`Session data is null for sessionId: ${sessionId}`);
            return false;
        }

        if (typeof session !== 'object') {
            console.warn(`Session data is not an object for sessionId: ${sessionId}`);
            return false;
        }

        // Check required fields
        const requiredFields = ['session_id', 'device_name', 'status'];
        for (const field of requiredFields) {
            if (!(field in session)) {
                console.warn(`Missing required field '${field}' in session data for sessionId: ${sessionId}`);
                return false;
            }
        }

        // Validate status field
        const validStatuses = ['connected', 'connecting', 'disconnected', 'failed', 'pending'];
        if (!validStatuses.includes(session.status)) {
            console.warn(`Invalid status '${session.status}' for sessionId: ${sessionId}`);
            return false;
        }

        return true;
    }

    sanitizeSessionData(session, sessionId) {
        if (!this.validateSessionData(session, sessionId)) {
            return null;
        }

        // Return sanitized session data with defaults
        return {
            session_id: session.session_id || sessionId,
            device_name: session.device_name || 'Unknown Device',
            device_ip: session.device_ip || 'Unknown IP',
            status: session.status || 'disconnected',
            connection_type: session.connection_type || 'unknown',
            created_at: session.created_at || new Date().toISOString(),
            ...session // Include any additional fields
        };
    }

    updateSessionState(sessionId, newStatus) {
        if (!this.sessions.has(sessionId)) {
            console.warn(`Cannot update state for unknown session: ${sessionId}`);
            return false;
        }

        try {
            const session = this.sessions.get(sessionId);
            if (!session) {
                console.warn(`Session data is null for sessionId: ${sessionId}`);
                return false;
            }

            // Update session status
            session.status = newStatus;
            this.sessions.set(sessionId, session);

            // If this is the current session, update connection state
            if (this.currentSession === sessionId) {
                if (newStatus === 'connected') {
                    this.isConnected = true;
                    this.setConnectionState('connected');
                    this.enableCommandInput();
                } else {
                    this.isConnected = false;
                    this.setConnectionState('disconnected');
                    this.disableCommandInput();
                }
            }

            // Update UI
            this.updateSessionTabs();
            this.updateNoSessionsMessage();

            return true;
        } catch (error) {
            console.error(`Error updating session state for ${sessionId}:`, error);
            return false;
        }
    }

    updateSessionTabs() {
        // Session tabs functionality has been moved to terminal header dropdown
        // This method now updates the session dropdown
        try {
            // Get current session state for consistency
            const sessionState = this.getCurrentSessionState();
            
            // Update terminal subtitle to show session information
            this.updateTerminalSubtitle(sessionState);
            
            // Update session dropdown
            this.updateSessionDropdown();
            
        } catch (error) {
            console.error('Error updating session tabs:', error);
        }
    }

    updateSessionDropdown() {
        const sessionDropdown = document.getElementById('sessionDropdown');
        if (!sessionDropdown) return;

        // Clear existing options
        sessionDropdown.innerHTML = '';

        // Get connected sessions
        const connectedSessions = Array.from(this.sessions.values())
            .filter(session => session.status === 'connected');

        if (connectedSessions.length === 0) {
            // No active sessions
            const option = document.createElement('option');
            option.value = '';
            option.textContent = 'No active sessions';
            option.disabled = true;
            sessionDropdown.appendChild(option);
            sessionDropdown.disabled = true;
        } else {
            // Add sessions to dropdown
            connectedSessions.forEach(session => {
                const option = document.createElement('option');
                option.value = session.session_id;
                option.textContent = `${session.device_name} (${session.device_ip})`;
                if (this.currentSession === session.session_id) {
                    option.selected = true;
                }
                sessionDropdown.appendChild(option);
            });
            sessionDropdown.disabled = false;
        }
    }

    onSessionDropdownChange(event) {
        const selectedSessionId = event.target.value;
        
        if (!selectedSessionId) {
            return;
        }

        // Switch to the selected session
        this.switchToSession(selectedSessionId);
    }

    updateSessionDropdownSelection(sessionId) {
        const sessionDropdown = document.getElementById('sessionDropdown');
        if (!sessionDropdown) return;

        // Update the dropdown selection to match the current session
        sessionDropdown.value = sessionId || '';
    }


    switchToSession(sessionId) {
        if (!sessionId || !this.sessions.has(sessionId)) {
            console.warn(`Cannot switch to session: ${sessionId} - session not found`);
            this.updateStatus('Session not found', 'error');
            return;
        }

        try {
            const session = this.sessions.get(sessionId);
            
            // Validate session data
            if (!session || !session.device_name) {
                console.warn(`Invalid session data for sessionId: ${sessionId}`);
                this.updateStatus('Invalid session data', 'error');
                return;
            }

            // Save current session's terminal output before switching
            if (this.currentSession && this.currentSession !== sessionId) {
                this.saveCurrentSessionTerminalOutput();
            }

            // Update current session
            this.currentSession = sessionId;
            
            // Update connection state based on session status
            if (session.status === 'connected') {
                this.isConnected = true;
                this.setConnectionState('connected');
                this.enableCommandInput();
            } else {
                this.isConnected = false;
                this.setConnectionState('disconnected');
                this.disableCommandInput();
            }
            
            // Session switching is now handled through the terminal header
            // No visual tabs to update

            // Update device info
            this.updateConnectedDeviceInfo(session);
            
            // Load session-specific terminal output
            this.loadSessionTerminalOutput(sessionId);
            
            // Load session-specific command history
            this.loadSessionCommandHistory(sessionId);
            
            // Update terminal prompt for the new session
            this.updateTerminalPrompt(session);
            
            // Update UI state
            this.updateNoSessionsMessage();
            
            // Update status
            const statusMessage = session.status === 'connected' 
                ? `Switched to session: ${session.device_name}` 
                : `Switched to session: ${session.device_name} (${session.status})`;
            this.updateStatus(statusMessage, session.status === 'connected' ? 'success' : 'warning');
            
            // Update session dropdown selection
            this.updateSessionDropdownSelection(sessionId);
            
        } catch (error) {
            console.error('Error switching to session:', error);
            this.updateStatus('Failed to switch session', 'error');
        }
    }

    async closeSession(sessionId) {
        if (!sessionId || !this.sessions.has(sessionId)) {
            console.warn(`Cannot close session: ${sessionId} - session not found`);
            return;
        }

        try {
            const session = this.sessions.get(sessionId);
            const sessionName = session?.device_name || sessionId;
            
            // Disconnect the session if it's connected
            if (session?.status === 'connected') {
                const result = await this.disconnectSession(sessionId);
                
                if (!result.success) {
                    console.warn(`Failed to disconnect session ${sessionId}: ${result.error}`);
                    // Continue with cleanup even if disconnect fails
                }
            }
            
            // Remove from sessions map
            this.sessions.delete(sessionId);
            
            // Clean up session-specific data
            this.sessionTerminalOutputs.delete(sessionId);
            this.sessionCommandHistories.delete(sessionId);
            
            // If this was the current session, clear it and update state
            if (this.currentSession === sessionId) {
                this.currentSession = null;
                this.isConnected = false;
                this.setConnectionState('disconnected');
                this.disableCommandInput();
                
                // Clear command history for the closed session
                this.commandHistory = [];
                this.historyIndex = 0;
            }
            
            // Update UI state
            this.updateSessionTabs();
            this.updateNoSessionsMessage();
            
            // Update session dropdown
            this.updateSessionDropdown();
            
            // Update status with more informative message
            this.updateStatus(`Session closed: ${sessionName}`, 'info');
            
        } catch (error) {
            console.error('Error closing session:', error);
            this.updateStatus(`Error closing session: ${error.message}`, 'error');
        }
    }

    focusDeviceSelect() {
        const deviceSelect = document.getElementById('deviceSelect');
        if (deviceSelect) {
            deviceSelect.focus();
            // Also trigger the change event to ensure proper validation
            deviceSelect.dispatchEvent(new Event('change'));
        }
    }

    showDeviceConnectionModal() {
        this.showModal('deviceConnectionModal');
        // Focus on device select when modal opens
        setTimeout(() => {
            this.focusDeviceSelect();
        }, 100);
    }

    // New feature methods
    showTemplates() {
        this.loadTemplates();
        this.showModal('templatesModal');
    }

    async loadTemplates() {
        try {
            const response = await fetch('/plugins/device-console/api/templates/');
            const data = await response.json();
            
            if (data.success) {
                this.displayTemplates(data.templates);
            } else {
                this.updateStatus('Failed to load templates: ' + data.error, 'error');
            }
        } catch (error) {
            console.error('Error loading templates:', error);
            this.updateStatus('Failed to load templates', 'error');
        }
    }

    displayTemplates(templates) {
        const templatesList = document.getElementById('templatesList');
        if (!templatesList) return;

        if (templates.length === 0) {
            templatesList.innerHTML = '<p style="color: var(--text-muted); text-align: center; padding: 20px;">No templates found</p>';
            return;
        }

        const html = templates.map(template => `
            <div class="template-item">
                <div class="template-header">
                    <div>
                        <h6 class="template-title">${template.name}</h6>
                        <p class="template-description">${template.description || 'No description'}</p>
                        <code class="template-command">${template.command}</code>
                        <div class="template-meta">
                            <span>Platform: ${template.platform || 'Any'}</span>
                            <span>Created by: ${template.created_by || 'Unknown'}</span>
                            <span>${template.is_public ? 'Public' : 'Private'}</span>
                        </div>
                    </div>
                    <div>
                        <button class="btn primary" onclick="deviceConsole.executeTemplate('${template.id}')">
                            <i class="fas fa-play"></i> Execute
                        </button>
                    </div>
                </div>
            </div>
        `).join('');

        templatesList.innerHTML = html;
    }

    async executeTemplate(templateId) {
        if (!this.currentSession || !this.isConnected) {
            this.updateStatus('Not connected to any device', 'error');
            return;
        }

        try {
            this.addTerminalOutput(`[TEMPLATE] Executing template...`);
            
            const response = await fetch(`/plugins/device-console/api/sessions/${this.currentSession}/templates/${templateId}/execute/`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRFToken': this.getCSRFToken()
                }
            });
            
            const result = await response.json();
            
            if (result.success) {
                this.addTerminalOutput(result.output);
            } else {
                this.addTerminalOutput(`Error: ${result.output}`, 'error');
            }
        } catch (error) {
            console.error('Template execution error:', error);
            this.addTerminalOutput(`Error: ${error.message}`, 'error');
        }
    }

    showCreateTemplate() {
        this.loadPlatforms();
        this.showModal('createTemplateModal');
    }

    async loadPlatforms() {
        try {
            const response = await fetch('/plugins/device-console/api/platforms/');
            const data = await response.json();
            
            const platformSelect = document.getElementById('templatePlatform');
            if (platformSelect) {
                platformSelect.innerHTML = '<option value="">Any Platform</option>';
                
                if (data.success) {
                    data.platforms.forEach(platform => {
                        const option = document.createElement('option');
                        option.value = platform.id;
                        option.textContent = platform.name + (platform.manufacturer ? ` (${platform.manufacturer})` : '');
                        platformSelect.appendChild(option);
                    });
                }
            }
        } catch (error) {
            console.error('Error loading platforms:', error);
        }
    }

    async saveTemplate() {
        const name = document.getElementById('templateName').value.trim();
        const description = document.getElementById('templateDescription').value.trim();
        const command = document.getElementById('templateCommand').value.trim();
        const platformSelect = document.getElementById('templatePlatform');
        const platformName = platformSelect.options[platformSelect.selectedIndex].text;
        const isPublic = document.getElementById('templatePublic').checked;

        if (!name || !command) {
            this.updateStatus('Name and command are required', 'error');
            return;
        }

        try {
            const response = await fetch('/plugins/device-console/api/templates/create/', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRFToken': this.getCSRFToken()
                },
                body: JSON.stringify({
                    name,
                    description,
                    command,
                    platform_name: platformName === 'Any Platform' ? '' : platformName,
                    is_public: isPublic
                })
            });

            const result = await response.json();

            if (result.success) {
                this.updateStatus('Template created successfully', 'success');
                this.closeModal('createTemplateModal');
                this.loadTemplates();
            } else {
                this.updateStatus('Failed to create template: ' + result.error, 'error');
            }
        } catch (error) {
            console.error('Error creating template:', error);
            this.updateStatus('Failed to create template', 'error');
        }
    }

    showComparison() {
        this.loadSessionsForComparison();
        this.showModal('compareModal');
    }

    async loadSessionsForComparison() {
        try {
            const response = await fetch('/plugins/device-console/api/sessions/');
            const data = await response.json();
            
            if (data.success) {
                const connectedSessions = data.sessions.filter(session => session.status === 'connected');
                this.populateComparisonSelects(connectedSessions);
            }
        } catch (error) {
            console.error('Error loading sessions for comparison:', error);
        }
    }

    populateComparisonSelects(sessions) {
        const select1 = document.getElementById('compareSession1');
        const select2 = document.getElementById('compareSession2');
        
        if (select1 && select2) {
            const options = sessions.map(session => 
                `<option value="${session.session_id}">${session.device_name} (${session.device_ip})</option>`
            ).join('');
            
            select1.innerHTML = '<option value="">Select session...</option>' + options;
            select2.innerHTML = '<option value="">Select session...</option>' + options;
        }
    }

    async runComparison() {
        const session1 = document.getElementById('compareSession1').value;
        const session2 = document.getElementById('compareSession2').value;
        const command = document.getElementById('compareCommand').value.trim();

        if (!session1 || !session2) {
            this.updateStatus('Please select both sessions for comparison', 'error');
            return;
        }

        if (session1 === session2) {
            this.updateStatus('Please select different sessions for comparison', 'error');
            return;
        }

        try {
            this.updateStatus('Running comparison...', 'info');
            
            const response = await fetch(`/plugins/device-console/api/config-comparison/?session_id1=${session1}&session_id2=${session2}&command=${encodeURIComponent(command)}`);
            const result = await response.json();
            
            if (result.success) {
                this.displayComparisonResult(result.comparison);
            } else {
                this.updateStatus('Comparison failed: ' + result.error, 'error');
            }
        } catch (error) {
            console.error('Comparison error:', error);
            this.updateStatus('Comparison failed', 'error');
        }
    }

    displayComparisonResult(comparison) {
        const resultDiv = document.getElementById('comparisonResult');
        if (!resultDiv) return;

        const html = `
            <div class="comparison-result">
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
                    <div class="comparison-device">
                        <h6>${comparison.device1.name} (${comparison.device1.ip})</h6>
                        <div class="comparison-output">
                            <pre>${comparison.device1.output}</pre>
                        </div>
                        <small style="color: var(--text-muted);">${comparison.device1.line_count} lines</small>
                    </div>
                    <div class="comparison-device">
                        <h6>${comparison.device2.name} (${comparison.device2.ip})</h6>
                        <div class="comparison-output">
                            <pre>${comparison.device2.output}</pre>
                        </div>
                        <small style="color: var(--text-muted);">${comparison.device2.line_count} lines</small>
                    </div>
                </div>
                <div style="margin-top: 20px;">
                    <div class="comparison-summary ${comparison.identical ? 'identical' : 'different'}">
                        <strong>Result:</strong> 
                        ${comparison.identical ? 'Configurations are identical' : `Configurations differ by ${comparison.line_differences} lines`}
                    </div>
                </div>
            </div>
        `;

        resultDiv.innerHTML = html;
        resultDiv.style.display = 'block';
    }

    toggleMultiSession() {
        // TODO: Implement multi-session layout toggle
        this.updateStatus('Multi-session feature coming soon', 'info');
    }

    async cleanupConnections() {
        try {
            this.updateStatus('Cleaning up stale connections...', 'info');
            
            const response = await fetch('/plugins/device-console/api/cleanup-connections/', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRFToken': this.getCSRFToken()
                }
            });
            
            const result = await response.json();
            
            if (result.success) {
                this.updateStatus(`Cleaned up ${result.cleaned_connections} stale connections`, 'success');
            } else {
                this.updateStatus('Failed to cleanup connections: ' + result.error, 'error');
            }
        } catch (error) {
            console.error('Cleanup error:', error);
            this.updateStatus('Failed to cleanup connections', 'error');
        }
    }

    async forceCleanupConnections() {
        if (!confirm('Are you sure you want to force cleanup ALL connections? This will disconnect all active sessions.')) {
            return;
        }

        try {
            this.updateStatus('Force cleaning up all connections...', 'warning');
            
            const response = await fetch('/plugins/device-console/api/force-cleanup-connections/', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRFToken': this.getCSRFToken()
                }
            });
            
            const result = await response.json();
            
            if (result.success) {
                this.updateStatus(`Force cleaned up ${result.cleaned_connections} connections`, 'success');
                // Clear all sessions from the Map
                this.sessions.clear();
                // Clear all session-specific data
                this.sessionTerminalOutputs.clear();
                this.sessionCommandHistories.clear();
                // Reset current session if it was cleaned up
                this.currentSession = null;
                this.isConnected = false;
                this.setConnectionState('disconnected');
                this.disableCommandInput();
                this.updateNoSessionsMessage();
            } else {
                this.updateStatus('Failed to force cleanup connections: ' + result.error, 'error');
            }
        } catch (error) {
            console.error('Force cleanup error:', error);
            this.updateStatus('Failed to force cleanup connections', 'error');
        }
    }

    toggleFullscreen() {
        const terminal = document.getElementById('consoleTerminal');
        const fullscreenBtn = document.getElementById('fullscreenBtn');
        
        if (terminal && fullscreenBtn) {
            if (terminal.classList.contains('fullscreen')) {
                terminal.classList.remove('fullscreen');
                fullscreenBtn.innerHTML = '<i class="fas fa-expand"></i> Fullscreen';
            } else {
                terminal.classList.add('fullscreen');
                fullscreenBtn.innerHTML = '<i class="fas fa-compress"></i> Exit Fullscreen';
            }
        }
    }

    displayConnectionError(errorData) {
        const statusDiv = document.getElementById('consoleStatus');
        
        if (statusDiv) {
            // Update the main status display
            const statusText = statusDiv.querySelector('span');
            if (statusText) {
                statusText.textContent = errorData.error || 'Connection failed';
            }
            
            // Update status indicator to show error
            statusDiv.className = 'status error';
            
            // Update icon to show error
            const icon = statusDiv.querySelector('i');
            if (icon) {
                icon.className = 'fas fa-exclamation-circle';
            }
            
            // Display detailed error information in the terminal
            let errorMessage = `Connection Error: ${errorData.details || errorData.error || 'Unknown error'}`;
            
            if (errorData.device_name) {
                errorMessage += `\nDevice: ${errorData.device_name}`;
            }
            
            if (errorData.suggestions && errorData.suggestions.length > 0) {
                errorMessage += `\nSuggestions:\n${errorData.suggestions.map(suggestion => `- ${suggestion}`).join('\n')}`;
            }
            
            this.addTerminalOutput(errorMessage, 'error');
        }
    }

    // Modal management methods
    showModal(modalId) {
        const modal = document.getElementById(modalId);
        if (modal) {
            modal.classList.add('show');
            modal.style.display = 'flex';
            document.body.style.overflow = 'hidden';
        }
    }

    closeModal(modalId) {
        const modal = document.getElementById(modalId);
        if (modal) {
            modal.classList.remove('show');
            modal.style.display = 'none';
            document.body.style.overflow = 'auto';
        }
    }

    // Close modal when clicking outside
    initModalEvents() {
        // Only add the event listener once
        if (!this.modalEventsInitialized) {
            document.addEventListener('click', (e) => {
                if (e.target.classList.contains('modal')) {
                    this.closeModal(e.target.id);
                }
            });
            this.modalEventsInitialized = true;
        }
    }
}

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    window.deviceConsole = new DeviceConsole();
    // Initialize after DOM is ready
    window.deviceConsole.init().catch(error => {
        console.error('Failed to initialize DeviceConsole:', error);
    });
});

// Export for global access
window.DeviceConsole = DeviceConsole;

// Make closeSession available globally for HTML onclick handlers
window.closeSession = function(sessionId) {
    if (window.deviceConsole) {
        window.deviceConsole.closeSession(sessionId);
    }
};
