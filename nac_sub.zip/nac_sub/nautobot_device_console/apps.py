from django.apps import AppConfig


class NautobotDeviceConsoleConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'nautobot_device_console'
    base_url = 'device-console'
