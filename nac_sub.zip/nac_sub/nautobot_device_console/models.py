from django.db import models
from django.core.validators import validate_ipv4_address
from nautobot.dcim.models import Device
from nautobot.extras.models import SecretsGroup
import uuid


class ConsoleSession(models.Model):
    """Track console sessions and store session information."""
    
    STATUS_CHOICES = [
        ('pending', 'Pending'),
        ('connecting', 'Connecting'),
        ('connected', 'Connected'),
        ('disconnected', 'Disconnected'),
        ('failed', 'Failed'),
        ('timeout', 'Timeout'),
    ]
    
    session_id = models.UUIDField(
        primary_key=True,
        default=uuid.uuid4,
        editable=False,
        help_text="Unique identifier for the console session"
    )
    
    device = models.ForeignKey(
        Device,
        on_delete=models.CASCADE,
        related_name='console_sessions',
        help_text="Device this session is connected to"
    )
    
    user = models.ForeignKey(
        'users.User',
        on_delete=models.CASCADE,
        related_name='console_sessions',
        help_text="User who initiated this session"
    )
    
    status = models.CharField(
        max_length=32,
        choices=STATUS_CHOICES,
        default='pending',
        help_text="Current status of the console session"
    )
    
    connection_type = models.CharField(
        max_length=32,
        default='ssh',
        choices=[
            ('ssh', 'SSH'),
            ('telnet', 'Telnet'),
            ('serial', 'Serial'),
        ],
        help_text="Type of connection used for this session"
    )
    
    secrets_group = models.ForeignKey(
        SecretsGroup,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        help_text="Secrets group used for device authentication"
    )
    
    custom_username = models.CharField(
        max_length=64,
        blank=True,
        null=True,
        help_text="Custom username for this session (overrides secrets group)"
    )
    
    custom_password = models.CharField(
        max_length=256,
        blank=True,
        null=True,
        help_text="Custom password for this session (overrides secrets group)"
    )
    
    port = models.PositiveIntegerField(
        default=22,
        help_text="Port number for the connection"
    )
    
    timeout = models.PositiveIntegerField(
        default=30,
        help_text="Connection timeout in seconds"
    )
    
    last_command = models.TextField(
        blank=True,
        null=True,
        help_text="Last command executed in this session"
    )
    
    command_count = models.PositiveIntegerField(
        default=0,
        help_text="Number of commands executed in this session"
    )
    
    session_data = models.JSONField(
        default=dict,
        blank=True,
        help_text="Additional session data and state"
    )
    
    error_message = models.TextField(
        blank=True,
        null=True,
        help_text="Error message if session failed"
    )
    
    created_at = models.DateTimeField(
        auto_now_add=True,
        help_text="When the console session was created"
    )
    
    updated_at = models.DateTimeField(
        auto_now=True,
        help_text="When the console session was last updated"
    )
    
    connected_at = models.DateTimeField(
        blank=True,
        null=True,
        help_text="When the session was successfully connected"
    )
    
    disconnected_at = models.DateTimeField(
        blank=True,
        null=True,
        help_text="When the session was disconnected"
    )

    class Meta:
        app_label = 'nautobot_device_console'
        ordering = ['-created_at']
        verbose_name = "Console Session"
        verbose_name_plural = "Console Sessions"

    def __str__(self):
        return f"Console Session {self.session_id} - {self.device.name} ({self.status})"

    @property
    def is_active(self):
        """Check if the console session is currently active."""
        return self.status in ['connecting', 'connected']

    @property
    def is_connected(self):
        """Check if the console session is connected."""
        return self.status == 'connected'

    @property
    def duration(self):
        """Calculate session duration."""
        if self.connected_at and self.disconnected_at:
            return self.disconnected_at - self.connected_at
        elif self.connected_at:
            from django.utils import timezone
            return timezone.now() - self.connected_at
        return None


class CommandLog(models.Model):
    """Log all commands executed in console sessions."""
    
    session = models.ForeignKey(
        ConsoleSession,
        on_delete=models.CASCADE,
        related_name='command_logs',
        help_text="Console session this command belongs to"
    )
    
    command = models.TextField(
        help_text="Command that was executed"
    )
    
    output = models.TextField(
        blank=True,
        null=True,
        help_text="Output from the command"
    )
    
    exit_code = models.IntegerField(
        default=0,
        help_text="Exit code of the command"
    )
    
    execution_time = models.FloatField(
        default=0.0,
        help_text="Time taken to execute the command in seconds"
    )
    
    success = models.BooleanField(
        default=True,
        help_text="Whether the command executed successfully"
    )
    
    error_message = models.TextField(
        blank=True,
        null=True,
        help_text="Error message if command failed"
    )
    
    timestamp = models.DateTimeField(
        auto_now_add=True,
        help_text="When the command was executed"
    )

    class Meta:
        app_label = 'nautobot_device_console'
        ordering = ['-timestamp']
        verbose_name = "Command Log"
        verbose_name_plural = "Command Logs"

    def __str__(self):
        return f"Command: {self.command[:50]}... - {self.session.device.name}"


class SessionState(models.Model):
    """Store session state for resumption and persistence."""
    
    session = models.OneToOneField(
        ConsoleSession,
        on_delete=models.CASCADE,
        related_name='session_state',
        help_text="Console session this state belongs to"
    )
    
    current_prompt = models.CharField(
        max_length=256,
        blank=True,
        null=True,
        help_text="Current device prompt"
    )
    
    current_mode = models.CharField(
        max_length=64,
        blank=True,
        null=True,
        help_text="Current device mode (e.g., enable, config)"
    )
    
    command_history = models.JSONField(
        default=list,
        help_text="Command history for this session"
    )
    
    device_info = models.JSONField(
        default=dict,
        help_text="Device information collected during session"
    )
    
    connection_info = models.JSONField(
        default=dict,
        help_text="Connection information and parameters"
    )
    
    last_activity = models.DateTimeField(
        auto_now=True,
        help_text="Last activity timestamp"
    )

    class Meta:
        app_label = 'nautobot_device_console'
        verbose_name = "Session State"
        verbose_name_plural = "Session States"

    def __str__(self):
        return f"Session State - {self.session.device.name}"


class CommandTemplate(models.Model):
    """Store command templates for common tasks."""
    
    name = models.CharField(
        max_length=128,
        help_text="Name of the command template"
    )
    
    description = models.TextField(
        blank=True,
        null=True,
        help_text="Description of what this template does"
    )
    
    platform = models.CharField(
        max_length=64,
        blank=True,
        null=True,
        help_text="Platform this template is for (e.g., cisco_ios, arista_eos)"
    )
    
    commands = models.JSONField(
        default=list,
        help_text="List of commands in this template"
    )
    
    variables = models.JSONField(
        default=dict,
        help_text="Variables that can be used in the template"
    )
    
    is_public = models.BooleanField(
        default=True,
        help_text="Whether this template is available to all users"
    )
    
    created_by = models.ForeignKey(
        'users.User',
        on_delete=models.CASCADE,
        related_name='command_templates',
        help_text="User who created this template"
    )
    
    created_at = models.DateTimeField(
        auto_now_add=True,
        help_text="When the template was created"
    )
    
    updated_at = models.DateTimeField(
        auto_now=True,
        help_text="When the template was last updated"
    )

    class Meta:
        app_label = 'nautobot_device_console'
        ordering = ['name']
        verbose_name = "Command Template"
        verbose_name_plural = "Command Templates"

    def __str__(self):
        return f"Template: {self.name} ({self.platform or 'All Platforms'})"
