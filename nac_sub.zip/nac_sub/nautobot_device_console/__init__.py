from nautobot.apps import NautobotAppConfig


class DeviceConsoleConfig(NautobotAppConfig):
    name = "nautobot_device_console"
    verbose_name = "Device Console Management"
    description = "Device CLI management plugin for Nautobot"
    version = "0.1.0"
    author = "Sameer Dudeja"
    author_email = "s-sameer@hcltech.com"
    base_url = "device-console"
    required_settings = []
    default_settings = {
        "max_concurrent_sessions": 50,
        "session_timeout": 3600,  # 1 hour
        "command_timeout": 30,
        "enable_command_logging": True,
        "max_command_history": 1000,
        "default_connection_timeout": 30,
        "enable_bulk_operations": True,
        "enable_config_comparison": True,
    }
    caching_config = {}


config = DeviceConsoleConfig
