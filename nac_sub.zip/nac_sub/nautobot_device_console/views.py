from django.shortcuts import render
from django.views.generic import TemplateView
from django.views import View
from django.contrib.auth.mixins import LoginRequiredMixin, PermissionRequiredMixin
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.utils.decorators import method_decorator
from django.contrib.auth import get_user_model
from django.db.models import Q
from nautobot.dcim.models import Device
from nautobot.extras.models import SecretsGroup
from nautobot.extras.choices import SecretsGroupAccessTypeChoices, SecretsGroupSecretTypeChoices
from nautobot.core.utils.permissions import get_permission_for_model
from django.core.exceptions import ObjectDoesNotExist
from .models import ConsoleSession, CommandLog, SessionState, CommandTemplate
from .connection_manager import connection_manager
import json
import uuid
import threading
import time
import logging
from django.utils import timezone
from netmiko import ConnectHandler
from netmiko.exceptions import NetMikoTimeoutException, NetMikoAuthenticationException

logger = logging.getLogger(__name__)

User = get_user_model()


class DeviceConsoleHomeView(LoginRequiredMixin, PermissionRequiredMixin, TemplateView):
    """Main console interface view."""
    template_name = 'nautobot_device_console/console.html'
    permission_required = 'nautobot_device_console.view_consolesession'
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['devices'] = Device.objects.all().order_by('name')
        context['secrets_groups'] = SecretsGroup.objects.all().order_by('name')
        return context


class ConsoleSessionListView(LoginRequiredMixin, TemplateView):
    """List all console sessions."""
    template_name = 'nautobot_device_console/session_list.html'
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['sessions'] = ConsoleSession.objects.filter(
            user=self.request.user
        ).order_by('-created_at')
        return context


class ConsoleSessionDetailView(LoginRequiredMixin, TemplateView):
    """Detail view for a specific console session."""
    template_name = 'nautobot_device_console/session_detail.html'
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        session_id = kwargs.get('session_id')
        try:
            context['session'] = ConsoleSession.objects.get(
                session_id=session_id,
                user=self.request.user
            )
            context['command_logs'] = CommandLog.objects.filter(
                session=context['session']
            ).order_by('-timestamp')[:100]  # Last 100 commands
        except ConsoleSession.DoesNotExist:
            context['session'] = None
            context['command_logs'] = []
        return context


@method_decorator(csrf_exempt, name='dispatch')
class StartSessionAPIView(LoginRequiredMixin, PermissionRequiredMixin, View):
    """API endpoint to start a new console session."""
    permission_required = 'nautobot_device_console.add_consolesession'
    
    def post(self, request):
        try:
            data = json.loads(request.body)
            device_id = data.get('device_id')
            connection_type = data.get('connection_type', 'ssh')
            port = data.get('port', 22)
            timeout = data.get('timeout', 30)
            secrets_group_id = data.get('secrets_group_id')
            custom_username = data.get('custom_username')
            custom_password = data.get('custom_password')
            
            # Get the device
            try:
                device = Device.objects.get(id=device_id)
            except Device.DoesNotExist:
                return JsonResponse({'error': 'Device not found'}, status=404)
            
            # Check device access
            has_access, error_msg = self.check_device_access(request.user, device)
            if not has_access:
                return JsonResponse({'error': error_msg}, status=403)
            
            # Create new session
            session = ConsoleSession.objects.create(
                device=device,
                user=request.user,
                connection_type=connection_type,
                port=port,
                timeout=timeout,
                secrets_group_id=secrets_group_id,
                custom_username=custom_username,
                custom_password=custom_password,
                status='pending'
            )
            
            # Create session state
            SessionState.objects.create(session=session)
            
            return JsonResponse({
                'success': True,
                'session_id': str(session.session_id),
                'device_name': device.name,
                'device_ip': str(device.primary_ip4.address.ip) if device.primary_ip4 else None
            })
            
        except Exception as e:
            return JsonResponse({'error': str(e)}, status=500)
    
    def check_device_access(self, user, device):
        """Check if user has access to the device."""
        # Check if user has device console permissions
        if not user.has_perm('nautobot_device_console.execute_command'):
            return False, "Insufficient permissions to access device console"
        
        # Check if user has access to the specific device
        # This could be extended to check device-specific permissions
        if not user.has_perm('dcim.view_device', device):
            return False, "No permission to view this device"
        
        return True, None


@method_decorator(csrf_exempt, name='dispatch')
class ConnectSessionAPIView(LoginRequiredMixin, View):
    """API endpoint to connect a console session."""
    
    def post(self, request, session_id):
        try:
            session = ConsoleSession.objects.get(
                session_id=session_id,
                user=request.user
            )
            
            # Update session status to connecting
            session.status = 'connecting'
            session.save()
            
            # Use the improved connection manager
            success, result = connection_manager.create_connection(
                device=session.device,
                connection_type=session.connection_type,
                port=session.port,
                timeout=session.timeout,
                secrets_group_id=session.secrets_group_id,
                custom_username=session.custom_username,
                custom_password=session.custom_password
            )
            
            if success:
                # Add connection to manager
                if connection_manager.add_connection(str(session.session_id), result):
                    # Update session status
                    session.status = 'connected'
                    session.connected_at = timezone.now()
                    session.error_message = None  # Clear any previous errors
                    session.save()
                    
                    logger.info(f"Successfully connected session {session.session_id} to device {session.device.name}")
                    return JsonResponse({
                        'success': True,
                        'status': session.status,
                        'message': f'Connected successfully to {session.device.name}',
                        'device_name': session.device.name,
                        'device_ip': str(session.device.primary_ip4.address.ip) if session.device.primary_ip4 else None
                    })
                else:
                    # Clean up the connection if we can't add it to manager
                    try:
                        connection_manager.remove_connection(result)
                    except Exception as cleanup_error:
                        logger.warning(f"Failed to cleanup connection {result}: {cleanup_error}")
                    
                    session.status = 'failed'
                    session.error_message = 'Failed to add connection to manager'
                    session.save()
                    return JsonResponse({
                        'error': 'Failed to add connection to manager',
                        'details': 'The connection was created but could not be added to the session manager',
                        'suggestions': [
                            'Try reconnecting to the device',
                            'Check if there are too many active connections',
                            'Contact administrator if the problem persists'
                        ]
                    }, status=500)
            else:
                session.status = 'failed'
                session.error_message = result
                session.save()
                return JsonResponse({
                    'error': 'Connection failed',
                    'details': result,
                    'device_name': session.device.name,
                    'suggestions': self._get_connection_suggestions(result)
                }, status=500)
            
        except ConsoleSession.DoesNotExist:
            return JsonResponse({'error': 'Session not found'}, status=404)
        except Exception as e:
            return JsonResponse({'error': str(e)}, status=500)
    
    def get_credentials(self, session):
        """Get username and password from secrets group or custom credentials."""
        username = None
        password = None
        
        # Try custom credentials first
        if session.custom_username and session.custom_password:
            return session.custom_username, session.custom_password
        
        # Try secrets group
        if session.secrets_group_id:
            try:
                secrets_group = SecretsGroup.objects.get(id=session.secrets_group_id)
                
                # Try to get username and password from secrets group using proper API
                username_found = False
                password_found = False
                
                # Try SSH access type first, then Generic
                for access_type in [SecretsGroupAccessTypeChoices.TYPE_SSH, 
                                  SecretsGroupAccessTypeChoices.TYPE_GENERIC]:
                    try:
                        if not username_found:
                            username = secrets_group.get_secret_value(
                                access_type=access_type,
                                secret_type=SecretsGroupSecretTypeChoices.TYPE_USERNAME
                            )
                            username_found = True
                    except (ObjectDoesNotExist, Exception):
                        continue
                    
                    try:
                        if not password_found:
                            password = secrets_group.get_secret_value(
                                access_type=access_type,
                                secret_type=SecretsGroupSecretTypeChoices.TYPE_PASSWORD
                            )
                            password_found = True
                    except (ObjectDoesNotExist, Exception):
                        continue
                    
                    # If we found both, we can break
                    if username_found and password_found:
                        break
                
                # If we found credentials, return them
                if username_found and password_found:
                    return username, password
                    
            except SecretsGroup.DoesNotExist:
                pass
        
        # Try device default credentials
        if not username and hasattr(session.device, 'secrets_group') and session.device.secrets_group:
            try:
                secrets_group = session.device.secrets_group
                
                # Try to get username and password from device's secrets group
                username_found = False
                password_found = False
                
                # Try SSH access type first, then Generic
                for access_type in [SecretsGroupAccessTypeChoices.TYPE_SSH, 
                                  SecretsGroupAccessTypeChoices.TYPE_GENERIC]:
                    try:
                        if not username_found:
                            username = secrets_group.get_secret_value(
                                access_type=access_type,
                                secret_type=SecretsGroupSecretTypeChoices.TYPE_USERNAME
                            )
                            username_found = True
                    except (ObjectDoesNotExist, Exception):
                        continue
                    
                    try:
                        if not password_found:
                            password = secrets_group.get_secret_value(
                                access_type=access_type,
                                secret_type=SecretsGroupSecretTypeChoices.TYPE_PASSWORD
                            )
                            password_found = True
                    except (ObjectDoesNotExist, Exception):
                        continue
                    
                    # If we found both, we can break
                    if username_found and password_found:
                        break
                
                # If we found credentials, return them
                if username_found and password_found:
                    return username, password
                    
            except Exception:
                pass
        
        return username, password
    
    def get_device_type(self, device):
        """Determine Netmiko device type from device platform."""
        if not device.platform:
            return 'cisco_ios'
        
        platform_name = device.platform.name.lower()
        
        # Map common platforms to Netmiko device types
        platform_mapping = {
            'cisco_ios': 'cisco_ios',
            'cisco_xe': 'cisco_ios',
            'cisco_xr': 'cisco_xr',
            'cisco_nxos': 'cisco_nxos',
            'cisco_asa': 'cisco_asa',
            'juniper_junos': 'juniper_junos',
            'arista_eos': 'arista_eos',
            'hp_procurve': 'hp_procurve',
            'hp_comware': 'hp_comware',
        }
        
        return platform_mapping.get(platform_name, 'cisco_ios')
    
    def _get_connection_suggestions(self, error_message: str) -> list:
        """Get helpful suggestions based on error message."""
        suggestions = []
        
        if "timeout" in error_message.lower():
            suggestions.extend([
                "Check if the device is reachable on the network",
                "Verify the IP address and port are correct",
                "Check if the device is powered on and responding",
                "Try increasing the connection timeout"
            ])
        elif "authentication" in error_message.lower():
            suggestions.extend([
                "Verify the username and password are correct",
                "Check if the secrets group is properly configured",
                "Ensure the device accepts the authentication method",
                "Try using custom credentials instead of secrets group"
            ])
        elif "no ip address" in error_message.lower():
            suggestions.extend([
                "Set a primary IP address for the device",
                "Check if the device has an IP address assigned",
                "Verify the IP address is in the correct format"
            ])
        elif "maximum connections" in error_message.lower():
            suggestions.extend([
                "Disconnect some existing sessions",
                "Wait for other users to disconnect",
                "Contact administrator to increase connection limit"
            ])
        else:
            suggestions.extend([
                "Check the device configuration",
                "Verify network connectivity",
                "Try a different connection type (SSH/Telnet)",
                "Contact system administrator for assistance"
            ])
        
        return suggestions


@method_decorator(csrf_exempt, name='dispatch')
class DisconnectSessionAPIView(LoginRequiredMixin, View):
    """API endpoint to disconnect a console session."""
    
    def post(self, request, session_id):
        try:
            session = ConsoleSession.objects.get(
                session_id=session_id,
                user=request.user
            )
            
            # Disconnect from device if connected
            if connection_manager.is_connected(str(session.session_id)):
                connection_manager.remove_connection(str(session.session_id))
            
            # Update session status to disconnected
            session.status = 'disconnected'
            session.save()
            
            return JsonResponse({
                'success': True,
                'status': session.status,
                'message': 'Disconnected successfully'
            })
            
        except ConsoleSession.DoesNotExist:
            return JsonResponse({'error': 'Session not found'}, status=404)
        except Exception as e:
            return JsonResponse({'error': str(e)}, status=500)


@method_decorator(csrf_exempt, name='dispatch')
class ExecuteCommandAPIView(LoginRequiredMixin, PermissionRequiredMixin, View):
    """API endpoint to execute a command in a console session."""
    permission_required = 'nautobot_device_console.execute_command'
    
    def post(self, request, session_id):
        try:
            # Parse JSON data with better error handling
            try:
                data = json.loads(request.body)
            except json.JSONDecodeError as e:
                return JsonResponse({
                    'error': 'Invalid JSON data',
                    'details': f'JSON parsing failed: {str(e)}'
                }, status=400)
            
            command = data.get('command', '').strip()
            
            if not command:
                return JsonResponse({
                    'error': 'Command is required',
                    'details': 'The command parameter cannot be empty or whitespace only'
                }, status=400)
            
            # Get session with better error handling
            try:
                session = ConsoleSession.objects.get(
                    session_id=session_id,
                    user=request.user
                )
            except ConsoleSession.DoesNotExist:
                return JsonResponse({
                    'error': 'Session not found',
                    'details': f'No session found with ID {session_id} for user {request.user.username}'
                }, status=404)
            
            # Check if session is connected with detailed error message and debug info
            if not connection_manager.is_connected(str(session.session_id)):
                debug_info = connection_manager.get_connection_debug_info(str(session.session_id))
                return JsonResponse({
                    'error': 'Session is not connected',
                    'details': f'Session {session_id} is not connected to device {session.device.name}',
                    'debug_info': debug_info,
                    'suggestions': [
                        'Try reconnecting to the device',
                        'Check if the device is still reachable',
                        'Verify the connection has not timed out',
                        'Check the debug_info for more details'
                    ]
                }, status=400)
            
            # Execute command using connection manager
            logger.info(f"Executing command '{command}' on session {session_id} for device {session.device.name}")
            success, output = connection_manager.execute_command(str(session.session_id), command)
            
            if success:
                # Create command log entry
                command_log = CommandLog.objects.create(
                    session=session,
                    command=command,
                    output=output,
                    success=True
                )
                
                # Update session
                session.last_command = command
                session.command_count += 1
                session.save()
                
                # Update session state
                session_state, created = SessionState.objects.get_or_create(session=session)
                session_state.command_history.append(command)
                session_state.save()
                
                return JsonResponse({
                    'success': True,
                    'output': output,
                    'command_id': command_log.id,
                    'timestamp': command_log.timestamp.isoformat()
                })
            else:
                # Log failed command
                command_log = CommandLog.objects.create(
                    session=session,
                    command=command,
                    output=f"Error: {output}",
                    success=False
                )
                
                return JsonResponse({
                    'success': False,
                    'output': f"Error: {output}",
                    'command_id': command_log.id,
                    'timestamp': command_log.timestamp.isoformat()
                })
            
        except ConsoleSession.DoesNotExist:
            return JsonResponse({'error': 'Session not found'}, status=404)
        except Exception as e:
            return JsonResponse({'error': str(e)}, status=500)


class GetDevicesAPIView(LoginRequiredMixin, View):
    """API endpoint to get list of devices."""
    
    def get(self, request):
        try:
            search = request.GET.get('search', '')
            devices = Device.objects.all()
            
            if search:
                devices = devices.filter(
                    Q(name__icontains=search) |
                    Q(primary_ip4__address__icontains=search) |
                    Q(device_type__model__icontains=search)
                )
            
            device_list = []
            for device in devices[:50]:  # Limit to 50 devices
                device_list.append({
                    'id': device.id,
                    'name': device.name,
                    'ip': str(device.primary_ip4.address.ip) if device.primary_ip4 else None,
                    'platform': device.platform.name if device.platform else None,
                    'status': device.status.name if device.status else None,
                    'location': device.location.name if device.location else None
                })
            
            return JsonResponse({
                'success': True,
                'devices': device_list
            })
            
        except Exception as e:
            return JsonResponse({'error': str(e)}, status=500)


class GetSessionsAPIView(LoginRequiredMixin, View):
    """API endpoint to get user's console sessions."""
    
    def get(self, request):
        try:
            sessions = ConsoleSession.objects.filter(
                user=request.user
            ).order_by('-created_at')
            
            session_list = []
            for session in sessions:
                session_list.append({
                    'session_id': str(session.session_id),
                    'device_name': session.device.name,
                    'device_ip': str(session.device.primary_ip4.address.ip) if session.device.primary_ip4 else None,
                    'status': session.status,
                    'connection_type': session.connection_type,
                    'created_at': session.created_at.isoformat(),
                    'connected_at': session.connected_at.isoformat() if session.connected_at else None,
                    'command_count': session.command_count
                })
            
            return JsonResponse({
                'success': True,
                'sessions': session_list
            })
            
        except Exception as e:
            return JsonResponse({'error': str(e)}, status=500)


@method_decorator(csrf_exempt, name='dispatch')
class DeleteSessionAPIView(LoginRequiredMixin, View):
    """API endpoint to delete a console session."""
    
    def delete(self, request, session_id):
        try:
            session = ConsoleSession.objects.get(
                session_id=session_id,
                user=request.user
            )
            
            # Disconnect if still connected
            if session.is_connected:
                session.status = 'disconnected'
                session.save()
            
            session.delete()
            
            return JsonResponse({
                'success': True,
                'message': 'Session deleted successfully'
            })
            
        except ConsoleSession.DoesNotExist:
            return JsonResponse({'error': 'Session not found'}, status=404)
        except Exception as e:
            return JsonResponse({'error': str(e)}, status=500)


class SessionStatusAPIView(LoginRequiredMixin, View):
    """API endpoint to get session status."""
    
    def get(self, request, session_id):
        try:
            session = ConsoleSession.objects.get(
                session_id=session_id,
                user=request.user
            )
            
            return JsonResponse({
                'success': True,
                'status': session.status,
                'is_connected': session.is_connected,
                'device_name': session.device.name,
                'device_ip': str(session.device.primary_ip4.address.ip) if session.device.primary_ip4 else None,
                'command_count': session.command_count,
                'last_command': session.last_command,
                'connected_at': session.connected_at.isoformat() if session.connected_at else None
            })
            
        except ConsoleSession.DoesNotExist:
            return JsonResponse({'error': 'Session not found'}, status=404)
        except Exception as e:
            return JsonResponse({'error': str(e)}, status=500)


@method_decorator(csrf_exempt, name='dispatch')
class SwitchSessionAPIView(LoginRequiredMixin, View):
    """API endpoint to switch to a different session."""
    
    def post(self, request, session_id):
        try:
            session = ConsoleSession.objects.get(
                session_id=session_id,
                user=request.user
            )
            
            # Check if session is connected
            if not connection_manager.is_connected(str(session.session_id)):
                return JsonResponse({'error': 'Session is not connected'}, status=400)
            
            return JsonResponse({
                'success': True,
                'session_id': str(session.session_id),
                'device_name': session.device.name,
                'device_ip': str(session.device.primary_ip4.address.ip) if session.device.primary_ip4 else None,
                'status': session.status
            })
            
        except ConsoleSession.DoesNotExist:
            return JsonResponse({'error': 'Session not found'}, status=404)
        except Exception as e:
            return JsonResponse({'error': str(e)}, status=500)


@method_decorator(csrf_exempt, name='dispatch')
class BulkExecuteCommandAPIView(LoginRequiredMixin, View):
    """API endpoint to execute commands on multiple sessions."""
    
    def post(self, request):
        try:
            data = json.loads(request.body)
            session_ids = data.get('session_ids', [])
            command = data.get('command', '').strip()
            
            if not command:
                return JsonResponse({'error': 'Command is required'}, status=400)
            
            if not session_ids:
                return JsonResponse({'error': 'Session IDs are required'}, status=400)
            
            results = []
            for session_id in session_ids:
                try:
                    session = ConsoleSession.objects.get(
                        session_id=session_id,
                        user=request.user
                    )
                    
                    if connection_manager.is_connected(str(session.session_id)):
                        success, output = connection_manager.execute_command(str(session.session_id), command)
                        
                        # Create command log entry
                        command_log = CommandLog.objects.create(
                            session=session,
                            command=command,
                            output=output,
                            success=success
                        )
                        
                        # Update session
                        session.last_command = command
                        session.command_count += 1
                        session.save()
                        
                        results.append({
                            'session_id': str(session.session_id),
                            'device_name': session.device.name,
                            'success': success,
                            'output': output,
                            'command_id': command_log.id
                        })
                    else:
                        results.append({
                            'session_id': str(session.session_id),
                            'device_name': session.device.name,
                            'success': False,
                            'output': 'Session not connected',
                            'command_id': None
                        })
                        
                except ConsoleSession.DoesNotExist:
                    results.append({
                        'session_id': session_id,
                        'device_name': 'Unknown',
                        'success': False,
                        'output': 'Session not found',
                        'command_id': None
                    })
                except Exception as e:
                    results.append({
                        'session_id': session_id,
                        'device_name': 'Unknown',
                        'success': False,
                        'output': f'Error: {str(e)}',
                        'command_id': None
                    })
            
            return JsonResponse({
                'success': True,
                'results': results,
                'command': command
            })
            
        except Exception as e:
            return JsonResponse({'error': str(e)}, status=500)


class GetConnectionStatsAPIView(LoginRequiredMixin, View):
    """API endpoint to get connection statistics."""
    
    def get(self, request):
        try:
            stats = {
                'total_connections': connection_manager.get_connection_count(),
                'max_connections': connection_manager.max_connections,
                'user_sessions': ConsoleSession.objects.filter(
                    user=request.user,
                    status__in=['connected', 'connecting']
                ).count(),
                'total_sessions': ConsoleSession.objects.filter(
                    user=request.user
                ).count()
            }
            
            return JsonResponse({
                'success': True,
                'stats': stats
            })
            
        except Exception as e:
            return JsonResponse({'error': str(e)}, status=500)


@method_decorator(csrf_exempt, name='dispatch')
class DebugSessionAPIView(LoginRequiredMixin, View):
    """API endpoint to debug session connection issues."""
    
    def get(self, request, session_id):
        try:
            # Get session from database
            try:
                session = ConsoleSession.objects.get(
                    session_id=session_id,
                    user=request.user
                )
            except ConsoleSession.DoesNotExist:
                return JsonResponse({
                    'error': 'Session not found in database',
                    'session_id': session_id
                }, status=404)
            
            # Get debug info from connection manager
            debug_info = connection_manager.get_connection_debug_info(str(session.session_id))
            
            # Get session details from database
            session_info = {
                'session_id': str(session.session_id),
                'device_name': session.device.name,
                'device_ip': str(session.device.primary_ip4.address.ip) if session.device.primary_ip4 else None,
                'status': session.status,
                'connection_type': session.connection_type,
                'port': session.port,
                'timeout': session.timeout,
                'connected_at': session.connected_at.isoformat() if session.connected_at else None,
                'disconnected_at': session.disconnected_at.isoformat() if session.disconnected_at else None,
                'error_message': session.error_message,
                'command_count': session.command_count,
                'last_command': session.last_command
            }
            
            return JsonResponse({
                'session_info': session_info,
                'connection_debug': debug_info,
                'recommendations': self._get_recommendations(session, debug_info)
            })
            
        except Exception as e:
            return JsonResponse({'error': str(e)}, status=500)
    
    def _get_recommendations(self, session, debug_info):
        """Get recommendations based on session and debug info."""
        recommendations = []
        
        if not debug_info['exists_in_manager']:
            recommendations.append("Session not found in connection manager - try reconnecting")
        elif not debug_info['is_connected']:
            if debug_info.get('error_details'):
                recommendations.append(f"Connection error: {debug_info['error_details']}")
            else:
                recommendations.append("Connection exists but is not healthy - try reconnecting")
        
        if session.status == 'failed':
            recommendations.append("Session status is 'failed' - check error_message and try reconnecting")
        elif session.status == 'disconnected':
            recommendations.append("Session status is 'disconnected' - try reconnecting")
        elif session.status == 'pending':
            recommendations.append("Session status is 'pending' - try connecting")
        
        if session.error_message:
            recommendations.append(f"Previous error: {session.error_message}")
        
        return recommendations


@method_decorator(csrf_exempt, name='dispatch')
class CleanupConnectionsAPIView(LoginRequiredMixin, View):
    """API endpoint to cleanup stale connections."""
    
    def post(self, request):
        try:
            # Clean up stale connections from connection manager
            cleaned_connections = connection_manager.cleanup_stale_connections()
            
            # Update database records for sessions that were cleaned up
            # Find sessions that are marked as connected but no longer exist in connection manager
            active_session_ids = set(connection_manager.active_connections.keys())
            stale_sessions = ConsoleSession.objects.filter(
                status__in=['connected', 'connecting']
            ).exclude(
                session_id__in=active_session_ids
            )
            
            updated_sessions = stale_sessions.update(
                status='disconnected',
                disconnected_at=timezone.now(),
                error_message='Connection lost - cleaned up as stale'
            )
            
            return JsonResponse({
                'success': True,
                'cleaned_connections': cleaned_connections,
                'updated_sessions': updated_sessions,
                'message': f'Cleaned up {cleaned_connections} stale connections, updated {updated_sessions} database records'
            })
            
        except Exception as e:
            return JsonResponse({'error': str(e)}, status=500)


@method_decorator(csrf_exempt, name='dispatch')
class ForceCleanupConnectionsAPIView(LoginRequiredMixin, View):
    """API endpoint to force cleanup all connections."""
    
    def post(self, request):
        try:
            # Clean up connections from connection manager
            cleaned_connections = connection_manager.force_cleanup_all_connections()
            
            # Clean up database records for all sessions
            # Update all sessions to disconnected status
            updated_sessions = ConsoleSession.objects.filter(
                status__in=['connected', 'connecting']
            ).update(
                status='disconnected',
                disconnected_at=timezone.now(),
                error_message='Force cleanup performed'
            )
            
            # Optionally delete old sessions (older than 24 hours)
            from datetime import timedelta
            cutoff_time = timezone.now() - timedelta(hours=24)
            deleted_sessions = ConsoleSession.objects.filter(
                created_at__lt=cutoff_time,
                status__in=['disconnected', 'failed']
            ).delete()[0]  # Returns tuple (count, dict)
            
            return JsonResponse({
                'success': True,
                'cleaned_connections': cleaned_connections,
                'updated_sessions': updated_sessions,
                'deleted_sessions': deleted_sessions,
                'message': f'Force cleaned up {cleaned_connections} connections, updated {updated_sessions} sessions, deleted {deleted_sessions} old sessions'
            })
            
        except Exception as e:
            return JsonResponse({'error': str(e)}, status=500)


@method_decorator(csrf_exempt, name='dispatch')
class AdvancedCleanupAPIView(LoginRequiredMixin, View):
    """API endpoint for advanced cleanup options."""
    
    def post(self, request):
        try:
            data = json.loads(request.body)
            cleanup_type = data.get('cleanup_type', 'stale')  # 'stale', 'all', 'user', 'old'
            user_id = data.get('user_id')  # For user-specific cleanup
            hours_old = data.get('hours_old', 24)  # For old session cleanup
            
            results = {
                'cleaned_connections': 0,
                'updated_sessions': 0,
                'deleted_sessions': 0,
                'cleanup_type': cleanup_type
            }
            
            if cleanup_type == 'stale':
                # Same as regular cleanup
                results['cleaned_connections'] = connection_manager.cleanup_stale_connections()
                active_session_ids = set(connection_manager.active_connections.keys())
                stale_sessions = ConsoleSession.objects.filter(
                    status__in=['connected', 'connecting']
                ).exclude(
                    session_id__in=active_session_ids
                )
                results['updated_sessions'] = stale_sessions.update(
                    status='disconnected',
                    disconnected_at=timezone.now(),
                    error_message='Connection lost - cleaned up as stale'
                )
                
            elif cleanup_type == 'all':
                # Force cleanup all connections and sessions
                results['cleaned_connections'] = connection_manager.force_cleanup_all_connections()
                results['updated_sessions'] = ConsoleSession.objects.filter(
                    status__in=['connected', 'connecting']
                ).update(
                    status='disconnected',
                    disconnected_at=timezone.now(),
                    error_message='Force cleanup performed'
                )
                
            elif cleanup_type == 'user' and user_id:
                # Cleanup sessions for specific user
                user_sessions = ConsoleSession.objects.filter(user_id=user_id)
                session_ids = [str(session.session_id) for session in user_sessions]
                
                # Disconnect from connection manager
                for session_id in session_ids:
                    if connection_manager.is_connected(session_id):
                        connection_manager.remove_connection(session_id)
                        results['cleaned_connections'] += 1
                
                # Update database records
                results['updated_sessions'] = user_sessions.update(
                    status='disconnected',
                    disconnected_at=timezone.now(),
                    error_message='User cleanup performed'
                )
                
            elif cleanup_type == 'old':
                # Delete old sessions
                from datetime import timedelta
                cutoff_time = timezone.now() - timedelta(hours=hours_old)
                old_sessions = ConsoleSession.objects.filter(
                    created_at__lt=cutoff_time,
                    status__in=['disconnected', 'failed']
                )
                
                # Disconnect from connection manager first
                for session in old_sessions:
                    if connection_manager.is_connected(str(session.session_id)):
                        connection_manager.remove_connection(str(session.session_id))
                        results['cleaned_connections'] += 1
                
                # Delete from database
                results['deleted_sessions'] = old_sessions.delete()[0]
                
            else:
                return JsonResponse({'error': 'Invalid cleanup type or missing parameters'}, status=400)
            
            return JsonResponse({
                'success': True,
                'results': results,
                'message': f'Cleanup completed: {results["cleaned_connections"]} connections, {results["updated_sessions"]} sessions updated, {results["deleted_sessions"]} sessions deleted'
            })
            
        except Exception as e:
            return JsonResponse({'error': str(e)}, status=500)


class GetCommandTemplatesAPIView(LoginRequiredMixin, View):
    """API endpoint to get command templates."""
    
    def get(self, request):
        try:
            templates = CommandTemplate.objects.filter(
                Q(is_public=True) | Q(created_by=request.user)
            ).order_by('name')
            
            template_list = []
            for template in templates:
                template_list.append({
                    'id': template.id,
                    'name': template.name,
                    'description': template.description,
                    'commands': template.commands,
                    'command': template.commands[0] if template.commands else '',  # For backward compatibility
                    'platform': template.platform,
                    'is_public': template.is_public,
                    'created_by': template.created_by.username if template.created_by else None,
                    'created_at': template.created_at.isoformat()
                })
            
            return JsonResponse({
                'success': True,
                'templates': template_list
            })
            
        except Exception as e:
            return JsonResponse({'error': str(e)}, status=500)


@method_decorator(csrf_exempt, name='dispatch')
class CreateCommandTemplateAPIView(LoginRequiredMixin, View):
    """API endpoint to create a command template."""
    
    def post(self, request):
        try:
            data = json.loads(request.body)
            name = data.get('name', '').strip()
            description = data.get('description', '').strip()
            command = data.get('command', '').strip()
            platform_name = data.get('platform_name', '').strip()
            is_public = data.get('is_public', False)
            
            if not name or not command:
                return JsonResponse({'error': 'Name and command are required'}, status=400)
            
            # Convert single command to commands array
            commands = [command] if command else []
            
            # Create template
            template = CommandTemplate.objects.create(
                name=name,
                description=description,
                commands=commands,
                platform=platform_name if platform_name else None,
                is_public=is_public,
                created_by=request.user
            )
            
            return JsonResponse({
                'success': True,
                'template_id': template.id,
                'message': 'Template created successfully'
            })
            
        except Exception as e:
            return JsonResponse({'error': str(e)}, status=500)


@method_decorator(csrf_exempt, name='dispatch')
class ExecuteTemplateAPIView(LoginRequiredMixin, View):
    """API endpoint to execute a command template on a session."""
    
    def post(self, request, session_id, template_id):
        try:
            # Get session
            session = ConsoleSession.objects.get(
                session_id=session_id,
                user=request.user
            )
            
            # Get template
            template = CommandTemplate.objects.filter(
                id=template_id
            ).filter(
                Q(is_public=True) | Q(created_by=request.user)
            ).first()
            
            if not template:
                return JsonResponse({'error': 'Template not found or access denied'}, status=404)
            
            # Check if session is connected
            if not connection_manager.is_connected(str(session.session_id)):
                return JsonResponse({'error': 'Session is not connected'}, status=400)
            
            # Execute all commands in the template
            all_outputs = []
            all_success = True
            command_logs = []
            
            for command in template.commands:
                success, output = connection_manager.execute_command(str(session.session_id), command)
                all_outputs.append(output)
                if not success:
                    all_success = False
                
                # Create command log entry for each command
                command_log = CommandLog.objects.create(
                    session=session,
                    command=f"[TEMPLATE: {template.name}] {command}",
                    output=output,
                    success=success
                )
                command_logs.append(command_log)
                
                # Update session
                session.last_command = command
                session.command_count += 1
                session.save()
            
            # Combine all outputs
            combined_output = '\n'.join(all_outputs)
            
            return JsonResponse({
                'success': all_success,
                'output': combined_output,
                'command_ids': [log.id for log in command_logs],
                'template_name': template.name,
                'commands_executed': len(template.commands)
            })
            
        except ConsoleSession.DoesNotExist:
            return JsonResponse({'error': 'Session not found'}, status=404)
        except CommandTemplate.DoesNotExist:
            return JsonResponse({'error': 'Template not found'}, status=404)
        except Exception as e:
            return JsonResponse({'error': str(e)}, status=500)


class GetConfigComparisonAPIView(LoginRequiredMixin, View):
    """API endpoint to get configuration comparison between devices."""
    
    def get(self, request):
        try:
            session_id1 = request.GET.get('session_id1')
            session_id2 = request.GET.get('session_id2')
            command = request.GET.get('command', 'show running-config')
            
            if not session_id1 or not session_id2:
                return JsonResponse({'error': 'Both session IDs are required'}, status=400)
            
            # Get sessions
            try:
                session1 = ConsoleSession.objects.get(
                    session_id=session_id1,
                    user=request.user
                )
                session2 = ConsoleSession.objects.get(
                    session_id=session_id2,
                    user=request.user
                )
            except ConsoleSession.DoesNotExist:
                return JsonResponse({'error': 'One or both sessions not found'}, status=404)
            
            # Check if both sessions are connected
            if not connection_manager.is_connected(str(session1.session_id)):
                return JsonResponse({'error': 'First session is not connected'}, status=400)
            
            if not connection_manager.is_connected(str(session2.session_id)):
                return JsonResponse({'error': 'Second session is not connected'}, status=400)
            
            # Execute command on both devices
            success1, output1 = connection_manager.execute_command(str(session1.session_id), command)
            success2, output2 = connection_manager.execute_command(str(session2.session_id), command)
            
            if not success1:
                return JsonResponse({'error': f'Failed to execute command on {session1.device.name}: {output1}'}, status=500)
            
            if not success2:
                return JsonResponse({'error': f'Failed to execute command on {session2.device.name}: {output2}'}, status=500)
            
            # Simple diff comparison (in production, you might want to use a proper diff library)
            lines1 = output1.split('\n')
            lines2 = output2.split('\n')
            
            diff_result = {
                'device1': {
                    'name': session1.device.name,
                    'ip': str(session1.device.primary_ip4.address.ip) if session1.device.primary_ip4 else None,
                    'output': output1,
                    'line_count': len(lines1)
                },
                'device2': {
                    'name': session2.device.name,
                    'ip': str(session2.device.primary_ip4.address.ip) if session2.device.primary_ip4 else None,
                    'output': output2,
                    'line_count': len(lines2)
                },
                'command': command,
                'identical': output1 == output2,
                'line_differences': abs(len(lines1) - len(lines2))
            }
            
            return JsonResponse({
                'success': True,
                'comparison': diff_result
            })
            
        except Exception as e:
            return JsonResponse({'error': str(e)}, status=500)


class GetPlatformsAPIView(LoginRequiredMixin, View):
    """API endpoint to get list of platforms."""
    
    def get(self, request):
        try:
            from nautobot.dcim.models import Platform
            platforms = Platform.objects.all().order_by('name')
            
            platform_list = []
            for platform in platforms:
                platform_list.append({
                    'id': platform.id,
                    'name': platform.name,
                    'manufacturer': platform.manufacturer.name if platform.manufacturer else None
                })
            
            return JsonResponse({
                'success': True,
                'platforms': platform_list
            })
            
        except Exception as e:
            return JsonResponse({'error': str(e)}, status=500)
