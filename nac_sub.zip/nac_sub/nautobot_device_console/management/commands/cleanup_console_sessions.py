"""
Management command to cleanup stale console sessions
"""

from django.core.management.base import BaseCommand
from django.utils import timezone
from datetime import timedelta
from nautobot_device_console.models import ConsoleSession
from nautobot_device_console.connection_manager import connection_manager


class Command(BaseCommand):
    help = 'Cleanup stale console sessions and connections'

    def add_arguments(self, parser):
        parser.add_argument(
            '--dry-run',
            action='store_true',
            help='Show what would be cleaned up without actually doing it',
        )
        parser.add_argument(
            '--older-than',
            type=int,
            default=3600,
            help='Clean up sessions older than this many seconds (default: 3600)',
        )

    def handle(self, *args, **options):
        dry_run = options['dry_run']
        older_than_seconds = options['older_than']
        
        # Calculate cutoff time
        cutoff_time = timezone.now() - timedelta(seconds=older_than_seconds)
        
        # Find stale sessions
        stale_sessions = ConsoleSession.objects.filter(
            status__in=['connected', 'connecting'],
            created_at__lt=cutoff_time
        )
        
        # Clean up connection manager
        cleaned_connections = connection_manager.cleanup_stale_connections()
        
        if dry_run:
            self.stdout.write(
                self.style.WARNING(
                    f'DRY RUN: Would clean up {stale_sessions.count()} stale sessions and {cleaned_connections} connections'
                )
            )
        else:
            # Update stale sessions
            updated_count = stale_sessions.update(
                status='disconnected',
                error_message='Session cleaned up due to inactivity'
            )
            
            self.stdout.write(
                self.style.SUCCESS(
                    f'Cleaned up {updated_count} stale sessions and {cleaned_connections} connections'
                )
            )
