"""
Device Connection Manager for Nautobot Device Console
Handles device connections using Netmiko and NAPALM
"""

import logging
import socket
from typing import Optional, Dict, Any
from django.conf import settings
from django.utils import timezone
from nautobot.dcim.models import Device
from nautobot.extras.models import SecretsGroup
from nautobot.extras.choices import SecretsGroupAccessTypeChoices, SecretsGroupSecretTypeChoices
from django.core.exceptions import ObjectDoesNotExist
from netmiko import ConnectHandler
from netmiko.exceptions import NetMikoTimeoutException, NetMikoAuthenticationException
import paramiko

logger = logging.getLogger(__name__)


class DeviceConnectionManager:
    """Manages device connections and command execution."""
    
    def __init__(self):
        self.active_connections = {}
        self.connection_timeout = getattr(settings, 'NAUTOBOT_DEVICE_CONSOLE', {}).get('connection_timeout', 30)
        self.command_timeout = getattr(settings, 'NAUTOBOT_DEVICE_CONSOLE', {}).get('command_timeout', 30)
        self.max_connections = getattr(settings, 'NAUTOBOT_DEVICE_CONSOLE', {}).get('max_concurrent_sessions', 50)  # Increased from 10 to 50
    
    def get_device_credentials(self, device: Device, secrets_group_id: Optional[str] = None) -> Dict[str, str]:
        """Get device credentials from secrets group or device defaults."""
        credentials = {}
        
        # Try to get credentials from secrets group
        if secrets_group_id:
            try:
                secrets_group = SecretsGroup.objects.get(id=secrets_group_id)
                
                # Try to get username and password from secrets group using proper API
                username_found = False
                password_found = False
                
                # Try SSH access type first, then Generic
                for access_type in [SecretsGroupAccessTypeChoices.TYPE_SSH, 
                                  SecretsGroupAccessTypeChoices.TYPE_GENERIC]:
                    try:
                        if not username_found:
                            credentials['username'] = secrets_group.get_secret_value(
                                access_type=access_type,
                                secret_type=SecretsGroupSecretTypeChoices.TYPE_USERNAME
                            )
                            username_found = True
                    except (ObjectDoesNotExist, Exception):
                        continue
                    
                    try:
                        if not password_found:
                            credentials['password'] = secrets_group.get_secret_value(
                                access_type=access_type,
                                secret_type=SecretsGroupSecretTypeChoices.TYPE_PASSWORD
                            )
                            password_found = True
                    except (ObjectDoesNotExist, Exception):
                        continue
                    
                    # If we found both, we can break
                    if username_found and password_found:
                        break
                        
            except SecretsGroup.DoesNotExist:
                logger.warning(f"Secrets group {secrets_group_id} not found")
        
        # Fallback to device credentials if available
        if not credentials.get('username'):
            credentials['username'] = getattr(device, 'username', 'admin')
        if not credentials.get('password'):
            credentials['password'] = getattr(device, 'password', '')
        
        return credentials
    
    def get_device_connection_params(self, device: Device, connection_type: str = 'ssh', 
                                   port: int = 22, secrets_group_id: Optional[str] = None) -> Dict[str, Any]:
        """Get connection parameters for device."""
        credentials = self.get_device_credentials(device, secrets_group_id)
        
        # Get device IP address
        device_ip = None
        if device.primary_ip4:
            device_ip = str(device.primary_ip4.address.ip)
        elif device.primary_ip6:
            device_ip = str(device.primary_ip6.address.ip)
        
        if not device_ip:
            raise ValueError(f"No IP address found for device {device.name}")
        
        # Determine device type for Netmiko
        device_type = self._get_netmiko_device_type(device)
        
        connection_params = {
            'device_type': device_type,
            'host': device_ip,
            'username': credentials['username'],
            'password': credentials['password'],
            'port': port,
            'timeout': self.connection_timeout,
            'session_timeout': self.connection_timeout,
            'banner_timeout': 10,
            'auth_timeout': 10,
        }
        
        # Add connection-specific parameters
        if connection_type == 'telnet':
            connection_params['device_type'] = f"{device_type}_telnet"
        
        return connection_params
    
    def _get_netmiko_device_type(self, device: Device) -> str:
        """Get Netmiko device type based on device platform."""
        if not device.platform:
            return 'cisco_ios'  # Default fallback
        
        platform_name = device.platform.name.lower()
        
        # Map common platform names to Netmiko device types
        platform_mapping = {
            'cisco_ios': 'cisco_ios',
            'cisco_xe': 'cisco_ios',
            'cisco_xr': 'cisco_xr',
            'cisco_nxos': 'cisco_nxos',
            'cisco_asa': 'cisco_asa',
            'juniper_junos': 'juniper',
            'arista_eos': 'arista_eos',
            'hp_procurve': 'hp_procurve',
            'hp_comware': 'hp_comware',
            'fortinet': 'fortinet',
            'paloalto_panos': 'paloalto_panos',
            'linux': 'linux',
            'generic': 'generic',
        }
        
        return platform_mapping.get(platform_name, 'cisco_ios')
    
    def connect_to_device(self, device: Device, connection_type: str = 'ssh', 
                         port: int = 22, secrets_group_id: Optional[str] = None) -> str:
        """Connect to device and return connection ID."""
        try:
            connection_params = self.get_device_connection_params(
                device, connection_type, port, secrets_group_id
            )
            
            # Create connection
            connection = ConnectHandler(**connection_params)
            
            # Generate unique connection ID
            import uuid
            connection_id = str(uuid.uuid4())
            
            # Store connection
            self.active_connections[connection_id] = {
                'connection': connection,
                'device': device,
                'connection_type': connection_type,
                'port': port,
                'connected_at': None
            }
            
            logger.info(f"Connected to device {device.name} with connection ID {connection_id}")
            return connection_id
            
        except NetMikoTimeoutException:
            raise Exception(f"Connection timeout to device {device.name}")
        except NetMikoAuthenticationException:
            raise Exception(f"Authentication failed for device {device.name}")
        except Exception as e:
            logger.error(f"Failed to connect to device {device.name}: {str(e)}")
            raise Exception(f"Connection failed: {str(e)}")
    
    def execute_command(self, connection_id: str, command: str) -> tuple[bool, str]:
        """Execute command on device and return (success, output)."""
        if connection_id not in self.active_connections:
            return False, "Connection not found"
        
        connection_data = self.active_connections[connection_id]
        connection = connection_data['connection']
        
        try:
            # Send command and get output
            output = connection.send_command(command, delay_factor=2)
            return True, output
            
        except Exception as e:
            logger.error(f"Command execution failed: {str(e)}")
            return False, str(e)
    
    def disconnect_device(self, connection_id: str) -> bool:
        """Disconnect from device."""
        if connection_id not in self.active_connections:
            return False
        
        try:
            connection_data = self.active_connections[connection_id]
            connection = connection_data['connection']
            
            # Disconnect
            connection.disconnect()
            
            # Remove from active connections
            del self.active_connections[connection_id]
            
            logger.info(f"Disconnected from device with connection ID {connection_id}")
            return True
            
        except Exception as e:
            logger.error(f"Failed to disconnect: {str(e)}")
            return False
    
    def is_connected(self, connection_id: str) -> bool:
        """Check if connection is still active."""
        if connection_id not in self.active_connections:
            logger.debug(f"Connection {connection_id} not found in active connections")
            return False
        
        try:
            connection_data = self.active_connections[connection_id]
            connection = connection_data['connection']
            
            # Check if the connection object is still valid
            if not hasattr(connection, 'remote_conn') or connection.remote_conn is None:
                logger.debug(f"Connection {connection_id} has no valid remote_conn")
                return False
            
            # Try to check if the connection is still alive
            # We'll use a simple approach that works with paramiko
            try:
                # Check if the channel is still open and active
                if hasattr(connection.remote_conn, 'closed') and connection.remote_conn.closed:
                    logger.debug(f"Connection {connection_id} channel is closed")
                    return False
                
                # Try to get the current prompt - this is a safe way to test the connection
                # without sending a command that might affect the device state
                current_prompt = connection.find_prompt()
                if current_prompt:
                    logger.debug(f"Connection {connection_id} is healthy, prompt: {current_prompt}")
                    return True
                else:
                    logger.debug(f"Connection {connection_id} could not get prompt")
                    return False
                    
            except Exception as e:
                logger.debug(f"Connection {connection_id} health check failed: {e}")
                return False
            
        except Exception as e:
            logger.debug(f"Connection health check failed for {connection_id}: {e}")
            # Connection is dead, remove it
            if connection_id in self.active_connections:
                del self.active_connections[connection_id]
            return False
    
    
    def cleanup_stale_connections(self):
        """Clean up stale connections."""
        stale_connections = []
        
        for connection_id in self.active_connections:
            if not self.is_connected(connection_id):
                stale_connections.append(connection_id)
        
        for connection_id in stale_connections:
            if connection_id in self.active_connections:
                del self.active_connections[connection_id]
                logger.info(f"Cleaned up stale connection {connection_id}")
        
        return len(stale_connections)
    
    def force_cleanup_all_connections(self):
        """Force cleanup all connections - use with caution."""
        connection_count = len(self.active_connections)
        
        for connection_id in list(self.active_connections.keys()):
            try:
                connection_data = self.active_connections[connection_id]
                connection = connection_data['connection']
                connection.disconnect()
            except Exception as e:
                logger.warning(f"Error disconnecting connection {connection_id}: {e}")
            finally:
                if connection_id in self.active_connections:
                    del self.active_connections[connection_id]
        
        logger.info(f"Force cleaned up {connection_count} connections")
        return connection_count
    
    def create_connection(self, device: Device, connection_type: str = 'ssh', 
                         port: int = 22, timeout: int = 30, secrets_group_id: Optional[str] = None,
                         custom_username: Optional[str] = None, custom_password: Optional[str] = None) -> tuple[bool, str]:
        """Create a new connection and return (success, result)."""
        try:
            # First, cleanup any stale connections
            self.cleanup_stale_connections()
            
            # Check if we've reached max connections after cleanup
            if len(self.active_connections) >= self.max_connections:
                return False, f"Maximum connections reached ({self.max_connections}). Please disconnect some sessions first."
            
            # Validate device has IP address
            device_ip = None
            if device.primary_ip4:
                device_ip = str(device.primary_ip4.address.ip)
            elif device.primary_ip6:
                device_ip = str(device.primary_ip6.address.ip)
            
            if not device_ip:
                return False, f"Device {device.name} has no IP address configured. Please set a primary IP address."
            
            # Get connection parameters
            connection_params = self.get_device_connection_params(
                device, connection_type, port, secrets_group_id
            )
            
            # Override with custom credentials if provided
            if custom_username:
                connection_params['username'] = custom_username
            if custom_password:
                connection_params['password'] = custom_password
            
            # Validate required parameters
            if not connection_params.get('username'):
                return False, "No username provided. Please configure device credentials or secrets group."
            
            if not connection_params.get('password'):
                return False, "No password provided. Please configure device credentials or secrets group."
            
            # Create connection with better error handling
            try:
                connection = ConnectHandler(**connection_params)
            except NetMikoTimeoutException as e:
                return False, f"Connection timeout to {device.name} ({device_ip}:{port}). Check network connectivity and device availability."
            except NetMikoAuthenticationException as e:
                return False, f"Authentication failed for {device.name}. Check username/password or secrets group configuration."
            except Exception as e:
                return False, f"Connection failed to {device.name}: {str(e)}"
            
            # Generate unique connection ID
            import uuid
            connection_id = str(uuid.uuid4())
            
            # Store connection
            self.active_connections[connection_id] = {
                'connection': connection,
                'device': device,
                'connection_type': connection_type,
                'port': port,
                'connected_at': timezone.now()
            }
            
            logger.info(f"Created connection to device {device.name} ({device_ip}:{port}) with connection ID {connection_id}")
            return True, connection_id
            
        except Exception as e:
            logger.error(f"Failed to create connection to device {device.name}: {str(e)}")
            return False, f"Unexpected error: {str(e)}"
    
    def add_connection(self, session_id: str, connection_id: str) -> bool:
        """Add a connection to the manager using session ID as key."""
        if connection_id in self.active_connections:
            # Move connection to use session_id as key
            self.active_connections[session_id] = self.active_connections.pop(connection_id)
            logger.info(f"Added connection {connection_id} as session {session_id}")
            return True
        logger.warning(f"Connection {connection_id} not found in active connections")
        return False
    
    def remove_connection(self, session_id: str) -> bool:
        """Remove a connection from the manager."""
        if session_id in self.active_connections:
            try:
                connection_data = self.active_connections[session_id]
                connection = connection_data['connection']
                connection.disconnect()
            except Exception as e:
                logger.warning(f"Error disconnecting connection {session_id}: {e}")
            finally:
                del self.active_connections[session_id]
                logger.info(f"Removed connection {session_id}")
                return True
        return False
    
    def get_connection_count(self) -> int:
        """Get the number of active connections."""
        return len(self.active_connections)
    
    def get_connection_info(self, session_id: str) -> Optional[Dict[str, Any]]:
        """Get connection information by session ID."""
        if session_id not in self.active_connections:
            return None
        
        connection_data = self.active_connections[session_id]
        return {
            'device_name': connection_data['device'].name,
            'device_ip': str(connection_data['device'].primary_ip4.address.ip) if connection_data['device'].primary_ip4 else None,
            'connection_type': connection_data['connection_type'],
            'port': connection_data['port'],
            'connected_at': connection_data['connected_at']
        }
    
    def get_connection_debug_info(self, session_id: str) -> Dict[str, Any]:
        """Get detailed debug information for a connection."""
        debug_info = {
            'session_id': session_id,
            'exists_in_manager': session_id in self.active_connections,
            'is_connected': False,
            'connection_details': None,
            'error_details': None,
            'health_check_details': None
        }
        
        if session_id in self.active_connections:
            try:
                connection_data = self.active_connections[session_id]
                connection = connection_data['connection']
                
                debug_info['connection_details'] = {
                    'device_name': connection_data['device'].name,
                    'connection_type': connection_data['connection_type'],
                    'port': connection_data['port'],
                    'connected_at': connection_data['connected_at'],
                    'has_remote_conn': hasattr(connection, 'remote_conn'),
                    'remote_conn_is_none': connection.remote_conn is None if hasattr(connection, 'remote_conn') else 'N/A'
                }
                
                # Detailed health check
                health_details = self._detailed_health_check(session_id)
                debug_info['health_check_details'] = health_details
                debug_info['is_connected'] = health_details['is_healthy']
                
            except Exception as e:
                debug_info['error_details'] = str(e)
        else:
            debug_info['error_details'] = f"Session {session_id} not found in active connections"
        
        return debug_info
    
    def _detailed_health_check(self, session_id: str) -> Dict[str, Any]:
        """Perform a detailed health check on a connection."""
        health_info = {
            'is_healthy': False,
            'checks': {},
            'errors': []
        }
        
        if session_id not in self.active_connections:
            health_info['errors'].append("Session not found in active connections")
            return health_info
        
        try:
            connection_data = self.active_connections[session_id]
            connection = connection_data['connection']
            
            # Check 1: Connection object exists
            health_info['checks']['has_connection'] = connection is not None
            if not health_info['checks']['has_connection']:
                health_info['errors'].append("Connection object is None")
                return health_info
            
            # Check 2: Remote connection exists
            health_info['checks']['has_remote_conn'] = hasattr(connection, 'remote_conn')
            if not health_info['checks']['has_remote_conn']:
                health_info['errors'].append("Connection has no remote_conn attribute")
                return health_info
            
            # Check 3: Remote connection is not None
            health_info['checks']['remote_conn_not_none'] = connection.remote_conn is not None
            if not health_info['checks']['remote_conn_not_none']:
                health_info['errors'].append("remote_conn is None")
                return health_info
            
            # Check 4: Channel is not closed
            health_info['checks']['channel_not_closed'] = not (hasattr(connection.remote_conn, 'closed') and connection.remote_conn.closed)
            if not health_info['checks']['channel_not_closed']:
                health_info['errors'].append("SSH channel is closed")
                return health_info
            
            # Check 5: Can get prompt (this tests the actual connection)
            try:
                current_prompt = connection.find_prompt()
                health_info['checks']['can_get_prompt'] = current_prompt is not None and len(current_prompt) > 0
                health_info['checks']['current_prompt'] = current_prompt
                if not health_info['checks']['can_get_prompt']:
                    health_info['errors'].append("Cannot get current prompt from device")
            except Exception as e:
                health_info['checks']['can_get_prompt'] = False
                health_info['errors'].append(f"Error getting prompt: {str(e)}")
            
            # Overall health status
            health_info['is_healthy'] = all(health_info['checks'].values())
            
        except Exception as e:
            health_info['errors'].append(f"Health check failed: {str(e)}")
        
        return health_info
    
    def get_all_connections_debug_info(self) -> Dict[str, Any]:
        """Get debug information for all active connections."""
        debug_info = {
            'total_connections': len(self.active_connections),
            'connections': {},
            'summary': {
                'healthy_connections': 0,
                'unhealthy_connections': 0,
                'connection_errors': []
            }
        }
        
        for session_id in self.active_connections:
            try:
                connection_debug = self.get_connection_debug_info(session_id)
                debug_info['connections'][session_id] = connection_debug
                
                if connection_debug.get('is_connected', False):
                    debug_info['summary']['healthy_connections'] += 1
                else:
                    debug_info['summary']['unhealthy_connections'] += 1
                    if connection_debug.get('error_details'):
                        debug_info['summary']['connection_errors'].append({
                            'session_id': session_id,
                            'error': connection_debug['error_details']
                        })
                        
            except Exception as e:
                debug_info['connections'][session_id] = {
                    'error': f"Failed to get debug info: {str(e)}"
                }
                debug_info['summary']['unhealthy_connections'] += 1
                debug_info['summary']['connection_errors'].append({
                    'session_id': session_id,
                    'error': f"Debug info failed: {str(e)}"
                })
        
        return debug_info


# Global connection manager instance
connection_manager = DeviceConnectionManager()
