# Nautobot Device Console Plugin

A comprehensive device console management plugin for Nautobot that provides CLI access to network devices through a web interface.

## Features

### Core Functionality
- **Device Console Access**: Connect to network devices via SSH/Telnet
- **Multi-Session Support**: Manage multiple device sessions simultaneously
- **Command Execution**: Execute commands and view real-time output
- **Session Management**: Create, manage, and track console sessions
- **Command Logging**: Log all commands and responses for audit purposes

### Advanced Features
- **Command Templates**: Create and execute reusable command templates
- **Configuration Comparison**: Compare configurations between devices
- **Bulk Operations**: Execute commands across multiple devices
- **Session Persistence**: Resume sessions after page refresh
- **Device Integration**: Seamless integration with Nautobot device inventory

### Security & Permissions
- **Role-based Access Control**: Granular permissions for different user roles
- **Device Access Control**: Control which devices users can access
- **Audit Logging**: Complete audit trail of all console activities
- **Secure Credential Management**: Integration with Nautobot secrets management

## Installation

1. Install the plugin:
```bash
pip install -e /path/to/nautobot_device_console
```

2. Add to `nautobot_config.py`:
```python
PLUGINS = [
    "nautobot_device_console",
]

PLUGINS_CONFIG = {
    "nautobot_device_console": {
        "max_concurrent_sessions": 10,
        "session_timeout": 3600,  # 1 hour
        "command_timeout": 30,
        "enable_command_logging": True,
        "max_command_history": 1000,
        "default_connection_timeout": 30,
        "enable_bulk_operations": True,
        "enable_config_comparison": True,
        "enable_command_templates": True,
        "enable_multi_session": True,
        "auto_cleanup_stale_connections": True,
        "cleanup_interval": 300,  # 5 minutes
        "require_device_permissions": True,
        "enable_session_persistence": True,
        "max_session_history": 100,
    }
}
```

3. Run migrations:
```bash
nautobot-server migrate
```

4. Collect static files:
```bash
nautobot-server collectstatic
```

5. Restart Nautobot:
```bash
nautobot-server runserver
```

## Configuration

### Plugin Settings

| Setting | Default | Description |
|---------|---------|-------------|
| `max_concurrent_sessions` | 10 | Maximum number of concurrent sessions per user |
| `session_timeout` | 3600 | Session timeout in seconds (1 hour) |
| `command_timeout` | 30 | Command execution timeout in seconds |
| `enable_command_logging` | True | Enable command and response logging |
| `max_command_history` | 1000 | Maximum commands to keep in history |
| `default_connection_timeout` | 30 | Default connection timeout in seconds |
| `enable_bulk_operations` | True | Enable bulk command execution |
| `enable_config_comparison` | True | Enable configuration comparison |
| `enable_command_templates` | True | Enable command templates |
| `enable_multi_session` | True | Enable multi-session support |
| `auto_cleanup_stale_connections` | True | Automatically cleanup stale connections |
| `cleanup_interval` | 300 | Cleanup interval in seconds |
| `require_device_permissions` | True | Require device-level permissions |
| `enable_session_persistence` | True | Enable session persistence |
| `max_session_history` | 100 | Maximum sessions to keep in history |

### Platform Mapping

The plugin automatically maps Nautobot platforms to Netmiko device types:

```python
"default_platform_mapping": {
    "cisco_ios": "cisco_ios",
    "cisco_xe": "cisco_ios",
    "cisco_xr": "cisco_xr",
    "cisco_nxos": "cisco_nxos",
    "juniper_junos": "juniper",
    "arista_eos": "arista_eos"
}
```

## Usage

### Basic Console Access

1. Navigate to **Plugins > Device Console**
2. Select a device from the dropdown
3. Choose connection type (SSH/Telnet) and port
4. Select credentials (secrets group or custom)
5. Click **Connect**

### Command Templates

1. Click **Templates** button
2. Create new templates with common commands
3. Execute templates on connected sessions
4. Share templates with other users

### Configuration Comparison

1. Connect to two devices
2. Click **Compare** button
3. Select the two sessions to compare
4. Choose the command to compare (default: `show running-config`)
5. View side-by-side comparison

### Multi-Session Management

1. Connect to multiple devices
2. Use session tabs to switch between devices
3. Execute commands on individual sessions
4. Use bulk operations for multiple devices

## Permissions

The plugin defines several permissions:

- `device_console.view_consolesession` - View console sessions
- `device_console.add_consolesession` - Create console sessions
- `device_console.change_consolesession` - Modify console sessions
- `device_console.delete_consolesession` - Delete console sessions
- `device_console.execute_command` - Execute commands on devices
- `device_console.view_commandlog` - View command logs
- `device_console.add_commandtemplate` - Create command templates
- `device_console.change_commandtemplate` - Modify command templates
- `device_console.delete_commandtemplate` - Delete command templates
- `device_console.view_commandtemplate` - View command templates
- `device_console.bulk_operations` - Perform bulk operations
- `device_console.config_comparison` - Perform configuration comparisons
- `device_console.manage_sessions` - Manage all console sessions

## Management Commands

### Cleanup Stale Sessions

```bash
nautobot-server cleanup_console_sessions
```

Options:
- `--dry-run`: Show what would be cleaned up without doing it
- `--older-than`: Clean up sessions older than specified seconds

## API Endpoints

### Session Management
- `POST /plugins/device-console/api/sessions/start/` - Start new session
- `POST /plugins/device-console/api/sessions/{id}/connect/` - Connect session
- `POST /plugins/device-console/api/sessions/{id}/disconnect/` - Disconnect session
- `POST /plugins/device-console/api/sessions/{id}/execute/` - Execute command
- `GET /plugins/device-console/api/sessions/` - List sessions

### Command Templates
- `GET /plugins/device-console/api/templates/` - List templates
- `POST /plugins/device-console/api/templates/create/` - Create template
- `POST /plugins/device-console/api/sessions/{id}/templates/{template_id}/execute/` - Execute template

### Configuration Comparison
- `GET /plugins/device-console/api/config-comparison/` - Compare configurations

### Device Management
- `GET /plugins/device-console/api/devices/` - List devices
- `GET /plugins/device-console/api/platforms/` - List platforms

## Troubleshooting

### Common Issues

1. **Connection Timeout**
   - Check device IP address and port
   - Verify network connectivity
   - Increase connection timeout

2. **Authentication Failed**
   - Verify username/password
   - Check secrets group configuration
   - Try custom credentials

3. **Device Not Found**
   - Ensure device has primary IP address
   - Check device permissions
   - Verify device is active

4. **Maximum Connections Reached**
   - Disconnect unused sessions
   - Wait for other users to disconnect
   - Contact administrator to increase limit

### Logs

Check Nautobot logs for detailed error information:
```bash
tail -f /var/log/nautobot/nautobot.log
```

## Development

### Running Tests

```bash
cd nautobot_device_console
python -m pytest
```

### Building Documentation

```bash
cd docs
make html
```

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests
5. Submit a pull request

## License

This plugin is licensed under the Apache 2.0 License.
