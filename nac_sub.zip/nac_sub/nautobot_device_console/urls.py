from django.urls import path
from . import views

app_name = 'nautobot_device_console'

urlpatterns = [
    # Main console interface
    path('', views.DeviceConsoleHomeView.as_view(), name='console_home'),
    
    # Session management
    path('sessions/', views.ConsoleSessionListView.as_view(), name='session_list'),
    path('sessions/<uuid:session_id>/', views.ConsoleSessionDetailView.as_view(), name='session_detail'),
    
    # API endpoints
    path('api/sessions/start/', views.StartSessionAPIView.as_view(), name='start_session'),
    path('api/sessions/<uuid:session_id>/connect/', views.ConnectSessionAPIView.as_view(), name='connect_session'),
    path('api/sessions/<uuid:session_id>/disconnect/', views.DisconnectSessionAPIView.as_view(), name='disconnect_session'),
    path('api/sessions/<uuid:session_id>/execute/', views.ExecuteCommandAPIView.as_view(), name='execute_command'),
    path('api/sessions/<uuid:session_id>/delete/', views.DeleteSessionAPIView.as_view(), name='delete_session'),
    path('api/sessions/<uuid:session_id>/status/', views.SessionStatusAPIView.as_view(), name='session_status'),
    path('api/sessions/<uuid:session_id>/debug/', views.DebugSessionAPIView.as_view(), name='debug_session'),
    
    # Device and session data
    path('api/devices/', views.GetDevicesAPIView.as_view(), name='get_devices'),
    path('api/sessions/', views.GetSessionsAPIView.as_view(), name='get_sessions'),
    path('api/platforms/', views.GetPlatformsAPIView.as_view(), name='get_platforms'),
    
    # Multi-session management
    path('api/sessions/<uuid:session_id>/switch/', views.SwitchSessionAPIView.as_view(), name='switch_session'),
    path('api/sessions/bulk-execute/', views.BulkExecuteCommandAPIView.as_view(), name='bulk_execute'),
    path('api/connection-stats/', views.GetConnectionStatsAPIView.as_view(), name='connection_stats'),
    path('api/cleanup-connections/', views.CleanupConnectionsAPIView.as_view(), name='cleanup_connections'),
    path('api/force-cleanup-connections/', views.ForceCleanupConnectionsAPIView.as_view(), name='force_cleanup_connections'),
    
    # Command templates
    path('api/templates/', views.GetCommandTemplatesAPIView.as_view(), name='get_templates'),
    path('api/templates/create/', views.CreateCommandTemplateAPIView.as_view(), name='create_template'),
    path('api/sessions/<uuid:session_id>/templates/<int:template_id>/execute/', views.ExecuteTemplateAPIView.as_view(), name='execute_template'),
    
    # Configuration comparison
    path('api/config-comparison/', views.GetConfigComparisonAPIView.as_view(), name='config_comparison'),
]