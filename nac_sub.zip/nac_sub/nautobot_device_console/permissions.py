"""
Permissions for Nautobot Device Console Plugin
"""

from nautobot.core.permissions import register_permissions
from nautobot.users.models import ObjectPermission

# Define permissions
permissions = (
    ObjectPermission(
        name="device_console.view_consolesession",
        description="Can view console sessions",
        actions=["view"],
    ),
    ObjectPermission(
        name="device_console.add_consolesession",
        description="Can create console sessions",
        actions=["add"],
    ),
    ObjectPermission(
        name="device_console.change_consolesession",
        description="Can modify console sessions",
        actions=["change"],
    ),
    ObjectPermission(
        name="device_console.delete_consolesession",
        description="Can delete console sessions",
        actions=["delete"],
    ),
    ObjectPermission(
        name="device_console.execute_command",
        description="Can execute commands on devices",
        actions=["execute"],
    ),
    ObjectPermission(
        name="device_console.view_commandlog",
        description="Can view command logs",
        actions=["view"],
    ),
    ObjectPermission(
        name="device_console.add_commandtemplate",
        description="Can create command templates",
        actions=["add"],
    ),
    ObjectPermission(
        name="device_console.change_commandtemplate",
        description="Can modify command templates",
        actions=["change"],
    ),
    ObjectPermission(
        name="device_console.delete_commandtemplate",
        description="Can delete command templates",
        actions=["delete"],
    ),
    ObjectPermission(
        name="device_console.view_commandtemplate",
        description="Can view command templates",
        actions=["view"],
    ),
    ObjectPermission(
        name="device_console.bulk_operations",
        description="Can perform bulk operations",
        actions=["bulk"],
    ),
    ObjectPermission(
        name="device_console.config_comparison",
        description="Can perform configuration comparisons",
        actions=["compare"],
    ),
    ObjectPermission(
        name="device_console.manage_sessions",
        description="Can manage all console sessions",
        actions=["manage"],
    ),
)

# Register permissions
register_permissions("nautobot_device_console", permissions)
