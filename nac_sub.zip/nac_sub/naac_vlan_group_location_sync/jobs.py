from nautobot.apps.jobs import Job, ObjectVar, BooleanVar, MultiObjectVar
from nautobot.dcim.models import Device, Interface, Location
from nautobot.ipam.models import VLAN, VLANGroup
from django.db.models import Prefetch


class VlanGroupLocationSync(Job):

    class Meta:
        name = "VLAN Group & Location Sync"
        description = "Sync VLAN location and assign VLAN group (Building-Floor based)"

    location = ObjectVar(
        model=Location,
        description="Select Location",
        required=True,
    )

    select_all = BooleanVar(
        description="Select all devices under location",
        default=True,
    )

    devices = MultiObjectVar(
        model=Device,
        required=False,
        description="Select devices (if select_all is False)",
    )

    dry_run = BooleanVar(
        description="Dry run (no DB changes)",
        default=True,
    )

    def _get_devices_from_location(self, location):
        """Fetch devices under room-level locations (iterative)."""

        stack = [location]
        all_locations = []

        while stack:
            current = stack.pop()
            all_locations.append(current)

            children = Location.objects.filter(parent=current)
            stack.extend(children)

        room_locations = [
            loc for loc in all_locations
            if loc.location_type.name.lower() == "room"
        ]

        self.logger.debug(f"Resolved {len(room_locations)} room locations")

        return Device.objects.filter(location__in=room_locations).prefetch_related(
            Prefetch(
                "interfaces",
                queryset=Interface.objects.prefetch_related(
                    "tagged_vlans",
                    "untagged_vlan"
                ),
            )
        )

    def _get_parent(self, location, type_name):
        current = location
        while current:
            if current.location_type.name.lower() == type_name:
                return current
            current = current.parent
        return None

    
    def run(self, **kwargs):
        location = kwargs["location"]
        select_all = kwargs["select_all"]
        devices = kwargs.get("devices")
        dry_run = kwargs.get("dry_run", True)

        self.logger.info("===== JOB START =====")
        self.logger.info(f"Input Location: {location} ({location.location_type})")
        self.logger.info(f"Mode: {'Select All' if select_all else 'Manual'}")
        self.logger.info(f"Dry Run: {dry_run}")

        # Device Selection
        if select_all:
            devices = self._get_devices_from_location(location)
            device_count = devices.count()
            self.logger.info(f"[DEVICE SELECTION] Found {device_count} devices")
        else:
            device_count = devices.count()
            self.logger.info(f"[DEVICE SELECTION] Manually selected {device_count} devices")

        vlan_room_map = {}

        updated = 0
        skipped = 0
        conflict_count = 0

        # Process each device
        for device in devices:

            self.logger.info(f"\n--- Processing Device: {device.name} ---")
            self.logger.info(f"Location: {device.location}")

            building = self._get_parent(device.location, "building")
            floor = self._get_parent(device.location, "floor")
            room = self._get_parent(device.location, "room")

            if not building or not floor:
                self.logger.warning(
                    f"[SKIP] Device {device.name}: Missing building/floor in hierarchy"
                )
                skipped += 1
                continue

            group_name = f"{building.name} - {floor.name} VLANS"
            vlan_group, created = VLANGroup.objects.get_or_create(name=group_name)

            if created:
                self.logger.info(f"[GROUP CREATED] {group_name}")
            else:
                self.logger.debug(f"[GROUP EXISTS] {group_name}")

            for interface in device.interfaces.all():

                self.logger.debug(f" Interface: {interface.name}")

                vlans = set()

                if interface.untagged_vlan:
                    vlans.add(interface.untagged_vlan)

                tagged = list(interface.tagged_vlans.all())
                vlans.update(tagged)

                if not vlans:
                    self.logger.debug("  No VLANs on this interface")
                    continue

                for vlan in vlans:

                    self.logger.debug(f"  Processing VLAN: {vlan}")

                    # Conflict detection
                    if vlan.id in vlan_room_map:
                        if vlan_room_map[vlan.id] != room.id:
                            conflict_count += 1
                            
                        self.logger.warning(
                            f"[CONFLICT] VLAN {vlan} is used in multiple rooms. "
                            f"Previously seen in Room ID: {vlan_room_map[vlan.id]}, "
                            f"Current Room: {room.name} (Device: {device.name})"
                        )

                    else:
                        vlan_room_map[vlan.id] = room.id

                    changes = []

                    # Location update
                    if vlan.location != device.location:
                        changes.append(
                            f"location: {vlan.location} → {device.location}"
                        )
                        vlan.location = device.location

                    # VLAN group update
                    if vlan.vlan_group != vlan_group:
                        changes.append(
                            f"group: {vlan.vlan_group} → {vlan_group}"
                        )
                        vlan.vlan_group = vlan_group

                    if changes:
                        if not dry_run:
                            vlan.save()

                        self.logger.info(
                            f"[{'DRY-RUN' if dry_run else 'UPDATED'}] VLAN {vlan} | "
                            + " | ".join(changes)
                        )
                        updated += 1
                    else:
                        self.logger.debug(f"  No change required for VLAN {vlan}")
                        skipped += 1

        # Final Summary
        self.logger.info("\n===== JOB SUMMARY =====")
        self.logger.info(f"Total Devices Processed: {device_count}")
        self.logger.info(f"VLANs Updated: {updated}")
        self.logger.info(f"Skipped: {skipped}")
        self.logger.info(f"Conflicts Detected: {conflict_count}")
        self.logger.info("===== JOB END =====")