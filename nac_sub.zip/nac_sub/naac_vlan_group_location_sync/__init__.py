from nautobot.extras.plugins import PluginConfig

__version__ = "1.0.0"


class NaacVlanGroupLocationSyncConfig(PluginConfig):
    """Plugin entry point for VLAN Group & Location Sync."""

    name = "naac_vlan_group_location_sync"
    verbose_name = "NAAC VLAN Group & Location Sync"
    version = __version__
    author = "Your Team"
    description = "Sync VLAN location and group based on device hierarchy"
    base_url = "naac-vlan-group-location-sync"
    required_settings = []
    default_settings = {}
    caching_config = {}

    def ready(self):
        super().ready()

        try:
            from nautobot.extras.models import Job as JobModel, JobQueue
            from nautobot.extras.registry import registry
            from naac_vlan_group_location_sync.jobs import VlanGroupLocationSync

            job_path = "naac_vlan_group_location_sync.jobs.VlanGroupLocationSync"

            # Register job in registry
            registry["jobs"][job_path] = VlanGroupLocationSync

            # Ensure default queue exists
            default_queue, _ = JobQueue.objects.get_or_create(name="default")

            # Register or update job metadata
            JobModel.objects.update_or_create(
                module_name="naac_vlan_group_location_sync.jobs",
                job_class_name="VlanGroupLocationSync",
                defaults={
                    "name": VlanGroupLocationSync.name,
                    "grouping": "VLAN Management",
                    "description": getattr(VlanGroupLocationSync, "description", ""),
                    "installed": True,
                    "enabled": True,
                    "has_sensitive_variables": False,
                    "default_job_queue": default_queue,
                },
            )

            print("[NAAC VLAN Sync] Job registered successfully.")

        except Exception as exc:
            print(f"[NAAC VLAN Sync] Error loading jobs: {exc}")


config = NaacVlanGroupLocationSyncConfig
