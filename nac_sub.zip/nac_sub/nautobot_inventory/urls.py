from django.urls import path

from . import views

app_name = 'nautobot_inventory'

urlpatterns = [
    # Main discovery page
    path('', views.InventoryDiscoveryHomeView.as_view(), name='discovery_home'),
    
    # API endpoints
    path('api/config/', views.PluginConfigAPIView.as_view(), name='plugin_config'),
    path('api/start-discovery/', views.StartDiscoveryAPIView.as_view(), name='start_discovery'),
    path('api/stop-discovery/<uuid:session_id>/', views.StopDiscoveryAPIView.as_view(), name='stop_discovery'),
    path('api/status/<uuid:session_id>/', views.DiscoveryStatusAPIView.as_view(), name='discovery_status'),
    path('api/update-selection/<uuid:session_id>/', views.UpdateDeviceSelectionAPIView.as_view(), name='update_selection'),
    path('api/prepare-onboarding/<uuid:session_id>/', views.PrepareOnboardingAPIView.as_view(), name='prepare_onboarding'),
    path('api/device-detail/<uuid:session_id>/<str:device_ip>/', views.DeviceDetailAPIView.as_view(), name='device_detail'),
    path('api/topology/<uuid:session_id>/', views.DiscoveryTopologyAPIView.as_view(), name='discovery_topology'),
    path('api/export-csv/<uuid:session_id>/', views.ExportDevicesCSVAPIView.as_view(), name='export_csv'),
    path('api/delete-session/<uuid:session_id>/', views.DeleteDiscoverySessionAPIView.as_view(), name='delete_session'),
    
    # New API endpoints for device onboarding
    path('api/device-onboarding-data/<uuid:session_id>/<str:device_ip>/', views.GetDeviceOnboardingDataAPIView.as_view(), name='device_onboarding_data'),
    path('api/onboarding-job-status/<uuid:session_id>/', views.OnboardingJobStatusAPIView.as_view(), name='onboarding_job_status'),
    path('api/dual-job-status/<uuid:session_id>/', views.OnboardingJobStatusAPIView.as_view(), name='dual_job_status'),
    path('api/confirm-duplicate-onboarding/<uuid:session_id>/', views.ConfirmDuplicateOnboardingAPIView.as_view(), name='confirm_duplicate_onboarding'),
    
    # Bulk Onboarding API endpoints
    path('api/prepare-bulk-onboarding/<uuid:session_id>/', views.PrepareBulkOnboardingAPIView.as_view(), name='prepare_bulk_onboarding'),
    path('api/bulk-onboarding-status/<uuid:session_id>/', views.BulkOnboardingStatusAPIView.as_view(), name='bulk_onboarding_status'),
    path('api/trigger-network-data-job/<uuid:session_id>/', views.TriggerNetworkDataJobAPIView.as_view(), name='trigger_network_data_job'),
    path('api/retry-batch/<uuid:session_id>/<int:batch_number>/', views.RetryBatchAPIView.as_view(), name='retry_batch'),
    path('api/retry-failed-devices/<uuid:session_id>/', views.RetryFailedDevicesAPIView.as_view(), name='retry_failed_devices'),
    
    # Custom Credentials Management API endpoints
    path('api/device-credentials/<uuid:session_id>/<str:device_ip>/', views.GetDeviceCredentialsAPIView.as_view(), name='device_credentials'),
    path('api/save-device-credentials/<uuid:session_id>/<str:device_ip>/', views.SaveDeviceCredentialsAPIView.as_view(), name='save_device_credentials'),
    path('api/test-device-credentials/<uuid:session_id>/<str:device_ip>/', views.TestDeviceCredentialsAPIView.as_view(), name='test_device_credentials'),
    path('api/test-device-type-detection/<uuid:session_id>/<str:device_ip>/', views.TestDeviceTypeDetectionAPIView.as_view(), name='test_device_type_detection'),
    path('api/retry-device/<uuid:session_id>/<str:device_ip>/', views.RetryDeviceDiscoveryAPIView.as_view(), name='retry_device'),
    path('api/bulk-retry-devices/<uuid:session_id>/', views.BulkRetryDevicesAPIView.as_view(), name='bulk_retry_devices'),
    path('api/bulk-assign-credentials/<uuid:session_id>/', views.BulkAssignCredentialsAPIView.as_view(), name='bulk_assign_credentials'),
    
    # Bulk Location Management API endpoints
    path('api/bulk-location/<uuid:session_id>/', views.BulkLocationUpdateAPIView.as_view(), name='bulk_location_update'),
    
    # Management pages
    path('sessions/', views.DiscoverySessionListView.as_view(), name='session_list'),
    path('sessions/<uuid:pk>/', views.DiscoverySessionDetailView.as_view(), name='session_detail'),
]
