/**
 * Device Detail Manager - Reusable Utility
 * Handles device detail modal display and interaction
 * Can be used independently by any page that includes the device detail modal template
 */

class DeviceDetailManager {
    constructor(sessionId, deviceDetailsUrlTemplate) {
        this.sessionId = sessionId;
        this.deviceDetailsUrlTemplate = deviceDetailsUrlTemplate;
        this.currentDeviceIp = null;
        this.nautobotData = null;
        
        // Initialize modal event handlers
        this.initModalHandlers();
    }

    /**
     * Initialize modal event handlers
     */
    initModalHandlers() {
        const modal = document.getElementById('deviceDetailModal');
        if (modal) {
            // Close modal when clicking outside
            modal.addEventListener('click', (e) => {
                if (e.target === modal) {
                    this.closeModal();
                }
            });

            // Close modal on Escape key
            document.addEventListener('keydown', (e) => {
                if (e.key === 'Escape' && modal.style.display === 'flex') {
                    this.closeModal();
                }
            });
        }
    }

    /**
     * Get CSRF token from cookies or form
     */
    getCsrfToken() {
        // Try to get from cookie
        const cookieValue = document.cookie
            .split('; ')
            .find(row => row.startsWith('csrftoken='))
            ?.split('=')[1];
        
        if (cookieValue) return cookieValue;

        // Try to get from form input
        const csrfInput = document.querySelector('[name=csrfmiddlewaretoken]');
        if (csrfInput) return csrfInput.value;

        // Try to get from meta tag
        const metaTag = document.querySelector('meta[name=csrf-token]');
        if (metaTag) return metaTag.content;

        return '';
    }

    /**
     * Update session ID (for when session starts after initialization)
     */
    updateSessionId(newSessionId) {
        if (newSessionId && newSessionId !== 'temp-session') {
            this.sessionId = newSessionId;
        }
    }

    /**
     * Build device details URL from template
     */
    buildDeviceDetailsUrl(deviceIp) {
        if (!this.deviceDetailsUrlTemplate) {
            // Fallback: construct URL manually
            return `/plugins/inventory/api/device-detail/${this.sessionId}/${encodeURIComponent(deviceIp)}/`;
        }
        
        // Replace placeholders in template
        return this.deviceDetailsUrlTemplate
            .replace('00000000-0000-0000-0000-000000000000', this.sessionId)
            .replace('0.0.0.0', encodeURIComponent(deviceIp));
    }

    /**
     * Show device detail modal
     */
    showDeviceDetail(deviceIp, deviceHostname = null) {
        this.currentDeviceIp = deviceIp;
        
        const modal = document.getElementById('deviceDetailModal');
        const titleEl = document.getElementById('deviceDetailTitle');
        const contentEl = document.getElementById('deviceDetailContent');
        
        if (!modal || !titleEl || !contentEl) {
            console.error('Device detail modal elements not found');
            if (window.commonPopup) {
                window.commonPopup.alert('Error', 'Device detail modal not found. Please refresh the page.', 'error');
            }
            return;
        }
        
        // Set title
        titleEl.textContent = `${deviceHostname || deviceIp} - Device Details`;
        
        // Show loading state
        contentEl.innerHTML = '<div style="text-align: center; padding: 20px;"><i class="fas fa-spinner fa-spin"></i> Loading device details...</div>';
        modal.style.display = 'flex';
        
        // Fetch detailed device information
        const deviceDetailsUrl = this.buildDeviceDetailsUrl(deviceIp);
        
        fetch(deviceDetailsUrl, {
            method: 'GET',
            credentials: 'same-origin',
            headers: {
                'X-CSRFToken': this.getCsrfToken(),
                'Content-Type': 'application/json',
            }
        })
        .then(async response => {
            const contentType = response.headers.get('content-type');
            if (!response.ok) {
                let errorMessage = `HTTP ${response.status}: ${response.statusText}`;
                if (contentType && contentType.includes('application/json')) {
                    const errorData = await response.json();
                    errorMessage = errorData.message || errorMessage;
                }
                throw new Error(errorMessage);
            }
            
            if (!contentType || !contentType.includes('application/json')) {
                throw new Error('Server returned non-JSON response. This might be a server error or authentication issue.');
            }
            
            return response.json();
        })
        .then(data => {
            if (data.status === 'success') {
                this.renderDeviceDetails(data.device);
            } else {
                contentEl.innerHTML = `
                    <div style="color: var(--error-color); text-align: center; padding: 20px;">
                        <i class="fas fa-exclamation-triangle"></i><br/>
                        Failed to load device details: ${data.message || 'Unknown error'}
                    </div>
                `;
            }
        })
        .catch(error => {
            console.error('Error fetching device details:', error);
            contentEl.innerHTML = `
                <div style="color: var(--error-color); text-align: center; padding: 20px;">
                    <i class="fas fa-exclamation-triangle"></i><br/>
                    <strong>Error loading device details</strong><br/>
                    <span style="font-size: 0.9em; margin-top: 10px; display: block;">${error.message}</span>
                </div>
            `;
        });
    }

    /**
     * Render device details in modal
     * Populates all tabs with device data
     */
    renderDeviceDetails(device) {
        const contentEl = document.getElementById('deviceDetailContent');
        if (!contentEl) return;
        
        // Use the device detail template
        const templateEl = document.getElementById('deviceDetailTemplate');
        if (templateEl) {
            // Clone the template
            const template = templateEl.content.cloneNode(true);
            
            // Populate all tabs
            this.populateOverviewTab(template, device);
            this.populateNetworkInterfacesTab(template, device);
            this.populateTopologyNeighborsTab(template, device);
            this.populateCommandOutputs(template, device);
            
            contentEl.innerHTML = '';
            contentEl.appendChild(template);
            
            // Setup tab switching after DOM insertion
            this.setupTabSwitching(contentEl);
            
            // Load Nautobot dropdown data if available
            this.loadNautobotDropdownData();
        } else {
            // Fallback to basic display
            contentEl.innerHTML = `
                <div class="device-info">
                    <h4>${device.hostname || device.ip_address}</h4>
                    <p><strong>IP:</strong> ${device.ip_address}</p>
                    <p><strong>Model:</strong> ${device.model || 'Unknown'}</p>
                    <p><strong>Platform:</strong> ${device.platform || 'Unknown'}</p>
                    <p><strong>Status:</strong> ${device.connection_status || 'Unknown'}</p>
                </div>
            `;
        }
    }

    /**
     * ============================================================
     * TAB 1: OVERVIEW TAB - Device identity, connection status, quick stats
     * ============================================================
     */
    populateOverviewTab(template, device) {
        const setFieldValue = this._createFieldSetter(template);
        const formatDateTime = this._formatDateTime;
        const onboardingInfo = device.onboarding_info || {};

        // Basic device identity
        setFieldValue('hostname', device.hostname || device.ip_address);
        setFieldValue('ip_address', device.ip_address);
        setFieldValue('model', device.model, 'Unknown');
        setFieldValue('platform', device.platform, 'Unknown');
        setFieldValue('os_version', device.os_version, 'Unknown');
        setFieldValue('serial_number', device.serial_number, 'Unknown');
        
        // Location information
        const sessionInfo = device.session_info || {};
        setFieldValue('location_name', sessionInfo.location || 'Not Specified');
        
        // Connection status section
        setFieldValue('discovered_at', formatDateTime(device.discovered_at));
        setFieldValue('discovery_depth', device.discovery_depth || 0);
        setFieldValue('connection_status', device.connection_status || 'Unknown');
        
        // Update connection status badge
        this._updateStatusBadge(template, 'connection_status', device.connection_status);
        
        // Quick stats cards
        this._populateQuickStats(template, device);
        
        // Device role and configuration
        setFieldValue('device_role_name', onboardingInfo.device_role || 'Network Device');
        setFieldValue('namespace', 'Global');
        setFieldValue('secrets_group_name', 'From Discovery Session');
        
        // Status information
        setFieldValue('device_status_name', onboardingInfo.status || 'Active');
        setFieldValue('interface_status_name', 'Active');
        setFieldValue('ip_address_status_name', 'Active');
        
        // Update status badges
        this._updateStatusBadge(template, 'device_status_name', onboardingInfo.status || 'Active');
        this._updateStatusBadge(template, 'interface_status_name', 'Active');
        this._updateStatusBadge(template, 'ip_address_status_name', 'Active');
        this.populateStackInformation(template, device);
        
        // Technical data
        this.populateTechnicalData(template, device);
    }

    /**
     * ============================================================
     * TAB 2: NETWORK & INTERFACES - Network config, interfaces, port types
     * ============================================================
     */
    populateNetworkInterfacesTab(template, device) {
        const setFieldValue = this._createFieldSetter(template);
        
        // Network configuration section
        setFieldValue('port', 22);
        setFieldValue('timeout', '30s');
        setFieldValue('set_mgmt_only', 'No');
        setFieldValue('update_devices_without_primary_ip', 'No');
        
        // Interface analysis
        this.populateInterfaceAnalysis(template, device);
    }

    /**
     * ============================================================
     * TAB 3: TOPOLOGY & NEIGHBORS - Neighbors, VLANs, trunks
     * ============================================================
     */
    populateTopologyNeighborsTab(template, device) {
        // Populate neighbors
        this.populateNeighbors(template, device);
        
        // Populate VLANs and Trunk Details
        const interfaceAnalysis = device.interface_analysis || {};
        const interfaces = interfaceAnalysis.interfaces || [];
        this.populateVlanInfo(template, interfaceAnalysis, interfaces);
        this.populateTrunkDetails(template, interfaceAnalysis);
    }

    /**
     * ============================================================
     * TAB 4: COMMAND OUTPUTS - Raw command outputs
     * ============================================================
     */
    populateCommandOutputs(template, device) {
        const commandOutputsContainer = template.querySelector('#commandOutputsContainer');
        if (!commandOutputsContainer) return;

        let outputsContent = '';
        
        // Get command outputs from cleaned API structure
        const commandOutputs = device.command_outputs || {};

        // Add command outputs if available
        if (Object.keys(commandOutputs).length > 0) {
            Object.entries(commandOutputs).forEach(([command, output]) => {
                // Format command name for display
                const displayName = command.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase());
                
                outputsContent += `
                    <div class="info-card full-width">
                        <div class="info-card-header">
                            <h5><i class="fas fa-terminal"></i> ${displayName}</h5>
                        </div>
                        <div class="info-card-body">
                            <div class="command-output">
                                <pre class="command-pre">${this._escapeHtml(output || 'No output available')}</pre>
                            </div>
                        </div>
                    </div>
                `;
            });
        }
        
        // If no outputs, show message
        if (!outputsContent) {
            outputsContent = `
                <div class="info-card full-width">
                    <div class="info-card-body">
                        <div style="text-align: center; padding: 20px; color: var(--text-muted);">
                            <i class="fas fa-info-circle"></i><br/>
                            No command outputs available
                        </div>
                    </div>
                </div>
            `;
        }

        commandOutputsContainer.innerHTML = outputsContent;
    }

    /**
     * ============================================================
     * HELPER FUNCTIONS - Reusable utilities
     * ============================================================
     */
    
    /**
     * Filter interfaces to only include physical interfaces
     */
    _filterPhysicalInterfaces(interfaces) {
        if (!interfaces || !Array.isArray(interfaces)) {
            return [];
        }
        
        return interfaces.filter(iface => {
            if (!iface.name) return false;
            
            const interfaceName = iface.name.toLowerCase();
            
            // Exclude virtual/logical interfaces
            const virtualPrefixes = [
                'vlan',           // VLAN interfaces
                'loopback',       // Loopback interfaces
                'lo',             // Loopback (short form)
                'tunnel',         // Tunnel interfaces
                'null',           // Null interfaces
                'mgmt',           // Management interfaces (often virtual)
                'management',     // Management interfaces
                'port-channel',   // Port channels/LAG
                'lag',            // Link aggregation
                'bond',           // Bonded interfaces
                'bridge',         // Bridge interfaces
                'br',             // Bridge (short form)
                'virtual',        // Virtual interfaces
                'veth',           // Virtual ethernet
                'tap',            // TAP interfaces
                'tun',            // TUN interfaces
                'dummy',          // Dummy interfaces
                'sit',            // IPv6-in-IPv4 tunnel
                'gre',            // GRE tunnel
                'ipip',           // IP-in-IP tunnel
                'ppp',            // PPP interfaces
                'slip',           // SLIP interfaces
                'serial',         // Serial interfaces (often logical)
                'dialer',         // Dialer interfaces
                'bvi',            // Bridge Virtual Interface
                'svi',            // Switch Virtual Interface
                'irb',            // Integrated Routing and Bridging
                'vti',            // Virtual Tunnel Interface
                'nve',            // Network Virtualization Endpoint
                'vtep'            // VXLAN Tunnel Endpoint
            ];
            
            // Check if interface name starts with any virtual prefix
            let isVirtual = virtualPrefixes.some(prefix => 
                interfaceName.startsWith(prefix)
            );
            
            // Special case: Check for Port-channel (Po) more precisely
            // Po1, Po2, etc. are virtual, but port1/1 is physical
            if (interfaceName.startsWith('po') && /^po\d+$/.test(interfaceName)) {
                isVirtual = true;
            }
            
            if (isVirtual) return false;
            
            // Include physical interface types
            const physicalPrefixes = [
                'gigabitethernet',    // Cisco GigE
                'gige',               // GigE short form
                'gi',                 // GigE very short form
                'fastethernet',       // Cisco FastEthernet
                'fa',                 // FastEthernet short form
                'ethernet',           // Generic Ethernet
                'eth',                // Ethernet short form
                'tengigabitethernet', // 10 GigE
                'te',                 // 10 GigE short form
                'twentyfivegige',     // 25 GigE
                'fortygige',          // 40 GigE
                'hundredgige',        // 100 GigE
                'fourhundredgige',    // 400 GigE
                'xe',                 // 10 GigE (Juniper)
                'ge-',                // Juniper GigE
                'fe-',                // Juniper FastEthernet
                'et-',                // Juniper 10/40/100 GigE
                'swp',                // Switch port (Cumulus)
                'ens',                // Ethernet network segment
                'enp',                // Ethernet network PCI
                'eno',                // Ethernet network onboard
                'em',                 // Ethernet em (FreeBSD)
                'igb',                // Intel Gigabit
                'ixgbe',              // Intel 10 Gigabit
                'e1000',              // Intel Ethernet
                'vmnic',              // VMware physical NIC
                'uplink'              // Uplink ports
            ];
            
            // Check if interface name starts with any physical prefix
            const isPhysical = physicalPrefixes.some(prefix => 
                interfaceName.startsWith(prefix)
            );
            
            // If we can identify it as physical, include it
            if (isPhysical) return true;
            
            // For unknown interface types, use additional heuristics
            // Include interfaces with numeric patterns that suggest physical ports
            const numericPattern = /^[a-z]+\d+\/\d+/i; // e.g., "port1/1", "int0/1"
            if (numericPattern.test(interfaceName)) return true;
            
            // Include simple numeric interfaces (e.g., "1", "2", "3")
            const simpleNumeric = /^\d+$/;
            if (simpleNumeric.test(interfaceName)) return true;
            
            // Default to excluding unknown interface types to be conservative
            return false;
        });
    }
    
    /**
     * Creates a field setter function for template elements
     */
    _createFieldSetter(template) {
        return (fieldName, value, defaultValue = 'N/A') => {
            const elements = template.querySelectorAll(`[data-field="${fieldName}"]`);
            elements.forEach(el => {
                if (el) el.textContent = value || defaultValue;
            });
        };
    }

    /**
     * Formats a date/time string
     */
    _formatDateTime(dateString) {
            if (!dateString) return 'N/A';
            try {
                return new Date(dateString).toLocaleString();
            } catch (e) {
                return dateString;
            }
    }

    /**
     * Escapes HTML in strings
     */
    _escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }

    /**
     * Updates status badge styling
     */
    _updateStatusBadge(template, fieldName, value) {
        const elements = template.querySelectorAll(`[data-field="${fieldName}"]`);
        elements.forEach(el => {
            if (el && el.classList.contains('status-badge')) {
                el.classList.remove('status-unknown', 'status-success', 'status-error', 'status-warning');
                const normalizedValue = (value || '').toLowerCase();
                if (normalizedValue === 'connected' || normalizedValue === 'active') {
                    el.classList.add('status-success');
                } else if (normalizedValue === 'failed' || normalizedValue === 'error') {
                    el.classList.add('status-error');
                } else if (value && value !== 'Unknown') {
                    el.classList.add('status-warning');
                } else {
                    el.classList.add('status-unknown');
                }
            }
        });
    }

    /**
     * Populates quick statistics cards in overview
     */
    _populateQuickStats(template, device) {
        const interfaceAnalysis = device.interface_analysis || {};
        
        // Get interfaces from multiple possible sources
        let interfaces = interfaceAnalysis.interfaces || [];
        if (interfaces.length === 0 && device.interfaces) {
            interfaces = device.interfaces;
        }
        
        // Use the physical interface count from the API if available, otherwise filter client-side
        let physicalInterfaceCount;
        if (device.physical_interface_count !== undefined) {
            physicalInterfaceCount = device.physical_interface_count;
            console.log('physicalInterfaceCount', physicalInterfaceCount);
            
        } else {
            // Fallback to client-side filtering for backward compatibility
            const physicalInterfaces = this._filterPhysicalInterfaces(interfaces);
            physicalInterfaceCount = physicalInterfaces.length;
            console.log('physicalInterfaceCount', physicalInterfaceCount);
            
        }
        
        // Get neighbors - check both CDP and LLDP
        let neighbors = device.neighbors || [];
        if (neighbors.length === 0) {
            const cdpNeighbors = device.cdp_neighbors || [];
            const lldpNeighbors = device.lldp_neighbors || [];
            neighbors = [...cdpNeighbors, ...lldpNeighbors];
        }
        
        // Get VLANs from interface analysis
        let vlans = interfaceAnalysis.vlans || [];
        
        // If no VLANs in interface_analysis, count VLAN interfaces
        if (vlans.length === 0 && interfaces.length > 0) {
            const vlanInterfaces = interfaces.filter(iface => 
                iface.name && iface.name.toLowerCase().startsWith('vlan')
            );
            vlans = vlanInterfaces;
        }
        
        const setFieldValue = this._createFieldSetter(template);
        
        // Set quick stat values - use physical interfaces count only
        setFieldValue('quick_stat_interfaces', physicalInterfaceCount || 0);
        setFieldValue('quick_stat_neighbors', neighbors.length || 0);
        setFieldValue('quick_stat_vlans', vlans.length || 0);
    }

    /**
     * Populate stack information if device is a stack
     */
    populateStackInformation(template, device) {
        const stackInfoContainer = template.querySelector('#stackInfoContainer');
        if (!stackInfoContainer) return;

        // Check if device is a stack
        const deviceData = device.device_data || {};
        const isStack = deviceData.is_stack || false;
        const stackInfo = deviceData.stack_info || {};

        if (!isStack || !stackInfo.is_stack) {
            stackInfoContainer.style.display = 'none';
            return;
        }

        // Show stack container
        stackInfoContainer.style.display = 'block';

        // Populate stack summary fields
        const setFieldValue = this._createFieldSetter(template);
        setFieldValue('stack_total_members', stackInfo.total_members || 0);
        setFieldValue('stack_master_number', stackInfo.master_switch_number || 'N/A');
        setFieldValue('stack_standby_number', stackInfo.standby_switch_number || 'N/A');
        setFieldValue('stack_mode', stackInfo.stack_mode || 'N/A');

        // Populate stack members table
        const stackMembersTableBody = template.querySelector('#stackMembersTableBody');
        if (stackMembersTableBody && stackInfo.stack_members) {
            let stackMembersHtml = '';
            
            stackInfo.stack_members.forEach(member => {
                const roleClass = member.role === 'master' ? 'stack-role-master' : 
                                  member.role === 'standby' ? 'stack-role-standby' : 
                                  'stack-role-member';
                const stateClass = member.state === 'ready' ? 'stack-state-ready' : 'stack-state-other';
                
                stackMembersHtml += `
                    <tr>
                        <td>${member.switch_number || 'N/A'}</td>
                        <td><span class="stack-role-badge ${roleClass}">${(member.role || 'member').toUpperCase()}</span></td>
                        <td>${member.model || 'Unknown'}</td>
                        <td>${member.serial_number || 'Unknown'}</td>
                        <td>${member.priority || 'N/A'}</td>
                        <td><span class="stack-state-badge ${stateClass}">${(member.state || 'unknown').toUpperCase()}</span></td>
                        <td><code>${member.mac_address || 'N/A'}</code></td>
                        <td>${member.sw_version || 'Unknown'}</td>
                    </tr>
                `;
            });
            
            stackMembersTableBody.innerHTML = stackMembersHtml;
        }

        // Check for stack member job status
        if (device.stack_member_job_id) {
            const stackJobStatus = template.querySelector('#stackMemberJobStatus');
            if (stackJobStatus) {
                stackJobStatus.style.display = 'block';
                
                const messageEl = stackJobStatus.querySelector('[data-field="stack_job_message"]');
                const detailsEl = stackJobStatus.querySelector('[data-field="stack_job_details"]');
                
                if (messageEl) {
                    if (device.stack_member_job_id.startsWith('stack_created_')) {
                        const membersCount = device.stack_member_job_id.replace('stack_created_', '').replace('_members', '');
                        messageEl.innerHTML = `<i class="fas fa-check-circle text-success"></i> Stack members created successfully (${membersCount} members)`;
                    } else {
                        messageEl.innerHTML = `<i class="fas fa-spinner fa-spin"></i> Stack member creation in progress...`;
                    }
                }
                
                if (detailsEl && stackInfo.virtual_chassis) {
                    detailsEl.innerHTML = `Virtual Chassis: <strong>${stackInfo.virtual_chassis}</strong>`;
                }
            }
        }
    }

    /**
     * Populate technical data sections (facts, interfaces, neighbors)
     */
    populateTechnicalData(template, device) {
        const technicalDataContainer = template.querySelector('#technicalDataContainer');
        if (!technicalDataContainer) return;

        let technicalContent = '';
        
        // Get device data (handle nested structure)
        const deviceData = device.device_data || {};
        const nestedDeviceData = deviceData.device_data || {};

        // Add device facts if available - check multiple sources
        const deviceFacts = device.facts || deviceData.facts || nestedDeviceData.facts || {};
        if (Object.keys(deviceFacts).length > 0) {
            technicalContent += `
                <div class="info-card full-width">
                    <div class="info-card-header">
                        <h5><i class="fas fa-info-circle"></i> Device Facts</h5>
                    </div>
                    <div class="info-card-body">
                        <div class="facts-grid">
            `;
            
            Object.entries(deviceFacts).forEach(([key, value]) => {
                technicalContent += `
                    <div class="info-item">
                        <span class="info-label">${key.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}</span>
                        <span class="info-value">${value || 'N/A'}</span>
                    </div>
                `;
            });
            
            technicalContent += `
                        </div>
                    </div>
                </div>
            `;
        }

        technicalDataContainer.innerHTML = technicalContent;
    }

    /**
     * Populate interface analysis data
     */
    populateInterfaceAnalysis(template, device) {
        // Get interface analysis data from device
        const interfaceAnalysis = device.interface_analysis || {};
        
        // Get interfaces from interface_analysis if available, otherwise from device
        let interfaces = interfaceAnalysis.interfaces || [];
        if (interfaces.length === 0 && device.interfaces) {
            interfaces = device.interfaces;
        }

        // Populate port summary counts
        this.populatePortSummary(template, interfaceAnalysis, interfaces);
        
        // Populate port type breakdown
        this.populatePortTypeBreakdown(template, interfaceAnalysis, interfaces);
        
        // Populate interface details table
        this.populateInterfaceTable(template, interfaces);
    }

    /**
     * Populate port summary statistics
     */
    populatePortSummary(template, interfaceAnalysis, interfaces) {
        const setFieldValue = (fieldName, value) => {
            const elements = template.querySelectorAll(`[data-field="${fieldName}"]`);
            elements.forEach(el => {
                if (el) el.textContent = value || '0';
            });
        };

        // Filter to only physical interfaces for counts
        const physicalInterfaces = this._filterPhysicalInterfaces(interfaces);

        // Calculate interface counts using only physical interfaces
        const totalInterfaces = physicalInterfaces.length;
        const activeInterfaces = physicalInterfaces.filter(iface => 
            (iface.admin_status === 'up' && iface.oper_status === 'up') || 
            (iface.status === 'up')
        ).length;
        const downInterfaces = physicalInterfaces.filter(iface => 
            iface.oper_status === 'down' || iface.status === 'down'
        ).length;
        const disabledInterfaces = physicalInterfaces.filter(iface => 
            iface.admin_status === 'down'
        ).length;

        // Set values
        setFieldValue('total_interfaces', totalInterfaces);
        setFieldValue('active_interfaces', activeInterfaces);
        setFieldValue('down_interfaces', downInterfaces);
        setFieldValue('disabled_interfaces', disabledInterfaces);
    }

    /**
     * Populate port type breakdown
     */
    populatePortTypeBreakdown(template, interfaceAnalysis, interfaces) {
        const setFieldValue = (fieldName, value) => {
            const elements = template.querySelectorAll(`[data-field="${fieldName}"]`);
            elements.forEach(el => {
                if (el) el.textContent = value || '0';
            });
        };

        // Try to use interface analysis port counts first
        const portCounts = interfaceAnalysis.port_counts || {};
        
        if (portCounts.ethernet_ports !== undefined) {
            setFieldValue('ethernet_count', portCounts.ethernet_ports || 0);
            setFieldValue('fiber_count', portCounts.fiber_ports || 0);
            setFieldValue('mgmt_count', portCounts.mgmt_ports || 0);
            setFieldValue('poe_count', interfaceAnalysis.poe_ports || 0);
            setFieldValue('trunk_count', portCounts.trunk_ports || 0);
            setFieldValue('access_count', portCounts.access_ports || 0);
        } else if (interfaceAnalysis.ethernet_count !== undefined) {
            setFieldValue('ethernet_count', interfaceAnalysis.ethernet_count || 0);
            setFieldValue('fiber_count', interfaceAnalysis.fiber_count || 0);
            setFieldValue('mgmt_count', interfaceAnalysis.mgmt_count || 0);
            setFieldValue('poe_count', interfaceAnalysis.poe_capable_count || 0);
            setFieldValue('trunk_count', interfaceAnalysis.trunk_ports || 0);
            setFieldValue('access_count', interfaceAnalysis.access_ports || 0);
        } else if (interfaces && interfaces.length > 0) {
            // Calculate port type counts from physical interfaces only
            const physicalInterfaces = this._filterPhysicalInterfaces(interfaces);
            let ethernetCount = 0;
            let fiberCount = 0;
            let mgmtCount = 0;
            let poeCount = 0;
            let trunkCount = 0;
            let accessCount = 0;

            physicalInterfaces.forEach(iface => {
                const interfaceName = (iface.name || '').toLowerCase();
                const interfaceType = (iface.type || '').toLowerCase();
                
                // Count Ethernet interfaces
                if (interfaceName.includes('gigabitethernet') || interfaceName.includes('gige') || 
                    interfaceName.includes('fastethernet') || interfaceName.includes('fa') ||
                    interfaceName.includes('tengigabitethernet') || interfaceName.includes('te') ||
                    interfaceType.includes('ethernet')) {
                    ethernetCount++;
                }
                
                // Count Fiber interfaces
                if (interfaceName.includes('tengigabit') || interfaceName.includes('twentyfivegig') || 
                    interfaceName.includes('fortygig') || interfaceName.includes('hundredgig') ||
                    interfaceType.includes('fiber') || interfaceType.includes('sfp')) {
                    fiberCount++;
                }
                
                // Count Management interfaces
                if (interfaceName.includes('mgmt') || interfaceName.includes('management') ||
                    interfaceType.includes('management')) {
                    mgmtCount++;
                }
                
                // Count PoE capable
                if (interfaceName.includes('fastethernet') || interfaceName.includes('gigabitethernet')) {
                    poeCount++;
                }
                
                // Count trunk/access ports
                if (iface.port_type === 'trunk' || (iface.vlan_id && iface.vlan_id > 1)) {
                    trunkCount++;
                } else if (iface.port_type === 'access' || iface.vlan_id === 1) {
                    accessCount++;
                }
            });

            setFieldValue('ethernet_count', ethernetCount);
            setFieldValue('fiber_count', fiberCount);
            setFieldValue('mgmt_count', mgmtCount);
            setFieldValue('poe_count', poeCount);
            setFieldValue('trunk_count', trunkCount);
            setFieldValue('access_count', accessCount);
        } else {
            // Fallback to zeros
            setFieldValue('ethernet_count', 0);
            setFieldValue('fiber_count', 0);
            setFieldValue('mgmt_count', 0);
            setFieldValue('poe_count', 0);
            setFieldValue('trunk_count', 0);
            setFieldValue('access_count', 0);
        }
    }

    /**
     * Populate interface details table
     */
    populateInterfaceTable(template, interfaces) {
        const tableBody = template.querySelector('#interfaceTableBody');
        if (!tableBody) return;

        if (!interfaces || interfaces.length === 0) {
            tableBody.innerHTML = '<tr><td colspan="9" style="text-align: center; padding: 20px; color: var(--text-muted);">No interfaces found</td></tr>';
            return;
        }

        let tableContent = '';
        
        interfaces.forEach(iface => {
            const statusClass = this.getInterfaceStatusClass(iface.admin_status, iface.oper_status, iface.status);
            const statusText = iface.admin_status && iface.oper_status 
                ? `${iface.admin_status}/${iface.oper_status}` 
                : (iface.status || 'unknown/unknown');
            const speed = iface.speed ? `${iface.speed} Mbps` : 'N/A';
            const vlan = iface.vlan_id || iface.native_vlan || 'N/A';
            
            // Show IP address if available
            const ipAddress = iface.ip_address || 'unassigned';
            const ipDisplay = ipAddress === 'unassigned' ? 'No IP' : ipAddress;
            
            // Show method and protocol if available
            const method = iface.method || 'N/A';
            const protocol = iface.protocol || 'N/A';
            
            tableContent += `
                <tr>
                    <td><strong>${iface.name || 'Unknown'}</strong></td>
                    <td><span class="interface-status ${statusClass}">${statusText}</span></td>
                    <td>${iface.type || 'Unknown'}</td>
                    <td>${speed}</td>
                    <td>${vlan}</td>
                    <td>${ipDisplay}</td>
                    <td>${method}</td>
                    <td>${protocol}</td>
                    <td>${iface.description || 'No description'}</td>
                </tr>
            `;
        });

        tableBody.innerHTML = tableContent;
    }

    /**
     * Get CSS class for interface status
     */
    getInterfaceStatusClass(adminStatus, operStatus, status) {
        if (adminStatus === 'up' && operStatus === 'up') return 'up';
        if (status === 'up') return 'up';
        if (operStatus === 'down' || status === 'down') return 'down';
        if (adminStatus === 'down') return 'disabled';
        return 'unknown';
    }

    /**
     * Populate VLAN information
     */
    populateVlanInfo(template, interfaceAnalysis, interfaces) {
        const vlanContainer = template.querySelector('#vlanInfoContainer');
        if (!vlanContainer) return;

        // First try to get VLANs from interface_analysis.vlans
        let vlans = interfaceAnalysis.vlans || [];
        
        // If no VLANs in interface_analysis, extract from interfaces
        if (vlans.length === 0) {
            const vlanMap = new Map();
            
            interfaces.forEach(iface => {
                // Look for VLAN interfaces (Vlan1, Vlan89, etc.)
                if (iface.name && iface.name.startsWith('Vlan')) {
                    const vlanId = iface.name.replace('Vlan', '');
                    if (vlanId && !isNaN(vlanId)) {
                        vlanMap.set(vlanId, {
                            id: vlanId,
                            name: iface.name,
                            status: iface.status || iface.oper_status || 'unknown',
                            protocol: iface.protocol || 'unknown',
                            description: iface.description || ''
                        });
                    }
                }
            });
            
            vlans = Array.from(vlanMap.values());
        }

        if (vlans.length === 0) {
            vlanContainer.innerHTML = '<p style="text-align: center; color: var(--text-muted); padding: 20px;">No VLAN information available</p>';
            return;
        }

        let vlanContent = '<div class="vlan-grid">';
        
        vlans.forEach(vlan => {
            const statusClass = vlan.status === 'up' ? 'status-up' : 'status-down';
            vlanContent += `
                <div class="vlan-card">
                    <div class="vlan-card-header">
                        <div class="vlan-id">${vlan.name}</div>
                        <div class="vlan-status ${statusClass}">
                            <i class="fas fa-circle"></i> ${vlan.status}
                        </div>
                    </div>
                    <div class="vlan-details">
                        Protocol: ${vlan.protocol}<br>
                        ${vlan.description ? `Description: ${vlan.description}` : ''}
                    </div>
                </div>
            `;
        });
        
        vlanContent += '</div>';
        vlanContainer.innerHTML = vlanContent;
    }

    /**
     * Populate trunk port details table
     */
    populateTrunkDetails(template, interfaceAnalysis) {
        const trunkPorts = interfaceAnalysis.trunk_ports || [];
        const trunkDetails = interfaceAnalysis.trunk_details || {};
        
        const trunkContainer = template.querySelector('#trunkDetailsContainer');
        if (!trunkContainer) return;
        
        if (trunkPorts.length === 0 && (!trunkDetails || Object.keys(trunkDetails).length === 0)) {
            trunkContainer.innerHTML = '<p style="color: var(--text-muted); text-align: center; padding: 20px;"><i class="fas fa-info-circle"></i> No trunk ports configured on this device</p>';
            return;
        }
        
        // If trunkPorts is an array, use it; otherwise use trunkDetails keys
        const ports = Array.isArray(trunkPorts) ? trunkPorts : Object.keys(trunkDetails);
        
        let trunkContent = `
            <div class="trunk-table-container" style="overflow-x: auto;">
                <table class="trunk-table" style="width: 100%; border-collapse: collapse;">
                    <thead>
                        <tr style="background-color: var(--sidebar-bg); border-bottom: 2px solid var(--border-color);">
                            <th style="padding: 12px; text-align: left; border: 1px solid var(--border-color);">Interface</th>
                            <th style="padding: 12px; text-align: left; border: 1px solid var(--border-color);">Mode</th>
                            <th style="padding: 12px; text-align: left; border: 1px solid var(--border-color);">Native VLAN</th>
                            <th style="padding: 12px; text-align: left; border: 1px solid var(--border-color);">Allowed VLANs</th>
                        </tr>
                    </thead>
                    <tbody>
        `;

        ports.forEach(port => {
            const details = trunkDetails[port] || {};
            const mode = details.mode || 'trunk';
            const nativeVlan = details.native_vlan || 'N/A';
            const allowedVlans = details.allowed_vlans || 'N/A';
            
            trunkContent += `
                <tr style="border-bottom: 1px solid var(--border-color);">
                    <td style="padding: 10px; border: 1px solid var(--border-color); font-weight: 600;">${port}</td>
                    <td style="padding: 10px; border: 1px solid var(--border-color);">${mode}</td>
                    <td style="padding: 10px; border: 1px solid var(--border-color);">${nativeVlan}</td>
                    <td style="padding: 10px; border: 1px solid var(--border-color); font-size: 0.9em;">${allowedVlans}</td>
                </tr>
            `;
        });

        trunkContent += `
                    </tbody>
                </table>
            </div>
        `;

        trunkContainer.innerHTML = trunkContent;
    }

    /**
     * Populate neighbors information with enhanced details
     */
    populateNeighbors(template, device) {
        const neighborsContainer = template.querySelector('#neighborsContainer');
        if (!neighborsContainer) return;

        // Use the new API structure with separate CDP and LLDP neighbors
        const cdpNeighbors = device.cdp_neighbors || [];
        const lldpNeighbors = device.lldp_neighbors || [];
        const allNeighbors = device.neighbors || [];

        if (allNeighbors.length === 0 && cdpNeighbors.length === 0 && lldpNeighbors.length === 0) {
            neighborsContainer.innerHTML = '<p style="text-align: center; color: var(--text-muted); padding: 20px;">No network neighbors discovered</p>';
            return;
        }

        let neighborsContent = '';
        
        // CDP Neighbors Section
        if (cdpNeighbors.length > 0) {
            neighborsContent += `
                <div class="neighbor-method-section">
                    <div class="neighbor-method-header">
                        <i class="fas fa-network-wired"></i>
                        <h6>CDP Neighbors (${cdpNeighbors.length})</h6>
                    </div>
                    <div class="neighbor-method-grid">
            `;

            cdpNeighbors.forEach(neighbor => {
                const displayName = neighbor.hostname || neighbor.ip_address || 'Unknown';
                const capabilities = neighbor.capabilities || [];
                
                neighborsContent += `
                    <div class="neighbor-card">
                        <div class="neighbor-header">
                            <i class="fas fa-server"></i>
                            <div class="neighbor-ip">${displayName}</div>
                        </div>
                        <div class="neighbor-details">
                            ${neighbor.hostname ? `
                                <div class="neighbor-detail-item">
                                    <span class="neighbor-detail-label">Hostname:</span>
                                    <span class="neighbor-detail-value"><strong>${neighbor.hostname}</strong></span>
                                </div>
                            ` : ''}
                            ${neighbor.ip_address ? `
                                <div class="neighbor-detail-item">
                                    <span class="neighbor-detail-label">IP Address:</span>
                                    <span class="neighbor-detail-value">${neighbor.ip_address}</span>
                                </div>
                            ` : ''}
                            ${neighbor.platform ? `
                                <div class="neighbor-detail-item">
                                    <span class="neighbor-detail-label">Platform:</span>
                                    <span class="neighbor-detail-value">${neighbor.platform}</span>
                                </div>
                            ` : ''}
                            ${capabilities.length > 0 ? `
                                <div class="neighbor-detail-item neighbor-capabilities-item">
                                    <span class="neighbor-detail-label">Capabilities</span>
                                    <div class="capability-badges">
                                        ${capabilities.map(cap => `<span class="capability-badge">${cap}</span>`).join('')}
                                    </div>
                                </div>
                            ` : ''}
                            ${neighbor.local_interface ? `
                                <div class="neighbor-detail-item">
                                    <span class="neighbor-detail-label">Connection:</span>
                                    <span class="neighbor-detail-value">
                                        ${neighbor.local_interface} <i class="fas fa-arrows-alt-h"></i> ${neighbor.remote_interface || 'N/A'}
                                    </span>
                                </div>
                            ` : ''}
                        </div>
                    </div>
                `;
            });

            neighborsContent += `
                    </div>
                </div>
            `;
        }

        // LLDP Neighbors Section
        if (lldpNeighbors.length > 0) {
            neighborsContent += `
                <div class="neighbor-method-section">
                    <div class="neighbor-method-header">
                        <i class="fas fa-sitemap"></i>
                        <h6>LLDP Neighbors (${lldpNeighbors.length})</h6>
                    </div>
                    <div class="neighbor-method-grid">
            `;

            lldpNeighbors.forEach(neighbor => {
                const displayName = neighbor.hostname || neighbor.ip_address || 'Unknown';
                const capabilities = neighbor.capabilities || [];
                
                neighborsContent += `
                    <div class="neighbor-card">
                        <div class="neighbor-header">
                            <i class="fas fa-server"></i>
                            <div class="neighbor-ip">${displayName}</div>
                        </div>
                        <div class="neighbor-details">
                            ${neighbor.hostname ? `
                                <div class="neighbor-detail-item">
                                    <span class="neighbor-detail-label">Hostname:</span>
                                    <span class="neighbor-detail-value"><strong>${neighbor.hostname}</strong></span>
                                </div>
                            ` : ''}
                            ${neighbor.ip_address ? `
                                <div class="neighbor-detail-item">
                                    <span class="neighbor-detail-label">IP Address:</span>
                                    <span class="neighbor-detail-value">${neighbor.ip_address}</span>
                                </div>
                            ` : ''}
                            ${neighbor.platform ? `
                                <div class="neighbor-detail-item">
                                    <span class="neighbor-detail-label">Platform:</span>
                                    <span class="neighbor-detail-value">${neighbor.platform}</span>
                                </div>
                            ` : ''}
                            ${capabilities.length > 0 ? `
                                <div class="neighbor-detail-item neighbor-capabilities-item">
                                    <span class="neighbor-detail-label">Capabilities</span>
                                    <div class="capability-badges">
                                        ${capabilities.map(cap => `<span class="capability-badge">${cap}</span>`).join('')}
                                    </div>
                                </div>
                            ` : ''}
                            ${neighbor.local_interface ? `
                                <div class="neighbor-detail-item">
                                    <span class="neighbor-detail-label">Connection:</span>
                                    <span class="neighbor-detail-value">
                                        ${neighbor.local_interface} <i class="fas fa-arrows-alt-h"></i> ${neighbor.remote_interface || 'N/A'}
                                    </span>
                                </div>
                            ` : ''}
                        </div>
                    </div>
                `;
            });

            neighborsContent += `
                    </div>
                </div>
            `;
        }

        neighborsContainer.innerHTML = neighborsContent;
    }

    /**
     * Setup tab switching functionality
     */
    setupTabSwitching(container) {
        const tabButtons = container.querySelectorAll('.tab-btn');
        const tabPanes = container.querySelectorAll('.tab-pane');

        tabButtons.forEach(button => {
            button.addEventListener('click', () => {
                const tabName = button.dataset.tab;

                // Remove active class from all tabs and panes
                tabButtons.forEach(btn => btn.classList.remove('active'));
                tabPanes.forEach(pane => pane.classList.remove('active'));

                // Add active class to clicked tab and corresponding pane
                button.classList.add('active');
                const targetPane = container.querySelector(`#${tabName}-tab`);
                if (targetPane) {
                    targetPane.classList.add('active');
                }
            });
        });
    }

    /**
     * Load Nautobot dropdown data
     */
    loadNautobotDropdownData() {
        // Get data from template context
        const nautobotDataElement = document.getElementById('nautobot-data');
        if (nautobotDataElement) {
            try {
                this.nautobotData = JSON.parse(nautobotDataElement.textContent);
            } catch (error) {
                console.error('Error parsing Nautobot data from template:', error);
                this.nautobotData = {};
            }
        }
    }

    /**
     * Close device detail modal
     */
    closeModal() {
        const modal = document.getElementById('deviceDetailModal');
        if (modal) {
            modal.style.display = 'none';
            this.currentDeviceIp = null;
        }
    }

}

// Export for use in other scripts
if (typeof window !== 'undefined') {
    window.DeviceDetailManager = DeviceDetailManager;
}

