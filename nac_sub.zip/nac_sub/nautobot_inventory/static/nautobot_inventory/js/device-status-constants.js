/**
 * Device Status Constants Module
 * 
 * Centralized constants for device status management across the application.
 * This module provides consistent status values, hostname prefixes, and helper
 * functions for determining device status.
 */

// Device connection statuses that indicate failure
const FAILED_CONNECTION_STATUSES = ['failed', 'cancelled', 'unreachable'];

// Hostname prefixes that indicate device failure states
const FAILED_HOSTNAME_PREFIXES = [
    'unreachable-',
    'failed-',
    'auth-failed-',
    'timeout-',
    'error-'
];

// Status class mappings for UI styling
const STATUS_CLASSES = {
    'discovering': 'discovering',
    'connected': 'connected',
    'failed': 'failed',
    'cancelled': 'cancelled',
    'unreachable': 'unreachable',
    'partial': 'partial'
};

// Status display text mappings
const STATUS_TEXT = {
    'discovering': 'Discovering...',
    'connected': 'Connected',
    'failed': 'Failed',
    'cancelled': 'Cancelled',
    'unreachable': 'Unreachable',
    'partial': 'Partial Info',
    'connection_failed': 'Connection Failed',
    'auth_failed': 'Auth Failed',
    'timeout': 'Timeout',
    'error': 'Error'
};

// Priority order for status sorting (lower number = higher priority)
const STATUS_PRIORITY = {
    'failed': 1,
    'unreachable': 2,
    'cancelled': 3,
    'partial': 4,
    'discovering': 5,
    'connected': 6
};

/**
 * Check if a device is in a failed state and should not be onboarded.
 * 
 * @param {Object} device - Device object with connection_status and hostname properties
 * @returns {boolean} True if device is in a failed state, false otherwise
 */
function isDeviceFailed(device) {
    // Check connection status
    if (device.connection_status && FAILED_CONNECTION_STATUSES.includes(device.connection_status)) {
        return true;
    }
    
    // Check hostname patterns for failed devices
    if (device.hostname) {
        for (const prefix of FAILED_HOSTNAME_PREFIXES) {
            if (device.hostname.startsWith(prefix)) {
                return true;
            }
        }
    }
    
    return false;
}

/**
 * Get device status class and text based on device properties.
 * 
 * @param {Object} device - Device object with connection_status, hostname, and status properties
 * @returns {Object} Object with statusClass and statusText properties
 */
function getDeviceStatus(device) {
    let statusClass = 'connected';
    let statusText = device.connection_status || 'discovered';
    
    // Check connection status first
    if (device.connection_status === 'discovering') {
        statusClass = STATUS_CLASSES.discovering;
        statusText = STATUS_TEXT.discovering;
    } else if (device.connection_status === 'failed') {
        statusClass = STATUS_CLASSES.failed;
        statusText = STATUS_TEXT.failed;
    } else if (device.connection_status === 'cancelled') {
        statusClass = STATUS_CLASSES.cancelled;
        statusText = STATUS_TEXT.cancelled;
    } else if (device.connection_status === 'connected') {
        statusClass = STATUS_CLASSES.connected;
        statusText = STATUS_TEXT.connected;
    }
    
    // Override based on hostname patterns for more specific error types
    if (device.hostname) {
        if (device.hostname.startsWith('unreachable-')) {
            statusClass = STATUS_CLASSES.unreachable;
            statusText = STATUS_TEXT.unreachable;
        } else if (device.hostname.startsWith('failed-')) {
            statusClass = STATUS_CLASSES.failed;
            statusText = STATUS_TEXT.connection_failed;
        } else if (device.hostname.startsWith('auth-failed-')) {
            statusClass = STATUS_CLASSES.failed;
            statusText = STATUS_TEXT.auth_failed;
        } else if (device.hostname.startsWith('timeout-')) {
            statusClass = STATUS_CLASSES.failed;
            statusText = STATUS_TEXT.timeout;
        } else if (device.hostname.startsWith('error-')) {
            statusClass = STATUS_CLASSES.failed;
            statusText = STATUS_TEXT.error;
        } else if (device.hostname.startsWith('partial-')) {
            statusClass = STATUS_CLASSES.partial;
            statusText = STATUS_TEXT.partial;
        } else if (device.hostname.startsWith('discovering-')) {
            statusClass = STATUS_CLASSES.discovering;
            statusText = STATUS_TEXT.discovering;
        }
    }
    
    // Check legacy status field for backward compatibility
    if (device.status?.includes('failed')) {
        statusClass = STATUS_CLASSES.failed;
        statusText = STATUS_TEXT.failed;
    } else if (device.status?.includes('cancelled')) {
        statusClass = STATUS_CLASSES.cancelled;
        statusText = STATUS_TEXT.cancelled;
    } else if (device.status?.includes('partial')) {
        statusClass = STATUS_CLASSES.partial;
        statusText = STATUS_TEXT.partial;
    }
    
    return { statusClass, statusText };
}

/**
 * Determine the specific type of failure for a device.
 * 
 * @param {Object} device - Device object with connection_status and hostname properties
 * @returns {string|null} The failure type or null if not failed
 */
function getFailedDeviceType(device) {
    if (!isDeviceFailed(device)) {
        return null;
    }
    
    // Check hostname patterns first for specific error types
    if (device.hostname) {
        if (device.hostname.startsWith('unreachable-')) {
            return 'unreachable';
        } else if (device.hostname.startsWith('auth-failed-')) {
            return 'auth_failed';
        } else if (device.hostname.startsWith('timeout-')) {
            return 'timeout';
        } else if (device.hostname.startsWith('error-')) {
            return 'error';
        } else if (device.hostname.startsWith('failed-')) {
            return 'failed';
        }
    }
    
    // Check connection status
    if (device.connection_status === 'unreachable') {
        return 'unreachable';
    } else if (device.connection_status === 'cancelled') {
        return 'cancelled';
    } else if (device.connection_status === 'failed') {
        return 'failed';
    }
    
    return 'failed';  // Default fallback
}

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        FAILED_CONNECTION_STATUSES,
        FAILED_HOSTNAME_PREFIXES,
        STATUS_CLASSES,
        STATUS_TEXT,
        STATUS_PRIORITY,
        isDeviceFailed,
        getDeviceStatus,
        getFailedDeviceType
    };
}

// Also attach to window for browser usage
if (typeof window !== 'undefined') {
    window.DeviceStatusConstants = {
        FAILED_CONNECTION_STATUSES,
        FAILED_HOSTNAME_PREFIXES,
        STATUS_CLASSES,
        STATUS_TEXT,
        STATUS_PRIORITY,
        isDeviceFailed,
        getDeviceStatus,
        getFailedDeviceType
    };
}

