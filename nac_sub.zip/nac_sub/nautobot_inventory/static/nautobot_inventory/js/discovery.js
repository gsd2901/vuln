/**
 * Network Inventory Discovery - JavaScript Module
 * Handles the interactive discovery interface functionality
 */

// Common Popup Utility
class CommonPopup {
    constructor() {
        this.modal = document.getElementById('commonModal');
        this.titleEl = document.getElementById('modalTitle');
        this.iconEl = document.getElementById('modalIcon');
        this.contentEl = document.getElementById('modalContent');
        this.confirmBtn = document.getElementById('modalConfirmBtn');
        this.cancelBtn = document.getElementById('modalCancelBtn');
        this.onConfirm = null;
        this.onCancel = null;
    }

    show(options = {}) {
        const {
            title = 'Confirmation',
            icon = 'fas fa-info-circle',
            content = '',
            confirmText = 'Confirm',
            cancelText = 'Cancel',
            confirmClass = 'primary',
            size = 'lg',
            onConfirm = null,
            onCancel = null,
            showCancel = true
        } = options;

        this.titleEl.innerHTML = title;  // Use innerHTML to support HTML in title
        this.iconEl.className = `${icon} header-icon`;
        this.contentEl.innerHTML = content;
        this.confirmBtn.textContent = confirmText;
        
        // Update modal size
        const modalDialog = this.modal.querySelector('.modal-dialog');
        if (modalDialog) {
            modalDialog.className = `modal-dialog modal-${size}`;
        }
        this.confirmBtn.className = `btn ${confirmClass}`;
        this.cancelBtn.textContent = cancelText;
        this.cancelBtn.style.display = showCancel ? 'inline-block' : 'none';

        this.onConfirm = onConfirm;
        this.onCancel = onCancel;

        // Remove any existing event listeners
        this.confirmBtn.replaceWith(this.confirmBtn.cloneNode(true));
        this.confirmBtn = document.getElementById('modalConfirmBtn');

        // Add new event listeners
        this.confirmBtn.addEventListener('click', () => {
            if (this.onConfirm) {
                this.onConfirm();
            }
            this.close();
        });

        this.modal.style.display = 'flex';
        document.body.style.overflow = 'hidden';
    }

    close() {
        this.modal.style.display = 'none';
        document.body.style.overflow = 'auto';
        if (this.onCancel) {
            this.onCancel();
        }
    }

    confirm(title, content, onConfirm) {
        this.show({
            title,
            content,
            icon: 'fas fa-question-circle',
            confirmText: 'Yes',
            cancelText: 'No',
            confirmClass: 'primary',
            onConfirm
        });
    }

    alert(title, content, type = 'info') {
        const icons = {
            success: 'fas fa-check-circle',
            error: 'fas fa-times-circle',
            warning: 'fas fa-exclamation-triangle',
            info: 'fas fa-info-circle'
        };
        
        const classes = {
            success: 'success',
            error: 'danger',
            warning: 'warning',
            info: 'primary'
        };

        this.show({
            title,
            content,
            icon: icons[type],
            confirmText: 'OK',
            confirmClass: classes[type],
            showCancel: false
        });
    }

    // Enhanced error display method for detailed error information
    showDetailedError(title, errorData, type = 'error') {
        let errorContent = '';
        if (typeof errorData === 'string') {
            errorContent = errorData;
        } else {
            // Build detailed error display
            errorContent = `<strong>Error Message:</strong> ${errorData.message || errorData.error_message || 'Unknown error'}<br/>`;
            
            // Handle onboarding-specific error structure
            if (errorData.failed_jobs && errorData.failed_jobs.length > 0) {
                errorContent += `<br/><strong>Failed Devices:</strong><br/>`;
                errorData.failed_jobs.forEach((job, index) => {
                    errorContent += `<div class="mb-2 p-2 border border-danger rounded">`;
                    errorContent += `<strong>Device:</strong> ${job.device}<br/>`;
                    errorContent += `<strong>Error:</strong> <code>${job.error}</code>`;
                    errorContent += `</div>`;
                });
            }
            
            // Handle error details
            if (errorData.error_details) {
                const details = errorData.error_details;
                
                if (details.total_failed) {
                    errorContent += `<br/><strong>Total Failed:</strong> ${details.total_failed}<br/>`;
                }
                
                if (details.error_messages && details.error_messages.length > 0) {
                    errorContent += `<br/><strong>Error Messages:</strong><br/>`;
                    details.error_messages.forEach(msg => {
                        errorContent += `<div class="mb-1"><code>${msg}</code></div>`;
                    });
                }
                
                if (details.suggestion) {
                    errorContent += `<br/><strong>Suggestion:</strong> ${details.suggestion}<br/>`;
                }
                
                // Legacy error details support
                if (details.error_type) {
                    errorContent += `<strong>Error Type:</strong> ${details.error_type}<br/>`;
                }
                if (details.failed_at) {
                    errorContent += `<strong>Failed At:</strong> ${new Date(details.failed_at).toLocaleString()}<br/>`;
                }
                if (details.job_execution_error) {
                    errorContent += `<strong>Source:</strong> Job Execution Error<br/>`;
                }
                if (details.error_source) {
                    errorContent += `<strong>Error Source:</strong> ${details.error_source}<br/>`;
                }
            }
            
            // Add next steps if available
            if (errorData.next_steps && errorData.next_steps.length > 0) {
                errorContent += `<br/><strong>Next Steps:</strong><br/>`;
                errorContent += `<ul class="mb-0">`;
                errorData.next_steps.forEach(step => {
                    errorContent += `<li>${step}</li>`;
                });
                errorContent += `</ul>`;
            }
            
            // Add expandable traceback if available
            if (errorData.error_details && errorData.error_details.error_traceback) {
                errorContent += `
                    <br/>
                    <div class="mb-2">
                        <button class="btn btn-sm btn-outline-secondary" type="button" data-bs-toggle="collapse" 
                                data-bs-target="#errorTraceback" aria-expanded="false">
                            Show Technical Details
                        </button>
                    </div>
                    <div class="collapse" id="errorTraceback">
                        <div class="card card-body">
                            <pre style="font-size: 0.8em; max-height: 300px; overflow-y: auto; white-space: pre-wrap;">${errorData.error_details.error_traceback}</pre>
                        </div>
                    </div>
                `;
            }
        }
        
        // Use the existing popup system but with enhanced content
        this.show({
            title: `<i class="fas fa-exclamation-triangle text-danger me-2"></i>${title}`,
            content: `<div class="alert alert-danger">${errorContent}</div>`,
            confirmText: 'OK',
            confirmClass: 'primary',
            showCancel: false,
            size: 'xl'  // Make modal larger for error details
        });
    }
}

class NetworkDiscovery {
    constructor(config = {}) {
        this.currentSessionId = null;
        this.discoveredDevices = [];
        this.filteredDevices = [];
        this.pollingInterval = null;
        this.knownDeviceIPs = new Set();
        this.currentSessionLocation = null;
        this.currentSessionSecretsGroup = null;
        
        // Filter and sort state
        this.allDevices = [];
        this.sortConfig = {
            column: 'status',
            direction: 'desc'
        };
        
        // Configuration for URLs and session data
        this.config = {
            urls: config.urls || this.getDefaultUrls(),
            loadedSession: config.loadedSession || null
        };
        
        this.init();
    }

    /**
     * Get default URLs (fallback when not configured)
     */
    getDefaultUrls() {
        const baseUrl = window.location.origin;
        const pluginPrefix = '/plugins/inventory';
        
        return {
            startDiscovery: `${baseUrl}${pluginPrefix}/api/start-discovery/`,
            stopDiscovery: `${baseUrl}${pluginPrefix}/api/stop-discovery/00000000-0000-0000-0000-000000000000/`,
            sessionStatus: `${baseUrl}${pluginPrefix}/api/status/00000000-0000-0000-0000-000000000000/`,
            deviceDetails: `${baseUrl}${pluginPrefix}/api/device-detail/00000000-0000-0000-0000-000000000000/0.0.0.0/`
        };
    }

    /**
     * Initialize the discovery interface
     */
    init() {
        this.bindEventListeners();
        this.updateStatus('Ready', 'ready');
        this.loadSessionData();
        this.loadNautobotDropdownData(); // Load Nautobot data for dropdowns
        
        // Initialize DeviceDetailManager
        if (typeof DeviceDetailManager !== 'undefined' && this.config.urls.deviceDetails) {
            // Use current session ID if available, or placeholder that will be updated later
            const sessionId = this.currentSessionId || 'temp-session';
            this.deviceDetailManager = new DeviceDetailManager(
                sessionId,
                this.config.urls.deviceDetails
            );
            // Store globally for template access
            window.deviceDetailManagerInstance = this.deviceDetailManager;
        }
    }

    /**
     * Get maximum bulk devices setting from backend configuration
     */
    async getMaxBulkDevices() {
        try {
            const response = await fetch('/plugins/inventory/api/config/', {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRFToken': this.getCsrfToken()
                }
            });
            
            if (response.ok) {
                const data = await response.json();
                return data.config?.max_bulk_devices || 50; // Default fallback
            } else {
                console.warn('Failed to get plugin configuration, using default max bulk devices');
                return 50;
            }
        } catch (error) {
            console.error('Error getting plugin configuration:', error);
            return 50; // Default fallback
        }
    }

    /**
     * Bind all event listeners
     */
    bindEventListeners() {
        // Form submission
        const discoveryForm = document.getElementById('discoveryForm');
        if (discoveryForm) {
            discoveryForm.addEventListener('submit', (e) => this.handleFormSubmission(e));
        }

        // Location selection change
        const locationSelect = document.getElementById('location');
        if (locationSelect) {
            locationSelect.addEventListener('change', (e) => this.handleLocationChange(e));
        }

        // Select all checkbox
        const selectAllCheckbox = document.getElementById('selectAll');
        if (selectAllCheckbox) {
            selectAllCheckbox.addEventListener('change', (e) => this.handleSelectAll(e));
        }

        // Prepare onboarding button
        const prepareBtn = document.getElementById('prepareOnboarding');
        if (prepareBtn) {
            prepareBtn.addEventListener('click', () => this.handlePrepareOnboarding());
        }

        // Export CSV button
        const exportBtn = document.getElementById('exportCSV');
        if (exportBtn) {
            exportBtn.addEventListener('click', () => this.handleExportCSV());
        }

        // View Topology button
        const viewTopologyBtn = document.getElementById('viewTopology');
        if (viewTopologyBtn) {
            viewTopologyBtn.addEventListener('click', () => this.handleViewTopology());
        }

        // New discovery button
        const newDiscoveryBtn = document.getElementById('newDiscovery');
        if (newDiscoveryBtn) {
            newDiscoveryBtn.addEventListener('click', () => this.handleNewDiscovery());
        }

        // Stop discovery button
        const stopDiscoveryBtn = document.getElementById('stopDiscovery');
        if (stopDiscoveryBtn) {
            stopDiscoveryBtn.addEventListener('click', () => this.handleStopDiscovery());
        }

        // Unreachable devices management button
        const manageUnreachableBtn = document.getElementById('manageUnreachableDevices');
        if (manageUnreachableBtn) {
            manageUnreachableBtn.addEventListener('click', () => this.handleManageUnreachableDevices());
        }

        // Bulk credentials button
        const bulkCredentialsBtn = document.getElementById('bulkCredentialsBtn');
        if (bulkCredentialsBtn) {
            bulkCredentialsBtn.addEventListener('click', () => this.handleBulkCredentials());
        }

        // Bulk location button
        const bulkLocationBtn = document.getElementById('bulkLocationBtn');
        if (bulkLocationBtn) {
            bulkLocationBtn.addEventListener('click', () => this.handleBulkLocation());
        }

        // Bulk location panel buttons
        const applyBulkLocationMainBtn = document.getElementById('applyBulkLocationMainBtn');
        if (applyBulkLocationMainBtn) {
            applyBulkLocationMainBtn.addEventListener('click', () => this.handleApplyBulkLocation());
        }

        const cancelBulkLocationBtn = document.getElementById('cancelBulkLocationBtn');
        if (cancelBulkLocationBtn) {
            cancelBulkLocationBtn.addEventListener('click', () => this.hideBulkLocationPanel());
        }

        // Device detail modal bulk location button
        const applyBulkLocationBtn = document.getElementById('applyBulkLocationBtn');
        if (applyBulkLocationBtn) {
            applyBulkLocationBtn.addEventListener('click', () => this.handleApplyBulkLocationFromModal());
        }

        // Filter controls
        this.bindFilterListeners();

        // Sortable headers
        const sortableHeaders = document.querySelectorAll('.sortable-header');
        sortableHeaders.forEach(header => {
            header.addEventListener('click', (e) => this.handleSort(e));
        });

        // Modal close events
        window.addEventListener('click', (e) => this.handleModalClick(e));
    }

    /**
     * Bind filter event listeners
     */
    bindFilterListeners() {
        // Clear filters button
        const clearBtn = document.getElementById('clearFilters');
        if (clearBtn) {
            clearBtn.addEventListener('click', () => this.clearFilters());
        }

        // Auto-apply filters on change for dropdowns and input for search
        const filterInputs = ['statusFilter', 'modelFilter', 'platformFilter', 'deviceSearchExact'];
        filterInputs.forEach(filterId => {
            const filter = document.getElementById(filterId);
            if (filter) {
                if (filter.type === 'text') {
                    // For search input, apply with delay
                    let timeout;
                    filter.addEventListener('input', () => {
                        clearTimeout(timeout);
                        timeout = setTimeout(() => this.applyFilters(), 300);
                    });
                } else {
                    // For dropdowns, apply immediately
                    filter.addEventListener('change', () => this.applyFilters());
                }
            }
        });

        // Enter key applies filters immediately for search
        document.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                const activeElement = document.activeElement;
                if (activeElement && activeElement.id === 'deviceSearchExact') {
                    this.applyFilters();
                }
            }
        });
    }

    /**
     * Get CSRF token from cookies or form
     */
    getCsrfToken() {
        // First try to get from cookie
        const name = 'csrftoken';
        let cookieValue = null;
        if (document.cookie && document.cookie !== '') {
            const cookies = document.cookie.split(';');
            for (let i = 0; i < cookies.length; i++) {
                const cookie = cookies[i].trim();
                if (cookie.substring(0, name.length + 1) === (name + '=')) {
                    cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                    break;
                }
            }
        }
        
        // If not found in cookie, try form token
        if (!cookieValue) {
            const token = document.querySelector('[name=csrfmiddlewaretoken]');
            if (token) {
                cookieValue = token.value;
            }
        }
        
        return cookieValue;
    }

    /**
     * Load session data if provided via URL parameter
     */
    loadSessionData() {
        if (this.config.loadedSession) {
            const session = this.config.loadedSession;
            
            // Set current session ID
            this.currentSessionId = session.session_id;
            
            // Update DeviceDetailManager with session ID if it exists
            if (this.deviceDetailManager && typeof this.deviceDetailManager.updateSessionId === 'function') {
                this.deviceDetailManager.updateSessionId(this.currentSessionId);
            }
            
            // Populate form fields
            const locationSelect = document.getElementById('location');
            const routerIpInput = document.getElementById('routerIp');
            
            if (locationSelect) {
                // Find location option by matching the location name
                // Note: option.text now contains hierarchical path, but we need to match by name
                // We'll match by checking if the path ends with the location name or contains it
                const sessionLocationName = session.location;
                for (let option of locationSelect.options) {
                    // Check if option text ends with the session location name (handles hierarchical paths)
                    // e.g., "A -> B -> C" ends with "C" if session.location is "C"
                    if (option.text === sessionLocationName || option.text.endsWith(' -> ' + sessionLocationName)) {
                        option.selected = true;
                        // Store the location name (not path) for later use
                        this.currentSessionLocation = sessionLocationName;
                        break;
                    }
                }
            }
            
            if (routerIpInput) {
                routerIpInput.value = session.router_ip;
            }
            
            // Find secrets group by name
            const secretsGroupSelect = document.getElementById('secretsGroup');
            if (secretsGroupSelect && session.secrets_group_name) {
                for (let option of secretsGroupSelect.options) {
                    if (option.text === session.secrets_group_name) {
                        option.selected = true;
                        break;
                    }
                }
            }
            
            // If session has discovered data, show the results
            if (session.discovered_data && session.discovered_data.length > 0) {
                this.discoveredDevices = session.discovered_data;
                this.showResults();
                this.displayDevices(this.discoveredDevices);
                this.updateStatus(`Loaded session with ${session.device_count} device${session.device_count !== 1 ? 's' : ''}`, 'success');
            } else {
                this.updateStatus(`Session loaded - ${session.status}`, 'ready');
            }
        }
    }

    /**
     * Update status indicator
     */
    updateStatus(text, type = 'ready', loading = false) {
        const statusEl = document.getElementById('discoveryStatus');
        if (!statusEl) return;

        const iconClass = loading ? 'fas fa-spinner fa-spin' :
            type === 'success' ? 'fas fa-check-circle' :
            type === 'error' ? 'fas fa-exclamation-circle' :
            type === 'warning' ? 'fas fa-exclamation-triangle' :
            type === 'loading' ? 'fas fa-spinner fa-spin' :
            'fas fa-circle';

        statusEl.className = `status ${type}`;
        statusEl.innerHTML = `<i class="${iconClass}"></i> ${text}`;
    }

    /**
     * Show/hide stop discovery button
     */
    showStopButton(show = true) {
        const stopBtn = document.getElementById('stopDiscovery');
        if (stopBtn) {
            if (show) {
                stopBtn.style.display = 'inline-block';
                stopBtn.classList.remove('hidden');
            } else {
                stopBtn.style.display = 'none';
                stopBtn.classList.add('hidden');
            }
        }
    }

    /**
     * Show discovery form panel
     */
    showDiscoveryForm() {
        const formPanel = document.getElementById('discoveryFormPanel');
        const resultsPanel = document.getElementById('resultsPanel');
        
        if (formPanel) formPanel.style.display = 'block';
        if (resultsPanel) resultsPanel.style.display = 'none';
        this.showStopButton(false);
    }

    /**
     * Show results panel
     */
    showResults() {
        const formPanel = document.getElementById('discoveryFormPanel');
        const resultsPanel = document.getElementById('resultsPanel');
        
        if (formPanel) formPanel.style.display = 'none';
        if (resultsPanel) resultsPanel.style.display = 'flex';
    }

    /**
     * Handle form submission
     */
    async handleFormSubmission(e) {
        e.preventDefault();
        
        const formData = new FormData(e.target);
        const startBtn = document.getElementById('startDiscovery');
        
        // Store session data for later use in onboarding forms
        const locationSelect = document.getElementById('location');
        const secretsGroupSelect = document.getElementById('secretsGroup');
        
        if (locationSelect && locationSelect.selectedOptions.length > 0) {
            // Get the location name from the selected option
            // Option value is the location ID, look up the name from nautobot_data
            const selectedOption = locationSelect.selectedOptions[0];
            const locationId = selectedOption.value;
            
            // Try to find location name from nautobot_data by ID
            if (this.nautobotData && this.nautobotData.locations) {
                const location = this.nautobotData.locations.find(loc => loc.id === parseInt(locationId));
                if (location) {
                    this.currentSessionLocation = location.name;
                } else {
                    // Fallback: extract name from path (last part after " -> ")
                    const selectedText = selectedOption.text;
                    this.currentSessionLocation = selectedText.includes(' -> ') 
                        ? selectedText.split(' -> ').pop() 
                        : selectedText;
                }
            } else {
                // Fallback: extract name from path (last part after " -> ")
                const selectedText = selectedOption.text;
                this.currentSessionLocation = selectedText.includes(' -> ') 
                    ? selectedText.split(' -> ').pop() 
                    : selectedText;
            }
        }
        if (secretsGroupSelect && secretsGroupSelect.selectedOptions.length > 0) {
            this.currentSessionSecretsGroup = secretsGroupSelect.selectedOptions[0].text;
        }
        
        // Disable form and show loading
        if (startBtn) startBtn.disabled = true;
        this.updateStatus('Starting discovery...', 'loading', true);
        
        try {
            const response = await fetch(this.config.urls.startDiscovery, {
                method: 'POST',
                body: formData,
                credentials: 'same-origin',
                headers: {
                    'X-CSRFToken': this.getCsrfToken()
                }
            });
            
            const data = await response.json();
            
            if (data.status === 'started') {
                this.currentSessionId = data.session_id;
                
                // Update DeviceDetailManager with new session ID
                if (this.deviceDetailManager && typeof this.deviceDetailManager.updateSessionId === 'function') {
                    this.deviceDetailManager.updateSessionId(this.currentSessionId);
                }
                
                // Show empty results panel, stop button, and start polling
                this.showResults();
                this.showStopButton(true);
                this.updateStatus('Discovery started - looking for devices...', 'loading', true);
                this.startPolling(this.currentSessionId);
                
            } else {
                this.updateStatus(`Discovery failed: ${data.message}`, 'error');
                console.error('Discovery error:', data);
                
                // Show detailed error if available
                if (data.error_details) {
                    // Check for SecretsGroup configuration errors
                    if (data.error_details.error_type === 'SecretsGroupConfigurationError') {
                        const errorMessage = `
                            <div class="alert alert-danger">
                                <h5><i class="fas fa-key"></i> SecretsGroup Configuration Error</h5>
                                <p><strong>Issue:</strong> ${data.message}</p>
                                
                                <div class="mt-3">
                                    <h6>Configuration Details:</h6>
                                    <ul>
                                        <li><strong>SecretsGroup:</strong> ${data.error_details.secrets_group_name}</li>
                                        <li><strong>Missing:</strong> ${data.error_details.missing_secret_type} secret</li>
                                        <li><strong>Tried Access Types:</strong> ${data.error_details.tried_access_types.join(', ')}</li>
                                    </ul>
                                </div>
                                
                                <div class="mt-3">
                                    <h6><i class="fas fa-lightbulb"></i> How to Fix:</h6>
                                    <ol>
                                        <li>Go to <strong>Extras → Secrets Groups</strong></li>
                                        <li>Edit the "${data.error_details.secrets_group_name}" secrets group</li>
                                        <li>Ensure it has both <strong>username</strong> and <strong>password</strong> secrets</li>
                                        <li>Set the access type to <strong>SSH</strong> or <strong>Generic</strong> for both secrets</li>
                                        <li>Save the configuration and try discovery again</li>
                                    </ol>
                                </div>
                                
                                ${data.error_details.last_error ? `
                                    <div class="mt-3">
                                        <h6>Technical Details:</h6>
                                        <code style="font-size: 0.9em;">${data.error_details.last_error}</code>
                                    </div>
                                ` : ''}
                            </div>
                        `;
                        
                        window.commonPopup.show({
                            title: '<i class="fas fa-exclamation-triangle text-danger me-2"></i>SecretsGroup Configuration Error',
                            content: errorMessage,
                            confirmText: 'OK',
                            confirmClass: 'btn-primary',
                            showCancel: false,
                            size: 'xl'
                        });
                    } else {
                        // Generic detailed error
                        window.commonPopup.showDetailedError('Discovery Start Failed', data);
                    }
                } else {
                    window.commonPopup.alert('Discovery Failed', data.message || 'Failed to start discovery process', 'error');
                }
            }
            
        } catch (error) {
            this.updateStatus('Connection error', 'error');
            console.error('Network error:', error);
        } finally {
            if (startBtn) startBtn.disabled = false;
        }
    }

    /**
     * Handle location selection change
     */
    handleLocationChange(e) {
        const locationId = e.target.value;
        const topologyBtn = document.getElementById('viewTopologyBtn');
        
        if (topologyBtn) {
            if (locationId) {
                // Update the href with the selected location ID
                topologyBtn.href = `/plugins/topology-viewer/viewer/${locationId}/`;
                topologyBtn.style.display = 'inline-block';
            } else {
                topologyBtn.style.display = 'none';
            }
        }
    }

    /**
     * Start polling for discovery updates
     */
    startPolling(sessionId) {
        if (this.pollingInterval) {
            clearInterval(this.pollingInterval);
        }
        
        this.pollingInterval = setInterval(async () => {
            try {
                const sessionStatusUrl = this.config.urls.sessionStatus.replace('00000000-0000-0000-0000-000000000000', sessionId);
                const response = await fetch(sessionStatusUrl, {
                    credentials: 'same-origin',
                    headers: {
                        'X-CSRFToken': this.getCsrfToken()
                    }
                });
                
                if (!response.ok) {
                    throw new Error(`HTTP ${response.status}: ${response.statusText}`);
                }
                
                const data = await response.json();
                
                if (data.status === 'error') {
                    console.error('Polling error:', data.message);
                    return;
                }
                
                // Update status with enhanced parallel discovery information
                const deviceCount = data.device_count || 0;
                const progressInfo = data.progress_info || {};
                
                if (data.is_running) {
                    // Enhanced status for parallel discovery with better progress tracking
                    let statusMessage = `🚀 Parallel Discovery - ${deviceCount} device${deviceCount !== 1 ? 's' : ''} found`;
                    
                    // Add performance metrics if available
                    if (progressInfo.message && progressInfo.message.includes('devices/sec')) {
                        statusMessage = progressInfo.message;
                        
                        // Add additional context for discovering devices
                        const discoveringCount = data.discovering_devices_count || (data.devices ? data.devices.filter(d => d.connection_status === 'discovering').length : 0);
                        if (discoveringCount > 0) {
                            statusMessage += ` (${discoveringCount} still discovering)`;
                        }
                    } else if (progressInfo.current_device) {
                        statusMessage += ` | Current: ${progressInfo.current_device}`;
                    }
                    
                    this.updateStatus(statusMessage, 'loading', true);
                } else if (data.is_complete || (!data.has_discovering_devices && deviceCount > 0)) {
                    // Stop polling if:
                    // 1. Session is marked as complete, OR  
                    // 2. No devices are discovering AND we have processed at least one device
                    
                    this.stopPolling();
                    this.showStopButton(false);
                    
                    // Determine final status based on device results
                    const connectedDevices = data.devices ? data.devices.filter(d => d.connection_status === 'connected').length : 0;
                    const failedDevices = data.devices ? data.devices.filter(d => d.connection_status === 'failed').length : 0;
                    
                    if (data.status === 'completed' || data.status === 'running') {
                        if (connectedDevices > 0) {
                            this.updateStatus(`Discovery completed - ${connectedDevices} device${connectedDevices !== 1 ? 's' : ''} connected${failedDevices > 0 ? `, ${failedDevices} failed` : ''}`, 'success');
                        } else if (failedDevices > 0) {
                            this.updateStatus(`Discovery completed - ${failedDevices} device${failedDevices !== 1 ? 's' : ''} failed to connect`, 'warning');
                        } else {
                            this.updateStatus(`Discovery completed - no devices found`, 'warning');
                        }
                    } else if (data.status === 'failed') {
                        this.updateStatus(`Discovery failed: ${data.error_message || 'Unknown error'}`, 'error');
                        
                        // Show detailed error popup if detailed error information is available
                        if (data.error_details && data.error_details.job_execution_error) {
                            this.popup.showDetailedError('Discovery Job Failed', data);
                        } else if (data.error_message) {
                            this.popup.alert('Discovery Failed', data.error_message, 'error');
                        }
                    } else if (data.status === 'stopped') {
                        this.updateStatus(`Discovery stopped - ${deviceCount} device${deviceCount !== 1 ? 's' : ''} found`, 'warning');
                    }
                }
                
                // Update devices progressively
                if (data.devices && data.devices.length > 0) {
                    this.displayDevices(data.devices, true);
                    
                    // Show results panel if not already visible
                    const resultsPanel = document.getElementById('resultsPanel');
                    if (resultsPanel && resultsPanel.style.display !== 'flex') {
                        this.showResults();
                    }
                }
                
            } catch (error) {
                console.error('Polling error:', error);
            }
        }, 2000); // Poll every 2 seconds
    }

    /**
     * Stop polling
     */
    stopPolling() {
        if (this.pollingInterval) {
            clearInterval(this.pollingInterval);
            this.pollingInterval = null;
        }
    }

    /**
     * Show/hide clear filters button based on active filters
     */
    updateClearFiltersButton() {
        const clearBtn = document.getElementById('clearFilters');
        if (!clearBtn) return;

        const hasActiveFilters = this.hasActiveFilters();
        clearBtn.style.display = hasActiveFilters ? 'flex' : 'none';
    }

    /**
     * Check if any filters are active
     */
    hasActiveFilters() {
        const statusFilter = document.getElementById('statusFilter')?.value || '';
        const modelFilter = document.getElementById('modelFilter')?.value || '';
        const platformFilter = document.getElementById('platformFilter')?.value || '';
        const searchFilter = document.getElementById('deviceSearchExact')?.value || '';
        
        // Consider "active" (connected + discovering) as default, so only show clear if other filters are active
        // or if status is not "active"
        return (statusFilter && statusFilter !== 'active') || 
               modelFilter || 
               platformFilter || 
               searchFilter;
    }

    /**
     * Handle column sorting
     */
    handleSort(e) {
        const header = e.currentTarget;
        const column = header.dataset.sort;
        if (!column) return;

        // Toggle direction if same column, otherwise default to asc
        if (this.sortConfig.column === column) {
            this.sortConfig.direction = this.sortConfig.direction === 'asc' ? 'desc' : 'asc';
        } else {
            this.sortConfig.column = column;
            this.sortConfig.direction = 'asc';
        }

        this.updateSortHeaders();
        this.applyFilters();
    }

    /**
     * Update sort header indicators
     */
    updateSortHeaders() {
        // Reset all icons
        document.querySelectorAll('.sortable-header i').forEach(icon => {
            icon.className = 'fas fa-sort';
        });

        // Update current sort icon
        const currentHeader = document.querySelector(`.sortable-header[data-sort="${this.sortConfig.column}"]`);
        if (currentHeader) {
            const icon = currentHeader.querySelector('i');
            if (icon) {
                icon.className = this.sortConfig.direction === 'asc' ? 'fas fa-sort-up' : 'fas fa-sort-down';
            }
        }
    }

    /**
     * Collect device data for filtering
     */
    collectDeviceData() {
        // This will be called when devices are loaded to populate filter options
        this.allDevices = [...this.discoveredDevices];
        this.filteredDevices = [...this.allDevices];
        this.populateFilterOptions();
    }

    /**
     * Populate filter dropdown options dynamically
     */
    populateFilterOptions() {
        const models = new Set();
        const platforms = new Set();

        this.allDevices.forEach(device => {
            if (device.model) models.add(device.model);
            if (device.platform) platforms.add(device.platform);
        });

        // Populate model filter
        const modelFilter = document.getElementById('modelFilter');
        if (modelFilter) {
            const currentValue = modelFilter.value;
            modelFilter.innerHTML = '<option value="">All Models</option>';
            Array.from(models).sort().forEach(model => {
                const option = document.createElement('option');
                option.value = model;
                option.textContent = model;
                if (model === currentValue) option.selected = true;
                modelFilter.appendChild(option);
            });
        }

        // Populate platform filter
        const platformFilter = document.getElementById('platformFilter');
        if (platformFilter) {
            const currentValue = platformFilter.value;
            platformFilter.innerHTML = '<option value="">All Platforms</option>';
            Array.from(platforms).sort().forEach(platform => {
                const option = document.createElement('option');
                option.value = platform;
                option.textContent = platform;
                if (platform === currentValue) option.selected = true;
                platformFilter.appendChild(option);
            });
        }
    }

    /**
     * Apply filters to device list
     */
    applyFilters() {
        const filters = {
            status: document.getElementById('statusFilter')?.value || '',
            model: document.getElementById('modelFilter')?.value || '',
            platform: document.getElementById('platformFilter')?.value || '',
            search: document.getElementById('deviceSearchExact')?.value.toLowerCase() || ''
        };

        this.filteredDevices = this.allDevices.filter(device => {
            // Status filter
            if (filters.status) {
                const deviceStatus = this.getDeviceStatus(device);
                
                // Handle special "active" filter that shows both connected and discovering
                if (filters.status === 'active') {
                    if (deviceStatus.statusClass !== 'connected' && deviceStatus.statusClass !== 'discovering') {
                        return false;
                    }
                } else {
                    // Regular single status filter
                    if (deviceStatus.statusClass !== filters.status) return false;
                }
            }

            // Model filter
            if (filters.model && device.model !== filters.model) return false;

            // Platform filter
            if (filters.platform && device.platform !== filters.platform) return false;

            // Search filter
            if (filters.search) {
                const searchFields = [
                    device.hostname || '',
                    device.ip_address || '',
                    device.model || '',
                    device.platform || ''
                ];
                if (!searchFields.some(field => 
                    field.toLowerCase().includes(filters.search)
                )) return false;
            }

            return true;
        });

        // Apply sorting
        this.sortDevices();
        this.renderFilteredDevices();
        this.updateFilterStatus();
        this.updateClearFiltersButton();
    }

    /**
     * Sort devices based on current sort configuration
     */
    sortDevices() {
        if (this.sortConfig.column) {
            this.filteredDevices.sort((a, b) => {
                let valueA, valueB;
                
                switch (this.sortConfig.column) {
                    case 'hostname':
                        valueA = (a.hostname || a.ip_address).toLowerCase();
                        valueB = (b.hostname || b.ip_address).toLowerCase();
                        break;
                    case 'ip':
                        valueA = a.ip_address;
                        valueB = b.ip_address;
                        break;
                    case 'model':
                        valueA = (a.model || 'unknown').toLowerCase();
                        valueB = (b.model || 'unknown').toLowerCase();
                        break;
                    case 'platform':
                        valueA = (a.platform || 'unknown').toLowerCase();
                        valueB = (b.platform || 'unknown').toLowerCase();
                        break;
                    case 'location':
                        valueA = (a.final_location_name || this.currentSessionLocation || '').toLowerCase();
                        valueB = (b.final_location_name || this.currentSessionLocation || '').toLowerCase();
                        break;
                    case 'status':
                        const statusA = this.getDeviceStatus(a);
                        const statusB = this.getDeviceStatus(b);
                        valueA = statusA.statusText.toLowerCase();
                        valueB = statusB.statusText.toLowerCase();
                        break;
                    default:
                        return 0;
                }

                if (valueA < valueB) return this.sortConfig.direction === 'asc' ? -1 : 1;
                if (valueA > valueB) return this.sortConfig.direction === 'asc' ? 1 : -1;
                return 0;
            });
        } else {
            // Default sorting by status priority (connected first, then others)
            this.filteredDevices.sort((a, b) => {
                const statusA = this.getDeviceStatus(a);
                const statusB = this.getDeviceStatus(b);
                
                // Define status priority (lower number = higher priority)
                const statusPriority = {
                    'connected': 1,
                    'discovering': 2,
                    'partial': 3,
                    'unreachable': 4,
                    'failed': 5,
                    'cancelled': 6
                };
                
                const priorityA = statusPriority[statusA.statusClass] || 7;
                const priorityB = statusPriority[statusB.statusClass] || 7;
                
                if (priorityA !== priorityB) {
                    return priorityA - priorityB;
                }
                
                // Secondary sort by hostname/IP
                const nameA = (a.hostname || a.ip_address).toLowerCase();
                const nameB = (b.hostname || b.ip_address).toLowerCase();
                return nameA.localeCompare(nameB);
            });
        }
    }

    /**
     * Render filtered devices in table
     */
    renderFilteredDevices() {
        const tableBody = document.getElementById('deviceTableBody');
        if (!tableBody) return;

        // Preserve checkbox states
        const selectedDeviceIPs = new Set();
        const checkboxes = tableBody.querySelectorAll('.device-checkbox');
        checkboxes.forEach(cb => {
            if (cb.checked && !cb.disabled) {
                const deviceRow = cb.closest('.table-row');
                if (deviceRow) {
                    const deviceIp = deviceRow.dataset.deviceIp;
                    if (deviceIp) {
                        selectedDeviceIPs.add(deviceIp);
                    }
                }
            }
        });

        // Clear and render filtered devices
        tableBody.innerHTML = '';
        
        if (this.filteredDevices.length === 0) {
            // Show empty state
            const emptyDiv = document.createElement('div');
            emptyDiv.className = 'empty-state';
            emptyDiv.innerHTML = `
                <div class="empty-state-icon">
                    <i class="fas fa-filter"></i>
                </div>
                <h4>No Devices Match Your Filters</h4>
                <p>Try adjusting your filter criteria to see more results.</p>
            `;
            tableBody.appendChild(emptyDiv);
        } else {
            this.filteredDevices.forEach((device, index) => {
                this.renderDeviceRow(device, index);
            });
        }
        
        // Restore checkbox states
        if (selectedDeviceIPs.size > 0) {
            const newCheckboxes = tableBody.querySelectorAll('.device-checkbox');
            newCheckboxes.forEach(cb => {
                if (!cb.disabled) {
                    const deviceRow = cb.closest('.table-row');
                    if (deviceRow) {
                        const deviceIp = deviceRow.dataset.deviceIp;
                        if (deviceIp && selectedDeviceIPs.has(deviceIp)) {
                            cb.checked = true;
                        }
                    }
                }
            });
        }
    }

    /**
     * Update filter status display
     */
    updateFilterStatus() {
        const hasActiveFilters = this.filteredDevices.length !== this.allDevices.length;
        const infoEl = document.getElementById('devicesInfo');
        const countEl = document.getElementById('deviceCount');
        
        if (infoEl) {
            if (hasActiveFilters) {
                infoEl.textContent = `Showing ${this.filteredDevices.length} of ${this.allDevices.length} devices`;
            } else {
                infoEl.textContent = 'Showing all devices';
            }
        }

        if (countEl) {
            countEl.textContent = this.filteredDevices.length;
        }
    }

    /**
     * Clear all filters and reset to defaults
     */
    clearFilters() {
        // Clear search
        const searchFilter = document.getElementById('deviceSearchExact');
        if (searchFilter) searchFilter.value = '';
        
        // Reset status to "active" (default - shows connected + discovering)
        const statusFilter = document.getElementById('statusFilter');
        if (statusFilter) statusFilter.value = 'active';
        
        // Clear model and platform filters
        const modelFilter = document.getElementById('modelFilter');
        if (modelFilter) modelFilter.value = '';
        
        const platformFilter = document.getElementById('platformFilter');
        if (platformFilter) platformFilter.value = '';
        
        // Reset sort to default
        this.sortConfig = { column: 'status', direction: 'desc' };
        this.updateSortHeaders();
        
        this.applyFilters();
    }

    /**
     * Display discovered devices in table
     */
    displayDevices(devices, isProgressive = false) {
        const tableBody = document.getElementById('deviceTableBody');
        const deviceCount = document.getElementById('deviceCount');
        
        if (!tableBody) return;
        
        if (!isProgressive) {
            // Clear table for initial load
            tableBody.innerHTML = '';
            this.knownDeviceIPs.clear();
            this.discoveredDevices = [];
        }
        
        // Process each device
        devices.forEach((device, index) => {
            const deviceIP = device.ip_address;
            
            if (isProgressive && this.knownDeviceIPs.has(deviceIP)) {
                // Update existing device - this handles status changes from "discovering" to "connected"
                this.updateExistingDevice(device);
                
                // Update the device in our local array as well
                const deviceIndex = this.discoveredDevices.findIndex(d => d.ip_address === deviceIP);
                if (deviceIndex !== -1) {
                    this.discoveredDevices[deviceIndex] = device;
                }
            } else {
                // Add new device only if we haven't seen this IP before
                this.addNewDevice(device, isProgressive ? this.discoveredDevices.length : index);
                this.knownDeviceIPs.add(deviceIP);
                if (isProgressive) {
                    this.discoveredDevices.push(device);
                }
            }
        });
        
        if (!isProgressive) {
            this.discoveredDevices = devices;
        }
        
        // Collect device data and apply filters
        this.collectDeviceData();
        
        // Set default filter to "active" (connected + discovering) on first load
        if (!isProgressive) {
            const statusFilter = document.getElementById('statusFilter');
            if (statusFilter && !statusFilter.value) {
                statusFilter.value = 'active';
            }
        }
        
        // Always apply filters to ensure proper rendering, especially during progressive updates
        this.applyFilters();
        this.updateSelectionInfo();
    }

    /**
     * Sort devices by status priority and render the table (legacy method - now uses applyFilters)
     */
    sortAndRenderDevices() {
        // Redirect to new filtering system
        this.applyFilters();
    }

    /**
     * Render a single device row
     */
    renderDeviceRow(device, index) {
        const tableBody = document.getElementById('deviceTableBody');
        if (!tableBody) return;

        const row = document.createElement('div');
        row.className = 'table-row';
        row.setAttribute('data-device-ip', device.ip_address);
        
        const {statusClass, statusText} = this.getDeviceStatus(device);
        
        // Determine if device can be selected for onboarding
        const isFailedDevice = this.isDeviceFailed(device);
        const checkboxDisabled = isFailedDevice ? 'disabled' : '';
        const checkboxTitle = isFailedDevice ? 'Failed devices cannot be selected for onboarding' : '';
        
        // Check if device is a stack
        const isStack = device.device_data && device.device_data.is_stack;
        const stackText = isStack ? `Stack Device with ${device.device_data.stack_info?.total_members || 'N/A'} members` : '';
        const stackBadge = isStack ? `<span class="stack-badge-small" title="${stackText}"><i class="fas fa-layer-group"></i>Stack</span>` : '';
        row.innerHTML = `
            <div>
                <input type="checkbox" class="device-checkbox" value="${device.ip_address}" 
                       data-index="${index}" onchange="networkDiscovery.updateSelectionInfo()" 
                       ${checkboxDisabled} title="${checkboxTitle}" />
            </div>
            <div style="display: flex; align-items: center; gap: 8px;">
                <span>${device.hostname || device.ip_address}</span>
                ${stackBadge}
            </div>
            <div>${device.ip_address}</div>
            <div>${device.model || 'Unknown'}</div>
            <div>${device.platform || 'Unknown'}</div>
            <div>
                <span class="final-location-display" data-device-ip="${device.ip_address}">
                    ${device.final_location_name || this.currentSessionLocation || 'Not Set'}
                </span>
            </div>
            <div style="display: flex; align-items: center; justify-content: space-between;">
                <span class="device-status ${statusClass}">${statusText}</span>
            </div>
            <div>
                ${statusText === 'Connected' ? 
                    `<button class="detail-button" onclick="networkDiscovery.showDeviceDetail('${device.ip_address}')">
                        <i class="fas fa-info-circle"></i> Details
                    </button>` : 
                    (statusClass === 'failed' || statusClass === 'unreachable') ?
                    `<button class="detail-button secondary" onclick="networkDiscovery.showDeviceDetail('${device.ip_address}')" title="Manage credentials">
                        <i class="fas fa-key"></i> Manage
                    </button>` :
                    '<span style="color: var(--text-muted); font-size: 12px;">-</span>'
                }
            </div>
        `;
        
        tableBody.appendChild(row);
    }

    /**
     * Add a new device row to the table (legacy method - now uses renderDeviceRow)
     */
    addNewDevice(device, index) {
        // This method is now handled by sortAndRenderDevices
        // Keep for backward compatibility but it's no longer used directly
        this.renderDeviceRow(device, index);
    }

    /**
     * Update an existing device row
     */
    updateExistingDevice(device) {
        // Update device in local array first
        const deviceIndex = this.discoveredDevices.findIndex(d => d.ip_address === device.ip_address);
        if (deviceIndex !== -1) {
            const oldDevice = this.discoveredDevices[deviceIndex];
            const oldStatus = this.getDeviceStatus(oldDevice);
            const newStatus = this.getDeviceStatus(device);
            
            this.discoveredDevices[deviceIndex] = device;
            
            // If status changed, trigger re-filter and sort to maintain proper order
            if (oldStatus.statusClass !== newStatus.statusClass) {
                this.applyFilters();
                return;
            }
        }
        
        // If no status change, just update the existing row
        const row = document.querySelector(`[data-device-ip="${device.ip_address}"]`);
        if (!row) {
            console.warn(`Could not find row for device ${device.ip_address} to update`);
            return;
        }
        
        // Preserve checkbox state before updating
        const checkbox = row.querySelector('.device-checkbox');
        const wasChecked = checkbox && checkbox.checked && !checkbox.disabled;
        
        const {statusClass, statusText} = this.getDeviceStatus(device);
        
        // Update device information
        const cells = row.children;
        
        // Update hostname (cell 1) - always update with latest hostname
        const newHostname = device.hostname || device.ip_address;
        const currentHostname = cells[1].textContent;
        
        // Update hostname if it's different and meaningful
        if (newHostname !== currentHostname) {
            // Prefer real hostnames over generated placeholders (discovering-, failed-, timeout-, etc.)
            const isPlaceholder = (hostname) => {
                return hostname.startsWith('discovering-') || 
                       hostname.startsWith('failed-') || 
                       hostname.startsWith('timeout-') || 
                       hostname.startsWith('unreachable-') ||
                       hostname.startsWith('auth_failed-') ||
                       hostname.startsWith('unknown-');
            };
            
            // Update if: new hostname is not a placeholder OR current hostname is a placeholder
            if (!isPlaceholder(newHostname) || isPlaceholder(currentHostname)) {
                cells[1].textContent = newHostname;
            }
        }
        
        // Update model and platform (cells 3 and 4) - update with any non-empty values
        if (device.model && device.model !== 'unknown' && device.model !== '') {
            cells[3].textContent = device.model;
        } else if (device.model === 'unknown' && cells[3].textContent === '') {
            cells[3].textContent = 'unknown';
        }
        
        if (device.platform && device.platform !== 'unknown' && device.platform !== '') {
            cells[4].textContent = device.platform;
        } else if (device.platform === 'unknown' && cells[4].textContent === '') {
            cells[4].textContent = 'unknown';
        }
        
        // Always update status (cell 5)
        const statusSpan = cells[5].querySelector('.device-status');
        if (statusSpan) {
            statusSpan.className = `device-status ${statusClass}`;
            statusSpan.textContent = statusText;
        }
        
        // Update actions column (cell 6) - show details for connected devices, show management options for failed
        const actionsCell = cells[6];
        if (statusText === 'Connected') {
            actionsCell.innerHTML = `
                <button class="detail-button" onclick="networkDiscovery.showDeviceDetail('${device.ip_address}')">
                    <i class="fas fa-info-circle"></i> Details
                </button>
            `;
        } else if (statusClass === 'failed' || statusClass === 'unreachable') {
            // Show credential management option for failed devices
            actionsCell.innerHTML = `
                <button class="detail-button secondary" onclick="networkDiscovery.showDeviceDetail('${device.ip_address}')" title="Manage credentials">
                    <i class="fas fa-key"></i> Manage
                </button>
            `;
        } else {
            actionsCell.innerHTML = '<span style="color: var(--text-muted); font-size: 12px;">-</span>';
        }
        
        // Restore checkbox state after update
        if (checkbox && wasChecked) {
            checkbox.checked = true;
        }
    }

    /**
     * Get device status class and text
     * Uses centralized status constants module
     */
    getDeviceStatus(device) {
        return window.DeviceStatusConstants.getDeviceStatus(device);
    }

    /**
     * Check if a device is in a failed state and should not be selected for onboarding
     * Uses centralized status constants module
     */
    isDeviceFailed(device) {
        return window.DeviceStatusConstants.isDeviceFailed(device);
    }

    /**
     * Handle select all checkbox
     */
    handleSelectAll(e) {
        const checkboxes = document.querySelectorAll('.device-checkbox:not(#selectAll)');
        checkboxes.forEach(cb => {
            if (!cb.disabled) {
                cb.checked = e.target.checked;
            }
        });
        this.updateSelectionInfo();
    }

    /**
     * Update selection information
     */
    updateSelectionInfo() {
        const checkboxes = document.querySelectorAll('.device-checkbox:not(#selectAll)');
        const selectedCount = Array.from(checkboxes).filter(cb => cb.checked && !cb.disabled).length;
        const totalCount = checkboxes.length;
        
        const selectionInfo = document.getElementById('selectionInfo');
        const prepareBtn = document.getElementById('prepareOnboarding');
        const exportBtn = document.getElementById('exportCSV');
        
        if (selectionInfo) {
            if (selectedCount === 0) {
                selectionInfo.textContent = 'No devices selected';
            } else {
                selectionInfo.textContent = `${selectedCount} of ${totalCount} devices selected`;
            }
        }
        
        if (prepareBtn) {
            prepareBtn.disabled = selectedCount === 0;
        }
        
        // Enable CSV export if there are any connected devices
        if (exportBtn) {
            const connectedDevices = this.discoveredDevices.filter(d => 
                d.connection_status === 'connected' && 
                d.hostname && 
                !window.DeviceStatusConstants.isDeviceFailed(d)
            );
            exportBtn.disabled = connectedDevices.length === 0;
        }

        // Enable topology view if there are any discovered devices
        const viewTopologyBtn = document.getElementById('viewTopology');
        if (viewTopologyBtn) {
            const validDevices = this.discoveredDevices.filter(d => 
                d.hostname && 
                !d.hostname.startsWith('unreachable-') && 
                !d.hostname.startsWith('failed-') && 
                !d.hostname.startsWith('error-') &&
                !d.hostname.startsWith('timeout-')
            );
            viewTopologyBtn.disabled = validDevices.length === 0;
        }
        
        // Update unreachable devices count and button state
        this.updateUnreachableDevicesInfo();
        
        // Update bulk credentials button state
        this.updateBulkCredentialsButton();
        
        // Update bulk location button state
        this.updateBulkLocationButton();
        
        // Update select all checkbox
        const selectAll = document.getElementById('selectAll');
        if (selectAll) {
            selectAll.indeterminate = selectedCount > 0 && selectedCount < totalCount;
            selectAll.checked = selectedCount === totalCount && totalCount > 0;
        }
    }

    /**
     * Update unreachable devices information and button state
     */
    updateUnreachableDevicesInfo() {
        const unreachableDevices = this.discoveredDevices.filter(d => 
            window.DeviceStatusConstants.isDeviceFailed(d)
        );
        
        const unreachableCount = unreachableDevices.length;
        const unreachableCountEl = document.getElementById('unreachableCount');
        const manageUnreachableBtn = document.getElementById('manageUnreachableDevices');
        
        if (unreachableCountEl) {
            unreachableCountEl.textContent = unreachableCount;
        }
        
        if (manageUnreachableBtn) {
            manageUnreachableBtn.disabled = unreachableCount === 0;
            if (unreachableCount > 0) {
                manageUnreachableBtn.classList.remove('disabled');
            } else {
                manageUnreachableBtn.classList.add('disabled');
            }
        }
    }

    /**
     * Update bulk credentials button state
     */
    updateBulkCredentialsButton() {
        const checkboxes = document.querySelectorAll('.device-checkbox:not(#selectAll)');
        const selectedCount = Array.from(checkboxes).filter(cb => cb.checked).length;
        const bulkCredentialsBtn = document.getElementById('bulkCredentialsBtn');
        
        if (bulkCredentialsBtn) {
            bulkCredentialsBtn.disabled = selectedCount === 0;
        }
    }

    /**
     * Update bulk location button state
     */
    updateBulkLocationButton() {
        const checkboxes = document.querySelectorAll('.device-checkbox:not(#selectAll)');
        const selectedCount = Array.from(checkboxes).filter(cb => cb.checked).length;
        const bulkLocationBtn = document.getElementById('bulkLocationBtn');
        
        if (bulkLocationBtn) {
            bulkLocationBtn.disabled = selectedCount === 0;
        }
    }

    /**
     * Handle prepare onboarding
     */
    async handlePrepareOnboarding() {
        if (!this.currentSessionId) return;
        
        const selectedDevices = this.getSelectedDevices();
        
        if (selectedDevices.length === 0) {
            window.commonPopup.alert('No Devices Selected', 'Please select devices to onboard before starting the onboarding process.', 'warning');
            return;
        }
        
        // Check if we need to use bulk onboarding
        const maxBulkDevices = await this.getMaxBulkDevices();
        const useBulkOnboarding = selectedDevices.length > 1;
        
        if (selectedDevices.length > maxBulkDevices) {
            window.commonPopup.alert(
                'Too Many Devices', 
                `You can onboard a maximum of ${maxBulkDevices} devices at once. Please select fewer devices or use multiple batches.`, 
                'warning'
            );
            return;
        }
        
        const prepareBtn = document.getElementById('prepareOnboarding');
        if (prepareBtn) prepareBtn.disabled = true;
        
        if (useBulkOnboarding) {
            this.updateStatus(`Starting bulk onboarding for ${selectedDevices.length} devices...`, 'loading', true);
            await this.handleBulkOnboarding(selectedDevices);
        } else {
            this.updateStatus('Starting device onboarding job...', 'loading', true);
            await this.handleSingleDeviceOnboarding(selectedDevices[0]);
        }
        
        if (prepareBtn) prepareBtn.disabled = false;
    }

    async handleBulkOnboarding(selectedDevices) {
        try {
            // First, update device selection in the database
            const selectedIps = selectedDevices.map(device => device.ip_address);
            
            const selectionResponse = await fetch(`/plugins/inventory/api/update-selection/${this.currentSessionId}/`, {
                method: 'POST',
                body: JSON.stringify({
                    selected_devices: selectedIps
                }),
                credentials: 'same-origin',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRFToken': this.getCsrfToken()
                }
            });
            
            const selectionData = await selectionResponse.json();
            
            if (selectionData.status !== 'success') {
                this.updateStatus(`Selection update failed: ${selectionData.message}`, 'error');
                return;
            }
            
            // Show warning if any failed devices were filtered out
            if (selectionData.filtered_count > 0) {
                window.commonPopup.alert(
                    'Some Devices Excluded',
                    `${selectionData.filtered_count} failed device(s) were excluded from onboarding selection. Only devices with successful connections can be onboarded.`,
                    'warning'
                );
            }
            
            // Get global settings if available
            let requestBody = {};
            if (window.globalSettingsManager) {
                const globalSettings = window.globalSettingsManager.getSettings();
                if (globalSettings && Object.keys(globalSettings).length > 0) {
                    requestBody.global_settings = globalSettings;
                    console.log('Using global settings for onboarding:', globalSettings);
                }
            }
            
            // Start bulk onboarding
            const response = await fetch(`/plugins/inventory/api/prepare-bulk-onboarding/${this.currentSessionId}/`, {
                method: 'POST',
                body: JSON.stringify({
                    device_ips: selectedIps,
                    device_names: selectedDevices.map(device => device.hostname || device.ip_address),
                    ...requestBody
                }),
                credentials: 'same-origin',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRFToken': this.getCsrfToken()
                }
            });
            
            const data = await response.json();
            
            if (data.status === 'success') {
                // Check if there are duplicate devices requiring confirmation
                if (data.requires_confirmation && data.duplicate_jobs && data.duplicate_jobs.length > 0) {
                    this.handleDuplicateDeviceConfirmation(data, 'bulk');
                } else {
                    this.updateStatus(`Bulk onboarding started for ${data.device_count} devices`, 'success');
                    
                    // Start monitoring bulk job progress
                    this.startBulkOnboardingJobMonitoring(data.batches);
                    
                    // Show bulk onboarding progress UI
                    this.showBulkOnboardingProgress(data);
                    
                    // Show success message
                    let message = `Bulk onboarding started successfully for ${data.device_count} devices!`;
                    
                    if (data.batches && data.batches.length > 1) {
                        message += `\n\nDevices split into ${data.batches.length} batches for optimal processing.`;
                    }
                    
                    if (data.failed_devices && data.failed_devices.length > 0) {
                        message += `\n\n⚠️ ${data.failed_devices.length} devices failed to start:`;
                        data.failed_devices.forEach(failure => {
                            message += `\n• ${failure.device}: ${failure.error}`;
                        });
                    }
                    
                    if (data.next_steps && data.next_steps.length > 0) {
                        message += `\n\nNext steps:\n${data.next_steps.join('\n')}`;
                    }
                    
                    const alertType = data.failed_devices && data.failed_devices.length > 0 ? 'warning' : 'success';
                    // window.commonPopup.alert('Bulk Onboarding Started', message, alertType);
                }
            } else {
                this.updateStatus(`Bulk onboarding failed: ${data.message}`, 'error');
                
                if (data.error_details) {
                    window.commonPopup.showDetailedError('Bulk Onboarding Failed', data);
                } else {
                    window.commonPopup.alert('Bulk Onboarding Failed', data.message, 'error');
                }
            }
            
        } catch (error) {
            this.updateStatus('Bulk onboarding preparation failed', 'error');
            console.error('Bulk onboarding error:', error);
        }
    }

    async handleSingleDeviceOnboarding(device) {
        try {
            // Use the original single device onboarding logic
            const selectedIps = [device.ip_address];

            let requestBody = {};
            if (window.globalSettingsManager) {
                const globalSettings = window.globalSettingsManager.getSettings();
                if (globalSettings && Object.keys(globalSettings).length > 0) {
                    requestBody.global_settings = globalSettings;
                    console.log('Using global settings for onboarding:', globalSettings);
                }
            }
            
            const selectionResponse = await fetch(`/plugins/inventory/api/update-selection/${this.currentSessionId}/`, {
                method: 'POST',
                body: JSON.stringify({
                    selected_devices: selectedIps
                }),
                credentials: 'same-origin',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRFToken': this.getCsrfToken()
                }
            });
            
            const selectionData = await selectionResponse.json();
            
            if (selectionData.status !== 'success') {
                this.updateStatus(`Selection update failed: ${selectionData.message}`, 'error');
                return;
            }
            
            // Now start onboarding jobs
            const response = await fetch(`/plugins/inventory/api/prepare-onboarding/${this.currentSessionId}/`, {
                method: 'POST',
                credentials: 'same-origin',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRFToken': this.getCsrfToken()
                },
                body: Object.keys(requestBody).length > 0 ? JSON.stringify(requestBody) : undefined
            });
            
            const data = await response.json();
            
            if (data.status === 'success') {
                // Check if there are duplicate devices requiring confirmation
                if (data.requires_confirmation && data.duplicate_jobs && data.duplicate_jobs.length > 0) {
                    this.handleDuplicateDeviceConfirmation(data, 'single');
                } else if (data.onboarding_jobs && data.onboarding_jobs.length > 0) {
                    this.updateStatus(`${data.onboarding_count} onboarding job started`, 'success');
                    this.startOnboardingJobMonitoring();
                    this.showOnboardingCards(data.onboarding_jobs, data.failed_jobs);
                } else {
                    this.updateStatus(`${data.onboarding_count} device prepared for CSV export`, 'success');
                    window.commonPopup.alert('CSV Export Ready', `Device onboarding plugin not available.<br><br><strong>${data.onboarding_count}</strong> device prepared for CSV export.<br><br><strong>Next steps:</strong><br>${data.next_steps.join('<br>')}`, 'info');
                }
            } else {
                this.updateStatus(`Onboarding failed: ${data.message}`, 'error');
                
                if (data.error_details) {
                    window.commonPopup.showDetailedError('Onboarding Failed', data);
                } else {
                    window.commonPopup.alert('Onboarding Failed', data.message, 'error');
                }
            }
            
        } catch (error) {
            this.updateStatus('Onboarding preparation failed', 'error');
            console.error('Onboarding error:', error);
        }
    }

    /**
     * Handle CSV export
     */
    handleExportCSV() {
        if (!this.currentSessionId) {
            window.commonPopup.alert('No Active Session', 'No active discovery session found. Please start a new discovery session.', 'warning');
            return;
        }
        
        // Download CSV file
        const downloadUrl = `/plugins/inventory/api/export-csv/${this.currentSessionId}/`;
        window.open(downloadUrl, '_blank');
    }

    /**
     * Handle view topology
     */
    handleViewTopology() {
        if (!this.currentSessionId) {
            window.commonPopup.alert('No Active Session', 'No active discovery session found. Please start a new discovery session.', 'warning');
            return;
        }

        // Check if we have any discovered devices
        if (this.discoveredDevices.length === 0) {
            window.commonPopup.alert('No Devices Found', 'No devices have been discovered yet. Please wait for discovery to complete or start a new discovery session.', 'warning');
            return;
        }

        // Open topology viewer in a new window/tab
        const topologyUrl = `/plugins/topology-viewer/viewer/discovery/${this.currentSessionId}/`;
        window.open(topologyUrl, '_blank');
    }

    /**
     * Handle new discovery
     */
    handleNewDiscovery() {
        // Stop all ongoing processes
        this.stopPolling();
        this.stopOnboardingJobMonitoring();
        
        // Clear all session data
        this.currentSessionId = null;
        this.discoveredDevices = [];
        this.knownDeviceIPs.clear();
        this.currentSessionLocation = null;
        this.currentSessionSecretsGroup = null;
        
        // Clear UI elements
        const discoveryForm = document.getElementById('discoveryForm');
        if (discoveryForm) discoveryForm.reset();
        
        const tableBody = document.getElementById('deviceTableBody');
        if (tableBody) tableBody.innerHTML = '';
        
        const deviceCount = document.getElementById('deviceCount');
        if (deviceCount) deviceCount.textContent = '0';
        
        // Clear onboarding cards container
        const onboardingCardsContainer = document.getElementById('onboardingCardsContainer');
        if (onboardingCardsContainer) {
            onboardingCardsContainer.innerHTML = '';
            onboardingCardsContainer.style.display = 'none';
        }
        
        // Hide results panel and show discovery form
        this.showDiscoveryForm();
        this.updateStatus('Ready for new discovery', 'ready');
        
        // Reset selection info
        this.updateSelectionInfo();
        
    }

    /**
     * Handle stop discovery
     */
    async handleStopDiscovery() {
        if (!this.currentSessionId) {
            window.commonPopup.alert('No Active Session', 'No active discovery session to stop.', 'warning');
            return;
        }

        const stopBtn = document.getElementById('stopDiscovery');
        
        // Confirm with user
        window.commonPopup.confirm(
            'Stop Discovery',
            'Are you sure you want to stop the discovery? Current results will be preserved.',
            () => {
                this.performStopDiscovery();
            }
        );
    }

    async performStopDiscovery() {
        const stopBtn = document.getElementById('stopDiscovery');
        
        // Disable stop button and show loading state
        if (stopBtn) {
            stopBtn.disabled = true;
            stopBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Stopping...';
        }
        
        this.updateStatus('Stopping discovery...', 'loading', true);

        try {
            const stopDiscoveryUrl = this.config.urls.stopDiscovery.replace('00000000-0000-0000-0000-000000000000', this.currentSessionId);
            const response = await fetch(stopDiscoveryUrl, {
                method: 'POST',
                credentials: 'same-origin',
                headers: {
                    'X-CSRFToken': this.getCsrfToken(),
                    'Content-Type': 'application/json',
                }
            });

            const data = await response.json();

            if (data.status === 'success') {
                // Stop polling immediately and update UI
                this.stopPolling();
                this.showStopButton(false);
                this.updateStatus(data.message, 'warning');
            } else {
                this.updateStatus(`Failed to stop discovery: ${data.message}`, 'error');
                // Re-enable stop button if stopping failed
                if (stopBtn) {
                    stopBtn.disabled = false;
                    stopBtn.innerHTML = '<i class="mdi mdi-stop"></i> Stop Discovery';
                }
            }

        } catch (error) {
            this.updateStatus('Error stopping discovery', 'error');
            console.error('Stop discovery error:', error);
            
            // Re-enable stop button if there was an error
            if (stopBtn) {
                stopBtn.disabled = false;
                stopBtn.innerHTML = '<i class="mdi mdi-stop"></i> Stop Discovery';
            }
        }
    }

    /**
     * Show device detail modal
     */
    showDeviceDetail(deviceIp) {
        if (!this.currentSessionId) {
            window.commonPopup.alert('No Active Session', 'No active discovery session found.', 'warning');
            return;
        }

        const device = this.discoveredDevices.find(d => d.ip_address === deviceIp);
        if (!device) {
            window.commonPopup.alert('Device Not Found', 'The requested device could not be found in the current session.', 'error');
            return;
        }
        
        const modal = document.getElementById('deviceDetailModal');
        const titleEl = document.getElementById('deviceDetailTitle');
        const contentEl = document.getElementById('deviceDetailContent');
        
        if (!modal || !titleEl || !contentEl) return;
        
        titleEl.textContent = `${device.hostname || device.ip_address} - Device Details`;
        contentEl.innerHTML = '<div style="text-align: center; padding: 20px;"><i class="fas fa-spinner fa-spin"></i> Loading device details...</div>';
        modal.style.display = 'flex';
        
        // Fetch detailed device information
        const deviceDetailsUrl = this.config.urls.deviceDetails
            .replace('00000000-0000-0000-0000-000000000000', this.currentSessionId)
            .replace('0.0.0.0', encodeURIComponent(deviceIp));
        fetch(deviceDetailsUrl, {
            method: 'GET',
            credentials: 'same-origin',
            headers: {
                'X-CSRFToken': this.getCsrfToken(),
                'Content-Type': 'application/json',
            }
        })
        .then(async response => {
            // Check if response is actually JSON
            const contentType = response.headers.get('content-type');
            if (!response.ok) {
                // Try to get error message from response
                let errorMessage = `HTTP ${response.status}: ${response.statusText}`;
                if (contentType && contentType.includes('application/json')) {
                    const errorData = await response.json();
                    errorMessage = errorData.message || errorMessage;
                }
                throw new Error(errorMessage);
            }
            
            if (!contentType || !contentType.includes('application/json')) {
                throw new Error('Server returned non-JSON response. This might be a server error or authentication issue.');
            }
            
            return response.json();
        })
        .then(data => {
            if (data.status === 'success') {
                this.renderDeviceDetails(data.device);
            } else {
                contentEl.innerHTML = `
                    <div style="color: var(--error-color); text-align: center; padding: 20px;">
                        <i class="fas fa-exclamation-triangle"></i><br/>
                        Failed to load device details: ${data.message || 'Unknown error'}
                    </div>
                `;
            }
        })
        .catch(error => {
            console.error('Error fetching device details:', error);
            contentEl.innerHTML = `
                <div style="color: var(--error-color); text-align: center; padding: 20px;">
                    <i class="fas fa-exclamation-triangle"></i><br/>
                    <strong>Error loading device details</strong><br/>
                    <span style="font-size: 0.9em; margin-top: 10px; display: block;">${error.message}</span>
                    ${error.message.includes('non-JSON') ? '<p style="font-size: 0.85em; margin-top: 10px;">Please check that the API endpoint is properly configured and accessible.</p>' : ''}
                </div>
            `;
        });
    }

    /**
     * Render device details in modal
     * Delegates to DeviceDetailManager for rendering, then adds discovery-specific functionality
     */
    renderDeviceDetails(device) {
        // If DeviceDetailManager is available, use it for rendering
        if (window.DeviceDetailManager && this.deviceDetailManager) {
            // Use DeviceDetailManager to render the device details
            this.deviceDetailManager.renderDeviceDetails(device);
            
            // After rendering, add discovery-specific functionality
            const contentEl = document.getElementById('deviceDetailContent');
            if (contentEl) {
                // Load onboarding data for the new tab
                this.loadOnboardingData(device.ip_address);
                
                // Setup device credential management
                this.setupDeviceCredentialManagement(device.ip_address);
            }
        } else {
            // Fallback: Basic display if DeviceDetailManager is not available
            const contentEl = document.getElementById('deviceDetailContent');
            if (!contentEl) return;
            
            contentEl.innerHTML = `
                <div class="device-info">
                    <h4>${device.hostname || device.ip_address}</h4>
                    <p><strong>IP:</strong> ${device.ip_address}</p>
                    <p><strong>Model:</strong> ${device.model || 'Unknown'}</p>
                    <p><strong>Platform:</strong> ${device.platform || 'Unknown'}</p>
                    <p><strong>Status:</strong> ${device.connection_status || 'Unknown'}</p>
                </div>
            `;
            
            // Still load onboarding data and setup credential management for fallback
            this.loadOnboardingData(device.ip_address);
            this.loadNautobotDropdownData();
            this.setupDeviceCredentialManagement(device.ip_address);
        }
    }

    /**
     * Close device detail modal
     */
    closeDeviceDetailModal() {
        const modal = document.getElementById('deviceDetailModal');
        if (modal) {
            modal.style.display = 'none';
        }
    }

    /**
     * Handle modal click events
     */
    handleModalClick(event) {
        const modal = document.getElementById('deviceDetailModal');
        if (modal && event.target === modal) {
            this.closeDeviceDetailModal();
        }
    }

    /**
     * Load Nautobot dropdown data for onboarding configuration
     */
    loadNautobotDropdownData() {
        if (this.nautobotData) {
            // Data already loaded
            this.populateOnboardingDropdowns(this.nautobotData);
            return;
        }

        // Get data from template context instead of API call
        const nautobotDataElement = document.getElementById('nautobot-data');
        if (nautobotDataElement) {
            try {
                this.nautobotData = JSON.parse(nautobotDataElement.textContent);
                this.populateOnboardingDropdowns(this.nautobotData);
            } catch (error) {
                console.error('Error parsing Nautobot data from template:', error);
                // Fallback to empty data
                this.nautobotData = {};
                this.populateOnboardingDropdowns({});
            }
        } else {
            console.error('Nautobot data element not found in template');
            // Fallback to empty data
            this.nautobotData = {};
            this.populateOnboardingDropdowns({});
        }
    }

    /**
     * Populate onboarding form dropdowns with Nautobot data
     */
    populateOnboardingDropdowns(data) {
        // Populate locations
        const locationSelect = document.getElementById('onb-location');
        if (locationSelect) {
            locationSelect.innerHTML = '<option value="">Select location...</option>';
            data.locations.forEach(location => {
                locationSelect.innerHTML += `<option value="${location.name}">${location.display}</option>`;
            });
            // Set default to discovery session location if available
            // Match by location name (currentSessionLocation stores name, not path)
            if (this.currentSessionLocation) {
                const matchingOption = Array.from(locationSelect.options).find(opt => 
                    opt.value === this.currentSessionLocation || 
                    opt.text.endsWith(' -> ' + this.currentSessionLocation)
                );
                if (matchingOption) {
                    locationSelect.value = matchingOption.value;
                }
            }
        }

        // Populate device roles
        const roleSelect = document.getElementById('onb-device-role');
        if (roleSelect) {
            roleSelect.innerHTML = '<option value="">Select role...</option>';
            data.device_roles.forEach(role => {
                const selected = role.name === 'Administrative' ? ' selected' : '';
                roleSelect.innerHTML += `<option value="${role.name}"${selected}>${role.display}</option>`;
            });
            // Default to Administrative role
            if (!roleSelect.value) {
                const adminOption = Array.from(roleSelect.options).find(opt => opt.value === 'Administrative');
                if (adminOption) {
                    roleSelect.value = 'Administrative';
                }
            }
        }

        // Populate namespaces
        const namespaceSelect = document.getElementById('onb-namespace');
        if (namespaceSelect) {
            namespaceSelect.innerHTML = '<option value="">Select namespace...</option>';
            data.namespaces.forEach(namespace => {
                const selected = namespace.name === 'Global' ? ' selected' : '';
                namespaceSelect.innerHTML += `<option value="${namespace.name}"${selected}>${namespace.display}</option>`;
            });
            // Default to Global namespace
            if (!namespaceSelect.value) {
                namespaceSelect.value = 'Global';
            }
        }

        // Populate device statuses
        const deviceStatusSelect = document.getElementById('onb-device-status');
        if (deviceStatusSelect) {
            deviceStatusSelect.innerHTML = '<option value="">Select status...</option>';
            data.device_statuses.forEach(status => {
                const selected = status.name === 'Active' ? ' selected' : '';
                deviceStatusSelect.innerHTML += `<option value="${status.name}"${selected}>${status.display}</option>`;
            });
            // Default to Active status
            if (!deviceStatusSelect.value) {
                deviceStatusSelect.value = 'Active';
            }
        }

        // Populate interface statuses
        const interfaceStatusSelect = document.getElementById('onb-interface-status');
        if (interfaceStatusSelect) {
            interfaceStatusSelect.innerHTML = '<option value="">Select status...</option>';
            data.interface_statuses.forEach(status => {
                const selected = status.name === 'Active' ? ' selected' : '';
                interfaceStatusSelect.innerHTML += `<option value="${status.name}"${selected}>${status.display}</option>`;
            });
            // Default to Active status
            if (!interfaceStatusSelect.value) {
                interfaceStatusSelect.value = 'Active';
            }
        }

        // Populate IP address statuses
        const ipStatusSelect = document.getElementById('onb-ip-status');
        if (ipStatusSelect) {
            ipStatusSelect.innerHTML = '<option value="">Select status...</option>';
            data.ip_address_statuses.forEach(status => {
                const selected = status.name === 'Active' ? ' selected' : '';
                ipStatusSelect.innerHTML += `<option value="${status.name}"${selected}>${status.display}</option>`;
            });
            // Default to Active status
            if (!ipStatusSelect.value) {
                ipStatusSelect.value = 'Active';
            }
        }

        // Populate secrets groups
        const secretsGroupSelect = document.getElementById('onb-secrets-group');
        if (secretsGroupSelect) {
            secretsGroupSelect.innerHTML = '<option value="">Select secrets group...</option>';
            data.secrets_groups.forEach(group => {
                secretsGroupSelect.innerHTML += `<option value="${group.name}">${group.display}</option>`;
            });
            // Set default to discovery session secrets group if available
            if (this.currentSessionSecretsGroup) {
                // Match by name (value) or display text
                const matchingOption = Array.from(secretsGroupSelect.options).find(opt => 
                    opt.value === this.currentSessionSecretsGroup || 
                    opt.text === this.currentSessionSecretsGroup
                );
                if (matchingOption) {
                    secretsGroupSelect.value = matchingOption.value;
                }
            }
        }

        // Populate platforms
        const platformSelect = document.getElementById('onb-platform');
        if (platformSelect) {
            platformSelect.innerHTML = '<option value="">Select platform...</option>';
            data.platforms.forEach(platform => {
                platformSelect.innerHTML += `<option value="${platform.name}">${platform.display}</option>`;
            });
        }

        // Populate final location dropdown (for actual onboarding location)
        const finalLocationSelect = document.getElementById('onb-final-location');
        if (finalLocationSelect) {
            finalLocationSelect.innerHTML = '<option value="">Select final location...</option>';
            data.locations.forEach(location => {
                finalLocationSelect.innerHTML += `<option value="${location.name}">${location.display}</option>`;
            });
        }

        // Populate bulk location assignment dropdown
        const bulkLocationAssignmentSelect = document.getElementById('bulk-location-assignment');
        if (bulkLocationAssignmentSelect) {
            bulkLocationAssignmentSelect.innerHTML = '<option value="">Select location for bulk assignment...</option>';
            data.locations.forEach(location => {
                bulkLocationAssignmentSelect.innerHTML += `<option value="${location.name}">${location.display}</option>`;
            });
        }
    }

    /**
     * Load onboarding data for a specific device
     */
    loadOnboardingData(deviceIp) {
        if (!this.currentSessionId) {
            return;
        }

        fetch(`/plugins/inventory/api/device-onboarding-data/${this.currentSessionId}/${encodeURIComponent(deviceIp)}/`, {
            method: 'GET',
            credentials: 'same-origin',
            headers: {
                'X-CSRFToken': this.getCsrfToken(),
                'Content-Type': 'application/json',
            }
        })
        .then(response => response.json())
        .then(data => {
            if (data.status === 'success') {
                this.populateOnboardingForm(data.onboarding_data);
                this.currentDeviceOnboardingData = data.onboarding_data;
            } else {
                console.error('Failed to load device onboarding data:', data.message);
            }
        })
        .catch(error => {
            console.error('Error fetching device onboarding data:', error);
        });
    }

    /**
     * Populate onboarding form with device data
     */
    populateOnboardingForm(data) {
        // Populate all form fields - scope to modal to avoid affecting main page elements
        const modal = document.getElementById('deviceDetailModal');
        if (!modal) return;
        
        Object.keys(data).forEach(key => {
            const element = modal.querySelector(`[data-field="${key}"]`);
            if (element) {
                if (element.type === 'checkbox') {
                    element.checked = data[key] === true || data[key] === 'True';
                } else {
                    element.value = data[key] || '';
                }
            }
        });

        // Handle final location field specifically
        const finalLocationSelect = document.getElementById('onb-final-location');
        if (finalLocationSelect && data.final_location_name) {
            finalLocationSelect.value = data.final_location_name;
        }
    }

    /**
     * Reset onboarding configuration to defaults
     */
    resetOnboardingDefaults() {
        if (this.currentDeviceOnboardingData) {
            this.populateOnboardingForm(this.currentDeviceOnboardingData);
        }
    }

    /**
     * Save onboarding configuration (placeholder for future implementation)
     */
    saveOnboardingConfig() {
        // Get all form values
        const formData = {};
        const onboardingTab = document.getElementById('onboarding-tab');
        if (onboardingTab) {
            const fields = onboardingTab.querySelectorAll('[data-field]');
            fields.forEach(field => {
                const fieldName = field.getAttribute('data-field');
                if (field.type === 'checkbox') {
                    formData[fieldName] = field.checked;
                } else {
                    formData[fieldName] = field.value;
                }
            });
        }

        // For now, just show a success message
        // In the future, this could save to the database
        window.commonPopup.alert('Configuration Saved', 'Onboarding configuration saved! These values will be used in the CSV export.', 'success');
    }

    /**
     * Start monitoring dual job progress (device sync + network data sync)
     */
    startOnboardingJobMonitoring() {
        if (this.onboardingJobPolling) {
            clearInterval(this.onboardingJobPolling);
        }

        let consecutiveErrors = 0;
        const maxConsecutiveErrors = 5;

        this.onboardingJobPolling = setInterval(async () => {
            try {
                const response = await fetch(`/plugins/inventory/api/dual-job-status/${this.currentSessionId}/`, {
                    credentials: 'same-origin',
                    headers: {
                        'X-CSRFToken': this.getCsrfToken()
                    },
                    timeout: 10000 // 10 second timeout
                });

                if (response.ok) {
                    const data = await response.json();
                    consecutiveErrors = 0; // Reset error counter on success
                    
                    // Handle redirect to bulk status endpoint
                    if (data.status === 'redirect') {
                        console.log('Session switched to bulk mode, redirecting to bulk monitoring');
                        this.stopOnboardingJobMonitoring();
                        this.startBulkOnboardingJobMonitoring([]);
                        return;
                    }
                    
                    if (data.status === 'success') {
                        // Update compact cards instead of old panel
                        this.updateOnboardingCards(data.job_statuses);
                        
                        // Check if all jobs are complete
                        const runningJobs = data.job_statuses.filter(job => 
                            job.overall_status === 'running'
                        );
                        
                        if (runningJobs.length === 0) {
                            // All jobs complete, stop monitoring
                            this.stopOnboardingJobMonitoring();
                            
                            const completedJobs = data.job_statuses.filter(job => job.overall_status === 'completed');
                            const partialJobs = data.job_statuses.filter(job => job.overall_status === 'partial_success');
                            const failedJobs = data.job_statuses.filter(job => job.overall_status === 'failed');
                            
                            let statusMessage = '';
                            let statusType = 'success';
                            
                            if (completedJobs.length > 0) {
                                statusMessage += `${completedJobs.length} fully completed`;
                            }
                            if (partialJobs.length > 0) {
                                statusMessage += `${statusMessage ? ', ' : ''}${partialJobs.length} partially completed`;
                                statusType = 'warning';
                            }
                            if (failedJobs.length > 0) {
                                statusMessage += `${statusMessage ? ', ' : ''}${failedJobs.length} failed`;
                                statusType = failedJobs.length === data.job_statuses.length ? 'error' : 'warning';
                            }
                            
                            this.updateStatus(
                                `Onboarding complete: ${statusMessage}`,
                                statusType
                            );
                        }
                    } else {
                        console.error('API returned error status:', data);
                        consecutiveErrors++;
                    }
                } else {
                    console.error(`HTTP error: ${response.status} ${response.statusText}`);
                    consecutiveErrors++;
                }
            } catch (error) {
                console.error('Error monitoring dual jobs:', error);
                consecutiveErrors++;
                
                // If we've had too many consecutive errors, stop monitoring
                if (consecutiveErrors >= maxConsecutiveErrors) {
                    console.error('Too many consecutive errors, stopping job monitoring');
                    this.stopOnboardingJobMonitoring();
                    this.updateStatus(
                        'Job monitoring stopped due to connection errors. Please refresh the page to check status.',
                        'error'
                    );
                }
            }
        }, 3000); // Check every 3 seconds for more responsive updates
    }

    /**
     * Stop monitoring onboarding job progress
     */
    stopOnboardingJobMonitoring() {
        if (this.onboardingJobPolling) {
            clearInterval(this.onboardingJobPolling);
            this.onboardingJobPolling = null;
        }
    }

    /**
     * Start monitoring bulk onboarding job progress
     */
    startBulkOnboardingJobMonitoring(bulkJobs) {
        if (this.bulkOnboardingJobPolling) {
            clearInterval(this.bulkOnboardingJobPolling);
        }
        
        this.bulkJobs = bulkJobs;
        
        this.bulkOnboardingJobPolling = setInterval(async () => {
            try {
                const response = await fetch(`/plugins/inventory/api/bulk-onboarding-status/${this.currentSessionId}/`, {
                    method: 'GET',
                    credentials: 'same-origin',
                    headers: {
                        'X-CSRFToken': this.getCsrfToken()
                    }
                });
                
                if (response.ok) {
                    const data = await response.json();
                    
                    if (data.status === 'success') {
                        // Handle both old format (data.data.batches) and new format (data.batches)
                        const bulkStatus = data.batches || (data.data && data.data.batches) || [];
                        this.updateBulkOnboardingProgress(bulkStatus);
                        
                        // Check if all jobs are complete
                        const allComplete = bulkStatus.every(batch => 
                            ['completed', 'failed', 'cancelled'].includes(batch.status)
                        );
                        
                        if (allComplete) {
                            this.stopBulkOnboardingJobMonitoring();
                            
                            // Use summary data if available for better status message
                            if (data.summary) {
                                const summary = data.summary;
                                const completedDevices = summary.device_sync_completed || 0;
                                const failedDevices = summary.failed_devices || 0;
                                const totalDevices = summary.total_devices || 0;
                                
                                let statusMessage = `Bulk onboarding completed: ${completedDevices}/${totalDevices} devices processed`;
                                let statusType = 'success';
                                
                                if (failedDevices > 0) {
                                    statusMessage += `, ${failedDevices} failed`;
                                    statusType = failedDevices === totalDevices ? 'error' : 'warning';
                                }
                                
                                this.updateStatus(statusMessage, statusType);
                            } else {
                                this.updateStatus('Bulk onboarding completed', 'success');
                            }
                        }
                    }
                }
            } catch (error) {
                console.error('Error checking bulk onboarding status:', error);
            }
        }, 5000); // Check every 5 seconds for bulk jobs
        
        // Also check immediately
        this.checkBulkOnboardingJobStatus();
    }

    /**
     * Check bulk onboarding job status immediately
     */
    async checkBulkOnboardingJobStatus() {
        if (!this.currentSessionId) return;
        
        try {
            const response = await fetch(`/plugins/inventory/api/bulk-onboarding-status/${this.currentSessionId}/`, {
                method: 'GET',
                credentials: 'same-origin',
                headers: {
                    'X-CSRFToken': this.getCsrfToken()
                }
            });
            
            if (response.ok) {
                const data = await response.json();
                
                if (data.status === 'success') {
                    // Handle both old format (data.data.batches) and new format (data.batches)
                    const bulkStatus = data.batches || (data.data && data.data.batches) || [];
                    this.updateBulkOnboardingProgress(bulkStatus);
                }
            }
        } catch (error) {
            console.error('Error checking bulk onboarding status:', error);
        }
    }

    /**
     * Stop monitoring bulk onboarding job progress
     */
    stopBulkOnboardingJobMonitoring() {
        if (this.bulkOnboardingJobPolling) {
            clearInterval(this.bulkOnboardingJobPolling);
            this.bulkOnboardingJobPolling = null;
        }
    }

    /**
     * Show bulk onboarding progress UI
     */
    showBulkOnboardingProgress(data) {
        const cardsContainer = document.getElementById('onboardingCardsContainer');
        if (!cardsContainer) return;

        // Show the container
        cardsContainer.style.display = 'grid';

        // Clear existing cards
        cardsContainer.innerHTML = '';

        // Get device count from summary or calculate from batches
        const deviceCount = (data.summary && data.summary.total_devices) || 
                           data.device_count || 
                           (data.batches ? data.batches.reduce((sum, batch) => sum + (batch.device_count || (batch.device_ips || []).length), 0) : 0);

        // Add bulk onboarding header
        const headerDiv = document.createElement('div');
        headerDiv.className = 'onboarding-summary-header';
        headerDiv.innerHTML = `
            <h4><i class="fas fa-layer-group"></i> Bulk Device Onboarding</h4>
            <p>Processing ${deviceCount} devices in ${data.batches ? data.batches.length : 1} batch(es)</p>
            ${data.summary ? `
                <div class="summary-stats">
                    <span class="stat-item">Device Sync: ${data.summary.device_sync_completed || 0}/${data.summary.total_devices || 0}</span>
                    <span class="stat-item">Network Data: ${data.summary.network_data_completed || 0}/${data.summary.total_devices || 0}</span>
                    ${data.summary.failed_devices > 0 ? `<span class="stat-item error">Failed: ${data.summary.failed_devices}</span>` : ''}
                    <span class="stat-item">Progress: ${Math.round(data.summary.overall_progress_percentage || 0)}%</span>
                </div>
            ` : ''}
        `;
        cardsContainer.appendChild(headerDiv);

        // Create batch cards
        if (data.batches) {
            data.batches.forEach((batch, index) => {
                const batchCard = this.createBulkOnboardingBatchCard(batch, index + 1);
                cardsContainer.appendChild(batchCard);
            });
        }

        // Show failed devices if any
        if (data.failed_devices && data.failed_devices.length > 0) {
            const failedCard = this.createFailedBulkOnboardingCard(data.failed_devices);
            cardsContainer.appendChild(failedCard);
        }
    }

    /**
     * Create a bulk onboarding batch card
     */
    createBulkOnboardingBatchCard(batch, batchNumber) {
        const actualBatchNumber = batch.batch_number || batchNumber;
        const card = document.createElement('div');
        card.className = `onboarding-card bulk-batch-card batch-${batch.status || 'pending'}`;
        card.id = `bulk-batch-${actualBatchNumber}`;

        const deviceList = (batch.device_ips || batch.devices || []).map(device => 
            `<span class="device-item">${typeof device === 'string' ? device : (device.hostname || device.ip)}</span>`
        ).join('');

        const deviceCount = batch.device_count || (batch.device_ips || batch.devices || []).length;

        card.innerHTML = `
            <div class="card-header">
                <div class="card-title">
                    <i class="fas fa-layer-group"></i>
                    Batch ${actualBatchNumber}
                    <small>(${deviceCount} devices)</small>
                </div>
                <span class="card-status status-${batch.status || 'pending'}">${this.formatJobStatus(batch.status || 'pending')}</span>
            </div>
            
            <div class="card-progress">
                <div class="card-progress-bar">
                    <div class="card-progress-fill" style="width: ${batch.progress || 0}%"></div>
                </div>
                <div class="card-progress-text">${batch.progress || 0}% Complete</div>
            </div>
            
            <div class="card-phases">
                <div class="card-phase ${this.getPhaseClass(batch.device_sync_status || 'pending')}" id="batch-${actualBatchNumber}-device-sync">
                    <div>
                        <i class="fas fa-server phase-icon"></i>
                        Device Sync
                    </div>
                    <div class="phase-link">
                        ${batch.job_result_id ? `<a href="/extras/job-results/${batch.job_result_id}/" target="_blank">View Job <i class="fas fa-external-link-alt"></i></a>` : `<span>${this.formatJobStatus(batch.device_sync_status || 'pending')}</span>`}
                    </div>
                </div>
                
                ${batch.has_stack_devices ? `
                <div class="card-phase ${this.getPhaseClass(batch.stack_member_status || 'pending')}" id="batch-${actualBatchNumber}-stack-members">
                    <div>
                        <i class="fas fa-layer-group phase-icon"></i>
                        Stack Members
                    </div>
                    <div class="phase-link">
                        <span>${this.formatJobStatus(batch.stack_member_status || 'pending')}</span>
                    </div>
                </div>
                ` : ''}
                
                <div class="card-phase ${this.getPhaseClass(batch.network_data_status || 'pending')}" id="batch-${actualBatchNumber}-network-data">
                    <div>
                        <i class="fas fa-network-wired phase-icon"></i>
                        Network Data Sync
                    </div>
                    <div class="phase-link">
                        ${batch.network_data_job_id ? `<a href="/extras/job-results/${batch.network_data_job_id}/" target="_blank">View Job <i class="fas fa-external-link-alt"></i></a>` : `<span>${this.formatJobStatus(batch.network_data_status || 'pending')}</span>`}
                    </div>
                </div>
            </div>
            
            <div class="card-devices">
                <h6><i class="fas fa-list"></i> Devices in this batch:</h6>
                <div class="device-list">${deviceList}</div>
            </div>
            
            ${batch.error ? `<div class="card-error">${batch.error}</div>` : ''}
            
        `;

        return card;
    }

    /**
     * Create a failed bulk onboarding card
     */
    createFailedBulkOnboardingCard(failedDevices) {
        const card = document.createElement('div');
        card.className = 'onboarding-card failed-devices-card failed';

        const failedList = failedDevices.map(failure => 
            `<div class="failed-device-item">
                <span class="device-name">${failure.device}</span>
                <span class="error-message">${failure.error}</span>
            </div>`
        ).join('');

        card.innerHTML = `
            <div class="card-header">
                <div class="card-title">
                    <i class="fas fa-exclamation-triangle"></i>
                    Failed Devices
                    <small>(${failedDevices.length} devices)</small>
                </div>
                <span class="card-status status-failed">Failed</span>
            </div>
            
            <div class="failed-devices-list">
                ${failedList}
            </div>
            
            <div class="card-actions">
                <button class="btn secondary" onclick="networkDiscovery.handleBulkCredentials()">
                    <i class="fas fa-key"></i> Manage Credentials
                </button>
                <button class="btn primary" onclick="networkDiscovery.retryFailedDevices()">
                    <i class="fas fa-redo"></i> Retry Failed
                </button>
            </div>
        `;

        return card;
    }

    /**
     * Update bulk onboarding progress
     */
    updateBulkOnboardingProgress(bulkStatus) {
        if (!bulkStatus) return;

        bulkStatus.forEach((batch, index) => {
            const batchNumber = batch.batch_number || (index + 1);
            const card = document.getElementById(`bulk-batch-${batchNumber}`);
            if (!card) return;

            // Update card status class
            card.className = `onboarding-card bulk-batch-card batch-${batch.status || 'pending'}`;

            // Update status badge
            const statusBadge = card.querySelector('.card-status');
            if (statusBadge) {
                statusBadge.className = `card-status status-${batch.status || 'pending'}`;
                statusBadge.textContent = this.formatJobStatus(batch.status || 'pending');
            }

            // Update progress bar
            const progressFill = card.querySelector('.card-progress-fill');
            const progressText = card.querySelector('.card-progress-text');
            if (progressFill && progressText) {
                const progress = batch.progress || 0;
                progressFill.style.width = `${progress}%`;
                progressText.textContent = `${progress}% Complete`;
            }

            // Update phases
            this.updateBatchPhases(card, batch, batchNumber);
        });
    }

    /**
     * Update batch phases
     */
    updateBatchPhases(card, batch, batchNumber) {
        // Update device sync phase
        const deviceSyncPhase = card.querySelector(`#batch-${batchNumber}-device-sync`);
        if (deviceSyncPhase) {
            deviceSyncPhase.className = `card-phase ${this.getPhaseClass(batch.device_sync_status || 'pending')}`;
            
            const phaseLink = deviceSyncPhase.querySelector('.phase-link');
            if (phaseLink && batch.job_result_id) {
                // Use job_result_id for device sync phase
                phaseLink.innerHTML = `<a href="/extras/job-results/${batch.job_result_id}/" target="_blank">View Job <i class="fas fa-external-link-alt"></i></a>`;
            } else if (phaseLink) {
                phaseLink.innerHTML = `<span>${this.formatJobStatus(batch.device_sync_status || 'pending')}</span>`;
            }
        }

        // Update stack member phase (if exists)
        const stackMemberPhase = card.querySelector(`#batch-${batchNumber}-stack-members`);
        if (stackMemberPhase) {
            stackMemberPhase.className = `card-phase ${this.getPhaseClass(batch.stack_member_status || 'pending')}`;
            
            const phaseLink = stackMemberPhase.querySelector('.phase-link');
            if (phaseLink) {
                phaseLink.innerHTML = `<span>${this.formatJobStatus(batch.stack_member_status || 'pending')}</span>`;
            }
        }

        // Update network data sync phase
        const networkDataPhase = card.querySelector(`#batch-${batchNumber}-network-data`);
        if (networkDataPhase) {
            networkDataPhase.className = `card-phase ${this.getPhaseClass(batch.network_data_status || 'pending')}`;
            
            const phaseLink = networkDataPhase.querySelector('.phase-link');
            if (phaseLink && batch.network_data_job_id) {
                // Use network_data_job_id for network data phase
                phaseLink.innerHTML = `<a href="/extras/job-results/${batch.network_data_job_id}/" target="_blank">View Job <i class="fas fa-external-link-alt"></i></a>`;
            } else if (phaseLink) {
                phaseLink.innerHTML = `<span>${this.formatJobStatus(batch.network_data_status || 'pending')}</span>`;
            }
        }
    }

    /**
     * Show compact onboarding cards for multiple devices
     */
    showOnboardingCards(onboardingJobs, failedJobs) {
        const cardsContainer = document.getElementById('onboardingCardsContainer');
        if (!cardsContainer) return;

        // Show the container
        cardsContainer.style.display = 'grid';

        // Clear existing cards
        cardsContainer.innerHTML = '';

        // Add summary header
        const totalJobs = onboardingJobs.length + failedJobs.length;
        const summaryHeader = document.createElement('div');
        summaryHeader.className = 'onboarding-summary-header';
        
        
        summaryHeader.innerHTML = `
            <h4 style="margin: 0 0 0.5rem 0;">
                <i class="fas fa-sync-alt"></i> Device Onboarding Progress
            </h4>
            <p style="margin: 0; opacity: 0.9;">
                ${totalJobs} device${totalJobs !== 1 ? 's' : ''} selected • 
                ${onboardingJobs.length} started • 
                ${failedJobs.length} failed
            </p>
        `;
        
        cardsContainer.appendChild(summaryHeader);

        // Create cards for successful jobs
        onboardingJobs.forEach(job => {
            const card = this.createOnboardingCard(job);
            cardsContainer.appendChild(card);
        });

        // Create cards for failed jobs
        failedJobs.forEach(failure => {
            const card = this.createFailedOnboardingCard(failure);
            cardsContainer.appendChild(card);
        });
    }

    /**
     * Create a compact onboarding card for a device
     */
    createOnboardingCard(job) {
        const card = document.createElement('div');
        card.className = 'onboarding-card running';
        card.id = `onboarding-card-${job.device.replace(/\./g, '-')}`;
        card.dataset.deviceIp = job.device;
        card.dataset.syncJobId = job.sync_devices_job_id;
        
        // Check if this is a stack device - check both job data and discoveredDevices
        let isStack = job.is_stack || false;
        let stackInfo = job.stack_info || {};
        let totalMembers = stackInfo.total_members || 'N/A';
        
        // If not in job data, check discoveredDevices for stack info
        if (!isStack && this.discoveredDevices) {
            const device = this.discoveredDevices.find(d => d.ip_address === job.device);
            if (device && device.device_data && device.device_data.is_stack) {
                isStack = true;
                stackInfo = device.device_data.stack_info || {};
                totalMembers = stackInfo.total_members || 'N/A';
            }
        }

        // Build phases HTML - include stack phase only for stack devices
        let phasesHtml = `
            <div class="card-phase running" id="phase-sync-${job.device.replace(/\./g, '-')}">
                <div>
                    <i class="fas fa-server phase-icon"></i>
                    <span>Device Sync</span>
                </div>
                <div class="phase-link">
                    <a href="/extras/job-results/${job.sync_devices_job_id}/?tab=main" target="_blank">
                        <i class="fas fa-external-link-alt"></i>
                    </a>
                </div>
            </div>
        `;
        
        // Add stack member phase only for stack devices
        if (isStack) {
            phasesHtml += `
                <div class="card-phase pending" id="phase-stack-${job.device.replace(/\./g, '-')}">
                    <div>
                        <i class="fas fa-layer-group phase-icon"></i>
                        <span>Stack Members (${totalMembers})</span>
                    </div>
                    <div class="phase-link">
                        <span>Pending</span>
                    </div>
                </div>
            `;
        }
        
        // Add network data phase
        phasesHtml += `
            <div class="card-phase pending" id="phase-network-${job.device.replace(/\./g, '-')}">
                <div>
                    <i class="fas fa-network-wired phase-icon"></i>
                    <span>Network Data Sync</span>
                </div>
                <div class="phase-link">
                    <span>Pending</span>
                </div>
            </div>
        `;

        card.innerHTML = `
            <div class="card-header">
                <div class="card-title">
                    <i class="fas fa-server"></i>
                    <span>${job.hostname || job.device}</span>
                    <small style="color: var(--text-muted); font-weight: normal;">(${job.device})</small>
                    ${isStack ? `<span class="stack-badge-small" title="Stack Device with ${totalMembers} members"><i class="fas fa-layer-group"></i>Stack</span>` : ''}
                </div>
                <div class="card-status status-running">Running</div>
            </div>
            
            <div class="card-progress">
                <div class="card-progress-bar">
                    <div class="card-progress-fill" style="width: 0%"></div>
                </div>
                <div class="card-progress-text">0% Complete</div>
            </div>
            
            <div class="card-phases">
                ${phasesHtml}
            </div>
            
            <div class="card-actions">
                <button class="btn secondary small" onclick="networkDiscovery.viewDeviceDetails('${job.device}')">
                    <i class="fas fa-eye"></i> Details
                </button>
                <button class="btn secondary small" onclick="networkDiscovery.refreshCardStatus('${job.device}')">
                    <i class="fas fa-sync-alt"></i> Refresh
                </button>
            </div>
        `;

        return card;
    }

    /**
     * Create a failed onboarding card
     */
    createFailedOnboardingCard(failure) {
        const card = document.createElement('div');
        card.className = 'onboarding-card failed';
        card.id = `onboarding-card-${failure.device.replace(/\./g, '-')}`;
        card.dataset.deviceIp = failure.device;

        card.innerHTML = `
            <div class="card-header">
                <div class="card-title">
                    <i class="fas fa-server"></i>
                    <span>${failure.device}</span>
                </div>
                <div class="card-status status-failed">Failed</div>
            </div>
            
            <div class="card-error">
                <strong>Error:</strong> ${failure.error}
            </div>
            
            <div class="card-actions">
                <button class="btn secondary small" onclick="networkDiscovery.viewDeviceDetails('${failure.device}')">
                    <i class="fas fa-eye"></i> Details
                </button>
                <button class="btn primary small" onclick="networkDiscovery.retryDeviceOnboarding('${failure.device}')">
                    <i class="fas fa-redo"></i> Retry
                </button>
            </div>
        `;

        return card;
    }

    /**
     * Update onboarding card status
     */
    updateOnboardingCard(deviceIp, jobStatus) {
        const card = document.getElementById(`onboarding-card-${deviceIp.replace(/\./g, '-')}`);
        if (!card) return;

        // Update card class based on overall status
        card.className = `onboarding-card ${jobStatus.overall_status}`;

        // Update status badge
        const statusBadge = card.querySelector('.card-status');
        if (statusBadge) {
            statusBadge.className = `card-status status-${jobStatus.overall_status}`;
            statusBadge.textContent = jobStatus.overall_status.charAt(0).toUpperCase() + jobStatus.overall_status.slice(1);
        }

        // Update progress
        const progressFill = card.querySelector('.card-progress-fill');
        const progressText = card.querySelector('.card-progress-text');
        if (progressFill && progressText) {
            const progress = jobStatus.progress || 0;
            progressFill.style.width = `${progress}%`;
            progressText.textContent = `${progress}% Complete`;
        }

        // Update phases
        this.updateCardPhases(card, jobStatus);

        // Update job links
        this.updateCardJobLinks(card, jobStatus);
    }

    /**
     * Update card phases based on job status
     */
    updateCardPhases(card, jobStatus) {
        const syncPhase = card.querySelector(`#phase-sync-${jobStatus.device_ip.replace(/\./g, '-')}`);
        const stackPhase = card.querySelector(`#phase-stack-${jobStatus.device_ip.replace(/\./g, '-')}`);
        const networkPhase = card.querySelector(`#phase-network-${jobStatus.device_ip.replace(/\./g, '-')}`);

        // Update Device Sync phase
        if (syncPhase) {
            syncPhase.className = `card-phase ${this.getPhaseClass(jobStatus.sync_devices_status)}`;
            const link = syncPhase.querySelector('.phase-link a');
            if (link && jobStatus.sync_devices_job_id) {
                link.href = `/extras/job-results/${jobStatus.sync_devices_job_id}/?tab=main`;
            }
        }

        // Update Stack Member phase (only for stack devices)
        // If stack phase doesn't exist but device is a stack, create it dynamically
        if (jobStatus.is_stack) {
            if (!stackPhase) {
                // Stack phase doesn't exist, create it dynamically
                const stackInfo = jobStatus.stack_info || {};
                const totalMembers = stackInfo.total_members || 'N/A';
                const networkPhase = card.querySelector(`#phase-network-${jobStatus.device_ip.replace(/\./g, '-')}`);
                
                // Create stack phase element
                const stackPhaseElement = document.createElement('div');
                stackPhaseElement.className = 'card-phase pending';
                stackPhaseElement.id = `phase-stack-${jobStatus.device_ip.replace(/\./g, '-')}`;
                stackPhaseElement.innerHTML = `
                    <div>
                        <i class="fas fa-layer-group phase-icon"></i>
                        <span>Stack Members (${totalMembers})</span>
                    </div>
                    <div class="phase-link">
                        <span>Pending</span>
                    </div>
                `;
                
                // Insert before network phase if it exists, otherwise append to card-phases
                const cardPhases = card.querySelector('.card-phases');
                if (networkPhase && cardPhases) {
                    cardPhases.insertBefore(stackPhaseElement, networkPhase);
                } else if (cardPhases) {
                    cardPhases.appendChild(stackPhaseElement);
                }
                
                // Update reference to the newly created phase
                stackPhase = stackPhaseElement;
            }
            
            // Now update the stack phase
            const stackStatus = jobStatus.stack_member_status || 'pending';
            stackPhase.className = `card-phase ${this.getPhaseClass(stackStatus)}`;
            const phaseLink = stackPhase.querySelector('.phase-link');
            
            if (jobStatus.stack_member_job_id && stackStatus === 'completed') {
                // Stack creation completed - show success indicator
                phaseLink.innerHTML = `<span style="color: var(--success-color);"><i class="fas fa-check-circle"></i></span>`;
            } else if (stackStatus === 'running') {
                phaseLink.innerHTML = `<span><i class="fas fa-spinner fa-spin"></i> Creating...</span>`;
            } else if (stackStatus === 'failed') {
                phaseLink.innerHTML = `<span style="color: var(--error-color);"><i class="fas fa-times-circle"></i> Failed</span>`;
            } else {
                phaseLink.innerHTML = `<span>Pending</span>`;
            }
        }

        // Update Network Data Sync phase
        if (networkPhase) {
            networkPhase.className = `card-phase ${this.getPhaseClass(jobStatus.network_data_status)}`;
            const phaseLink = networkPhase.querySelector('.phase-link');
            
            if (jobStatus.network_data_job_id) {
                // Network job has started, show link
                phaseLink.innerHTML = `
                    <a href="/extras/job-results/${jobStatus.network_data_job_id}/?tab=main" target="_blank">
                        <i class="fas fa-external-link-alt"></i>
                    </a>
                `;
            } else {
                // Network job not started yet, show status text
                const statusText = this.formatJobStatus(jobStatus.network_data_status);
                phaseLink.innerHTML = `<span>${statusText}</span>`;
            }
        }
    }

    /**
     * Update job links in card
     */
    updateCardJobLinks(card, jobStatus) {
        // Update sync job link
        const syncLink = card.querySelector(`#phase-sync-${jobStatus.device_ip.replace(/\./g, '-')} .phase-link a`);
        if (syncLink && jobStatus.sync_devices_job_id) {
            syncLink.href = `/extras/job-results/${jobStatus.sync_devices_job_id}/?tab=main`;
        }

        // Update network job link
        const networkLink = card.querySelector(`#phase-network-${jobStatus.device_ip.replace(/\./g, '-')} .phase-link a`);
        if (networkLink && jobStatus.network_data_job_id) {
            networkLink.href = `/extras/job-results/${jobStatus.network_data_job_id}/?tab=main`;
        }
    }

    /**
     * Refresh individual card status
     */
    async refreshCardStatus(deviceIp) {
        try {
            const response = await fetch(`/plugins/inventory/api/dual-job-status/${this.currentSessionId}/`, {
                credentials: 'same-origin',
                headers: {
                    'X-CSRFToken': this.getCsrfToken()
                }
            });

            if (response.ok) {
                const data = await response.json();
                if (data.status === 'success') {
                    const jobStatus = data.job_statuses.find(job => job.device_ip === deviceIp);
                    if (jobStatus) {
                        this.updateOnboardingCard(deviceIp, jobStatus);
                    }
                }
            }
        } catch (error) {
            console.error('Error refreshing card status:', error);
        }
    }

    /**
     * View device details (opens device detail modal)
     */
    viewDeviceDetails(deviceIp) {
        this.showDeviceDetail(deviceIp);
    }

    /**
     * Retry device onboarding
     */
    async retryDeviceOnboarding(deviceIp) {
        window.commonPopup.confirm(
            'Retry Device Onboarding',
            `Retry onboarding for device ${deviceIp}?`,
            async () => {
                try {
                    const response = await fetch(`/plugins/inventory/api/retry-onboarding/${this.currentSessionId}/${encodeURIComponent(deviceIp)}/`, {
                        method: 'POST',
                        credentials: 'same-origin',
                        headers: {
                            'X-CSRFToken': this.getCsrfToken(),
                            'Content-Type': 'application/json',
                        }
                    });

                    const data = await response.json();
                    
                    if (data.status === 'success') {
                        window.commonPopup.alert('Retry Started', `Onboarding retry started for ${deviceIp}.`, 'success');
                        // Refresh the card
                        this.refreshCardStatus(deviceIp);
                    } else {
                        window.commonPopup.alert('Retry Failed', `Failed to retry onboarding: ${data.message}`, 'error');
                    }
                } catch (error) {
                    console.error('Error retrying onboarding:', error);
                    window.commonPopup.alert('Error', 'An error occurred while retrying onboarding.', 'error');
                }
            }
        );
    }

    /**
     * Update all onboarding cards with current job statuses
     */
    updateOnboardingCards(jobStatuses) {
        jobStatuses.forEach(jobStatus => {
            this.updateOnboardingCard(jobStatus.device_ip, jobStatus);
        });
    }

    /**
     * Get CSS class for job phase status
     */
    getPhaseClass(status) {
        // Normalize status to lowercase for consistent mapping
        const normalizedStatus = status ? status.toLowerCase() : '';
        const statusMap = {
            'success': 'phase-success',
            'completed': 'phase-success',
            'running': 'phase-running',
            'pending': 'phase-pending',
            'failure': 'phase-error',
            'failed': 'phase-error',
            'cancelled': 'phase-cancelled',
            'not_found': 'phase-error',
            'not_applicable': 'phase-success'
        };
        return statusMap[normalizedStatus] || 'phase-unknown';
    }
    
    /**
     * Format job status for display
     */
    formatJobStatus(status) {
        // Normalize status to lowercase for consistent mapping
        const normalizedStatus = status ? status.toLowerCase() : '';
        const statusMap = {
            'success': 'Completed',
            'completed': 'Completed',
            'running': 'Running',
            'pending': 'Pending',
            'failure': 'Failed',
            'failed': 'Failed',
            'cancelled': 'Cancelled',
            'not_found': 'Not Found',
            'not_applicable': 'N/A'
        };
        return statusMap[normalizedStatus] || status;
    }

    /**
     * Handle manage unreachable devices
     */
    handleManageUnreachableDevices() {
        if (!window.unreachableDevicesManager) {
            window.unreachableDevicesManager = new UnreachableDevicesManager(this);
        }
        window.unreachableDevicesManager.show();
    }

    /**
     * Handle bulk credentials assignment
     */
    handleBulkCredentials() {
        if (!window.bulkCredentialsManager) {
            window.bulkCredentialsManager = new BulkCredentialsManager(this);
        }
        window.bulkCredentialsManager.show();
    }

    /**
     * Handle bulk location assignment
     */
    handleBulkLocation() {
        const selectedDevices = this.getSelectedDevices();
        if (selectedDevices.length === 0) {
            commonPopup.alert('No Selection', 'Please select devices first.');
            return;
        }

        this.showBulkLocationPanel(selectedDevices);
    }

    /**
     * Show bulk location assignment panel
     */
    showBulkLocationPanel(selectedDevices) {
        const panel = document.getElementById('bulkLocationPanel');
        const deviceCountSpan = document.getElementById('bulkLocationDeviceCount');
        const locationSelect = document.getElementById('bulkLocationSelect');
        
        if (panel && deviceCountSpan && locationSelect) {
            deviceCountSpan.textContent = selectedDevices.length;
            
            // Load locations into the dropdown
            this.loadLocationsIntoSelect(locationSelect);
            
            panel.style.display = 'block';
            panel.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        }
    }

    /**
     * Hide bulk location assignment panel
     */
    hideBulkLocationPanel() {
        const panel = document.getElementById('bulkLocationPanel');
        if (panel) {
            panel.style.display = 'none';
        }
    }

    /**
     * Handle apply bulk location from main panel
     */
    async handleApplyBulkLocation() {
        const locationSelect = document.getElementById('bulkLocationSelect');
        const selectedLocation = locationSelect.value;
        
        if (!selectedLocation) {
            commonPopup.alert('No Location Selected', 'Please select a location first.');
            return;
        }

        const selectedDevices = this.getSelectedDevices();
        if (selectedDevices.length === 0) {
            commonPopup.alert('No Selection', 'Please select devices first.');
            return;
        }

        await this.applyBulkLocation(selectedDevices, selectedLocation);
    }

    /**
     * Handle apply bulk location from device detail modal
     */
    async handleApplyBulkLocationFromModal() {
        const locationSelect = document.getElementById('bulk-location-assignment');
        const selectedLocation = locationSelect.value;
        
        if (!selectedLocation) {
            commonPopup.alert('No Location Selected', 'Please select a location first.');
            return;
        }

        const selectedDevices = this.getSelectedDevices();
        if (selectedDevices.length === 0) {
            commonPopup.alert('No Selection', 'Please select devices first.');
            return;
        }

        await this.applyBulkLocation(selectedDevices, selectedLocation);
    }

    /**
     * Apply bulk location to selected devices
     */
    async applyBulkLocation(selectedDevices, locationName) {
        try {
            const response = await fetch(`/plugins/inventory/api/bulk-location/${this.currentSessionId}/`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRFToken': this.getCsrfToken()
                },
                body: JSON.stringify({
                    device_ips: selectedDevices.map(d => d.ip_address),
                    location_name: locationName
                })
            });

            if (!response.ok) {
                const errorData = await response.json();
                throw new Error(errorData.message || 'Failed to update device locations');
            }

            const result = await response.json();
            
            // Update the devices in the main discoveredDevices array
            selectedDevices.forEach(selectedDevice => {
                const deviceIndex = this.discoveredDevices.findIndex(d => d.ip_address === selectedDevice.ip_address);
                if (deviceIndex !== -1) {
                    this.discoveredDevices[deviceIndex].final_location_name = locationName;
                }
            });

            // Force a complete re-render of the device table to ensure all updates are visible
            this.displayDevices(this.discoveredDevices, false);
            
            // Hide the bulk location panel
            this.hideBulkLocationPanel();
            
        } catch (error) {
            console.error('Error applying bulk location:', error);
            commonPopup.showDetailedError('Bulk Location Error', {
                message: error.message,
                details: 'Failed to update device locations'
            });
        }
    }

    /**
     * Get selected devices
     */
    getSelectedDevices() {
        const checkboxes = document.querySelectorAll('.device-checkbox:not(#selectAll)');
        const selectedDevices = [];
        
        
        checkboxes.forEach((checkbox, index) => {
            if (checkbox.checked) {
                const deviceRow = checkbox.closest('.table-row');
                if (deviceRow) {
                    const deviceIp = deviceRow.dataset.deviceIp;
                    
                    // Find the actual device object from discoveredDevices
                    const actualDevice = this.discoveredDevices.find(d => d.ip_address === deviceIp);
                    
                    // Skip failed devices as a safety check
                    if (actualDevice && this.isDeviceFailed(actualDevice)) {
                        console.warn(`Skipping failed device ${deviceIp} from selection`);
                        return;
                    }
                    
                    // Get device data from the row divs (the actual structure from renderDeviceRow)
                    const rowDivs = deviceRow.querySelectorAll('div');
                    const deviceData = {
                        ip_address: deviceIp,
                        hostname: rowDivs[1]?.textContent?.trim() || deviceIp, // Second div contains hostname
                        model: rowDivs[3]?.textContent?.trim() || 'Unknown', // Fourth div contains model
                        platform: rowDivs[4]?.textContent?.trim() || 'Unknown', // Fifth div contains platform
                        connection_status: rowDivs[6]?.querySelector('.device-status')?.textContent?.trim() || 'Unknown', // Seventh div contains status
                        selected_for_onboarding: true
                    };
                    selectedDevices.push(deviceData);
                }
            }
        });
        
        return selectedDevices;
    }

    /**
     * Load locations into a select element
     */
    loadLocationsIntoSelect(selectElement) {
        if (!this.nautobotData || !this.nautobotData.locations) {
            selectElement.innerHTML = '<option value="">Loading locations...</option>';
            // Try to load Nautobot data if not already loaded
            this.loadNautobotDropdownData();
            return;
        }

        selectElement.innerHTML = '<option value="">Select location...</option>';
        this.nautobotData.locations.forEach(location => {
            const option = document.createElement('option');
            option.value = location.name;
            option.textContent = location.display || location.name; // Use display name if available
            selectElement.appendChild(option);
        });
    }

    /**
     * Setup device credential management in the device detail modal
     */
    setupDeviceCredentialManagement(deviceIp) {
        // Load existing credential status
        this.loadDeviceCredentialStatus(deviceIp);
        
        // Setup template buttons
        const templateButtons = document.querySelectorAll('#credentials-tab .template-btn[data-template]');
        templateButtons.forEach(btn => {
            btn.addEventListener('click', (e) => this.applyCredentialTemplate(e.target.dataset.template));
        });

        // Setup action buttons
        const testCredentialsBtn = document.getElementById('testCredentialsBtn');
        if (testCredentialsBtn) {
            testCredentialsBtn.addEventListener('click', () => this.testDeviceCredentials(deviceIp));
        }

        const saveCredentialsBtn = document.getElementById('saveCredentialsBtn');
        if (saveCredentialsBtn) {
            saveCredentialsBtn.addEventListener('click', () => this.saveDeviceCredentials(deviceIp));
        }

        const retryDiscoveryBtn = document.getElementById('retryDiscoveryBtn');
        if (retryDiscoveryBtn) {
            retryDiscoveryBtn.addEventListener('click', () => this.retryDeviceDiscovery(deviceIp));
        }
    }

    /**
     * Load device credential status
     */
    async loadDeviceCredentialStatus(deviceIp) {
        try {
            const response = await fetch(`/plugins/inventory/api/device-credentials/${this.currentSessionId}/${encodeURIComponent(deviceIp)}/`, {
                method: 'GET',
                credentials: 'same-origin',
                headers: {
                    'X-CSRFToken': this.getCsrfToken(),
                    'Content-Type': 'application/json',
                }
            });

            const data = await response.json();
            
            if (data.status === 'success') {
                this.updateCredentialStatusDisplay(data.credentials);
                if (data.credentials && data.credentials.username) {
                    this.populateCredentialForm(data.credentials);
                }
            }
        } catch (error) {
            console.error('Error loading device credentials:', error);
        }
    }

    /**
     * Update credential status display
     */
    updateCredentialStatusDisplay(credentials) {
        const statusCard = document.getElementById('credentialStatusCard');
        const statusText = document.getElementById('credentialStatusText');
        const statusDetails = document.getElementById('credentialStatusDetails');
        
        if (!statusCard || !statusText) return;

        if (credentials && credentials.username) {
            statusText.textContent = 'Custom credentials configured';
            statusCard.className = 'credential-status-card has-credentials';
            
            if (statusDetails) {
                statusDetails.innerHTML = `
                    <div class="credential-detail-item">
                        <span class="credential-detail-label">Username:</span>
                        <span class="credential-detail-value">${credentials.username}</span>
                    </div>
                    <div class="credential-detail-item">
                        <span class="credential-detail-label">Device Type:</span>
                        <span class="credential-detail-value">${credentials.device_type || 'cisco_ios'}</span>
                    </div>
                    <div class="credential-detail-item">
                        <span class="credential-detail-label">Protocol:</span>
                        <span class="credential-detail-value">${credentials.protocol || 'ssh'}</span>
                    </div>
                    <div class="credential-detail-item">
                        <span class="credential-detail-label">Port:</span>
                        <span class="credential-detail-value">${credentials.port || 22}</span>
                    </div>
                `;
                statusDetails.style.display = 'block';
            }

            // Show retry button
            const retryBtn = document.getElementById('retryDiscoveryBtn');
            if (retryBtn) {
                retryBtn.style.display = 'inline-block';
            }
        } else {
            statusText.textContent = 'No custom credentials configured';
            statusCard.className = 'credential-status-card no-credentials';
            if (statusDetails) {
                statusDetails.style.display = 'none';
            }
        }
    }

    /**
     * Populate credential form with existing data
     */
    populateCredentialForm(credentials) {
        document.getElementById('cred-username').value = credentials.username || '';
        document.getElementById('cred-password').value = ''; // Don't populate password for security
        document.getElementById('cred-enable-password').value = ''; // Don't populate password for security
        document.getElementById('cred-device-type').value = credentials.device_type || 'cisco_ios';
        document.getElementById('cred-protocol').value = credentials.protocol || 'ssh';
        document.getElementById('cred-port').value = credentials.port || 22;
        document.getElementById('cred-timeout').value = credentials.timeout || 30;
    }

    /**
     * Apply credential template
     */
    applyCredentialTemplate(template) {
        const templates = {
            cisco_ios: {
                deviceType: 'cisco_ios',
                protocol: 'ssh',
                port: 22
            },
            cisco_nxos: {
                deviceType: 'cisco_nxos',
                protocol: 'ssh',
                port: 22
            },
            arista_eos: {
                deviceType: 'arista_eos',
                protocol: 'ssh',
                port: 22
            },
            juniper: {
                deviceType: 'juniper',
                protocol: 'ssh',
                port: 22
            },
            hp_procurve: {
                deviceType: 'hp_procurve',
                protocol: 'ssh',
                port: 22
            }
        };

        const templateData = templates[template];
        if (templateData) {
            document.getElementById('cred-device-type').value = templateData.deviceType;
            document.getElementById('cred-protocol').value = templateData.protocol;
            document.getElementById('cred-port').value = templateData.port;
        }
    }

    /**
     * Test device credentials
     */
    async testDeviceCredentials(deviceIp) {
        const formData = this.getDeviceCredentialFormData();
        
        if (!formData.username || !formData.password) {
            window.commonPopup.alert('Missing Required Fields', 'Please provide both username and password to test credentials.', 'warning');
            return;
        }

        const testBtn = document.getElementById('testCredentialsBtn');
        if (testBtn) {
            testBtn.disabled = true;
            testBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Testing...';
        }

        try {
            const response = await fetch(`/plugins/inventory/api/test-device-credentials/${this.currentSessionId}/${encodeURIComponent(deviceIp)}/`, {
                method: 'POST',
                credentials: 'same-origin',
                headers: {
                    'X-CSRFToken': this.getCsrfToken(),
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    credentials: formData
                })
            });

            const data = await response.json();
            
            this.displayTestResults(data);
            
        } catch (error) {
            console.error('Error testing credentials:', error);
            this.displayTestResults({
                status: 'error',
                message: 'An error occurred while testing credentials'
            });
        } finally {
            if (testBtn) {
                testBtn.disabled = false;
                testBtn.innerHTML = '<i class="fas fa-vial"></i> Test Connection';
            }
        }
    }

    /**
     * Display test results
     */
    displayTestResults(data) {
        const testResultsSection = document.getElementById('testResultsSection');
        const testResultsContent = document.getElementById('testResultsContent');
        
        if (!testResultsSection || !testResultsContent) return;

        let resultHtml = '';
        let resultClass = '';

        if (data.status === 'success') {
            resultClass = 'test-success';
            resultHtml = `
                <div class="test-result ${resultClass}">
                    <div class="test-result-header">
                        <i class="fas fa-check-circle"></i>
                        <span>Connection Successful</span>
                    </div>
                    <div class="test-result-details">
                        <p>${data.message}</p>
                        ${data.device_info ? `<pre class="test-output">${data.device_info}</pre>` : ''}
                    </div>
                </div>
            `;
        } else {
            resultClass = 'test-error';
            resultHtml = `
                <div class="test-result ${resultClass}">
                    <div class="test-result-header">
                        <i class="fas fa-times-circle"></i>
                        <span>Connection Failed</span>
                    </div>
                    <div class="test-result-details">
                        <p>${data.message}</p>
                        ${data.error_details ? `<pre class="test-output">${data.error_details}</pre>` : ''}
                    </div>
                </div>
            `;
        }

        testResultsContent.innerHTML = resultHtml;
        testResultsSection.style.display = 'block';
    }

    /**
     * Save device credentials
     */
    async saveDeviceCredentials(deviceIp) {
        const formData = this.getDeviceCredentialFormData();
        
        if (!formData.username || !formData.password) {
            window.commonPopup.alert('Missing Required Fields', 'Please provide both username and password.', 'warning');
            return;
        }

        try {
            const response = await fetch(`/plugins/inventory/api/save-device-credentials/${this.currentSessionId}/${encodeURIComponent(deviceIp)}/`, {
                method: 'POST',
                credentials: 'same-origin',
                headers: {
                    'X-CSRFToken': this.getCsrfToken(),
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    credentials: formData
                })
            });

            const data = await response.json();
            
            if (data.status === 'success') {
                window.commonPopup.alert('Credentials Saved', 'Device credentials have been saved successfully.', 'success');
                this.updateCredentialStatusDisplay(formData);
                
                // Show retry button
                const retryBtn = document.getElementById('retryDiscoveryBtn');
                if (retryBtn) {
                    retryBtn.style.display = 'inline-block';
                }
            } else {
                window.commonPopup.alert('Save Failed', `Failed to save credentials: ${data.message}`, 'error');
            }
        } catch (error) {
            console.error('Error saving credentials:', error);
            window.commonPopup.alert('Error', 'An error occurred while saving credentials.', 'error');
        }
    }

    /**
     * Retry device discovery with new credentials
     */
    async retryDeviceDiscovery(deviceIp) {
        window.commonPopup.confirm(
            'Retry Device Discovery',
            `Retry discovery for device ${deviceIp} using the configured custom credentials?`,
            () => {
                this.performRetryDeviceDiscovery(deviceIp);
            }
        );
    }

    /**
     * Perform retry device discovery
     */
    async performRetryDeviceDiscovery(deviceIp) {
        try {
            const response = await fetch(`/plugins/inventory/api/retry-device/${this.currentSessionId}/${encodeURIComponent(deviceIp)}/`, {
                method: 'POST',
                credentials: 'same-origin',
                headers: {
                    'X-CSRFToken': this.getCsrfToken(),
                    'Content-Type': 'application/json',
                }
            });

            const data = await response.json();
            
            if (data.status === 'success') {
                window.commonPopup.alert('Retry Started', `Retry discovery started for ${deviceIp}. The device status will be updated automatically. You can close this modal and check the main device list.`, 'success');
                this.closeDeviceDetailModal();
            } else {
                window.commonPopup.alert('Retry Failed', `Failed to retry device ${deviceIp}: ${data.message}`, 'error');
            }
        } catch (error) {
            console.error('Error retrying device discovery:', error);
            window.commonPopup.alert('Error', 'An error occurred while retrying device discovery.', 'error');
        }
    }

    /**
     * Get device credential form data
     */
    getDeviceCredentialFormData() {
        return {
            username: document.getElementById('cred-username').value,
            password: document.getElementById('cred-password').value,
            enable_password: document.getElementById('cred-enable-password').value,
            device_type: document.getElementById('cred-device-type').value,
            protocol: document.getElementById('cred-protocol').value,
            port: parseInt(document.getElementById('cred-port').value) || 22,
            timeout: parseInt(document.getElementById('cred-timeout').value) || 30
        };
    }

    /**
     * View batch details
     */
    viewBatchDetails(batchNumber) {
        // This could open a modal with detailed batch information
        console.log(`Viewing details for batch ${batchNumber}`);
        // TODO: Implement batch details modal
    }

    /**
     * Retry a failed batch
     */
    async retryBatch(batchNumber) {
        try {
            const response = await fetch(`/plugins/inventory/api/retry-batch/${this.currentSessionId}/${batchNumber}/`, {
                method: 'POST',
                credentials: 'same-origin',
                headers: {
                    'X-CSRFToken': this.getCsrfToken()
                }
            });
            
            const data = await response.json();
            
            if (data.status === 'success') {
                this.updateStatus(`Batch ${batchNumber} retry started`, 'success');
                // Restart monitoring if needed
                if (!this.bulkOnboardingJobPolling) {
                    this.startBulkOnboardingJobMonitoring(this.bulkJobs);
                }
            } else {
                window.commonPopup.alert('Retry Failed', data.message, 'error');
            }
        } catch (error) {
            console.error('Error retrying batch:', error);
            window.commonPopup.alert('Retry Failed', 'An error occurred while retrying the batch.', 'error');
        }
    }

    /**
     * Retry failed devices from bulk onboarding
     */
    async retryFailedDevices() {
        try {
            const response = await fetch(`/plugins/inventory/api/retry-failed-devices/${this.currentSessionId}/`, {
                method: 'POST',
                credentials: 'same-origin',
                headers: {
                    'X-CSRFToken': this.getCsrfToken()
                }
            });
            
            const data = await response.json();
            
            if (data.status === 'success') {
                this.updateStatus(`Retry started for ${data.device_count} failed devices`, 'success');
                // Restart monitoring if needed
                if (!this.bulkOnboardingJobPolling) {
                    this.startBulkOnboardingJobMonitoring(data.batches);
                }
            } else {
                window.commonPopup.alert('Retry Failed', data.message, 'error');
            }
        } catch (error) {
            console.error('Error retrying failed devices:', error);
            window.commonPopup.alert('Retry Failed', 'An error occurred while retrying failed devices.', 'error');
        }
    }

    /**
     * Create device batches for bulk processing
     */
    createDeviceBatches(devices, batchSize = 50) {
        const batches = [];
        for (let i = 0; i < devices.length; i += batchSize) {
            batches.push(devices.slice(i, i + batchSize));
        }
        return batches;
    }

    /**
     * Handle duplicate device confirmation dialog
     */
    handleDuplicateDeviceConfirmation(data, operationType = 'single') {
        const duplicateDevices = data.duplicate_jobs || [];
        
        if (duplicateDevices.length === 0) {
            return;
        }
        
        const isBulk = operationType === 'bulk';
        const totalDevices = data.total_device_count || duplicateDevices.length;
        const cleanDevices = data.clean_device_count || 0;
        
        // Build detailed confirmation message
        let confirmationContent = `
            <div class="duplicate-device-warning">
                <div class="alert alert-warning">
                    <h5>Duplicate Devices Detected</h5>
                    <p>
                        ${isBulk ? `Out of ${totalDevices} selected devices, ` : ''}
                        ${duplicateDevices.length} device${duplicateDevices.length !== 1 ? 's' : ''} already exist${duplicateDevices.length === 1 ? 's' : ''} in Nautobot or have previous onboarding jobs.
                        ${cleanDevices > 0 ? ` ${cleanDevices} device${cleanDevices !== 1 ? 's' : ''} can proceed without issues.` : ''}
                    </p>
                </div>
                
                <div class="duplicate-devices-list">
        `;
        
        duplicateDevices.forEach(device => {
            const duplicateInfo = device.duplicate_info || {};
            const warningLevel = duplicateInfo.warning_level || 'medium';
            const warningClass = warningLevel === 'high' ? 'danger' : warningLevel === 'medium' ? 'warning' : 'info';
            
            confirmationContent += `
                <div class="duplicate-device-item border-${warningClass} mb-3 p-3">
                    <div class="device-headers">
                        <strong>${device.device || device.hostname}</strong>
                        <span class="badge bg-${warningClass}">${warningLevel.toUpperCase()} RISK</span>
                    </div>
                    <div class="device-details mt-2">
                        <p class="mb-1">${duplicateInfo.message || device.message}</p>
                        
                        ${duplicateInfo.existing_device_name ? `
                            <div class="existing-device-info">
                                <small class="text-muted">
                                    <i class="fas fa-server"></i> Existing device: <strong>${duplicateInfo.existing_device_name}</strong>
                                </small>
                            </div>
                        ` : ''}
                        
                        ${duplicateInfo.previous_sync_job_id || duplicateInfo.previous_network_job_id ? `
                            <div class="previous-jobs-info">
                                <small class="text-muted">
                                    <i class="fas fa-history"></i> Previous jobs: 
                                    ${duplicateInfo.previous_sync_job_id ? `<a href="/extras/job-results/${duplicateInfo.previous_sync_job_id}/" target="_blank" class="job-link">Sync: ${duplicateInfo.previous_sync_job_id.substring(0, 8)}...</a>` : ''}
                                    ${duplicateInfo.previous_sync_job_id && duplicateInfo.previous_network_job_id ? ' | ' : ''}
                                    ${duplicateInfo.previous_network_job_id ? `<a href="/extras/job-results/${duplicateInfo.previous_network_job_id}/" target="_blank" class="job-link">Network: ${duplicateInfo.previous_network_job_id.substring(0, 8)}...</a>` : ''}
                                </small>
                            </div>
                        ` : ''}
                    </div>
                </div>
            `;
        });
        
        confirmationContent += `
                </div>
                
                <div class="alert alert-info mt-3">
                    <h6><i class="fas fa-info-circle"></i> What happens if you proceed?</h6>
                    <ul class="mb-0">
                        <li>Previous job IDs will be reset for duplicate devices</li>
                        <li>New onboarding jobs will be created for all selected devices</li>
                        ${cleanDevices > 0 ? `<li>${cleanDevices} clean device${cleanDevices !== 1 ? 's' : ''} will proceed normally</li>` : ''}
                        <li>This may create duplicate data in Nautobot for existing devices</li>
                        <li>Existing device configurations may be overwritten</li>
                    </ul>
                </div>
            </div>
        `;
        
        // Show confirmation dialog
        window.commonPopup.show({
            title: `<i class="fas fa-exclamation-triangle text-warning me-2"></i>Confirm ${isBulk ? 'Bulk ' : ''}Re-onboarding`,
            content: confirmationContent,
            confirmText: `Proceed with ${isBulk ? 'Bulk ' : ''}Re-onboarding`,
            cancelText: 'Cancel',
            confirmClass: 'btn-warning',
            size: 'xl',
            showCancel: true,
            onConfirm: () => {
                this.confirmDuplicateOnboarding(duplicateDevices, data, operationType);
            },
            onCancel: () => {
                this.updateStatus(`${isBulk ? 'Bulk o' : 'O'}nboarding cancelled by user`, 'warning');
            }
        });
    }
    
    /**
     * Confirm and proceed with duplicate device onboarding
     */
    async confirmDuplicateOnboarding(duplicateDevices, originalData, operationType = 'single') {
        try {
            const isBulk = operationType === 'bulk';
            this.updateStatus(`Processing ${isBulk ? 'bulk ' : ''}re-onboarding confirmation...`, 'loading', true);
            
            const deviceIps = duplicateDevices.map(device => device.device || device.hostname);
            
            const response = await fetch(`/plugins/inventory/api/confirm-duplicate-onboarding/${this.currentSessionId}/`, {
                method: 'POST',
                body: JSON.stringify({
                    device_ips: deviceIps,
                    operation_type: operationType,
                    original_data: originalData
                }),
                credentials: 'same-origin',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRFToken': this.getCsrfToken()
                }
            });
            
            const data = await response.json();
            
            if (data.status === 'success') {
                if (isBulk) {
                    // Handle bulk onboarding response
                    this.updateStatus(`Bulk re-onboarding started for ${data.device_count || data.onboarding_count} devices`, 'success');
                    
                    if (data.batches) {
                        // Start monitoring bulk job progress
                        this.startBulkOnboardingJobMonitoring(data.batches);
                        
                        // Show bulk onboarding progress UI
                        this.showBulkOnboardingProgress(data);
                    }
                } else {
                    // Handle single device onboarding response
                    this.updateStatus(`Re-onboarding started for ${data.onboarding_count} devices`, 'success');
                    
                    // Show onboarding cards for the confirmed devices
                    if (data.onboarding_jobs && data.onboarding_jobs.length > 0) {
                        this.startOnboardingJobMonitoring();
                        this.showOnboardingCards(data.onboarding_jobs, data.failed_jobs || []);
                    }
                }
                
                // Show success message with details
                let message = `${isBulk ? 'Bulk r' : 'R'}e-onboarding confirmed and started for ${data.device_count || data.onboarding_count} devices.`;
                
                if (data.failed_jobs && data.failed_jobs.length > 0) {
                    message += `\n\n${data.failed_jobs.length} devices failed to start:`;
                    data.failed_jobs.forEach(failure => {
                        message += `\n• ${failure.device}: ${failure.error}`;
                    });
                }
                
                if (data.failed_devices && data.failed_devices.length > 0) {
                    message += `\n\n${data.failed_devices.length} devices failed to start:`;
                    data.failed_devices.forEach(failure => {
                        message += `\n• ${failure.device}: ${failure.error}`;
                    });
                }
                
                window.commonPopup.alert(
                    `${isBulk ? 'Bulk ' : ''}Re-onboarding Started`, 
                    message, 
                    (data.failed_jobs && data.failed_jobs.length > 0) || (data.failed_devices && data.failed_devices.length > 0) ? 'warning' : 'success'
                );
                
            } else {
                this.updateStatus(`${isBulk ? 'Bulk r' : 'R'}e-onboarding failed: ${data.message}`, 'error');
                
                if (data.error_details) {
                    window.commonPopup.showDetailedError(`${isBulk ? 'Bulk ' : ''}Re-onboarding Failed`, data);
                } else {
                    window.commonPopup.alert(`${isBulk ? 'Bulk ' : ''}Re-onboarding Failed`, data.message, 'error');
                }
            }
            
        } catch (error) {
            this.updateStatus(`${isBulk ? 'Bulk r' : 'R'}e-onboarding confirmation failed`, 'error');
            console.error('Re-onboarding confirmation error:', error);
            window.commonPopup.alert('Error', 'An error occurred while confirming re-onboarding.', 'error');
        }
    }

    /**
     * Get bulk onboarding summary
     */
    getBulkOnboardingSummary(bulkStatus) {
        const summary = {
            totalBatches: bulkStatus.length,
            totalDevices: 0,
            completedBatches: 0,
            failedBatches: 0,
            runningBatches: 0,
            pendingBatches: 0
        };

        bulkStatus.forEach(batch => {
            summary.totalDevices += (batch.device_ips || batch.devices || []).length;
            
            switch (batch.status) {
                case 'completed':
                    summary.completedBatches++;
                    break;
                case 'failed':
                    summary.failedBatches++;
                    break;
                case 'running':
                    summary.runningBatches++;
                    break;
                default:
                    summary.pendingBatches++;
            }
        });

        return summary;
    }
}

// Initialize the discovery interface when DOM is loaded
/**
 * Initialize NetworkDiscovery with configuration
 * This function can be called from HTML with custom config
 */
function initNetworkDiscovery(config = {}) {
    if (typeof NetworkDiscovery !== 'undefined') {
        window.networkDiscovery = new NetworkDiscovery(config);
        return window.networkDiscovery;
    } else {
        console.error('NetworkDiscovery class not found.');
        // Show error message to user
        const statusElement = document.getElementById('discoveryStatus');
        if (statusElement) {
            statusElement.innerHTML = '<i class="fas fa-exclamation-triangle"></i> Error loading discovery interface';
            statusElement.className = 'status error';
        }
        return null;
    }
}

// Auto-initialize with default config when DOM is ready (fallback)
// NOTE: Removed fallback initialization to prevent duplicate instances
// The main initialization happens in the HTML template with proper configuration

/**
 * UnreachableDevicesManager - Manages unreachable devices and credential assignment
 */
class UnreachableDevicesManager {
    constructor(networkDiscovery) {
        this.networkDiscovery = networkDiscovery;
        this.modal = document.getElementById('unreachableDevicesModal');
        this.unreachableDevices = [];
        this.selectedDevices = new Set();
        this.init();
    }

    init() {
        this.bindEventListeners();
    }

    bindEventListeners() {
        // Select all unreachable devices
        const selectAllUnreachable = document.getElementById('selectAllUnreachable');
        if (selectAllUnreachable) {
            selectAllUnreachable.addEventListener('change', (e) => this.handleSelectAllUnreachable(e));
        }

        // Bulk actions
        const bulkAssignCredsBtn = document.getElementById('bulkAssignCredsBtn');
        if (bulkAssignCredsBtn) {
            bulkAssignCredsBtn.addEventListener('click', () => this.handleBulkAssignCredentials());
        }

        const bulkRetryBtn = document.getElementById('bulkRetryBtn');
        if (bulkRetryBtn) {
            bulkRetryBtn.addEventListener('click', () => this.handleBulkRetry());
        }

        const refreshUnreachableBtn = document.getElementById('refreshUnreachableBtn');
        if (refreshUnreachableBtn) {
            refreshUnreachableBtn.addEventListener('click', () => this.refresh());
        }

        // Modal close events
        window.addEventListener('click', (e) => {
            if (e.target === this.modal) {
                this.close();
            }
        });
    }

    show() {
        this.isVisible = true;
        this.loadUnreachableDevices();
        this.modal.style.display = 'flex';
        document.body.style.overflow = 'hidden';
    }

    close() {
        this.isVisible = false;
        this.modal.style.display = 'none';
        document.body.style.overflow = 'auto';
        this.selectedDevices.clear();
    }

    loadUnreachableDevices() {
        // Filter unreachable devices from discovered devices
        this.unreachableDevices = this.networkDiscovery.discoveredDevices.filter(d => 
            window.DeviceStatusConstants.isDeviceFailed(d)
        );

        this.updateSummaryCards();
        this.displayUnreachableDevices();
    }

    updateSummaryCards() {
        const totalUnreachable = this.unreachableDevices.length;
        
        // Count authentication failures using improved error detection
        const authFailures = this.unreachableDevices.filter(d => {
            // Check device_data first
            if (d.device_data) {
                if (d.device_data.error_type === 'authentication_failed') return true;
                if (d.device_data.error_category && d.device_data.error_category.toLowerCase().includes('authentication')) return true;
                if (d.device_data.error && d.device_data.error.toLowerCase().includes('authentication')) return true;
            }
            // Fallback to hostname
            if (d.hostname && (d.hostname.includes('auth') || d.hostname.includes('auth-failed'))) return true;
            // Check connection status
            if (d.connection_status === 'auth_failed') return true;
            return false;
        }).length;
        
        // Count timeouts using improved error detection
        const timeouts = this.unreachableDevices.filter(d => {
            // Check device_data first
            if (d.device_data) {
                if (d.device_data.error_type === 'connection_timeout') return true;
                if (d.device_data.error_category && d.device_data.error_category.toLowerCase().includes('timeout')) return true;
                if (d.device_data.error && d.device_data.error.toLowerCase().includes('timeout')) return true;
            }
            // Fallback to hostname
            if (d.hostname && d.hostname.includes('timeout')) return true;
            // Check connection status
            if (d.connection_status === 'timeout') return true;
            return false;
        }).length;
        
        document.getElementById('totalUnreachableCount').textContent = totalUnreachable;
        document.getElementById('authFailuresCount').textContent = authFailures;
        document.getElementById('timeoutsCount').textContent = timeouts;
    }

    displayUnreachableDevices() {
        const tableBody = document.getElementById('unreachableDevicesTableBody');
        if (!tableBody) return;

        tableBody.innerHTML = '';

        this.unreachableDevices.forEach((device, index) => {
            const row = document.createElement('div');
            row.className = 'table-row';
            row.setAttribute('data-device-ip', device.ip_address);

            const lastError = this.getLastError(device);
            
            // Get full error details for tooltip
            const fullErrorDetails = this.getFullErrorDetails(device);

            row.innerHTML = `
                <div>
                    <input type="checkbox" class="unreachable-device-checkbox" 
                           value="${device.ip_address}" data-index="${index}" 
                           onchange="unreachableDevicesManager.updateSelection()" />
                </div>
                <div>${device.ip_address}</div>
                <div>${device.hostname || 'Unknown'}</div>
                <div class="error-cell" title="${fullErrorDetails}">${lastError}</div>
            `;

            tableBody.appendChild(row);
        });

        this.updateSelection();
    }
    
    getFullErrorDetails(device) {
        // Get comprehensive error details for tooltip
        let details = [];
        
        if (device.device_data) {
            if (device.device_data.error_category) {
                details.push(`Category: ${device.device_data.error_category}`);
            }
            if (device.device_data.error_type) {
                details.push(`Type: ${device.device_data.error_type}`);
            }
            if (device.device_data.error) {
                details.push(`Error: ${device.device_data.error}`);
            }
            if (device.device_data.failure_reason) {
                details.push(`Reason: ${device.device_data.failure_reason}`);
            }
        }
        
        if (device.connection_status) {
            details.push(`Status: ${device.connection_status}`);
        }
        
        return details.length > 0 ? details.join('\n') : 'No detailed error information available';
    }

    getLastError(device) {
        // First, check if we have detailed error information in device_data
        if (device.device_data) {
            // Check for error_category (most descriptive)
            if (device.device_data.error_category) {
                return device.device_data.error_category;
            }
            
            // Check for error_type
            if (device.device_data.error_type) {
                // Convert error_type to human-readable format
                const errorTypeMap = {
                    'authentication_failed': 'Authentication Failed',
                    'connection_timeout': 'Connection Timeout',
                    'unreachable': 'Network Unreachable',
                    'worker_exception': 'Discovery Worker Error',
                    'connection_failed': 'Connection Failed'
                };
                const humanReadableError = errorTypeMap[device.device_data.error_type] || device.device_data.error_type;
                return humanReadableError;
            }
            
            // Check for raw error message
            if (device.device_data.error) {
                const errorMsg = device.device_data.error;
                
                // Parse common error patterns from the error message
                if (errorMsg.toLowerCase().includes('authentication') || errorMsg.toLowerCase().includes('auth')) {
                    return 'Authentication Failed';
                } else if (errorMsg.toLowerCase().includes('timeout')) {
                    return 'Connection Timeout';
                } else if (errorMsg.toLowerCase().includes('unreachable')) {
                    return 'Network Unreachable';
                } else if (errorMsg.toLowerCase().includes('refused') || errorMsg.toLowerCase().includes('connection refused')) {
                    return 'Connection Refused';
                } else if (errorMsg.toLowerCase().includes('worker exception')) {
                    return 'Discovery Worker Error';
                } else {
                    // Return truncated error message for display (first 50 chars)
                    return errorMsg.length > 50 ? errorMsg.substring(0, 47) + '...' : errorMsg;
                }
            }
            
            // Check for failure_reason
            if (device.device_data.failure_reason) {
                const failureReason = device.device_data.failure_reason;
                // Extract just the error type part if it's in "error_type: message" format
                const colonIndex = failureReason.indexOf(':');
                if (colonIndex > 0) {
                    const errorType = failureReason.substring(0, colonIndex).trim();
                    const errorTypeMap = {
                        'authentication_failed': 'Authentication Failed',
                        'connection_timeout': 'Connection Timeout',
                        'unreachable': 'Network Unreachable',
                        'worker_exception': 'Discovery Worker Error',
                        'connection_failed': 'Connection Failed'
                    };
                    return errorTypeMap[errorType] || failureReason;
                }
                return failureReason.length > 50 ? failureReason.substring(0, 47) + '...' : failureReason;
            }
        }
        
        // Fallback to checking connection_status
        if (device.connection_status) {
            const statusMap = {
                'failed': 'Connection Failed',
                'timeout': 'Connection Timeout',
                'unreachable': 'Network Unreachable',
                'cancelled': 'Discovery Cancelled',
                'auth_failed': 'Authentication Failed'
            };
            if (statusMap[device.connection_status]) {
                return statusMap[device.connection_status];
            }
        }
        
        // Fallback to hostname parsing (legacy support)
        if (device.hostname) {
            if (device.hostname.includes('auth-failed') || device.hostname.includes('auth_failed')) {
                return 'Authentication Failed';
            } else if (device.hostname.includes('timeout')) {
                return 'Connection Timeout';
            } else if (device.hostname.includes('unreachable')) {
                return 'Network Unreachable';
            } else if (device.hostname.includes('worker-failed')) {
                return 'Discovery Worker Error';
            } else if (device.hostname.includes('failed') || device.hostname.includes('error')) {
                return 'Connection Failed';
            }
        }
        
        // Final fallback
        return device.last_error || 'Unknown Error';
    }

    handleSelectAllUnreachable(e) {
        const checkboxes = document.querySelectorAll('.unreachable-device-checkbox');
        checkboxes.forEach(cb => {
            cb.checked = e.target.checked;
            if (e.target.checked) {
                this.selectedDevices.add(cb.value);
            } else {
                this.selectedDevices.delete(cb.value);
            }
        });
        this.updateSelection();
    }

    updateSelection() {
        const checkboxes = document.querySelectorAll('.unreachable-device-checkbox');
        const selectedCount = Array.from(checkboxes).filter(cb => cb.checked).length;
        const totalCount = checkboxes.length;

        // Update selected devices set
        this.selectedDevices.clear();
        checkboxes.forEach(cb => {
            if (cb.checked) {
                this.selectedDevices.add(cb.value);
            }
        });

        // Update UI elements
        document.getElementById('selectedUnreachableCount').textContent = selectedCount;

        const bulkAssignBtn = document.getElementById('bulkAssignCredsBtn');
        const bulkRetryBtn = document.getElementById('bulkRetryBtn');
        
        if (bulkAssignBtn) bulkAssignBtn.disabled = selectedCount === 0;
        if (bulkRetryBtn) bulkRetryBtn.disabled = selectedCount === 0;

        // Update select all checkbox
        const selectAll = document.getElementById('selectAllUnreachable');
        if (selectAll) {
            selectAll.indeterminate = selectedCount > 0 && selectedCount < totalCount;
            selectAll.checked = selectedCount === totalCount && totalCount > 0;
        }
    }

    assignCredentials(deviceIp) {
        // Open device detail modal with credentials tab active
        const device = this.networkDiscovery.discoveredDevices.find(d => d.ip_address === deviceIp);
        if (device) {
            this.close();
            this.networkDiscovery.showDeviceDetail(deviceIp);
            // Switch to credentials tab after a short delay
            setTimeout(() => {
                const credentialsTab = document.querySelector('[data-tab="credentials"]');
                if (credentialsTab) {
                    credentialsTab.click();
                }
            }, 100);
        }
    }

    retryDevice(deviceIp) {
        window.commonPopup.confirm(
            'Retry Device Discovery',
            `Retry discovery for device ${deviceIp}? This will attempt to reconnect using existing or custom credentials.`,
            () => {
                this.performRetryDevice(deviceIp);
            }
        );
    }

    async performRetryDevice(deviceIp) {
        try {
            const response = await fetch(`/plugins/inventory/api/retry-device/${this.networkDiscovery.currentSessionId}/${encodeURIComponent(deviceIp)}/`, {
                method: 'POST',
                credentials: 'same-origin',
                headers: {
                    'X-CSRFToken': this.networkDiscovery.getCsrfToken(),
                    'Content-Type': 'application/json',
                }
            });

            const data = await response.json();
            
            if (data.status === 'success') {
                window.commonPopup.alert('Retry Started', `Retry discovery started for ${deviceIp}. The device status will be updated automatically.`, 'success');
                this.refresh();
            } else {
                window.commonPopup.alert('Retry Failed', `Failed to retry device ${deviceIp}: ${data.message}`, 'error');
            }
        } catch (error) {
            console.error('Error retrying device:', error);
            window.commonPopup.alert('Error', 'An error occurred while retrying the device.', 'error');
        }
    }

    handleBulkAssignCredentials() {
        if (this.selectedDevices.size === 0) {
            window.commonPopup.alert('No Devices Selected', 'Please select devices to assign credentials to.', 'warning');
            return;
        }

        if (!window.bulkCredentialsManager) {
            window.bulkCredentialsManager = new BulkCredentialsManager(this.networkDiscovery);
        }
        
        // Pass selected unreachable devices to bulk credentials manager
        const selectedDevicesList = Array.from(this.selectedDevices);
        window.bulkCredentialsManager.show(selectedDevicesList);
        this.close();
    }

    handleBulkRetry() {
        if (this.selectedDevices.size === 0) {
            window.commonPopup.alert('No Devices Selected', 'Please select devices to retry.', 'warning');
            return;
        }

        const deviceCount = this.selectedDevices.size;
        window.commonPopup.confirm(
            'Bulk Retry Discovery',
            `Retry discovery for ${deviceCount} selected device${deviceCount !== 1 ? 's' : ''}? This will attempt to reconnect using existing or custom credentials.`,
            () => {
                this.performBulkRetry();
            }
        );
    }

    async performBulkRetry() {
        const selectedDevicesList = Array.from(this.selectedDevices);
        
        try {
            const response = await fetch(`/plugins/inventory/api/bulk-retry-devices/${this.networkDiscovery.currentSessionId}/`, {
                method: 'POST',
                credentials: 'same-origin',
                headers: {
                    'X-CSRFToken': this.networkDiscovery.getCsrfToken(),
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    device_ips: selectedDevicesList
                })
            });

            const data = await response.json();
            
            if (data.status === 'success') {
                window.commonPopup.alert('Bulk Retry Started', `Retry discovery started for ${data.retry_count} devices. Device statuses will be updated automatically.`, 'success');
                this.refresh();
            } else {
                window.commonPopup.alert('Bulk Retry Failed', `Failed to retry devices: ${data.message}`, 'error');
            }
        } catch (error) {
            console.error('Error performing bulk retry:', error);
            window.commonPopup.alert('Error', 'An error occurred while retrying devices.', 'error');
        }
    }

    refresh() {
        this.loadUnreachableDevices();
    }
}

/**
 * BulkCredentialsManager - Manages bulk credential assignment
 */
class BulkCredentialsManager {
    constructor(networkDiscovery) {
        this.networkDiscovery = networkDiscovery;
        this.modal = document.getElementById('bulkCredentialsModal');
        this.targetDevices = [];
        this.init();
    }

    init() {
        this.bindEventListeners();
    }

    bindEventListeners() {
        // Template buttons
        const templateButtons = document.querySelectorAll('.template-btn[data-template]');
        templateButtons.forEach(btn => {
            btn.addEventListener('click', (e) => this.applyTemplate(e.target.dataset.template));
        });

        // Apply credentials button
        const applyBtn = document.getElementById('applyBulkCredentialsBtn');
        if (applyBtn) {
            applyBtn.addEventListener('click', () => this.applyBulkCredentials());
        }

        // Modal close events
        window.addEventListener('click', (e) => {
            if (e.target === this.modal) {
                this.close();
            }
        });
    }

    show(deviceList = null) {
        // If deviceList is provided, use it (from unreachable devices)
        // Otherwise, get selected devices from main discovery interface
        if (deviceList) {
            this.targetDevices = deviceList;
        } else {
            const checkboxes = document.querySelectorAll('.device-checkbox:not(#selectAll):checked');
            this.targetDevices = Array.from(checkboxes).map(cb => cb.value);
        }

        if (this.targetDevices.length === 0) {
            window.commonPopup.alert('No Devices Selected', 'Please select devices to assign credentials to.', 'warning');
            return;
        }

        // Update device count in modal
        document.getElementById('bulkDeviceCount').textContent = this.targetDevices.length;

        this.modal.style.display = 'flex';
        document.body.style.overflow = 'hidden';
    }

    close() {
        this.modal.style.display = 'none';
        document.body.style.overflow = 'auto';
        this.clearForm();
    }

    applyTemplate(template) {
        const templates = {
            cisco_ios: {
                deviceType: 'cisco_ios',
                protocol: 'ssh',
                port: 22
            },
            cisco_nxos: {
                deviceType: 'cisco_nxos',
                protocol: 'ssh',
                port: 22
            },
            arista_eos: {
                deviceType: 'arista_eos',
                protocol: 'ssh',
                port: 22
            },
            juniper: {
                deviceType: 'juniper',
                protocol: 'ssh',
                port: 22
            }
        };

        const templateData = templates[template];
        if (templateData) {
            document.getElementById('bulk-cred-device-type').value = templateData.deviceType;
            document.getElementById('bulk-cred-protocol').value = templateData.protocol;
            document.getElementById('bulk-cred-port').value = templateData.port;
        }
    }

    async applyBulkCredentials() {
        const formData = this.getFormData();
        
        if (!formData.username || !formData.password) {
            window.commonPopup.alert('Missing Required Fields', 'Please provide both username and password.', 'warning');
            return;
        }

        try {
            const response = await fetch(`/plugins/inventory/api/bulk-assign-credentials/${this.networkDiscovery.currentSessionId}/`, {
                method: 'POST',
                credentials: 'same-origin',
                headers: {
                    'X-CSRFToken': this.networkDiscovery.getCsrfToken(),
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    device_ips: this.targetDevices,
                    credentials: formData
                })
            });

            const data = await response.json();
            
            if (data.status === 'success') {
                window.commonPopup.alert('Credentials Applied', `Credentials successfully assigned to ${data.updated_count} devices.`, 'success');
                this.close();
                
                // Refresh unreachable devices if manager is open
                if (window.unreachableDevicesManager) {
                    window.unreachableDevicesManager.refresh();
                }
            } else {
                window.commonPopup.alert('Assignment Failed', `Failed to assign credentials: ${data.message}`, 'error');
            }
        } catch (error) {
            console.error('Error applying bulk credentials:', error);
            window.commonPopup.alert('Error', 'An error occurred while assigning credentials.', 'error');
        }
    }

    getFormData() {
        return {
            username: document.getElementById('bulk-cred-username').value,
            password: document.getElementById('bulk-cred-password').value,
            enable_password: document.getElementById('bulk-cred-enable-password').value,
            device_type: document.getElementById('bulk-cred-device-type').value,
            protocol: document.getElementById('bulk-cred-protocol').value,
            port: parseInt(document.getElementById('bulk-cred-port').value) || 22
        };
    }

    clearForm() {
        document.getElementById('bulk-cred-username').value = '';
        document.getElementById('bulk-cred-password').value = '';
        document.getElementById('bulk-cred-enable-password').value = '';
        document.getElementById('bulk-cred-device-type').value = 'cisco_ios';
        document.getElementById('bulk-cred-protocol').value = 'ssh';
        document.getElementById('bulk-cred-port').value = '22';
    }
}

/**
 * Global Settings Manager
 * Handles global onboarding settings configuration
 */
class GlobalSettingsManager {
    constructor() {
        this.modal = document.getElementById('globalSettingsModal');
        this.form = document.getElementById('globalSettingsForm');
        this.settings = this.getDefaultSettings();
        this.nautobotData = null;
        
        console.log('GlobalSettingsManager initialized');
        console.log('Modal element found:', !!this.modal);
        console.log('Form element found:', !!this.form);
        
        this.initEventHandlers();
        this.loadNautobotData();
        this.loadSettings();
    }

    initEventHandlers() {
        // Settings button (top form)
        const settingsBtn = document.getElementById('globalSettingsBtn');
        if (settingsBtn) {
            settingsBtn.addEventListener('click', () => {
                console.log('Global settings button clicked');
                this.show();
            });
        } else {
            console.error('Global settings button not found');
        }

        // Settings button (bottom bar)
        const settingsBottomBtn = document.getElementById('globalSettingsBottomBtn');
        if (settingsBottomBtn) {
            settingsBottomBtn.addEventListener('click', () => {
                console.log('Global settings bottom button clicked');
                this.show();
            });
        } else {
            console.error('Global settings bottom button not found');
        }

        // Close modal when clicking outside
        if (this.modal) {
            this.modal.addEventListener('click', (e) => {
                if (e.target === this.modal) {
                    this.close();
                }
            });

            // Close modal on Escape key
            document.addEventListener('keydown', (e) => {
                if (e.key === 'Escape' && this.modal.style.display === 'flex') {
                    this.close();
                }
            });
        }
    }

    getDefaultSettings() {
        return {
            port: 22,
            timeout: 60,
            namespace: '',
            device_role: '',
            device_status: '',
            interface_status: '',
            ip_status: '',
            set_mgmt_only: false,
            update_devices_without_primary_ip: true,
            sync_vlans: true,
            sync_vrfs: true,
            sync_cables: true
        };
    }

    show() {
        if (!this.modal) {
            console.error('Global settings modal element not found');
            return;
        }
        
        this.populateDropdowns();
        this.populateForm();
        this.modal.style.display = 'flex';
        document.body.style.overflow = 'hidden';
    }

    loadNautobotData() {
        // Get data from template context
        const nautobotDataElement = document.getElementById('nautobot-data');
        if (nautobotDataElement) {
            try {
                this.nautobotData = JSON.parse(nautobotDataElement.textContent);
            } catch (error) {
                console.error('Error parsing Nautobot data from template:', error);
                this.nautobotData = {};
            }
        }
    }

    populateDropdowns() {
        if (!this.nautobotData) return;

        // Populate namespaces
        const namespaceSelect = document.getElementById('global-namespace');
        if (namespaceSelect && this.nautobotData.namespaces) {
            namespaceSelect.innerHTML = '<option value="">Select namespace...</option>';
            this.nautobotData.namespaces.forEach(ns => {
                const option = document.createElement('option');
                option.value = ns.id;
                option.textContent = ns.display || ns.name;
                namespaceSelect.appendChild(option);
            });
        }

        // Populate device roles
        const deviceRoleSelect = document.getElementById('global-device-role');
        if (deviceRoleSelect && this.nautobotData.device_roles) {
            deviceRoleSelect.innerHTML = '<option value="">Select device role...</option>';
            this.nautobotData.device_roles.forEach(role => {
                const option = document.createElement('option');
                option.value = role.id;
                option.textContent = role.display || role.name;
                deviceRoleSelect.appendChild(option);
            });
        }

        // Populate device statuses
        const deviceStatusSelect = document.getElementById('global-device-status');
        if (deviceStatusSelect && this.nautobotData.device_statuses) {
            deviceStatusSelect.innerHTML = '<option value="">Select device status...</option>';
            this.nautobotData.device_statuses.forEach(status => {
                const option = document.createElement('option');
                option.value = status.id;
                option.textContent = status.display || status.name;
                if (status.name === 'Active') {
                    option.selected = true;
                }
                deviceStatusSelect.appendChild(option);
            });
        }

        // Populate interface statuses
        const interfaceStatusSelect = document.getElementById('global-interface-status');
        if (interfaceStatusSelect && this.nautobotData.interface_statuses) {
            interfaceStatusSelect.innerHTML = '<option value="">Select interface status...</option>';
            this.nautobotData.interface_statuses.forEach(status => {
                const option = document.createElement('option');
                option.value = status.id;
                option.textContent = status.display || status.name;
                if (status.name === 'Active') {
                    option.selected = true;
                }
                interfaceStatusSelect.appendChild(option);
            });
        }

        // Populate IP address statuses
        const ipStatusSelect = document.getElementById('global-ip-status');
        if (ipStatusSelect && this.nautobotData.ip_address_statuses) {
            ipStatusSelect.innerHTML = '<option value="">Select IP address status...</option>';
            this.nautobotData.ip_address_statuses.forEach(status => {
                const option = document.createElement('option');
                option.value = status.id;
                option.textContent = status.display || status.name;
                if (status.name === 'Active') {
                    option.selected = true;
                }
                ipStatusSelect.appendChild(option);
            });
        }
    }

    close() {
        if (this.modal) {
            this.modal.style.display = 'none';
            document.body.style.overflow = 'auto';
        }
    }

    populateForm() {
        // Populate form fields with current settings
        Object.keys(this.settings).forEach(key => {
            const element = document.getElementById(`global-${key.replace(/_/g, '-')}`);
            if (element) {
                if (element.type === 'checkbox') {
                    element.checked = this.settings[key];
                } else {
                    element.value = this.settings[key] || '';
                }
            }
        });
    }

    collectFormData() {
        const formData = {};
        
        // Collect all form values
        Object.keys(this.settings).forEach(key => {
            const element = document.getElementById(`global-${key.replace(/_/g, '-')}`);
            if (element) {
                if (element.type === 'checkbox') {
                    formData[key] = element.checked;
                } else if (element.type === 'number') {
                    formData[key] = parseInt(element.value) || this.settings[key];
                } else {
                    formData[key] = element.value || '';
                }
            }
        });

        return formData;
    }

    saveSettings() {
        const formData = this.collectFormData();
        
        // Validate required fields
        const requiredFields = ['namespace', 'device_status', 'interface_status', 'ip_status'];
        const missingFields = requiredFields.filter(field => !formData[field]);
        
        if (missingFields.length > 0) {
            window.commonPopup.alert(
                'Validation Error', 
                `Please fill in all required fields: ${missingFields.join(', ')}`, 
                'warning'
            );
            return;
        }

        // Save settings
        this.settings = { ...formData };
        this.storeSettings();
        
        window.commonPopup.alert(
            'Settings Saved', 
            'Global onboarding settings have been saved successfully.', 
            'success'
        );
        
        this.close();
    }

    resetDefaults() {
        this.settings = this.getDefaultSettings();
        this.populateForm();
        
        window.commonPopup.alert(
            'Settings Reset', 
            'Settings have been reset to default values.', 
            'info'
        );
    }

    loadSettings() {
        // Load settings from localStorage
        const stored = localStorage.getItem('nautobot_global_onboarding_settings');
        if (stored) {
            try {
                this.settings = { ...this.getDefaultSettings(), ...JSON.parse(stored) };
            } catch (error) {
                console.warn('Failed to load stored settings:', error);
                this.settings = this.getDefaultSettings();
            }
        }
    }

    storeSettings() {
        // Store settings in localStorage
        try {
            localStorage.setItem('nautobot_global_onboarding_settings', JSON.stringify(this.settings));
        } catch (error) {
            console.warn('Failed to store settings:', error);
        }
    }

    getSettings() {
        return { ...this.settings };
    }

    getJobData(device, sessionInfo) {
        // Build job data using global settings
        const settings = this.getSettings();
        
        return {
            dryrun: false,
            memory_profiling: false,
            debug: false,
            csv_file: null,
            location: sessionInfo.location_id,
            namespace: settings.namespace,
            ip_addresses: device.ip_address,
            set_mgmt_only: settings.set_mgmt_only,
            update_devices_without_primary_ip: settings.update_devices_without_primary_ip,
            device_role: settings.device_role || null,
            device_status: settings.device_status,
            interface_status: settings.interface_status,
            ip_address_status: settings.ip_status,
            port: settings.port,
            timeout: settings.timeout,
            secrets_group: sessionInfo.secrets_group_id,
            platform: device.platform_id
        };
    }

    getNetworkDataJobData(device, sessionInfo) {
        // Build network data job data using global settings
        const settings = this.getSettings();
        
        return {
            dryrun: false,
            memory_profiling: false,
            debug: false,
            devices: [], // Will be populated with Device UUID when triggered
            secrets_group: sessionInfo.secrets_group_id,
            location: sessionInfo.location_id,
            namespace: settings.namespace,
            interface_status: settings.interface_status,
            ip_address_status: settings.ip_status,
            default_prefix_status: settings.ip_status,
            device_role: settings.device_role || null,
            platform: device.platform_id,
            sync_vlans: settings.sync_vlans,
            sync_vrfs: settings.sync_vrfs,
            sync_cables: settings.sync_cables
        };
    }
}

// Export for global access
window.NetworkDiscovery = NetworkDiscovery;
window.initNetworkDiscovery = initNetworkDiscovery;
window.UnreachableDevicesManager = UnreachableDevicesManager;
window.BulkCredentialsManager = BulkCredentialsManager;
window.GlobalSettingsManager = GlobalSettingsManager;
