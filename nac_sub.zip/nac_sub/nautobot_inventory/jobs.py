import re
import socket
import time
import threading
import logging
import os
import queue
import asyncio
from concurrent.futures import ThreadPoolExecutor, as_completed, Future
from datetime import datetime, timedelta
from typing import Dict, List, Set, Tuple, Optional
from collections import defaultdict, deque
from dataclasses import dataclass
from enum import Enum
import weakref

from django.conf import settings
from django.utils import timezone
from django.db import transaction
from nautobot.apps.jobs import Job
from nautobot.extras.jobs import BooleanVar
from nautobot.extras.models import SecretsGroup
from nautobot.extras.choices import SecretsGroupAccessTypeChoices, SecretsGroupSecretTypeChoices
from .utils.logging_utils import DiscoveryLogger, CommandLogger, get_discovery_logger, setup_netmiko_logging, cleanup_netmiko_logging
from .utils.interface_parser import InterfaceParser, NeighborParser
from nautobot.extras.secrets.exceptions import SecretError
from django.core.exceptions import ObjectDoesNotExist
from netmiko import ConnectHandler, NetmikoTimeoutException, NetmikoAuthenticationException

from .models import InventoryDiscoverySession, DiscoveredDevice
from .utils import stack_utils

# Import Platform model for platform handling
try:
    from nautobot.dcim.models import Platform
except ImportError:
    Platform = None


def get_or_create_platform(detected_platform):
    """
    Get or create a Platform object based on detected platform string.
    
    Args:
        detected_platform (str): The platform string detected from device
        
    Returns:
        Platform: Platform object or None if not found/created
    """
    if not Platform or not detected_platform:
        return None
        
    try:
        # Enhanced platform mapping with multiple fallback options
        platform_mapping = {
            'cisco': ['cisco_xe', 'Cisco IOS-XE', 'cisco_ios', 'Cisco Catalyst Lab'],
            'cisco_ios': ['cisco_xe', 'Cisco IOS-XE', 'cisco_ios', 'Cisco IOS', 'cisco_catalyst', 'Cisco Catalyst Lab'],
            'cisco_nxos': ['cisco_nxos', 'Cisco NX-OS'],
            'cisco_xe': ['cisco_xe', 'Cisco IOS-XE', 'cisco_ios', 'Cisco IOS'],
            'cisco_xr': ['cisco_xr', 'Cisco IOS-XR'],
            'cisco_asa': ['cisco_asa', 'Cisco ASA'],
            'aruba': ['aruba_aoscx', 'Aruba Lab'], 
            'juniper': ['juniper_junos', 'Juniper Junos'],
            'arista': ['arista_eos', 'pla-arista', 'Arista EOS'],
            'hp': ['hp_comware', 'HP Comware'],
            'fortinet': ['fortinet_fortios', 'FortiGate'],
            'paloalto': ['paloalto_panos', 'Palo Alto PAN-OS'],
            'f5': ['f5_tmsh', 'F5 BIG-IP'],
            'dell': ['dell_force10', 'Dell Networking'],
            'extreme': ['extreme_exos', 'Extreme Networks'],
            'huawei': ['huawei', 'Huawei VRP'],
            'mikrotik': ['mikrotik', 'MikroTik RouterOS'],
            'linux': ['linux', 'Linux'],
            'unknown': ['cisco_xe', 'cisco_nxos']  # Default fallback for unknown platforms - prefer cisco_xe
        }
        
        # Get list of possible platform names for this device type
        possible_platforms = platform_mapping.get(detected_platform.lower(), [detected_platform])
        
        # Try each possible platform name
        for platform_name in possible_platforms:
            platform_obj = Platform.objects.filter(name=platform_name).first()
            if platform_obj:
                # Check if platform has napalm_driver configured
                if platform_obj.napalm_driver:
                    print(f"✅ Found platform {platform_obj.name} with napalm_driver: {platform_obj.napalm_driver}")
                    return platform_obj
                else:
                    print(f"⚠️ Platform {platform_obj.name} has no napalm_driver configured, trying next option")
        
        # If no existing platform found, try to create one with basic configuration
        primary_platform_name = possible_platforms[0] if possible_platforms else detected_platform
        
        # Map platform to napalm driver
        napalm_driver_mapping = {
            'cisco_ios': 'ios',
            'cisco_nxos': 'nxos', 
            'cisco_xe': 'ios',
            'cisco_xr': 'iosxr',
            'cisco_asa': 'asa',
            'aruba_aoscx': 'aoscx',
            'juniper_junos': 'junos',
            'arista_eos': 'eos',
            'hp_comware': 'comware',
            'fortinet_fortios': 'fortios',
            'paloalto_panos': 'panos',
            'f5_tmsh': 'f5',
            'dell_force10': 'dellos10',
            'extreme_exos': 'exos',
            'huawei': 'huawei',
            'mikrotik': 'routeros',
            'linux': 'linux'
        }
        
        napalm_driver = napalm_driver_mapping.get(primary_platform_name.lower())
        if not napalm_driver:
            # Default to ios for unknown Cisco-like devices (cisco_xe uses ios driver)
            napalm_driver = 'ios' if 'cisco' in detected_platform.lower() else None
            
        if napalm_driver:
            platform_obj, created = Platform.objects.get_or_create(
                name=primary_platform_name,
                defaults={
                    'napalm_driver': napalm_driver,
                    'description': f'Auto-created platform for {detected_platform} devices'
                }
            )
            
            if created:
                print(f"✅ Created new platform: {platform_obj.name} with napalm_driver: {napalm_driver}")
            else:
                print(f"✅ Using existing platform: {platform_obj.name}")
                
            return platform_obj
            
    except Exception as e:
        print(f"❌ Error in get_or_create_platform for '{detected_platform}': {e}")
        
    return None


def detect_platform_from_output(version_output: str, is_aruba: bool = False, logger: Optional[logging.Logger] = None) -> str:
    """
    Robust platform detection from device output.
    
    This function uses a priority-based detection system where more specific patterns
    are checked before generic ones to avoid misidentification.
    
    Args:
        version_output (str): Output from 'show version' or similar command
        is_aruba (bool): Flag indicating if device is already identified as Aruba
        logger (logging.Logger): Optional logger for debug information
        
    Returns:
        str: Detected platform identifier (e.g., 'cisco_nxos', 'arista', 'juniper')
        
    Platform Detection Priority:
        1. Pre-identified platforms (is_aruba flag)
        2. Specific vendor OS variants (NX-OS, IOS-XE, IOS-XR before generic Cisco)
        3. Unique vendor signatures (Arista, Juniper, etc.)
        4. Generic patterns (last resort)
        5. Unknown if no match
    """
    if not version_output:
        if logger:
            logger.warning("Empty version output provided for platform detection")
        return 'unknown'
    
    version_lower = version_output.lower()
    
    # Log the first 200 chars for debugging
    if logger:
        logger.debug(f"Platform detection analyzing: {version_output[:200]}...")
    
    # Priority 1: Pre-identified platforms (highest confidence)
    if is_aruba:
        if logger:
            logger.info("Platform detected as 'aruba' (pre-identified)")
        return 'aruba'
    
    # Priority 2: Specific Cisco OS variants (check BEFORE generic Cisco patterns)
    # This prevents NX-OS devices from being misidentified as generic Cisco
    if any(pattern in version_lower for pattern in ['nx-os', 'nxos']) or \
       ('nexus' in version_lower and 'cisco' in version_lower):
        if logger:
            logger.info("Platform detected as 'cisco_nxos' (NX-OS pattern match)")
        return 'cisco_nxos'
    
    if any(pattern in version_lower for pattern in ['ios-xr', 'iosxr']) or \
       ('ios xr' in version_lower):
        if logger:
            logger.info("Platform detected as 'cisco_xr' (IOS-XR pattern match)")
        return 'cisco_xr'
    
    if any(pattern in version_lower for pattern in ['adaptive security appliance', 'cisco asa']) or \
       ('asa' in version_lower and 'cisco' in version_lower):
        if logger:
            logger.info("Platform detected as 'cisco_asa' (ASA pattern match)")
        return 'cisco_asa'
    
    # Combined Cisco IOS and IOS-XE detection - both return cisco_xe
    # This includes both traditional IOS and IOS-XE devices under cisco_xe platform
    if (any(pattern in version_lower for pattern in ['ios-xe', 'iosxe']) or 
        ('ios xe' in version_lower) or
        ('cisco ios' in version_lower) or 
        ('cisco' in version_lower and 'ios software' in version_lower) or
        ('cisco' in version_lower and any(ios_pattern in version_lower for ios_pattern in ['version 15.', 'version 12.', 'version 16.', 'version 17.']))):
        if logger:
            logger.info("Platform detected as 'cisco_xe' (Combined Cisco IOS/IOS-XE pattern match)")
        return 'cisco_xe'
    
    # Priority 3: Unique vendor signatures (high confidence, minimal collision risk)
    # Aruba/HP detection
    if any(pattern in version_lower for pattern in ['aruba', 'arubaos', 'aruba-os', 'hp procurve', 'hp provision']):
        if logger:
            logger.info("Platform detected as 'aruba' (Aruba/HP pattern match)")
        return 'aruba'
    
    # Juniper detection
    if any(pattern in version_lower for pattern in ['juniper', 'junos', 'jnpr']):
        if logger:
            logger.info("Platform detected as 'juniper' (Juniper pattern match)")
        return 'juniper'
    
    # Arista detection
    if any(pattern in version_lower for pattern in ['arista', 'arista networks', 'veos']) or \
       ('eos' in version_lower and any(x in version_lower for x in ['arista', 'veos'])):
        if logger:
            logger.info("Platform detected as 'arista' (Arista pattern match)")
        return 'arista'
    
    # Fortinet detection
    if any(pattern in version_lower for pattern in ['fortinet', 'fortigate', 'fortios']):
        if logger:
            logger.info("Platform detected as 'fortinet' (Fortinet pattern match)")
        return 'fortinet'
    
    # Palo Alto detection
    if any(pattern in version_lower for pattern in ['palo alto', 'palo alto networks', 'pan-os', 'panos']):
        if logger:
            logger.info("Platform detected as 'paloalto' (Palo Alto pattern match)")
        return 'paloalto'
    
    # F5 detection
    if any(pattern in version_lower for pattern in ['f5 networks', 'big-ip', 'bigip', 'tmos']):
        if logger:
            logger.info("Platform detected as 'f5' (F5 pattern match)")
        return 'f5'
    
    # Dell detection
    if any(pattern in version_lower for pattern in ['dell emc', 'dell networking', 'force10', 'dnos', 'dell os']):
        if logger:
            logger.info("Platform detected as 'dell' (Dell pattern match)")
        return 'dell'
    
    # Extreme Networks detection
    if any(pattern in version_lower for pattern in ['extreme networks', 'extremexos', 'exos']):
        if logger:
            logger.info("Platform detected as 'extreme' (Extreme Networks pattern match)")
        return 'extreme'
    
    # Huawei detection
    if any(pattern in version_lower for pattern in ['huawei', 'vrp platform', 'versatile routing platform']):
        if logger:
            logger.info("Platform detected as 'huawei' (Huawei pattern match)")
        return 'huawei'
    
    # MikroTik detection
    if any(pattern in version_lower for pattern in ['mikrotik', 'routeros', 'router os']):
        if logger:
            logger.info("Platform detected as 'mikrotik' (MikroTik pattern match)")
        return 'mikrotik'
    
    # Priority 4: Generic Cisco detection (lower priority to avoid false positives)
    # Only triggers if specific Cisco variants weren't detected above
    # Make 'ios' pattern more specific to avoid false positives with iOS apps, etc.
    if ('cisco' in version_lower or 
        'catalyst' in version_lower or
        ('ios' in version_lower and any(cisco_indicator in version_lower for cisco_indicator in [
            'cisco', 'catalyst', 'internetwork operating system'
        ]) and any(network_indicator in version_lower for network_indicator in [
            'switch', 'router', 'software', 'version', 'technical support'
        ]))):
        if logger:
            logger.info("Platform detected as 'cisco_xe' (generic Cisco pattern match)")
        return 'cisco_xe'
    
    # Priority 5: Generic fallback patterns (lowest confidence)
    # Linux/Unix detection
    if any(pattern in version_lower for pattern in ['linux', 'ubuntu', 'centos', 'redhat', 'debian', 'gnu/linux']):
        if logger:
            logger.info("Platform detected as 'linux' (Linux pattern match)")
        return 'linux'
    
    # Last resort: look for generic network device indicators
    # Make these patterns more specific to avoid false positives
    if (('switch' in version_lower and any(net_indicator in version_lower for net_indicator in [
            'management', 'ethernet', 'port', 'vlan', 'interface'
        ])) or
        ('router' in version_lower and any(net_indicator in version_lower for net_indicator in [
            'management', 'ethernet', 'interface', 'routing', 'bgp', 'ospf'
        ])) or
        ('software version' in version_lower and any(net_indicator in version_lower for net_indicator in [
            'switch', 'router', 'ethernet', 'management'
        ]))):
        if logger:
            logger.warning("Generic network device detected, defaulting to 'cisco_xe' (low confidence)")
        return 'cisco_xe'  # Default to cisco_xe for unidentified network devices
    
    # Priority 6: Unknown
    if logger:
        logger.warning(f"Unable to detect platform from output. First 500 chars: {version_output[:500]}")
    return 'unknown'


def is_switch_device(version_output: str, model: str = '', hostname: str = '', logger: Optional[logging.Logger] = None) -> bool:
    """
    Detect if a device is a switch (vs router) based on available information.
    
    Args:
        version_output: Output from 'show version' command
        model: Device model string
        hostname: Device hostname
        logger: Optional logger for debug information
        
    Returns:
        bool: True if device is a switch, False if it's a router
    """
    if not version_output:
        return False
    
    version_lower = version_output.lower()
    model_lower = model.lower() if model else ''
    hostname_lower = hostname.lower() if hostname else ''
    
    # Clear switch indicators in model
    switch_model_patterns = [
        'catalyst', 'c9300', 'c9200', 'c3850', 'c3750', 'c2960', 'c2950',
        'nexus', 'n9k', 'n7k', 'n5k', 'n3k', 'n2k',
        'switch', 'procurve', 'aruba', 'ws-c'
    ]
    
    # Clear router indicators in model
    router_model_patterns = [
        'asr', 'isr', 'router', 'c19', 'c29', 'c39', 'c89',
        'mx', 'srx', 'ex',  # Juniper routers
        '-r', '_r'  # Common router naming convention
    ]
    
    # Check model for strong indicators
    if model_lower:
        for pattern in switch_model_patterns:
            if pattern in model_lower:
                if logger:
                    logger.debug(f"Device identified as SWITCH based on model pattern: {pattern}")
                return True
        
        for pattern in router_model_patterns:
            if pattern in model_lower:
                if logger:
                    logger.debug(f"Device identified as ROUTER based on model pattern: {pattern}")
                return False
    
    # Check hostname for naming conventions
    if hostname_lower:
        if any(suffix in hostname_lower for suffix in ['-sw', '_sw', 'switch']):
            if logger:
                logger.debug(f"Device identified as SWITCH based on hostname")
            return True
        if any(suffix in hostname_lower for suffix in ['-r#', '-r', '_r', 'router']):
            if logger:
                logger.debug(f"Device identified as ROUTER based on hostname")
            return False
    
    # Check version output for switch-specific features
    switch_indicators = [
        'switch stack',
        'switch ports',
        'vlan',
        'spanning-tree',
        'catalyst',
        'nexus',
        'procurve',
        'switching',
        'ethernet switching'
    ]
    
    router_indicators = [
        'routing protocol',
        'bgp',
        'ospf',
        'eigrp',
        'ip routing',
        'mpls',
        'vpn'
    ]
    
    switch_score = sum(1 for pattern in switch_indicators if pattern in version_lower)
    router_score = sum(1 for pattern in router_indicators if pattern in version_lower)
    
    if logger:
        logger.debug(f"Device type scoring - Switch: {switch_score}, Router: {router_score}")
    
    # If switch score is significantly higher, it's a switch
    if switch_score > router_score:
        return True
    
    # Default to False (router) to avoid executing switch-specific commands on unknown devices
    if logger:
        logger.debug(f"Device type uncertain, defaulting to ROUTER (safer for command execution)")
    return False


class TaskPriority(Enum):
    """Task priority levels for work scheduling"""
    HIGH = 1      # Root devices, critical infrastructure
    MEDIUM = 2    # Core network devices
    LOW = 3       # Edge devices, endpoints


@dataclass
class DiscoveryTask:
    """Represents a device discovery task"""
    ip_address: str
    depth: int
    priority: TaskPriority
    credentials: Dict
    retry_count: int = 0
    parent_device: Optional[str] = None
    discovered_via: str = 'unknown'  # cdp, lldp, arp, etc.
    
    def __lt__(self, other):
        """Enable priority queue sorting"""
        return (self.priority.value, self.depth, self.retry_count) < (other.priority.value, other.depth, other.retry_count)


class ConnectionPool:
    """SSH Connection pool with reuse and lifecycle management"""
    
    def __init__(self, max_connections: int = 50, connection_timeout: int = 300):
        self.max_connections = max_connections
        self.connection_timeout = connection_timeout
        self.connections = {}  # {(ip, username): {'conn': conn, 'last_used': time, 'in_use': bool}}
        self.lock = threading.RLock()
        self._cleanup_thread = None
        self._start_cleanup_thread()
    
    def _start_cleanup_thread(self):
        """Start background thread to cleanup stale connections"""
        def cleanup_worker():
            while True:
                try:
                    time.sleep(60)  # Cleanup every minute
                    self._cleanup_stale_connections()
                except Exception as e:
                    logging.error(f"Connection cleanup error: {e}")
        
        self._cleanup_thread = threading.Thread(target=cleanup_worker, daemon=True)
        self._cleanup_thread.start()
    
    def _cleanup_stale_connections(self):
        """Remove stale connections"""
        current_time = time.time()
        with self.lock:
            stale_keys = []
            for key, conn_info in self.connections.items():
                if (not conn_info['in_use'] and 
                    current_time - conn_info['last_used'] > self.connection_timeout):
                    stale_keys.append(key)
            
            for key in stale_keys:
                try:
                    conn_info = self.connections.pop(key)
                    conn_info['conn'].disconnect()
                    logging.debug(f"Cleaned up stale connection to {key[0]}")
                except Exception as e:
                    logging.debug(f"Error cleaning up connection to {key[0]}: {e}")
    
    def get_connection(self, ip: str, username: str, password: str, device_type: str = 'cisco_ios', 
                      port: int = 22, timeout: int = 30) -> Optional['ConnectHandler']:
        """Get or create a connection from the pool"""
        key = (ip, username)
        
        with self.lock:
            if key in self.connections:
                conn_info = self.connections[key]
                if not conn_info['in_use']:
                    # Test if connection is still alive
                    try:
                        conn_info['conn'].find_prompt()
                        conn_info['in_use'] = True
                        conn_info['last_used'] = time.time()
                        logging.debug(f"Reusing connection to {ip}")
                        return conn_info['conn']
                    except:
                        # Connection is dead, remove it
                        del self.connections[key]
            
            # Create new connection if we haven't hit the limit
            if len(self.connections) >= self.max_connections:
                # Find and remove least recently used connection
                oldest_key = min(
                    (k for k, v in self.connections.items() if not v['in_use']),
                    key=lambda k: self.connections[k]['last_used'],
                    default=None
                )
                if oldest_key:
                    old_conn = self.connections.pop(oldest_key)
                    try:
                        old_conn['conn'].disconnect()
                    except:
                        pass
        
        # Create new connection
        try:
            device_conn = {
                'device_type': device_type,
                'ip': ip,
                'username': username,
                'password': password,
                'secret': password,
                'port': port,
                'timeout': timeout,
                'session_timeout': timeout * 2,
                'auth_timeout': min(30, timeout),
                'banner_timeout': 30,  # Increased for banner handling
                'global_delay_factor': 1,
                'fast_cli': True,
                'auto_connect': True,
                'allow_agent': False,
                'ssh_config_file': None,
                'conn_timeout': timeout,
                'use_keys': False,
                'key_file': None,
                'passphrase': None,
                'ssh_strict': False,
                'system_host_keys': False,  # Don't use system host keys
                'alt_host_keys': False,     # Don't use alt host keys
                'alt_key_file': '',
                'sock': None,
            }
            
            conn = ConnectHandler(**device_conn)
            
            with self.lock:
                self.connections[key] = {
                    'conn': conn,
                    'last_used': time.time(),
                    'in_use': True
                }
            
            logging.debug(f"Created new connection to {ip}")
            return conn
            
        except Exception as e:
            logging.warning(f"Failed to create connection to {ip}: {e}")
            # Log more specific error types for better debugging
            if "Authentication" in str(e):
                logging.warning(f"Authentication failed for {ip}: {e}")
            elif "timeout" in str(e).lower():
                logging.warning(f"Connection timeout to {ip}: {e}")
            elif "unreachable" in str(e).lower():
                logging.warning(f"Host unreachable {ip}: {e}")
            else:
                logging.warning(f"Connection error for {ip}: {e}")
            return None
    
    def release_connection(self, ip: str, username: str):
        """Release a connection back to the pool"""
        key = (ip, username)
        with self.lock:
            if key in self.connections:
                self.connections[key]['in_use'] = False
                self.connections[key]['last_used'] = time.time()
    
    def close_all(self):
        """Close all connections in the pool"""
        with self.lock:
            for conn_info in self.connections.values():
                try:
                    conn_info['conn'].disconnect()
                except:
                    pass
            self.connections.clear()


class ParallelDiscoveryEngine:
    """High-performance parallel discovery engine"""
    
    def __init__(self, session, logger, max_workers: int = 50, max_depth: int = None, filter_device_types: bool = True):
        self.session = session
        self.logger = logger
        self.max_workers = max_workers
        self.max_depth = max_depth or 999  # No depth limit by default
        self.filter_device_types = filter_device_types
        
        # Initialize specialized loggers for structured logging
        self.interface_logger = logging.getLogger(f'nautobot_inventory.interface_analysis.{id(self)}')
        self.neighbor_logger = logging.getLogger(f'nautobot_inventory.neighbor_discovery.{id(self)}')
        
        # Setup log files
        log_dir = os.path.join(settings.BASE_DIR, 'logs')
        os.makedirs(log_dir, exist_ok=True)
        
        # Interface analysis logger
        interface_handler = logging.FileHandler(os.path.join(log_dir, 'interface_analysis.log'))
        interface_formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - [%(funcName)s:%(lineno)d] - %(message)s')
        interface_handler.setFormatter(interface_formatter)
        self.interface_logger.addHandler(interface_handler)
        self.interface_logger.setLevel(logging.INFO)
        
        # Neighbor discovery logger
        neighbor_handler = logging.FileHandler(os.path.join(log_dir, 'neighbor_discovery.log'))
        neighbor_formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - [%(funcName)s:%(lineno)d] - %(message)s')
        neighbor_handler.setFormatter(neighbor_formatter)
        self.neighbor_logger.addHandler(neighbor_handler)
        self.neighbor_logger.setLevel(logging.DEBUG)  # Enable debug logging to see device type filtering
        
        # Work management
        self.task_queue = queue.PriorityQueue()
        self.completed_tasks = queue.Queue()
        self.visited_ips = set()
        self.processing_ips = set()
        self.active_workers = set()  # Track workers currently processing devices
        self.worker_tasks = {}  # Track what each worker is processing
        self.lock = threading.RLock()
        
        # Connection management
        self.connection_pool = ConnectionPool(max_connections=max_workers * 2)
        
        # Worker management
        self.workers = []
        self.neighbor_workers = []
        self.running = False
        
        # Statistics
        self.stats = {
            'devices_discovered': 0,
            'devices_failed': 0,
            'neighbors_found': 0,
            'connections_reused': 0,
            'start_time': None,
            'batch_updates': 0,
            'devices_in_progress': 0,
            'total_tasks_started': 0
        }
        
        # Batch processing
        self.device_batch = []
        self.batch_size = 20
        self.batch_lock = threading.Lock()
        self.last_batch_time = time.time()
    
    def add_task(self, ip: str, depth: int, priority: TaskPriority, credentials: Dict, 
                 parent_device: str = None, discovered_via: str = 'unknown'):
        """Add a discovery task to the queue"""
        if ip not in self.visited_ips and ip not in self.processing_ips:
            task = DiscoveryTask(
                ip_address=ip,
                depth=depth,
                priority=priority,
                credentials=credentials,
                parent_device=parent_device,
                discovered_via=discovered_via
            )
            self.task_queue.put(task)
            with self.lock:
                self.processing_ips.add(ip)
    
    def start_discovery(self, root_ip: str, credentials: Dict):
        """Start the parallel discovery process"""
        self.running = True
        self.stats['start_time'] = time.time()
        
        # Add root device with high priority
        self.add_task(root_ip, 0, TaskPriority.HIGH, credentials, discovered_via='root')
        
        # Start worker threads
        for i in range(self.max_workers):
            worker = threading.Thread(target=self._discovery_worker, args=(i,), daemon=True)
            worker.start()
            self.workers.append(worker)
        
        # Start neighbor discovery workers (specialized for CDP/LLDP)
        for i in range(min(10, self.max_workers // 3)):
            neighbor_worker = threading.Thread(target=self._neighbor_worker, args=(i,), daemon=True)
            neighbor_worker.start()
            self.neighbor_workers.append(neighbor_worker)
        
        # Start batch processor
        batch_processor = threading.Thread(target=self._batch_processor, daemon=True)
        batch_processor.start()
        
        self.logger.info(f"Started parallel discovery with {len(self.workers)} device workers and {len(self.neighbor_workers)} neighbor workers")
    
    def stop_discovery(self):
        """Stop the discovery process"""
        self.running = False
        
        # Flush any remaining devices in the batch
        with self.batch_lock:
            self._flush_batch()
        
        # Clean up any devices still stuck in discovering state
        self._cleanup_discovering_devices()
        
        self.connection_pool.close_all()
    
    def _cleanup_discovering_devices(self):
        """Clean up any devices still stuck in discovering state"""
        try:
            # Wait for all workers to finish before cleanup
            max_wait_time = 30  # Maximum 30 seconds to wait
            wait_start = time.time()
            
            while time.time() - wait_start < max_wait_time:
                with self.lock:
                    if len(self.active_workers) == 0 and self.stats['devices_in_progress'] == 0:
                        break
                    self.logger.info(f"Waiting for {len(self.active_workers)} active workers and {self.stats['devices_in_progress']} devices in progress to finish...")
                time.sleep(2)
            
            # Find devices still in discovering state
            discovering_devices = self.session.devices.filter(connection_status='discovering')
            cleanup_count = 0
            
            for device in discovering_devices:
                # Check if this device is currently being processed by a worker
                with self.lock:
                    is_being_processed = device.ip_address in self.worker_tasks.values()
                
                if is_being_processed:
                    self.logger.info(f"Device {device.ip_address} is still being processed by a worker, skipping cleanup")
                    continue
                
                if self.logger:
                    self.logger.warning(f"Cleaning up stuck device: {device.hostname} ({device.ip_address})")
                
                # Update device to failed state
                device.connection_status = 'failed'
                device.hostname = device.hostname.replace('discovering-', 'failed-')
                
                # Add error information to device_data
                if not device.device_data:
                    device.device_data = {}
                device.device_data['cleanup_reason'] = 'Discovery incomplete - marked as failed during cleanup'
                device.device_data['cleanup_timestamp'] = timezone.now().isoformat()
                device.device_data['cleanup_after_seconds'] = time.time() - wait_start
                
                device.save()
                cleanup_count += 1
                
                # Update stats
                self.stats['devices_failed'] += 1
            
            if cleanup_count > 0 and self.logger:
                self.logger.info(f"Cleaned up {cleanup_count} devices stuck in discovering state")
                
        except Exception as e:
            if self.logger:
                self.logger.error(f"Error during device cleanup: {e}")
            else:
                print(f"Error during device cleanup: {e}")
    
    def _discovery_worker(self, worker_id: int):
        """Worker thread for device discovery"""
        self.logger.debug(f"Discovery worker {worker_id} started")
        
        while self.running:
            try:
                # Get task with timeout
                task = self.task_queue.get(timeout=5)
                
                if task.depth > self.max_depth:
                    self.task_queue.task_done()
                    continue
                
                # Mark as visited and track worker activity
                with self.lock:
                    if task.ip_address in self.visited_ips:
                        self.task_queue.task_done()
                        continue
                    self.visited_ips.add(task.ip_address)
                    self.active_workers.add(worker_id)
                    self.worker_tasks[worker_id] = task.ip_address
                    self.stats['devices_in_progress'] += 1
                    self.stats['total_tasks_started'] += 1
                
                # Create initial "discovering" device record immediately
                discovering_device = {
                    'ip_address': task.ip_address,
                    'hostname': f'discovering-{task.ip_address}',
                    'model': 'unknown',
                    'platform': 'unknown',
                    'os_version': None,
                    'serial_number': None,
                    'discovery_depth': task.depth,
                    'connection_status': 'discovering',
                    'parent_device': task.parent_device,
                    'discovered_via': task.discovered_via,
                    'discovered_at': timezone.now().isoformat(),
                    'device_data': {
                        'discovery_status': 'in_progress',
                        'worker_id': worker_id
                    }
                }
                
                # Add discovering device to batch immediately
                with self.batch_lock:
                    self.device_batch.append(discovering_device)
                    if len(self.device_batch) >= self.batch_size:
                        self._flush_batch()
                
                # Discover device
                device_info = self._discover_device(task, worker_id)
                
                # Always add final device state to batch, whether successful or failed
                if device_info:
                    self.logger.debug(f"Worker {worker_id} got device_info for {task.ip_address}: status={device_info.get('connection_status')}, hostname={device_info.get('hostname')}")
                    # Add to batch for database update (this will update the existing record)
                    with self.batch_lock:
                        self.device_batch.append(device_info)
                        # Force flush for devices in final state (connected/failed) to ensure immediate UI visibility
                        if device_info.get('connection_status') in ['failed', 'connected'] or len(self.device_batch) >= self.batch_size:
                            self._flush_batch()
                    
                    # Update stats based on connection status
                    if device_info.get('connection_status') == 'connected':
                        self.stats['devices_discovered'] += 1
                    else:
                        self.stats['devices_failed'] += 1
                        self.logger.debug(f"Worker {worker_id} marked device {task.ip_address} as failed")
                else:
                    # This should rarely happen now, but create failed device as fallback
                    self.logger.warning(f"No device info returned for {task.ip_address}, creating fallback failed device")
                    failed_device = self._create_failed_device_info(task, "No device info returned")
                    with self.batch_lock:
                        self.device_batch.append(failed_device)
                        if len(self.device_batch) >= self.batch_size:
                            self._flush_batch()
                    self.stats['devices_failed'] += 1
                
                self.task_queue.task_done()
                
                # Mark worker as no longer active and remove from processing
                with self.lock:
                    self.active_workers.discard(worker_id)
                    processed_ip = self.worker_tasks.pop(worker_id, None)
                    if processed_ip:
                        self.processing_ips.discard(processed_ip)
                    if self.stats['devices_in_progress'] > 0:
                        self.stats['devices_in_progress'] -= 1
                
            except queue.Empty:
                continue
            except Exception as e:
                self.logger.error(f"Discovery worker {worker_id} error: {e}")
                # Create failed device for this exception case too
                try:
                    if 'task' in locals():
                        failed_device = self._create_failed_device_info(task, f"Worker exception: {str(e)}")
                        with self.batch_lock:
                            self.device_batch.append(failed_device)
                            if len(self.device_batch) >= self.batch_size:
                                self._flush_batch()
                        self.stats['devices_failed'] += 1
                        self.task_queue.task_done()
                        
                        # Mark worker as no longer active and remove from processing
                        with self.lock:
                            self.active_workers.discard(worker_id)
                            processed_ip = self.worker_tasks.pop(worker_id, None)
                            if processed_ip:
                                self.processing_ips.discard(processed_ip)
                            if self.stats['devices_in_progress'] > 0:
                                self.stats['devices_in_progress'] -= 1
                except Exception as nested_e:
                    self.logger.error(f"Error handling worker exception: {nested_e}")
        
        self.logger.debug(f"Discovery worker {worker_id} stopped")
    
    def _neighbor_worker(self, worker_id: int):
        """Specialized worker for neighbor discovery"""
        self.logger.debug(f"Neighbor worker {worker_id} started")
        
        while self.running:
            try:
                # Get completed discovery tasks
                device_info = self.completed_tasks.get(timeout=5)
                
                if device_info and device_info.get('connection_status') == 'connected':
                    neighbors = self._discover_neighbors_parallel(device_info, worker_id)
                    
                    # CRITICAL FIX: Save the updated device_info (with CDP/LLDP outputs) back to database
                    # The _discover_neighbors_parallel method modifies device_info in place,
                    # adding neighbors, CDP/LLDP command outputs to device_data
                    # We need to push this updated info to the batch for database persistence
                    with self.batch_lock:
                        self.device_batch.append(device_info)
                        # Force immediate flush to ensure neighbor data is visible in UI
                        if len(self.device_batch) >= self.batch_size // 2:  # Flush more frequently for neighbor updates
                            self._flush_batch()
                    
                    self.logger.info(f"Neighbor discovery complete for {device_info.get('ip_address')}: "
                                   f"found {len(neighbors)} neighbors, saved to database")
                    
                    # Add neighbor tasks with appropriate priority
                    for neighbor_ip, discovery_method in neighbors:
                        if neighbor_ip not in self.visited_ips:
                            priority = TaskPriority.MEDIUM if device_info.get('depth', 0) < 2 else TaskPriority.LOW
                            self.add_task(
                                neighbor_ip, 
                                device_info.get('depth', 0) + 1, 
                                priority,
                                device_info.get('credentials', {}),
                                parent_device=device_info.get('ip_address'),
                                discovered_via=discovery_method
                            )
                    
                    self.stats['neighbors_found'] += len(neighbors)
                
                self.completed_tasks.task_done()
                
            except queue.Empty:
                continue
            except Exception as e:
                self.logger.error(f"Neighbor worker {worker_id} error: {e}")
        
        self.logger.debug(f"Neighbor worker {worker_id} stopped")
    
    def _batch_processor(self):
        """Process device updates in batches"""
        while self.running:
            time.sleep(1)  # Process batches every 1 second for better UI responsiveness
            
            with self.batch_lock:
                if self.device_batch or time.time() - self.last_batch_time > 3:
                    self._flush_batch()
    
    def _flush_batch(self):
        """Flush current batch to database using bulk operations to minimize DB connections"""
        if not self.device_batch:
            return
        
        # Valid fields for DiscoveredDevice model
        valid_fields = {
            'hostname', 'ip_address', 'model', 'platform', 'os_version', 'serial_number',
            'discovery_depth', 'connection_status', 'neighbor_info', 'device_data',
            'parent_device', 'discovered_via', 'selected_for_onboarding', 
            'onboarding_job_id', 'onboarding_status', 'custom_credentials', 'discovered_at'
        }
        
        try:
            # Process devices in batch - group by IP address to handle updates properly
            devices_by_ip = {}
            for device_data in self.device_batch:
                ip = device_data.get('ip_address')
                if ip:
                    devices_by_ip[ip] = device_data  # Keep latest data for each IP
            
            # Use transaction to minimize connection overhead
            with transaction.atomic():
                # Bulk fetch all existing devices in one query
                ip_addresses = list(devices_by_ip.keys())
                existing_devices = {
                    dev.ip_address: dev 
                    for dev in DiscoveredDevice.objects.filter(
                        session=self.session,
                        ip_address__in=ip_addresses
                    ).select_for_update(skip_locked=True)  # Skip locked rows to avoid deadlocks
                }
                
                devices_to_create = []
                devices_to_update = []
                
                for ip_address, device_data in devices_by_ip.items():
                    # Filter out invalid fields
                    filtered_data = {k: v for k, v in device_data.items() if k in valid_fields}
                    
                    if ip_address in existing_devices:
                        # Update existing device
                        device_obj = existing_devices[ip_address]
                        updated = False
                        
                        for field, value in filtered_data.items():
                            current_value = getattr(device_obj, field, None)
                            # Update if value is meaningful and different
                            if value is not None and value != current_value:
                                # Special handling for certain fields
                                if field == 'hostname':
                                    # Handle hostname updates with priority logic
                                    should_update = False
                                    if isinstance(value, str) and isinstance(current_value, str):
                                        if current_value.startswith('discovering-'):
                                            should_update = True
                                        elif current_value.startswith(('auth-failed-', 'timeout-', 'unreachable-', 'failed-')):
                                            should_update = not value.startswith('discovering-')
                                        else:
                                            should_update = not value.startswith(('discovering-', 'auth-failed-', 'timeout-', 'unreachable-', 'failed-'))
                                    elif value is not None:
                                        should_update = True
                                    
                                    if should_update:
                                        setattr(device_obj, field, value)
                                        updated = True
                                elif field == 'connection_status' and value in ['discovering', 'connected', 'failed']:
                                    setattr(device_obj, field, value)
                                    updated = True
                                elif field == 'device_data':
                                    # Special handling for device_data - merge dictionaries
                                    if isinstance(value, dict) and isinstance(current_value, dict):
                                        merged_data = current_value.copy()
                                        for key, val in value.items():
                                            if key in merged_data and isinstance(merged_data[key], dict) and isinstance(val, dict):
                                                merged_data[key].update(val)
                                            else:
                                                merged_data[key] = val
                                        setattr(device_obj, field, merged_data)
                                        updated = True
                                    else:
                                        setattr(device_obj, field, value)
                                        updated = True
                                elif field == 'neighbor_info':
                                    if value:  # Only update if there's actual neighbor data
                                        setattr(device_obj, field, value)
                                        updated = True
                                else:
                                    setattr(device_obj, field, value)
                                    updated = True
                        
                        if updated:
                            devices_to_update.append(device_obj)
                    else:
                        # Create new device
                        device_obj = DiscoveredDevice(
                            session=self.session,
                            **filtered_data
                        )
                        devices_to_create.append(device_obj)
                
                # Bulk create new devices
                if devices_to_create:
                    DiscoveredDevice.objects.bulk_create(
                        devices_to_create,
                        ignore_conflicts=True,  # Handle race conditions gracefully
                        batch_size=100  # Process in batches to avoid memory issues
                    )
                    self.logger.debug(f"Bulk created {len(devices_to_create)} new devices")
                
                # Bulk update existing devices
                if devices_to_update:
                    # Use bulk_update with only fields that changed
                    update_fields = ['hostname', 'model', 'platform', 'os_version', 'serial_number',
                                   'discovery_depth', 'connection_status', 'neighbor_info', 'device_data',
                                   'parent_device', 'discovered_via', 'selected_for_onboarding',
                                   'onboarding_job_id', 'onboarding_status', 'custom_credentials']
                    DiscoveredDevice.objects.bulk_update(
                        devices_to_update,
                        update_fields,
                        batch_size=100  # Process in batches
                    )
                    self.logger.debug(f"Bulk updated {len(devices_to_update)} existing devices")
            
            self.stats['batch_updates'] += 1
            self.logger.debug(f"Batch update: {len(self.device_batch)} device records processed, {len(devices_by_ip)} unique devices (created: {len(devices_to_create)}, updated: {len(devices_to_update)})")
            
            self.device_batch.clear()
            self.last_batch_time = time.time()
            
        except Exception as e:
            self.logger.error(f"Batch update error: {e}")
            # Log the problematic device data for debugging
            for i, device_data in enumerate(self.device_batch):
                self.logger.debug(f"Batch device {i}: {device_data.get('ip_address', 'unknown')} - {device_data.get('hostname', 'unknown')}")
            self.device_batch.clear()  # Clear batch even on error to prevent infinite retry
    
    def _discover_device(self, task: DiscoveryTask, worker_id: int) -> Optional[Dict]:
        """Discover a single device with connection pooling"""
        ip = task.ip_address
        credentials = task.credentials
        
        # Log discovery start using structured logging
        if self.discovery_logger:
            self.discovery_logger.log_device_connection(
                ip, 'unknown', 'discovery_start', True
            )
        
        # Get connection from pool
        conn = self.connection_pool.get_connection(
            ip, 
            credentials['username'], 
            credentials['password'],
            credentials.get('device_type', 'cisco_ios'),
            credentials.get('port', 22),
            credentials.get('timeout', 30)
        )
        
        if not conn:
            if self.discovery_logger:
                self.discovery_logger.log_discovery_error(
                    ip, 'unknown', 'connection_failed', "Connection failed"
                )
            failed_info = self._create_failed_device_info(task, "Connection failed")
            return failed_info
        
        try:
            # Enable mode
            try:
                conn.enable()
            except Exception as enable_e:
                # Log command execution if needed
                if self.discovery_logger:
                    self.discovery_logger.log_command_execution(
                        ip, 'unknown', 'enable', False, None, f"Enable mode failed: {enable_e}"
                    )
                pass
            
            # Disable paging
            try:
                conn.send_command('terminal length 0', delay_factor=0.5)
            except:
                try:
                    conn.send_command('terminal len 0', delay_factor=0.5)
                except Exception as paging_e:
                    # Log command execution if needed
                    if self.discovery_logger:
                        self.discovery_logger.log_command_execution(
                            ip, 'unknown', 'terminal length 0', False, None, f"Disable paging failed: {paging_e}"
                        )
                    pass
            
            # Extract device information
            device_info = self._extract_device_info_fast(conn, task)
            
            # Log successful discovery
            if device_info and device_info.get('connection_status') == 'connected':
                hostname = device_info.get('hostname', 'unknown')
                if self.discovery_logger:
                    self.discovery_logger.log_device_connection(
                        ip, hostname, 'discovery_complete', True
                    )
                
                # Store credentials separately for neighbor discovery, don't add to device_info
                neighbor_task = device_info.copy()
                neighbor_task['credentials'] = credentials
                self.completed_tasks.put(neighbor_task)
            
            return device_info
            
        except Exception as e:
            if self.discovery_logger:
                self.discovery_logger.log_discovery_error(
                    ip, 'unknown', 'discovery_exception', str(e)
                )
            return self._create_failed_device_info(task, str(e))
        
        finally:
            # Clean up netmiko logging
            cleanup_netmiko_logging()
            
            # Release connection back to pool
            self.connection_pool.release_connection(ip, credentials['username'])
    
    def _extract_device_info_fast(self, conn: 'ConnectHandler', task: DiscoveryTask) -> Dict:
        """Enhanced device information extraction with full analysis"""
        device_info = {
            'ip_address': task.ip_address,
            'discovery_depth': task.depth,
            'connection_status': 'connected',
            'parent_device': task.parent_device,
            'discovered_via': task.discovered_via,
            'discovered_at': timezone.now().isoformat()  # Fix datetime serialization
        }
        
        try:
            # Get hostname from prompt
            prompt = conn.find_prompt()
            device_info['hostname'] = prompt.replace('#', '').replace('>', '') if prompt else f"device-{task.ip_address}"
            
            # Setup netmiko logging for this device
            if self.discovery_logger:
                setup_netmiko_logging(self.discovery_logger, task.ip_address, device_info['hostname'])
            
            # Get comprehensive version info and additional commands
            with CommandLogger(self.discovery_logger, task.ip_address, device_info.get('hostname', 'unknown')) as cmd_logger:
                cmd_logger.set_command("show version")
                version_output = conn.send_command("show version", delay_factor=1)
                cmd_logger.set_output(version_output)
            
            # Initialize device_data with basic information
            device_info['device_data'] = {
                'show_version': version_output,
                'raw_version_output': version_output,
                'discovery_timestamp': datetime.now().isoformat(),
                'command_outputs': {}
            }
            
            # Detect if device is a switch before running switch-specific commands
            is_switch = is_switch_device(version_output, '', device_info.get('hostname', ''), self.logger)
            device_type_role = 'switch' if is_switch else 'router'
            device_info['device_type_role'] = device_type_role
            # Also store in device_data so it gets saved to the database
            device_info['device_data']['device_type_role'] = device_type_role
            
            # Run additional commands for more comprehensive data
            # Build command list based on device type
            additional_commands = {
                'show_ip_interface_brief': 'show ip interface brief',
                'show_inventory': 'show inventory',
                'show_running_config': 'show running-config | include hostname|interface|ip address',
                'show spanning-tree': 'show spanning-tree',
                'show ip protocols': 'show ip protocols',
                'show ip route': 'show ip route',
                'show ip ospf neighbor': 'show ip ospf neighbor',
                'show bgp vrf * all summary': 'show bgp vrf * all summary',
            }
            
            # Only add switch-specific commands for switches
            if is_switch:
                additional_commands['show_interfaces_status'] = 'show interfaces status'
                self.logger.debug(f"Device {task.ip_address} identified as SWITCH, will execute switch commands")
            else:
                self.logger.debug(f"Device {task.ip_address} identified as ROUTER, skipping switch-specific commands")
            
            for cmd_name, command in additional_commands.items():
                try:
                    with CommandLogger(self.discovery_logger, task.ip_address, device_info.get('hostname', 'unknown')) as cmd_logger:
                        cmd_logger.set_command(command)
                        output = conn.send_command(command, delay_factor=0.5)
                        cmd_logger.set_output(output)
                    # Check if command returned an error
                    if output and ('% invalid' in output.lower() or '% incomplete' in output.lower()):
                        self.logger.warning(f"Command '{command}' returned error on {task.ip_address}: {output[:200]}")
                        device_info['device_data']['command_outputs'][cmd_name] = f"Error: Invalid command"
                    else:
                        device_info['device_data']['command_outputs'][cmd_name] = output
                except Exception as e:
                    if self.discovery_logger:
                        self.discovery_logger.log_command_execution(
                            task.ip_address, device_info.get('hostname', 'unknown'), 
                            command, False, None, str(e)
                        )
                    self.logger.debug(f"Failed to run {command} on {task.ip_address}: {e}")
                    device_info['device_data']['command_outputs'][cmd_name] = f"Error: {str(e)}"
            
            # Extract detailed device information like the full method
            # More specific Aruba/HP detection to avoid false positives
            version_lower = version_output.lower()
            is_aruba = (
                'aruba' in version_lower or 
                'arubaos' in version_lower or
                'hp procurve' in version_lower or 
                'hp provision' in version_lower or
                ('hp' in version_lower and any(hp_indicator in version_lower for hp_indicator in [
                    'procurve', 'provision', 'comware', 'hp networking', 'hp switch'
                ]))
            )
            
            # Use centralized robust platform detection
            detected_platform = detect_platform_from_output(version_output, is_aruba, self.logger)
            device_info['platform'] = detected_platform
            
            # Validate platform exists in Nautobot and has proper configuration
            platform_obj = get_or_create_platform(detected_platform)
            if platform_obj:
                device_info['platform_validated'] = True
                device_info['nautobot_platform'] = platform_obj.name
                device_info['napalm_driver'] = platform_obj.napalm_driver
            else:
                device_info['platform_validated'] = False
                self.logger.warning(f"Could not validate/create platform '{detected_platform}' for device {task.ip_address}")
            
            # NEW: Detect and parse stack information
            stack_info = stack_utils.detect_and_parse_stack(
                conn, detected_platform, version_output, self.logger, self.discovery_logger
            )
            if stack_info:
                device_info['stack_info'] = stack_info
                device_info['is_stack'] = True
                # Store stack info in device_data for persistence
                device_info['device_data']['stack_info'] = stack_info
                device_info['device_data']['is_stack'] = True
                # Override hostname with stack master hostname if available
                if stack_info.get('master_hostname'):
                    device_info['hostname'] = stack_info['master_hostname']
                self.logger.info(f"Device {task.ip_address} is a stack with {stack_info.get('total_members', 0)} members")
            else:
                device_info['is_stack'] = False
                device_info['device_data']['is_stack'] = False
            
            # Model extraction with device-specific patterns
            if is_aruba:
                model_patterns = [
                    r'Product Name\s*:\s*(.+?)(?:\n|$)',
                    r'Hardware:\s*(\S+)',
                    r'Model:\s*(\S+)',
                ]
            else:
                model_patterns = [
                    r'cisco\s+(\S+)\s+\(',
                    r'Model number\s*:\s*(\S+)',
                    r'Hardware:\s*(\S+)',
                    r'Product Name:\s*(.+?)(?:\n|$)',
                ]
            
            for pattern in model_patterns:
                model_match = re.search(pattern, version_output, re.IGNORECASE)
                if model_match:
                    device_info['model'] = model_match.group(1).strip()
                    break
            else:
                device_info['model'] = 'unknown'
            
            # OS Version extraction
            if is_aruba:
                version_patterns = [
                    r'Software revision\s*:\s*([^\s,\n]+)',
                    r'Version\s+([^\s,]+)',
                    r'Software Version\s+([^\s,]+)',
                ]
            else:
                version_patterns = [
                    r'Version\s+([^\s,]+)',
                    r'Software Version\s+([^\s,]+)',
                    r'IOS.*Version\s+([^\s,]+)',
                ]
            
            for pattern in version_patterns:
                version_match = re.search(pattern, version_output, re.IGNORECASE)
                if version_match:
                    device_info['os_version'] = version_match.group(1)
                    break
            else:
                device_info['os_version'] = None
            
            # Serial number extraction
            if is_aruba:
                serial_patterns = [
                    r'Serial Number:\s*(\S+)',
                    r'System serial number:\s*(\S+)',
                ]
            else:
                serial_patterns = [
                    r'System Serial Number\s*:\s*(\S+)',
                    r'Processor board ID\s+(\S+)',
                    r'Serial Number:\s*(\S+)',
                ]
            
            for pattern in serial_patterns:
                serial_match = re.search(pattern, version_output, re.IGNORECASE)
                if serial_match:
                    device_info['serial_number'] = serial_match.group(1)
                    break
            else:
                device_info['serial_number'] = None
            
            # Perform interface analysis for complete device information
            try:
                device_type = 'aruba_os' if is_aruba else 'cisco_ios'
                interface_analysis = self._analyze_device_interfaces_parallel(conn, device_info, device_type)
                device_info["interface_analysis"] = interface_analysis
                
                # Add port count summary
                port_counts = interface_analysis.get('port_counts', {})
                device_info["total_ports"] = port_counts.get('total_ports', 0)
                device_info["ethernet_ports"] = port_counts.get('ethernet_ports', 0)
                device_info["active_ports"] = interface_analysis.get('interface_status', {}).get('up', 0)
                device_info["interfaces"] = interface_analysis.get('interfaces', [])
                
                # Store interface analysis in device_data for persistence
                device_info["device_data"]["interface_analysis"] = interface_analysis
                device_info["device_data"]["interfaces"] = interface_analysis.get('interfaces', [])
                
                # Log interface analysis for structured logging
                self._log_interface_analysis_parallel(
                    device_info.get('hostname', 'unknown'),
                    task.ip_address,
                    interface_analysis
                )
                
            except Exception as e:
                self.logger.warning(f"Interface analysis failed for {task.ip_address}: {str(e)}")
                device_info["interface_analysis"] = {"error": str(e), "analysis_failed": True}
                device_info["device_data"]["interface_analysis"] = {"error": str(e), "analysis_failed": True}
            
            device_info['status'] = 'discovered'
            
        except Exception as e:
            self.logger.error(f"Error extracting device info from {task.ip_address}: {e}")
            device_info['status'] = f'partial_info: {str(e)}'
        
        return device_info
    
    def _analyze_device_interfaces_parallel(self, conn: 'ConnectHandler', device_info: Dict, device_type: str) -> Dict:
        """
        Parallel-safe interface analysis with comprehensive error handling including trunk ports.
        
        Args:
            conn: Netmiko connection object
            device_info: Device information dictionary
            device_type: Device type string
            
        Returns:
            Dictionary containing interface analysis results
        """
        analysis_result = {
            'port_counts': {'total_ports': 0, 'ethernet_ports': 0, 'trunk_ports': 0, 'access_ports': 0},
            'interface_status': {'up': 0, 'down': 0, 'admin_down': 0},
            'interfaces': [],
            'vlans': [],
            'vlan_count': 0,
            'poe_ports': 0,
            'interface_utilization': {},
            'trunk_details': {},
            'analysis_timestamp': datetime.now().isoformat()
        }
        
        try:
            is_aruba = device_type == 'aruba_os' or 'aruba' in device_info.get('platform', '').lower()
            
            # Get interface information with device-specific commands
            is_device_switch = device_info.get('device_type_role') == 'switch'
            
            if is_aruba:
                interface_commands = [
                    'show interfaces brief',
                    'show interface brief',
                    'show int brief'
                ]
            elif is_device_switch:
                # Switch-specific commands
                interface_commands = [
                    'show ip interface brief',
                    'show interface status',
                    'show interfaces description'
                ]
            else:
                # Router-specific commands (no 'show interface status')
                interface_commands = [
                    'show ip interface brief',
                    'show interfaces description'
                ]
            
            interface_output = None
            for cmd in interface_commands:
                try:
                    interface_output = conn.send_command(cmd, delay_factor=1)
                    if interface_output and 'invalid' not in interface_output.lower():
                        break
                except:
                    continue
            
            if interface_output:
                # Parse interface information
                interfaces = []
                lines = interface_output.split('\n')
                
                for line in lines:
                    if not line.strip() or line.startswith('Interface') or line.startswith('---'):
                        continue
                    
                    # Basic interface parsing - can be enhanced based on device type
                    parts = line.split()
                    if len(parts) >= 3:
                        interface = {
                            'name': parts[0],
                            'status': 'up' if 'up' in line.lower() else 'down',
                            'protocol': 'up' if len(parts) > 1 and 'up' in parts[1].lower() else 'down',
                            'description': ' '.join(parts[2:]) if len(parts) > 2 else ''
                        }
                        interfaces.append(interface)
                
                # Filter to only physical interfaces for counting
                from .utils.interface_parser import InterfaceParser
                physical_interfaces = InterfaceParser.filter_physical_interfaces(interfaces)
                
                # Count interface types and status using only physical interfaces
                for interface in physical_interfaces:
                    if 'ethernet' in interface['name'].lower() or 'gigabit' in interface['name'].lower():
                        analysis_result['port_counts']['ethernet_ports'] += 1
                    
                    analysis_result['port_counts']['total_ports'] += 1
                    
                    if interface['status'] == 'up':
                        analysis_result['interface_status']['up'] += 1
                    else:
                        analysis_result['interface_status']['down'] += 1
                
                # Store all interfaces (including virtual) for detailed display
                analysis_result['interfaces'] = interfaces
                # Store physical interfaces count separately for summary stats
                analysis_result['physical_interfaces'] = physical_interfaces
                analysis_result['port_counts']['physical_ports'] = len(physical_interfaces)
            
            # Parse trunk port information using InterfaceParser
            # Only parse trunks for switches, not routers
            is_device_switch = device_info.get('device_type_role') == 'switch'
            try:
                trunk_info = InterfaceParser.parse_trunk_ports(conn, device_type, is_switch=is_device_switch)
                analysis_result['port_counts']['trunk_ports'] = trunk_info.get('trunk_count', 0)
                analysis_result['port_counts']['access_ports'] = trunk_info.get('access_count', 0)
                analysis_result['trunk_details'] = trunk_info.get('trunk_details', {})
                analysis_result['trunk_ports'] = trunk_info.get('trunk_ports', [])
                analysis_result['access_ports'] = trunk_info.get('access_ports', [])
                
                if is_device_switch:
                    self.logger.debug(
                        f"Trunk analysis complete: {trunk_info.get('trunk_count', 0)} trunk ports, "
                        f"{trunk_info.get('access_count', 0)} access ports"
                    )
                else:
                    self.logger.debug("Skipped trunk analysis for router device")
            except Exception as trunk_error:
                self.logger.warning(f"Trunk port parsing failed: {trunk_error}")
                analysis_result['trunk_parse_error'] = str(trunk_error)
            
        except Exception as e:
            self.logger.error(f"Interface analysis failed in parallel worker: {e}")
            # Return minimal error result
            return {
                'error': str(e),
                'analysis_failed': True,
                'port_counts': {'total_ports': 0, 'ethernet_ports': 0, 'trunk_ports': 0, 'access_ports': 0},
                'interface_status': {'up': 0, 'down': 0},
                'interfaces': [],
                'trunk_details': {}
            }
        
        return analysis_result
    
    def _log_interface_analysis_parallel(self, hostname: str, ip: str, analysis_result: Dict) -> None:
        """Thread-safe interface analysis logging"""
        try:
            # Use the existing interface logger if available, otherwise use main logger
            if hasattr(self, 'interface_logger'):
                logger = self.interface_logger
            else:
                logger = self.logger
            
            port_counts = analysis_result.get('port_counts', {})
            interface_status = analysis_result.get('interface_status', {})
            
            logger.info(
                f"INTERFACE_ANALYSIS | IP: {ip} | Hostname: {hostname} | "
                f"TotalPorts: {port_counts.get('total_ports', 0)} | "
                f"EthernetPorts: {port_counts.get('ethernet_ports', 0)} | "
                f"ActiveInterfaces: {interface_status.get('up', 0)} | "
                f"DownInterfaces: {interface_status.get('down', 0)} | "
                f"Timestamp: {datetime.now().isoformat()}"
            )
        except Exception as e:
            self.logger.debug(f"Interface logging error: {e}")
    
    def _discover_neighbors_parallel(self, device_info: Dict, worker_id: int) -> List[Tuple[str, str]]:
        """Enhanced parallel neighbor discovery with logging and detailed neighbor info storage"""
        neighbors = []
        ip = device_info['ip_address']
        hostname = device_info.get('hostname', 'unknown')
        credentials = device_info['credentials']
        
        try:
            # Get connection from pool
            conn = self.connection_pool.get_connection(
                ip, credentials['username'], credentials['password']
            )
            
            if not conn:
                self.logger.debug(f"No connection available for neighbor discovery on {ip}")
                return neighbors
            
            # Log neighbor discovery start
            self._log_neighbor_discovery_start(hostname, ip)
            
            # Discover neighbors using CDP and LLDP - now returns detailed info with hostnames
            cdp_neighbors, cdp_output = self._discover_cdp_neighbors_safe(conn, ip)
            lldp_neighbors, lldp_output = self._discover_lldp_neighbors_safe(conn, ip)
            
            # Store raw CDP/LLDP outputs in command_outputs for UI display
            if 'device_data' not in device_info:
                device_info['device_data'] = {}
            if 'command_outputs' not in device_info['device_data']:
                device_info['device_data']['command_outputs'] = {}
            
            # ALWAYS store the raw outputs, even if empty - this helps with debugging
            self.logger.debug(f"Storing CDP output for {ip}: {'YES' if cdp_output else 'NO'} (length: {len(cdp_output) if cdp_output else 0})")
            self.logger.debug(f"Storing LLDP output for {ip}: {'YES' if lldp_output else 'NO'} (length: {len(lldp_output) if lldp_output else 0})")
            
            if cdp_output:
                device_info['device_data']['command_outputs']['show_cdp_neighbors_detail'] = cdp_output
            else:
                # Store a message indicating no CDP output was received
                device_info['device_data']['command_outputs']['show_cdp_neighbors_detail'] = "No CDP neighbors detail output received (CDP may not be enabled on this device)"
                
            if lldp_output:
                device_info['device_data']['command_outputs']['show_lldp_neighbors_detail'] = lldp_output
            else:
                # Store a message indicating no LLDP output was received
                device_info['device_data']['command_outputs']['show_lldp_neighbors_detail'] = "No LLDP neighbors detail output received (LLDP may not be enabled on this device)"
            
            # Parse detailed neighbor information using NeighborParser
            cdp_detailed = NeighborParser.parse_cdp_neighbor_details(cdp_output) if cdp_output else []
            lldp_detailed = NeighborParser.parse_lldp_neighbor_details(lldp_output) if lldp_output else []
            
            # Merge and deduplicate neighbors with enriched information
            neighbors_detailed = NeighborParser.merge_neighbor_sources(cdp_detailed, lldp_detailed)
            
            # Create simple neighbor list for backward compatibility
            for neighbor_detail in neighbors_detailed:
                neighbor_ip = neighbor_detail.get('ip_address')
                if neighbor_ip and self._is_valid_ip(neighbor_ip):
                    method = neighbor_detail.get('discovery_method', 'unknown')
                    neighbors.append((neighbor_ip, method))
            
            # Log neighbor discovery results
            cdp_ips = [n.get('ip_address') for n in cdp_detailed if n.get('ip_address')]
            lldp_ips = [n.get('ip_address') for n in lldp_detailed if n.get('ip_address')]
            self._log_neighbor_discovery_complete(hostname, ip, neighbors, cdp_ips, lldp_ips)
            
            # Store detailed neighbor data with hostnames in device_info for persistence
            device_info['device_data']['neighbors'] = neighbors_detailed
            device_info['neighbor_info'] = neighbors_detailed
            
        except Exception as e:
            self.logger.error(f"Neighbor discovery failed for {ip}: {e}")
            # Store empty neighbor data
            if 'device_data' not in device_info:
                device_info['device_data'] = {}
            device_info['device_data']['neighbors'] = []
            device_info['neighbor_info'] = []
        
        return neighbors
    
    
    def _discover_cdp_neighbors_safe(self, conn: 'ConnectHandler', ip: str) -> tuple:
        """
        Safe CDP neighbor discovery with device type filtering.
        
        Returns:
            tuple: (list of neighbor details with hostnames, raw CDP output string)
        """
        neighbors = []
        cdp_output = None
        
        try:
            # Get full CDP neighbors detail output to extract capabilities
            with CommandLogger(self.discovery_logger, ip, 'unknown') as cmd_logger:
                cmd_logger.set_command('show cdp neighbors detail')
                # ENHANCED: Use configurable timeout settings for large CDP outputs
                timeout = getattr(self, 'cdp_lldp_timeout', 300)
                max_loops = getattr(self, 'cdp_lldp_max_loops', 500)
                cdp_output = conn.send_command('show cdp neighbors detail', 
                                              delay_factor=2,  # Reduced for faster response
                                              max_loops=max_loops,   # Configurable loops
                                              cmd_verify=False,
                                              read_timeout=timeout,  # Configurable timeout
                                              expect_string=r'#|>',  # Explicit prompt detection
                                              strip_prompt=False,
                                              strip_command=False)
                cmd_logger.set_output(cdp_output)
            
            if cdp_output:
                # Parse CDP output to extract neighbors with capabilities and hostnames
                filtered_neighbors = self._parse_cdp_neighbors_with_capabilities(cdp_output)
                neighbors.extend(filtered_neighbors)
                
        except Exception as e:
            if self.discovery_logger:
                self.discovery_logger.log_command_execution(
                    ip, 'unknown', 'show cdp neighbors detail', 
                    False, None, str(e)
                )
            self.logger.debug(f"CDP discovery failed for {ip}: {e}")
            
            # Enhanced retry logic with multiple fallback strategies
            if "Pattern not detected" in str(e) or "timeout" in str(e).lower():
                try:
                    self.logger.debug(f"Retrying CDP discovery for {ip} with alternative method")
                    # Strategy 1: Try with chunked reading approach using configurable settings
                    retry_timeout = getattr(self, 'cdp_lldp_retry_timeout', 600)
                    cdp_output = conn.send_command('show cdp neighbors detail', 
                                                  delay_factor=1,  # Very fast checking
                                                  max_loops=1000,  # Allow many more loops
                                                  cmd_verify=False,
                                                  read_timeout=retry_timeout,  # Configurable retry timeout
                                                  expect_string=r'#|>|\$',  # Multiple prompt patterns
                                                  normalize=False)  # Don't normalize output
                    if cdp_output:
                        filtered_neighbors = self._parse_cdp_neighbors_with_capabilities(cdp_output)
                        neighbors.extend(filtered_neighbors)
                        self.logger.debug(f"CDP retry successful for {ip}: found {len(filtered_neighbors)} neighbors")
                except Exception as retry_e:
                    self.logger.debug(f"CDP detailed retry failed for {ip}: {retry_e}")
                    # Strategy 2: Fallback to simple CDP neighbors (no detail) if enabled
                    if getattr(self, 'enable_simple_fallback', True):
                        try:
                            self.logger.debug(f"Trying simple CDP neighbors for {ip}")
                            simple_cdp = conn.send_command('show cdp neighbors', 
                                                         delay_factor=1, 
                                                         max_loops=100,
                                                         read_timeout=60)
                            if simple_cdp:
                                # Parse simple CDP output (less detailed but faster)
                                simple_neighbors = self._parse_simple_cdp_output(simple_cdp)
                                neighbors.extend(simple_neighbors)
                                self.logger.debug(f"Simple CDP successful for {ip}: found {len(simple_neighbors)} neighbors")
                        except Exception as simple_e:
                            self.logger.debug(f"Simple CDP also failed for {ip}: {simple_e}")
                    
        return neighbors, cdp_output
    
    def _parse_simple_cdp_output(self, cdp_output: str) -> List[Dict]:
        """
        Parse simple CDP neighbors output (without detail) for fallback scenarios.
        
        Args:
            cdp_output: Raw CDP neighbors output (not detail)
            
        Returns:
            List of dictionaries with basic neighbor info
        """
        neighbors = []
        try:
            lines = cdp_output.split('\n')
            for line in lines:
                # Look for lines with device info (skip headers)
                if ('.' in line and 
                    not line.startswith('Capability') and 
                    not line.startswith('Device ID') and 
                    not line.startswith('-') and
                    len(line.split()) >= 2):
                    
                    parts = line.split()
                    if len(parts) >= 2:
                        device_id = parts[0]
                        # Extract hostname from device_id
                        hostname = device_id.split('.')[0] if '.' in device_id else device_id
                        
                        # Simple neighbor entry (no IP, will need to be resolved later)
                        neighbor = {
                            'ip': None,  # Will be resolved via DNS if possible
                            'hostname': hostname,
                            'device_id': device_id,
                            'method': 'cdp_simple',
                            'capabilities': ['R', 'S'],  # Assume router/switch for filtering
                        }
                        neighbors.append(neighbor)
                        
        except Exception as e:
            self.logger.debug(f"Error parsing simple CDP output: {e}")
            
        return neighbors
    
    def _parse_cdp_neighbors_with_capabilities(self, cdp_output: str) -> List[Dict]:
        """
        Parse CDP neighbors detail output and filter by device capabilities.
        
        Args:
            cdp_output: Raw CDP neighbors detail output
            
        Returns:
            List of dictionaries with neighbor details (ip, hostname, method, etc.)
        """
        filtered_neighbors = []
        valid_capabilities = {'R', 'S', 'B'}  # Router, Switch, Bridge
        
        try:
            # Log raw CDP output for debugging (first 500 chars)
            self.neighbor_logger.debug(f"CDP: Raw output (first 500 chars): {cdp_output[:500]}...")
            
            # Split output into device blocks
            device_blocks = cdp_output.split('-------------------------')
            self.neighbor_logger.debug(f"CDP: Found {len(device_blocks)} device blocks in output")
            
            for block in device_blocks:
                if not block.strip():
                    continue
                    
                # Extract device information from each block
                device_info = self._extract_cdp_device_info(block)
                
                if device_info and device_info.get('ip_address'):
                    capabilities = device_info.get('capabilities', set())
                    device_id = device_info.get('device_id', '')
                    hostname = device_id.split('.')[0] if device_id else None  # Extract hostname from device_id
                    
                    self.neighbor_logger.debug(
                        f"CDP: Extracted device info for {device_info.get('ip_address')}: "
                        f"capabilities={capabilities}, device_id={device_id}, hostname={hostname}"
                    )
                    
                    # Check if device has any of the valid capabilities
                    if capabilities & valid_capabilities:
                        neighbor_detail = {
                            'ip': device_info['ip_address'],
                            'hostname': hostname,
                            'method': 'cdp',
                            'platform': device_info.get('platform'),
                            'local_interface': device_info.get('local_interface'),
                            'remote_interface': device_info.get('remote_interface'),
                            'capabilities': list(capabilities)
                        }
                        filtered_neighbors.append(neighbor_detail)
                        self.neighbor_logger.debug(
                            f"CDP: Including {device_info['ip_address']} ({hostname}) with capabilities: {capabilities}"
                        )
                    else:
                        self.neighbor_logger.debug(
                            f"CDP: Excluding {device_info['ip_address']} ({hostname}) with capabilities: {capabilities}"
                        )
                        
        except Exception as e:
            self.neighbor_logger.debug(f"Error parsing CDP capabilities: {e}")
            # Fallback to simple IP extraction if parsing fails
            for line in cdp_output.split('\n'):
                if 'IP address:' in line:
                    match = re.search(r'IP address:\s*(\d+\.\d+\.\d+\.\d+)', line)
                    if match:
                        filtered_neighbors.append({
                            'ip': match.group(1),
                            'hostname': None,
                            'method': 'cdp'
                        })
        
        self.neighbor_logger.debug(f"CDP: Final filtered neighbors: {[n['ip'] for n in filtered_neighbors]}")
        return filtered_neighbors
    
    def _extract_cdp_device_info(self, device_block: str) -> Dict:
        """
        Extract device information from a CDP device block.
        
        Args:
            device_block: Single device block from CDP output
            
        Returns:
            Dictionary with device information including IP, hostname, capabilities, interfaces, platform
        """
        device_info = {}
        
        try:
            lines = device_block.split('\n')
            
            for line in lines:
                line = line.strip()
                
                # Extract IP address
                if 'IP address:' in line:
                    ip_match = re.search(r'IP address:\s*(\d+\.\d+\.\d+\.\d+)', line)
                    if ip_match:
                        device_info['ip_address'] = ip_match.group(1)
                
                # Extract capabilities
                elif 'Capabilities:' in line:
                    capabilities_text = line.split('Capabilities:')[1].strip()
                    # Parse capability codes (R, S, B, etc.)
                    capabilities = set()
                    for char in capabilities_text:
                        if char.isalpha() and char.isupper():
                            capabilities.add(char)
                    device_info['capabilities'] = capabilities
                
                # Extract device ID/name (hostname)
                elif 'Device ID:' in line:
                    device_id = line.split('Device ID:')[1].strip()
                    device_info['device_id'] = device_id
                
                # Extract platform
                elif 'Platform:' in line:
                    platform_match = re.search(r'Platform:\s*([^,]+)', line)
                    if platform_match:
                        device_info['platform'] = platform_match.group(1).strip()
                
                # Extract local interface
                elif 'Interface:' in line and 'Port ID' in line:
                    # Format: "Interface: GigabitEthernet0/1,  Port ID (outgoing port): GigabitEthernet0/2"
                    interface_match = re.search(r'Interface:\s*([^,]+)', line)
                    if interface_match:
                        device_info['local_interface'] = interface_match.group(1).strip()
                    port_match = re.search(r'Port ID[^:]*:\s*(.+)', line)
                    if port_match:
                        device_info['remote_interface'] = port_match.group(1).strip()
                    
        except Exception as e:
            self.logger.debug(f"Error extracting CDP device info: {e}")
            
        return device_info
    
    def _extract_lldp_device_info(self, device_block: str) -> Dict:
        """
        Extract device information from an LLDP device block.
        
        Args:
            device_block: Single device block from LLDP output
            
        Returns:
            Dictionary with device information including IP, hostname, capabilities, interfaces
        """
        device_info = {}
        
        try:
            lines = device_block.split('\n')
            
            for line in lines:
                line = line.strip()
                
                # Extract management IP address (multiple patterns)
                if 'Management Address:' in line or 'Management Addresses:' in line or 'IP:' in line:
                    ip_match = re.search(r'(\d+\.\d+\.\d+\.\d+)', line)
                    if ip_match:
                        device_info['ip_address'] = ip_match.group(1)
                
                # Extract capabilities (LLDP format varies by vendor)
                elif 'Capabilities:' in line or 'System Capabilities:' in line:
                    capabilities_text = line.split(':')[1].strip()
                    # Parse capability codes (R, B, etc.)
                    capabilities = set()
                    for char in capabilities_text:
                        if char.isalpha() and char.isupper():
                            capabilities.add(char)
                    device_info['capabilities'] = capabilities
                
                # Extract system name (hostname)
                elif 'System Name:' in line:
                    system_name = line.split('System Name:')[1].strip()
                    device_info['system_name'] = system_name
                
                # Extract system description (platform info)
                elif 'System Description:' in line:
                    system_desc = line.split('System Description:')[1].strip()
                    device_info['system_description'] = system_desc
                
                # Extract local interface
                elif 'Local Interface:' in line or 'Local Intf:' in line:
                    local_intf_match = re.search(r'Local (?:Interface|Intf):\s*(\S+)', line)
                    if local_intf_match:
                        device_info['local_interface'] = local_intf_match.group(1)
                
                # Extract remote interface (Port ID)
                elif 'Port ID:' in line:
                    port_id = line.split('Port ID:')[1].strip()
                    device_info['remote_interface'] = port_id
                
                # Extract chassis ID
                elif 'Chassis ID:' in line:
                    chassis_id = line.split('Chassis ID:')[1].strip()
                    device_info['chassis_id'] = chassis_id
                    
        except Exception as e:
            self.logger.debug(f"Error extracting LLDP device info: {e}")
            
        return device_info
    
    def _discover_lldp_neighbors_safe(self, conn: 'ConnectHandler', ip: str) -> tuple:
        """
        Safe LLDP neighbor discovery with device type filtering.
        
        Returns:
            tuple: (list of neighbor details with hostnames, raw LLDP output string)
        """
        neighbors = []
        lldp_output = None
        
        try:
            with CommandLogger(self.discovery_logger, ip, 'unknown') as cmd_logger:
                cmd_logger.set_command('show lldp neighbors detail')
                # ENHANCED: Use configurable timeout settings for large LLDP outputs
                timeout = getattr(self, 'cdp_lldp_timeout', 300)
                max_loops = getattr(self, 'cdp_lldp_max_loops', 500)
                lldp_output = conn.send_command('show lldp neighbors detail', 
                                               delay_factor=2,  # Reduced for faster response
                                               max_loops=max_loops,   # Configurable loops
                                               cmd_verify=False,
                                               read_timeout=timeout,  # Configurable timeout
                                               expect_string=r'#|>',  # Explicit prompt detection
                                               strip_prompt=False,
                                               strip_command=False)
                cmd_logger.set_output(lldp_output)
            
            if lldp_output and 'Total entries displayed: 0' not in lldp_output:
                # Parse LLDP output to extract neighbors with capabilities and hostnames
                filtered_neighbors = self._parse_lldp_neighbors_with_capabilities(lldp_output)
                neighbors.extend(filtered_neighbors)
                
        except Exception as e:
            if self.discovery_logger:
                self.discovery_logger.log_command_execution(
                    ip, 'unknown', 'show lldp neighbors detail', 
                    False, None, str(e)
                )
            self.logger.debug(f"LLDP discovery failed for {ip}: {e}")
            
            # Enhanced retry logic with multiple fallback strategies for LLDP
            if "Pattern not detected" in str(e) or "timeout" in str(e).lower():
                try:
                    self.logger.debug(f"Retrying LLDP discovery for {ip} with alternative method")
                    # Strategy 1: Try with chunked reading approach using configurable settings
                    retry_timeout = getattr(self, 'cdp_lldp_retry_timeout', 600)
                    lldp_output = conn.send_command('show lldp neighbors detail', 
                                                   delay_factor=1,  # Very fast checking
                                                   max_loops=1000,  # Allow many more loops
                                                   cmd_verify=False,
                                                   read_timeout=retry_timeout,  # Configurable retry timeout
                                                   expect_string=r'#|>|\$',  # Multiple prompt patterns
                                                   normalize=False)  # Don't normalize output
                    if lldp_output and 'Total entries displayed: 0' not in lldp_output:
                        filtered_neighbors = self._parse_lldp_neighbors_with_capabilities(lldp_output)
                        neighbors.extend(filtered_neighbors)
                        self.logger.debug(f"LLDP retry successful for {ip}: found {len(filtered_neighbors)} neighbors")
                except Exception as retry_e:
                    self.logger.debug(f"LLDP detailed retry failed for {ip}: {retry_e}")
                    # Strategy 2: Fallback to simple LLDP neighbors (no detail) if enabled
                    if getattr(self, 'enable_simple_fallback', True):
                        try:
                            self.logger.debug(f"Trying simple LLDP neighbors for {ip}")
                            simple_lldp = conn.send_command('show lldp neighbors', 
                                                           delay_factor=1, 
                                                           max_loops=100,
                                                           read_timeout=60)
                            if simple_lldp and 'Total entries displayed: 0' not in simple_lldp:
                                # Parse simple LLDP output (less detailed but faster)
                                simple_neighbors = self._parse_simple_lldp_output(simple_lldp)
                                neighbors.extend(simple_neighbors)
                                self.logger.debug(f"Simple LLDP successful for {ip}: found {len(simple_neighbors)} neighbors")
                        except Exception as simple_e:
                            self.logger.debug(f"Simple LLDP also failed for {ip}: {simple_e}")
                    
        return neighbors, lldp_output
    
    def _parse_simple_lldp_output(self, lldp_output: str) -> List[Dict]:
        """
        Parse simple LLDP neighbors output (without detail) for fallback scenarios.
        
        Args:
            lldp_output: Raw LLDP neighbors output (not detail)
            
        Returns:
            List of dictionaries with basic neighbor info
        """
        neighbors = []
        try:
            lines = lldp_output.split('\n')
            for line in lines:
                # Look for lines with device info (skip headers)
                if (not line.startswith('Device ID') and 
                    not line.startswith('Local Intf') and 
                    not line.startswith('-') and
                    not line.startswith('Total entries') and
                    len(line.split()) >= 2):
                    
                    parts = line.split()
                    if len(parts) >= 2:
                        device_id = parts[0]
                        # Extract hostname from device_id
                        hostname = device_id.split('.')[0] if '.' in device_id else device_id
                        
                        # Simple neighbor entry (no IP, will need to be resolved later)
                        neighbor = {
                            'ip': None,  # Will be resolved via DNS if possible
                            'hostname': hostname,
                            'device_id': device_id,
                            'method': 'lldp_simple',
                            'capabilities': ['R', 'B'],  # Assume router/bridge for filtering
                        }
                        neighbors.append(neighbor)
                        
        except Exception as e:
            self.logger.debug(f"Error parsing simple LLDP output: {e}")
            
        return neighbors
    
    def _parse_lldp_neighbors_with_capabilities(self, lldp_output: str) -> List[Dict]:
        """
        Parse LLDP neighbors detail output and filter by device capabilities.
        
        Args:
            lldp_output: Raw LLDP neighbors detail output
            
        Returns:
            List of dictionaries with neighbor details (ip, hostname, method, etc.)
        """
        filtered_neighbors = []
        valid_capabilities = {'R', 'B'}  # Router, Bridge (LLDP uses B for switches)
        
        try:
            # Split output into device blocks (LLDP typically uses different separators)
            # Try common LLDP separators
            separators = ['Local Interface:', 'Port ID:', 'Chassis ID:']
            device_blocks = []
            
            # Split by common LLDP patterns
            current_block = ""
            for line in lldp_output.split('\n'):
                if any(sep in line for sep in separators) and current_block:
                    device_blocks.append(current_block)
                    current_block = line + '\n'
                else:
                    current_block += line + '\n'
            
            # Add the last block
            if current_block.strip():
                device_blocks.append(current_block)
            
            for block in device_blocks:
                if not block.strip():
                    continue
                    
                # Extract device information from each block
                device_info = self._extract_lldp_device_info(block)
                
                if device_info and device_info.get('ip_address'):
                    capabilities = device_info.get('capabilities', set())
                    system_name = device_info.get('system_name', '')
                    hostname = system_name.split('.')[0] if system_name else None  # Extract hostname from system_name
                    
                    # Check if device has any of the valid capabilities
                    if capabilities & valid_capabilities:
                        neighbor_detail = {
                            'ip': device_info['ip_address'],
                            'hostname': hostname,
                            'method': 'lldp',
                            'platform': device_info.get('system_description'),
                            'local_interface': device_info.get('local_interface'),
                            'remote_interface': device_info.get('remote_interface'),
                            'capabilities': list(capabilities)
                        }
                        filtered_neighbors.append(neighbor_detail)
                        self.logger.debug(
                            f"LLDP: Including {device_info['ip_address']} ({hostname}) with capabilities: {capabilities}"
                        )
                    else:
                        self.logger.debug(
                            f"LLDP: Excluding {device_info['ip_address']} ({hostname}) with capabilities: {capabilities}"
                        )
                        
        except Exception as e:
            self.logger.debug(f"Error parsing LLDP capabilities: {e}")
            # Fallback to simple IP extraction if parsing fails
            ip_patterns = [
                r'Management Address:\s*(\d+\.\d+\.\d+\.\d+)',
                r'Management Addresses:\s*IP:\s*(\d+\.\d+\.\d+\.\d+)',
                r'IP:\s*(\d+\.\d+\.\d+\.\d+)',
                r'Management IP:\s*(\d+\.\d+\.\d+\.\d+)',
            ]
            
            for pattern in ip_patterns:
                ip_matches = re.findall(pattern, lldp_output, re.IGNORECASE)
                for ip_match in ip_matches:
                    filtered_neighbors.append({
                        'ip': ip_match,
                        'hostname': None,
                        'method': 'lldp'
                    })
        
        return filtered_neighbors
    
    def _log_neighbor_discovery_start(self, hostname: str, ip: str) -> None:
        """Log neighbor discovery start"""
        try:
            self.discovery_logger.log_neighbor_discovery_start(ip, hostname)
        except Exception as e:
            self.logger.debug(f"Neighbor logging error: {e}")
    
    def _log_neighbor_discovery_complete(self, hostname: str, ip: str, neighbors: List[Tuple[str, str]], 
                                        cdp_neighbors: List[str] = None, lldp_neighbors: List[str] = None) -> None:
        """Log neighbor discovery completion with filtering information"""
        try:
            cdp_count = len([n for n in neighbors if n[1] == 'cdp'])
            lldp_count = len([n for n in neighbors if n[1] == 'lldp'])
            neighbor_ips = [n[0] for n in neighbors]
            
            # Calculate filtering statistics if raw neighbor lists are provided
            filtering_info = ""
            if cdp_neighbors is not None and lldp_neighbors is not None:
                total_raw_cdp = len(cdp_neighbors)
                total_raw_lldp = len(lldp_neighbors)
                total_raw = total_raw_cdp + total_raw_lldp
                total_filtered = len(neighbors)
                
                if total_raw > 0:
                    filtered_percentage = (total_filtered / total_raw) * 100
                    filtering_info = f" | Raw: {total_raw} (CDP: {total_raw_cdp}, LLDP: {total_raw_lldp}) | Filtered: {total_filtered} ({filtered_percentage:.1f}%)"
            
            self.discovery_logger.log_neighbor_discovery_complete(
                ip, hostname, cdp_count, lldp_count, neighbor_ips
            )
            
            # Log additional filtering information
            if filtering_info:
                self.logger.info(f"NEIGHBOR_FILTERING | {hostname} ({ip}): {filtering_info}")
                # Also log to neighbor discovery log for better visibility
                self.neighbor_logger.info(f"NEIGHBOR_FILTERING | {hostname} ({ip}): {filtering_info}")
                
        except Exception as e:
            self.logger.debug(f"Neighbor logging error: {e}")
    
    def _create_failed_device_info(self, task: DiscoveryTask, error: str) -> Dict:
        """Create device info for failed discovery with enhanced error details"""
        self.logger.warning(f"Creating failed device info for {task.ip_address}: {error}")
        
        # Determine more specific error type for better UI display
        if "Authentication" in error or "authentication" in error.lower():
            error_type = "authentication_failed"
            hostname_prefix = "auth-failed"
            error_category = "Authentication Error"
        elif "timeout" in error.lower():
            error_type = "connection_timeout"
            hostname_prefix = "timeout"
            error_category = "Connection Timeout"
        elif "unreachable" in error.lower():
            error_type = "unreachable"
            hostname_prefix = "unreachable"
            error_category = "Network Unreachable"
        elif "Worker exception" in error:
            error_type = "worker_exception"
            hostname_prefix = "worker-failed"
            error_category = "Discovery Worker Error"
        else:
            error_type = "connection_failed"
            hostname_prefix = "failed"
            error_category = "Connection Failed"
            
        return {
            'ip_address': task.ip_address,
            'hostname': f'{hostname_prefix}-{task.ip_address}',
            'discovery_depth': task.depth,
            'connection_status': 'failed',
            'parent_device': task.parent_device,
            'discovered_via': task.discovered_via,
            'model': 'unknown',
            'platform': 'unknown',
            'os_version': None,
            'serial_number': None,
            'discovered_at': timezone.now().isoformat(),
            'neighbor_info': [],
            'selected_for_onboarding': False,
            'custom_credentials': False,
            # Store detailed error information
            'device_data': {
                'error': error,
                'error_type': error_type,
                'error_category': error_category,
                'discovery_attempted': True,
                'failure_reason': f'{error_type}: {error}',
                'discovery_timestamp': timezone.now().isoformat(),
                'retry_count': getattr(task, 'retry_count', 0),
                'discovery_worker_error': 'Worker exception' in error
            }
        }
    
    def _is_valid_ip(self, ip: str) -> bool:
        """Validate IP address"""
        try:
            socket.inet_aton(ip)
            return not (ip.startswith('127.') or ip.endswith('.255') or ip.endswith('.0'))
        except:
            return False
    
    def get_stats(self) -> Dict:
        """Get discovery statistics with improved tracking"""
        runtime = time.time() - self.stats['start_time'] if self.stats['start_time'] else 0
        devices_per_second = 0
        total_devices_processed = self.stats['devices_discovered'] + self.stats['devices_failed']
        if runtime > 0 and total_devices_processed > 0:
            devices_per_second = total_devices_processed / runtime
        
        with self.lock:
            active_workers_count = len(self.active_workers)
            devices_in_progress = self.stats['devices_in_progress']
            
        # Check if truly complete: no tasks in main queue, no tasks in completed queue, 
        # no active workers, and no devices in progress
        pending_neighbor_tasks = self.completed_tasks.qsize()
        is_truly_complete = (
            self.task_queue.qsize() == 0 and 
            pending_neighbor_tasks == 0 and
            active_workers_count == 0 and 
            devices_in_progress == 0
        )
            
        return {
            **self.stats,
            'runtime_seconds': runtime,
            'devices_per_second': devices_per_second,
            'active_tasks': self.task_queue.qsize(),
            'pending_neighbor_tasks': pending_neighbor_tasks,
            'visited_devices': len(self.visited_ips),
            'processing_devices': len(self.processing_ips),
            'active_workers': active_workers_count,
            'devices_in_progress': devices_in_progress,
            'is_truly_complete': is_truly_complete
        }
    
    # Stack detection and parsing methods have been moved to stack_utils.py
    # Use stack_utils.detect_and_parse_stack() instead


class NetworkInventoryDiscoveryJob(Job):
    """
    Network device discovery job that recursively discovers devices via SSH/CDP/LLDP.
    
    Features:
    - Recursive device discovery up to configurable depth
    - Resource management with concurrent connection limits
    - Timeout protection and error handling
    - Progress tracking and status updates
    - Support for multiple device types and platforms
    - Configurable logging verbosity for reduced log volume
    """
    
    class Meta:
        name = "Network Inventory Discovery"
        description = "Discover network devices via SSH/CDP/LLDP recursively"
        has_sensitive_variables = True  # Contains passwords
    
    # Job variables
    verbose_logging = BooleanVar(
        label="Verbose Logging",
        description="Enable detailed logging (increases log volume significantly)",
        default=False,
        required=False
    )
    
    filter_device_types = BooleanVar(
        label="Filter Device Types",
        description="Filter CDP/LLDP neighbors to only include routers (R), switches (S), and bridges (B)",
        default=True,
        required=False
    )

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.session = None
        self.visited_ips: Set[str] = set()
        self.discovered_devices: List[Dict] = []
        self.lock = threading.Lock()
        
        # Enhanced configuration for parallel discovery
        config = getattr(settings, 'PLUGINS_CONFIG', {}).get('nautobot_inventory', {})
        self.max_depth = config.get('max_discovery_depth', None)  # No limit by default
        self.max_workers = config.get('max_concurrent_connections', 50)  # Increased default
        self.timeout = config.get('discovery_timeout', 1800)  # 30 minutes default
        self.device_timeout = config.get('device_connection_timeout', 30)  # Faster timeout
        self.batch_timeout = config.get('futures_batch_timeout', 120)
        
        # CDP/LLDP timeout configuration
        self.cdp_lldp_timeout = config.get('cdp_lldp_timeout', 300)  # 5 minutes default
        self.cdp_lldp_max_loops = config.get('cdp_lldp_max_loops', 500)  # 500 loops default
        self.cdp_lldp_retry_timeout = config.get('cdp_lldp_retry_timeout', 600)  # 10 minutes default
        self.enable_simple_fallback = config.get('enable_simple_neighbor_fallback', True)
        
        # Parallel discovery engine
        self.parallel_engine = None
        
        # Discovery logger will be initialized when session is available
        self.discovery_logger = None

    def _initialize_discovery_logger(self, session_id: str, verbose: bool = False):
        """Initialize the centralized discovery logger with optimized settings."""
        if not self.discovery_logger:
            # Configure logging levels for discovery jobs
            log_levels = {
                'netmiko_debug': False,  # Disable netmiko debug by default
                'command_output': True,  # Keep command output
                'detailed_output': verbose,  # Only detailed output if verbose
                'connection_debug': False,  # Disable connection debug
            }
            
            self.discovery_logger = get_discovery_logger(session_id, log_levels)
            self.logger.info(f"Initialized discovery logger for session: {session_id} (verbose: {verbose})")
            
            # Suppress console debug output for the entire session
            self._suppress_console_debug_output()

    def _suppress_console_debug_output(self):
        """Suppress debug output to console for cleaner logs."""
        import logging
        import sys
        
        # Suppress netmiko debug output to console
        netmiko_logger = logging.getLogger('netmiko')
        netmiko_logger.setLevel(logging.WARNING)
        
        # Suppress paramiko debug output to console
        paramiko_logger = logging.getLogger('paramiko')
        paramiko_logger.setLevel(logging.WARNING)
        
        # Suppress root logger debug output to console
        root_logger = logging.getLogger()
        root_logger.setLevel(logging.INFO)
        
        # Remove any existing console handlers from root logger
        for handler in root_logger.handlers[:]:
            if isinstance(handler, logging.StreamHandler) and handler.stream == sys.stdout:
                root_logger.removeHandler(handler)

    def log_device_discovery_start(self, ip: str, hostname: str = None) -> None:
        """Log structured information about device discovery start."""
        if self.discovery_logger:
            self.discovery_logger.log_device_connection(
                ip, hostname or 'unknown', 'discovery_start', True
            )
    
    def log_device_discovery_complete(self, device_info: Dict) -> None:
        """Log structured information about completed device discovery."""
        ip = device_info.get('ip_address', 'unknown')
        hostname = device_info.get('hostname', 'unknown')
        
        if self.discovery_logger:
            self.discovery_logger.log_device_connection(
                ip, hostname, 'discovery_complete', True
            )
    
    def log_interface_analysis_summary(self, hostname: str, ip: str, analysis_result: Dict) -> None:
        """Log structured interface analysis summary."""
        if self.discovery_logger:
            total_interfaces = analysis_result.get('total_interfaces', 0)
            self.discovery_logger.log_interface_analysis_complete(
                ip, hostname, total_interfaces, analysis_result
            )
    
    def log_discovery_error(self, ip: str, error_type: str, error_message: str, hostname: str = None) -> None:
        """Log structured error information."""
        if self.discovery_logger:
            self.discovery_logger.log_discovery_error(
                ip, hostname or 'unknown', error_type, error_message
            )
    
    def log_session_summary(self, total_devices: int, successful: int, failed: int, session_duration: float) -> None:
        """Log structured session summary."""
        if self.discovery_logger:
            self.discovery_logger.log_session_summary(total_devices, successful, failed, session_duration)
        else:
            # Fallback to standard logger if discovery_logger not available
            self.logger.info(
                f"SESSION_SUMMARY | TotalDevices: {total_devices} | Successful: {successful} | "
                f"Failed: {failed} | Duration: {session_duration:.2f}s | "
                f"SuccessRate: {(successful/total_devices*100):.1f}% | "
                f"Timestamp: {datetime.now().isoformat()}"
            )
    
    def _make_json_serializable(self, obj):
        """Recursively convert datetime objects to JSON-serializable format."""
        if hasattr(obj, 'isoformat'):  # datetime object
            return obj.isoformat()
        elif isinstance(obj, dict):
            return {key: self._make_json_serializable(value) for key, value in obj.items()}
        elif isinstance(obj, list):
            return [self._make_json_serializable(item) for item in obj]
        else:
            return obj

    def is_discovery_stopped(self) -> bool:
        """
        Check if the discovery session has been stopped by the user.
        Uses direct query instead of refresh_from_db to avoid connection overhead.
        
        Returns:
            bool: True if the session status is 'stopped', False otherwise
        """
        if not self.session:
            return False
            
        try:
            # Use direct query instead of refresh_from_db to avoid connection overhead
            # Cache the result for a short time to reduce queries
            current_time = time.time()
            if not hasattr(self, '_last_status_check') or (current_time - self._last_status_check) >= 2:
                status = InventoryDiscoverySession.objects.filter(
                    session_id=self.session.session_id
                ).values_list('status', flat=True).first()
                self._cached_status = status
                self._last_status_check = current_time
            else:
                status = getattr(self, '_cached_status', None)
            
            return status == 'stopped'
        except Exception as e:
            self.logger.warning(f"Error checking session status: {e}")
            return False

    def run(self, session_id: str, location: str, router_ip: str, secrets_group_id: str, username: str = None, verbose_logging: bool = False, filter_device_types: bool = True):
        """
        Main entry point for the discovery job.
        
        Args:
            session_id: UUID of the discovery session
            location: Network location/site name
            router_ip: IP address of the starting router
            secrets_group_id: ID of the secrets group containing credentials
            username: Optional username override (if not provided, uses secrets group username)
            verbose_logging: Enable verbose logging (default: False for reduced log volume)
            filter_device_types: Filter CDP/LLDP neighbors by device type (default: True)
            
        Returns:
            Dictionary with discovery results
        """
        try:
            # Get the discovery session
            self.session = InventoryDiscoverySession.objects.get(session_id=session_id)
            self.session.status = 'running'
            self.session.save()
            
            # Initialize discovery logger with session ID and verbose setting
            self._initialize_discovery_logger(session_id, verbose_logging)
            
            # Get credentials from secrets group
            try:
                secrets_group = SecretsGroup.objects.get(id=secrets_group_id)
                
                # Log the secrets group details
                self.logger.debug(f"Using secrets group: {secrets_group.name} (ID: {secrets_group.id})")
                self.logger.debug(f"Secrets group associations: {len(secrets_group.secrets_group_associations.all())} total")
                
                # Get username and password from secrets group using proper API
                if username is None:
                    # Try different access types for username
                    username_found = False
                    for access_type in [SecretsGroupAccessTypeChoices.TYPE_SSH, 
                                      SecretsGroupAccessTypeChoices.TYPE_GENERIC]:
                        try:
                            username = secrets_group.get_secret_value(
                                access_type=access_type,
                                secret_type=SecretsGroupSecretTypeChoices.TYPE_USERNAME
                            )
                            self.logger.debug(f"Retrieved username using {access_type} access type")
                            username_found = True
                            break
                        except ObjectDoesNotExist as e:
                            self.logger.debug(f"Failed to get username with {access_type}: {e}")
                            continue
                    
                    if not username_found:
                        raise ValueError("No username found in secrets group and none provided")
                
                # Get password from secrets group
                password_found = False
                for access_type in [SecretsGroupAccessTypeChoices.TYPE_SSH, 
                                  SecretsGroupAccessTypeChoices.TYPE_GENERIC]:
                    try:
                        password = secrets_group.get_secret_value(
                            access_type=access_type,
                            secret_type=SecretsGroupSecretTypeChoices.TYPE_PASSWORD
                        )
                        password_found = True
                        break
                    except ObjectDoesNotExist:
                        continue
                
                if not password_found:
                    raise ValueError("No password found in secrets group")
                        
            except SecretsGroup.DoesNotExist:
                raise ValueError(f"Secrets group with ID {secrets_group_id} not found")
            except SecretError as e:
                raise ValueError(f"Failed to retrieve secret value: {str(e)}")
            except Exception as e:
                raise ValueError(f"Failed to retrieve credentials from secrets group: {str(e)}")
            
            self.logger.info(f"Starting network discovery from {router_ip} at location: {location}")
            
            # Log discovery session start
            self.log_device_discovery_start(router_ip)
            
            # Set timeout
            start_time = time.time()
            end_time = start_time + self.timeout
            
            # Start parallel discovery with the new engine
            devices = self.discover_network_parallel(
                router_ip=router_ip,
                username=username,
                password=password,
                max_depth=self.max_depth,
                end_time=end_time,
                filter_device_types=filter_device_types
            )
            
            # Check if discovery was stopped or timed out
            if self.is_discovery_stopped():
                self.session.status = 'stopped'
                self.session.completed_at = timezone.now()
                self.session.progress_info = self.session.progress_info or {}
                self.session.progress_info['stopped_by_user'] = True
                self.logger.info("Discovery was stopped by user")
            elif time.time() >= end_time:
                self.session.status = 'timeout'
                self.session.completed_at = timezone.now()
                self.session.progress_info = self.session.progress_info or {}
                self.session.progress_info['timed_out'] = True
                self.session.error_message = f'Discovery timed out after {self.timeout} seconds'
                self.logger.warning("Discovery timed out")
            else:
                self.session.status = 'completed'
                self.session.completed_at = timezone.now()
                self.logger.success(f"Discovery completed. Found {len(devices)} devices.")
            
            # Log session summary
            session_duration = time.time() - start_time
            successful_devices = len([d for d in devices if d.get('connection_status') == 'connected'])
            failed_devices = len(devices) - successful_devices
            self.log_session_summary(len(devices), successful_devices, failed_devices, session_duration)
            
            # Convert devices to JSON-serializable format before storing
            json_safe_devices = []
            for device in devices:
                json_device = device.copy()
                # Convert any datetime objects to ISO format strings
                for key, value in json_device.items():
                    if hasattr(value, 'isoformat'):  # datetime object
                        json_device[key] = value.isoformat()
                    elif isinstance(value, dict):
                        # Handle nested datetime objects in device_data, etc.
                        json_device[key] = self._make_json_serializable(value)
                json_safe_devices.append(json_device)
            
            # Final update session with results
            self.session.discovered_data = json_safe_devices
            self.session.device_count = len(devices)
            self.session.save()
            
            # Return the results data - this will be stored in JobResult.result
            return {
                "discovered_count": len(devices),
                "devices": json_safe_devices,
                "location": location,
                "message": f"Successfully discovered {len(devices)} devices"
            }
            
        except InventoryDiscoverySession.DoesNotExist:
            error_msg = f"Discovery session {session_id} not found"
            self.logger.error(error_msg)
            raise RuntimeError(error_msg)
            
        except Exception as e:
            import traceback
            error_traceback = traceback.format_exc()
            error_msg = f"Discovery failed: {str(e)}"
            
            self.logger.error(error_msg)
            self.logger.error(f"Full traceback: {error_traceback}")
            
            if self.session:
                self.session.status = 'failed'
                self.session.error_message = error_msg
                self.session.completed_at = timezone.now()
                
                # Store detailed error information
                if not self.session.progress_info:
                    self.session.progress_info = {}
                self.session.progress_info.update({
                    'error_type': type(e).__name__,
                    'error_traceback': error_traceback,
                    'failed_at': timezone.now().isoformat(),
                    'job_execution_error': True,
                    'error_source': 'job_main_execution'
                })
                self.session.save()
                
                # Log structured error information
                self.log_discovery_error('job_execution', 'job_main_error', str(e))
            
            # Re-raise the exception to indicate job failure
            raise

    def discover_network_parallel(self, router_ip: str, username: str, password: str, 
                                 max_depth: int, end_time: float, filter_device_types: bool = True) -> List[Dict]:
        """
        High-performance parallel network discovery using the new engine.
        
        Args:
            router_ip: Starting router IP
            username: SSH username
            password: SSH password
            max_depth: Maximum discovery depth (None for unlimited)
            end_time: Discovery timeout timestamp
            filter_device_types: Filter CDP/LLDP neighbors by device type
            
        Returns:
            List of discovered device dictionaries
        """
        self.logger.info(f"🚀 Starting PARALLEL discovery from {router_ip} with {self.max_workers} workers")
        
        # Initialize parallel discovery engine
        self.parallel_engine = ParallelDiscoveryEngine(
            session=self.session,
            logger=self.logger,
            max_workers=self.max_workers,
            max_depth=max_depth,
            filter_device_types=filter_device_types
        )
        # Pass discovery logger and timeout settings to parallel engine
        self.parallel_engine.discovery_logger = self.discovery_logger
        self.parallel_engine.cdp_lldp_timeout = self.cdp_lldp_timeout
        self.parallel_engine.cdp_lldp_max_loops = self.cdp_lldp_max_loops
        self.parallel_engine.cdp_lldp_retry_timeout = self.cdp_lldp_retry_timeout
        self.parallel_engine.enable_simple_fallback = self.enable_simple_fallback
        
        # Prepare credentials
        credentials = {
            'username': username,
            'password': password,
            'device_type': 'cisco_ios',  # Default, will auto-detect
            'port': 22,
            'timeout': self.device_timeout
        }
        
        try:
            # Start the parallel discovery
            self.parallel_engine.start_discovery(router_ip, credentials)
            
            # Monitor progress and handle timeout
            last_progress_time = time.time()
            last_device_count = 0
            no_progress_timeout = 120  # 2 minutes without progress
            
            while time.time() < end_time:
                if self.is_discovery_stopped():
                    self.logger.info("Discovery stopped by user request")
                    break
                
                stats = self.parallel_engine.get_stats()
                
                # Check for progress timeout (no new devices discovered in 2 minutes)
                current_device_count = stats['devices_discovered'] + stats['devices_failed']
                if current_device_count > last_device_count:
                    last_progress_time = time.time()
                    last_device_count = current_device_count
                elif time.time() - last_progress_time > no_progress_timeout and stats.get('active_workers', 0) == 0:
                    self.logger.warning(f"No progress for {no_progress_timeout} seconds and no active workers, stopping discovery")
                    break
                
                # Update session progress with enhanced information (throttled to reduce DB connections)
                # Only update every 5 seconds to minimize database writes
                current_time = time.time()
                if not hasattr(self, '_last_progress_update') or (current_time - self._last_progress_update) >= 5:
                    try:
                        progress_message = f"⚡ {stats['devices_per_second']:.1f} devices/sec"
                        if stats['active_tasks'] > 0:
                            progress_message += f", {stats['active_tasks']} queued"
                        if stats.get('pending_neighbor_tasks', 0) > 0:
                            progress_message += f", {stats['pending_neighbor_tasks']} neighbors pending"
                        if stats.get('active_workers', 0) > 0:
                            progress_message += f", {stats['active_workers']} workers active"
                        if stats.get('devices_in_progress', 0) > 0:
                            progress_message += f", {stats['devices_in_progress']} processing"
                        
                        # Use update() to avoid fetching the object first
                        # This uses a single UPDATE query instead of SELECT + UPDATE
                        InventoryDiscoverySession.objects.filter(session_id=self.session.session_id).update(
                            progress_info={
                                'current_device': f"Parallel Discovery ({stats['devices_discovered']} found, {stats['devices_failed']} failed)",
                                'total_discovered': stats['devices_discovered'],
                                'message': progress_message,
                                'last_update': timezone.now().isoformat()
                            },
                            device_count=stats['devices_discovered']
                        )
                        self._last_progress_update = current_time
                    except Exception as e:
                        self.logger.debug(f"Progress update failed: {e}")
                
                # Check if discovery is complete (no more tasks AND no workers processing)
                total_devices_processed = stats['devices_discovered'] + stats['devices_failed']
                if stats.get('is_truly_complete', False) and total_devices_processed > 1:
                    self.logger.info("✅ Parallel discovery completed - no more tasks and no active workers")
                    break
                elif stats['active_tasks'] == 0 and stats.get('active_workers', 0) == 0 and stats.get('pending_neighbor_tasks', 0) == 0 and total_devices_processed > 0:
                    # Wait longer to ensure all workers have finished processing and neighbor discovery is complete
                    self.logger.info(f"⏳ No active tasks or workers, waiting for final cleanup... (devices_in_progress: {stats.get('devices_in_progress', 0)}, pending_neighbor_tasks: {stats.get('pending_neighbor_tasks', 0)})")
                    time.sleep(10)  # Give workers more time to finish and update stats
                    # Re-check stats after waiting
                    updated_stats = self.parallel_engine.get_stats()
                    self.logger.info(f"📊 Final check stats: active_tasks={updated_stats['active_tasks']}, pending_neighbor_tasks={updated_stats.get('pending_neighbor_tasks', 0)}, active_workers={updated_stats.get('active_workers', 0)}, devices_in_progress={updated_stats.get('devices_in_progress', 0)}, is_truly_complete={updated_stats.get('is_truly_complete', False)}")
                    if updated_stats.get('is_truly_complete', False):
                        self.logger.info("✅ Parallel discovery completed after final check")
                        break
                    else:
                        self.logger.info("⏳ Still waiting for workers to complete, continuing monitoring...")
                
                time.sleep(2)  # Check every 2 seconds
            
            # Stop the discovery engine
            self.parallel_engine.stop_discovery()
            
            # Small delay to ensure all database operations are completed
            time.sleep(1)
            
            # Get final statistics
            final_stats = self.parallel_engine.get_stats()
            self.logger.info(
                f"🎉 Parallel discovery completed: {final_stats['devices_discovered']} devices, "
                f"{final_stats['devices_failed']} failed, {final_stats['neighbors_found']} neighbors, "
                f"{final_stats['devices_per_second']:.1f} devices/sec, "
                f"{final_stats['connections_reused']} connection reuses"
            )
            
            # Get all devices from the session
            devices = []
            for device_obj in self.session.devices.all():
                device_data = {
                    'hostname': device_obj.hostname,
                    'ip_address': device_obj.ip_address,
                    'model': device_obj.model,
                    'platform': device_obj.platform,
                    'os_version': device_obj.os_version,
                    'serial_number': device_obj.serial_number,
                    'discovery_depth': device_obj.discovery_depth,
                    'connection_status': device_obj.connection_status,
                    'device_data': device_obj.device_data,
                    'discovered_at': device_obj.discovered_at
                }
                devices.append(device_data)
            
            return devices
            
        except Exception as e:
            import traceback
            error_traceback = traceback.format_exc()
            
            self.logger.error(f"Parallel discovery error: {e}")
            self.logger.error(f"Full traceback: {error_traceback}")
            
            # Update session with parallel discovery error details
            if self.session:
                if not self.session.progress_info:
                    self.session.progress_info = {}
                self.session.progress_info.update({
                    'parallel_discovery_error': str(e),
                    'parallel_error_traceback': error_traceback,
                    'parallel_error_at': timezone.now().isoformat(),
                    'error_source': 'parallel_discovery_engine'
                })
                self.session.save()
            
            if self.parallel_engine:
                self.parallel_engine.stop_discovery()
                
            # Log structured error for parallel discovery
            self.log_discovery_error('parallel_discovery', 'parallel_engine_error', str(e))
            
            raise

    def discover_single_device(self, ip: str, username: str, password: str, 
                             depth: int, end_time: float) -> Tuple[Optional[Dict], List[str]]:
        """
        Discover a single device and return its info plus neighbors.
        
        Args:
            ip: Device IP address
            username: SSH username
            password: SSH password
            depth: Current discovery depth
            end_time: Discovery timeout timestamp
            
        Returns:
            Tuple of (device_info_dict, neighbor_ip_list)
        """
        with self.lock:
            if ip in self.visited_ips:
                return None, []
            self.visited_ips.add(ip)
        
        if time.time() >= end_time:
            return None, []
        
        try:
            # Determine device type
            device_type = self.detect_device_type(ip)
            
            # Connection parameters - based on working old code
            device_conn = {
                'device_type': device_type,
                'ip': ip,
                'username': username,
                'password': password,
                'secret': password,  # Enable password
                'timeout': self.device_timeout,  # Use configurable device timeout
                'session_timeout': self.device_timeout * 2,  # Double for session
                'auth_timeout': min(30, self.device_timeout),  # Auth timeout capped at 30s
                'banner_timeout': 30,  # Increased for banner handling
                'global_delay_factor': 2,  # Important for slow devices
                'fast_cli': False,  # More reliable for older devices
                'ssh_strict': False,  # Auto-accept host keys
                'system_host_keys': False,  # Don't use system host keys
                'alt_host_keys': False,     # Don't use alt host keys
                'alt_key_file': '',
                'auto_connect': True,
                'allow_agent': False,
                'use_keys': False,
                'sock': None,
            }
            
            # Multiple connection attempts like the old code
            for attempt in range(3):
                try:
                    with ConnectHandler(**device_conn) as conn:
                        # Enter enable mode and setup terminal like old code
                        try:
                            conn.enable()
                        except:
                            pass  # Some devices don't need enable mode
                        
                        # Disable paging like old code
                        try:
                            conn.send_command('terminal length 0', delay_factor=1)
                        except:
                            try:
                                conn.send_command('terminal len 0', delay_factor=1)
                            except:
                                pass  # Some devices use different commands
                        
                        # Extract device information
                        device_info = self.extract_device_info(conn, ip, depth)
                        
                        # Get neighbor information
                        neighbors = self.get_device_neighbors(conn, device_type)
                        
                        return device_info, neighbors
                        
                except (NetmikoTimeoutException, NetmikoAuthenticationException) as e:
                    if attempt < 2:  # Retry up to 3 times
                        self.logger.debug(f"Attempt {attempt + 1} failed for {ip}, retrying: {str(e)}")
                        time.sleep(1)  # Wait before retry
                        continue
                    else:
                        raise e
                except Exception as e:
                    if attempt < 2:
                        self.logger.debug(f"Attempt {attempt + 1} failed for {ip}, retrying: {str(e)}")
                        time.sleep(1)
                        continue
                    else:
                        raise e
                
        except (NetmikoTimeoutException, NetmikoAuthenticationException, socket.timeout) as e:
            self.logger.debug(f"Connection failed for {ip}: {str(e)}")
            self.log_discovery_error(ip, "connection_failed", str(e))
            return {
                "hostname": f"unreachable-{ip}",
                "ip_address": ip,
                "status": f"connection_failed: {type(e).__name__}",
                "model": "unknown",
                "platform": "unknown",
                "discovery_depth": depth,
                "connection_status": "failed"
            }, []
            
        except Exception as e:
            self.logger.debug(f"Unexpected error discovering {ip}: {str(e)}")
            self.log_discovery_error(ip, "unexpected_error", str(e))
            return {
                "hostname": f"error-{ip}",
                "ip_address": ip,
                "status": f"error: {str(e)}",
                "model": "unknown",
                "platform": "unknown", 
                "discovery_depth": depth,
                "connection_status": "error"
            }, []

    def detect_device_type(self, ip: str) -> str:
        """
        Detect device type for netmiko connection.
        
        Args:
            ip: Device IP address
            
        Returns:
            Netmiko device type string
        """
        # Try to get hostname for device type detection like old code
        try:
            # Reverse DNS lookup to get hostname
            hostname = socket.gethostbyaddr(ip)[0].lower()
            
            # Device type detection based on hostname patterns from old code
            if any(pattern in hostname for pattern in ['aruba', 'hp', 'procurve']):
                return 'aruba_osswitch'
            elif any(pattern in hostname for pattern in ['nexus', 'nx-os']):
                return 'cisco_nxos'
            elif any(pattern in hostname for pattern in ['asa', 'firewall']):
                return 'cisco_asa'
            else:
                return 'cisco_ios'  # Default fallback
                
        except:
            # If hostname lookup fails, default to cisco_ios
            return 'cisco_ios'

    def extract_device_info(self, conn: ConnectHandler, ip: str, depth: int) -> Dict:
        """
        Extract device information from SSH connection.
        
        Args:
            conn: Netmiko connection object
            ip: Device IP address
            depth: Discovery depth
            
        Returns:
            Dictionary containing device information
        """
        device_info = {
            "ip_address": ip,
            "discovery_depth": depth,
            "connection_status": "connected"
        }
        
        try:
            # Detect if this is an Aruba device
            device_type = self.detect_device_type(ip)
            is_aruba = device_type == 'aruba_osswitch'
            
            # Get hostname - more robust approach
            try:
                if is_aruba:
                    # Aruba uses different commands
                    hostname_output = conn.send_command("show system info", delay_factor=10)
                    hostname_match = re.search(r'System Name\s*:\s*(\S+)', hostname_output)
                else:
                    hostname_output = conn.send_command("show running-config | include hostname", delay_factor=10)
                    hostname_match = re.search(r'hostname\s+(\S+)', hostname_output)
                
                if hostname_match:
                    device_info["hostname"] = hostname_match.group(1)
                else:
                    # Fallback to prompt-based hostname extraction
                    prompt = conn.find_prompt()
                    device_info["hostname"] = prompt.replace('#', '').replace('>', '') if prompt else f"device-{ip}"
            except:
                device_info["hostname"] = f"device-{ip}"
            
            # Get version information with device-specific commands
            if is_aruba:
                version_output = conn.send_command("show system info", delay_factor=10)
            else:
                version_output = conn.send_command("show version", delay_factor=10)
            
            # Store the raw version output and collect additional device information
            command_outputs = {"show_version": version_output}
            
            # Collect additional device information
            try:
                # Get interface information with device-specific commands and fallbacks
                interfaces_output = None
                if is_aruba:
                    # Aruba-specific interface commands
                    interface_commands = [
                        "show interfaces brief",
                        "show interface brief", 
                        "show interfaces",
                        "show ports"
                    ]
                else:
                    # Cisco and other vendor interface commands
                    interface_commands = [
                        "show ip interface brief",
                        "show interfaces brief", 
                        "show interface brief",
                        "show interfaces status",
                        "show interfaces"
                    ]
                
                for cmd in interface_commands:
                    try:
                        interfaces_output = conn.send_command(cmd, delay_factor=10)
                        if interfaces_output and "% Invalid input" not in interfaces_output and "Invalid" not in interfaces_output:
                            command_outputs["show_interfaces"] = interfaces_output
                            command_outputs["interfaces_command_used"] = cmd  # Track which command worked
                            break
                    except Exception as cmd_error:
                        self.logger.debug(f"Interface command '{cmd}' failed on {ip}: {str(cmd_error)}")
                        continue
                        
                if not interfaces_output or "% Invalid input" in interfaces_output:
                    self.logger.debug(f"All interface commands failed on {ip}")
                    
            except Exception as e:
                self.logger.debug(f"Error getting interface information from {ip}: {str(e)}")
                pass
            
            try:
                # Get inventory information with fallback commands
                if not is_aruba:
                    inventory_commands = [
                        "show inventory",
                        "show module",
                        "show hardware",
                        "show chassis"
                    ]
                    
                    for cmd in inventory_commands:
                        try:
                            inventory_output = conn.send_command(cmd, delay_factor=10)
                            if inventory_output and "% Invalid input" not in inventory_output and "Invalid" not in inventory_output:
                                command_outputs["show_inventory"] = inventory_output
                                command_outputs["inventory_command_used"] = cmd  # Track which command worked
                                break
                        except Exception as cmd_error:
                            self.logger.debug(f"Inventory command '{cmd}' failed on {ip}: {str(cmd_error)}")
                            continue
            except Exception as e:
                self.logger.debug(f"Error getting inventory information from {ip}: {str(e)}")
                pass
            
            try:
                # Get running config hostname section with fallback commands
                config_commands = []
                if is_aruba:
                    config_commands = [
                        "show running-config",
                        "show config",
                        "show configuration"
                    ]
                else:
                    config_commands = [
                        "show running-config | section hostname",
                        "show running-config | include hostname",
                        "show running-config | begin hostname",
                        "show running-config"
                    ]
                
                for cmd in config_commands:
                    try:
                        config_output = conn.send_command(cmd, delay_factor=10)
                        if config_output and "% Invalid input" not in config_output and "Invalid" not in config_output:
                            command_outputs["show_config_hostname"] = config_output
                            command_outputs["config_command_used"] = cmd  # Track which command worked
                            break
                    except Exception as cmd_error:
                        self.logger.debug(f"Config command '{cmd}' failed on {ip}: {str(cmd_error)}")
                        continue
                        
            except Exception as e:
                self.logger.debug(f"Error getting config information from {ip}: {str(e)}")
                pass
            
            # Store comprehensive device data including interface analysis
            device_info["device_data"] = {
                "raw_version_output": version_output,
                "show_version": version_output,  # For compatibility
                "command_outputs": command_outputs,
                "device_type": device_type,
                "is_aruba": is_aruba,
                "discovery_timestamp": datetime.now().isoformat()
            }
            
            # Include interface analysis in device_data if it exists
            if "interface_analysis" in device_info:
                device_info["device_data"]["interface_analysis"] = device_info["interface_analysis"]
            if "interfaces" in device_info:
                device_info["device_data"]["interfaces"] = device_info["interfaces"]
            
            # Perform comprehensive interface analysis
            try:
                self.logger.info(f"Performing interface analysis for {device_info.get('hostname', ip)}")
                interface_analysis = self._analyze_device_interfaces_parallel(conn, device_info, device_type)
                device_info["interface_analysis"] = interface_analysis
                
                # Add port count summary to main device info for easy access
                port_counts = interface_analysis.get('port_counts', {})
                device_info["total_ports"] = port_counts.get('total_ports', 0)
                device_info["ethernet_ports"] = port_counts.get('ethernet_ports', 0)
                device_info["active_ports"] = interface_analysis.get('interface_status', {}).get('up', 0)
                
                # Also add interface details and neighbors to top level for frontend access
                device_info["interfaces"] = interface_analysis.get('interfaces', [])
                device_info["neighbors"] = device_info.get('neighbor_info', [])
                
                # Ensure neighbors are also stored in device_data
                device_info["device_data"]["neighbors"] = device_info.get('neighbor_info', [])
                
                self.logger.info(
                    f"Interface analysis completed for {device_info.get('hostname', ip)}: "
                    f"{device_info['total_ports']} total ports, "
                    f"{device_info['ethernet_ports']} ethernet ports, "
                    f"{device_info['active_ports']} active"
                )
                
                # Log structured interface analysis summary
                self.log_interface_analysis_summary(
                    device_info.get('hostname', 'unknown'), 
                    ip, 
                    interface_analysis
                )
                
            except Exception as e:
                self.logger.warning(f"Interface analysis failed for {ip}: {str(e)}")
                # Still include basic info even if interface analysis fails
                device_info["interface_analysis"] = {"error": str(e), "analysis_failed": True}
            
            # Extract model with device-specific patterns
            if is_aruba:
                model_patterns = [
                    r'Product Name\s*:\s*(.+?)(?:\n|$)',
                    r'Hardware:\s*(\S+)',
                    r'Model:\s*(\S+)',
                ]
            else:
                model_patterns = [
                    r'cisco\s+(\S+)\s+\(',
                    r'Model number\s*:\s*(\S+)',
                    r'Hardware:\s*(\S+)',
                    r'Product Name:\s*(.+?)(?:\n|$)',
                ]
            
            for pattern in model_patterns:
                model_match = re.search(pattern, version_output, re.IGNORECASE)
                if model_match:
                    device_info["model"] = model_match.group(1).strip()
                    break
            else:
                device_info["model"] = "unknown"
            
            # Extract platform/vendor using centralized robust detection
            detected_platform = detect_platform_from_output(version_output, is_aruba, self.logger)
            device_info["platform"] = detected_platform
            
            # Validate platform exists in Nautobot and has proper configuration
            platform_obj = get_or_create_platform(detected_platform)
            if platform_obj:
                device_info['platform_validated'] = True
                device_info['nautobot_platform'] = platform_obj.name
                device_info['napalm_driver'] = platform_obj.napalm_driver
            else:
                device_info['platform_validated'] = False
            
            # Extract OS version with device-specific patterns
            if is_aruba:
                version_patterns = [
                    r'Software revision\s*:\s*([^\s,\n]+)',
                    r'Version\s+([^\s,]+)',
                    r'Software Version\s+([^\s,]+)',
                ]
            else:
                version_patterns = [
                    r'Version\s+([^\s,]+)',
                    r'Software Version\s+([^\s,]+)',
                    r'IOS.*Version\s+([^\s,]+)',
                ]
            
            for pattern in version_patterns:
                version_match = re.search(pattern, version_output, re.IGNORECASE)
                if version_match:
                    device_info["os_version"] = version_match.group(1)
                    break
            else:
                device_info["os_version"] = "unknown"
            
            # Extract serial number with device-specific patterns
            if is_aruba:
                # For Aruba, need to get serial from show modules
                try:
                    modules_output = conn.send_command("show modules", delay_factor=10)
                    serial_match = re.search(r'Serial Number:\s*(\S+)', modules_output)
                    if serial_match:
                        device_info["serial_number"] = serial_match.group(1)
                    else:
                        device_info["serial_number"] = "unknown"
                except:
                    device_info["serial_number"] = "unknown"
            else:
                serial_patterns = [
                    r'Processor board ID\s+(\S+)',
                    r'System Serial Number\s*:\s*(\S+)',
                    r'Serial Number\s*:\s*(\S+)',
                ]
                
                for pattern in serial_patterns:
                    serial_match = re.search(pattern, version_output, re.IGNORECASE)
                    if serial_match:
                        device_info["serial_number"] = serial_match.group(1)
                        break
                else:
                    device_info["serial_number"] = "unknown"
            
            device_info["status"] = "discovered"
            
            # Log successful device discovery completion
            self.log_device_discovery_complete(device_info)
            
        except Exception as e:
            self.logger.debug(f"Error extracting device info from {ip}: {str(e)}")
            self.log_discovery_error(ip, "info_extraction_failed", str(e), device_info.get('hostname'))
            device_info.update({
                "hostname": f"partial-{ip}",
                "model": "unknown",
                "platform": "unknown",
                "os_version": "unknown",
                "serial_number": "unknown",
                "status": f"partial_info: {str(e)}"
            })
        
        return device_info

    def get_device_neighbors(self, conn: ConnectHandler, device_type: str) -> List[str]:
        """
        Get neighboring device IP addresses via CDP/LLDP only.
        
        This method discovers only directly connected network infrastructure devices
        by using network discovery protocols (CDP/LLDP). ARP table lookup is 
        intentionally excluded as it would include end-user devices, servers, 
        and other non-infrastructure equipment.
        
        Args:
            conn: Netmiko connection object
            device_type: Device type string
            
        Returns:
            List of neighbor IP addresses from network infrastructure devices
        """
        neighbors = []
        current_device_ip = getattr(conn, 'host', 'unknown')
        
        self.neighbor_logger.info(f"Starting neighbor discovery for device {current_device_ip} (type: {device_type})")
        
        try:
            # Try CDP first (Cisco Discovery Protocol)
            cdp_neighbors = self._discover_cdp_neighbors_safe(conn, current_device_ip)
            neighbors.extend(cdp_neighbors)
            
            # Try LLDP (Link Layer Discovery Protocol - more universal)
            lldp_neighbors = self._discover_lldp_neighbors_safe(conn, current_device_ip)
            neighbors.extend(lldp_neighbors)
            
            # Remove duplicates and filter valid IPs
            neighbors = list(set([ip for ip in neighbors if self.is_valid_ip(ip)]))
            
            # Enhanced logging with device type filtering information
            total_raw = len(cdp_neighbors) + len(lldp_neighbors)
            total_filtered = len(neighbors)
            filtering_info = ""
            if total_raw > 0:
                filtered_percentage = (total_filtered / total_raw) * 100
                filtering_info = f" | Raw: {total_raw} (CDP: {len(cdp_neighbors)}, LLDP: {len(lldp_neighbors)}) | Filtered: {total_filtered} ({filtered_percentage:.1f}%)"
            
            self.neighbor_logger.info(
                f"Device {current_device_ip}: Found {len(neighbors)} network neighbors: {neighbors}{filtering_info}"
            )
            
            # Log filtering information to main log as well
            if filtering_info:
                self.logger.info(f"NEIGHBOR_FILTERING | {current_device_ip}: {filtering_info}")
            
        except Exception as e:
            self.neighbor_logger.error(f"Error getting neighbors for {current_device_ip}: {str(e)}")
            self.logger.debug(f"Error getting neighbors: {str(e)}")
        
        return neighbors
    
    
    def is_valid_ip(self, ip: str) -> bool:
        """
        Validate IP address format and exclude private/reserved ranges if needed.
        
        Args:
            ip: IP address string
            
        Returns:
            True if valid IP address
        """
        try:
            socket.inet_aton(ip)
            # Exclude loopback and broadcast
            if ip.startswith('127.') or ip.endswith('.255') or ip.endswith('.0'):
                return False
            return True
        except socket.error:
            return False
    
    # Removed is_likely_infrastructure_ip method as we no longer use ARP discovery


# Register the job
jobs = [NetworkInventoryDiscoveryJob]
