# Generated for parallel discovery enhancements

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('nautobot_inventory', '0004_discovereddevice_custom_credentials'),
    ]

    operations = [
        migrations.AddField(
            model_name='discovereddevice',
            name='parent_device',
            field=models.CharField(blank=True, help_text='IP address of the parent device that discovered this device', max_length=45, null=True),
        ),
        migrations.AddField(
            model_name='discovereddevice',
            name='discovered_via',
            field=models.CharField(blank=True, choices=[('root', 'Root Device'), ('cdp', 'CDP Discovery'), ('lldp', 'LLDP Discovery'), ('arp', 'ARP Discovery'), ('manual', 'Manual Entry')], default='unknown', help_text='Method used to discover this device', max_length=20),
        ),
        migrations.AddField(
            model_name='inventorydiscoverysession',
            name='parallel_stats',
            field=models.JSONField(blank=True, default=dict, help_text='Statistics from parallel discovery engine'),
        ),
        migrations.AddField(
            model_name='inventorydiscoverysession',
            name='max_workers',
            field=models.PositiveIntegerField(default=50, help_text='Number of parallel workers used for this session'),
        ),
        migrations.AddIndex(
            model_name='discovereddevice',
            index=models.Index(fields=['parent_device'], name='nautobot_in_parent__a85c2d_idx'),
        ),
        migrations.AddIndex(
            model_name='discovereddevice',
            index=models.Index(fields=['discovered_via'], name='nautobot_in_discove_4b8e1f_idx'),
        ),
        migrations.AddIndex(
            model_name='discovereddevice',
            index=models.Index(fields=['discovery_depth', 'connection_status'], name='nautobot_in_discove_2a3f4c_idx'),
        ),
    ]
