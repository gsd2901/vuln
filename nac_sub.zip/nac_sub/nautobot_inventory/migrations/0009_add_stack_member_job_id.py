# Generated manually for adding stack_member_job_id field

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('nautobot_inventory', '0008_discovereddevice_network_data_retry_count'),
    ]

    operations = [
        migrations.AddField(
            model_name='discovereddevice',
            name='stack_member_job_id',
            field=models.CharField(
                blank=True,
                help_text="Status of stack member creation (e.g., 'stack_created_2_members')",
                max_length=200,
                null=True
            ),
        ),
    ]

