"""
Device validation utilities for network inventory discovery.

This module provides utilities for validating device creation and lookup
in Nautobot after onboarding operations.
"""

import logging
from typing import Optional, List, Dict, Any
from django.utils import timezone
from django.db.models import Q
from datetime import timedelta

from nautobot.dcim.models import Device, Interface
from nautobot.ipam.models import IPAddress
from nautobot.dcim.models import Location
from .error_handler import DeviceInfoErrorHandler


class DeviceValidationUtils:
    """Utilities for validating device creation and lookup in Nautobot."""
    
    def __init__(self, logger_name: str = 'nautobot_inventory.device_validation'):
        self.logger = logging.getLogger(logger_name)
        self.error_handler = DeviceInfoErrorHandler(logger_name)
    
    def validate_bulk_devices_created(self, device_ips: List[str], hostnames: Optional[List[str]] = None, 
                                    session_location: Optional[str] = None) -> Dict[str, Any]:
        """
        Validate that multiple devices were actually created in Nautobot after bulk onboarding.
        Optimized to avoid N+1 query problems by using bulk database operations.
        
        Args:
            device_ips: List of IP addresses of the devices to validate
            hostnames: List of hostnames of the devices (optional)
            session_location: Location name from the session (optional)
            
        Returns:
            Dictionary with bulk validation result and device info
        """
        from nautobot.dcim.models import Device, Location
        from nautobot.ipam.models import IPAddress
        from django.db.models import Q
        
        validation_result = {
            'is_valid': False,
            'total_devices': len(device_ips),
            'successful_devices': 0,
            'failed_devices': 0,
            'device_results': {},
            'summary': {}
        }
        
        try:
            self.logger.info(f"Validating bulk device creation for {len(device_ips)} devices")
            
            # Build hostname list for validation
            hostname_list = hostnames if hostnames else [None] * len(device_ips)
            
            # Bulk query for devices by primary IP
            devices_by_primary_ip = {}
            primary_ip_devices = Device.objects.filter(
                primary_ip4__host__in=device_ips
            ).select_related('primary_ip4', 'location', 'device_type', 'device_role').prefetch_related('interfaces__ip_addresses')
            
            for device in primary_ip_devices:
                if device.primary_ip4:
                    devices_by_primary_ip[device.primary_ip4.host] = device
            
            # Bulk query for devices by interface IP (for devices not found by primary IP)
            remaining_ips = [ip for ip in device_ips if ip not in devices_by_primary_ip]
            devices_by_interface_ip = {}
            
            if remaining_ips:
                interface_ip_devices = Device.objects.filter(
                    interfaces__ip_addresses__host__in=remaining_ips
                ).select_related('primary_ip4', 'location', 'device_type', 'device_role').prefetch_related('interfaces__ip_addresses').distinct()
                
                for device in interface_ip_devices:
                    for interface in device.interfaces.all():
                        for ip_addr in interface.ip_addresses.all():
                            if ip_addr.host in remaining_ips and ip_addr.host not in devices_by_interface_ip:
                                devices_by_interface_ip[ip_addr.host] = device
            
            # Bulk query for devices by hostname (for additional validation)
            devices_by_hostname = {}
            valid_hostnames = [h for h in hostname_list if h and h not in ['unknown', '']]
            
            if valid_hostnames:
                hostname_devices = Device.objects.filter(
                    name__in=valid_hostnames
                ).select_related('primary_ip4', 'location', 'device_type', 'device_role')
                
                for device in hostname_devices:
                    devices_by_hostname[device.name] = device
            
            # Get location for validation if provided
            location_obj = None
            if session_location:
                try:
                    location_obj = Location.objects.get(name=session_location)
                except Location.DoesNotExist:
                    self.logger.warning(f"Session location '{session_location}' not found for validation")
            
            # Process validation results for each device
            for i, device_ip in enumerate(device_ips):
                hostname = hostname_list[i] if i < len(hostname_list) else None
                
                # Find device using the bulk-queried data
                found_device = None
                validation_method = None
                
                # Check primary IP first
                if device_ip in devices_by_primary_ip:
                    found_device = devices_by_primary_ip[device_ip]
                    validation_method = 'primary_ip'
                # Check interface IP
                elif device_ip in devices_by_interface_ip:
                    found_device = devices_by_interface_ip[device_ip]
                    validation_method = 'interface_ip'
                # Check hostname if available
                elif hostname and hostname in devices_by_hostname:
                    found_device = devices_by_hostname[hostname]
                    validation_method = 'hostname'
                
                # Build validation result for this device
                device_result = self._build_device_validation_result(
                    device_ip, hostname, found_device, location_obj, validation_method
                )
                
                validation_result['device_results'][device_ip] = device_result
                
                if device_result['is_valid']:
                    validation_result['successful_devices'] += 1
                else:
                    validation_result['failed_devices'] += 1
            
            # Calculate overall success
            validation_result['is_valid'] = validation_result['successful_devices'] > 0
            validation_result['success_rate'] = (
                validation_result['successful_devices'] / validation_result['total_devices']
            ) * 100
            
            # Create summary
            validation_result['summary'] = {
                'total': validation_result['total_devices'],
                'successful': validation_result['successful_devices'],
                'failed': validation_result['failed_devices'],
                'success_rate': f"{validation_result['success_rate']:.1f}%"
            }
            
            self.logger.info(
                f"Bulk validation complete: {validation_result['successful_devices']}/{validation_result['total_devices']} "
                f"devices validated successfully ({validation_result['success_rate']:.1f}%)"
            )
            
        except Exception as e:
            error_info = self.error_handler.handle_device_info_error(
                e, f"bulk validation for {len(device_ips)} devices", "bulk_device_validation"
            )
            validation_result['error'] = str(e)
            self.logger.error(f"Error validating bulk device creation: {e}")
        
        return validation_result
    
    def _build_device_validation_result(self, device_ip: str, hostname: Optional[str], 
                                      found_device, location_obj, validation_method: Optional[str]) -> Dict[str, Any]:
        """
        Build validation result for a single device using pre-fetched data.
        
        Args:
            device_ip: IP address of the device
            hostname: Hostname of the device (optional)
            found_device: Device object if found, None otherwise
            location_obj: Location object for validation (optional)
            validation_method: Method used to find the device
            
        Returns:
            Dictionary with device validation result
        """
        if not found_device:
            return {
                'is_valid': False,
                'device_ip': device_ip,
                'hostname': hostname,
                'error': 'Device not found in Nautobot',
                'validation_method': None
            }
        
        # Build device info
        device_info = {
            'id': str(found_device.id),
            'name': found_device.name,
            'device_type': found_device.device_type.model if found_device.device_type else 'Unknown',
            'device_role': found_device.device_role.name if found_device.device_role else 'Unknown',
            'location': found_device.location.name if found_device.location else 'Unknown',
            'primary_ip': found_device.primary_ip4.host if found_device.primary_ip4 else None,
            'validation_method': validation_method
        }
        
        # Validate location if provided
        location_match = True
        if location_obj and found_device.location:
            location_match = found_device.location.id == location_obj.id
            if not location_match:
                device_info['location_mismatch'] = {
                    'expected': location_obj.name,
                    'actual': found_device.location.name
                }
        
        return {
            'is_valid': True,
            'device_ip': device_ip,
            'hostname': hostname,
            'device_info': device_info,
            'location_match': location_match,
            'validation_method': validation_method
        }

    def validate_device_created(self, device_ip: str, hostname: Optional[str] = None, 
                             session_location: Optional[str] = None) -> Dict[str, Any]:
        """
        Validate that a device was actually created in Nautobot after onboarding.
        
        Args:
            device_ip: IP address of the device to validate
            hostname: Hostname of the device (optional)
            session_location: Location name from the session (optional)
            
        Returns:
            Dictionary with validation result and device info
        """
        validation_result = {
            'is_valid': False,
            'device': None,
            'method_used': None,
            'error': None
        }
        
        try:
            self.logger.info(f"Validating device creation for {device_ip}")
            
            # Try multiple lookup methods in order of reliability
            lookup_methods = [
                self._lookup_by_primary_ip,
                self._lookup_by_interface_ip,
                self._lookup_by_hostname,
                self._lookup_by_ip_object,
                self._lookup_by_recent_creation,
                self._lookup_by_location_pattern
            ]
            
            for method in lookup_methods:
                try:
                    device = method(device_ip, hostname, session_location)
                    if device:
                        validation_result.update({
                            'is_valid': True,
                            'device': device,
                            'method_used': method.__name__
                        })
                        self.logger.info(f"Device found using {method.__name__}: {device.name}")
                        return validation_result
                except Exception as e:
                    self.logger.warning(f"Lookup method {method.__name__} failed: {e}")
                    continue
            
            self.logger.error(f"Device not found in Nautobot for IP {device_ip}")
            validation_result['error'] = f"Device not found using any lookup method"
            
        except Exception as e:
            error_info = self.error_handler.handle_device_info_error(
                e, device_ip, "device_validation"
            )
            validation_result['error'] = str(e)
            self.logger.error(f"Error validating device creation for {device_ip}: {e}")
        
        return validation_result
    
    def _lookup_by_primary_ip(self, device_ip: str, hostname: Optional[str] = None, 
                            session_location: Optional[str] = None) -> Optional[Device]:
        """Look up device by primary IP address."""
        try:
            # Try IPv4 first, then IPv6
            device = Device.objects.filter(
                primary_ip4__host__net_host=device_ip
            ).first()
            if device:
                return device
            # Try IPv6
            device = Device.objects.filter(
                primary_ip6__host__net_host=device_ip
            ).first()
            return device
        except Exception as e:
            self.logger.warning(f"Primary IP lookup failed for {device_ip}: {e}")
            return None
    
    def _lookup_by_interface_ip(self, device_ip: str, hostname: Optional[str] = None, 
                               session_location: Optional[str] = None) -> Optional[Device]:
        """Look up device by interface IP addresses."""
        try:
            device = Device.objects.filter(
                interfaces__ip_addresses__host__net_host=device_ip
            ).distinct().first()
            return device
        except Exception as e:
            self.logger.warning(f"Interface IP lookup failed for {device_ip}: {e}")
            return None
    
    def _lookup_by_hostname(self, device_ip: str, hostname: Optional[str] = None, 
                           session_location: Optional[str] = None) -> Optional[Device]:
        """Look up device by hostname."""
        if not hostname or hostname.startswith(('unreachable-', 'failed-', 'error-', 'retrying-')):
            return None
        
        try:
            device = Device.objects.filter(name=hostname).first()
            return device
        except Exception as e:
            self.logger.warning(f"Hostname lookup failed for {device_ip}: {e}")
            return None
    
    def _lookup_by_ip_object(self, device_ip: str, hostname: Optional[str] = None, 
                            session_location: Optional[str] = None) -> Optional[Device]:
        """Look up device by IP address object."""
        try:
            matching_ips = IPAddress.objects.filter(host__net_host=device_ip)
            for ip_obj in matching_ips:
                # Check if IP is assigned to any interface on a device
                device = Device.objects.filter(
                    interfaces__ip_addresses=ip_obj
                ).distinct().first()
                if device:
                    return device
                # Also check if it's a primary IP
                device = Device.objects.filter(
                    Q(primary_ip4=ip_obj) | Q(primary_ip6=ip_obj)
                ).first()
                if device:
                    return device
            return None
        except Exception as e:
            self.logger.warning(f"IP object lookup failed for {device_ip}: {e}")
            return None
    
    def _lookup_by_recent_creation(self, device_ip: str, hostname: Optional[str] = None, 
                                  session_location: Optional[str] = None) -> Optional[Device]:
        """Look up device by recent creation time."""
        try:
            recent_time = timezone.now() - timedelta(minutes=10)
            search_name = hostname if hostname else 'switch'
            
            device = Device.objects.filter(
                created__gte=recent_time,
                name__icontains=search_name
            ).first()
            return device
        except Exception as e:
            self.logger.warning(f"Recent creation lookup failed for {device_ip}: {e}")
            return None
    
    def _lookup_by_location_pattern(self, device_ip: str, hostname: Optional[str] = None, 
                                   session_location: Optional[str] = None) -> Optional[Device]:
        """Look up device by location and name pattern."""
        if not session_location:
            return None
        
        try:
            location_obj = Location.objects.filter(name=session_location).first()
            if location_obj:
                device = Device.objects.filter(
                    location=location_obj,
                    name__icontains='switch'  # Based on typical device naming
                ).first()
                return device
            return None
        except Exception as e:
            self.logger.warning(f"Location-based lookup failed for {device_ip}: {e}")
            return None
    
    def get_device_lookup_methods(self) -> List[str]:
        """Get list of available device lookup methods."""
        return [
            'primary_ip',
            'interface_ip', 
            'hostname',
            'ip_object',
            'recent_creation',
            'location_pattern'
        ]
    
    def create_device_batches(self, device_list: List[Dict[str, Any]], batch_size: int = 50) -> List[List[Dict[str, Any]]]:
        """
        Split a list of devices into batches for bulk processing.
        
        Args:
            device_list: List of device dictionaries
            batch_size: Maximum number of devices per batch
            
        Returns:
            List of device batches
        """
        batches = []
        for i in range(0, len(device_list), batch_size):
            batch = device_list[i:i + batch_size]
            batches.append(batch)
            
        self.logger.info(f"Created {len(batches)} batches from {len(device_list)} devices (max {batch_size} per batch)")
        return batches
    
    def get_bulk_validation_summary(self, validation_results: List[Dict[str, Any]]) -> Dict[str, Any]:
        """
        Create a summary of multiple bulk validation results.
        
        Args:
            validation_results: List of bulk validation result dictionaries
            
        Returns:
            Summary dictionary with aggregated results
        """
        summary = {
            'total_batches': len(validation_results),
            'total_devices': 0,
            'successful_devices': 0,
            'failed_devices': 0,
            'batch_summaries': []
        }
        
        for i, result in enumerate(validation_results):
            summary['total_devices'] += result.get('total_devices', 0)
            summary['successful_devices'] += result.get('successful_devices', 0)
            summary['failed_devices'] += result.get('failed_devices', 0)
            
            batch_summary = {
                'batch_number': i + 1,
                'devices': result.get('total_devices', 0),
                'successful': result.get('successful_devices', 0),
                'failed': result.get('failed_devices', 0),
                'success_rate': result.get('success_rate', 0)
            }
            summary['batch_summaries'].append(batch_summary)
        
        # Calculate overall success rate
        if summary['total_devices'] > 0:
            summary['overall_success_rate'] = (
                summary['successful_devices'] / summary['total_devices']
            ) * 100
        else:
            summary['overall_success_rate'] = 0
            
        return summary
