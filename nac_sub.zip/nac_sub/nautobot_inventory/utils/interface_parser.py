"""
Interface and neighbor parsing utilities for network device discovery.

This module provides reusable parsers for interface information, trunk ports,
and neighbor details to avoid code duplication across views and jobs.
"""

import re
import logging
from typing import Dict, List, Tuple, Optional, Set
from datetime import datetime

logger = logging.getLogger(__name__)


class InterfaceParser:
    """Parser for network device interface information."""
    
    @staticmethod
    def filter_physical_interfaces(interfaces: List[Dict]) -> List[Dict]:
        """
        Filter interfaces to only include physical switchports, excluding virtual/logical ones and management interfaces.
        
        For Cisco switches, this focuses on the actual switchports (e.g., GigabitEthernet1/0/1-48 for a 48-port switch)
        and excludes management interfaces, uplink modules, and special interfaces.
        
        Args:
            interfaces: List of interface dictionaries
            
        Returns:
            List of physical switchport dictionaries only
        """
        if not interfaces or not isinstance(interfaces, list):
            return []
        
        physical_interfaces = []
        
        # Define virtual/logical interface prefixes to exclude
        virtual_prefixes = [
            'vlan',           # VLAN interfaces
            'loopback',       # Loopback interfaces
            'lo',             # Loopback (short form)
            'tunnel',         # Tunnel interfaces
            'null',           # Null interfaces
            'mgmt',           # Management interfaces (often virtual)
            'management',     # Management interfaces
            'port-channel',   # Port channels/LAG
            'lag',            # Link aggregation
            'bond',           # Bonded interfaces
            'bridge',         # Bridge interfaces
            'br',             # Bridge (short form)
            'virtual',        # Virtual interfaces
            'veth',           # Virtual ethernet
            'tap',            # TAP interfaces
            'tun',            # TUN interfaces
            'dummy',          # Dummy interfaces
            'sit',            # IPv6-in-IPv4 tunnel
            'gre',            # GRE tunnel
            'ipip',           # IP-in-IP tunnel
            'ppp',            # PPP interfaces
            'slip',           # SLIP interfaces
            'serial',         # Serial interfaces (often logical)
            'dialer',         # Dialer interfaces
            'bvi',            # Bridge Virtual Interface
            'svi',            # Switch Virtual Interface
            'irb',            # Integrated Routing and Bridging
            'vti',            # Virtual Tunnel Interface
            'nve',            # Network Virtualization Endpoint
            'vtep'            # VXLAN Tunnel Endpoint
        ]
        
        # Define interfaces to exclude for accurate switchport counting
        excluded_interface_prefixes = [
            'gigabitethernet0/',      # Management interface (Gi0/0)
            'ap',                     # Application hosting ports
            'bluetooth',              # Bluetooth interfaces
            'twentyfivegige',         # 25G uplink modules
            'fortygige',              # 40G uplink modules  
            'fo',                     # FortyGigabitEthernet short form
            'hundredgige',            # 100G uplink modules
            'fourhundredgige',        # 400G uplink modules
        ]
        
        # Define physical switchport prefixes to include
        physical_prefixes = [
            'gigabitethernet',    # Cisco GigE
            'gige',               # GigE short form
            'gi',                 # GigE very short form
            'fastethernet',       # Cisco FastEthernet
            'fa',                 # FastEthernet short form
            'ethernet',           # Generic Ethernet
            'eth',                # Ethernet short form
            'tengigabitethernet', # 10 GigE
            'te',                 # 10 GigE short form
            'xe',                 # 10 GigE (Juniper)
            'ge-',                # Juniper GigE
            'fe-',                # Juniper FastEthernet
            'et-',                # Juniper 10/40/100 GigE
            'swp',                # Switch port (Cumulus)
            'ens',                # Ethernet network segment
            'enp',                # Ethernet network PCI
            'eno',                # Ethernet network onboard
            'em',                 # Ethernet em (FreeBSD)
            'igb',                # Intel Gigabit
            'ixgbe',              # Intel 10 Gigabit
            'e1000',              # Intel Ethernet
            'vmnic',              # VMware physical NIC
            'uplink'              # Uplink ports
        ]
        
        for interface in interfaces:
            if not isinstance(interface, dict) or not interface.get('name'):
                continue
                
            interface_name = interface['name'].lower()
            
            # Check if interface name starts with any virtual prefix
            is_virtual = any(interface_name.startswith(prefix) for prefix in virtual_prefixes)
            
            # Special case: Check for Port-channel (Po) more precisely
            # Po1, Po2, etc. are virtual, but port1/1 is physical
            if interface_name.startswith('po') and re.match(r'^po\d+$', interface_name):
                is_virtual = True
            
            if is_virtual:
                continue
            
            # Check if interface should be excluded (management, uplink modules, special interfaces)
            is_excluded = any(interface_name.startswith(prefix) for prefix in excluded_interface_prefixes)
            if is_excluded:
                continue
            
            # For Cisco switches, exclude uplink module interfaces (1/1/x pattern for modules)
            # Only include main switchports (1/0/x pattern)
            if re.match(r'^(gi|gigabitethernet|te|tengigabitethernet)\d+/1/\d+', interface_name):
                # This is an uplink module interface, exclude it
                continue
            
            # Check if interface name starts with any physical prefix
            is_physical = any(interface_name.startswith(prefix) for prefix in physical_prefixes)
            if is_physical:
                physical_interfaces.append(interface)
                continue
            
            # For unknown interface types, use additional heuristics
            # Include interfaces with numeric patterns that suggest physical ports
            if re.match(r'^[a-z]+\d+\/0\/\d+', interface_name):  # e.g., "gi1/0/1" - main switchports
                physical_interfaces.append(interface)
                continue
                
            # Include simple numeric interfaces (e.g., "1", "2", "3")
            if re.match(r'^\d+$', interface_name):
                physical_interfaces.append(interface)
                continue
            
            # Default to excluding unknown interface types to be conservative
            logger.debug(f"Excluding unknown interface type: {interface['name']}")
        
        logger.info(f"Filtered {len(interfaces)} interfaces to {len(physical_interfaces)} physical switchports")
        return physical_interfaces
    
    @staticmethod
    def parse_trunk_ports(conn, device_type: str = 'cisco_ios', is_switch: bool = True) -> Dict:
        """
        Parse trunk port information from device.
        
        Args:
            conn: Netmiko connection object
            device_type: Device type string
            is_switch: Whether the device is a switch (default True for backward compatibility)
            
        Returns:
            Dictionary with trunk port details
        """
        trunk_info = {
            'trunk_ports': [],
            'trunk_count': 0,
            'access_ports': [],
            'access_count': 0,
            'trunk_details': {}
        }
        
        # Skip trunk parsing for routers - trunk commands are switch-specific
        if not is_switch:
            logger.debug("Device identified as router, skipping trunk port parsing (switch-only feature)")
            return trunk_info
        
        try:
            is_aruba = 'aruba' in device_type.lower()
            
            if is_aruba:
                # Aruba trunk commands
                trunk_commands = [
                    'show trunks',
                    'show interface trunk',
                    'show lacp'
                ]
            else:
                # Cisco trunk commands
                trunk_commands = [
                    'show interfaces trunk',
                    'show interface switchport'
                ]
            
            trunk_output = None
            for cmd in trunk_commands:
                try:
                    trunk_output = conn.send_command(cmd, delay_factor=1)
                    if trunk_output and 'invalid' not in trunk_output.lower():
                        break
                except Exception as e:
                    logger.debug(f"Trunk command '{cmd}' failed: {e}")
                    continue
            
            if trunk_output:
                if is_aruba:
                    trunk_info = InterfaceParser._parse_aruba_trunks(trunk_output)
                else:
                    trunk_info = InterfaceParser._parse_cisco_trunks(trunk_output, conn)
                    
        except Exception as e:
            logger.error(f"Error parsing trunk ports: {e}")
            
        return trunk_info
    
    @staticmethod
    def _parse_cisco_trunks(trunk_output: str, conn) -> Dict:
        """Parse Cisco trunk port information."""
        trunk_info = {
            'trunk_ports': [],
            'trunk_count': 0,
            'access_ports': [],
            'access_count': 0,
            'trunk_details': {}
        }
        
        try:
            # Parse 'show interfaces trunk' output
            lines = trunk_output.split('\n')
            in_trunk_section = False
            
            for line in lines:
                line = line.strip()
                
                # Detect trunk section headers
                if 'Port' in line and 'Mode' in line:
                    in_trunk_section = True
                    continue
                elif line.startswith('---'):
                    continue
                elif not line or line.startswith('Port'):
                    continue
                    
                if in_trunk_section:
                    # Parse trunk port lines
                    parts = line.split()
                    if len(parts) >= 2:
                        interface = parts[0]
                        
                        # Basic trunk detection
                        if interface and not interface.startswith('---'):
                            trunk_info['trunk_ports'].append(interface)
                            trunk_info['trunk_details'][interface] = {
                                'mode': 'trunk',
                                'native_vlan': 'unknown',
                                'allowed_vlans': 'unknown'
                            }
            
            # Get detailed switchport information for each interface
            try:
                switchport_output = conn.send_command('show interfaces switchport', delay_factor=2)
                trunk_info = InterfaceParser._parse_switchport_details(switchport_output, trunk_info)
            except Exception as e:
                logger.debug(f"Failed to get detailed switchport info: {e}")
            
            trunk_info['trunk_count'] = len(trunk_info['trunk_ports'])
            
        except Exception as e:
            logger.error(f"Error parsing Cisco trunk output: {e}")
            
        return trunk_info
    
    @staticmethod
    def _parse_switchport_details(switchport_output: str, trunk_info: Dict) -> Dict:
        """Parse detailed switchport information."""
        try:
            # Split by interface sections
            interface_sections = re.split(r'Name:', switchport_output)
            
            for section in interface_sections[1:]:  # Skip first empty section
                lines = section.split('\n')
                if not lines:
                    continue
                
                # Get interface name
                interface_name = lines[0].strip()
                
                # Parse switchport details
                mode = 'unknown'
                native_vlan = 'unknown'
                allowed_vlans = 'unknown'
                
                for line in lines:
                    if 'Administrative Mode:' in line:
                        mode = line.split(':')[1].strip().lower()
                    elif 'Trunking Native Mode VLAN:' in line:
                        match = re.search(r'(\d+)', line)
                        if match:
                            native_vlan = match.group(1)
                    elif 'Trunking VLANs Enabled:' in line:
                        allowed_vlans = line.split(':')[1].strip()
                
                # Update trunk or access info
                if mode == 'trunk':
                    if interface_name not in trunk_info['trunk_ports']:
                        trunk_info['trunk_ports'].append(interface_name)
                    trunk_info['trunk_details'][interface_name] = {
                        'mode': 'trunk',
                        'native_vlan': native_vlan,
                        'allowed_vlans': allowed_vlans
                    }
                elif mode in ['static access', 'access']:
                    if interface_name not in trunk_info['access_ports']:
                        trunk_info['access_ports'].append(interface_name)
                        trunk_info['access_count'] += 1
            
            trunk_info['trunk_count'] = len(trunk_info['trunk_ports'])
            
        except Exception as e:
            logger.error(f"Error parsing switchport details: {e}")
            
        return trunk_info
    
    @staticmethod
    def _parse_aruba_trunks(trunk_output: str) -> Dict:
        """Parse Aruba trunk port information."""
        trunk_info = {
            'trunk_ports': [],
            'trunk_count': 0,
            'access_ports': [],
            'access_count': 0,
            'trunk_details': {}
        }
        
        try:
            lines = trunk_output.split('\n')
            
            for line in lines:
                # Aruba trunk detection patterns
                if 'Trk' in line or 'trunk' in line.lower():
                    parts = line.split()
                    if parts:
                        interface = parts[0]
                        trunk_info['trunk_ports'].append(interface)
                        trunk_info['trunk_details'][interface] = {
                            'mode': 'trunk',
                            'type': 'aruba_trunk'
                        }
            
            trunk_info['trunk_count'] = len(trunk_info['trunk_ports'])
            
        except Exception as e:
            logger.error(f"Error parsing Aruba trunk output: {e}")
            
        return trunk_info


class NeighborParser:
    """Parser for CDP/LLDP neighbor information."""
    
    @staticmethod
    def parse_cdp_neighbor_details(cdp_output: str) -> List[Dict]:
        """
        Parse detailed CDP neighbor information.
        
        Args:
            cdp_output: Raw CDP neighbors detail output
            
        Returns:
            List of neighbor detail dictionaries
        """
        neighbors = []
        
        try:
            # Split output into device blocks
            device_blocks = cdp_output.split('-------------------------')
            
            for block in device_blocks:
                if not block.strip():
                    continue
                
                neighbor = NeighborParser._extract_cdp_device_details(block)
                if neighbor and neighbor.get('ip_address'):
                    neighbors.append(neighbor)
                    
        except Exception as e:
            logger.error(f"Error parsing CDP neighbor details: {e}")
            
        return neighbors
    
    @staticmethod
    def _extract_cdp_device_details(device_block: str) -> Dict:
        """Extract detailed information from a CDP device block."""
        neighbor = {
            'discovery_method': 'cdp',
            'device_id': None,
            'hostname': None,
            'ip_address': None,
            'platform': None,
            'capabilities': [],
            'local_interface': None,
            'remote_interface': None,
            'software_version': None,
            'duplex': None,
            'vlan_id': None
        }
        
        try:
            lines = device_block.split('\n')
            
            for line in lines:
                line = line.strip()
                
                # Device ID
                if 'Device ID:' in line:
                    device_id = line.split('Device ID:')[1].strip()
                    neighbor['device_id'] = device_id
                    # Extract hostname (before first dot)
                    neighbor['hostname'] = device_id.split('.')[0] if '.' in device_id else device_id
                
                # IP address
                elif 'IP address:' in line:
                    ip_match = re.search(r'(\d+\.\d+\.\d+\.\d+)', line)
                    if ip_match:
                        neighbor['ip_address'] = ip_match.group(1)
                
                # Platform
                elif 'Platform:' in line:
                    platform_match = re.search(r'Platform:\s*([^,]+)', line)
                    if platform_match:
                        neighbor['platform'] = platform_match.group(1).strip()
                    
                    # Capabilities might be on same line
                    if 'Capabilities:' in line:
                        cap_text = line.split('Capabilities:')[1].strip()
                        neighbor['capabilities'] = NeighborParser._parse_capabilities(cap_text)
                
                # Capabilities (separate line)
                elif 'Capabilities:' in line and not neighbor['capabilities']:
                    cap_text = line.split('Capabilities:')[1].strip()
                    neighbor['capabilities'] = NeighborParser._parse_capabilities(cap_text)
                
                # Interface information
                elif 'Interface:' in line and 'Port ID' in line:
                    interface_match = re.search(r'Interface:\s*([^,]+)', line)
                    if interface_match:
                        neighbor['local_interface'] = interface_match.group(1).strip()
                    
                    port_match = re.search(r'Port ID[^:]*:\s*(.+)', line)
                    if port_match:
                        neighbor['remote_interface'] = port_match.group(1).strip()
                
                # Software version
                elif 'Version' in line and ':' in line:
                    version_match = re.search(r'Version[^:]*:\s*(.+)', line)
                    if version_match:
                        neighbor['software_version'] = version_match.group(1).strip()
                
                # Duplex
                elif 'Duplex:' in line:
                    duplex_match = re.search(r'Duplex:\s*(\S+)', line)
                    if duplex_match:
                        neighbor['duplex'] = duplex_match.group(1).strip()
                
                # Native VLAN
                elif 'Native VLAN:' in line:
                    vlan_match = re.search(r'Native VLAN:\s*(\d+)', line)
                    if vlan_match:
                        neighbor['vlan_id'] = vlan_match.group(1)
                        
        except Exception as e:
            logger.debug(f"Error extracting CDP device details: {e}")
            
        return neighbor
    
    @staticmethod
    def parse_lldp_neighbor_details(lldp_output: str) -> List[Dict]:
        """
        Parse detailed LLDP neighbor information.
        
        Args:
            lldp_output: Raw LLDP neighbors detail output
            
        Returns:
            List of neighbor detail dictionaries
        """
        neighbors = []
        
        try:
            # Split by common LLDP separators
            device_blocks = NeighborParser._split_lldp_blocks(lldp_output)
            
            for block in device_blocks:
                if not block.strip():
                    continue
                
                neighbor = NeighborParser._extract_lldp_device_details(block)
                if neighbor and neighbor.get('ip_address'):
                    neighbors.append(neighbor)
                    
        except Exception as e:
            logger.error(f"Error parsing LLDP neighbor details: {e}")
            
        return neighbors
    
    @staticmethod
    def _split_lldp_blocks(lldp_output: str) -> List[str]:
        """Split LLDP output into device blocks."""
        device_blocks = []
        current_block = ""
        
        separators = ['Local Interface:', 'Local Intf:', 'Chassis id:']
        
        for line in lldp_output.split('\n'):
            if any(sep in line for sep in separators) and current_block:
                device_blocks.append(current_block)
                current_block = line + '\n'
            else:
                current_block += line + '\n'
        
        # Add the last block
        if current_block.strip():
            device_blocks.append(current_block)
            
        return device_blocks
    
    @staticmethod
    def _extract_lldp_device_details(device_block: str) -> Dict:
        """Extract detailed information from an LLDP device block."""
        neighbor = {
            'discovery_method': 'lldp',
            'device_id': None,
            'hostname': None,
            'ip_address': None,
            'platform': None,
            'capabilities': [],
            'local_interface': None,
            'remote_interface': None,
            'system_description': None,
            'chassis_id': None,
            'port_description': None
        }
        
        try:
            lines = device_block.split('\n')
            
            for line in lines:
                line = line.strip()
                
                # System Name (hostname)
                if 'System Name:' in line:
                    system_name = line.split('System Name:')[1].strip()
                    neighbor['hostname'] = system_name.split('.')[0] if '.' in system_name else system_name
                    neighbor['device_id'] = system_name
                
                # Management IP address
                elif any(pattern in line for pattern in ['Management Address:', 'Management Addresses:', 'IP:']):
                    ip_match = re.search(r'(\d+\.\d+\.\d+\.\d+)', line)
                    if ip_match:
                        neighbor['ip_address'] = ip_match.group(1)
                
                # Capabilities
                elif 'Capabilities:' in line or 'System Capabilities:' in line:
                    cap_text = line.split(':')[1].strip()
                    neighbor['capabilities'] = NeighborParser._parse_capabilities(cap_text)
                
                # System Description (platform info)
                elif 'System Description:' in line:
                    neighbor['system_description'] = line.split('System Description:')[1].strip()
                    neighbor['platform'] = neighbor['system_description']
                
                # Local Interface
                elif 'Local Interface:' in line or 'Local Intf:' in line:
                    local_match = re.search(r'Local (?:Interface|Intf):\s*(\S+)', line)
                    if local_match:
                        neighbor['local_interface'] = local_match.group(1)
                
                # Remote Interface (Port ID)
                elif 'Port ID:' in line:
                    port_id = line.split('Port ID:')[1].strip()
                    neighbor['remote_interface'] = port_id
                
                # Port Description
                elif 'Port Description:' in line:
                    neighbor['port_description'] = line.split('Port Description:')[1].strip()
                
                # Chassis ID
                elif 'Chassis ID:' in line or 'Chassis id:' in line:
                    chassis_match = re.search(r'Chassis [Ii][Dd]:\s*(.+)', line)
                    if chassis_match:
                        neighbor['chassis_id'] = chassis_match.group(1).strip()
                        
        except Exception as e:
            logger.debug(f"Error extracting LLDP device details: {e}")
            
        return neighbor
    
    @staticmethod
    def _parse_capabilities(capability_text: str) -> List[str]:
        """Parse capability codes into readable list."""
        capabilities = []
        
        # Capability code mappings
        cap_map = {
            'R': 'Router',
            'S': 'Switch',
            'B': 'Bridge',
            'H': 'Host',
            'I': 'IGMP',
            'r': 'Repeater',
            'P': 'Phone',
            'D': 'Remote',
            'C': 'CVTA',
            'T': 'Trans-Bridge',
            'W': 'WLAN-AP'
        }
        
        # Extract capability codes
        for char in capability_text:
            if char.isalpha() and char in cap_map:
                capabilities.append(cap_map[char])
        
        return capabilities
    
    @staticmethod
    def deduplicate_neighbors(neighbors: List[Dict]) -> List[Dict]:
        """
        Remove duplicate neighbors based on IP address.
        
        Args:
            neighbors: List of neighbor dictionaries
            
        Returns:
            Deduplicated list of neighbors
        """
        seen_ips: Set[str] = set()
        unique_neighbors = []
        
        for neighbor in neighbors:
            ip = neighbor.get('ip_address')
            if ip and ip not in seen_ips:
                seen_ips.add(ip)
                unique_neighbors.append(neighbor)
        
        return unique_neighbors
    
    @staticmethod
    def merge_neighbor_sources(cdp_neighbors: List[Dict], lldp_neighbors: List[Dict]) -> List[Dict]:
        """
        Merge CDP and LLDP neighbor information, enriching data where possible.
        
        Args:
            cdp_neighbors: List of CDP neighbor dictionaries
            lldp_neighbors: List of LLDP neighbor dictionaries
            
        Returns:
            Merged and deduplicated neighbor list
        """
        # Create IP-based lookup for enrichment
        ip_map: Dict[str, List[Dict]] = {}
        
        for neighbor in cdp_neighbors + lldp_neighbors:
            ip = neighbor.get('ip_address')
            if ip:
                if ip not in ip_map:
                    ip_map[ip] = []
                ip_map[ip].append(neighbor)
        
        # Merge information from multiple sources
        merged_neighbors = []
        
        for ip, neighbor_list in ip_map.items():
            if len(neighbor_list) == 1:
                merged_neighbors.append(neighbor_list[0])
            else:
                # Merge information from multiple sources
                merged = NeighborParser._merge_neighbor_info(neighbor_list)
                merged_neighbors.append(merged)
        
        return merged_neighbors
    
    @staticmethod
    def _merge_neighbor_info(neighbor_list: List[Dict]) -> Dict:
        """Merge information from multiple neighbor discovery sources."""
        merged = {
            'discovery_method': [],
            'ip_address': None,
            'hostname': None,
            'device_id': None,
            'platform': None,
            'capabilities': [],
            'local_interface': None,
            'remote_interface': None
        }
        
        for neighbor in neighbor_list:
            # Collect discovery methods
            method = neighbor.get('discovery_method')
            if method and method not in merged['discovery_method']:
                merged['discovery_method'].append(method)
            
            # Prefer non-None values
            for key in ['ip_address', 'hostname', 'device_id', 'platform']:
                if not merged[key] and neighbor.get(key):
                    merged[key] = neighbor[key]
            
            # Merge interfaces (prefer CDP)
            if neighbor.get('local_interface'):
                merged['local_interface'] = neighbor['local_interface']
            if neighbor.get('remote_interface'):
                merged['remote_interface'] = neighbor['remote_interface']
            
            # Merge capabilities
            caps = neighbor.get('capabilities', [])
            for cap in caps:
                if cap not in merged['capabilities']:
                    merged['capabilities'].append(cap)
            
            # Keep all additional fields from first source
            for key, value in neighbor.items():
                if key not in merged and value:
                    merged[key] = value
        
        # Convert discovery_method list to string
        merged['discovery_method'] = '+'.join(merged['discovery_method'])
        
        return merged


