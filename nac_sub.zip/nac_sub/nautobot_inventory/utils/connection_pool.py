"""
Connection pool utilities for network inventory discovery.

This module provides connection management utilities to optimize
network device connections and reduce connection overhead.
"""

import threading
from typing import Dict, Optional, Any
from netmiko import ConnectHandler
from netmiko.exceptions import (
    NetmikoTimeoutException, 
    NetmikoAuthenticationException,
    ConnectionException
)
import logging


class ConnectionPool:
    """Thread-safe connection pool for network devices."""
    
    def __init__(self, max_connections: int = 10):
        self.max_connections = max_connections
        self.connections: Dict[str, ConnectHandler] = {}
        self.lock = threading.Lock()
        self.logger = logging.getLogger('nautobot_inventory.connection_pool')
    
    def get_connection(
        self, 
        device_ip: str, 
        device_type: str, 
        username: str, 
        password: str,
        timeout: int = 30
    ) -> Optional[ConnectHandler]:
        """
        Get a connection from the pool or create a new one.
        
        Args:
            device_ip: IP address of the device
            device_type: Device type (cisco_ios, aruba_osswitch, etc.)
            username: Username for authentication
            password: Password for authentication
            timeout: Connection timeout in seconds
            
        Returns:
            ConnectHandler instance or None if connection failed
        """
        connection_key = f"{device_ip}_{device_type}"
        
        with self.lock:
            # Check if connection already exists and is alive
            if connection_key in self.connections:
                conn = self.connections[connection_key]
                if self._is_connection_alive(conn):
                    self.logger.debug(f"Reusing existing connection for {device_ip}")
                    return conn
                else:
                    # Remove dead connection
                    self.logger.debug(f"Removing dead connection for {device_ip}")
                    del self.connections[connection_key]
            
            # Check pool size limit
            if len(self.connections) >= self.max_connections:
                self.logger.warning(f"Connection pool full, removing oldest connection")
                self._remove_oldest_connection()
            
            # Create new connection
            try:
                device_params = {
                    'device_type': device_type,
                    'host': device_ip,
                    'username': username,
                    'password': password,
                    'timeout': timeout,
                    'session_timeout': timeout,
                    'banner_timeout': timeout,
                    'conn_timeout': timeout,
                }
                
                conn = ConnectHandler(**device_params)
                
                # Test connection
                conn.send_command('show version', max_loops=10, cmd_verify=False)
                
                self.connections[connection_key] = conn
                self.logger.info(f"Created new connection for {device_ip}")
                return conn
                
            except (NetMikoTimeoutException, NetMikoAuthenticationException) as e:
                self.logger.warning(f"Connection failed for {device_ip}: {str(e)}")
                return None
            except Exception as e:
                self.logger.error(f"Unexpected connection error for {device_ip}: {str(e)}")
                return None
    
    def _is_connection_alive(self, conn: ConnectHandler) -> bool:
        """Check if a connection is still alive."""
        try:
            conn.send_command('show version', max_loops=5, cmd_verify=False)
            return True
        except:
            return False
    
    def _remove_oldest_connection(self):
        """Remove the oldest connection from the pool."""
        if self.connections:
            oldest_key = next(iter(self.connections))
            oldest_conn = self.connections[oldest_key]
            try:
                oldest_conn.disconnect()
            except:
                pass
            del self.connections[oldest_key]
            self.logger.debug(f"Removed oldest connection: {oldest_key}")
    
    def close_connection(self, device_ip: str, device_type: str):
        """Close a specific connection."""
        connection_key = f"{device_ip}_{device_type}"
        
        with self.lock:
            if connection_key in self.connections:
                try:
                    self.connections[connection_key].disconnect()
                except:
                    pass
                del self.connections[connection_key]
                self.logger.debug(f"Closed connection for {device_ip}")
    
    def close_all_connections(self):
        """Close all connections in the pool."""
        with self.lock:
            for conn in self.connections.values():
                try:
                    conn.disconnect()
                except:
                    pass
            self.connections.clear()
            self.logger.info("Closed all connections in pool")
    
    def get_pool_status(self) -> Dict[str, Any]:
        """Get current pool status."""
        with self.lock:
            return {
                'active_connections': len(self.connections),
                'max_connections': self.max_connections,
                'connection_keys': list(self.connections.keys())
            }


class DeviceConnectionManager:
    """High-level device connection manager."""
    
    def __init__(self, connection_pool: Optional[ConnectionPool] = None):
        self.connection_pool = connection_pool or ConnectionPool()
        self.logger = logging.getLogger('nautobot_inventory.device_connection_manager')
    
    def connect_to_device(
        self,
        device_ip: str,
        device_type: str,
        credentials: Dict[str, str]
    ) -> Optional[ConnectHandler]:
        """
        Connect to a device using the connection pool.
        
        Args:
            device_ip: IP address of the device
            device_type: Device type
            credentials: Dictionary with 'username' and 'password'
            
        Returns:
            ConnectHandler instance or None if connection failed
        """
        username = credentials.get('username')
        password = credentials.get('password')
        
        if not username or not password:
            self.logger.error(f"Missing credentials for {device_ip}")
            return None
        
        return self.connection_pool.get_connection(
            device_ip, device_type, username, password
        )
    
    def execute_command(
        self,
        device_ip: str,
        device_type: str,
        credentials: Dict[str, str],
        command: str,
        **kwargs
    ) -> Optional[str]:
        """
        Execute a command on a device.
        
        Args:
            device_ip: IP address of the device
            device_type: Device type
            credentials: Authentication credentials
            command: Command to execute
            **kwargs: Additional arguments for send_command
            
        Returns:
            Command output or None if failed
        """
        conn = self.connect_to_device(device_ip, device_type, credentials)
        if not conn:
            return None
        
        try:
            output = conn.send_command(command, **kwargs)
            return output
        except Exception as e:
            self.logger.error(f"Command execution failed for {device_ip}: {str(e)}")
            return None
    
    def cleanup(self):
        """Cleanup all connections."""
        self.connection_pool.close_all_connections()


# Global connection manager instance
connection_manager = DeviceConnectionManager()
