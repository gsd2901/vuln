"""
Utilities package for nautobot_inventory.

This package contains reusable utility modules for device discovery,
interface parsing, and logging.
"""

from .interface_parser import InterfaceParser, NeighborParser
from .error_handler import (
    ErrorHandler, 
    ConnectionErrorHandler, 
    DeviceInfoErrorHandler,
    api_error_handler,
    connection_error_handler,
    device_info_error_handler
)
from .connection_pool import ConnectionPool, connection_manager
from .device_validation import DeviceValidationUtils
from .job_management import JobManagementUtils
from .logging_utils import (
    DiscoveryLogger,
    CommandLogger,
    NetmikoLoggingManager,
    device_logger,
    job_logger,
    inventory_logger,
    onboarding_logger
)
from .device_status import is_device_failed, get_failed_device_type
from . import stack_utils

__all__ = [
    # Interface parsing
    'InterfaceParser', 
    'NeighborParser',
    # Error handling
    'ErrorHandler',
    'ConnectionErrorHandler',
    'DeviceInfoErrorHandler',
    'api_error_handler',
    'connection_error_handler',
    'device_info_error_handler',
    # Connection management
    'ConnectionPool',
    'connection_manager',
    # Device validation
    'DeviceValidationUtils',
    # Job management
    'JobManagementUtils',
    # Logging
    'DiscoveryLogger',
    'CommandLogger',
    'NetmikoLoggingManager',
    'device_logger',
    'job_logger',
    'inventory_logger',
    'onboarding_logger',
    # Device status
    'is_device_failed',
    'get_failed_device_type',
    # Stack utilities
    'stack_utils',
]
