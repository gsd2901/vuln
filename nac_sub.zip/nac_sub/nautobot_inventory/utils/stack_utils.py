"""
Utility functions for stack device management.

This module provides functions to create and manage stack member devices
without requiring separate Celery job execution. This approach avoids
job registration issues and provides synchronous stack creation.

Key Features:
- Direct stack member creation (no Celery job required)
- VirtualChassis creation and management
- Automatic role assignment (stack-master, stack-member, stack-standby)
- IP address conflict prevention (only master gets management IP)
- Support for multiple stack member naming conventions
- Stack detection and parsing for Cisco and Aruba platforms

Usage:
    from nautobot_inventory.utils.stack_utils import create_stack_members, detect_and_parse_stack
    
    # Create stack members
    result = create_stack_members(
        device_id=master_device.id,
        stack_info={
            'total_members': 3,
            'master_switch': 1,
            'members': [
                {'switch_number': 1, 'role': 'master', 'serial_number': 'ABC123', ...},
                {'switch_number': 2, 'role': 'member', 'serial_number': 'DEF456', ...},
                {'switch_number': 3, 'role': 'standby', 'serial_number': 'GHI789', ...}
            ]
        },
        session_id='optional-session-id'
    )
    
    if result['success']:
        print(f"Created {result['members_created']} stack members")
    else:
        print(f"Error: {result['error']}")
    
    # Detect stack
    stack_info = detect_and_parse_stack(conn, platform, version_output, logger)
    if stack_info and stack_info['is_stack']:
        print(f"Stack detected with {stack_info['total_members']} members")
"""
import logging
import re
import time
from typing import Dict, List, Optional, Any, TYPE_CHECKING

from django.core.exceptions import ValidationError
from nautobot.dcim.models import Device, VirtualChassis, DeviceType, Manufacturer, Interface
from nautobot.extras.models import Role, Status

if TYPE_CHECKING:
    from netmiko import ConnectHandler

logger = logging.getLogger(__name__)


def create_stack_members(
    device_id: str, 
    stack_info: Dict, 
    session_id: Optional[str] = None,
    create_interfaces: bool = False,
    redistribute_interfaces: bool = False
) -> Dict:
    """
    Create stack member devices and VirtualChassis for a stack device.
    
    This function is called directly from the onboarding workflow, avoiding
    the need for a separate Celery job that can fail due to registration issues.
    
    Args:
        device_id: ID of the master device (already onboarded)
        stack_info: Dictionary containing stack member information
        session_id: Optional discovery session ID for logging
        create_interfaces: Whether to create interfaces for member devices
        redistribute_interfaces: Whether to redistribute interfaces from master to members
        
    Returns:
        Dictionary with results:
        {
            'success': bool,
            'virtual_chassis': str,
            'master_device': str,
            'members_created': int,
            'total_devices': int,
            'error': str (if success=False)
        }
    """
    logger.info("=" * 80)
    logger.info("🏗️  STACK MEMBER CREATION STARTED")
    logger.info("=" * 80)
    
    try:
        # Get the master device
        master_device = Device.objects.get(id=device_id)
        logger.info(f"📦 Master Device: {master_device.name} (ID: {device_id})")
        logger.info(f"📍 Location: {master_device.location}")
        logger.info(f"🔧 Platform: {master_device.platform}")
        
        # Validate stack_info
        if not stack_info or not isinstance(stack_info, dict):
            raise ValueError("Invalid stack_info provided")
        
        # Log the full stack_info structure for debugging
        logger.info(f"📋 Stack Info Keys: {list(stack_info.keys())}")
        
        total_members = stack_info.get('total_members', 0)
        
        # Support both 'members' and 'stack_members' field names
        members = stack_info.get('members') or stack_info.get('stack_members', [])
        
        # Support both 'master_switch' and 'master_switch_number' field names
        master_switch = stack_info.get('master_switch') or stack_info.get('master_switch_number', 1)
        
        logger.info(f"📊 Stack Info: {total_members} members, master switch: {master_switch}")
        logger.info(f"📊 Found {len(members)} member entries in stack_info")
        
        if not members:
            raise ValueError("No stack members found in stack_info")
        
        # Step 1: Create VirtualChassis
        logger.info("\n" + "=" * 80)
        logger.info("STEP 1: Creating Virtual Chassis")
        logger.info("=" * 80)
        
        vc_name = _generate_vc_name(master_device.name)
        domain = vc_name.lower().replace('_', '-').replace(' ', '-')
        
        # Check if VirtualChassis already exists
        vc = VirtualChassis.objects.filter(name=vc_name).first()
        if vc:
            logger.warning(f"♻️  Virtual Chassis '{vc_name}' already exists, using existing")
        else:
            vc = VirtualChassis.objects.create(
                name=vc_name,
                domain=domain
            )
            logger.info(f"✅ Created Virtual Chassis: {vc_name} (domain: {domain})")
        
        # Step 2: Update master device
        logger.info("\n" + "=" * 80)
        logger.info("STEP 2: Updating Master Device")
        logger.info("=" * 80)
        
        master_info = next((m for m in members if m.get('switch_number') == master_switch), None)
        if master_info:
            master_device.virtual_chassis = vc
            master_device.vc_position = master_info.get('switch_number', 1)
            master_device.vc_priority = master_info.get('priority', 15)
            
            # Update serial if available and not already set
            if master_info.get('serial_number') and not master_device.serial:
                master_device.serial = master_info['serial_number']
                logger.info(f"📝 Updated master serial: {master_device.serial}")
            
            # Update role to stack-master
            try:
                master_role = Role.objects.get(name='stack-master')
                master_device.role = master_role
                logger.info(f"🎭 Updated master role to: stack-master")
            except Role.DoesNotExist:
                logger.warning("⚠️  Role 'stack-master' not found, keeping existing role")
            
            master_device.validated_save()
            logger.info(f"✅ Master device updated: VC position {master_device.vc_position}, priority {master_device.vc_priority}")
        else:
            logger.warning(f"⚠️  Master switch info not found for switch {master_switch}")
        
        # Step 3: Create member devices
        logger.info("\n" + "=" * 80)
        logger.info("STEP 3: Creating Stack Member Devices")
        logger.info("=" * 80)
        
        created_members = []
        for member_info in members:
            switch_num = member_info.get('switch_number')
            
            # Skip the master switch (already exists)
            if switch_num == master_switch:
                logger.info(f"⏭️  Skipping switch {switch_num} (master device)")
                continue
            
            logger.info(f"\n--- Creating Member Device {switch_num} ---")
            
            try:
                member_device = _create_member_device(
                    master_device=master_device,
                    vc=vc,
                    member_info=member_info,
                    vc_name=vc_name,
                    create_interfaces=create_interfaces
                )
                
                if member_device:
                    created_members.append(member_device)
                    logger.info(f"✅ Created member device: {member_device.name}")
                else:
                    logger.error(f"❌ Failed to create member device for switch {switch_num}")
                    
            except Exception as e:
                logger.error(f"❌ Error creating member device {switch_num}: {str(e)}", exc_info=True)
                continue
        
        # Step 4: Set VirtualChassis master
        logger.info("\n" + "=" * 80)
        logger.info("STEP 4: Setting Virtual Chassis Master")
        logger.info("=" * 80)
        
        vc.master = master_device
        vc.validated_save()
        logger.info(f"✅ Set Virtual Chassis master to: {master_device.name}")
        
        # Step 5: Try to get serial numbers from version output if still missing
        members_without_serials = [m for m in created_members if m.serial in ['unknown', '', None]]
        if members_without_serials:
            logger.info("\n" + "=" * 80)
            logger.info("STEP 5: Attempting Serial Number Recovery from Version Output")
            logger.info("=" * 80)
            
            # Try to get version output from stack_info raw_outputs
            version_output = None
            if isinstance(stack_info, dict) and 'raw_outputs' in stack_info:
                version_output = stack_info['raw_outputs'].get('show version')
            
            if version_output:
                logger.info(f"📋 Found version output, attempting to extract {len(members_without_serials)} missing serial numbers")
                
                # Convert Device objects to member info format for the parser
                member_dicts = []
                for device in created_members + [master_device]:
                    member_dict = {
                        'switch_number': device.vc_position,
                        'serial_number': device.serial if device.serial not in ['unknown', '', None] else 'unknown',
                        'model': device.device_type.model if device.device_type else 'unknown',
                        'device_obj': device  # Keep reference to update later
                    }
                    member_dicts.append(member_dict)
                
                # Use the version parser
                updated_members = add_serial_numbers_from_version(member_dicts, version_output, logger)
                
                # Apply updates back to Device objects
                updated_count = 0
                for member_dict in updated_members:
                    device_obj = member_dict.get('device_obj')
                    new_serial = member_dict.get('serial_number')
                    
                    if device_obj and new_serial and new_serial not in ['unknown', '', None]:
                        if device_obj.serial in ['unknown', '', None]:
                            device_obj.serial = new_serial
                            device_obj.validated_save()
                            updated_count += 1
                            logger.info(f"   ✅ Updated {device_obj.name} serial: {new_serial}")
                
                logger.info(f"✅ Updated {updated_count} device serial numbers from version output")
            else:
                logger.warning("⚠️  No version output available for serial number recovery")
        
        # Step 6: Optionally redistribute interfaces
        if redistribute_interfaces and created_members:
            logger.info("\n" + "=" * 80)
            logger.info("STEP 6: Redistributing Interfaces")
            logger.info("=" * 80)
            
            moved_count = redistribute_device_interfaces(master_device, vc, stack_info)
            logger.info(f"✅ Redistributed {moved_count} interfaces to member devices")
        
        # Summary
        logger.info("\n" + "=" * 80)
        logger.info("📊 STACK MEMBER CREATION SUMMARY")
        logger.info("=" * 80)
        logger.info(f"Virtual Chassis: {vc.name}")
        logger.info(f"Master Device: {master_device.name} (position {master_device.vc_position})")
        logger.info(f"Member Devices Created: {len(created_members)}")
        for member in created_members:
            logger.info(f"  - {member.name} (position {member.vc_position}, serial: {member.serial})")
        logger.info(f"Total Devices in Stack: {len(created_members) + 1}")
        logger.info("=" * 80)
        logger.info("✅ STACK MEMBER CREATION COMPLETED SUCCESSFULLY")
        logger.info("=" * 80)
        
        return {
            'success': True,
            'virtual_chassis': vc.name,
            'master_device': master_device.name,
            'members_created': len(created_members),
            'total_devices': len(created_members) + 1
        }
        
    except Device.DoesNotExist:
        error_msg = f"Device with ID {device_id} not found"
        logger.error(f"❌ {error_msg}")
        return {
            'success': False,
            'error': error_msg
        }
        
    except Exception as e:
        error_msg = f"Stack member creation failed: {str(e)}"
        logger.error(f"❌ {error_msg}", exc_info=True)
        return {
            'success': False,
            'error': error_msg
        }


def _generate_vc_name(hostname: str) -> str:
    """
    Generate Virtual Chassis name from hostname.
    
    Removes trailing numbers and common switch suffixes, then adds -STACK.
    
    Examples:
        'CORE-SW1' -> 'CORE-STACK'
        'DIST-SWITCH-2' -> 'DIST-STACK'
        'ACCESS-STK1' -> 'ACCESS-STACK'
    
    Args:
        hostname: Device hostname
        
    Returns:
        Virtual Chassis name with -STACK suffix
    """
    # Remove trailing numbers/dashes
    vc_name = hostname.rstrip('-_')
    
    # Remove common suffixes like -SW1, -SWITCH1, etc.
    for suffix in ['-SW', '-SWITCH', '-STK', '-STACK']:
        if vc_name.upper().endswith(suffix):
            vc_name = vc_name[:-len(suffix)]
    
    # Add -STACK suffix if not present
    if not vc_name.upper().endswith('-STACK'):
        vc_name = f"{vc_name}-STACK"
    
    return vc_name


def _create_member_device(
    master_device: Device,
    vc: VirtualChassis,
    member_info: Dict,
    vc_name: str,
    create_interfaces: bool = False
) -> Optional[Device]:
    """
    Create a stack member device WITHOUT IP address conflict.
    
    Key: Member devices do NOT get the management IP!
    
    Args:
        master_device: The master device in the stack
        vc: VirtualChassis instance
        member_info: Dictionary with member information
        vc_name: Name of the virtual chassis
        create_interfaces: Whether to create interfaces for this member device
        
    Returns:
        Created Device instance or None if failed
    """
    try:
        switch_num = member_info.get('switch_number', 0)
        serial_number = member_info.get('serial_number', '')
        
        # Generate member device name: {hostname}-{serial_number}
        # Example: CORE-SW-FOC2715Z6RN
        base_name = vc_name.replace('-STACK', '')
        
        # Sanitize serial number for hostname use
        sanitized_serial = _sanitize_serial_for_hostname(serial_number)
        
        # Fall back to switch number if serial is missing
        if not sanitized_serial:
            logger.warning(f"  ⚠️  No serial number for switch {switch_num}, using switch number")
            sanitized_serial = f"SW{switch_num}"
        
        member_name = f"{base_name}-{sanitized_serial}"
        
        logger.info(f"  Device Name: {member_name}")
        logger.info(f"  Switch Number: {switch_num}")
        logger.info(f"  Serial: {serial_number}")
        
        # Check if device already exists
        existing = Device.objects.filter(name=member_name).first()
        if existing:
            logger.warning(f"  ⚠️  Device {member_name} already exists, updating...")
            member_device = existing
        else:
            member_device = Device(name=member_name)
        
        # Get or create device type
        model = member_info.get('model', master_device.device_type.model)
        device_type = _get_or_create_device_type(model, master_device.device_type.manufacturer)
        logger.info(f"  Device Type: {device_type.model}")
        
        # Get role based on stack role
        role_name = _get_role_name(member_info.get('role', 'member'))
        try:
            role = Role.objects.get(name=role_name)
            logger.info(f"  Role: {role_name}")
        except Role.DoesNotExist:
            logger.warning(f"  ⚠️  Role '{role_name}' not found, using master's role")
            role = master_device.role
        
        # Set device attributes (clone from master)
        member_device.device_type = device_type
        member_device.role = role
        member_device.platform = master_device.platform
        member_device.location = master_device.location
        member_device.tenant = master_device.tenant
        member_device.status = master_device.status
        
        # Stack-specific attributes
        member_device.virtual_chassis = vc
        member_device.vc_position = switch_num
        member_device.vc_priority = member_info.get('priority', 1)
        member_device.serial = serial_number
        
        # CRITICAL: Do NOT assign primary IP (would conflict with master)
        # Only the master device should have the management IP
        member_device.primary_ip4 = None
        member_device.primary_ip6 = None
        
        logger.info(f"  VC Position: {member_device.vc_position}")
        logger.info(f"  VC Priority: {member_device.vc_priority}")
        logger.info(f"  ⚠️  No IP assigned (master has management IP)")
        
        member_device.validated_save()
        
        # Optionally create interfaces
        if create_interfaces and 'ports' in member_info:
            interfaces_created = create_interfaces_for_member(member_device, member_info)
            logger.info(f"  Created {interfaces_created} interfaces")
        
        return member_device
        
    except Exception as e:
        logger.error(f"  ❌ Error creating member device: {e}", exc_info=True)
        return None


def _get_role_name(stack_role: str) -> str:
    """
    Map stack role to Nautobot device role name.
    
    Args:
        stack_role: Stack role from device (master, standby, member, etc.)
        
    Returns:
        Nautobot role name (stack-master, stack-standby, or stack-member)
    """
    role_map = {
        'master': 'stack-master',
        'active': 'stack-master',
        'standby': 'stack-standby',
        'member': 'stack-member',
        'ready': 'stack-member',
    }
    return role_map.get(stack_role.lower(), 'stack-member')


def _sanitize_serial_for_hostname(serial: str) -> str:
    """
    Sanitize serial number for use in hostname.
    
    Removes spaces, special characters, and converts to uppercase.
    Keeps only alphanumeric characters and hyphens.
    
    Args:
        serial: Serial number string
        
    Returns:
        Sanitized serial number suitable for hostname
    """
    if not serial:
        return ''
    
    # Remove spaces and special characters, keep alphanumeric and hyphens
    sanitized = re.sub(r'[^A-Za-z0-9-]', '', serial.upper())
    
    # Remove leading/trailing hyphens
    sanitized = sanitized.strip('-')
    
    return sanitized


def _get_or_create_device_type(model: str, manufacturer: Manufacturer) -> DeviceType:
    """
    Get existing device type or create a new one.
    
    Args:
        model: Device model name
        manufacturer: Manufacturer instance
        
    Returns:
        DeviceType instance
    """
    device_type = DeviceType.objects.filter(
        model=model,
        manufacturer=manufacturer
    ).first()
    
    if device_type:
        return device_type
    
    # Create new device type with default values
    logger.info(f"  📝 Creating new device type: {model}")
    device_type = DeviceType.objects.create(
        model=model,
        manufacturer=manufacturer,
        u_height=1,
        is_full_depth=True
    )
    
    return device_type


# ==============================================================================
# Additional Stack Management Functions
# ==============================================================================

def get_stack_info_from_device(device: Device) -> Optional[Dict]:
    """
    Get stack information from discovered device.
    
    Tries multiple sources:
    1. Device custom field 'stack_info'
    2. DiscoveredDevice.device_data['stack_info']
    3. Device tags/metadata
    
    Args:
        device: Device instance to get stack info for
        
    Returns:
        Stack information dictionary or None if not found
    """
    try:
        # Try to find associated DiscoveredDevice
        if device.primary_ip4:
            ip_address = str(device.primary_ip4.address).split('/')[0]
            
            # Import here to avoid circular imports
            from nautobot_inventory.models import DiscoveredDevice
            
            discovered = DiscoveredDevice.objects.filter(
                ip_address=ip_address
            ).order_by('-discovered_at').first()
            
            if discovered and discovered.device_data:
                if isinstance(discovered.device_data, dict):
                    stack_info = discovered.device_data.get('stack_info')
                    if stack_info:
                        logger.info(f"📍 Found stack info from DiscoveredDevice for {device.name}")
                        return stack_info
    except Exception as e:
        logger.debug(f"Could not retrieve from DiscoveredDevice: {e}")
    
    # Try custom field
    if hasattr(device, '_custom_field_data') and 'stack_info' in device._custom_field_data:
        logger.info(f"📍 Found stack info from custom field for {device.name}")
        return device._custom_field_data['stack_info']
    
    logger.warning(f"⚠️ No stack info found for device {device.name}")
    return None


def create_interfaces_for_member(device: Device, member_info: Dict) -> int:
    """
    Create interfaces for a member device based on port information.
    
    Args:
        device: Device to create interfaces for
        member_info: Dictionary with member information including 'ports'
        
    Returns:
        Number of interfaces created
    """
    ports = member_info.get('ports', [])
    if not ports:
        return 0
    
    # Get active status
    try:
        active_status = Status.objects.get(name='Active')
    except Status.DoesNotExist:
        logger.warning("Active status not found, using first available status")
        active_status = Status.objects.first()
    
    created_count = 0
    for port_name in ports[:10]:  # Limit to prevent creating too many
        interface, created = Interface.objects.get_or_create(
            device=device,
            name=port_name,
            defaults={
                'type': 'other',
                'status': active_status,
            }
        )
        if created:
            created_count += 1
    
    logger.info(f"   Created {created_count} interfaces for {device.name}")
    return created_count


def redistribute_device_interfaces(master_device: Device, vc: VirtualChassis, stack_info: Dict) -> int:
    """
    Redistribute interfaces from master device to correct member devices.
    
    This looks at interface names like "GigabitEthernet2/0/1" and moves them
    to the device at vc_position=2.
    
    Args:
        master_device: Master device with interfaces to redistribute
        vc: Virtual Chassis containing member devices
        stack_info: Stack information (not currently used but kept for compatibility)
        
    Returns:
        Number of interfaces moved
    """
    logger.info(f"🔄 Redistributing interfaces from {master_device.name}...")
    
    moved_count = 0
    for interface in master_device.interfaces.all():
        # Try to extract switch number from interface name
        # Format: GigabitEthernet2/0/1 -> switch 2
        # Format: Te1/0/1 -> switch 1
        match = re.match(r'^[A-Za-z]+(\d+)/\d+/\d+', interface.name)
        if match:
            switch_num = int(match.group(1))
            
            # Find device at that position
            target_device = Device.objects.filter(
                virtual_chassis=vc,
                vc_position=switch_num
            ).first()
            
            if target_device and target_device != master_device:
                interface.device = target_device
                interface.save()
                moved_count += 1
                logger.debug(f"   Moved {interface.name} to {target_device.name}")
    
    logger.info(f"   Moved {moved_count} interfaces to member devices")
    return moved_count


def remove_virtual_chassis_conversion(vc: VirtualChassis, keep_member_devices: bool = False) -> Dict:
    """
    Remove/reverse a Virtual Chassis conversion.
    
    This function removes Virtual Chassis and consolidates back to a single device.
    Useful for testing or if conversion was done incorrectly.
    
    Args:
        vc: Virtual Chassis to remove
        keep_member_devices: If True, keep member devices (just unlink from VC)
                           If False, delete member devices
        
    Returns:
        Dictionary with results:
        {
            'success': bool,
            'master_device': str,
            'members_processed': int,
            'error': str (if success=False)
        }
    """
    logger.info(f"🗑️ Removing Virtual Chassis: {vc.name}")
    
    try:
        master = vc.master
        if not master:
            # Find a device to use as master
            master = Device.objects.filter(virtual_chassis=vc).first()
            if not master:
                raise ValueError("No devices found in Virtual Chassis")
        
        members = Device.objects.filter(virtual_chassis=vc).exclude(id=master.id)
        
        logger.info(f"   Master: {master.name}")
        logger.info(f"   Members to process: {members.count()}")
        
        members_processed = 0
        
        if keep_member_devices:
            # Just unlink
            for member in members:
                member.virtual_chassis = None
                member.vc_position = None
                member.vc_priority = None
                member.save()
                logger.info(f"   Unlinked: {member.name}")
                members_processed += 1
        else:
            # Delete member devices
            for member in members:
                member_name = member.name
                member.delete()
                logger.info(f"   Deleted: {member_name}")
                members_processed += 1
        
        # Remove VC link from master
        master.virtual_chassis = None
        master.vc_position = None
        master.vc_priority = None
        master.save()
        
        # Delete Virtual Chassis
        vc_name = vc.name
        vc.delete()
        
        logger.info(f"✅ Removed Virtual Chassis: {vc_name}")
        
        return {
            'success': True,
            'master_device': master.name,
            'members_processed': members_processed
        }
        
    except Exception as e:
        error_msg = f"Failed to remove Virtual Chassis: {str(e)}"
        logger.error(f"❌ {error_msg}", exc_info=True)
        return {
            'success': False,
            'error': error_msg
        }


# ==============================================================================
# Stack Detection and Parsing Functions
# ==============================================================================

def detect_and_parse_stack(
    conn: 'ConnectHandler', 
    platform: str, 
    version_output: str,
    log: Any = None,
    discovery_logger: Any = None
) -> Optional[Dict]:
    """
    Detect if device is a stack and parse stack information.
    
    Args:
        conn: Netmiko connection
        platform: Detected platform type
        version_output: Output from show version command
        log: Logger instance
        discovery_logger: Discovery logger for command logging
        
    Returns:
        Dictionary with stack information or None if not a stack
    """
    _logger = log or logger
    
    try:
        # Quick check in version output first
        version_lower = version_output.lower()
        
        # Check for STRONG stack indicators in version output
        # These patterns should only match actual stacks, not single switches
        stack_indicators = [
            'switch stack',
            'stack member',
            'stackwise',
            'stack port',
            'virtual switching system',
            'vss',
        ]
        
        has_stack_indicator = any(indicator in version_lower for indicator in stack_indicators)
        
        # Additional check: Look for multiple switch entries in version output
        # This is a more reliable indicator than just "Switch Ports Model" header
        # Count lines that look like switch entries: "Switch 01", "Switch 02", etc.
        switch_entry_pattern = r'^\s*[\*]?\s*switch\s+0?([2-9]|\d{2,})\s+'
        multiple_switches = len(re.findall(switch_entry_pattern, version_output, re.MULTILINE | re.IGNORECASE)) > 0
        
        if multiple_switches:
            _logger.info(f"Detected multiple switch entries in version output for {conn.host}")
            has_stack_indicator = True
        
        # Additional check: Look for stack table with multiple members
        # Format: "*    1 41    C9300-24T" followed by "     2 41    C9300-24T"
        stack_table_matches = re.findall(r'^\s*[\*]?\s*(\d+)\s+\d+\s+\S+', version_output, re.MULTILINE)
        if len(stack_table_matches) > 1:
            # Check if we have switch numbers 1 AND 2 (or higher)
            switch_numbers = [int(m) for m in stack_table_matches]
            if len(set(switch_numbers)) > 1 and max(switch_numbers) > 1:
                _logger.info(f"Detected stack table with multiple members for {conn.host}: {switch_numbers}")
                has_stack_indicator = True
        
        if not has_stack_indicator:
            _logger.debug(f"No stack indicators found in version output for {conn.host}")
            return None
        
        # Platform-specific stack detection
        if 'cisco' in platform.lower():
            return parse_cisco_stack(conn, platform, version_output, _logger, discovery_logger)
        elif ('aruba' in platform.lower() or 'arubaos' in platform.lower() or
              'hp procurve' in platform.lower() or 'hp provision' in platform.lower() or
              ('hp' in platform.lower() and any(hp_indicator in platform.lower() for hp_indicator in [
                  'procurve', 'provision', 'comware', 'networking', 'switch'
              ]))):
            return parse_aruba_stack(conn, _logger, discovery_logger)
        else:
            _logger.debug(f"Stack detection not implemented for platform: {platform}")
            return None
            
    except Exception as e:
        _logger.warning(f"Error detecting stack: {e}")
        return None


def parse_cisco_stack(
    conn: 'ConnectHandler', 
    platform: str, 
    version_output: Optional[str] = None,
    log: Any = None,
    discovery_logger: Any = None
) -> Optional[Dict]:
    """
    Parse Cisco stack information.
    
    Args:
        conn: Connection handler
        platform: Platform string
        version_output: Output from 'show version' command (optional)
        log: Logger instance
        discovery_logger: Discovery logger for command logging
    
    Returns:
        Dictionary with detailed stack information
    """
    _logger = log or logger
    
    stack_info = {
        'vendor': 'cisco',
        'is_stack': False,
        'stack_members': [],
        'total_members': 0,
        'master_switch_number': None,
        'standby_switch_number': None,
        'stack_mode': 'unknown',
        'raw_outputs': {}
    }
    
    try:
        # Try different commands in order of preference
        commands = [
            'show switch detail',
            'show switch',
            'show platform stack',
            'show stack'
        ]
        
        stack_output = None
        command_used = None
        
        for cmd in commands:
            try:
                start_time = time.time()
                _logger.info(f"[STACK_DETECTION] Executing command on {conn.host}: {cmd}")
                
                # Use CommandLogger if available
                if discovery_logger:
                    try:
                        from nautobot_inventory.utils import CommandLogger
                        with CommandLogger(discovery_logger, conn.host, 'stack_detection') as cmd_logger:
                            cmd_logger.set_command(cmd)
                            output = conn.send_command(cmd, delay_factor=1)
                            cmd_logger.set_output(output)
                    except ImportError:
                        output = conn.send_command(cmd, delay_factor=1)
                else:
                    output = conn.send_command(cmd, delay_factor=1)
                
                duration = time.time() - start_time
                
                if output and 'invalid' not in output.lower() and len(output.strip()) > 10:
                    stack_output = output
                    command_used = cmd
                    stack_info['raw_outputs'][cmd] = output
                    _logger.info(f"[STACK_DETECTION] Command '{cmd}' succeeded on {conn.host} ({duration:.2f}s, {len(output)} bytes)")
                    break
                else:
                    _logger.debug(f"[STACK_DETECTION] Command '{cmd}' returned invalid/empty output on {conn.host}")
            except Exception as e:
                _logger.debug(f"[STACK_DETECTION] Command '{cmd}' failed on {conn.host}: {e}")
                continue
        
        if not stack_output:
            _logger.info(f"[STACK_DETECTION] No valid stack command output from {conn.host}")
            return None
        
        # Parse the stack output
        members = []
        lines = stack_output.split('\n')
        
        for line in lines:
            line = line.strip()
            
            # Match stack member lines (various formats)
            # Format 1: "*1       Master   0011.2233.4455     15     V02     Ready"
            # Format 2: " 2       Member   0011.2233.4456     14     V02     Ready"
            match = re.match(r'^(\*?)(\d+)\s+(Master|Member|Standby|Active)\s+([0-9a-fA-F]{4}\.[0-9a-fA-F]{4}\.[0-9a-fA-F]{4})\s+(\d+)\s+(\S+)\s+(\S+)', line)
            
            if match:
                is_master = bool(match.group(1))
                switch_num = int(match.group(2))
                role = match.group(3).lower()
                mac_address = match.group(4)
                priority = int(match.group(5))
                hw_version = match.group(6)
                state = match.group(7).lower()
                
                member = {
                    'switch_number': switch_num,
                    'role': role,
                    'mac_address': mac_address,
                    'priority': priority,
                    'hw_version': hw_version,
                    'state': state,
                    'is_master': is_master or role == 'master',
                    'model': 'unknown',
                    'serial_number': 'unknown',
                    'sw_version': 'unknown',
                    'ports': []
                }
                
                members.append(member)
                
                # Track master/standby
                if member['is_master'] or role == 'master':
                    stack_info['master_switch_number'] = switch_num
                elif role == 'standby':
                    stack_info['standby_switch_number'] = switch_num
        
        # If we found members, try to get detailed info
        if members:
            stack_info['is_stack'] = True
            stack_info['total_members'] = len(members)
            stack_info['stack_mode'] = 'full' if len(members) > 1 else 'standalone'
            
            # Try to get more detailed information
            try:
                start_time = time.time()
                _logger.info(f"[STACK_DETECTION] Executing 'show switch detail' on {conn.host}")
                
                # Use CommandLogger if available
                if discovery_logger:
                    try:
                        from nautobot_inventory.utils import CommandLogger
                        with CommandLogger(discovery_logger, conn.host, 'stack_detection') as cmd_logger:
                            cmd_logger.set_command('show switch detail')
                            detail_output = conn.send_command('show switch detail', delay_factor=1)
                            cmd_logger.set_output(detail_output)
                    except ImportError:
                        detail_output = conn.send_command('show switch detail', delay_factor=1)
                else:
                    detail_output = conn.send_command('show switch detail', delay_factor=1)
                
                duration = time.time() - start_time
                stack_info['raw_outputs']['show switch detail'] = detail_output
                members = enrich_cisco_stack_members(members, detail_output, _logger)
                _logger.info(f"[STACK_DETECTION] 'show switch detail' completed ({duration:.2f}s)")
            except Exception as e:
                _logger.debug(f"[STACK_DETECTION] 'show switch detail' failed: {e}")
            
            # Try to get inventory for serial numbers
            try:
                start_time = time.time()
                _logger.info(f"[STACK_DETECTION] Executing 'show inventory' on {conn.host}")
                
                # Use CommandLogger if available
                if discovery_logger:
                    try:
                        from nautobot_inventory.utils import CommandLogger
                        with CommandLogger(discovery_logger, conn.host, 'stack_detection') as cmd_logger:
                            cmd_logger.set_command('show inventory')
                            inventory_output = conn.send_command('show inventory', delay_factor=1)
                            cmd_logger.set_output(inventory_output)
                    except ImportError:
                        inventory_output = conn.send_command('show inventory', delay_factor=1)
                else:
                    inventory_output = conn.send_command('show inventory', delay_factor=1)
                
                duration = time.time() - start_time
                stack_info['raw_outputs']['show inventory'] = inventory_output
                members = add_serial_numbers_from_inventory(members, inventory_output, _logger)
                _logger.info(f"[STACK_DETECTION] 'show inventory' completed ({duration:.2f}s)")
            except Exception as e:
                _logger.debug(f"[STACK_DETECTION] 'show inventory' failed: {e}")
            
            # Fallback: Try to extract serial numbers from version output if inventory didn't work
            members_still_unknown = [m for m in members if m.get('serial_number') in ['unknown', '', None]]
            if members_still_unknown and version_output:
                _logger.info(f"[STACK_DETECTION] {len(members_still_unknown)} members still need serial numbers, trying version output fallback")
                members = add_serial_numbers_from_version(members, version_output, _logger)
            
            # Extract software version from version output and apply to all members
            if version_output:
                sw_version = extract_software_version(version_output, _logger)
                if sw_version:
                    for member in members:
                        if member.get('sw_version') == 'unknown':
                            member['sw_version'] = sw_version
                    _logger.debug(f"[STACK_DETECTION] Applied software version {sw_version} to all stack members")
            
            stack_info['stack_members'] = members
            
            _logger.info(
                f"[STACK_DETECTION] Successfully detected Cisco stack with {len(members)} members. "
                f"Master: Switch {stack_info['master_switch_number']}, Members: {[m['switch_number'] for m in members]}"
            )
            
            return stack_info
        
        _logger.info(f"[STACK_DETECTION] No stack members parsed from output on {conn.host}")
        return None
        
    except Exception as e:
        _logger.error(f"Error parsing Cisco stack: {e}")
        return None


def enrich_cisco_stack_members(members: List[Dict], detail_output: str, log: Any = None) -> List[Dict]:
    """
    Enrich stack member information from detailed output.
    
    Extracts:
    - Model numbers
    - Software versions
    - Port ranges
    """
    _logger = log or logger
    
    try:
        # Parse detailed output
        # Format: "1        24      WS-C3850-24P        16.12.04        CAT3K_CAA-UNIVERSALK9"
        
        for line in detail_output.split('\n'):
            match = re.match(r'^\s*(\d+)\s+(\d+)\s+(\S+)\s+([\d.]+)\s+(\S+)', line.strip())
            if match:
                switch_num = int(match.group(1))
                port_count = int(match.group(2))
                model = match.group(3)
                sw_version = match.group(4)
                sw_image = match.group(5)
                
                # Find matching member
                for member in members:
                    if member['switch_number'] == switch_num:
                        member['model'] = model
                        member['sw_version'] = sw_version
                        member['sw_image'] = sw_image
                        member['port_count'] = port_count
                        # Generate port range
                        member['ports'] = [f"{switch_num}/0/{i+1}" for i in range(port_count)]
                        break
        
    except Exception as e:
        _logger.debug(f"Error enriching stack members: {e}")
    
    return members


def add_serial_numbers_from_inventory(members: List[Dict], inventory_output: str, log: Any = None) -> List[Dict]:
    """
    Add serial numbers and model information to stack members from inventory output.
    
    Parse inventory output to match serial numbers and models with switch numbers.
    Only captures the chassis serial number and model, not modules/SFPs/power supplies.
    """
    _logger = log or logger
    
    try:
        # Parse inventory output
        # Format varies, but typically:
        # NAME: "Switch 1", DESCR: "C9300-24T"
        # PID: C9300-24T         , VID: V02  , SN: FOC2715Z6RN
        # NAME: "Switch 1 FRU Uplink Module 1", DESCR: "8x10G Uplink Module"
        # PID: C9300-NM-8X       , VID: V03  , SN: FVH27081GCV  <- ignore this
        
        current_switch = None
        found_chassis_info = False
        
        for line in inventory_output.split('\n'):
            # Look for switch chassis identifier (not modules, ports, or power supplies)
            # Match: NAME: "Switch 1", DESCR: "..."
            # Don't match: NAME: "Switch 1 - Power Supply A"
            # Don't match: NAME: "Switch 1 FRU Uplink Module 1"
            # Don't match: NAME: "Te1/1/1"
            switch_match = re.search(r'NAME:\s*"Switch\s+(\d+)"', line, re.IGNORECASE)
            if switch_match and not re.search(r'(Power Supply|FRU|Module|Port|StackPort)', line, re.IGNORECASE):
                current_switch = int(switch_match.group(1))
                found_chassis_info = False  # Reset flag for new switch
                continue
            
            # Look for PID (model) and serial number on the next line after switch identifier
            # Only capture the first PID/SN after seeing "Switch X" (the chassis info)
            # Format: PID: C9300-24T         , VID: V03  , SN: FOC2715Z6RN
            pid_sn_match = re.search(r'PID:\s*(\S+)\s*,.*?SN:\s+(\S+)', line)
            if pid_sn_match and current_switch and not found_chassis_info:
                model = pid_sn_match.group(1)
                serial = pid_sn_match.group(2)
                
                # Find matching member and update
                for member in members:
                    if member['switch_number'] == current_switch:
                        member['serial_number'] = serial
                        member['model'] = model
                        found_chassis_info = True  # Mark that we found the chassis info
                        _logger.debug(f"[STACK_DETECTION] Updated Switch {current_switch}: model={model}, serial={serial}")
                        break
                
                # Reset current_switch to avoid capturing module/SFP serial numbers
                if found_chassis_info:
                    current_switch = None
        
    except Exception as e:
        _logger.debug(f"Error adding serial numbers and models: {e}")
    
    return members


def add_serial_numbers_from_version(members: List[Dict], version_output: str, log: Any = None) -> List[Dict]:
    """
    Fallback function to extract serial numbers from 'show version' output.
    
    This function serves as a backup when 'show inventory' fails or doesn't contain
    the needed information. It supports various Cisco device types and formats.
    
    Supported formats:
    - IOS/IOS-XE Stack: Switch sections with "System serial number: XXX"
    - IOS-XE Single: "Processor board ID XXX" or "System Serial Number: XXX"
    - NX-OS: "Processor Board ID XXX"
    - ASA: "Serial Number: XXX"
    - WLC: "System Serial Number XXX"
    
    Args:
        members: List of stack member dictionaries to update
        version_output: Output from 'show version' command
        log: Logger instance
        
    Returns:
        Updated list of members with serial numbers and models
    """
    _logger = log or logger
    
    try:
        lines = version_output.split('\n')
        current_switch = None
        
        # Track which members still need serial numbers
        members_needing_serials = [m for m in members if m.get('serial_number') in ['unknown', '', None]]
        if not members_needing_serials:
            _logger.debug("[STACK_DETECTION] All members already have serial numbers")
            return members
        
        _logger.debug(f"[STACK_DETECTION] Attempting to extract serial numbers from version output for {len(members_needing_serials)} members")
        
        for i, line in enumerate(lines):
            line = line.strip()
            
            # Method 1: Stack format - Look for Switch sections
            # Format: "Switch 01" or "Switch 02" (C2960X, C3850, C9300, etc.)
            switch_match = re.search(r'^Switch\s+0?(\d+)', line, re.IGNORECASE)
            if switch_match:
                current_switch = int(switch_match.group(1))
                _logger.debug(f"[STACK_DETECTION] Found switch section: Switch {current_switch}")
                
                # Look ahead for serial number in the next 50 lines (C2960X has long switch sections)
                for j in range(i + 1, min(i + 51, len(lines))):
                    next_line = lines[j].strip()
                    
                    # Stop if we hit another switch section
                    if re.search(r'^Switch\s+0?\d+', next_line, re.IGNORECASE):
                        break
                    
                    # Look for various serial number patterns
                    # Order matters - more specific patterns first!
                    serial_patterns = [
                        r'System serial number\s*:\s*(\S+)',           # C2960X, C3850 - MOST SPECIFIC
                        r'System Serial Number\s*:\s*(\S+)',          # Some IOS-XE variants
                        r'Processor board ID\s+(\S+)',                # Common IOS format (but not for stacks usually)
                        # Note: Motherboard/Power supply serials are NOT the device serial
                    ]
                    
                    for pattern in serial_patterns:
                        serial_match = re.search(pattern, next_line, re.IGNORECASE)
                        if serial_match:
                            serial = serial_match.group(1)
                            
                            # Find the member for this switch and update (overwrite any previous value)
                            for member in members:
                                if member['switch_number'] == current_switch:
                                    old_serial = member.get('serial_number', 'unknown')
                                    member['serial_number'] = serial
                                    if old_serial != serial:
                                        _logger.info(f"[STACK_DETECTION] Updated Switch {current_switch} serial from version: {serial} (was: {old_serial})")
                                    break
                            break
                continue
            
            # Method 2: Single device format (fallback for non-stack or master device)
            # This handles cases where there's no "Switch X" section but we need the main serial
            if current_switch is None:
                single_device_patterns = [
                    r'System serial number\s*:\s*(\S+)',              # C2960X, C3850 - MOST SPECIFIC
                    r'System Serial Number\s*:\s*(\S+)',              # IOS-XE format
                    r'Processor board ID\s+(\S+)',                    # Most common IOS format (single devices)
                    r'Processor Board ID\s*:\s*(\S+)',                # NX-OS format
                    r'Serial Number\s*:\s*(\S+)',                     # ASA format
                ]
                
                for pattern in single_device_patterns:
                    serial_match = re.search(pattern, line, re.IGNORECASE)
                    if serial_match:
                        serial = serial_match.group(1)
                        
                        # Apply to first member that needs a serial (usually switch 1/master)
                        for member in members:
                            if member.get('serial_number') in ['unknown', '', None]:
                                member['serial_number'] = serial
                                _logger.info(f"[STACK_DETECTION] Updated Switch {member['switch_number']} serial from version (single device format): {serial}")
                                break
                        break
            
            # Method 3: Extract model information from stack table
            # Format: "*    1 54    WS-C2960XR-48FPS-I        15.2(7)E13            C2960X-UNIVERSALK9-M"
            stack_table_match = re.match(r'^\s*[\*]?\s*(\d+)\s+\d+\s+(\S+)\s+', line)
            if stack_table_match:
                switch_num = int(stack_table_match.group(1))
                model = stack_table_match.group(2)
                
                # Update model if not already set
                for member in members:
                    if member['switch_number'] == switch_num and member.get('model') in ['unknown', '', None]:
                        member['model'] = model
                        _logger.debug(f"[STACK_DETECTION] Updated Switch {switch_num} model from version: {model}")
                        break
        
        # Log results
        updated_count = 0
        for member in members:
            if member.get('serial_number') not in ['unknown', '', None]:
                updated_count += 1
        
        _logger.info(f"[STACK_DETECTION] Version output parsing complete: {updated_count}/{len(members)} members have serial numbers")
        
    except Exception as e:
        _logger.debug(f"Error extracting serial numbers from version output: {e}")
    
    return members


def extract_software_version(version_output: str, log: Any = None) -> Optional[str]:
    """
    Extract software version from 'show version' output.
    
    Handles various Cisco version formats:
    - Cisco IOS XE Software, Version 17.06.07
    - Cisco IOS Software, Version 15.2(4)E7
    - IOS-XE Version 16.12.04
    
    Args:
        version_output: Output from 'show version' command
        log: Logger instance
        
    Returns:
        Software version string or None
    """
    _logger = log or logger
    
    try:
        # Try different version patterns
        version_patterns = [
            r'(?:Cisco IOS XE Software|IOS-XE).*?Version\s+([\d.]+)',
            r'Cisco IOS Software.*?Version\s+([\d.()A-Z]+)',
            r'Version\s+([\d.]+)',
        ]
        
        for pattern in version_patterns:
            match = re.search(pattern, version_output, re.IGNORECASE)
            if match:
                version = match.group(1)
                _logger.debug(f"[STACK_DETECTION] Extracted software version: {version}")
                return version
        
        _logger.debug("[STACK_DETECTION] Could not extract software version from version output")
        return None
        
    except Exception as e:
        _logger.debug(f"Error extracting software version: {e}")
        return None


def parse_aruba_stack(conn: 'ConnectHandler', log: Any = None, discovery_logger: Any = None) -> Optional[Dict]:
    """
    Parse Aruba/HP stack information.
    """
    _logger = log or logger
    
    stack_info = {
        'vendor': 'aruba',
        'is_stack': False,
        'stack_members': [],
        'total_members': 0,
        'master_switch_number': None,
        'standby_switch_number': None,
        'stack_id': None,
        'raw_outputs': {}
    }
    
    try:
        # Aruba stacking command with CommandLogger
        _logger.info(f"[STACK_DETECTION] Executing 'show stacking' on {conn.host}")
        
        if discovery_logger:
            try:
                from nautobot_inventory.utils import CommandLogger
                with CommandLogger(discovery_logger, conn.host, 'stack_detection') as cmd_logger:
                    cmd_logger.set_command('show stacking')
                    stack_output = conn.send_command('show stacking', delay_factor=1)
                    cmd_logger.set_output(stack_output)
            except ImportError:
                stack_output = conn.send_command('show stacking', delay_factor=1)
        else:
            stack_output = conn.send_command('show stacking', delay_factor=1)
        
        stack_info['raw_outputs']['show stacking'] = stack_output
        
        if not stack_output or 'not stacked' in stack_output.lower():
            return None
        
        members = []
        lines = stack_output.split('\n')
        
        for line in lines:
            line = line.strip()
            
            # Extract stack ID
            if 'Stack ID' in line:
                stack_id_match = re.search(r'Stack ID\s*:\s*([0-9a-fA-F-]+)', line)
                if stack_id_match:
                    stack_info['stack_id'] = stack_id_match.group(1)
            
            # Match member lines
            # Format: "1      Active   2930F-48G   128   001122334455      SG18K12345 Commander"
            match = re.match(r'^(\d+)\s+(Active|Standby|Member)\s+(\S+)\s+(\d+)\s+([0-9a-fA-F]+)\s+(\S+)\s+(\S+)', line)
            
            if match:
                member_id = int(match.group(1))
                state = match.group(2).lower()
                model = match.group(3)
                priority = int(match.group(4))
                mac_address = match.group(5)
                serial_number = match.group(6)
                role = match.group(7).lower()
                
                member = {
                    'switch_number': member_id,
                    'role': role,
                    'state': state,
                    'model': model,
                    'priority': priority,
                    'mac_address': mac_address,
                    'serial_number': serial_number,
                    'is_master': role == 'commander' or state == 'active'
                }
                
                members.append(member)
                
                if member['is_master']:
                    stack_info['master_switch_number'] = member_id
                elif role == 'standby' or state == 'standby':
                    stack_info['standby_switch_number'] = member_id
        
        if members:
            stack_info['is_stack'] = True
            stack_info['total_members'] = len(members)
            stack_info['stack_members'] = members
            
            _logger.info(
                f"Detected Aruba stack with {len(members)} members. "
                f"Commander: Switch {stack_info['master_switch_number']}"
            )
            
            return stack_info
        
        return None
        
    except Exception as e:
        _logger.error(f"Error parsing Aruba stack: {e}")
        return None

