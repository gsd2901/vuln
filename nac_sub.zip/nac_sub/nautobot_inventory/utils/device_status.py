"""
Device Status Utility Module

Centralized constants and helper functions for determining device status
across the nautobot_inventory application.
"""

# Device status constants
FAILED_CONNECTION_STATUSES = ['failed', 'cancelled', 'unreachable']

# Hostname prefixes that indicate device failure states
FAILED_HOSTNAME_PREFIXES = [
    'unreachable-',
    'failed-',
    'auth-failed-',
    'timeout-',
    'error-',
]


def is_device_failed(device):
    """
    Check if a device is in a failed state and should not be onboarded.
    
    Args:
        device: A DiscoveredDevice instance or object with connection_status and hostname attributes
        
    Returns:
        bool: True if device is in a failed state, False otherwise
    """
    # Check connection status
    if hasattr(device, 'connection_status') and device.connection_status in FAILED_CONNECTION_STATUSES:
        return True
    
    # Check hostname patterns for failed devices
    if hasattr(device, 'hostname') and device.hostname:
        if any(device.hostname.startswith(prefix) for prefix in FAILED_HOSTNAME_PREFIXES):
            return True
    
    return False


def get_failed_device_type(device):
    """
    Determine the specific type of failure for a device.
    
    Args:
        device: A DiscoveredDevice instance or object with connection_status and hostname attributes
        
    Returns:
        str: The failure type ('unreachable', 'auth_failed', 'timeout', 'error', 'cancelled', 'failed', or None)
    """
    if not is_device_failed(device):
        return None
    
    # Check hostname patterns first for specific error types
    if hasattr(device, 'hostname') and device.hostname:
        if device.hostname.startswith('unreachable-'):
            return 'unreachable'
        elif device.hostname.startsWith('auth-failed-'):
            return 'auth_failed'
        elif device.hostname.startswith('timeout-'):
            return 'timeout'
        elif device.hostname.startswith('error-'):
            return 'error'
        elif device.hostname.startswith('failed-'):
            return 'failed'
    
    # Check connection status
    if hasattr(device, 'connection_status'):
        if device.connection_status == 'unreachable':
            return 'unreachable'
        elif device.connection_status == 'cancelled':
            return 'cancelled'
        elif device.connection_status == 'failed':
            return 'failed'
    
    return 'failed'  # Default fallback

