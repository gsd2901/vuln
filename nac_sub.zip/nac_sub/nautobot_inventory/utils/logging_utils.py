"""
Comprehensive logging utilities for network inventory discovery.

This module provides all logging utilities for the application:
- DiscoveryLogger: For network discovery operations with file-based logging
- CommandLogger: For individual command executions with timing
- NetmikoLoggingManager: For managing netmiko debug logging
- InventoryLogger: Standardized logger for general operations
- DeviceOperationLogger: Specialized logger for device operations
- JobOperationLogger: Specialized logger for job operations
"""

import logging
import os
import sys
from datetime import datetime
from typing import Dict, Any, Optional, List
from django.conf import settings


class DiscoveryLogger:
    """
    Centralized logger for network discovery operations.
    Provides structured logging with device context and command tracking.
    """
    
    # Logger configuration constants
    LOGGER_CONFIGS = {
        'command': {'filename': 'command_execution.log', 'format': '%(asctime)s | %(message)s'},
        'neighbor': {'filename': 'neighbor_discovery.log', 'format': '%(asctime)s | %(message)s'},
        'interface': {'filename': 'interface_analysis.log', 'format': '%(asctime)s | %(message)s'},
        'connection': {'filename': 'device_connections.log', 'format': '%(asctime)s | %(message)s'},
        'error': {'filename': 'discovery_errors.log', 'format': '%(asctime)s | %(levelname)s | %(message)s'},
    }
    
    # Logging level controls for optimization
    LOG_LEVELS = {
        'netmiko_debug': False,  # Disable netmiko debug by default
        'command_output': True,  # Keep command output but make it configurable
        'detailed_output': False,  # Disable line-by-line output logging
        'connection_debug': False,  # Disable connection establishment debug
    }
    
    def __init__(self, session_id: str, log_levels: Dict[str, bool] = None):
        self.session_id = session_id
        self.log_dir = os.path.join(settings.BASE_DIR, 'logs')
        self.loggers: Dict[str, logging.Logger] = {}
        self.handlers: List[logging.Handler] = []
        
        # Override default log levels if provided
        if log_levels:
            self.LOG_LEVELS.update(log_levels)
        
        os.makedirs(self.log_dir, exist_ok=True)
        self._configure_logging_levels()
        self._setup_loggers()
    
    def _configure_logging_levels(self):
        """Configure logging levels to suppress console debug output."""
        loggers_to_suppress = ['netmiko', 'paramiko']
        
        for logger_name in loggers_to_suppress:
            logger = logging.getLogger(logger_name)
            logger.setLevel(logging.WARNING)
        
        # Configure root logger
        root_logger = logging.getLogger()
        root_logger.setLevel(logging.INFO)
        
        # Remove console handlers from root logger
        for handler in root_logger.handlers[:]:
            if isinstance(handler, logging.StreamHandler) and handler.stream == sys.stdout:
                root_logger.removeHandler(handler)
    
    def _setup_loggers(self):
        """Setup specialized loggers for different types of operations."""
        for logger_type, config in self.LOGGER_CONFIGS.items():
            logger_name = f'discovery.{logger_type}s.{self.session_id}'
            self.loggers[logger_type] = self._create_logger(
                name=logger_name,
                filename=config['filename'],
                format_string=config['format']
            )
    
    def _create_logger(self, name: str, filename: str, format_string: str) -> logging.Logger:
        """Create a logger with file handler and custom formatting."""
        logger = logging.getLogger(name)
        logger.setLevel(logging.INFO)
        
        # Remove existing handlers to avoid duplicates
        self._cleanup_logger_handlers(logger)
        
        # Create file handler
        log_file = os.path.join(self.log_dir, filename)
        file_handler = logging.FileHandler(log_file)
        file_handler.setLevel(logging.INFO)
        
        # Set formatter and add handler
        formatter = logging.Formatter(format_string)
        file_handler.setFormatter(formatter)
        logger.addHandler(file_handler)
        logger.propagate = False
        
        # Track handler for cleanup
        self.handlers.append(file_handler)
        
        return logger
    
    def _cleanup_logger_handlers(self, logger: logging.Logger):
        """Clean up existing handlers from a logger."""
        for handler in logger.handlers[:]:
            handler.close()
            logger.removeHandler(handler)
    
    def _format_log_message(self, log_type: str, device_ip: str, hostname: str, 
                           **kwargs) -> str:
        """Format log message with common device context."""
        device_context = f"Device: {hostname}({device_ip})"
        timestamp = f"Timestamp: {datetime.now().isoformat()}"
        
        # Build message parts
        parts = [log_type, device_context]
        
        # Add optional parameters
        for key, value in kwargs.items():
            if value is not None:
                if key == 'duration':
                    parts.append(f"{key.title()}: {value:.2f}s")
                elif key == 'error':
                    parts.append(f"Error: {value}")
                else:
                    parts.append(f"{key.title()}: {value}")
        
        # Add timestamp for certain log types
        if log_type in ['NEIGHBOR_START', 'NEIGHBOR_COMPLETE', 'INTERFACE_START', 
                       'INTERFACE_COMPLETE', 'SESSION_COMPLETE']:
            parts.append(timestamp)
        
        return " | ".join(parts)
    
    def _log_with_status(self, logger_type: str, log_type: str, device_ip: str, 
                        hostname: str, success: bool, **kwargs):
        """Generic method for logging with success/failure status."""
        status = "SUCCESS" if success else "FAILED"
        self.loggers[logger_type].info(
            self._format_log_message(log_type, device_ip, hostname, 
                                   status=status, **kwargs)
        )
    
    def log_command_execution(self, device_ip: str, hostname: str, command: str, 
                            success: bool, duration: float = None, error: str = None,
                            output: str = None):
        """Log command execution with device context."""
        self._log_with_status(
            'command', 'COMMAND_EXEC', device_ip, hostname, success,
            command=command, duration=duration, error=error
        )
        
        # Log detailed command output if provided
        if output and success:
            self.log_command_output(device_ip, hostname, command, output)
    
    def log_command_output(self, device_ip: str, hostname: str, command: str, output: str):
        """Log command output with configurable verbosity."""
        if not self.LOG_LEVELS['command_output']:
            return
            
        # Log command summary instead of full output for most commands
        output_lines = output.strip().split('\n')
        non_empty_lines = [line for line in output_lines if line.strip()]
        
        if self.LOG_LEVELS['detailed_output']:
            # Full detailed logging (original behavior)
            self.loggers['command'].info(
                f"COMMAND_OUTPUT_START | Device: {hostname}({device_ip}) | Command: {command}"
            )
            
            for line in non_empty_lines:
                self.loggers['command'].info(f"OUTPUT | {line}")
            
            self.loggers['command'].info(
                f"COMMAND_OUTPUT_END | Device: {hostname}({device_ip}) | Command: {command}"
            )
        else:
            # Optimized logging - only log summary and first few lines
            self.loggers['command'].info(
                f"COMMAND_OUTPUT | Device: {hostname}({device_ip}) | Command: {command} | Lines: {len(non_empty_lines)}"
            )
            
            # Log only first 3 lines and last 3 lines for context
            if len(non_empty_lines) > 6:
                for line in non_empty_lines[:3]:
                    self.loggers['command'].info(f"OUTPUT | {line}")
                self.loggers['command'].info("OUTPUT | ... (truncated for brevity) ...")
                for line in non_empty_lines[-3:]:
                    self.loggers['command'].info(f"OUTPUT | {line}")
            else:
                for line in non_empty_lines:
                    self.loggers['command'].info(f"OUTPUT | {line}")
    
    def log_netmiko_debug(self, device_ip: str, hostname: str, debug_message: str):
        """Log netmiko debug messages to command execution log (configurable)."""
        if not self.LOG_LEVELS['netmiko_debug']:
            return
            
        # Only log important netmiko debug messages, skip routine ones
        important_patterns = ['error', 'exception', 'timeout', 'failed', 'connection']
        if any(pattern in debug_message.lower() for pattern in important_patterns):
            self.loggers['command'].debug(
                f"NETMIKO_DEBUG | Device: {hostname}({device_ip}) | {debug_message}"
            )
    
    def log_connection_establishment(self, device_ip: str, hostname: str, connection_type: str, 
                                   success: bool, duration: float = None, error: str = None):
        """Log detailed connection establishment process."""
        self._log_with_status(
            'command', 'CONNECTION_ESTABLISH', device_ip, hostname, success,
            type=connection_type, duration=duration, error=error
        )
    
    def log_neighbor_discovery_start(self, device_ip: str, hostname: str):
        """Log start of neighbor discovery for a device."""
        self.loggers['neighbor'].info(
            self._format_log_message('NEIGHBOR_START', device_ip, hostname)
        )
    
    def log_neighbor_discovery_complete(self, device_ip: str, hostname: str, 
                                      cdp_count: int, lldp_count: int, 
                                      neighbor_ips: list):
        """Log completion of neighbor discovery."""
        total_neighbors = cdp_count + lldp_count
        neighbor_list = ','.join(neighbor_ips) if neighbor_ips else 'None'
        
        self.loggers['neighbor'].info(
            self._format_log_message('NEIGHBOR_COMPLETE', device_ip, hostname,
                                   cdp=cdp_count, lldp=lldp_count, 
                                   total=total_neighbors, neighbor_ips=neighbor_list)
        )
    
    def log_interface_analysis_start(self, device_ip: str, hostname: str):
        """Log start of interface analysis."""
        self.loggers['interface'].info(
            self._format_log_message('INTERFACE_START', device_ip, hostname)
        )
    
    def log_interface_analysis_complete(self, device_ip: str, hostname: str, 
                                      interface_count: int, analysis_data: Dict[str, Any]):
        """Log completion of interface analysis."""
        summary = self._format_interface_summary(analysis_data)
        
        self.loggers['interface'].info(
            self._format_log_message('INTERFACE_COMPLETE', device_ip, hostname,
                                   interface_count=interface_count, summary=summary)
        )
    
    def log_device_connection(self, device_ip: str, hostname: str, 
                            connection_type: str, success: bool, 
                            duration: float = None, error: str = None):
        """Log device connection attempts."""
        self._log_with_status(
            'connection', 'CONNECTION', device_ip, hostname, success,
            type=connection_type, duration=duration, error=error
        )
    
    def log_discovery_error(self, device_ip: str, hostname: str, 
                          error_type: str, error_message: str, 
                          context: str = None):
        """Log discovery errors with context."""
        self.loggers['error'].error(
            self._format_log_message('DISCOVERY_ERROR', device_ip, hostname,
                                   type=error_type, message=error_message, context=context)
        )
    
    def log_session_summary(self, total_devices: int, successful: int, 
                          failed: int, duration: float):
        """Log session completion summary."""
        self.loggers['connection'].info(
            f"SESSION_COMPLETE | SessionID: {self.session_id} | "
            f"TotalDevices: {total_devices} | Successful: {successful} | "
            f"Failed: {failed} | Duration: {duration:.2f}s | "
            f"Timestamp: {datetime.now().isoformat()}"
        )
    
    def _format_interface_summary(self, analysis_data: Dict[str, Any]) -> str:
        """Format interface analysis data for logging."""
        if not analysis_data:
            return "NoData"
        
        summary_parts = []
        
        # Port counts
        port_counts = analysis_data.get('port_counts', {})
        if port_counts:
            for port_type, count in port_counts.items():
                if count > 0:
                    summary_parts.append(f"{port_type}: {count}")
        
        # VLAN count
        vlans = analysis_data.get('vlans', [])
        if vlans:
            summary_parts.append(f"VLANs: {len(vlans)}")
        
        # PoE info
        poe_info = analysis_data.get('poe_summary', {})
        if poe_info.get('total_ports', 0) > 0:
            summary_parts.append(f"PoE: {poe_info.get('powered_ports', 0)}/{poe_info.get('total_ports', 0)}")
        
        return " | ".join(summary_parts) if summary_parts else "BasicAnalysis"
    
    def configure_for_discovery(self, verbose: bool = False):
        """Configure logging levels specifically for discovery jobs."""
        if verbose:
            # Full logging for debugging
            self.LOG_LEVELS.update({
                'netmiko_debug': True,
                'command_output': True,
                'detailed_output': True,
                'connection_debug': True,
            })
        else:
            # Optimized logging for production
            self.LOG_LEVELS.update({
                'netmiko_debug': False,
                'command_output': True,
                'detailed_output': False,
                'connection_debug': False,
            })
    
    def cleanup(self):
        """Clean up all logger handlers and resources."""
        # Clean up all tracked handlers
        for handler in self.handlers:
            try:
                handler.close()
            except Exception:
                pass  # Ignore errors during cleanup
        
        # Clean up all loggers
        for logger in self.loggers.values():
            self._cleanup_logger_handlers(logger)
        
        # Clear tracking lists
        self.handlers.clear()
        self.loggers.clear()
    
    def __enter__(self):
        """Context manager entry."""
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit with automatic cleanup."""
        self.cleanup()


class CommandLogger:
    """
    Utility class for logging individual command executions.
    Provides context management for command timing and error handling.
    """
    
    def __init__(self, discovery_logger: DiscoveryLogger, device_ip: str, hostname: str):
        self.discovery_logger = discovery_logger
        self.device_ip = device_ip
        self.hostname = hostname
        self.start_time = None
        self.command = None
        self.output = None
    
    def __enter__(self):
        self.start_time = datetime.now()
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        if self.command and self.start_time:
            duration = (datetime.now() - self.start_time).total_seconds()
            success = exc_type is None
            error = str(exc_val) if exc_val else None
            
            self.discovery_logger.log_command_execution(
                self.device_ip, self.hostname, self.command, 
                success, duration, error, self.output
            )
    
    def set_command(self, command: str):
        """Set the command being executed."""
        self.command = command
        return self
    
    def set_output(self, output: str):
        """Set the command output."""
        self.output = output
        return self


class NetmikoLoggingManager:
    """
    Manages netmiko logging configuration and cleanup.
    """
    
    def __init__(self, discovery_logger: DiscoveryLogger):
        self.discovery_logger = discovery_logger
        self.netmiko_logger = logging.getLogger('netmiko')
        self.original_level = self.netmiko_logger.level
        self.handlers = []
    
    def setup_for_device(self, device_ip: str, hostname: str):
        """Setup netmiko logging for a specific device."""
        # Clean up existing handlers
        self.cleanup()
        
        # Configure netmiko logger
        self.netmiko_logger.setLevel(logging.DEBUG)
        
        # Create file handler
        log_file = os.path.join(self.discovery_logger.log_dir, 'command_execution.log')
        file_handler = logging.FileHandler(log_file)
        file_handler.setLevel(logging.DEBUG)
        
        # Create formatter
        formatter = logging.Formatter('%(asctime)s | %(message)s')
        file_handler.setFormatter(formatter)
        
        # Add device context filter
        class DeviceContextFilter(logging.Filter):
            def __init__(self, device_ip, hostname):
                self.device_ip = device_ip
                self.hostname = hostname
            
            def filter(self, record):
                record.msg = f"NETMIKO_DEBUG | Device: {self.hostname}({self.device_ip}) | {record.msg}"
                return True
        
        file_handler.addFilter(DeviceContextFilter(device_ip, hostname))
        self.netmiko_logger.addHandler(file_handler)
        self.netmiko_logger.propagate = False
        
        # Track handler for cleanup
        self.handlers.append(file_handler)
    
    def cleanup(self):
        """Clean up netmiko logging handlers."""
        for handler in self.handlers:
            try:
                handler.close()
                self.netmiko_logger.removeHandler(handler)
            except Exception:
                pass  # Ignore errors during cleanup
        
        self.handlers.clear()
        self.netmiko_logger.setLevel(self.original_level)
    
    def __enter__(self):
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        self.cleanup()


# Factory functions for backward compatibility
def get_discovery_logger(session_id: str, log_levels: Dict[str, bool] = None) -> DiscoveryLogger:
    """
    Factory function to get or create a discovery logger for a session.
    """
    return DiscoveryLogger(session_id, log_levels)


def setup_netmiko_logging(discovery_logger: DiscoveryLogger, device_ip: str, hostname: str):
    """
    Setup netmiko logging to redirect debug output to our log files.
    Deprecated: Use NetmikoLoggingManager for better resource management.
    """
    manager = NetmikoLoggingManager(discovery_logger)
    manager.setup_for_device(device_ip, hostname)
    return manager


def cleanup_netmiko_logging():
    """
    Clean up netmiko logging handlers.
    Deprecated: Use NetmikoLoggingManager for better resource management.
    """
    netmiko_logger = logging.getLogger('netmiko')
    for handler in netmiko_logger.handlers[:]:
        handler.close()
        netmiko_logger.removeHandler(handler)
    netmiko_logger.setLevel(logging.WARNING)


class InventoryLogger:
    """Standardized logger for network inventory operations."""
    
    def __init__(self, name: str = 'nautobot_inventory', level: int = logging.INFO):
        self.logger = logging.getLogger(name)
        self.logger.setLevel(level)
        
        # Only add handler if not already present
        if not self.logger.handlers:
            handler = logging.StreamHandler(sys.stdout)
            formatter = logging.Formatter(
                '%(asctime)s - %(name)s - %(levelname)s - %(message)s',
                datefmt='%Y-%m-%d %H:%M:%S'
            )
            handler.setFormatter(formatter)
            self.logger.addHandler(handler)
    
    def info(self, message: str, context: Optional[Dict[str, Any]] = None):
        """Log an info message with optional context."""
        formatted_message = self._format_message(message, context)
        self.logger.info(formatted_message)
    
    def warning(self, message: str, context: Optional[Dict[str, Any]] = None):
        """Log a warning message with optional context."""
        formatted_message = self._format_message(message, context)
        self.logger.warning(formatted_message)
    
    def error(self, message: str, context: Optional[Dict[str, Any]] = None):
        """Log an error message with optional context."""
        formatted_message = self._format_message(message, context)
        self.logger.error(formatted_message)
    
    def debug(self, message: str, context: Optional[Dict[str, Any]] = None):
        """Log a debug message with optional context."""
        formatted_message = self._format_message(message, context)
        self.logger.debug(formatted_message)
    
    def _format_message(self, message: str, context: Optional[Dict[str, Any]] = None) -> str:
        """Format message with context information."""
        if context:
            context_str = " | ".join([f"{k}={v}" for k, v in context.items()])
            return f"{message} | {context_str}"
        return message


class DeviceOperationLogger(InventoryLogger):
    """Specialized logger for device operations."""
    
    def log_device_operation(self, operation: str, device_ip: str, 
                           status: str, message: str, 
                           additional_context: Optional[Dict[str, Any]] = None):
        """Log a device operation with standardized context."""
        context = {
            'operation': operation,
            'device_ip': device_ip,
            'status': status
        }
        
        if additional_context:
            context.update(additional_context)
        
        if status in ['success', 'completed']:
            self.info(f"✅ {message}", context)
        elif status in ['warning', 'retry']:
            self.warning(f"⚠️ {message}", context)
        elif status in ['error', 'failed']:
            self.error(f"❌ {message}", context)
        else:
            self.info(f"ℹ️ {message}", context)
    
    def log_job_trigger(self, job_type: str, device_ip: str, job_id: Optional[str] = None):
        """Log job triggering with standardized format."""
        context = {'job_type': job_type, 'device_ip': device_ip}
        if job_id:
            context['job_id'] = job_id
        
        self.info(f"🚀 Triggered {job_type} job", context)
    
    def log_device_validation(self, device_ip: str, method: str, success: bool, 
                            device_name: Optional[str] = None):
        """Log device validation results."""
        context = {
            'device_ip': device_ip,
            'validation_method': method,
            'success': success
        }
        
        if device_name:
            context['device_name'] = device_name
        
        if success:
            self.info(f"✅ Device validation successful using {method}", context)
        else:
            self.warning(f"⚠️ Device validation failed using {method}", context)


class JobOperationLogger(InventoryLogger):
    """Specialized logger for job operations."""
    
    def log_job_status(self, job_type: str, job_id: str, status: str, 
                      device_ip: Optional[str] = None, message: Optional[str] = None):
        """Log job status updates."""
        context = {
            'job_type': job_type,
            'job_id': job_id,
            'status': status
        }
        
        if device_ip:
            context['device_ip'] = device_ip
        
        if message:
            formatted_message = message
        else:
            formatted_message = f"{job_type} job {status}"
        
        if status == 'success':
            self.info(f"✅ {formatted_message}", context)
        elif status == 'failure':
            self.error(f"❌ {formatted_message}", context)
        elif status == 'pending':
            self.info(f"⏳ {formatted_message}", context)
        else:
            self.info(f"ℹ️ {formatted_message}", context)
    
    def log_job_verification(self, job_id: str, verification_result: Dict[str, Any], 
                           device_ip: str):
        """Log job verification results."""
        context = {
            'job_id': job_id,
            'device_ip': device_ip,
            'verification_method': verification_result.get('verification_method'),
            'devices_processed': verification_result.get('devices_processed', 0)
        }
        
        if verification_result.get('is_successful'):
            self.info(f"✅ Job verification successful", context)
        else:
            self.warning(f"⚠️ Job verification failed", context)


class OnboardingLogger:
    """
    Specialized logger for onboarding jobs and operations.
    Writes to a separate log file to keep onboarding logs separate from main application logs.
    Uses singleton pattern to prevent duplicate handlers.
    """
    
    _instances = {}
    _initialized_loggers = set()
    
    def __new__(cls, name: str = 'nautobot_inventory.onboarding', level: int = logging.INFO):
        """Implement singleton pattern to prevent duplicate instances."""
        if name not in cls._instances:
            cls._instances[name] = super(OnboardingLogger, cls).__new__(cls)
        return cls._instances[name]
    
    def __init__(self, name: str = 'nautobot_inventory.onboarding', level: int = logging.INFO):
        # Only initialize once per logger name
        if name in self._initialized_loggers:
            return
            
        self.logger = logging.getLogger(name)
        self.logger.setLevel(level)
        
        # Create logs directory if it doesn't exist
        log_dir = os.path.join(settings.BASE_DIR, 'logs')
        os.makedirs(log_dir, exist_ok=True)
        
        # Clear any existing handlers to prevent duplicates
        self.logger.handlers.clear()
        
        # Add file handler
        log_file = os.path.join(log_dir, 'onboarding_jobs.log')
        file_handler = logging.FileHandler(log_file)
        file_handler.setLevel(level)
        
        formatter = logging.Formatter(
            '%(asctime)s - %(name)s - %(levelname)s - %(message)s',
            datefmt='%Y-%m-%d %H:%M:%S'
        )
        file_handler.setFormatter(formatter)
        self.logger.addHandler(file_handler)
        
        # Prevent propagation to root logger to avoid duplicate logs
        self.logger.propagate = False
        
        # Mark this logger as initialized
        self._initialized_loggers.add(name)
    
    def info(self, message: str, context: Optional[Dict[str, Any]] = None):
        """Log an info message with optional context."""
        formatted_message = self._format_message(message, context)
        self.logger.info(formatted_message)
    
    def warning(self, message: str, context: Optional[Dict[str, Any]] = None):
        """Log a warning message with optional context."""
        formatted_message = self._format_message(message, context)
        self.logger.warning(formatted_message)
    
    def error(self, message: str, context: Optional[Dict[str, Any]] = None):
        """Log an error message with optional context."""
        formatted_message = self._format_message(message, context)
        self.logger.error(formatted_message)
    
    def debug(self, message: str, context: Optional[Dict[str, Any]] = None):
        """Log a debug message with optional context."""
        formatted_message = self._format_message(message, context)
        self.logger.debug(formatted_message)
    
    def _format_message(self, message: str, context: Optional[Dict[str, Any]] = None) -> str:
        """Format message with context information."""
        if context:
            context_str = " | ".join([f"{k}={v}" for k, v in context.items()])
            return f"{message} | {context_str}"
        return message
    
    def log_job_trigger(self, job_type: str, device_ip: str = None, job_id: Optional[str] = None, 
                       device_count: Optional[int] = None):
        """Log job triggering with standardized format."""
        context = {'job_type': job_type}
        if device_ip:
            context['device_ip'] = device_ip
        if job_id:
            context['job_id'] = job_id
        if device_count:
            context['device_count'] = device_count
        
        self.info(f"🚀 Triggered {job_type} job", context)
    
    def log_job_status(self, job_type: str, job_id: str, status: str, 
                      device_ip: Optional[str] = None, message: Optional[str] = None,
                      device_count: Optional[int] = None):
        """Log job status updates."""
        context = {
            'job_type': job_type,
            'job_id': job_id,
            'status': status
        }
        
        if device_ip:
            context['device_ip'] = device_ip
        
        if device_count:
            context['device_count'] = device_count
        
        if message:
            formatted_message = message
        else:
            formatted_message = f"{job_type} job {status}"
        
        if status == 'success':
            self.info(f"✅ {formatted_message}", context)
        elif status == 'failure':
            self.error(f"❌ {formatted_message}", context)
        elif status == 'pending':
            self.info(f"⏳ {formatted_message}", context)
        else:
            self.info(f"ℹ️ {formatted_message}", context)
    
    def log_bulk_operation(self, operation: str, batch_number: Optional[int] = None,
                          device_count: Optional[int] = None, status: str = None):
        """Log bulk onboarding operations."""
        context = {'operation': operation}
        if batch_number:
            context['batch_number'] = batch_number
        if device_count:
            context['device_count'] = device_count
        if status:
            context['status'] = status
        
        self.info(f"📦 Bulk {operation}", context)


# Global logger instances
inventory_logger = InventoryLogger('nautobot_inventory')
device_logger = DeviceOperationLogger('nautobot_inventory.device')
job_logger = JobOperationLogger('nautobot_inventory.job')
onboarding_logger = OnboardingLogger('nautobot_inventory.onboarding')
