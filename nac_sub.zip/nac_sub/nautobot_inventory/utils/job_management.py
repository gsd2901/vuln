"""
Job management utilities for network inventory discovery.

This module provides utilities for managing job triggering, verification,
and status checking for network inventory operations.
"""

import logging
from typing import Optional, Dict, Any, List
from django.core.cache import cache
from django.contrib.contenttypes.models import ContentType
from django.utils import timezone
from django.conf import settings

from nautobot.extras.models import Job, JobResult
from nautobot.extras.choices import JobResultStatusChoices
from nautobot.dcim.models import Device, Interface
from nautobot.ipam.models import IPAddress
from nautobot.extras.models import Status
from .error_handler import ErrorHandler
from nautobot_inventory.utils.stack_utils import create_stack_members
from .logging_utils import onboarding_logger


class JobManagementUtils:
    """Utilities for managing jobs in network inventory operations."""
    
    def __init__(self, session=None, logger_name: str = 'nautobot_inventory.job_management'):
        self.logger = logging.getLogger(logger_name)
        self.error_handler = ErrorHandler(logger_name)
        self.max_bulk_devices = self._get_max_bulk_devices()
        self.session = session
    
    def _get_max_bulk_devices(self) -> int:
        """Get the maximum bulk devices setting from plugin configuration."""
        try:
            plugin_config = getattr(settings, 'PLUGINS_CONFIG', {}).get('nautobot_inventory', {})
            return plugin_config.get('max_bulk_devices', 50)  # Default to 50 if not configured
        except Exception:
            return 50  # Fallback default
    
    def trigger_bulk_device_sync_job(self, session_id: str, device_ips: List[str], 
                                   device_names: List[str], user) -> Optional[str]:
        """
        Trigger the SSOTSyncDevices job for multiple devices in a single batch.
        
        Args:
            session_id: Session ID for caching
            device_ips: List of IP addresses of the devices
            device_names: List of names of the devices
            user: User triggering the job
            
        Returns:
            Job result ID if successful, None otherwise
        """
        try:
            if not device_ips or len(device_ips) == 0:
                onboarding_logger.error("❌ No device IPs provided for bulk sync job")
                return None
                
            if len(device_ips) > self.max_bulk_devices:
                onboarding_logger.error(f"❌ Too many devices ({len(device_ips)}). Maximum allowed: {self.max_bulk_devices}")
                return None
                
            onboarding_logger.log_job_trigger("bulk_device_sync", device_count=len(device_ips))
            
            # Get cached device sync job parameters from the first device
            cache_key = f"device_sync_job_{session_id}_{device_ips[0]}"
            device_sync_job_data = cache.get(cache_key)
            
            if not device_sync_job_data:
                onboarding_logger.error(f"❌ No cached device sync job parameters for session {session_id}")
                return None
                
            onboarding_logger.debug(f"✅ Found cached job data for bulk sync")
            
            # Find the job model
            job_model = self._find_device_sync_job_model()
            if not job_model:
                onboarding_logger.error("SSOTSyncDevices job model not found")
                return None
                
            # Prepare bulk job data
            job_data = self._prepare_bulk_device_sync_job_data(
                device_sync_job_data, device_ips, device_names
            )
            
            # Trigger the bulk job
            job_result = self._execute_bulk_device_sync_job(job_model, job_data, user)
            
            if job_result:
                # Clear the cache after successful job execution
                for device_ip in device_ips:
                    cache_key = f"device_sync_job_{session_id}_{device_ip}"
                    cache.delete(cache_key)
                onboarding_logger.log_job_status("bulk_device_sync", str(job_result.id), "success", device_count=len(device_ips))
                return str(job_result.id)
            else:
                onboarding_logger.error(f"Failed to trigger bulk device sync job")
                return None
                
        except Exception as e:
            error_info = self.error_handler.log_and_create_error_response(
                e, f"triggering bulk device sync job for {len(device_ips)} devices"
            )
            onboarding_logger.error(f"Error triggering bulk device sync job: {e}")
            return None

    def trigger_bulk_network_data_job(self, session_id: str, device_data: List[Dict[str, Any]], user) -> Optional[str]:
        """
        Trigger the SSOTSyncNetworkData job for multiple devices in a single batch.
        
        Args:
            session_id: Session ID for caching
            device_data: List of device data dictionaries containing ip, name, and device_id
            user: User triggering the job
            
        Returns:
            Job result ID if successful, None otherwise
        """
        try:
            if not device_data or len(device_data) == 0:
                onboarding_logger.error("❌ No device data provided for bulk network data job")
                return None
                
            if len(device_data) > self.max_bulk_devices:
                onboarding_logger.error(f"❌ Too many devices ({len(device_data)}). Maximum allowed: {self.max_bulk_devices}")
                return None
                
            onboarding_logger.log_job_trigger("bulk_network_data", device_count=len(device_data))
            
            # Get cached network data job parameters from the first device
            first_device = device_data[0]
            cache_key = f"network_data_job_{session_id}_{first_device['ip']}"
            network_data_job_data = cache.get(cache_key)
            
            if not network_data_job_data:
                onboarding_logger.error(f"❌ No cached network data job parameters for session {session_id}")
                return None
                
            onboarding_logger.debug(f"✅ Found cached job data for bulk network data sync")
            
            # Validate all devices exist in database
            device_ids = []
            for device_info in device_data:
                if not device_info.get('device_id'):
                    onboarding_logger.error(f"❌ No device_id provided for {device_info.get('ip')}")
                    return None
                    
                device_obj = self._wait_for_device_commitment(device_info['ip'], device_info['device_id'])
                if not device_obj:
                    onboarding_logger.error(f"❌ Device {device_info['ip']} not found in database")
                    return None
                    
                device_ids.append(str(device_obj.id))
                
            # Find the job model
            job_model = self._find_network_data_job_model()
            if not job_model:
                onboarding_logger.error("SSOTSyncNetworkData job model not found")
                return None
                
            # Prepare bulk job data
            job_data = self._prepare_bulk_network_data_job_data(
                network_data_job_data, device_ids, device_data
            )
            
            # Trigger the bulk job
            job_result = self._execute_network_data_job(job_model, job_data, user)
            
            if job_result:
                # Clear the cache after successful job execution
                for device_info in device_data:
                    cache_key = f"network_data_job_{session_id}_{device_info['ip']}"
                    cache.delete(cache_key)
                onboarding_logger.log_job_status("bulk_network_data", str(job_result.id), "success", device_count=len(device_data))
                return str(job_result.id)
            else:
                onboarding_logger.error(f"Failed to trigger bulk network data job")
                return None
                
        except Exception as e:
            error_info = self.error_handler.log_and_create_error_response(
                e, f"triggering bulk network data job for {len(device_data)} devices"
            )
            onboarding_logger.error(f"Error triggering bulk network data job: {e}")
            return None

    def trigger_network_data_job(self, session_id: str, device_ip: str, 
                                device_name: str, user, device_id: Optional[int] = None) -> Optional[str]:
        """
        Trigger the SSOTSyncNetworkData job for a device.
        
        Args:
            session_id: Session ID for caching
            device_ip: IP address of the device
            device_name: Name of the device
            user: User triggering the job
            device_id: Optional device ID (REQUIRED for proper job execution)
            
        Returns:
            Job result ID if successful, None otherwise
        """
        try:
            onboarding_logger.log_job_trigger("network_data", device_ip=device_ip)
            
            # CRITICAL CHECK: We must have a device_id
            if not device_id:
                onboarding_logger.error(f"❌ CRITICAL: No device_id provided for {device_ip}. "
                                f"Network data job requires a valid device ID to target the specific device. "
                                f"Without it, the job will find NO devices.")
                return None
            
            onboarding_logger.debug(f"✅ Device ID provided: {device_id}")
            
            # Get cached network data job parameters
            cache_key = f"network_data_job_{session_id}_{device_ip}"
            network_data_job_data = cache.get(cache_key)
            
            if not network_data_job_data:
                onboarding_logger.error(f"❌ No cached network data job parameters for {device_ip}")
                return None
            
            onboarding_logger.debug(f"✅ Found cached job data for {device_ip}")
            
            # Validate that the cached data is appropriate for this device
            if not self._validate_cached_job_data(network_data_job_data, device_ip, device_name):
                onboarding_logger.error(f"Cached job data validation failed for {device_ip}")
                return None
            
            # Find the job model
            job_model = self._find_network_data_job_model()
            if not job_model:
                onboarding_logger.error("SSOTSyncNetworkData job model not found")
                return None
            
            # Wait for device to be fully committed to database
            device_obj = self._wait_for_device_commitment(device_ip, device_id)
            if not device_obj:
                onboarding_logger.error(f"❌ CRITICAL: Device {device_ip} not found in database after waiting. "
                                f"Cannot trigger network data job without a valid device in the database.")
                return None
            
            onboarding_logger.debug(f"✅ Device confirmed in database: {device_obj.name} (ID: {device_obj.id})")
            
            # Prepare job data with device-specific filters
            job_data = self._prepare_network_data_job_data(
                network_data_job_data, device_ip, device_name, device_obj.id
            )
            
            # Final validation: Ensure the job data has a valid devices list
            if not job_data.get('devices') or len(job_data.get('devices', [])) == 0:
                onboarding_logger.error(f"❌ CRITICAL: Job data has no devices list for {device_ip}. "
                                f"This will cause the network data job to find NO devices. Aborting.")
                return None
            
            onboarding_logger.debug(f"✅ Job data prepared with devices: {job_data.get('devices')}")
            
            # Trigger the job
            job_result = self._execute_network_data_job(job_model, job_data, user)
            
            if job_result:
                # Clear the cache after successful job execution
                cache.delete(cache_key)
                onboarding_logger.log_job_status("network_data", str(job_result.id), "success", device_ip=device_ip)
                return str(job_result.id)
            else:
                onboarding_logger.error(f"Failed to trigger network data job for {device_ip}")
                return None
                
        except Exception as e:
            error_info = self.error_handler.log_and_create_error_response(
                e, f"triggering network data job for {device_ip}"
            )
            onboarding_logger.error(f"Error triggering network data job for {device_ip}: {e}")
            return None
    
    def _validate_cached_job_data(self, cached_data: Dict[str, Any], device_ip: str, device_name: str) -> bool:
        """
        Validate that cached job data is appropriate for the device being onboarded.
        
        Args:
            cached_data: Cached network data job parameters
            device_ip: IP address of the device
            device_name: Name of the device
            
        Returns:
            True if validation passes, False otherwise
        """
        try:
            # Check if cached data has required fields
            required_fields = ['secrets_group', 'location', 'namespace', 'platform']
            for field in required_fields:
                if field not in cached_data:
                    onboarding_logger.error(f"Cached job data missing required field: {field}")
                    return False
            
            # Log the cached data for debugging (without sensitive info)
            onboarding_logger.debug(f"Cached job data for {device_ip}: secrets_group={cached_data.get('secrets_group')}, "
                            f"location={cached_data.get('location')}, namespace={cached_data.get('namespace')}, "
                            f"platform={cached_data.get('platform')}")
            
            # Additional validation could be added here to check if the cached data
            # is compatible with the current device (e.g., platform matches, etc.)
            
            return True
            
        except Exception as e:
            self.logger.error(f"Error validating cached job data for {device_ip}: {e}")
            return False
    
    def clear_network_data_job_cache(self, session_id: str, device_ip: str) -> bool:
        """
        Clear cached network data job parameters for a specific device.
        
        Args:
            session_id: Session ID
            device_ip: Device IP address
            
        Returns:
            True if cache was cleared, False otherwise
        """
        try:
            cache_key = f"network_data_job_{session_id}_{device_ip}"
            cache.delete(cache_key)
            onboarding_logger.debug(f"Cleared network data job cache for {device_ip}")
            return True
        except Exception as e:
            onboarding_logger.error(f"Error clearing cache for {device_ip}: {e}")
            return False
    
    def verify_network_data_job_success(self, job_result: JobResult, device_ip: str) -> Dict[str, Any]:
        """
        Verify that the network data job actually processed the device.
        
        Args:
            job_result: The job result to verify
            device_ip: IP address of the device
            
        Returns:
            Dictionary with verification result
        """
        verification_result = {
            'is_successful': False,
            'devices_processed': 0,
            'verification_method': None,
            'error': None
        }
        
        try:
            # Method 1: Check job result data
            if hasattr(job_result, 'result') and job_result.result:
                result_data = job_result.result
                
                if isinstance(result_data, dict):
                    # Check for device counts or processing indicators
                    if 'devices_processed' in result_data:
                        count = result_data['devices_processed']
                        verification_result.update({
                            'is_successful': count > 0,
                            'devices_processed': count,
                            'verification_method': 'result_data_devices_processed'
                        })
                        return verification_result
                    
                    elif 'devices_synced' in result_data:
                        count = result_data['devices_synced']
                        verification_result.update({
                            'is_successful': count > 0,
                            'devices_processed': count,
                            'verification_method': 'result_data_devices_synced'
                        })
                        return verification_result
                    
                    elif 'sync_summary' in result_data:
                        sync_summary = result_data['sync_summary']
                        if isinstance(sync_summary, dict):
                            # Check for any positive counts
                            counts = ['create', 'update', 'no-change']
                            total_processed = sum(sync_summary.get(count, 0) for count in counts)
                            verification_result.update({
                                'is_successful': total_processed > 0,
                                'devices_processed': total_processed,
                                'verification_method': 'result_data_sync_summary'
                            })
                            return verification_result
            
            # Method 2: Check job logs
            if hasattr(job_result, 'log_entries'):
                log_text = ' '.join([entry.message for entry in job_result.log_entries.all()])
                positive_indicators = [
                    'devices processed', 'devices synced', 'sync complete', 
                    'created', 'updated', 'processed'
                ]
                
                if any(indicator in log_text.lower() for indicator in positive_indicators):
                    verification_result.update({
                        'is_successful': True,
                        'devices_processed': 1,  # Assume at least one if indicators found
                        'verification_method': 'log_entries_indicators'
                    })
                    return verification_result
            
            # Method 3: Conservative approach - assume success if job completed
            if job_result.status == JobResultStatusChoices.STATUS_SUCCESS:
                verification_result.update({
                    'is_successful': True,
                    'devices_processed': 1,  # Assume one device processed
                    'verification_method': 'conservative_assumption'
                })
                onboarding_logger.warning(f"Could not verify network data job success for {device_ip}, assuming success")
                return verification_result
            
            verification_result['error'] = "Job did not complete successfully"
            
        except Exception as e:
            verification_result['error'] = str(e)
            onboarding_logger.error(f"Error verifying network data job success for {device_ip}: {e}")
        
        return verification_result
    
    def _find_network_data_job_model(self) -> Optional[Job]:
        """Find the SSOTSyncNetworkData job model."""
        job_class_names = [
            'SSOTSyncNetworkData',
            'nautobot_device_onboarding.jobs.SSOTSyncNetworkData',
            'SyncNetworkData'
        ]
        
        for job_class_name in job_class_names:
            try:
                job_model = Job.objects.get(job_class_name=job_class_name)
                onboarding_logger.debug(f"Found job model: {job_class_name}")
                return job_model
            except Job.DoesNotExist:
                onboarding_logger.debug(f"Job not found: {job_class_name}")
                continue
        
        return None
    
    def _wait_for_device_commitment(self, device_ip: str, device_id: Optional[int] = None) -> Optional['Device']:
        """
        Wait for device to be fully committed to the database.
        
        This method addresses the timing issue where the SSOTSyncNetworkData job
        is triggered immediately after SSOTSyncDevices, but the device might not
        be fully committed to the database yet.
        
        Args:
            device_ip: Device IP address
            device_id: Optional device ID for direct lookup
            
        Returns:
            Device object if found, None otherwise
        """
        from nautobot.dcim.models import Device
        from nautobot.ipam.models import IPAddress
        import time
        
        max_wait_time = 30  # Maximum 30 seconds to wait
        wait_interval = 1   # Check every 1 second
        start_time = time.time()
        
        onboarding_logger.debug(f"Waiting for device {device_ip} to be committed to database...")
        
        while time.time() - start_time < max_wait_time:
            try:
                device_obj = None
                
                # Try direct device ID lookup first (most reliable)
                if device_id:
                    try:
                        device_obj = Device.objects.get(id=device_id)
                        onboarding_logger.debug(f"Found device by ID {device_id}: {device_obj.name}")
                        return device_obj
                    except Device.DoesNotExist:
                        pass  # Continue waiting
                
                # Fallback: try to find device by IP address
                try:
                    ip_obj = IPAddress.objects.get(address=device_ip)
                    if ip_obj.assigned_object and hasattr(ip_obj.assigned_object, 'device'):
                        device_obj = ip_obj.assigned_object.device
                        onboarding_logger.debug(f"Found device by IP {device_ip}: {device_obj.name}")
                        return device_obj
                except (IPAddress.DoesNotExist, AttributeError):
                    pass  # Continue waiting
                
                # Wait before next attempt
                time.sleep(wait_interval)
                
            except Exception as e:
                onboarding_logger.debug(f"Error during device lookup attempt: {e}")
                time.sleep(wait_interval)
        
        onboarding_logger.warning(f"Device {device_ip} not found after waiting {max_wait_time} seconds")
        return None
    
    def _find_device_sync_job_model(self) -> Optional[Job]:
        """Find the SSOTSyncDevices job model."""
        job_class_names = [
            'SSOTSyncDevices',
            'nautobot_device_onboarding.jobs.SSOTSyncDevices',
            'SyncDevices'
        ]
        
        for job_class_name in job_class_names:
            try:
                job_model = Job.objects.get(job_class_name=job_class_name)
                onboarding_logger.debug(f"Found device sync job model: {job_class_name}")
                return job_model
            except Job.DoesNotExist:
                onboarding_logger.debug(f"Device sync job not found: {job_class_name}")
                continue
        
        return None
    
    def _prepare_bulk_device_sync_job_data(self, cached_data: Dict[str, Any], 
                                         device_ips: List[str], device_names: List[str]) -> Dict[str, Any]:
        """
        Prepare job data for bulk device sync operation.
        
        Args:
            cached_data: Cached device sync job parameters
            device_ips: List of device IP addresses
            device_names: List of device names
            
        Returns:
            Dictionary with bulk job data
        """
        job_data = cached_data.copy()
        
        # Set the device IPs for bulk processing (use ip_addresses field like individual jobs)
        job_data['ip_addresses'] = ','.join(device_ips)  # SSOTSyncDevices expects comma-separated string
        job_data['device_names'] = device_names
        job_data['batch_size'] = len(device_ips)
        
        # Add bulk processing configuration
        job_data['bulk_operation'] = True
        job_data['handle_duplicates'] = True
        job_data['update_existing'] = True
        
        # Ensure required status objects are available
        job_data.update(self._get_required_status_objects())
        
        onboarding_logger.debug(f"✅ Prepared bulk device sync job data for {len(device_ips)} devices")
        return job_data
    
    def _prepare_bulk_network_data_job_data(self, cached_data: Dict[str, Any], 
                                          device_ids: List[str], device_data: List[Dict[str, Any]]) -> Dict[str, Any]:
        """
        Prepare job data for bulk network data sync operation.
        
        Args:
            cached_data: Cached network data job parameters
            device_ids: List of device UUIDs
            device_data: List of device data dictionaries
            
        Returns:
            Dictionary with bulk job data
        """
        job_data = cached_data.copy()
        
        # Set the device UUIDs for bulk processing
        job_data['devices'] = device_ids
        job_data['device_data'] = device_data
        job_data['batch_size'] = len(device_ids)
        
        # Add bulk processing configuration
        job_data['bulk_operation'] = True
        job_data['handle_duplicates'] = True
        job_data['update_existing'] = True
        
        # Ensure required status objects are available
        job_data.update(self._get_required_status_objects())
        
        onboarding_logger.debug(f"✅ Prepared bulk network data job data for {len(device_ids)} devices")
        return job_data
    
    def _execute_bulk_device_sync_job(self, job_model: Job, job_data: Dict[str, Any], user) -> Optional[JobResult]:
        """Execute the bulk device sync job."""
        try:
            # Log the job data being sent (without sensitive information)
            # The job data uses 'ip_addresses' as a comma-separated string, not 'device_ips' as a list
            ip_addresses = job_data.get('ip_addresses', '')
            device_count = len(ip_addresses.split(',')) if ip_addresses else 0
            onboarding_logger.debug(f"Executing bulk device sync job with {device_count} devices")
            
            # Enqueue the job using the proper Nautobot API
            job_result = JobResult.enqueue_job(
                job_model=job_model,
                user=user,
                **job_data
            )
            
            onboarding_logger.debug(f"Bulk device sync job enqueued successfully: {job_result.id}")
            return job_result
            
        except Exception as e:
            onboarding_logger.error(f"Error executing bulk device sync job: {e}")
            return None
    
    def _prepare_network_data_job_data(self, cached_data: Dict[str, Any], 
                                      device_ip: str, device_name: str, 
                                      device_id: Optional[int] = None) -> Dict[str, Any]:
        """
        Prepare job data with device-specific filters.
        
        Note: In Nautobot, Device objects use 'id' as the primary key field (which contains the UUID),
        not 'uuid'. This method correctly accesses device_obj.id to get the device's UUID.
        """
        job_data = cached_data.copy()
        
        # CRITICAL: We must have a device_id to proceed
        # Without it, the network data job will find NO devices
        if not device_id:
            onboarding_logger.error(f"❌ CRITICAL: No device_id provided for {device_ip}. Cannot prepare network data job without device ID.")
            job_data['devices'] = []
            return job_data
        
        # Get the specific device object to ensure we're working with the right device
        device_obj = None
        try:
            from nautobot.dcim.models import Device
            device_obj = Device.objects.get(id=device_id)
            onboarding_logger.debug(f"✅ Found device object for {device_ip}: {device_obj.name} (ID: {device_obj.id})")
        except Device.DoesNotExist:
            onboarding_logger.error(f"❌ CRITICAL: Device with ID {device_id} not found in database for {device_ip}")
        
        # If we still don't have device_obj after the ID lookup failed, this is a critical error
        if not device_obj:
            onboarding_logger.error(f"❌ CRITICAL: Cannot proceed without valid device object for {device_ip}")
            job_data['devices'] = []
            return job_data
        
        # If we have a device object, use its UUID for the devices field
        if device_obj:
            try:
                # The SSOTSyncNetworkData job expects a list of device UUIDs
                # In Nautobot, the primary key field is 'id' (which contains the UUID)
                device_uuid = str(device_obj.id)
                job_data['devices'] = [device_uuid]
                onboarding_logger.debug(f"✅ Set devices field to [{device_uuid}] for {device_ip} (device: {device_obj.name})")
                
                # Additional validation: verify the device exists in the database
                from nautobot.dcim.models import Device
                try:
                    verify_device = Device.objects.get(id=device_uuid)
                    onboarding_logger.debug(f"✅ Device verification successful: {verify_device.name} (ID: {verify_device.id})")
                except Device.DoesNotExist:
                    onboarding_logger.error(f"❌ Device verification failed: Device with ID {device_uuid} not found in database")
                    job_data['devices'] = []
                    return job_data
                    
            except Exception as e:
                onboarding_logger.error(f"Error accessing device ID for {device_ip}: {e}")
                # Fallback: clear devices field
                job_data['devices'] = []
                onboarding_logger.warning(f"Clearing devices field due to error for {device_ip}")
        else:
            # Fallback: clear devices field and let the job find devices by other criteria
            # This is less reliable but better than using wrong device data
            job_data['devices'] = []
            onboarding_logger.warning(f"No device object found for {device_ip}, clearing devices field")
        
        # Add duplicate handling configuration
        job_data['handle_duplicates'] = True
        job_data['update_existing'] = True
        
        # Ensure required status objects are available
        job_data.update(self._get_required_status_objects())
        
        return job_data
    
    def _get_required_status_objects(self) -> Dict[str, Any]:
        """Get required status objects for the network data job."""
        try:
            device_ct = ContentType.objects.get_for_model(Device)
            interface_ct = ContentType.objects.get_for_model(Interface)
            ipaddress_ct = ContentType.objects.get_for_model(IPAddress)
            
            # Get default statuses
            default_device_status = Status.objects.filter(
                content_types=device_ct, name='Active'
            ).first()
            default_interface_status = Status.objects.filter(
                content_types=interface_ct, name='Active'
            ).first()
            default_ip_status = Status.objects.filter(
                content_types=ipaddress_ct, name='Active'
            ).first()
            
            return {
                'default_device_status': default_device_status.id if default_device_status else None,
                'default_interface_status': default_interface_status.id if default_interface_status else None,
                'default_ip_status': default_ip_status.id if default_ip_status else None,
            }
        except Exception as e:
            onboarding_logger.warning(f"Error getting required status objects: {e}")
            return {}
    
    def _execute_network_data_job(self, job_model: Job, job_data: Dict[str, Any], user) -> Optional[JobResult]:
        """Execute the network data job with duplicate handling."""
        try:
            # Log the job data being sent (without sensitive information)
            onboarding_logger.debug(f"Executing network data job with devices: {job_data.get('devices', [])}")
            
            # Enqueue the job using the proper Nautobot API
            job_result = JobResult.enqueue_job(
                job_model=job_model,
                user=user,
                **job_data
            )
            
            onboarding_logger.debug(f"Network data job enqueued successfully: {job_result.id}")
            return job_result
            
        except Exception as e:
            # Handle ObjectAlreadyExists errors specifically
            if 'ObjectAlreadyExists' in str(e) or 'already present' in str(e):
                onboarding_logger.warning(f"Device already exists, attempting to update instead: {e}")
                
                # Try to find the existing device and update it
                try:
                    device_filters = job_data.get('filters', {})
                    device_ip = device_filters.get('ip_address')
                    device_name = device_filters.get('name')
                    
                    if device_ip:
                        # Find the existing device
                        from nautobot.dcim.models import Device
                        existing_device = Device.objects.filter(name=device_name).first()
                        
                        if existing_device:
                            onboarding_logger.debug(f"Found existing device {existing_device.name}, updating job data")
                            # Update job data to target the existing device
                            job_data['filters']['id'] = existing_device.id
                            job_data['update_existing'] = True
                            
                            # Retry the job with updated data
                            job_result = JobResult.enqueue_job(
                                job_model=job_model,
                                user=user,
                                **job_data
                            )
                            return job_result
                except Exception as update_error:
                    onboarding_logger.error(f"Failed to handle existing device: {update_error}")
            
            onboarding_logger.error(f"Error executing network data job: {e}")
            return None
    
    def get_job_status_info(self, job_result_id: str) -> Dict[str, Any]:
        """Get comprehensive job status information."""
        try:
            job_result = JobResult.objects.get(pk=job_result_id)
            
            return {
                'id': job_result.id,
                'name': job_result.name,
                'status': job_result.status,
                'created': job_result.created.isoformat() if job_result.created else None,
                'started': job_result.started.isoformat() if job_result.started else None,
                'completed': job_result.date_done.isoformat() if job_result.date_done else None,
                'duration': str(job_result.duration) if job_result.duration else None,
                'has_errors': bool(job_result.traceback),
                'error_message': job_result.traceback if job_result.traceback else None
            }
        except JobResult.DoesNotExist:
            return {
                'error': 'Job result not found',
                'id': job_result_id
            }
        except Exception as e:
            return {
                'error': str(e),
                'id': job_result_id
            }
    
    def prepare_bulk_onboarding(self, device_ips: List[str], user, global_settings=None) -> Dict[str, Any]:
        """
        Prepare bulk onboarding by creating batches and triggering bulk jobs.
        
        Args:
            device_ips: List of device IP addresses to onboard
            user: User triggering the jobs
            global_settings: Optional global settings to apply to all devices
            
        Returns:
            Dict containing status, batches info, and any error messages
        """
        try:
            if not device_ips:
                return {
                    'status': 'error',
                    'message': 'No devices provided for bulk onboarding'
                }
            
            onboarding_logger.log_bulk_operation("preparation", device_count=len(device_ips), status="started")
            
            # Get required objects for job creation
            required_objects = self._get_required_objects_for_bulk()
            if not required_objects:
                return {
                    'status': 'error',
                    'message': 'Failed to get required Nautobot objects for bulk onboarding'
                }
            
            # Validate required objects
            if not required_objects['location']:
                return {
                    'status': 'error',
                    'message': f'Location "{self.session.location}" not found'
                }
            if not required_objects['secrets_group']:
                return {
                    'status': 'error',
                    'message': f'Secrets group "{self.session.secrets_group_name}" not found'
                }
            
            # Get selected devices from the session
            selected_devices = self._get_selected_devices(device_ips)
            if not selected_devices:
                return {
                    'status': 'error',
                    'message': 'No valid selected devices found for the provided IPs'
                }
            
            # Create batches of devices using max_bulk_devices setting
            batch_size = self.max_bulk_devices
            batches = []
            triggered_jobs = []
            
            for i in range(0, len(device_ips), batch_size):
                batch_devices = device_ips[i:i + batch_size]
                batch_number = (i // batch_size) + 1
                
                onboarding_logger.log_bulk_operation("batch_processing", batch_number=batch_number, device_count=len(batch_devices))
                
                # Get device names for this batch
                batch_device_names = []
                for device_ip in batch_devices:
                    device = next((d for d in selected_devices if d.ip_address == device_ip), None)
                    if device:
                        batch_device_names.append(device.hostname or device.ip_address)
                    else:
                        batch_device_names.append(device_ip)
                
                # Create device sync job data for each device in the batch and cache it
                self._prepare_device_sync_job_cache(batch_devices, selected_devices, required_objects, global_settings)
                
                # Trigger bulk device sync job for this batch
                job_result_id = self.trigger_bulk_device_sync_job(
                    self.session.session_id, 
                    batch_devices, 
                    batch_device_names, 
                    user
                )
                
                batch_info = {
                    'batch_number': batch_number,
                    'device_ips': batch_devices,
                    'device_count': len(batch_devices),
                    'status': 'running' if job_result_id else 'failed',
                    'job_result_id': job_result_id,
                    'device_sync_status': 'running' if job_result_id else 'failed',
                    'network_data_status': 'pending'
                }
                
                batches.append(batch_info)
                
                if job_result_id:
                    triggered_jobs.append(job_result_id)
                    onboarding_logger.log_bulk_operation("batch_triggered", batch_number=batch_number, status="success")
                else:
                    onboarding_logger.error(f"❌ Failed to trigger job for batch {batch_number}")
            
            # Store user in cache for later use (needed for network data jobs)
            user_cache_key = f"bulk_onboarding_user_{self.session.session_id}"
            cache.set(user_cache_key, {
                'username': user.username,
                'user_id': user.id,
                'user_pk': user.pk
            }, timeout=3600)
            
            # Store batch information in cache for tracking
            cache_key = f"bulk_onboarding_batches_{self.session.session_id}"
            cache.set(cache_key, {
                'batches': batches,
                'total_devices': len(device_ips),
                'triggered_jobs': triggered_jobs,
                'created_at': timezone.now().isoformat()
            }, timeout=3600)  # 1 hour timeout
            
            successful_batches = len([b for b in batches if b['status'] == 'running'])
            
            return {
                'status': 'success',
                'batches': batches,
                'total_batches': len(batches),
                'total_devices': len(device_ips),
                'successful_batches': successful_batches,
                'triggered_jobs': triggered_jobs
            }
            
        except Exception as e:
            onboarding_logger.error(f"Error preparing bulk onboarding: {e}")
            return {
                'status': 'error',
                'message': str(e)
            }
    
    def _update_job_status_from_result(self, batch_number: int, job_result_id: str) -> Dict[str, Any]:
        """
        Update job status cache from JobResult.
        
        Args:
            batch_number: The batch number
            job_result_id: The JobResult UUID
            
        Returns:
            Dict containing updated job status
        """
        try:
            from nautobot.extras.models import JobResult
            
            job_result = JobResult.objects.get(pk=job_result_id)
            job_status_key = f"bulk_job_status_{self.session.session_id}_batch_{batch_number}"
            
            # Parse job logs to extract device information
            device_statuses = {}
            processed_devices = 0
            successful_devices = 0
            failed_devices = 0
            
            # Get device IPs from batch data
            cache_key = f"bulk_onboarding_batches_{self.session.session_id}"
            batch_data = cache.get(cache_key, {})
            batches = batch_data.get('batches', [])
            
            target_batch = None
            for batch in batches:
                if batch['batch_number'] == batch_number:
                    target_batch = batch
                    break
            
            if target_batch:
                device_ips = target_batch.get('device_ips', [])
                
                # Initialize device statuses based on job result status
                if job_result.status == JobResultStatusChoices.STATUS_SUCCESS:
                    for device_ip in device_ips:
                        device_statuses[device_ip] = {
                            'status': 'completed',
                            'message': 'Device sync completed successfully'
                        }
                        successful_devices += 1
                        processed_devices += 1
                    
                    # Update batch status
                    target_batch['status'] = 'completed'
                    onboarding_logger.log_bulk_operation("batch_completed", batch_number=batch_number, device_count=len(device_ips), status="completed")
                    
                elif job_result.status == JobResultStatusChoices.STATUS_FAILURE:
                    for device_ip in device_ips:
                        device_statuses[device_ip] = {
                            'status': 'failed',
                            'message': 'Device sync failed'
                        }
                        failed_devices += 1
                        processed_devices += 1
                    
                    # Update batch status
                    target_batch['status'] = 'failed'
                    
                elif job_result.status == JobResultStatusChoices.STATUS_STARTED:
                    for device_ip in device_ips:
                        device_statuses[device_ip] = {
                            'status': 'running',
                            'message': 'Device sync in progress'
                        }
                    
                    # Keep batch status as running
                    target_batch['status'] = 'running'
                
                else:
                    # Handle other statuses (pending, etc.)
                    for device_ip in device_ips:
                        device_statuses[device_ip] = {
                            'status': 'pending',
                            'message': f'Job status: {job_result.status}'
                        }
            
            # Create job status data
            job_status = {
                'job_result_id': job_result_id,
                'job_status': job_result.status,
                'device_statuses': device_statuses,
                'processed_devices': processed_devices,
                'successful_devices': successful_devices,
                'failed_devices': failed_devices,
                'last_updated': timezone.now().isoformat()
            }
            
            # Update cache
            cache.set(job_status_key, job_status, timeout=3600)
            
            # Update batch data
            cache.set(cache_key, batch_data, timeout=3600)
            
            onboarding_logger.debug(f"Updated job status for batch {batch_number}: {job_result.status}")
            return job_status
            
        except Exception as e:
            onboarding_logger.error(f"Error updating job status for batch {batch_number}: {e}")
            return {}

    def clear_bulk_onboarding_cache(self) -> bool:
        """Clear bulk onboarding cache data for the session."""
        try:
            bulk_cache_key = f"bulk_onboarding_batches_{self.session.session_id}"
            cache.delete(bulk_cache_key)
            onboarding_logger.debug(f"Cleared bulk onboarding cache for session {self.session.session_id}")
            return True
        except Exception as e:
            onboarding_logger.error(f"Failed to clear bulk onboarding cache: {e}")
            return False

    def get_bulk_onboarding_status(self) -> Dict[str, Any]:
        """
        Get the status of all bulk onboarding batches for the session.
        
        Returns:
            Dict containing batch statuses and overall progress
        """
        try:
            cache_key = f"bulk_onboarding_batches_{self.session.session_id}"
            batch_data = cache.get(cache_key)
            
            if not batch_data:
                return {
                    'status': 'no_batches',
                    'message': 'No bulk onboarding batches found'
                }
            
            # Get job status for each batch and update from JobResult if needed
            batches = batch_data.get('batches', [])
            total_devices = 0
            device_sync_completed = 0
            network_data_completed = 0
            failed_devices = 0
            
            for batch in batches:
                batch_number = batch['batch_number']
                device_sync_job_id = batch.get('job_result_id')  # This is the device sync job ID
                batch_device_count = batch['device_count']
                total_devices += batch_device_count
                
                # Get device sync job status from cache
                job_status_key = f"bulk_job_status_{self.session.session_id}_batch_{batch_number}"
                device_sync_status = cache.get(job_status_key, {})
                
                # Update device sync status if needed
                needs_update = self._should_update_job_status(batch, device_sync_status)
                if needs_update and device_sync_job_id:
                    device_sync_status = self._update_job_status_from_result(batch_number, device_sync_job_id)
                
                # Set device sync status and counts
                if device_sync_status:
                    if device_sync_status.get('job_status') == 'SUCCESS':
                        batch['device_sync_status'] = 'completed'
                        device_sync_completed += device_sync_status.get('successful_devices', 0)
                    elif device_sync_status.get('job_status') == 'FAILURE':
                        batch['device_sync_status'] = 'failed'
                        failed_devices += device_sync_status.get('failed_devices', 0)
                    elif device_sync_status.get('job_status') in ['STARTED', 'RUNNING']:
                        batch['device_sync_status'] = 'running'
                    else:
                        batch['device_sync_status'] = 'pending'
                else:
                    batch['device_sync_status'] = 'pending'
            
            # Check if we should trigger network data jobs
            all_device_sync_complete = device_sync_completed == total_devices and total_devices > 0
            onboarding_logger.debug(f"🔍 Job completion check: device_sync_completed={device_sync_completed}, total={total_devices}")
            onboarding_logger.debug(f"🔍 All device sync jobs complete: {all_device_sync_complete}")
            
            if all_device_sync_complete and device_sync_completed > 0:
                onboarding_logger.info(f"🚀 All device sync jobs complete, checking for stack member creation...")
                # First, trigger stack member creation for any stack devices
                stack_creation_complete = self._trigger_stack_member_creation_if_ready()
                
                if stack_creation_complete:
                    onboarding_logger.info(f"🚀 Stack member creation complete, triggering network data jobs for {device_sync_completed} successful devices")
                    self._trigger_network_data_jobs_if_ready()
                else:
                    onboarding_logger.debug(f"⏳ Stack member creation still in progress, waiting before network data jobs")
            else:
                onboarding_logger.debug(f"⏳ Not ready to trigger stack member creation yet - device sync not complete")
            
            # Get network data job information
            network_job_result_key = f"network_job_result_{self.session.session_id}"
            network_job_info = cache.get(network_job_result_key)
            network_data_status = 'pending'  # Default status
            network_data_job_id = None
            
            if network_job_info:
                network_data_job_id = network_job_info.get('job_result_id')
                onboarding_logger.debug(f"🔍 Found network data job ID: {network_data_job_id}")
                
                # Check actual network job status
                network_data_status = self._get_network_job_status(network_data_job_id)
                if network_data_status == 'completed':
                    network_data_completed = device_sync_completed  # All successful device sync jobs also completed network data
            
            # Update batch statuses and calculate progress
            for batch in batches:
                device_sync_status = batch.get('device_sync_status', 'pending')
                
                # Set network data status for all batches (shared network job)
                batch['network_data_status'] = network_data_status if network_data_job_id else 'pending'
                batch['network_data_job_id'] = network_data_job_id
                
                # Check if this batch has stack devices and get stack member status
                stack_member_status = batch.get('stack_member_status', 'not_applicable')
                has_stack_devices = batch.get('has_stack_devices', False)
                
                # Calculate progress based on whether batch has stack devices
                batch_progress = 0.0
                if has_stack_devices:
                    # 3-phase progress: Device Sync (33%) + Stack Members (33%) + Network Data (34%)
                    if device_sync_status == 'failed' or stack_member_status == 'failed' or network_data_status == 'failed':
                        batch_progress = 0.0  # Any failure resets progress to 0
                    elif device_sync_status == 'completed':
                        batch_progress = 33.0  # Device sync completed
                        if stack_member_status == 'completed':
                            batch_progress = 66.0  # Device sync + stack members completed
                            if network_data_status == 'completed':
                                batch_progress = 100.0  # All phases completed
                            elif network_data_status == 'running':
                                batch_progress = 83.0  # Device sync + stack done, network data in progress
                        elif stack_member_status == 'running':
                            batch_progress = 50.0  # Device sync done, stack creation in progress
                    elif device_sync_status == 'running':
                        batch_progress = 16.0  # Device sync in progress
                else:
                    # 2-phase progress: Device Sync (50%) + Network Data (50%)
                    if device_sync_status == 'failed' or network_data_status == 'failed':
                        batch_progress = 0.0  # Any failure resets progress to 0
                    elif device_sync_status == 'completed':
                        batch_progress = 50.0  # Device sync completed
                        if network_data_status == 'completed':
                            batch_progress = 100.0  # Both phases completed
                        elif network_data_status == 'running':
                            batch_progress = 75.0  # Device sync done, network data in progress
                    elif device_sync_status == 'running':
                        batch_progress = 25.0  # Device sync in progress
                
                batch['progress'] = batch_progress
                
                # Determine overall batch status: only "completed" when ALL required phases are completed
                if device_sync_status == 'failed':
                    batch['status'] = 'failed'
                elif has_stack_devices:
                    # 3-phase workflow: device sync + stack members + network data
                    if (device_sync_status == 'completed' and 
                        stack_member_status == 'completed' and 
                        network_data_status == 'completed'):
                        batch['status'] = 'completed'
                    elif stack_member_status == 'failed':
                        batch['status'] = 'failed'  # Stack member creation failed
                    elif (device_sync_status == 'completed' and 
                          stack_member_status == 'completed' and 
                          network_data_status == 'failed'):
                        batch['status'] = 'failed'  # Network data failed
                    elif (device_sync_status in ['running'] or 
                          stack_member_status in ['running'] or 
                          network_data_status in ['running'] or
                          (device_sync_status == 'completed' and stack_member_status in ['pending', 'completed']) or
                          (device_sync_status == 'completed' and stack_member_status == 'completed' and network_data_status == 'pending')):
                        batch['status'] = 'running'  # At least one phase is running or ready to run
                    else:
                        batch['status'] = 'pending'
                else:
                    # 2-phase workflow: device sync + network data
                    if device_sync_status == 'completed' and network_data_status == 'completed':
                        batch['status'] = 'completed'
                    elif network_data_status == 'failed':
                        batch['status'] = 'failed'  # Network data failed
                    elif (device_sync_status in ['running'] or 
                          network_data_status in ['running'] or
                          (device_sync_status == 'completed' and network_data_status == 'pending')):
                        batch['status'] = 'running'  # At least one phase is running or ready to run
                    else:
                        batch['status'] = 'pending'
                
                # Clean up the batch data - remove redundant fields
                batch.pop('job_status', None)  # Remove the nested job_status object
                
                onboarding_logger.debug(f"📊 Batch {batch['batch_number']}: device_sync={device_sync_status}, network_data={network_data_status}, overall={batch['status']}, progress={batch_progress}%")
            
            # Calculate overall progress
            overall_progress = 0.0
            if total_devices > 0:
                device_sync_progress = (device_sync_completed / total_devices) * 50.0
                network_data_progress = (network_data_completed / total_devices) * 50.0
                overall_progress = device_sync_progress + network_data_progress
            
            # Check if all batches are complete (either completed or failed)
            all_batches_complete = all(
                batch.get('status') in ['completed', 'failed'] 
                for batch in batches
            )
            
            # Clear bulk cache if all operations are complete
            if all_batches_complete:
                onboarding_logger.info(f"All bulk onboarding batches complete for session {self.session.session_id}. Clearing bulk cache.")
                self.clear_bulk_onboarding_cache()
            
            return {
                'status': 'success',
                'batches': batches,
                'summary': {
                    'total_devices': total_devices,
                    'device_sync_completed': device_sync_completed,
                    'network_data_completed': network_data_completed,
                    'failed_devices': failed_devices,
                    'overall_progress_percentage': round(overall_progress, 1),
                    'all_complete': all_batches_complete
                }
            }
            
        except Exception as e:
            onboarding_logger.error(f"Error getting bulk onboarding status: {e}")
            return {
                'status': 'error',
                'message': str(e)
            }
    
    def _should_update_job_status(self, batch: Dict[str, Any], job_status: Dict[str, Any]) -> bool:
        """Determine if job status needs to be updated from JobResult."""
        if not job_status:
            return True
            
        batch_status = batch.get('status', 'pending')
        job_status_value = job_status.get('job_status')
        
        return (
            job_status_value in ['pending', 'running', 'STARTED'] or
            (job_status_value == 'SUCCESS' and batch_status != 'completed') or
            (job_status_value == 'FAILURE' and batch_status != 'failed')
        )
    
    def _get_network_job_status(self, network_job_id: str) -> str:
        """Get the status of a network data job."""
        try:
            from nautobot.extras.models import JobResult
            network_job_result = JobResult.objects.get(pk=network_job_id)
            
            # Debug logging to see actual status value
            onboarding_logger.debug(f"🔍 Network job {network_job_id} status: '{network_job_result.status}' (type: {type(network_job_result.status)})")
            
            # Handle both string and enum values for robustness
            status_str = str(network_job_result.status).upper()
            
            if status_str in ['SUCCESS', 'COMPLETED'] or network_job_result.status == JobResultStatusChoices.STATUS_SUCCESS:
                return 'completed'
            elif status_str in ['FAILURE', 'FAILED'] or network_job_result.status == JobResultStatusChoices.STATUS_FAILURE:
                return 'failed'
            elif status_str in ['STARTED', 'RUNNING'] or network_job_result.status in [JobResultStatusChoices.STATUS_STARTED, JobResultStatusChoices.STATUS_RUNNING]:
                return 'running'
            else:
                self.logger.warning(f"⚠️ Unknown network job status: '{network_job_result.status}', defaulting to pending")
                return 'pending'
                
        except JobResult.DoesNotExist:
            self.logger.warning(f"❌ Network job {network_job_id} not found in database")
            return 'pending'
        except Exception as e:
            self.logger.warning(f"❌ Error checking network job status: {e}")
            return 'running'

    def _trigger_network_data_jobs_if_ready(self):
        """
        Trigger network data jobs for successfully onboarded devices if not already triggered.
        """
        try:
            onboarding_logger.debug(f"🚀 _trigger_network_data_jobs_if_ready() called for session {self.session.session_id}")
            # Check if network data jobs have already been triggered
            network_jobs_key = f"network_jobs_triggered_{self.session.session_id}"
            network_job_result_key = f"network_job_result_{self.session.session_id}"
            
            # Check if we already have a network job result (more reliable than cache flag)
            existing_network_job = cache.get(network_job_result_key)
            if existing_network_job:
                onboarding_logger.debug(f"Network data job already exists: {existing_network_job.get('job_result_id')}")
                return  # Already triggered
            
            # Get all successfully onboarded devices
            successful_devices = []
            device_data_list = []
            cache_key = f"bulk_onboarding_batches_{self.session.session_id}"
            batch_data = cache.get(cache_key, {})
            batches = batch_data.get('batches', [])
            
            onboarding_logger.debug(f"🔍 Checking {len(batches)} batches for successful devices")
            
            for batch in batches:
                batch_number = batch['batch_number']
                batch_status = batch.get('status', 'unknown')
                job_status_key = f"bulk_job_status_{self.session.session_id}_batch_{batch_number}"
                job_status = cache.get(job_status_key, {})
                
                # Check if batch is completed by looking at the batch status directly
                if batch_status == 'completed':
                    # Get device IPs from batch
                    batch_device_ips = batch.get('device_ips', [])
                    onboarding_logger.debug(f"✅ Batch {batch_number} completed with {len(batch_device_ips)} devices")
                    
                    for device_ip in batch_device_ips:
                        successful_devices.append(device_ip)
                        device_data_list.append({
                            'ip': device_ip,
                            'name': device_ip,  # Will be updated with actual device name if found
                            'device_id': None   # Will be populated when we find the device
                        })
            
            if not successful_devices:
                onboarding_logger.warning("❌ No successful devices found for network data jobs")
                return
            
            onboarding_logger.info(f"🚀 Found {len(successful_devices)} successful devices, triggering network data job")
            
            # Get cached network data job data from the first successful device
            network_job_data = None
            for device_ip in successful_devices:
                network_cache_key = f"network_data_job_{self.session.session_id}_{device_ip}"
                network_job_data = cache.get(network_cache_key)
                if network_job_data:
                    onboarding_logger.debug(f"✅ Found cached network data job data from device {device_ip}")
                    break
            
            if not network_job_data:
                onboarding_logger.warning("❌ No cached network data job data found")
                return
            
            # Get the network data job model
            from nautobot.extras.models import Job
            job_model = Job.objects.filter(
                job_class_name="SSOTSyncNetworkData"
            ).first()
            
            if not job_model:
                onboarding_logger.error("❌ SSOTSyncNetworkData job model not found")
                return
            
            # Get Device objects for successful IPs and populate device_data_list
            from nautobot.dcim.models import Device
            from nautobot.ipam.models import IPAddress
            
            found_devices = []
            for i, device_info in enumerate(device_data_list):
                device_ip = device_info['ip']
                device_obj = None
                
                # Try multiple methods to find the device
                try:
                    # Method 1: Find by primary IP
                    ip_obj = IPAddress.objects.filter(host=device_ip).first()
                    if ip_obj and hasattr(ip_obj, 'assigned_object') and ip_obj.assigned_object:
                        if hasattr(ip_obj.assigned_object, 'device'):
                            device_obj = ip_obj.assigned_object.device
                        elif hasattr(ip_obj.assigned_object, 'parent_device'):
                            device_obj = ip_obj.assigned_object.parent_device
                    
                    # Method 2: Direct device lookup by primary IP
                    if not device_obj:
                        device_obj = Device.objects.filter(primary_ip4__host=device_ip).first()
                    
                    # Method 3: Find by any interface IP
                    if not device_obj:
                        devices_with_ip = Device.objects.filter(
                            interfaces__ip_addresses__host=device_ip
                        ).distinct()
                        if devices_with_ip.exists():
                            device_obj = devices_with_ip.first()
                    
                    if device_obj:
                        device_data_list[i]['device_id'] = str(device_obj.id)
                        device_data_list[i]['name'] = device_obj.name
                        found_devices.append(device_obj)
                        onboarding_logger.debug(f"✅ Found device for {device_ip}: {device_obj.name} (ID: {device_obj.id})")
                    else:
                        onboarding_logger.warning(f"❌ No device found for IP {device_ip}")
                        
                except Exception as e:
                    onboarding_logger.error(f"Error finding device for {device_ip}: {e}")
            
            if not found_devices:
                onboarding_logger.warning(f"❌ No Device objects found for any IPs: {successful_devices}")
                return
            
            onboarding_logger.info(f"✅ Found {len(found_devices)} devices, triggering bulk network data job")
            
            # Get user from cache (stored during prepare_bulk_onboarding)
            user_cache_key = f"bulk_onboarding_user_{self.session.session_id}"
            user_cache_data = cache.get(user_cache_key)
            
            if not user_cache_data:
                onboarding_logger.error("❌ No user found in cache for network data job")
                return
            
            # Get the User object from cache data
            from django.contrib.auth import get_user_model
            User = get_user_model()
            try:
                user = User.objects.get(pk=user_cache_data.get('user_pk') or user_cache_data.get('user_id'))
                onboarding_logger.debug(f"✅ Retrieved user from cache: {user.username}")
            except User.DoesNotExist:
                onboarding_logger.error(f"❌ User not found: {user_cache_data}")
                return
            
            # Filter devices that were found
            valid_device_data = [d for d in device_data_list if d.get('device_id')]
            
            # Create batches for network data jobs using max_bulk_devices setting
            batch_size = self.max_bulk_devices
            network_job_ids = []
            total_processed = 0
            
            for i in range(0, len(valid_device_data), batch_size):
                batch_devices = valid_device_data[i:i + batch_size]
                batch_number = (i // batch_size) + 1
                
                onboarding_logger.info(f"🚀 Triggering network data batch {batch_number} with {len(batch_devices)} devices")
                
                # Trigger bulk network data job for this batch
                job_result_id = self.trigger_bulk_network_data_job(
                    self.session.session_id,
                    batch_devices,
                    user
                )
                
                if job_result_id:
                    network_job_ids.append(job_result_id)
                    total_processed += len(batch_devices)
                    onboarding_logger.info(f"✅ Network data batch {batch_number} triggered successfully")
                else:
                    onboarding_logger.error(f"❌ Failed to trigger network data batch {batch_number}")
            
            if network_job_ids:
                # Mark network jobs as triggered
                cache.set(network_jobs_key, True, timeout=3600)
                
                # Store network job result info (use the first job ID as primary)
                cache.set(network_job_result_key, {
                    'job_result_id': network_job_ids[0],  # Primary job ID
                    'all_job_ids': network_job_ids,      # All job IDs for tracking
                    'device_count': total_processed,
                    'batch_count': len(network_job_ids),
                    'triggered_at': timezone.now().isoformat()
                }, timeout=3600)
                
                onboarding_logger.info(f"✅ All network data batches triggered: {len(network_job_ids)} batches, {total_processed} devices")
            else:
                onboarding_logger.error("❌ Failed to trigger any network data jobs")
                
        except Exception as e:
            onboarding_logger.error(f"❌ Error triggering network data jobs: {e}")
            import traceback
            onboarding_logger.error(f"Traceback: {traceback.format_exc()}")
    
    def retry_batch(self, batch_number: int) -> Dict[str, Any]:
        """
        Retry onboarding for a specific batch.
        
        Args:
            batch_number: The batch number to retry
            
        Returns:
            Dict containing status and job information
        """
        try:
            cache_key = f"bulk_onboarding_batches_{self.session.session_id}"
            batch_data = cache.get(cache_key)
            
            if not batch_data:
                return {
                    'status': 'error',
                    'message': 'No bulk onboarding batches found'
                }
            
            # Find the specific batch
            batches = batch_data.get('batches', [])
            target_batch = None
            
            for batch in batches:
                if batch['batch_number'] == batch_number:
                    target_batch = batch
                    break
            
            if not target_batch:
                return {
                    'status': 'error',
                    'message': f'Batch {batch_number} not found'
                }
            
            # Reset batch status
            target_batch['status'] = 'retrying'
            
            # Clear previous job status
            job_status_key = f"bulk_job_status_{self.session.session_id}_batch_{batch_number}"
            cache.delete(job_status_key)
            
            # Update batch data in cache
            cache.set(cache_key, batch_data, timeout=3600)
            
            return {
                'status': 'success',
                'message': f'Batch {batch_number} retry initiated',
                'batch': target_batch
            }
            
        except Exception as e:
            onboarding_logger.error(f"Error retrying batch {batch_number}: {e}")
            return {
                'status': 'error',
                'message': str(e)
            }
    
    def retry_failed_devices(self, user) -> Dict[str, Any]:
        """
        Retry onboarding for all failed devices across all batches.
        
        Args:
            user: User triggering the retry
        
        Returns:
            Dict containing status and retry information
        """
        try:
            cache_key = f"bulk_onboarding_batches_{self.session.session_id}"
            batch_data = cache.get(cache_key)
            
            if not batch_data:
                return {
                    'status': 'error',
                    'message': 'No bulk onboarding batches found'
                }
            
            # Collect all failed devices
            failed_devices = []
            batches = batch_data.get('batches', [])
            
            for batch in batches:
                batch_number = batch['batch_number']
                job_status_key = f"bulk_job_status_{self.session.session_id}_batch_{batch_number}"
                job_status = cache.get(job_status_key, {})
                
                device_statuses = job_status.get('device_statuses', {})
                for device_ip, status_info in device_statuses.items():
                    if status_info.get('status') == 'failed':
                        failed_devices.append(device_ip)
            
            if not failed_devices:
                return {
                    'status': 'success',
                    'message': 'No failed devices found to retry',
                    'device_count': 0
                }
            
            # Create new batches for failed devices
            retry_result = self.prepare_bulk_onboarding(failed_devices, user)
            
            if retry_result['status'] == 'success':
                return {
                    'status': 'success',
                    'message': f'Retry initiated for {len(failed_devices)} failed devices',
                    'device_count': len(failed_devices),
                    'batches_created': retry_result['total_batches']
                }
            else:
                return retry_result
                
        except Exception as e:
            self.logger.error(f"Error retrying failed devices: {e}")
            return {
                'status': 'error',
                'message': str(e)
            }
    
    def _get_required_objects_for_bulk(self) -> Optional[Dict[str, Any]]:
        """Get all required Nautobot objects for bulk onboarding."""
        try:
            from nautobot.dcim.models import Location
            from nautobot.extras.models import SecretsGroup, Role
            from nautobot.ipam.models import Namespace
            from nautobot.extras.models import Status
            from nautobot.dcim.models import Device, Interface
            from nautobot.ipam.models import IPAddress
            from django.contrib.contenttypes.models import ContentType
            
            # Get location
            location = Location.objects.filter(name=self.session.location).first()
            if not location:
                location = Location.objects.filter(name__icontains=self.session.location).first()
            
            # Get secrets group
            secrets_group = None
            if self.session.secrets_group_name:
                secrets_group = SecretsGroup.objects.filter(name=self.session.secrets_group_name).first()
            
            # Get default namespace (using same logic as individual device onboarding)
            namespace = Namespace.objects.filter(name='Global').first()
            if not namespace:
                namespace = Namespace.objects.first()  # Default namespace
            
            # Get device role (using same logic as individual device onboarding)
            device_role = Role.objects.filter(
                content_types__model='device',
                name__icontains='network'
            ).first()
            if not device_role:
                device_role = Role.objects.filter(content_types__model='device').first()
            
            # Get content types
            device_ct = ContentType.objects.get_for_model(Device)
            interface_ct = ContentType.objects.get_for_model(Interface)
            ipaddress_ct = ContentType.objects.get_for_model(IPAddress)
            
            # Get default statuses (using same logic as individual device onboarding)
            device_status = Status.objects.filter(
                content_types=device_ct, name='Active'
            ).first()
            interface_status = Status.objects.filter(
                content_types=interface_ct, name='Active'
            ).first()
            ip_status = Status.objects.filter(
                content_types=ipaddress_ct, name='Active'
            ).first()
            
            return {
                'location': location,
                'secrets_group': secrets_group,
                'namespace': namespace,
                'device_role': device_role,
                'device_status': device_status,
                'interface_status': interface_status,
                'ip_status': ip_status,
            }
            
        except Exception as e:
            onboarding_logger.error(f"Error getting required objects for bulk onboarding: {e}")
            return None
    
    def _get_selected_devices(self, device_ips: List[str]) -> List:
        """Get selected device objects from the session."""
        try:
            from ..models import DiscoveredDevice
            
            selected_devices = DiscoveredDevice.objects.filter(
                session=self.session,
                ip_address__in=device_ips,
                selected_for_onboarding=True
            )
            
            return list(selected_devices)
            
        except Exception as e:
            self.logger.error(f"Error getting selected devices: {e}")
            return []
    
    def _prepare_device_sync_job_cache(self, device_ips: List[str], selected_devices: List, required_objects: Dict[str, Any], global_settings=None):
        """Prepare and cache device sync job data for each device."""
        try:
            for device_ip in device_ips:
                # Find the device object
                device = next((d for d in selected_devices if d.ip_address == device_ip), None)
                if not device:
                    self.logger.warning(f"Device {device_ip} not found in selected devices")
                    continue
                
                # Get platform for device
                platform_obj = self._get_platform_for_device(device)
                if not platform_obj:
                    self.logger.warning(f'No suitable platform found for device {device_ip}')
                    # Try to get a default platform to prevent complete failure
                    from nautobot.dcim.models import Platform
                    platform_obj = Platform.objects.first()
                    if not platform_obj:
                        self.logger.error(f'No platforms available in system for device {device_ip}')
                        continue
                    self.logger.info(f'Using default platform {platform_obj.name} for device {device_ip}')
                
                # Build device sync job data
                job_data = self._build_device_sync_job_data(device, required_objects, platform_obj, global_settings)
                
                # Cache device sync job data
                cache_key = f"device_sync_job_{self.session.session_id}_{device_ip}"
                cache.set(cache_key, job_data, timeout=3600)
                
                # Also prepare and cache network data job parameters
                network_data_job_data = self._build_network_data_job_data(device, required_objects, platform_obj, global_settings)
                network_cache_key = f"network_data_job_{self.session.session_id}_{device_ip}"
                cache.set(network_cache_key, network_data_job_data, timeout=3600)
                
                self.logger.debug(f"Cached job data for device {device_ip}")
                
        except Exception as e:
            self.logger.error(f"Error preparing device sync job cache: {e}")
    
    def _get_platform_for_device(self, device):
        """Get platform for device based on device platform detection."""
        try:
            from nautobot.dcim.models import Platform
            
            # Try to get platform from device's detected platform (DiscoveredDevice.platform field)
            if hasattr(device, 'platform') and device.platform:
                platform = Platform.objects.filter(name__icontains=device.platform).first()
                if platform:
                    self.logger.info(f"Found platform by device.platform '{device.platform}': {platform.name}")
                    return platform
            
            # Fallback to default platforms based on common device types
            default_platforms = {
                'cisco': 'cisco_ios',
                'juniper': 'juniper_junos',
                'arista': 'arista_eos',
                'hp': 'hp_comware',
                'dell': 'dell_os10',
            }
            
            device_platform_lower = (device.platform or '').lower()
            for vendor, platform_name in default_platforms.items():
                if vendor in device_platform_lower:
                    platform = Platform.objects.filter(name__icontains=platform_name).first()
                    if platform:
                        self.logger.info(f"Found platform by vendor mapping '{vendor}' -> '{platform_name}': {platform.name}")
                        return platform
            
            # Final fallback - get first available platform
            platform = Platform.objects.first()
            if platform:
                self.logger.warning(f"Using fallback platform for device {device.ip_address}: {platform.name}")
            return platform
            
        except Exception as e:
            self.logger.error(f"Error getting platform for device {device.ip_address}: {e}")
            return None
    
    def build_device_sync_job_data(self, device, required_objects: Dict[str, Any], platform_obj):
        """Build job data for SSOTSyncDevices - public method for reuse."""
        return self._build_device_sync_job_data(device, required_objects, platform_obj)
    
    def build_network_data_job_data(self, device, required_objects: Dict[str, Any], platform_obj):
        """Build job data for SSOTSyncNetworkData - public method for reuse."""
        return self._build_network_data_job_data(device, required_objects, platform_obj)
    
    def get_required_objects_for_session(self, session):
        """Get required objects for a session - public method for reuse."""
        # Temporarily set session for the bulk method
        original_session = getattr(self, 'session', None)
        self.session = session
        result = self._get_required_objects_for_bulk()
        self.session = original_session
        return result
    
    def get_platform_for_device(self, device):
        """Get platform for device - public method for reuse."""
        return self._get_platform_for_device(device)
    
    def force_trigger_network_data_jobs(self, user=None) -> Dict[str, Any]:
        """
        Force trigger network data jobs for all completed batches.
        This is a manual override that bypasses the normal trigger conditions.
        
        Args:
            user: Optional user to use for triggering jobs. If not provided, will try to get from cache.
        
        Returns:
            Dict containing status and job information
        """
        try:
            self.logger.info("🚀 Force triggering network data jobs")
            
            # Store user in cache if provided
            if user:
                user_cache_key = f"bulk_onboarding_user_{self.session.session_id}"
                cache.set(user_cache_key, {
                    'username': user.username,
                    'user_id': user.id,
                    'user_pk': user.pk
                }, timeout=3600)
                self.logger.info(f"✅ Stored user in cache: {user.username}")
            
            # Clear the trigger flag to allow re-triggering
            network_jobs_key = f"network_jobs_triggered_{self.session.session_id}"
            cache.delete(network_jobs_key)
            
            # Clear existing network job result to allow re-triggering
            network_job_result_key = f"network_job_result_{self.session.session_id}"
            cache.delete(network_job_result_key)
            
            # Force trigger the network data jobs
            self._trigger_network_data_jobs_if_ready()
            
            # Check if the job was triggered
            network_job_info = cache.get(network_job_result_key)
            if network_job_info:
                return {
                    'status': 'success',
                    'message': 'Network data job triggered successfully',
                    'job_result_id': network_job_info.get('job_result_id'),
                    'device_count': network_job_info.get('device_count')
                }
            else:
                return {
                    'status': 'error',
                    'message': 'Failed to trigger network data job'
                }
                
        except Exception as e:
            self.logger.error(f"Error force triggering network data jobs: {e}")
            return {
                'status': 'error',
                'message': str(e)
            }

    def _trigger_stack_member_creation_if_ready(self) -> bool:
        """
        Trigger stack member creation for successfully onboarded stack devices.
        
        Returns:
            True if all stack member creation is complete (or no stack devices), False if still in progress
        """
        try:
            onboarding_logger.debug(f"🏗️ Checking for stack devices that need member creation...")
            
            # Get batch data
            cache_key = f"bulk_onboarding_batches_{self.session.session_id}"
            batch_data = cache.get(cache_key, {})
            batches = batch_data.get('batches', [])
            
            all_stack_creation_complete = True
            
            for batch in batches:
                batch_number = batch['batch_number']
                device_sync_status = batch.get('device_sync_status', 'pending')
                
                # Only process batches where device sync is completed
                if device_sync_status != 'completed':
                    continue
                
                # Check if this batch has stack devices and needs stack member creation
                batch_device_ips = batch.get('device_ips', [])
                stack_devices_in_batch = []
                
                # Find stack devices in this batch
                for device_ip in batch_device_ips:
                    device_obj = self._find_device_by_ip(device_ip)
                    if device_obj and self._is_stack_device(device_obj):
                        stack_devices_in_batch.append({
                            'device': device_obj,
                            'ip': device_ip
                        })
                
                if not stack_devices_in_batch:
                    # No stack devices in this batch
                    batch['has_stack_devices'] = False
                    batch['stack_member_status'] = 'not_applicable'
                    continue
                
                # This batch has stack devices
                batch['has_stack_devices'] = True
                
                # Check if stack member creation has already been triggered for this batch
                stack_creation_key = f"stack_creation_{self.session.session_id}_batch_{batch_number}"
                stack_creation_status = cache.get(stack_creation_key)
                
                if not stack_creation_status:
                    # Trigger stack member creation for all stack devices in this batch
                    onboarding_logger.info(f"🏗️ Creating stack members for {len(stack_devices_in_batch)} stack devices in batch {batch_number}")
                    
                    stack_results = []
                    for stack_device_info in stack_devices_in_batch:
                        device_obj = stack_device_info['device']
                        device_ip = stack_device_info['ip']
                        
                        # Get stack info from device data
                        stack_info = self._get_stack_info_from_device(device_obj)
                        if not stack_info:
                            onboarding_logger.warning(f"⚠️ No stack info found for device {device_obj.name}")
                            continue
                        
                        # Create stack members
                        onboarding_logger.debug(f"🏗️ Creating stack members for device {device_obj.name} ({device_ip})")
                        result = create_stack_members(
                            device_id=str(device_obj.id),
                            stack_info=stack_info,
                            session_id=str(self.session.session_id)
                        )
                        
                        stack_results.append({
                            'device_ip': device_ip,
                            'device_name': device_obj.name,
                            'result': result
                        })
                    
                    # Cache the stack creation results
                    cache.set(stack_creation_key, {
                        'status': 'completed',
                        'results': stack_results,
                        'timestamp': timezone.now().isoformat()
                    }, timeout=3600)
                    
                    batch['stack_member_status'] = 'completed'
                    onboarding_logger.info(f"✅ Stack member creation completed for batch {batch_number}")
                else:
                    # Stack creation already done
                    batch['stack_member_status'] = stack_creation_status.get('status', 'completed')
                    onboarding_logger.debug(f"✅ Stack member creation already completed for batch {batch_number}")
            
            # Update batch data in cache
            cache.set(cache_key, batch_data, timeout=3600)
            
            # Check if all stack creation is complete
            for batch in batches:
                if batch.get('has_stack_devices', False):
                    stack_status = batch.get('stack_member_status', 'pending')
                    if stack_status not in ['completed', 'not_applicable']:
                        all_stack_creation_complete = False
                        break
            
            onboarding_logger.debug(f"🏗️ Stack member creation status: {'complete' if all_stack_creation_complete else 'in progress'}")
            return all_stack_creation_complete
            
        except Exception as e:
            onboarding_logger.error(f"❌ Error in stack member creation: {e}", exc_info=True)
            return False  # Assume not complete on error
    
    def _find_device_by_ip(self, device_ip: str):
        """Find a device by its IP address."""
        try:
            from nautobot.dcim.models import Device
            from nautobot.ipam.models import IPAddress
            
            # Try to find by primary IP
            ip_obj = IPAddress.objects.filter(host=device_ip).first()
            if ip_obj and hasattr(ip_obj, 'assigned_object') and ip_obj.assigned_object:
                if hasattr(ip_obj.assigned_object, 'device'):
                    return ip_obj.assigned_object.device
                elif hasattr(ip_obj.assigned_object, 'parent_device'):
                    return ip_obj.assigned_object.parent_device
            
            return None
        except Exception as e:
            onboarding_logger.error(f"Error finding device by IP {device_ip}: {e}")
            return None
    
    def _is_stack_device(self, device_obj) -> bool:
        """Check if a device is a stack device."""
        try:
            # Check if device has stack-related data in the session
            from ..models import DiscoveredDevice
            
            discovered_device = DiscoveredDevice.objects.filter(
                session_id=self.session.session_id,
                ip_address=str(device_obj.primary_ip4.host if device_obj.primary_ip4 else device_obj.name)
            ).first()
            
            if discovered_device and discovered_device.device_data:
                return discovered_device.device_data.get('is_stack', False)
            
            return False
        except Exception as e:
            onboarding_logger.error(f"Error checking if device is stack: {e}")
            return False
    
    def _get_stack_info_from_device(self, device_obj) -> Optional[Dict]:
        """Get stack info for a device."""
        try:
            from ..models import DiscoveredDevice
            
            discovered_device = DiscoveredDevice.objects.filter(
                session_id=self.session.session_id,
                ip_address=str(device_obj.primary_ip4.host if device_obj.primary_ip4 else device_obj.name)
            ).first()
            
            if discovered_device and discovered_device.device_data:
                return discovered_device.device_data.get('stack_info', {})
            
            return None
        except Exception as e:
            onboarding_logger.error(f"Error getting stack info for device: {e}")
            return None

    def _build_device_sync_job_data(self, device, required_objects: Dict[str, Any], platform_obj, global_settings=None):
        """Build job data for SSOTSyncDevices using global settings if provided."""
        # Use global settings if provided, otherwise use defaults
        if global_settings:
            job_data = {
                'dryrun': False,
                'memory_profiling': False,
                'debug': False,
                'csv_file': None,
                'location': required_objects['location'].id,
                'namespace': global_settings.get('namespace', required_objects['namespace'].id),
                'ip_addresses': device.ip_address,
                'set_mgmt_only': global_settings.get('set_mgmt_only', True),
                'update_devices_without_primary_ip': global_settings.get('update_devices_without_primary_ip', True),
                'device_role': global_settings.get('device_role') or (required_objects['device_role'].id if required_objects['device_role'] else None),
                'device_status': global_settings.get('device_status', required_objects['device_status'].id),
                'interface_status': global_settings.get('interface_status', required_objects['interface_status'].id),
                'ip_address_status': global_settings.get('ip_status', required_objects['ip_status'].id),
                'port': global_settings.get('port', 22),
                'timeout': global_settings.get('timeout', 60),
                'secrets_group': required_objects['secrets_group'].id,
                'platform': platform_obj.id,
            }
        else:
            # Fallback to original behavior
            job_data = {
                'dryrun': False,
                'memory_profiling': False,
                'debug': False,
                'csv_file': None,
                'location': required_objects['location'].id,
                'namespace': required_objects['namespace'].id,
                'ip_addresses': device.ip_address,
                'set_mgmt_only': True,
                'update_devices_without_primary_ip': True,
                'device_role': required_objects['device_role'].id if required_objects['device_role'] else None,
                'device_status': required_objects['device_status'].id,
                'interface_status': required_objects['interface_status'].id,
                'ip_address_status': required_objects['ip_status'].id,
                'port': 22,
                'timeout': 60,
                'secrets_group': required_objects['secrets_group'].id,
                'platform': platform_obj.id,
            }
        return job_data

    def _build_network_data_job_data(self, device, required_objects: Dict[str, Any], platform_obj, global_settings=None):
        """Build job data for SSOTSyncNetworkData using global settings if provided."""
        # Use global settings if provided, otherwise use defaults
        if global_settings:
            return {
                'dryrun': False,
                'memory_profiling': False,
                'debug': False,
                'devices': [],  # Will be populated with Device UUID when triggered
                'secrets_group': required_objects['secrets_group'].id,
                'location': required_objects['location'].id,
                'namespace': global_settings.get('namespace', required_objects['namespace'].id),
                'interface_status': global_settings.get('interface_status', required_objects['interface_status'].id),
                'ip_address_status': global_settings.get('ip_status', required_objects['ip_status'].id),
                'default_prefix_status': global_settings.get('ip_status', required_objects['ip_status'].id),
                'device_role': global_settings.get('device_role') or (required_objects['device_role'].id if required_objects['device_role'] else None),
                'platform': platform_obj.id,
                'sync_vlans': global_settings.get('sync_vlans', True),
                'sync_vrfs': global_settings.get('sync_vrfs', True),
                'sync_cables': global_settings.get('sync_cables', True),
                'sync_software_version':True,
                'connectivity_test':False
            }
        else:
            # Fallback to original behavior
            return {
                'dryrun': False,
                'memory_profiling': False,
                'debug': False,
                'devices': [],  # Will be populated with Device UUID when triggered
                'secrets_group': required_objects['secrets_group'].id,
                'location': required_objects['location'].id,
                'namespace': required_objects['namespace'].id,
                'interface_status': required_objects['interface_status'].id,
                'ip_address_status': required_objects['ip_status'].id,
                'default_prefix_status': required_objects['ip_status'].id,
                'device_role': required_objects['device_role'].id if required_objects['device_role'] else None,
                'platform': platform_obj.id,
                'sync_vlans': True,
                'sync_vrfs': True,
                'sync_cables': True,
                'sync_software_version':True,
                'connectivity_test':False
            }