"""
Error handling utilities for network inventory discovery.

This module provides standardized error handling and logging utilities
to ensure consistent error responses across the application.
"""

import logging
from typing import Dict, Any, Optional
from django.http import JsonResponse


class ErrorHandler:
    """Standardized error handling for network inventory operations."""
    
    def __init__(self, logger_name: str = 'nautobot_inventory'):
        self.logger = logging.getLogger(logger_name)
    
    def log_and_create_error_response(
        self, 
        error: Exception, 
        context: str = "Unknown operation",
        status_code: int = 500,
        additional_data: Optional[Dict[str, Any]] = None
    ) -> JsonResponse:
        """
        Log an error and create a standardized error response.
        
        Args:
            error: The exception that occurred
            context: Context description of where the error occurred
            status_code: HTTP status code for the response
            additional_data: Additional data to include in the response
            
        Returns:
            JsonResponse with standardized error format
        """
        error_message = str(error)
        
        # Log the error with context
        self.logger.error(f"Error in {context}: {error_message}")
        
        # Create standardized error response
        response_data = {
            'status': 'error',
            'message': f"Error in {context}: {error_message}",
            'error_type': type(error).__name__,
            'context': context
        }
        
        if additional_data:
            response_data.update(additional_data)
        
        return JsonResponse(response_data, status=status_code)
    
    def create_validation_error_response(
        self,
        message: str,
        errors: Optional[Dict[str, Any]] = None,
        status_code: int = 400
    ) -> JsonResponse:
        """
        Create a standardized validation error response.
        
        Args:
            message: Error message
            errors: Validation errors dictionary
            status_code: HTTP status code
            
        Returns:
            JsonResponse with validation error format
        """
        response_data = {
            'status': 'error',
            'message': message,
            'error_type': 'ValidationError'
        }
        
        if errors:
            response_data['validation_errors'] = errors
        
        return JsonResponse(response_data, status=status_code)
    
    def create_success_response(
        self,
        data: Optional[Dict[str, Any]] = None,
        message: str = "Success",
        status_code: int = 200
    ) -> JsonResponse:
        """
        Create a standardized success response.
        
        Args:
            data: Response data
            message: Success message
            status_code: HTTP status code
            
        Returns:
            JsonResponse with success format
        """
        response_data = {
            'status': 'success',
            'message': message
        }
        
        if data:
            response_data.update(data)
        
        return JsonResponse(response_data, status=status_code)


class ConnectionErrorHandler(ErrorHandler):
    """Specialized error handler for connection-related errors."""
    
    def handle_connection_error(
        self,
        error: Exception,
        device_ip: str,
        operation: str = "connection"
    ) -> Dict[str, Any]:
        """
        Handle connection errors with device-specific context.
        
        Args:
            error: The connection exception
            device_ip: IP address of the device
            operation: Type of operation being performed
            
        Returns:
            Dictionary with error information
        """
        error_info = {
            'device_ip': device_ip,
            'operation': operation,
            'error_type': type(error).__name__,
            'error_message': str(error),
            'connection_status': 'failed'
        }
        
        # Log with device context
        self.logger.warning(f"Connection error for {device_ip} during {operation}: {str(error)}")
        
        return error_info


class DeviceInfoErrorHandler(ErrorHandler):
    """Specialized error handler for device information processing errors."""
    
    def handle_device_info_error(
        self,
        error: Exception,
        device_ip: str,
        info_type: str = "device_info"
    ) -> Dict[str, Any]:
        """
        Handle device information processing errors.
        
        Args:
            error: The processing exception
            device_ip: IP address of the device
            info_type: Type of information being processed
            
        Returns:
            Dictionary with error information
        """
        error_info = {
            'device_ip': device_ip,
            'info_type': info_type,
            'error_type': type(error).__name__,
            'error_message': str(error),
            'processing_status': 'failed'
        }
        
        # Log with device context
        self.logger.warning(f"Device info error for {device_ip} processing {info_type}: {str(error)}")
        
        return error_info


# Global error handler instances
api_error_handler = ErrorHandler('nautobot_inventory.api')
connection_error_handler = ConnectionErrorHandler('nautobot_inventory.connection')
device_info_error_handler = DeviceInfoErrorHandler('nautobot_inventory.device_info')
