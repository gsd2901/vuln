from django.apps import AppConfig


class NautobotInventoryConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'nautobot_inventory'
    base_url = 'inventory'
