"""
Device Connection Testing Utility

This module provides reusable functionality for testing device connectivity,
running commands, and detecting device types. It can be used across different
parts of the application for consistent device testing behavior.
"""

import time
import logging
from typing import Dict, Optional, Tuple, Any
from datetime import datetime
from netmiko import ConnectHandler
from netmiko.exceptions import (
    NetmikoTimeoutException, 
    NetmikoAuthenticationException,
    ConnectionException
)

logger = logging.getLogger(__name__)


class DeviceConnectionTester:
    """
    Reusable utility for testing device connectivity and running commands.
    
    This class provides a consistent interface for:
    - Testing device connectivity with various credentials
    - Running commands and capturing output
    - Detecting device types and platforms
    - Handling connection errors gracefully
    """
    
    def __init__(self, timeout: int = 30, max_retries: int = 3):
        """
        Initialize the device connection tester.
        
        Args:
            timeout: Connection timeout in seconds
            max_retries: Maximum number of connection retry attempts
        """
        self.timeout = timeout
        self.max_retries = max_retries
        self.logger = logger
    
    def test_connection(self, ip: str, username: str, password: str, 
                      device_type: str = 'cisco_ios', port: int = 22,
                      enable_password: str = None) -> Dict[str, Any]:
        """
        Test device connectivity with the provided credentials.
        
        Args:
            ip: Device IP address
            username: SSH username
            password: SSH password
            device_type: Netmiko device type (default: cisco_ios)
            port: SSH port (default: 22)
            enable_password: Enable password if needed
            
        Returns:
            Dictionary containing test results with keys:
            - success: Boolean indicating if connection was successful
            - device_info: Dictionary with device information if successful
            - error: Error message if connection failed
            - response_time: Connection response time in seconds
            - detected_device_type: Detected device type
        """
        start_time = time.time()
        
        try:
            # Test connection and get device info
            device_info = self._connect_and_get_info(
                ip, username, password, device_type, port, enable_password
            )
            
            response_time = time.time() - start_time
            
            return {
                'success': True,
                'device_info': device_info,
                'error': None,
                'response_time': round(response_time, 2),
                'detected_device_type': device_info.get('detected_device_type', device_type),
                'tested_at': datetime.now().isoformat(),
                'hostname': device_info.get('hostname', 'unknown'),
                'platform': device_info.get('platform', 'unknown'),
                'model': device_info.get('model', 'unknown'),
                'os_version': device_info.get('os_version', 'unknown')
            }
            
        except Exception as e:
            response_time = time.time() - start_time
            error_msg = str(e)
            
            # Categorize error types for better user feedback
            error_type = self._categorize_error(e)
            
            return {
                'success': False,
                'device_info': None,
                'error': error_msg,
                'error_type': error_type,
                'response_time': round(response_time, 2),
                'detected_device_type': None,
                'tested_at': datetime.now().isoformat(),
                'hostname': None,
                'platform': None,
                'model': None,
                'os_version': None
            }
    
    def _connect_and_get_info(self, ip: str, username: str, password: str,
                            device_type: str, port: int, enable_password: str = None) -> Dict[str, Any]:
        """
        Establish connection and extract device information.
        
        Args:
            ip: Device IP address
            username: SSH username
            password: SSH password
            device_type: Netmiko device type
            port: SSH port
            enable_password: Enable password if needed
            
        Returns:
            Dictionary containing device information
            
        Raises:
            Exception: If connection or command execution fails
        """
        device_conn = {
            'device_type': device_type,
            'ip': ip,
            'username': username,
            'password': password,
            'secret': enable_password or password,
            'port': port,
            'timeout': self.timeout,
            'session_timeout': self.timeout * 2,
            'auth_timeout': min(30, self.timeout),
            'banner_timeout': 30,
            'global_delay_factor': 1,
            'fast_cli': True,
            'auto_connect': True,
            'allow_agent': False,
            'ssh_config_file': None,
            'conn_timeout': self.timeout,
            'use_keys': False,
            'key_file': None,
            'passphrase': None,
            'ssh_strict': False,
            'system_host_keys': False,
            'alt_host_keys': False,
            'alt_key_file': '',
            'sock': None,
        }
        
        # Try multiple connection attempts
        last_exception = None
        
        for attempt in range(self.max_retries):
            try:
                with ConnectHandler(**device_conn) as conn:
                    # Enter enable mode if needed
                    try:
                        conn.enable()
                    except:
                        pass  # Some devices don't need enable mode
                    
                    # Disable paging
                    self._disable_paging(conn)
                    
                    # Extract device information
                    device_info = self._extract_device_info(conn, ip, device_type)
                    
                    return device_info
                    
            except (NetmikoTimeoutException, NetmikoAuthenticationException, ConnectionException) as e:
                last_exception = e
                if attempt < self.max_retries - 1:
                    self.logger.debug(f"Attempt {attempt + 1} failed for {ip}, retrying: {str(e)}")
                    time.sleep(1)  # Wait before retry
                    continue
                else:
                    raise e
            except Exception as e:
                last_exception = e
                if attempt < self.max_retries - 1:
                    self.logger.debug(f"Attempt {attempt + 1} failed for {ip}, retrying: {str(e)}")
                    time.sleep(1)
                    continue
                else:
                    raise e
        
        # If we get here, all attempts failed
        raise last_exception or Exception("Connection failed after all retry attempts")
    
    def _disable_paging(self, conn: ConnectHandler) -> None:
        """Disable paging on the device."""
        paging_commands = [
            'terminal length 0',
            'terminal len 0',
            'set cli pagination off',
            'set cli screen-length 0'
        ]
        
        for cmd in paging_commands:
            try:
                conn.send_command(cmd, delay_factor=1)
                break
            except:
                continue
    
    def _extract_device_info(self, conn: ConnectHandler, ip: str, device_type: str) -> Dict[str, Any]:
        """
        Extract device information by running commands.
        
        Args:
            conn: Active Netmiko connection
            ip: Device IP address
            device_type: Original device type
            
        Returns:
            Dictionary containing device information
        """
        device_info = {
            'ip_address': ip,
            'hostname': 'unknown',
            'model': 'unknown',
            'platform': 'unknown',
            'os_version': 'unknown',
            'serial_number': 'unknown',
            'detected_device_type': device_type,
            'uptime': 'unknown',
            'command_outputs': {}
        }
        
        try:
            # Get basic device information
            version_output = conn.send_command('show version', delay_factor=0.5)
            device_info['command_outputs']['show_version'] = version_output
            
            # Extract hostname
            hostname_output = conn.send_command('show running-config | include hostname', delay_factor=0.5)
            device_info['command_outputs']['hostname_config'] = hostname_output
            
            # Parse device information
            self._parse_device_info(device_info, version_output, hostname_output)
            
            # Try to get additional information
            try:
                uptime_output = conn.send_command('show uptime', delay_factor=0.5)
                device_info['command_outputs']['uptime'] = uptime_output
                device_info['uptime'] = self._extract_uptime(uptime_output)
            except:
                pass
            
            # Try to get interface information
            try:
                interface_output = conn.send_command('show ip interface brief', delay_factor=0.5)
                device_info['command_outputs']['interfaces'] = interface_output
            except:
                pass
            
        except Exception as e:
            self.logger.warning(f"Error extracting device info from {ip}: {e}")
            device_info['error'] = str(e)
        
        return device_info
    
    def _parse_device_info(self, device_info: Dict[str, Any], version_output: str, hostname_output: str) -> None:
        """Parse device information from command outputs."""
        version_lower = version_output.lower()
        
        # Extract hostname
        if hostname_output:
            for line in hostname_output.split('\n'):
                if 'hostname' in line.lower():
                    hostname = line.split()[-1].strip()
                    if hostname and hostname != 'hostname':
                        device_info['hostname'] = hostname
                        break
        
        # Extract model and platform information
        if 'cisco' in version_lower:
            device_info['platform'] = 'cisco'
            # Look for model patterns
            if 'catalyst' in version_lower:
                device_info['model'] = 'Catalyst Switch'
            elif 'isr' in version_lower:
                device_info['model'] = 'ISR Router'
            elif 'asr' in version_lower:
                device_info['model'] = 'ASR Router'
            elif 'nexus' in version_lower:
                device_info['model'] = 'Nexus Switch'
                device_info['detected_device_type'] = 'cisco_nxos'
        elif ('aruba' in version_lower or 'arubaos' in version_lower or 
              'hp procurve' in version_lower or 'hp provision' in version_lower or
              ('hp' in version_lower and any(hp_indicator in version_lower for hp_indicator in [
                  'procurve', 'provision', 'comware', 'hp networking', 'hp switch'
              ]))):
            device_info['platform'] = 'aruba'
            device_info['detected_device_type'] = 'aruba_aoscx'
        elif 'juniper' in version_lower:
            device_info['platform'] = 'juniper'
            device_info['detected_device_type'] = 'juniper_junos'
        elif 'arista' in version_lower:
            device_info['platform'] = 'arista'
            device_info['detected_device_type'] = 'arista_eos'
        
        # Extract OS version
        for line in version_output.split('\n'):
            line = line.strip()
            if 'version' in line.lower() and len(line.split()) > 1:
                # Look for version patterns
                words = line.split()
                for i, word in enumerate(words):
                    if word.lower() == 'version':
                        if i + 1 < len(words):
                            device_info['os_version'] = words[i + 1]
                            break
        
        # Extract serial number
        for line in version_output.split('\n'):
            line = line.strip()
            if 'processor board id' in line.lower() or 'serial number' in line.lower():
                words = line.split()
                for i, word in enumerate(words):
                    if word.lower() in ['id', 'number'] and i + 1 < len(words):
                        device_info['serial_number'] = words[i + 1]
                        break
    
    def _extract_uptime(self, uptime_output: str) -> str:
        """Extract uptime information."""
        for line in uptime_output.split('\n'):
            if 'uptime' in line.lower():
                return line.strip()
        return 'unknown'
    
    def _categorize_error(self, error: Exception) -> str:
        """Categorize connection errors for better user feedback."""
        error_str = str(error).lower()
        
        if 'authentication' in error_str or 'login' in error_str:
            return 'authentication_failed'
        elif 'timeout' in error_str:
            return 'connection_timeout'
        elif 'unreachable' in error_str or 'no route' in error_str:
            return 'host_unreachable'
        elif 'refused' in error_str or 'connection refused' in error_str:
            return 'connection_refused'
        elif 'permission denied' in error_str:
            return 'permission_denied'
        elif 'host key' in error_str:
            return 'host_key_error'
        else:
            return 'unknown_error'
    
    def run_command(self, ip: str, username: str, password: str, command: str,
                   device_type: str = 'cisco_ios', port: int = 22,
                   enable_password: str = None) -> Dict[str, Any]:
        """
        Run a single command on a device.
        
        Args:
            ip: Device IP address
            username: SSH username
            password: SSH password
            command: Command to execute
            device_type: Netmiko device type
            port: SSH port
            enable_password: Enable password if needed
            
        Returns:
            Dictionary containing command results
        """
        start_time = time.time()
        
        try:
            device_conn = {
                'device_type': device_type,
                'ip': ip,
                'username': username,
                'password': password,
                'secret': enable_password or password,
                'port': port,
                'timeout': self.timeout,
                'session_timeout': self.timeout * 2,
                'auth_timeout': min(30, self.timeout),
                'banner_timeout': 30,
                'global_delay_factor': 1,
                'fast_cli': True,
                'auto_connect': True,
                'allow_agent': False,
                'ssh_config_file': None,
                'conn_timeout': self.timeout,
                'use_keys': False,
                'key_file': None,
                'passphrase': None,
                'ssh_strict': False,
                'system_host_keys': False,
                'alt_host_keys': False,
                'alt_key_file': '',
                'sock': None,
            }
            
            with ConnectHandler(**device_conn) as conn:
                # Enter enable mode if needed
                try:
                    conn.enable()
                except:
                    pass
                
                # Disable paging
                self._disable_paging(conn)
                
                # Execute command
                output = conn.send_command(command, delay_factor=0.5)
                
                response_time = time.time() - start_time
                
                return {
                    'success': True,
                    'command': command,
                    'output': output,
                    'response_time': round(response_time, 2),
                    'executed_at': datetime.now().isoformat()
                }
                
        except Exception as e:
            response_time = time.time() - start_time
            
            return {
                'success': False,
                'command': command,
                'output': None,
                'error': str(e),
                'error_type': self._categorize_error(e),
                'response_time': round(response_time, 2),
                'executed_at': datetime.now().isoformat()
            }


class DeviceCredentialValidator:
    """
    Utility class for validating device credentials and testing connectivity.
    """
    
    def __init__(self, tester: DeviceConnectionTester = None):
        """
        Initialize the credential validator.
        
        Args:
            tester: DeviceConnectionTester instance (creates new one if None)
        """
        self.tester = tester or DeviceConnectionTester()
    
    def validate_credentials(self, ip: str, credentials: Dict[str, Any]) -> Dict[str, Any]:
        """
        Validate device credentials and return comprehensive test results.
        
        Args:
            ip: Device IP address
            credentials: Dictionary containing credential information
            
        Returns:
            Dictionary containing validation results
        """
        # Extract credentials
        username = credentials.get('username', '')
        password = credentials.get('password', '')
        device_type = credentials.get('device_type', 'cisco_ios')
        port = credentials.get('port', 22)
        enable_password = credentials.get('enable_password', '')
        
        # Validate required fields
        if not username or not password:
            return {
                'success': False,
                'error': 'Username and password are required',
                'error_type': 'missing_credentials',
                'tested_at': datetime.now().isoformat()
            }
        
        # Test connection
        result = self.tester.test_connection(
            ip=ip,
            username=username,
            password=password,
            device_type=device_type,
            port=port,
            enable_password=enable_password
        )
        
        return result
    
    def test_multiple_device_types(self, ip: str, credentials: Dict[str, Any]) -> Dict[str, Any]:
        """
        Test connection with multiple device types to auto-detect the correct one.
        
        Args:
            ip: Device IP address
            credentials: Dictionary containing credential information
            
        Returns:
            Dictionary containing test results for all device types
        """
        device_types = [
            'cisco_ios',
            'cisco_nxos',
            'cisco_xe',
            'cisco_xr',
            'aruba_aoscx',
            'juniper_junos',
            'arista_eos',
            'hp_comware',
            'hp_procurve'
        ]
        
        results = {}
        successful_types = []
        
        for device_type in device_types:
            try:
                result = self.tester.test_connection(
                    ip=ip,
                    username=credentials.get('username', ''),
                    password=credentials.get('password', ''),
                    device_type=device_type,
                    port=credentials.get('port', 22),
                    enable_password=credentials.get('enable_password', '')
                )
                
                results[device_type] = result
                
                if result['success']:
                    successful_types.append(device_type)
                    
            except Exception as e:
                results[device_type] = {
                    'success': False,
                    'error': str(e),
                    'error_type': self.tester._categorize_error(e)
                }
        
        return {
            'results': results,
            'successful_types': successful_types,
            'recommended_type': successful_types[0] if successful_types else None,
            'tested_at': datetime.now().isoformat()
        }
