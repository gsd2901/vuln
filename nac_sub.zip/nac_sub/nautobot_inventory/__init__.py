from nautobot.apps import NautobotAppConfig


class InventoryConfig(NautobotAppConfig):
    name = "nautobot_inventory"
    verbose_name = "Network Inventory Discovery"
    description = "Network device discovery plugin for Nautobot"
    version = "0.1.0"
    author = "Sameer Dudeja"
    author_email = "s-sameer@hcltech.com"
    base_url = "inventory"
    required_settings = []
    default_settings = {
        "max_discovery_depth": None,  # No limit by default
        "max_concurrent_connections": 50,  # Optimized for 2400 device networks
        "discovery_timeout": 7200,  # 2 hours for large networks
        "device_connection_timeout": 25,  # Balanced timeout for reliability
        "futures_batch_timeout": 180,  # 3 minutes per batch for large networks
        "cdp_lldp_timeout": 300,  # 5 minutes for CDP/LLDP commands
        "cdp_lldp_max_loops": 750,  # Increased for 2400 device networks
        "cdp_lldp_retry_timeout": 600,  # 10 minutes for retry attempts
        "enable_simple_neighbor_fallback": True,  # Fallback for failed detail commands
        "max_bulk_devices": 50,  # Maximum devices per bulk onboarding operation
    }
    caching_config = {}


config = InventoryConfig
