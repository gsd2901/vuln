"""
Stack to Virtual Chassis Conversion Job.

This job converts a single onboarded device (representing a stack) into
a proper Virtual Chassis with individual member devices.

Usage:
1. Discover stack device (gets stack_info in device_data)
2. Onboard device normally (creates 1 Device with management IP)
3. Run this job to:
   - Create Virtual Chassis
   - Create additional member devices (WITHOUT duplicate IPs)
   - Set up proper relationships
"""
import logging
from typing import Dict, Optional

from nautobot.apps.jobs import Job, ObjectVar, BooleanVar
from nautobot.dcim.models import Device, VirtualChassis

from nautobot_inventory.utils.stack_utils import (
    create_stack_members,
    get_stack_info_from_device,
    redistribute_device_interfaces,
    remove_virtual_chassis_conversion,
)

logger = logging.getLogger(__name__)


class ConvertStackToVirtualChassis(Job):
    """
    Convert a discovered and onboarded stack device into Virtual Chassis.
    
    This job takes a single Device (created during onboarding) and transforms it
    into a proper Virtual Chassis with individual member devices.
    
    Key Features:
    - Creates Virtual Chassis object
    - Converts existing device to master member
    - Creates additional Device objects for stack members (WITHOUT IP conflicts)
    - Assigns proper roles, positions, priorities
    - Handles serial numbers correctly
    - Moves interfaces to correct member devices (optional)
    """
    
    class Meta:
        name = "Convert Stack to Virtual Chassis"
        description = "Create Virtual Chassis and member devices from discovered stack"
        grouping = "Network Inventory"
        has_sensitive_variables = False
        task_queues = ["default"]  # Specify the Celery queue to use
    
    device = ObjectVar(
        model=Device,
        description="The onboarded device (will become stack master)",
        query_params={
            "has_primary_ip": True,  # Stack device should have management IP
        }
    )
    
    create_interfaces = BooleanVar(
        description="Create interfaces for member devices based on stack_info",
        default=False,
        required=False
    )
    
    delete_original_interfaces = BooleanVar(
        description="Delete original interfaces from master device after creating members",
        default=False,
        required=False
    )
    
    def run(self, device, create_interfaces, delete_original_interfaces):
        """Main execution logic."""
        self.logger.info(f"🚀 Starting stack conversion for device: {device.name}")
        
        # 1. Get stack information using consolidated utility
        stack_info = get_stack_info_from_device(device)
        if not stack_info:
            self.logger.error(f"❌ No stack information found for device {device.name}")
            return
        
        if not stack_info.get('is_stack') or not stack_info.get('stack_members'):
            self.logger.error(f"❌ Device {device.name} is not a stack or has no members")
            return
        
        self.logger.info(f"📊 Found stack with {len(stack_info['stack_members'])} members")
        
        # 2. Check if already converted
        if device.virtual_chassis:
            self.logger.warning(f"⚠️ Device {device.name} is already part of Virtual Chassis: {device.virtual_chassis.name}")
            
            # If already converted, just optionally redistribute interfaces
            if delete_original_interfaces:
                moved_count = redistribute_device_interfaces(device, device.virtual_chassis, stack_info)
                self.logger.info(f"✅ Redistributed {moved_count} interfaces")
            return
        
        # 3. Use consolidated stack creation function
        # Need to prepare stack_info in the format expected by create_stack_members
        formatted_stack_info = self._format_stack_info_for_creation(stack_info)
        
        result = create_stack_members(
            device_id=str(device.id),
            stack_info=formatted_stack_info,
            create_interfaces=create_interfaces,
            redistribute_interfaces=delete_original_interfaces
        )
        
        if result.get('success'):
        self.logger.info(f"")
        self.logger.info(f"🎉 Stack conversion complete!")
            self.logger.info(f"   Virtual Chassis: {result['virtual_chassis']}")
            self.logger.info(f"   Master Device: {result['master_device']}")
            self.logger.info(f"   Total Members: {result['total_devices']}")
            self.logger.info(f"   Member Devices Created: {result['members_created']}")
        else:
            self.logger.error(f"❌ Stack conversion failed: {result.get('error', 'Unknown error')}")
    
    def _format_stack_info_for_creation(self, stack_info: Dict) -> Dict:
        """
        Format stack_info from job format to create_stack_members format.
        
        The job uses 'stack_members' while create_stack_members expects 'members'.
        Also ensures raw_outputs (including show version) are preserved for serial number fallback.
        """
        formatted = stack_info.copy()
        
        # Convert 'stack_members' to 'members' if needed
        if 'stack_members' in formatted and 'members' not in formatted:
            formatted['members'] = formatted['stack_members']
        
        # Ensure we have total_members count
        if 'total_members' not in formatted and 'members' in formatted:
            formatted['total_members'] = len(formatted['members'])
        
        # Find master switch number
        if 'master_switch_number' in formatted and 'master_switch' not in formatted:
            formatted['master_switch'] = formatted['master_switch_number']
        
        # Ensure raw_outputs are preserved for version output fallback
        if 'raw_outputs' not in formatted:
            formatted['raw_outputs'] = {}
        
        self.logger.debug(f"📋 Formatted stack info has raw_outputs keys: {list(formatted.get('raw_outputs', {}).keys())}")
        
        return formatted
    
    


class RemoveVirtualChassisConversion(Job):
    """
    Reverse a Virtual Chassis conversion.
    
    This job removes Virtual Chassis and consolidates back to a single device.
    Useful for testing or if conversion was done incorrectly.
    """
    
    class Meta:
        name = "Remove Virtual Chassis Conversion"
        description = "Delete Virtual Chassis and member devices (except master)"
        grouping = "Network Inventory"
        has_sensitive_variables = False
        task_queues = ["default"]  # Specify the Celery queue to use
    
    virtual_chassis = ObjectVar(
        model=VirtualChassis,
        description="Virtual Chassis to remove"
    )
    
    keep_member_devices = BooleanVar(
        description="Keep member devices (just unlink from VC)",
        default=False,
        required=False
    )
    
    def run(self, virtual_chassis, keep_member_devices):
        """Remove Virtual Chassis conversion using consolidated utility."""
        result = remove_virtual_chassis_conversion(
            vc=virtual_chassis,
            keep_member_devices=keep_member_devices
        )
        
        if result.get('success'):
            self.logger.info(f"✅ Successfully removed Virtual Chassis")
            self.logger.info(f"   Master Device: {result['master_device']}")
            self.logger.info(f"   Members Processed: {result['members_processed']}")
        else:
            self.logger.error(f"❌ Failed to remove Virtual Chassis: {result.get('error', 'Unknown error')}")
