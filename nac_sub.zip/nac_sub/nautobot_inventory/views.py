import hashlib
import threading
import json
from datetime import timedelta

from django.contrib.auth.mixins import LoginRequiredMixin
from django.contrib.auth.decorators import login_required
from django.views.decorators.csrf import csrf_exempt
from django.db import models
from django.db.models import F, Value
from django.db.models.functions import Concat
from django.http import JsonResponse
from django.shortcuts import render, get_object_or_404
from django.utils import timezone
from django.views import View
from django.views.generic import TemplateView
from django.core.cache import cache
import logging
from nautobot.dcim.models import Location, LocationType, Platform, DeviceType, Device, Interface
from nautobot.extras.models import SecretsGroup, Status, Role, Job, JobResult
from nautobot.extras.choices import SecretsGroupAccessTypeChoices, SecretsGroupSecretTypeChoices, JobResultStatusChoices
from nautobot.ipam.models import Namespace, IPAddress
from django.core.exceptions import ObjectDoesNotExist
from django.contrib.contenttypes.models import ContentType
from django.apps import apps
from nautobot.users.models import Token

from .jobs import NetworkInventoryDiscoveryJob
from .models import InventoryDiscoverySession, DiscoveredDevice
from .utils import (
    ErrorHandler, ConnectionErrorHandler, DeviceInfoErrorHandler, connection_manager,
    DeviceValidationUtils, JobManagementUtils, device_logger, job_logger, inventory_logger,
    onboarding_logger, is_device_failed
)

# Initialize logger
logger = logging.getLogger(__name__)


class PluginConfigAPIView(LoginRequiredMixin, View):
    """API endpoint to get plugin configuration values for frontend."""
    
    def get(self, request):
        """Get plugin configuration values."""
        try:
            from django.conf import settings
            
            plugin_config = getattr(settings, 'PLUGINS_CONFIG', {}).get('nautobot_inventory', {})
            
            # Return relevant configuration values for frontend
            config_data = {
                'max_bulk_devices': plugin_config.get('max_bulk_devices', 50),
                'max_concurrent_connections': plugin_config.get('max_concurrent_connections', 50),
                'discovery_timeout': plugin_config.get('discovery_timeout', 7200),
                'device_connection_timeout': plugin_config.get('device_connection_timeout', 25),
            }
            
            return JsonResponse({
                'status': 'success',
                'config': config_data
            })
            
        except Exception as e:
            return JsonResponse({
                'status': 'error',
                'message': f'Failed to get plugin configuration: {str(e)}'
            }, status=500)

# Initialize error handlers
api_error_handler = ErrorHandler('nautobot_inventory.api')
connection_error_handler = ConnectionErrorHandler('nautobot_inventory.connection')
device_info_error_handler = DeviceInfoErrorHandler('nautobot_inventory.device_info')


class TokenOrSessionAuthMixin:
    """
    Mixin that supports both token-based and session-based authentication.
    This allows API endpoints to be accessed via API tokens or browser sessions.
    """
    
    def dispatch(self, request, *args, **kwargs):
        """Check for token authentication before dispatching the request."""
        # Check for token in Authorization header
        auth_header = request.META.get('HTTP_AUTHORIZATION', '')
        
        if auth_header.startswith('Token '):
            token_key = auth_header.split(' ')[1]
            try:
                token = Token.objects.select_related('user').get(key=token_key)
                
                # Check if token is expired
                if token.is_expired:
                    return JsonResponse({
                        'status': 'error',
                        'message': 'Token expired'
                    }, status=401)
                
                # Check if user is active
                if not token.user.is_active:
                    return JsonResponse({
                        'status': 'error',
                        'message': 'User inactive'
                    }, status=401)
                
                # Set the user on the request
                request.user = token.user
                request.auth = token
                
                # Proceed with the request
                return super().dispatch(request, *args, **kwargs)
                
            except Token.DoesNotExist:
                return JsonResponse({
                    'status': 'error',
                    'message': 'Invalid token'
                }, status=401)
        
        # If no token, fall back to session authentication (LoginRequiredMixin behavior)
        if not request.user.is_authenticated:
            return JsonResponse({
                'status': 'error',
                'message': 'Authentication credentials were not provided.'
            }, status=403)
        
        return super().dispatch(request, *args, **kwargs)


class APIResponseMixin:
    """Mixin for standardizing API responses across all views."""
    
    @staticmethod
    def success_response(data=None, message="Success", status_code=200):
        """Create a standardized success response using ErrorHandler."""
        return api_error_handler.create_success_response(data, message, status_code)
    
    @staticmethod
    def error_response(message="Error", status_code=400, error_details=None):
        """Create a standardized error response using ErrorHandler."""
        return api_error_handler.create_validation_error_response(message, error_details, status_code)
    
    @staticmethod
    def validation_error_response(message="Validation error", errors=None):
        """Create a standardized validation error response using ErrorHandler."""
        return api_error_handler.create_validation_error_response(message, errors)


class NautobotDataMixin:
    """Mixin for getting Nautobot data needed for device onboarding dropdowns."""
    
    def _get_location_path(self, location):
        """Build hierarchical path for a location (e.g., 'A -> B -> C')."""
        path_parts = []
        current = location
        
        # Traverse up the parent chain to build the path
        while current:
            path_parts.insert(0, current.name)
            current = current.parent
        
        return ' -> '.join(path_parts)
    
    def _get_nautobot_data(self):
        """Get all Nautobot data needed for device onboarding dropdowns."""
        try:
            # Get Device content type for status filtering
            device_ct = ContentType.objects.get_for_model(Device)
            interface_ct = ContentType.objects.get_for_model(Interface)
            ipaddress_ct = ContentType.objects.get_for_model(IPAddress)
            
            # Fetch all required data with hierarchical location paths - only Sites
            locations_qs = Location.objects.filter(
                status__name='Active',
                location_type__name='Room'
            ).select_related('parent').order_by('name')
            locations_data = []
            for loc in locations_qs:
                location_path = self._get_location_path(loc)
                locations_data.append({
                    'id': loc.id,
                    'name': loc.name,
                    'display': location_path  # Use hierarchical path for display
                })
            
            data = {
                'locations': locations_data,
                'device_roles': [
                    {'id': role.id, 'name': role.name, 'display': str(role)}
                    for role in Role.objects.filter(
                        content_types=device_ct
                    ).order_by('name')
                ],
                'namespaces': [
                    {'id': ns.id, 'name': ns.name, 'display': str(ns)}
                    for ns in Namespace.objects.all().order_by('name')
                ],
                'device_statuses': [
                    {'id': status.id, 'name': status.name, 'display': str(status)}
                    for status in Status.objects.filter(
                        content_types=device_ct
                    ).order_by('name')
                ],
                'interface_statuses': [
                    {'id': status.id, 'name': status.name, 'display': str(status)}
                    for status in Status.objects.filter(
                        content_types=interface_ct
                    ).order_by('name')
                ],
                'ip_address_statuses': [
                    {'id': status.id, 'name': status.name, 'display': str(status)}
                    for status in Status.objects.filter(
                        content_types=ipaddress_ct
                    ).order_by('name')
                ],
                'secrets_groups': [
                    {'id': sg.id, 'name': sg.name, 'display': str(sg)}
                    for sg in SecretsGroup.objects.all().order_by('name')
                ],
                'platforms': [
                    {'id': platform.id, 'name': platform.name, 'display': str(platform)}
                    for platform in Platform.objects.all().order_by('name')
                ],
            }
            
            return data
            
        except Exception as e:
            logger.error(f"Error getting Nautobot data: {e}")
            return {}


class InventoryDiscoveryHomeView(LoginRequiredMixin, NautobotDataMixin, TemplateView):
    """
    Main discovery page with the interactive UI.
    
    This view provides the primary interface for network inventory discovery,
    including session management, device selection, and onboarding preparation.
    """
    
    template_name = 'nautobot_inventory/discovery.html'
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        
        # Clean up orphaned sessions before displaying
        self.cleanup_orphaned_sessions()
        
        # Check if we're loading an existing session
        session_id = self.request.GET.get('session')
        loaded_session = None
        if session_id:
            try:
                loaded_session = InventoryDiscoverySession.objects.get(session_id=session_id)
            except InventoryDiscoverySession.DoesNotExist:
                pass
        
        # Get recent sessions for the user
        recent_sessions = InventoryDiscoverySession.objects.filter(
            created_at__gte=timezone.now() - timedelta(days=7)
        ).select_related().order_by('-created_at')[:10]
        
        # Get all locations for dropdown with hierarchical paths - only Sites
        locations_qs = Location.objects.filter(
            status__name='Active',
            location_type__name='Room'
        ).select_related('parent').order_by('name')
        locations_with_paths = []
        for loc in locations_qs:
            location_path = self._get_location_path(loc)
            locations_with_paths.append({
                'id': loc.id,
                'name': loc.name,
                'path': location_path
            })
        
        # Get secrets groups that might contain network credentials
        secrets_groups = SecretsGroup.objects.all().prefetch_related('secrets_group_associations').order_by('name')
        
        # Get Nautobot data for onboarding dropdowns
        nautobot_data = self._get_nautobot_data()
        
        context.update({
            'recent_sessions': recent_sessions,
            'locations': locations_with_paths,  # Pass locations with paths
            'secrets_groups': secrets_groups,
            'nautobot_data': nautobot_data,
            'page_title': 'Network Inventory Discovery',
            'loaded_session': loaded_session,
            'loaded_session_json': json.dumps({
                'session_id': str(loaded_session.session_id) if loaded_session else None,
                'location': loaded_session.location if loaded_session else None,
                'router_ip': loaded_session.router_ip if loaded_session else None,
                'secrets_group_name': loaded_session.secrets_group_name if loaded_session else None,
                'username': loaded_session.username if loaded_session else None,
                'status': loaded_session.status if loaded_session else None,
                'device_count': loaded_session.device_count if loaded_session else 0,
                'discovered_data': loaded_session.discovered_data if loaded_session else []
            }) if loaded_session else 'null',
        })
        
        return context
    
    def cleanup_orphaned_sessions(self):
        """
        Clean up sessions that are stuck in 'running' or 'pending' state.
        Mark them as 'stopped' if they've been running for too long.
        """
        try:
            # Sessions running for more than 30 minutes are considered orphaned
            cutoff_time = timezone.now() - timedelta(minutes=30)
            
            orphaned_sessions = InventoryDiscoverySession.objects.filter(
                status__in=['running', 'pending'],
                created_at__lt=cutoff_time
            )
            
            for session in orphaned_sessions:
                session.status = 'stopped'
                session.completed_at = timezone.now()
                session.progress_info = session.progress_info or {}
                session.progress_info['auto_stopped'] = True
                session.progress_info['auto_stopped_reason'] = 'Session exceeded maximum runtime (30 minutes)'
                session.progress_info['auto_stopped_at'] = timezone.now().isoformat()
                session.error_message = 'Session was automatically stopped due to exceeding maximum runtime'
                session.save()
                
        except Exception as e:
            # Log the error but don't fail the view
            logger.error(f"Error cleaning up orphaned sessions: {e}")


class StartDiscoveryAPIView(LoginRequiredMixin, View):
    """API endpoint to start a new discovery session."""
    
    def post(self, request):
        """Start a new network discovery session."""
        try:
            # Extract parameters from request
            location_id = request.POST.get('location', '').strip()
            router_ip = request.POST.get('router_ip', '').strip()
            secrets_group_id = request.POST.get('secrets_group', '').strip()
            
            # Validate required fields
            if not all([location_id, router_ip, secrets_group_id]):
                return JsonResponse({
                    'status': 'error',
                    'message': 'All fields are required: location, router_ip, secrets_group'
                }, status=400)
            
            # Get the location object - ensure it's a Room
            try:
                location = Location.objects.get(
                    id=location_id,
                    location_type__name='Room'
                )
                location_name = location.name
            except Location.DoesNotExist:
                return JsonResponse({
                    'status': 'error',
                    'message': 'Invalid location selected (must be a Room)'
                }, status=400)
            
            # Get the secrets group and extract credentials
            try:
                secrets_group = SecretsGroup.objects.get(id=secrets_group_id)
                
                # Try to get username and password from secrets group
                username_found = False
                last_username_error = None
                
                for access_type in [SecretsGroupAccessTypeChoices.TYPE_SSH, 
                                  SecretsGroupAccessTypeChoices.TYPE_GENERIC]:
                    try:
                        username = secrets_group.get_secret_value(
                            access_type=access_type,
                            secret_type=SecretsGroupSecretTypeChoices.TYPE_USERNAME
                        )
                        username_found = True
                        break
                    except (ObjectDoesNotExist, Exception) as e:
                        last_username_error = str(e)
                        continue
                
                if not username_found:
                    error_msg = f'Could not retrieve username from secrets group "{secrets_group.name}". '
                    error_msg += f'Tried access types: SSH, Generic. '
                    if last_username_error:
                        error_msg += f'Last error: {last_username_error}. '
                    error_msg += 'Please ensure the secrets group contains a username secret with SSH or Generic access type.'
                    
                    return JsonResponse({
                        'status': 'error',
                        'message': error_msg,
                        'error_details': {
                            'error_type': 'SecretsGroupConfigurationError',
                            'secrets_group_name': secrets_group.name,
                            'missing_secret_type': 'username',
                            'tried_access_types': ['SSH', 'Generic'],
                            'last_error': last_username_error,
                            'solution': 'Configure the secrets group with proper username and password secrets having SSH or Generic access types'
                        }
                    }, status=400)
                
                password_found = False
                last_password_error = None
                
                for access_type in [SecretsGroupAccessTypeChoices.TYPE_SSH, 
                                  SecretsGroupAccessTypeChoices.TYPE_GENERIC]:
                    try:
                        password = secrets_group.get_secret_value(
                            access_type=access_type,
                            secret_type=SecretsGroupSecretTypeChoices.TYPE_PASSWORD
                        )
                        password_found = True
                        break
                    except (ObjectDoesNotExist, Exception) as e:
                        last_password_error = str(e)
                        continue
                
                if not password_found:
                    error_msg = f'Could not retrieve password from secrets group "{secrets_group.name}". '
                    error_msg += f'Tried access types: SSH, Generic. '
                    if last_password_error:
                        error_msg += f'Last error: {last_password_error}. '
                    error_msg += 'Please ensure the secrets group contains a password secret with SSH or Generic access type.'
                    
                    return JsonResponse({
                        'status': 'error',
                        'message': error_msg,
                        'error_details': {
                            'error_type': 'SecretsGroupConfigurationError',
                            'secrets_group_name': secrets_group.name,
                            'missing_secret_type': 'password',
                            'tried_access_types': ['SSH', 'Generic'],
                            'last_error': last_password_error,
                            'solution': 'Configure the secrets group with proper username and password secrets having SSH or Generic access types'
                        }
                    }, status=400)
                        
            except SecretsGroup.DoesNotExist:
                return JsonResponse({
                    'status': 'error',
                    'message': 'Invalid secrets group selected'
                }, status=400)
            
            # Create password hash (simple hash for demo - use proper encryption in production)
            password_hash = hashlib.sha256(password.encode()).hexdigest()
            
            # Create discovery session
            session = InventoryDiscoverySession.objects.create(
                location=location_name,
                router_ip=router_ip,
                username=username,
                password_hash=password_hash,
                secrets_group_name=secrets_group.name,
                status='pending'
            )
            
            # Start discovery job asynchronously in a separate thread
            def run_discovery():
                try:
                    job = NetworkInventoryDiscoveryJob()
                    result = job.run(
                        session_id=str(session.session_id),
                        location=location_name,
                        router_ip=router_ip,
                        secrets_group_id=secrets_group_id,
                        username=username if username else None,
                        verbose_logging=False  # Default to reduced logging
                    )
                    
                    # Update session with successful result
                    session.refresh_from_db()
                    if session.status not in ['completed', 'failed', 'stopped']:
                        session.status = 'completed'
                        session.completed_at = timezone.now()
                        session.save()
                        
                except Exception as e:
                    # Enhanced error handling with detailed logging
                    import traceback
                    error_traceback = traceback.format_exc()
                    
                    logger.error(f"Discovery job failed for session {session.session_id}: {str(e)}")
                    logger.error(f"Full traceback: {error_traceback}")
                    
                    # Update session with detailed error information
                    session.refresh_from_db()
                    session.status = 'failed'
                    session.error_message = str(e)
                    session.completed_at = timezone.now()
                    
                    # Store additional error details in progress_info
                    if not session.progress_info:
                        session.progress_info = {}
                    session.progress_info.update({
                        'error_type': type(e).__name__,
                        'error_traceback': error_traceback,
                        'failed_at': timezone.now().isoformat(),
                        'job_execution_error': True
                    })
                    session.save()
            
            # Start the discovery in a background thread
            discovery_thread = threading.Thread(target=run_discovery)
            discovery_thread.daemon = True
            discovery_thread.start()
            
            # Return immediately with session info for progressive updates
            return JsonResponse({
                'status': 'started',
                'session_id': str(session.session_id),
                'discovery_status': 'running',
                'message': 'Discovery started. Use the status endpoint to monitor progress.',
                'polling_url': f'/plugins/inventory/api/status/{session.session_id}/'
            })
                
        except Exception as e:
            return JsonResponse({
                'status': 'error',
                'message': f'Failed to start discovery: {str(e)}'
            }, status=500)


class DiscoveryStatusAPIView(LoginRequiredMixin, View):
    """API endpoint to get discovery session status with progressive updates."""
    
    def get(self, request, session_id):
        """Get the status of a discovery session with real-time device updates."""
        try:
            session = get_object_or_404(InventoryDiscoverySession, session_id=session_id)
            
            # Get devices for this session with all their data
            # Use distinct on ip_address to prevent duplicates, order by discovery depth and discovered_at
            devices = []
            seen_ips = set()
            
            # Get all devices including failed ones - order by ID to get latest updates first
            all_devices = session.devices.all().select_related().order_by('-id', 'discovery_depth', 'discovered_at')
            
            for device in all_devices:
                # Skip duplicates based on IP address, keeping the most recent record
                if device.ip_address in seen_ips:
                    continue
                    
                seen_ips.add(device.ip_address)
                
                # Enrich failed devices with CDP neighbor information from parent device
                hostname = device.hostname
                model = device.model or 'unknown'
                platform = device.platform or 'unknown'
                
                # Check if this is a failed device with CDP neighbor info available
                if device.connection_status in ['failed', 'unreachable', 'timeout', 'auth_failed']:
                    # Try to get CDP neighbor info from parent device
                    parent_ip = getattr(device, 'parent_device', None)
                    logger.debug(f"Failed device {device.ip_address} has parent: {parent_ip}")
                    if parent_ip:
                        try:
                            # Find parent device in this session
                            parent = session.devices.filter(
                                ip_address=parent_ip,
                                connection_status='connected'
                            ).first()
                            
                            logger.debug(f"Parent device found: {parent is not None}, neighbor_info exists: {parent.neighbor_info if parent else None}")
                            
                            # Try to get neighbor info from either neighbor_info field or device_data
                            neighbors = []
                            if parent:
                                if parent.neighbor_info:
                                    neighbors = parent.neighbor_info
                                elif parent.device_data and 'neighbors' in parent.device_data:
                                    neighbors = parent.device_data.get('neighbors', [])
                            
                            if neighbors:
                                logger.debug(f"Parent {parent_ip} has {len(neighbors)} neighbors")
                                # Look for this device's IP in parent's CDP neighbors
                                for neighbor in neighbors:
                                    neighbor_ip = neighbor.get('ip_address', '')
                                    neighbor_hostname = neighbor.get('hostname') or neighbor.get('device_id', '')
                                    logger.debug(f"  Checking neighbor: IP={neighbor_ip}, hostname={neighbor_hostname}")
                                    if neighbor_ip == device.ip_address:
                                        # Found CDP info for this failed device!
                                        cdp_hostname = neighbor.get('hostname') or neighbor.get('device_id')
                                        if cdp_hostname:
                                            hostname = cdp_hostname
                                        if neighbor.get('platform'):
                                            platform = neighbor.get('platform')
                                        # Try to extract model from platform if available
                                        if neighbor.get('platform') and model == 'unknown':
                                            model = neighbor.get('platform')
                                        break
                                else:
                                    logger.warning(f"Failed device {device.ip_address} not found in parent's neighbor list")
                            else:
                                if parent:
                                    logger.warning(f"Parent device {parent_ip} found but has no neighbor_info")
                                else:
                                    logger.warning(f"Parent device {parent_ip} not found in session")
                        except Exception as e:
                            # Log but don't fail - just use default values
                            logger.error(f"Could not enrich failed device {device.ip_address} with CDP data: {e}")
                
                device_data = {
                    'hostname': hostname or f"unknown-{device.ip_address}",
                    'ip_address': device.ip_address,
                    'model': model,
                    'platform': platform,
                    'os_version': device.os_version,
                    'serial_number': device.serial_number,
                    'discovery_depth': device.discovery_depth or 0,
                    'connection_status': device.connection_status or 'unknown',
                    'selected_for_onboarding': getattr(device, 'selected_for_onboarding', False),
                    'custom_credentials': getattr(device, 'custom_credentials', False),
                    'discovered_at': device.discovered_at.isoformat() if device.discovered_at else None,
                    'parent_device': getattr(device, 'parent_device', None),
                    'discovered_via': getattr(device, 'discovered_via', 'unknown'),
                    'final_location_name': device.device_data.get('final_location_name', '') if device.device_data else '',
                }
                
                # Include stack information if available
                if device.device_data and isinstance(device.device_data, dict):
                    if device.device_data.get('is_stack'):
                        device_data['device_data'] = {
                            'is_stack': device.device_data.get('is_stack', False),
                            'stack_info': device.device_data.get('stack_info', {})
                        }
                
                devices.append(device_data)
            
            # Check if there are still devices in discovering state
            discovering_devices = [d for d in devices if d['connection_status'] == 'discovering']
            has_discovering_devices = len(discovering_devices) > 0
            
            # Check for devices that have been discovering for too long (>5 minutes)
            from django.utils import timezone
            from datetime import timedelta
            
            if has_discovering_devices:
                current_time = timezone.now()
                stuck_devices = []
                
                for device_data in discovering_devices:
                    discovered_at_str = device_data.get('discovered_at')
                    if discovered_at_str:
                        try:
                            discovered_at = timezone.datetime.fromisoformat(discovered_at_str.replace('Z', '+00:00'))
                            if current_time - discovered_at > timedelta(minutes=5):
                                stuck_devices.append(device_data['ip_address'])
                        except:
                            pass
                
                # Mark stuck devices as failed
                if stuck_devices:
                    session.devices.filter(
                        ip_address__in=stuck_devices,
                        connection_status='discovering'
                    ).update(
                        connection_status='failed',
                        hostname=Concat(Value('timeout-'), F('ip_address'))
                    )
                    # Refresh devices list after update
                    discovering_devices = [d for d in discovering_devices if d['ip_address'] not in stuck_devices]
                    has_discovering_devices = len(discovering_devices) > 0
            
            # Check if session should be marked as complete based on device states
            # If session is still 'running' but no devices are discovering and we have devices processed
            all_devices = session.devices.all()
            total_devices = all_devices.count()
            final_state_devices = all_devices.exclude(connection_status='discovering').count()
            
            # Auto-complete session if all devices have reached final state
            # BUT ONLY if the session has been stable for at least 15 seconds
            # This prevents premature completion when neighbor discovery is still queuing devices
            should_auto_complete = False
            if (session.status == 'running' and 
                total_devices > 0 and 
                final_state_devices == total_devices and 
                not has_discovering_devices):
                
                # Check if session has been stable (no new devices) for at least 15 seconds
                # Get the most recent device update time
                most_recent_device = all_devices.order_by('-discovered_at').first()
                if most_recent_device and most_recent_device.discovered_at:
                    time_since_last_device = timezone.now() - most_recent_device.discovered_at
                    if time_since_last_device.total_seconds() >= 15:
                        should_auto_complete = True
                        logger.info(f"Session {session_id} has been stable for {time_since_last_device.total_seconds():.1f}s, auto-completing")
                    else:
                        logger.debug(f"Session {session_id} not stable yet ({time_since_last_device.total_seconds():.1f}s < 15s), waiting before auto-complete")
                
                if should_auto_complete:
                    # Update session status to completed
                    session.status = 'completed'
                    session.completed_at = timezone.now()
                    session.save()
                    logger.info(f"Auto-completed session {session_id} - all {total_devices} devices processed")
            
            # Override session status if there are still discovering devices
            actual_is_running = session.status in ['pending', 'running'] or has_discovering_devices
            actual_is_complete = session.status in ['completed', 'failed', 'timeout', 'stopped'] and not has_discovering_devices
            
            response_data = {
                'status': session.status,
                'location': session.location,
                'router_ip': session.router_ip,
                'device_count': len(devices),  # Use actual device count from DB
                'devices': devices,
                'progress_info': session.progress_info,
                'created_at': session.created_at.isoformat(),
                'updated_at': session.updated_at.isoformat(),
                'is_running': actual_is_running,
                'is_complete': actual_is_complete,
                'discovering_devices_count': len(discovering_devices),
                'has_discovering_devices': has_discovering_devices,
            }
            
            # Enhanced error information
            if session.error_message:
                response_data['error_message'] = session.error_message
                
                # Add detailed error information if available
                if session.progress_info:
                    error_details = {}
                    if 'error_type' in session.progress_info:
                        error_details['error_type'] = session.progress_info['error_type']
                    if 'error_traceback' in session.progress_info:
                        error_details['error_traceback'] = session.progress_info['error_traceback']
                    if 'failed_at' in session.progress_info:
                        error_details['failed_at'] = session.progress_info['failed_at']
                    if 'job_execution_error' in session.progress_info:
                        error_details['job_execution_error'] = session.progress_info['job_execution_error']
                    
                    if error_details:
                        response_data['error_details'] = error_details
                
            if session.completed_at:
                response_data['completed_at'] = session.completed_at.isoformat()
            
            return JsonResponse(response_data)
            
        except Exception as e:
            return JsonResponse({
                'status': 'error',
                'message': str(e)
            }, status=404)


class UpdateDeviceSelectionAPIView(LoginRequiredMixin, View):
    """API endpoint to update device selection for onboarding."""
    
    def post(self, request, session_id):
        """Update which devices are selected for onboarding."""
        try:
            import json
            from django.db.models import Count
            
            session = get_object_or_404(InventoryDiscoverySession, session_id=session_id)
            data = json.loads(request.body)
            selected_ips = data.get('selected_devices', [])
            
            # Check for and clean up duplicate IP addresses in the session
            duplicate_ips = session.devices.values('ip_address').annotate(
                count=Count('ip_address')
            ).filter(count__gt=1)
            
            if duplicate_ips:
                for dup in duplicate_ips:
                    devices_with_ip = session.devices.filter(ip_address=dup['ip_address']).order_by('-discovered_at')
                    if devices_with_ip.count() > 1:
                        # Keep the most recent device, delete older duplicates
                        latest_device = devices_with_ip.first()
                        older_devices = devices_with_ip[1:]
                        for old_device in older_devices:
                            old_device.delete()
            
            # Update device selection
            session.devices.all().update(selected_for_onboarding=False)
            
            # Track filtered out devices
            filtered_count = 0
            
            if selected_ips:
                # Handle potential duplicate devices by selecting only the most recent device for each IP
                for ip in selected_ips:
                    latest_device = session.devices.filter(ip_address=ip).order_by('-discovered_at').first()
                    if latest_device:
                        # Filter out failed devices - they should not be selected for onboarding
                        if is_device_failed(latest_device):
                            filtered_count += 1
                            logger.warning(f"Skipping failed device {ip} from onboarding selection")
                            continue
                        
                        latest_device.selected_for_onboarding = True
                        latest_device.save()
            
            selected_count = session.devices.filter(selected_for_onboarding=True).count()
            
            response_data = {
                'status': 'success',
                'selected_count': selected_count,
                'message': f'{selected_count} devices selected for onboarding'
            }
            
            # Add warning if any failed devices were filtered out
            if filtered_count > 0:
                response_data['warning'] = f'{filtered_count} failed device(s) were excluded from selection'
                response_data['filtered_count'] = filtered_count
            
            return JsonResponse(response_data)
            
        except Exception as e:
            logger.error(f"UpdateDeviceSelectionAPIView error: {e}")
            return JsonResponse({
                'status': 'error',
                'message': str(e)
            }, status=500)
    

class PrepareOnboardingAPIView(LoginRequiredMixin, APIResponseMixin, View):
    """API endpoint to prepare selected devices for onboarding."""
    
    def _check_onboarding_plugin_availability(self):
        """Check if the nautobot_device_onboarding plugin is available."""
        try:
            onboarding_app = apps.get_app_config('nautobot_device_onboarding')
            from nautobot_device_onboarding.jobs import SSOTSyncDevices
            from nautobot.extras.jobs import get_job
            
            # Test get_job function
            job_class = get_job('nautobot_device_onboarding.jobs.SSOTSyncDevices')
            onboarding_logger.info(f"Device onboarding plugin detected successfully: {onboarding_app}")
            return True, None
        except (LookupError, ImportError) as e:
            onboarding_logger.warning(f"Device onboarding plugin not available: {e}")
            return False, str(e)
        except Exception as e:
            onboarding_logger.error(f"Error testing onboarding plugin: {e}")
            return False, str(e)
    
    def _get_required_objects(self, session):
        """Get all required Nautobot objects for onboarding."""
        try:
            # Get location - only Sites
            location = Location.objects.filter(
                name=session.location,
                location_type__name='Room'
            ).first()
            if not location:
                location = Location.objects.filter(
                    name__icontains=session.location,
                    location_type__name='Room'
                ).first()
            
            # Get secrets group
            secrets_group = None
            if session.secrets_group_name:
                secrets_group = SecretsGroup.objects.filter(name=session.secrets_group_name).first()
            
            # Get device role
            device_role_obj = Role.objects.filter(
                content_types__model='device',
                name__icontains='network'
            ).first()
            if not device_role_obj:
                device_role_obj = Role.objects.filter(content_types__model='device').first()
            
            # Get default statuses
            device_ct = ContentType.objects.get_for_model(Device)
            interface_ct = ContentType.objects.get_for_model(Interface)
            ipaddress_ct = ContentType.objects.get_for_model(IPAddress)
            
            default_device_status = Status.objects.filter(
                content_types=device_ct, name='Active'
            ).first()
            default_interface_status = Status.objects.filter(
                content_types=interface_ct, name='Active'
            ).first()
            default_ip_status = Status.objects.filter(
                content_types=ipaddress_ct, name='Active'
            ).first()
            
            # Get default namespace
            default_namespace = Namespace.objects.filter(name='Madurai').first()
            if not default_namespace:
                default_namespace = Namespace.objects.first()
            
            return {
                'location': location,
                'secrets_group': secrets_group,
                'device_role': device_role_obj,
                'device_status': default_device_status,
                'interface_status': default_interface_status,
                'ip_status': default_ip_status,
                'namespace': default_namespace
            }
        except Exception as e:
            logger.error(f"Error getting required objects: {e}")
            return None
    
    def _get_platform_for_device(self, device):
        """Get or create appropriate platform for device."""
        from .jobs import get_or_create_platform
        
        platform_obj = None
        if device.platform:
            try:
                platform_obj = get_or_create_platform(device.platform)
                if platform_obj:
                    logger.info(f"Platform validation successful: {platform_obj.name} with napalm_driver: {platform_obj.network_driver}")
                else:
                    logger.warning(f"Platform validation failed for device {device.ip_address} with platform '{device.platform}'")
            except Exception as e:
                logger.error(f"Exception during platform validation: {e}")
                platform_obj = None
        
        # Try fallback platforms if no platform found
        if not platform_obj:
            fallback_platforms = ['cisco_ios', 'Cisco IOS-XE', 'cisco_nxos', 'Cisco NX-OS', 'juniper_junos', 'arista_eos']
            for platform_name in fallback_platforms:
                platform_obj = Platform.objects.filter(
                    name=platform_name,
                    napalm_driver__isnull=False
                ).exclude(napalm_driver='').first()
                if platform_obj:
                    logger.info(f"Using fallback platform {platform_obj.name} with napalm_driver: {platform_obj.napalm_driver}")
                    break
        
        # Final fallback
        if not platform_obj:
            platform_obj = Platform.objects.filter(napalm_driver__isnull=False).exclude(napalm_driver='').first()
            if platform_obj:
                logger.warning(f"Using final fallback platform {platform_obj.name} with napalm_driver: {platform_obj.napalm_driver}")
        
        return platform_obj
    
    def _create_generic_associations(self, secrets_group, device_ip):
        """Create Generic access type associations for the secrets group if they don't exist."""
        from nautobot.extras.models import Secret, SecretsGroupAssociation
        from nautobot.extras.choices import SecretsGroupAccessTypeChoices, SecretsGroupSecretTypeChoices
        
        onboarding_logger.debug(f"Creating Generic associations for secrets group: {secrets_group.name}")
        
        # Find existing secrets that can be used for Generic associations
        existing_secrets = {}
        for assoc in secrets_group.secrets_group_associations.all():
            if assoc.secret_type == SecretsGroupSecretTypeChoices.TYPE_USERNAME:
                existing_secrets['username'] = assoc.secret
            elif assoc.secret_type == SecretsGroupSecretTypeChoices.TYPE_PASSWORD:
                existing_secrets['password'] = assoc.secret
        
        # Create Generic associations for username if it doesn't exist
        if 'username' in existing_secrets:
            username_secret = existing_secrets['username']
            # Check if Generic association already exists
            if not secrets_group.secrets_group_associations.filter(
                secret=username_secret,
                access_type=SecretsGroupAccessTypeChoices.TYPE_GENERIC,
                secret_type=SecretsGroupSecretTypeChoices.TYPE_USERNAME
            ).exists():
                SecretsGroupAssociation.objects.create(
                    secrets_group=secrets_group,
                    secret=username_secret,
                    access_type=SecretsGroupAccessTypeChoices.TYPE_GENERIC,
                    secret_type=SecretsGroupSecretTypeChoices.TYPE_USERNAME
                )
                logger.info(f"Created Generic username association for {username_secret.name}")
            else:
                logger.debug(f"Generic username association already exists for {username_secret.name}")
        else:
            raise Exception("No username secret found to create Generic association")
        
        # Create Generic associations for password if it doesn't exist
        if 'password' in existing_secrets:
            password_secret = existing_secrets['password']
            # Check if Generic association already exists
            if not secrets_group.secrets_group_associations.filter(
                secret=password_secret,
                access_type=SecretsGroupAccessTypeChoices.TYPE_GENERIC,
                secret_type=SecretsGroupSecretTypeChoices.TYPE_PASSWORD
            ).exists():
                SecretsGroupAssociation.objects.create(
                    secrets_group=secrets_group,
                    secret=password_secret,
                    access_type=SecretsGroupAccessTypeChoices.TYPE_GENERIC,
                    secret_type=SecretsGroupSecretTypeChoices.TYPE_PASSWORD
                )
                logger.info(f"Created Generic password association for {password_secret.name}")
            else:
                logger.debug(f"Generic password association already exists for {password_secret.name}")
        else:
            raise Exception("No password secret found to create Generic association")
        
        logger.info(f"Successfully created Generic associations for secrets group: {secrets_group.name}")

    def post(self, request, session_id):
        """Prepare selected devices for onboarding."""
        try:
            session = get_object_or_404(InventoryDiscoverySession, session_id=session_id)
            selected_devices = session.devices.filter(selected_for_onboarding=True)
            
            # Parse global settings from request body if provided
            global_settings = None
            if request.content_type == 'application/json' and request.body:
                try:
                    request_data = json.loads(request.body)
                    global_settings = request_data.get('global_settings')
                    if global_settings:
                        onboarding_logger.info(f"PrepareOnboardingAPIView: Using global settings: {global_settings}")
                except json.JSONDecodeError:
                    onboarding_logger.warning("Failed to parse request body JSON, proceeding without global settings")
            
            onboarding_logger.info(f"PrepareOnboardingAPIView: Found {selected_devices.count()} selected devices")
            for device in selected_devices:
                onboarding_logger.debug(f"  - {device.ip_address} ({device.hostname})")
            
            if not selected_devices.exists():
                return self.error_response('No devices selected for onboarding', 400)
            
            # Filter out failed devices as an additional safety check
            valid_devices = []
            filtered_devices = []
            
            for device in selected_devices:
                if is_device_failed(device):
                    filtered_devices.append(device.ip_address)
                    onboarding_logger.warning(f"Filtering out failed device {device.ip_address} from onboarding")
                else:
                    valid_devices.append(device)
            
            if not valid_devices:
                return self.error_response(
                    'No valid devices selected for onboarding. All selected devices are in a failed state.',
                    400
                )
            
            # Check plugin availability
            onboarding_available, plugin_error = self._check_onboarding_plugin_availability()
            
            if onboarding_available:
                result = self._create_onboarding_jobs(session, valid_devices, request.user, global_settings)
                # Add warning about filtered devices if any
                if filtered_devices and result.status_code == 200:
                    result_data = json.loads(result.content)
                    result_data['filtered_devices'] = filtered_devices
                    result_data['filtered_count'] = len(filtered_devices)
                    if 'message' in result_data:
                        result_data['message'] += f" ({len(filtered_devices)} failed device(s) were excluded)"
                    result.content = json.dumps(result_data)
                return result
            else:
                result = self._prepare_csv_export(session, valid_devices)
                # Add warning about filtered devices if any
                if filtered_devices and result.status_code == 200:
                    result_data = json.loads(result.content)
                    result_data['filtered_devices'] = filtered_devices
                    result_data['filtered_count'] = len(filtered_devices)
                    result.content = json.dumps(result_data)
                return result
                
        except Exception as e:
            onboarding_logger.error(f"Error in PrepareOnboardingAPIView: {e}")
            return self.error_response(f'Failed to prepare onboarding: {str(e)}', 500)
    
    def _create_onboarding_jobs(self, session, selected_devices, user, global_settings=None):
        """Create onboarding jobs for selected devices."""
        # Get required objects once using JobManagementUtils
        job_utils = JobManagementUtils(session=session)
        required_objects = job_utils.get_required_objects_for_session(session)
        if not required_objects:
            return self.error_response('Failed to get required Nautobot objects', 500)
        
        # Validate required objects
        if not required_objects['location']:
            return self.error_response(f'Location "{session.location}" not found', 400)
        if not required_objects['secrets_group']:
            return self.error_response(f'Secrets group "{session.secrets_group_name}" not found', 400)
        
        onboarding_jobs = []
        failed_jobs = []
        duplicate_jobs = []
        
        for device in selected_devices:
            try:
                job_result = self._create_device_onboarding_job(device, session, required_objects, user, global_settings)
                
                if job_result and job_result.get('status') == 'duplicate_detected':
                    duplicate_jobs.append(job_result)
                elif job_result and job_result.get('status') == 'sync_devices_started':
                    onboarding_jobs.append(job_result)
                elif job_result:
                    # Some other status - treat as failure
                    failed_jobs.append({
                        'device': device.ip_address,
                        'error': job_result.get('message', 'Unknown error')
                    })
                else:
                    failed_jobs.append({
                        'device': device.ip_address,
                        'error': 'Failed to create onboarding job'
                    })
            except Exception as e:
                failed_jobs.append({
                    'device': device.ip_address,
                    'error': str(e)
                })
        
        return self._format_onboarding_response(onboarding_jobs, failed_jobs, duplicate_jobs)
    
    def _create_device_onboarding_job(self, device, session, required_objects, user, global_settings=None):
        """Create onboarding job for a single device."""
        # Use JobManagementUtils for consistency
        job_utils = JobManagementUtils(session=session)
        
        # Get platform for device
        platform_obj = job_utils.get_platform_for_device(device)
        if not platform_obj:
            raise Exception(f'No suitable platform found for device {device.ip_address}')
        
        # Check if device already exists in Nautobot and has previous job IDs
        duplicate_info = self._check_device_duplicate_status(device, session)
        if duplicate_info['is_duplicate']:
            # Return duplicate status for frontend to handle
            return {
                'device': device.ip_address,
                'hostname': device.hostname,
                'status': 'duplicate_detected',
                'duplicate_info': duplicate_info,
                'message': duplicate_info['message']
            }
        
        # Validate secrets group associations
        self._validate_secrets_group_associations(required_objects['secrets_group'], device.ip_address)
        
        # Create job data using global settings if provided
        job_data = self._build_job_data(device, session, required_objects, platform_obj, global_settings)
        
        # Execute SSOTSyncDevices job
        try:
            sync_devices_job_model = Job.objects.get(job_class_name='SSOTSyncDevices')
            sync_devices_result = JobResult.enqueue_job(
                job_model=sync_devices_job_model,
                user=user,
                **job_data
            )
            
            # Update device record
            device.onboarding_job_id = str(sync_devices_result.id)
            device.save()
            
            # Store network data job parameters for later execution using global settings
            network_data_job_data = self._build_network_data_job_data(device, session, required_objects, platform_obj, global_settings)
            cache_key = f"network_data_job_{session.session_id}_{device.ip_address}"
            cache.set(cache_key, network_data_job_data, timeout=3600)
            
            return {
                'device': device.ip_address,
                'hostname': device.hostname,
                'sync_devices_job_id': str(sync_devices_result.id),
                'network_data_job_id': None,
                'status': 'sync_devices_started',
                'sync_devices_status': 'running',
                'network_data_status': 'pending'
            }
            
        except Job.DoesNotExist:
            raise Exception('SSOTSyncDevices job not found. Please ensure the device onboarding plugin is properly installed.')
    
    def _check_device_duplicate_status(self, device, session):
        """
        Check if device already exists in Nautobot and has previous job IDs.
        
        Returns:
            Dict with duplicate status information
        """
        try:
            from nautobot.dcim.models import Device
            from nautobot.ipam.models import IPAddress
            
            # Check if device exists in Nautobot
            device_exists_in_nautobot = False
            existing_device = None
            
            # Check by hostname
            if device.hostname and device.hostname not in ['unknown', '']:
                existing_device = Device.objects.filter(name=device.hostname).first()
                if existing_device:
                    device_exists_in_nautobot = True
            
            # Check by primary IP if not found by hostname
            if not device_exists_in_nautobot:
                existing_device = Device.objects.filter(primary_ip4__host=device.ip_address).first()
                if existing_device:
                    device_exists_in_nautobot = True
            
            # Check by any interface IP if not found by primary IP
            if not device_exists_in_nautobot:
                existing_device = Device.objects.filter(interfaces__ip_addresses__host=device.ip_address).first()
                if existing_device:
                    device_exists_in_nautobot = True
            
            # Check if device has previous job IDs from this session
            has_previous_jobs = bool(device.onboarding_job_id or device.network_data_job_id)
            
            # Determine if this is a duplicate that needs confirmation
            is_duplicate = device_exists_in_nautobot or has_previous_jobs
            
            if not is_duplicate:
                return {
                    'is_duplicate': False,
                    'device_exists': False,
                    'has_previous_jobs': False
                }
            
            # Build detailed duplicate information
            duplicate_info = {
                'is_duplicate': True,
                'device_exists': device_exists_in_nautobot,
                'has_previous_jobs': has_previous_jobs,
                'existing_device_name': existing_device.name if existing_device else None,
                'existing_device_id': str(existing_device.id) if existing_device else None,
                'previous_sync_job_id': device.onboarding_job_id,
                'previous_network_job_id': device.network_data_job_id
            }
            
            # Create appropriate message
            if device_exists_in_nautobot and has_previous_jobs:
                duplicate_info['message'] = (
                    f'Device {device.ip_address} ({device.hostname}) already exists in Nautobot '
                    f'as "{existing_device.name}" and has previous onboarding jobs in this session. '
                    f'Re-onboarding will reset job IDs and may create duplicate data.'
                )
                duplicate_info['warning_level'] = 'high'
            elif device_exists_in_nautobot:
                duplicate_info['message'] = (
                    f'Device {device.ip_address} ({device.hostname}) already exists in Nautobot '
                    f'as "{existing_device.name}". Re-onboarding may create duplicate data.'
                )
                duplicate_info['warning_level'] = 'medium'
            elif has_previous_jobs:
                duplicate_info['message'] = (
                    f'Device {device.ip_address} ({device.hostname}) has previous onboarding jobs '
                    f'in this session. Re-onboarding will reset job IDs and start fresh.'
                )
                duplicate_info['warning_level'] = 'low'
            
            return duplicate_info
            
        except Exception as e:
            logger.error(f"Error checking device duplicate status for {device.ip_address}: {e}")
            return {
                'is_duplicate': False,
                'device_exists': False,
                'has_previous_jobs': False,
                'error': str(e)
            }
    
    def _reset_device_job_ids(self, device):
        """Reset job IDs for a device to allow re-onboarding."""
        try:
            onboarding_logger.info(f"Resetting job IDs for device {device.ip_address} - user confirmed re-onboarding")
            device.onboarding_job_id = None
            device.network_data_job_id = None
            device.stack_member_job_id = None
            device.network_data_retry_count = 0
            device.save()
            return True
        except Exception as e:
            onboarding_logger.error(f"Error resetting job IDs for device {device.ip_address}: {e}")
            return False

    def _validate_secrets_group_associations(self, secrets_group, device_ip):
        """Validate and create Generic associations if needed."""
        from nautobot.extras.choices import SecretsGroupAccessTypeChoices, SecretsGroupSecretTypeChoices
        
        # Check for Generic associations
        has_generic_auth = False
        has_ssh_auth = False
        
        for assoc in secrets_group.secrets_group_associations.all():
            if (assoc.access_type == SecretsGroupAccessTypeChoices.TYPE_GENERIC and 
                assoc.secret_type == SecretsGroupSecretTypeChoices.TYPE_USERNAME):
                has_generic_auth = True
            elif (assoc.access_type == SecretsGroupAccessTypeChoices.TYPE_SSH and 
                  assoc.secret_type == SecretsGroupSecretTypeChoices.TYPE_USERNAME):
                has_ssh_auth = True
        
        if not has_generic_auth and not has_ssh_auth:
            # Try to create Generic associations
            try:
                self._create_generic_associations(secrets_group, device_ip)
            except Exception as e:
                raise Exception(f'Secrets group missing required associations: {str(e)}')
    
    def _build_job_data(self, device, session, required_objects, platform_obj, global_settings=None):
        """Build job data for SSOTSyncDevices using global settings if provided."""
        # Use global settings if provided, otherwise use defaults
        if global_settings:
            job_data = {
                'dryrun': False,
                'memory_profiling': False,
                'debug': False,
                'csv_file': None,
                'location': required_objects['location'].id,
                'namespace': global_settings.get('namespace', required_objects['namespace'].id),
                'ip_addresses': device.ip_address,
                'set_mgmt_only': global_settings.get('set_mgmt_only', False),
                'update_devices_without_primary_ip': global_settings.get('update_devices_without_primary_ip', True),
                'device_role': global_settings.get('device_role') or (required_objects['device_role'].id if required_objects['device_role'] else None),
                'device_status': global_settings.get('device_status', required_objects['device_status'].id),
                'interface_status': global_settings.get('interface_status', required_objects['interface_status'].id),
                'ip_address_status': global_settings.get('ip_status', required_objects['ip_status'].id),
                'port': global_settings.get('port', 22),
                'timeout': global_settings.get('timeout', 60),
                'secrets_group': required_objects['secrets_group'].id,
                'platform': platform_obj.id,
            }
        else:
            # Fallback to original behavior
            job_data = {
                'dryrun': False,
                'memory_profiling': False,
                'debug': False,
                'csv_file': None,
                'location': required_objects['location'].id,
                'namespace': required_objects['namespace'].id,
                'ip_addresses': device.ip_address,
                'set_mgmt_only': True,
                'update_devices_without_primary_ip': True,
                'device_role': required_objects['device_role'].id if required_objects['device_role'] else None,
                'device_status': required_objects['device_status'].id,
                'interface_status': required_objects['interface_status'].id,
                'ip_address_status': required_objects['ip_status'].id,
                'port': 22,
                'timeout': 60,
                'secrets_group': required_objects['secrets_group'].id,
                'platform': platform_obj.id,
            }
        return job_data
    
    def _build_network_data_job_data(self, device, session, required_objects, platform_obj, global_settings=None):
        """Build job data for SSOTSyncNetworkData using global settings if provided."""
        # Use global settings if provided, otherwise use defaults
        if global_settings:
            return {
                'dryrun': False,
                'memory_profiling': False,
                'debug': False,
                'devices': [],  # Will be populated with Device UUID when triggered
                'secrets_group': required_objects['secrets_group'].id,
                'location': required_objects['location'].id,
                'namespace': global_settings.get('namespace', required_objects['namespace'].id),
                'interface_status': global_settings.get('interface_status', required_objects['interface_status'].id),
                'ip_address_status': global_settings.get('ip_status', required_objects['ip_status'].id),
                'default_prefix_status': global_settings.get('ip_status', required_objects['ip_status'].id),
                'device_role': global_settings.get('device_role') or (required_objects['device_role'].id if required_objects['device_role'] else None),
                'platform': platform_obj.id,
                'sync_vlans': global_settings.get('sync_vlans', True),
                'sync_vrfs': global_settings.get('sync_vrfs', True),
                'sync_cables': global_settings.get('sync_cables', True),
                'sync_software_version':True,
                'connectivity_test':False
            }
        else:
            # Fallback to original behavior
            return {
                'dryrun': False,
                'memory_profiling': False,
                'debug': False,
                'devices': [],  # Will be populated with Device UUID when triggered
                'secrets_group': required_objects['secrets_group'].id,
                'location': required_objects['location'].id,
                'namespace': required_objects['namespace'].id,
                'interface_status': required_objects['interface_status'].id,
                'ip_address_status': required_objects['ip_status'].id,
                'default_prefix_status': required_objects['ip_status'].id,
                'device_role': required_objects['device_role'].id if required_objects['device_role'] else None,
                'platform': platform_obj.id,
                'sync_vlans': True,
                'sync_vrfs': True,
                'sync_cables': True,
                'sync_software_version':True,
                'connectivity_test':False
            }
    
    def _create_generic_associations(self, secrets_group, device_ip):
        """Create Generic associations for secrets group if they don't exist."""
        from nautobot.extras.models import Secret, SecretsGroupAssociation
        from nautobot.extras.choices import SecretsGroupAccessTypeChoices, SecretsGroupSecretTypeChoices
        
        # Find username and password secrets
        username_secret = None
        password_secret = None
        
        for assoc in secrets_group.secrets_group_associations.all():
            if assoc.secret_type == SecretsGroupSecretTypeChoices.TYPE_USERNAME:
                username_secret = assoc.secret
            elif assoc.secret_type == SecretsGroupSecretTypeChoices.TYPE_PASSWORD:
                password_secret = assoc.secret
        
        if not username_secret or not password_secret:
            raise Exception(f'SecretsGroup {secrets_group.name} missing username or password secrets')
        
        # Create Generic associations if they don't exist
        generic_username_assoc, created = SecretsGroupAssociation.objects.get_or_create(
            secrets_group=secrets_group,
            secret=username_secret,
            access_type=SecretsGroupAccessTypeChoices.TYPE_GENERIC,
            secret_type=SecretsGroupSecretTypeChoices.TYPE_USERNAME
        )
        
        generic_password_assoc, created = SecretsGroupAssociation.objects.get_or_create(
            secrets_group=secrets_group,
            secret=password_secret,
            access_type=SecretsGroupAccessTypeChoices.TYPE_GENERIC,
            secret_type=SecretsGroupSecretTypeChoices.TYPE_PASSWORD
        )
        
        logger.info(f"Created Generic associations for SecretsGroup {secrets_group.name} for device {device_ip}")
    
    def _format_onboarding_response(self, onboarding_jobs, failed_jobs, duplicate_jobs=None):
        """Format the response based on job results."""
        duplicate_jobs = duplicate_jobs or []
        
        # Handle case with duplicate devices requiring confirmation
        if duplicate_jobs:
            return self.success_response({
                'onboarding_count': len(onboarding_jobs),
                'onboarding_jobs': onboarding_jobs,
                'failed_jobs': failed_jobs,
                'duplicate_jobs': duplicate_jobs,
                'requires_confirmation': True,
                'next_steps': [
                    f'{len(duplicate_jobs)} devices require confirmation for re-onboarding',
                    f'{len(onboarding_jobs)} devices started successfully' if onboarding_jobs else 'No devices started yet',
                    f'{len(failed_jobs)} devices failed' if failed_jobs else '',
                    'Confirm duplicate devices to proceed with re-onboarding'
                ]
            }, f'{len(onboarding_jobs)} devices started, {len(duplicate_jobs)} require confirmation, {len(failed_jobs)} failed')
        
        if onboarding_jobs and not failed_jobs:
            return self.success_response({
                'onboarding_count': len(onboarding_jobs),
                'onboarding_jobs': onboarding_jobs,
                'failed_jobs': failed_jobs,
                'next_steps': [
                    'Device onboarding jobs have been started',
                    'Monitor job progress in the Jobs section',
                    'Devices will be automatically added to Nautobot inventory upon successful completion'
                ]
            }, f'{len(onboarding_jobs)} devices started for onboarding')
        elif failed_jobs and not onboarding_jobs:
            error_messages = [job['error'] for job in failed_jobs]
            return self.error_response(
                f'Failed to start onboarding for {len(failed_jobs)} devices',
                400,
                {
                    'total_failed': len(failed_jobs),
                    'error_messages': error_messages,
                    'onboarding_count': 0,
                    'onboarding_jobs': [],
                    'failed_jobs': failed_jobs
                }
            )
        else:
            return self.success_response({
                'onboarding_count': len(onboarding_jobs),
                'onboarding_jobs': onboarding_jobs,
                'failed_jobs': failed_jobs,
                'next_steps': [
                    f'{len(onboarding_jobs)} device onboarding jobs have been started',
                    f'{len(failed_jobs)} devices failed - check error details',
                    'Monitor job progress in the Jobs section'
                ]
            }, f'{len(onboarding_jobs)} devices started for onboarding, {len(failed_jobs)} failed')
    
    def _prepare_csv_export(self, session, selected_devices):
        """Prepare CSV export when onboarding plugin is not available."""
        onboarding_data = []
        for device in selected_devices:
            device_info = {
                'hostname': device.hostname,
                'ip_address': device.ip_address,
                'model': device.model,
                'platform': device.platform,
                'os_version': device.os_version,
                'serial_number': device.serial_number,
                'location': session.location,
                'discovery_session': str(session.session_id),
            }
            onboarding_data.append(device_info)
        
        return self.success_response({
            'onboarding_count': len(onboarding_data),
            'devices': onboarding_data,
            'plugin_available': False,
            'next_steps': [
                'Export devices as CSV for manual onboarding',
                'Use the CSV import feature in Nautobot to add devices',
                'Consider installing nautobot-device-onboarding plugin for automated onboarding'
            ]
        }, f'{len(onboarding_data)} devices prepared for CSV export (Device onboarding plugin not available)')



class OnboardingJobStatusAPIView(LoginRequiredMixin, View):
    """API endpoint to get individual device job status (onboarding + network data sync) for devices.
    
    This API is used for individual device onboarding jobs, not bulk operations.
    For bulk operations, use BulkOnboardingStatusAPIView instead.
    """
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.device_validator = DeviceValidationUtils()
        self.job_manager = JobManagementUtils()
    
    def get(self, request, session_id):
        """Get status of individual device onboarding jobs (not bulk operations).
        
        This endpoint handles individual device onboarding jobs. If bulk operations exist,
        it will handle both individual and bulk jobs appropriately.
        """
        try:
            session = get_object_or_404(InventoryDiscoverySession, session_id=session_id)
            
            # Check if this is ONLY a bulk operation by looking for individual jobs
            devices_with_individual_jobs = session.devices.filter(
                selected_for_onboarding=True,
                onboarding_job_id__isnull=False
            ).exclude(onboarding_job_id='')
            
            # Check for bulk cache data
            bulk_cache_key = f"bulk_onboarding_batches_{session.session_id}"
            bulk_data = cache.get(bulk_cache_key)
            
            # If we have bulk data but NO individual jobs, redirect to bulk endpoint
            if bulk_data and not devices_with_individual_jobs.exists():
                return JsonResponse({
                    'status': 'redirect',
                    'message': 'This session uses bulk onboarding. Use the bulk status endpoint instead.',
                    'bulk_status_url': f'/plugins/inventory/api/bulk-onboarding-status/{session_id}/'
                }, status=302)
            
            # If we have both bulk and individual jobs, or only individual jobs, continue processing individual jobs
            
            # Get devices with individual onboarding jobs
            devices_with_jobs = session.devices.filter(
                selected_for_onboarding=True  # Only process currently selected devices
            ).exclude(
                onboarding_job_id__isnull=True
            ).exclude(
                onboarding_job_id=''
            ).exclude(
                network_data_retry_count__gt=3  # Skip devices that exceeded max retries
            )
            
            onboarding_logger.info(f"IndividualJobStatusAPIView: Processing {devices_with_jobs.count()} selected devices with individual onboarding jobs")
            for device in devices_with_jobs:
                onboarding_logger.debug(f"  Processing device: {device.ip_address} (selected: {device.selected_for_onboarding})")
            
            job_statuses = []
            for device in devices_with_jobs:
                # Skip devices that are no longer selected for onboarding
                if not device.selected_for_onboarding:
                    onboarding_logger.debug(f"Skipping device {device.ip_address} - not selected for onboarding")
                    continue
                    
                # Check if device is a stack to determine if we need 3 phases
                is_stack = device.device_data and device.device_data.get('is_stack', False)
                
                device_status = {
                    'device_ip': device.ip_address,
                    'hostname': device.hostname,
                    'sync_devices_job_id': device.onboarding_job_id,
                    'stack_member_job_id': device.stack_member_job_id if is_stack else None,
                    'network_data_job_id': device.network_data_job_id,
                    'sync_devices_status': 'unknown',
                    'stack_member_status': 'not_applicable' if not is_stack else 'pending',
                    'network_data_status': 'pending',
                    'overall_status': 'running',
                    'is_stack': is_stack,
                    'stack_info': device.device_data.get('stack_info', {}) if is_stack else None,
                    'created': None,
                    'completed': None,
                    'progress': None,
                    'errors': []
                }
                
                # Check stack status early - if stack_member_job_id exists, stack is completed
                if is_stack and device.stack_member_job_id:
                    device_status['stack_member_status'] = 'completed'
                    device_status['stack_member_job_id'] = device.stack_member_job_id
                
                # Check SSOTSyncDevices job status
                try:
                    sync_devices_result = JobResult.objects.get(pk=device.onboarding_job_id)
                    # Convert JobResult status to lowercase for frontend consistency
                    device_status['sync_devices_status'] = str(sync_devices_result.status).lower()
                    device_status['created'] = sync_devices_result.date_created.isoformat() if sync_devices_result.date_created else None
                    
                    print(f"🔍 Device {device.ip_address}: sync_devices_status = {sync_devices_result.status}")
                    print(f"🔍 Device {device.ip_address}: network_data_job_id = {device.network_data_job_id}")
                    
                    # Handle retry case - if device is in retry state and first job succeeded, try again
                    if (str(sync_devices_result.status).lower() == 'success' and 
                        not device.network_data_job_id and 
                        device.network_data_retry_count > 0 and 
                        device.network_data_retry_count <= 3):
                        
                        print(f"🔄 Retrying network data job trigger for {device.ip_address} (attempt {device.network_data_retry_count})")
                        
                        # Add delay for retry
                        import time
                        time.sleep(1)
                        
                        # Validate device creation again
                        validation_result = self.device_validator.validate_device_created(
                            device.ip_address, device.hostname, session.location
                        )
                        
                        if validation_result['is_valid']:
                            device_logger.log_device_validation(
                                device.ip_address, validation_result['method_used'], True,
                                validation_result['device'].name if validation_result['device'] else None
                            )
                            
                            # Trigger network data job using utility
                            network_data_job_id = self.job_manager.trigger_network_data_job(
                                session_id, device.ip_address, 
                                validation_result['device'].name if validation_result['device'] else device.hostname,
                                request.user, validation_result['device'].id if validation_result['device'] else None
                            )
                            if network_data_job_id:
                                device.network_data_job_id = network_data_job_id
                                device.network_data_retry_count = 0  # Reset retry count on success
                                device.save()
                                device_status['network_data_job_id'] = network_data_job_id
                                device_status['network_data_status'] = 'running'
                                print(f"✅ Network data job triggered successfully on retry: {network_data_job_id}")
                            else:
                                print(f"❌ Failed to trigger network data job on retry for {device.ip_address}")
                                device_status['network_data_status'] = 'failed_to_trigger'
                        else:
                            # Increment retry count when validation fails to prevent infinite retry loop
                            device.network_data_retry_count += 1
                            device.save()
                            print(f"❌ Device still not found on retry {device.network_data_retry_count - 1} for {device.ip_address} (retry count now: {device.network_data_retry_count})")
                            
                            if device.network_data_retry_count <= 3:
                                device_status['network_data_status'] = 'retrying_device_lookup'
                            else:
                                device_status['network_data_status'] = 'max_retries_exceeded'
                                print(f"❌ Max retries exceeded for device lookup: {device.ip_address}")
                    
                    elif str(sync_devices_result.status).lower() == 'success':
                        # First job completed successfully, trigger second job if not already triggered
                        if not device.network_data_job_id:
                            print(f"🚀 Triggering network data job for {device.ip_address}")
                            
                            # Add a small delay to ensure the device is fully committed to the database
                            import time
                            time.sleep(2)  # Wait 2 seconds for database consistency
                            
                            # Validate that the device was actually created before triggering network data job
                            validation_result = self.device_validator.validate_device_created(
                                device.ip_address, device.hostname, session.location
                            )
                        
                            if validation_result['is_valid']:
                                device_logger.log_device_validation(
                                    device.ip_address, validation_result['method_used'], True,
                                    validation_result['device'].name if validation_result['device'] else None
                                )
                                
                                # Check if device is a stack and trigger stack member creation if needed
                                device_is_stack = device.device_data and device.device_data.get('is_stack', False)
                                if device_is_stack and not device.stack_member_job_id:
                                    # Create stack members directly using stack_utils (no separate Celery job)
                                    onboarding_logger.info(f"🏗️  Device {device.ip_address} is a stack, creating stack members...")
                                    device_status['stack_member_status'] = 'running'
                                    
                                    # Store stack info in cache for stack member creation
                                    stack_info = device.device_data.get('stack_info', {})
                                    if stack_info:
                                        cache_key = f"stack_onboarding_{device.ip_address}"
                                        cache.set(cache_key, {'stack_info': stack_info}, timeout=3600)
                                    
                                    stack_result = self._trigger_stack_member_job(
                                        device, session_id, request.user
                                    )
                                    if stack_result:
                                        device.stack_member_job_id = stack_result
                                        device.save()
                                        device_status['stack_member_job_id'] = stack_result
                                        device_status['stack_member_status'] = 'completed'
                                        onboarding_logger.info(f"✅ Stack members created for {device.ip_address}: {stack_result}")
                                    else:
                                        device_status['stack_member_status'] = 'failed'
                                        device_status['errors'].append({
                                            'job': 'stack_member_creation',
                                            'error': 'Failed to create stack members'
                                        })
                                        onboarding_logger.error(f"❌ Failed to create stack members for {device.ip_address}")
                                elif device_is_stack and device.stack_member_job_id:
                                    # Stack members already created
                                    device_status['stack_member_status'] = 'completed'
                                    device_status['stack_member_job_id'] = device.stack_member_job_id
                                
                                # Trigger network data job using utility
                                network_data_job_id = self.job_manager.trigger_network_data_job(
                                    session_id, device.ip_address, 
                                    validation_result['device'].name if validation_result['device'] else device.hostname,
                                    request.user, validation_result['device'].id if validation_result['device'] else None
                                )
                                if network_data_job_id:
                                    device.network_data_job_id = network_data_job_id
                                    device.save()
                                    device_status['network_data_job_id'] = network_data_job_id
                                    device_status['network_data_status'] = 'running'
                                    device_logger.log_job_trigger('network_data', device.ip_address, network_data_job_id)
                                else:
                                    device_logger.log_device_operation('network_data_trigger', device.ip_address, 'failed', 'Failed to trigger network data job')
                                    device_status['network_data_status'] = 'failed_to_trigger'
                            elif not validation_result['is_valid']:
                                device_logger.log_device_validation(
                                    device.ip_address, validation_result.get('method_used', 'unknown'), False
                                )
                                device_status['network_data_status'] = 'device_not_found'
                                
                                # Set a retry flag for the next status check
                                device.network_data_retry_count += 1
                                device.save()
                                
                                # If we haven't exceeded retry limit, mark for retry
                                if device.network_data_retry_count <= 3:
                                    device_status['network_data_status'] = 'retrying_device_lookup'
                                    print(f"🔄 Will retry device lookup for {device.ip_address} (attempt {device.network_data_retry_count}/3)")
                                else:
                                    print(f"❌ Max retries exceeded for device lookup: {device.ip_address}")
                                    device_status['network_data_status'] = 'max_retries_exceeded'
                        else:
                            print(f"ℹ️ Network data job already exists for {device.ip_address}: {device.network_data_job_id}")
                        
                        # Check stack status regardless of network_data_job_id status
                        # This ensures stack status is always updated when device is a stack
                        device_is_stack = device.device_data and device.device_data.get('is_stack', False)
                        if device_is_stack and device.stack_member_job_id:
                            # Stack members already created
                            device_status['stack_member_status'] = 'completed'
                            device_status['stack_member_job_id'] = device.stack_member_job_id
                            print(f"✅ Stack members already created for {device.ip_address}: {device.stack_member_job_id}")
                        
                    elif str(sync_devices_result.status).lower() == 'failure':
                        device_status['errors'].append({
                            'job': 'sync_devices',
                            'error': sync_devices_result.traceback or 'Job failed'
                        })
                        device_status['overall_status'] = 'failed'
                        device_status['network_data_status'] = 'cancelled'
                        
                except JobResult.DoesNotExist:
                    device_status['sync_devices_status'] = 'not_found'
                    device_status['errors'].append({
                        'job': 'sync_devices',
                        'error': 'Job result not found'
                    })
                
                # Check SSOTSyncNetworkData job status if it exists
                if device.network_data_job_id:
                    try:
                        network_data_result = JobResult.objects.get(pk=device.network_data_job_id)
                        # Convert JobResult status to lowercase for frontend consistency
                        device_status['network_data_status'] = str(network_data_result.status).lower()
                        
                        if str(network_data_result.status).lower() == 'success':
                            # Verify that the network data job actually processed the device using utility
                            verification_result = self.job_manager.verify_network_data_job_success(
                                network_data_result, device.ip_address
                            )
                            
                            if verification_result['is_successful']:
                                device_status['overall_status'] = 'completed'
                                device_status['completed'] = network_data_result.date_done.isoformat() if network_data_result.date_done else None
                                job_logger.log_job_verification(
                                    str(network_data_result.id), verification_result, device.ip_address
                                )
                            else:
                                device_status['overall_status'] = 'partial_success'
                                device_status['network_data_status'] = 'no_devices_processed'
                                device_status['errors'].append({
                                    'job': 'network_data',
                                    'error': 'Network data job completed but no devices were processed'
                                })
                                job_logger.log_job_verification(
                                    str(network_data_result.id), verification_result, device.ip_address
                                )
                                print(f"⚠️ Network data job completed but no devices processed for {device.ip_address}")
                                
                        elif str(network_data_result.status).lower() == 'failure':
                            device_status['errors'].append({
                                'job': 'network_data',
                                'error': network_data_result.traceback or 'Network data sync failed'
                            })
                            device_status['overall_status'] = 'partial_success'  # First job succeeded, second failed
                            print(f"❌ Network data job failed for {device.ip_address}")
                            
                    except JobResult.DoesNotExist:
                        device_status['network_data_status'] = 'not_found'
                        device_status['errors'].append({
                            'job': 'network_data',
                            'error': 'Network data job result not found'
                        })
                
                # Calculate individual device progress (accounting for stack devices with 3 phases)
                if is_stack:
                    # 3-phase progress: Device Sync (33%) -> Stack Members (33%) -> Network Data (34%)
                    if device_status['network_data_status'] == 'success':
                        device_status['progress'] = 100
                    elif device_status['network_data_status'] in ['running', 'pending']:
                        if device_status['stack_member_status'] == 'completed':
                            device_status['progress'] = 80  # Stack done, network data in progress
                        else:
                            device_status['progress'] = 66  # Device sync done, stack in progress
                    elif device_status['stack_member_status'] == 'completed':
                        device_status['progress'] = 66  # Device sync + stack done, waiting for network
                    elif device_status['stack_member_status'] in ['running', 'pending']:
                        device_status['progress'] = 40  # Device sync done, stack in progress
                    elif device_status['sync_devices_status'] == 'success':
                        device_status['progress'] = 33  # Only device sync done
                    elif device_status['sync_devices_status'] == 'running':
                        device_status['progress'] = 15
                    else:
                        device_status['progress'] = 0
                else:
                    # 2-phase progress: Device Sync (50%) -> Network Data (50%)
                    if device_status['sync_devices_status'] == 'success':
                        if device_status['network_data_status'] == 'success':
                            device_status['progress'] = 100
                        elif device_status['network_data_status'] in ['running', 'pending']:
                            device_status['progress'] = 75
                        else:
                            device_status['progress'] = 50
                    elif device_status['sync_devices_status'] == 'running':
                        device_status['progress'] = 25
                    else:
                        device_status['progress'] = 0
                
                job_statuses.append(device_status)
                
                # Clear job cache for completed devices to prevent stale data
                if (device_status['sync_devices_status'] == 'success' and 
                    device_status['network_data_status'] == 'success'):
                    try:
                        from .utils.job_management import JobManagementUtils
                        job_utils = JobManagementUtils(session)
                        job_utils.clear_network_data_job_cache(session.session_id, device.ip_address)
                        onboarding_logger.debug(f"Cleared job cache for completed device {device.ip_address}")
                    except Exception as cache_error:
                        onboarding_logger.warning(f"Failed to clear job cache for device {device.ip_address}: {cache_error}")
            
            return JsonResponse({
                'status': 'success',
                'operation_type': 'individual',
                'job_statuses': job_statuses,  # Frontend expects job_statuses, not devices
                'devices': job_statuses,  # Keep devices for backward compatibility
                'total_devices': len(job_statuses)
            })
            
        except Exception as e:
            # Improved error handling to prevent connection issues
            import traceback
            error_details = {
                'status': 'error',
                'message': str(e),
                'traceback': traceback.format_exc() if request.user.is_staff else None
            }
            return JsonResponse(error_details, status=500)
    
    def _trigger_stack_member_job(self, device, session_id, user):
        """
        Create stack members directly using the stack_utils utility function.
        
        This method calls the stack creation utility directly instead of
        enqueuing a separate Celery job, avoiding job registration issues.
        
        The stack_utils.create_stack_members() function:
        - Creates a VirtualChassis for the stack
        - Updates the master device with VC membership
        - Creates member devices for all non-master switches
        - Sets proper roles (stack-master, stack-member, stack-standby)
        - Avoids IP address conflicts (only master gets management IP)
        
        Args:
            device: DiscoveredDevice instance with stack_info in device_data
            session_id: Discovery session ID for logging
            user: User triggering the operation (not currently used)
            
        Returns:
            str: Status string like "stack_created_N_members" if successful
            None: If creation failed
        """
        try:
            # Get stack info from cache
            cache_key = f"stack_onboarding_{device.ip_address}"
            stack_data = cache.get(cache_key)
            
            if not stack_data:
                onboarding_logger.error(f"❌ Stack info not found in cache for {device.ip_address}")
                return None
            
            stack_info = stack_data.get('stack_info')
            if not stack_info:
                onboarding_logger.error(f"❌ No stack_info in cached data for {device.ip_address}")
                return None
            
            # Find the onboarded device in Nautobot
            from nautobot.dcim.models import Device
            
            # Try to find device by IP address first
            onboarded_device = None
            try:
                from nautobot.ipam.models import IPAddress
                ip_obj = IPAddress.objects.filter(address=device.ip_address).first()
                if ip_obj and hasattr(ip_obj, 'primary_ip4_for'):
                    onboarded_device = ip_obj.primary_ip4_for.first()
            except Exception as e:
                onboarding_logger.warning(f"Could not find device by IP: {e}")
            
            # Fallback: try to find by hostname
            if not onboarded_device:
                onboarded_device = Device.objects.filter(name=device.hostname).first()
            
            if not onboarded_device:
                onboarding_logger.error(f"❌ Could not find onboarded device for {device.ip_address} / {device.hostname}")
                return None
            
            onboarding_logger.info(f"📦 Found onboarded device: {onboarded_device.name} (ID: {onboarded_device.id})")
            
            # Call stack creation utility directly
            from nautobot_inventory.utils.stack_utils import create_stack_members
            
            onboarding_logger.info(f"🏗️  Creating stack members directly for {onboarded_device.name}...")
            result = create_stack_members(
                device_id=str(onboarded_device.id),
                stack_info=stack_info,
                session_id=str(session_id)
            )
            
            if result.get('success'):
                onboarding_logger.info(f"✅ Stack members created successfully: {result.get('members_created')} members")
                # Return a status string to indicate success
                return f"stack_created_{result.get('members_created')}_members"
            else:
                error = result.get('error', 'Unknown error')
                onboarding_logger.error(f"❌ Stack member creation failed: {error}")
                return None
            
        except Exception as e:
            onboarding_logger.error(f"❌ Error creating stack members: {str(e)}", exc_info=True)
            return None


class DiscoverySessionListView(LoginRequiredMixin, TemplateView):
    """List view for discovery sessions."""
    
    template_name = 'nautobot_inventory/session_list.html'
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        
        # Clean up orphaned running sessions (sessions that have been running too long)
        self.cleanup_orphaned_sessions()
        
        sessions = InventoryDiscoverySession.objects.order_by('-created_at')
        context['object_list'] = sessions
        
        # Get unique filter options from existing sessions
        unique_locations = sessions.values_list('location', flat=True).distinct().order_by('location')
        unique_statuses = sessions.values_list('status', flat=True).distinct().order_by('status')
        unique_router_ips = sessions.values_list('router_ip', flat=True).distinct().order_by('router_ip')
        
        # Also get all active locations from the Location model - only Sites
        from nautobot.dcim.models import Location
        all_locations = Location.objects.filter(
            status__name='Active',
            location_type__name='Room'
        ).values_list('name', flat=True).order_by('name')
        
        # Combine session locations with all active locations
        combined_locations = sorted(set(list(unique_locations) + list(all_locations)))
        
        context.update({
            'filter_locations': combined_locations,
            'filter_statuses': unique_statuses,
            'filter_router_ips': unique_router_ips,
        })
        
        return context
    
    def cleanup_orphaned_sessions(self):
        """
        Clean up sessions that are stuck in 'running' or 'pending' state.
        Mark them as 'stopped' if they've been running for too long.
        """
        try:
            # Sessions running for more than 30 minutes are considered orphaned
            cutoff_time = timezone.now() - timedelta(minutes=30)
            
            orphaned_sessions = InventoryDiscoverySession.objects.filter(
                status__in=['running', 'pending'],
                created_at__lt=cutoff_time
            )
            
            for session in orphaned_sessions:
                session.status = 'stopped'
                session.completed_at = timezone.now()
                session.progress_info = session.progress_info or {}
                session.progress_info['auto_stopped'] = True
                session.progress_info['auto_stopped_reason'] = 'Session exceeded maximum runtime (30 minutes)'
                session.progress_info['auto_stopped_at'] = timezone.now().isoformat()
                session.error_message = 'Session was automatically stopped due to exceeding maximum runtime'
                session.save()
                
        except Exception as e:
            # Log the error but don't fail the view
            logger.error(f"Error cleaning up orphaned sessions: {e}")


class DiscoverySessionDetailView(LoginRequiredMixin, NautobotDataMixin, TemplateView):
    """Detail view for a discovery session."""
    
    template_name = 'nautobot_inventory/session_detail.html'
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        
        session_id = kwargs.get('pk')
        session = get_object_or_404(InventoryDiscoverySession, session_id=session_id)
        # Sort devices: successful first, then failed at bottom, within each group by depth then hostname
        devices = session.devices.all().order_by(
            models.Case(
                models.When(connection_status='failed', then=1),
                default=0,
                output_field=models.IntegerField()
            ),
            'discovery_depth', 
            'hostname'
        )
        
        # Get Nautobot data for device detail modal onboarding dropdowns
        nautobot_data = self._get_nautobot_data()
        
        context.update({
            'object': session,
            'session': session,
            'devices': devices,
            'selected_devices': devices.filter(selected_for_onboarding=True),
            'total_devices': devices.count(),
            'selected_count': devices.filter(selected_for_onboarding=True).count(),
            'nautobot_data': nautobot_data,
        })
        
        return context


class DeviceDetailAPIView(TokenOrSessionAuthMixin, View):
    """API endpoint to get detailed device information."""
    
    def get(self, request, session_id, device_ip):
        """Get detailed information for a specific discovered device."""
        try:
            session = get_object_or_404(InventoryDiscoverySession, session_id=session_id)
            device = get_object_or_404(DiscoveredDevice, session=session, ip_address=device_ip)
            
            # Build clean device detail response without duplicates
            device_detail = {
                'hostname': device.hostname,
                'ip_address': device.ip_address,
                'model': device.model,
                'platform': device.platform,
                'os_version': device.os_version,
                'serial_number': device.serial_number,
                'discovery_depth': device.discovery_depth,
                'connection_status': device.connection_status,
                'discovered_at': device.discovered_at.isoformat() if device.discovered_at else None,
                'selected_for_onboarding': device.selected_for_onboarding,
                'session_info': {
                    'location': session.location,
                    'session_id': str(session.session_id),
                    'created_at': session.created_at.isoformat(),
                }
            }
            
            # Extract and clean device_data to avoid duplication
            if device.device_data and isinstance(device.device_data, dict):
                # Include stack information if available
                if device.device_data.get('is_stack'):
                    device_detail['device_data'] = {
                        'is_stack': device.device_data.get('is_stack', False),
                        'stack_info': device.device_data.get('stack_info', {})
                    }
                
                # Extract interface analysis (includes interfaces within it)
                if 'interface_analysis' in device.device_data:
                    device_detail['interface_analysis'] = device.device_data['interface_analysis']
                
                # Filter interfaces to only include physical interfaces for accurate counting
                all_interfaces = device.device_data.get('interfaces', [])
                if all_interfaces:
                    # Import the interface filtering utility
                    from .utils.interface_parser import InterfaceParser
                    physical_interfaces = InterfaceParser.filter_physical_interfaces(all_interfaces)
                    device_detail['physical_interface_count'] = len(physical_interfaces)
                    device_detail['total_interface_count'] = len(all_interfaces)
                else:
                    device_detail['physical_interface_count'] = 0
                    device_detail['total_interface_count'] = 0
                
                # Extract neighbors from device_data (primary source with detailed info)
                neighbors_data = device.device_data.get('neighbors', [])
                
                # If no neighbors in device_data but available in neighbor_info, use that
                if not neighbors_data and device.neighbor_info:
                    neighbors_data = device.neighbor_info
                
                # Store deduplicated neighbors
                device_detail['neighbors'] = neighbors_data
                
                # Split neighbors by discovery method for UI display
                cdp_neighbors = [n for n in neighbors_data if 'cdp' in n.get('discovery_method', '').lower()]
                lldp_neighbors = [n for n in neighbors_data if 'lldp' in n.get('discovery_method', '').lower()]
                
                device_detail['cdp_neighbors'] = cdp_neighbors
                device_detail['lldp_neighbors'] = lldp_neighbors
                device_detail['total_neighbors'] = len(neighbors_data)
                
                # Extract command outputs and include show_version within it
                if 'command_outputs' in device.device_data:
                    command_outputs = device.device_data['command_outputs'].copy()
                    # Move show_version into command_outputs if it exists separately
                    if 'show_version' in device.device_data:
                        command_outputs['show_version'] = device.device_data['show_version']
                    device_detail['command_outputs'] = command_outputs
                elif 'show_version' in device.device_data:
                    # If only show_version exists, put it in command_outputs
                    device_detail['command_outputs'] = {
                        'show_version': device.device_data['show_version']
                    }
            
            # Add onboarding information
            if device.connection_status == 'connected':
                device_detail['onboarding_info'] = {
                    'ready_for_onboarding': True,
                    'suggested_device_type': device.platform,
                    'suggested_site': session.location,
                    'management_ip': device.ip_address,
                    'primary_interface': 'Management',
                    'device_role': 'Network Device',
                    'status': 'Active'
                }
            else:
                device_detail['onboarding_info'] = {
                    'ready_for_onboarding': False,
                    'reason': f'Device connection status: {device.connection_status}'
                }
            
            return JsonResponse({
                'status': 'success',
                'device': device_detail
            })
            
        except Exception as e:
            return JsonResponse({
                'status': 'error',
                'message': str(e)
            }, status=500)


class ExportDevicesCSVAPIView(LoginRequiredMixin, View):
    """API endpoint to export discovered devices as CSV for device onboarding."""
    
    def get(self, request, session_id):
        """Export selected devices as CSV in the specified onboarding format."""
        import csv
        from django.http import HttpResponse
        
        try:
            session = get_object_or_404(InventoryDiscoverySession, session_id=session_id)
            
            # Get selected devices that are connected and interfaceable, or all properly connected devices if none selected
            # Filter out devices with problematic hostnames (unreachable, failed, error prefixes)
            connected_filter = models.Q(connection_status='connected') & ~models.Q(hostname__startswith='unreachable-') & ~models.Q(hostname__startswith='failed-') & ~models.Q(hostname__startswith='error-')
            
            selected_devices = session.devices.filter(selected_for_onboarding=True).filter(connected_filter)
            if not selected_devices.exists():
                selected_devices = session.devices.filter(connected_filter)
            
            if not selected_devices.exists():
                return JsonResponse({
                    'status': 'error',
                    'message': 'No properly connected and interfaceable devices available for export'
                }, status=400)
            
            # Create HTTP response with CSV content type
            response = HttpResponse(content_type='text/csv')
            response['Content-Disposition'] = f'attachment; filename="device_onboarding_{session_id}_{timezone.now().strftime("%Y%m%d_%H%M%S")}.csv"'
            
            writer = csv.writer(response)
            
            # CSV header matching the user's specified format
            header = [
                'ip_address_host',
                'port',
                'timeout',
                'location_name',
                'device_role_name',
                'namespace',
                'device_status_name',
                'interface_status_name',
                'ip_address_status_name',
                'secrets_group_name',
                'platform_name',
                'set_mgmt_only',
                'update_devices_without_primary_ip'
            ]
            writer.writerow(header)
            
            # Get default values from Nautobot
            default_location = session.location
            default_secrets_group = session.secrets_group_name or ""
            
            # Get default statuses
            try:
                device_ct = ContentType.objects.get_for_model(Device)
                interface_ct = ContentType.objects.get_for_model(Interface)
                ipaddress_ct = ContentType.objects.get_for_model(IPAddress)
                
                default_device_status = Status.objects.filter(
                    content_types=device_ct, name='Active'
                ).first()
                default_interface_status = Status.objects.filter(
                    content_types=interface_ct, name='Active'
                ).first()
                default_ip_status = Status.objects.filter(
                    content_types=ipaddress_ct, name='Active'
                ).first()
                
                default_namespace = Namespace.objects.filter(name='Global').first()
                
            except Exception:
                default_device_status = None
                default_interface_status = None
                default_ip_status = None
                default_namespace = None
            
            # Write device data
            for device in selected_devices:
                # Determine device role based on model/platform
                device_role = 'Onboarding'  # Default role
                if device.model:
                    model_lower = device.model.lower()
                    if any(term in model_lower for term in ['switch', 'catalyst', '2960', '3560', '3750', '9300', '9200']):
                        device_role = 'Switch'
                    elif any(term in model_lower for term in ['router', 'isr', 'asr', '1900', '2900', '3900', '4000','3725', 'csr1000v']):
                        device_role = 'Router'
                    elif any(term in model_lower for term in ['firewall', 'asa', 'pix', 'fortigate']):
                        device_role = 'Firewall'
                    elif any(term in model_lower for term in ['ap', 'access point', 'wireless']):
                        device_role = 'Access Point'
                
                # If role still not determined and model is unknown, check hostname
                if device_role == 'Onboarding' and device.hostname:
                    hostname_lower = device.hostname.lower()
                    if any(term in hostname_lower for term in ['router', 'rtr', 'rt', 'core-router', 'mpls-router']):
                        device_role = 'Router'
                    elif any(term in hostname_lower for term in ['switch', 'sw', 'core-sw']):
                        device_role = 'Switch'
                    elif any(term in hostname_lower for term in ['firewall', 'fw', 'asa']):
                        device_role = 'Firewall'
                    elif any(term in hostname_lower for term in ['ap', 'access-point', 'wireless', 'wlc']):
                        device_role = 'Access Point'
                
                # Map platform to standard Nautobot platform names
                platform_name = device.platform or ''
                if device.platform:
                    # Enhanced platform mapping - use the first (most common) option for CSV export
                    platform_mapping = {
                        'cisco': 'cisco_ios',
                        'aruba': 'aruba_aoscx', 
                        'juniper': 'juniper_junos',
                        'arista': 'arista_eos',
                        'hp': 'hp_comware',
                        'unknown': 'cisco_ios'  # Default fallback
                    }
                    platform_name = platform_mapping.get(device.platform.lower(), device.platform)
                
                row = [
                    device.ip_address,                                                    # ip_address_host
                    '22',                                                                # port (default SSH)
                    '30',                                                               # timeout
                    default_location,                                                   # location_name
                    device_role,                                                        # device_role_name
                    default_namespace.name if default_namespace else 'Global',         # namespace
                    default_device_status.name if default_device_status else 'Active', # device_status_name
                    default_interface_status.name if default_interface_status else 'Active', # interface_status_name
                    default_ip_status.name if default_ip_status else 'Active',         # ip_address_status_name
                    default_secrets_group,                                             # secrets_group_name
                    platform_name,                                                      # platform_name
                    'False',                                                           # set_mgmt_only
                    'True',                                                            # update_devices_without_primary_ip
                ]
                writer.writerow(row)
            
            return response
            
        except Exception as e:
            return JsonResponse({
                'status': 'error',
                'message': f'CSV export failed: {str(e)}'
            }, status=500)


class StopDiscoveryAPIView(LoginRequiredMixin, View):
    """API endpoint to stop a running discovery session."""
    
    def post(self, request, session_id):
        """Stop a running discovery session and preserve current results."""
        try:
            session = get_object_or_404(InventoryDiscoverySession, session_id=session_id)
            
            # Only allow stopping if session is currently running
            if session.status not in ['pending', 'running']:
                return JsonResponse({
                    'status': 'error',
                    'message': f'Cannot stop discovery session in {session.status} state'
                }, status=400)
            
            # Update session status to stopped
            session.status = 'stopped'
            session.completed_at = timezone.now()
            session.progress_info = session.progress_info or {}
            session.progress_info['stopped_by_user'] = True
            session.progress_info['stopped_at'] = timezone.now().isoformat()
            session.save()
            
            # Get current device count
            device_count = session.devices.count()
            
            return JsonResponse({
                'status': 'success',
                'message': f'Discovery stopped. {device_count} devices discovered so far.',
                'device_count': device_count,
                'session_status': 'stopped'
            })
            
        except Exception as e:
            return JsonResponse({
                'status': 'error',
                'message': f'Failed to stop discovery: {str(e)}'
            }, status=500)


class DeleteDiscoverySessionAPIView(LoginRequiredMixin, View):
    """API endpoint to delete a discovery session."""
    
    def delete(self, request, session_id):
        """Delete a discovery session and all associated data."""
        try:
            session = get_object_or_404(InventoryDiscoverySession, session_id=session_id)
            session.delete()
            
            return JsonResponse({
                'status': 'success',
                'message': 'Discovery session deleted successfully'
            })
            
        except Exception as e:
            return JsonResponse({
                'status': 'error',
                'message': str(e)
            }, status=500)




class BulkLocationUpdateAPIView(LoginRequiredMixin, View):
    """API endpoint to update final location for multiple devices."""
    
    def post(self, request, session_id):
        """Update final location for multiple devices."""
        try:
            session = get_object_or_404(InventoryDiscoverySession, session_id=session_id)
            data = json.loads(request.body)
            device_ips = data.get('device_ips', [])
            location_name = data.get('location_name', '')
            
            if not device_ips:
                return JsonResponse({
                    'status': 'error',
                    'message': 'No device IPs provided'
                }, status=400)
            
            if not location_name:
                return JsonResponse({
                    'status': 'error',
                    'message': 'No location name provided'
                }, status=400)
            
            # Update devices with the new final location
            updated_count = 0
            failed_devices = []
            
            for device_ip in device_ips:
                try:
                    device = session.devices.filter(ip_address=device_ip).first()
                    if device:
                        # Store the final location in the device's device_data or create a new field
                        if not device.device_data:
                            device.device_data = {}
                        device.device_data['final_location_name'] = location_name
                        device.save()
                        updated_count += 1
                    else:
                        failed_devices.append({
                            'device_ip': device_ip,
                            'error': 'Device not found in session'
                        })
                except Exception as e:
                    failed_devices.append({
                        'device_ip': device_ip,
                        'error': str(e)
                    })
            
            return JsonResponse({
                'status': 'success',
                'message': f'Updated final location for {updated_count} devices',
                'updated_count': updated_count,
                'failed_devices': failed_devices
            })
            
        except json.JSONDecodeError:
            return JsonResponse({
                'status': 'error',
                'message': 'Invalid JSON in request body'
            }, status=400)
        except Exception as e:
            onboarding_logger.error(f"Error updating bulk location: {e}")
            return JsonResponse({
                'status': 'error',
                'message': str(e)
            }, status=500)


class GetDeviceOnboardingDataAPIView(LoginRequiredMixin, View):
    """API endpoint to get device onboarding data with defaults for editing."""
    
    def get(self, request, session_id, device_ip):
        """Get device onboarding data with default values populated from Nautobot."""
        try:
            session = get_object_or_404(InventoryDiscoverySession, session_id=session_id)
            device = get_object_or_404(DiscoveredDevice, session=session, ip_address=device_ip)
            
            # Get content types for status filtering
            device_ct = ContentType.objects.get_for_model(Device)
            interface_ct = ContentType.objects.get_for_model(Interface)
            ipaddress_ct = ContentType.objects.get_for_model(IPAddress)
            
            # Get default values
            default_location = session.location
            default_secrets_group = session.secrets_group_name or ""
            
            # Get default statuses
            default_device_status = Status.objects.filter(
                content_types=device_ct, name='Active'
            ).first()
            default_interface_status = Status.objects.filter(
                content_types=interface_ct, name='Active'
            ).first()
            default_ip_status = Status.objects.filter(
                content_types=ipaddress_ct, name='Active'
            ).first()
            default_namespace = Namespace.objects.filter(name='Global').first()
            
            # Determine device role based on model/platform
            device_role = 'Onboarding'  # Default role
            if device.model:
                model_lower = device.model.lower()
                if any(term in model_lower for term in ['switch', 'catalyst', '2960', '3560', '3750', '9300', '9200']):
                    device_role = 'Switch'
                elif any(term in model_lower for term in ['router', 'isr', 'asr', '1900', '2900', '3900', '4000','3725', 'csr1000v']):
                    device_role = 'Router'
                elif any(term in model_lower for term in ['firewall', 'asa', 'pix', 'fortigate']):
                    device_role = 'Firewall'
                elif any(term in model_lower for term in ['ap', 'access point', 'wireless']):
                    device_role = 'Access Point'

            if device_role == 'Onboarding' and device.hostname:
                hostname_lower = device.hostname.lower()
                if any(term in hostname_lower for term in ['router', 'rtr', 'rt', 'core-router', 'mpls-router']):
                    device_role = 'Router'
                elif any(term in hostname_lower for term in ['switch', 'sw', 'core-sw']):
                    device_role = 'Switch'
                elif any(term in hostname_lower for term in ['firewall', 'fw', 'asa']):
                    device_role = 'Firewall'
                elif any(term in hostname_lower for term in ['ap', 'access-point', 'wireless', 'wlc']):
                    device_role = 'Access Point'       
            
            # Map platform to standard Nautobot platform names
            platform_name = device.platform or ''
            if device.platform:
                # Enhanced platform mapping - use the first (most common) option
                platform_mapping = {
                    'cisco': 'cisco_ios',
                    'aruba': 'aruba_aoscx', 
                    'juniper': 'juniper_junos',
                    'arista': 'arista_eos',
                    'hp': 'hp_comware',
                    'unknown': 'cisco_ios'  # Default fallback
                }
                platform_name = platform_mapping.get(device.platform.lower(), device.platform)
            
            # Get final location from device data if it exists
            final_location_name = ''
            if device.device_data and isinstance(device.device_data, dict):
                final_location_name = device.device_data.get('final_location_name', '')

            # Device onboarding data with defaults
            onboarding_data = {
                'ip_address_host': device.ip_address,
                'port': '22',
                'timeout': '30',
                'location_name': default_location,
                'final_location_name': final_location_name,
                'device_role_name': device_role,
                'namespace': default_namespace.name if default_namespace else 'Global',
                'device_status_name': default_device_status.name if default_device_status else 'Active',
                'interface_status_name': default_interface_status.name if default_interface_status else 'Active',
                'ip_address_status_name': default_ip_status.name if default_ip_status else 'Active',
                'secrets_group_name': default_secrets_group,
                'platform_name': platform_name,
                'set_mgmt_only': False,
                'update_devices_without_primary_ip': True,
            }
            
            # Also include device info for context
            device_info = {
                'hostname': device.hostname,
                'model': device.model,
                'platform': device.platform,
                'os_version': device.os_version,
                'serial_number': device.serial_number,
                'connection_status': device.connection_status,
                'discovered_at': device.discovered_at.isoformat() if device.discovered_at else None,
            }
            
            return JsonResponse({
                'status': 'success',
                'device_info': device_info,
                'onboarding_data': onboarding_data
            })
            
        except Exception as e:
            return JsonResponse({
                'status': 'error',
                'message': f'Failed to get device onboarding data: {str(e)}'
            }, status=500)


# Custom Credentials Management Views

class GetDeviceCredentialsAPIView(LoginRequiredMixin, View):
    """API endpoint to get device credentials."""
    
    def get(self, request, session_id, device_ip):
        """Get custom credentials for a specific device."""
        try:
            session = get_object_or_404(InventoryDiscoverySession, session_id=session_id)
            device = get_object_or_404(DiscoveredDevice, session=session, ip_address=device_ip)
            
            cache_key = f"custom_creds_{session_id}_{device_ip}"
            credentials = cache.get(cache_key)
            
            if credentials:
                # Don't return the actual password for security
                safe_credentials = {
                    'username': credentials.get('username'),
                    'device_type': credentials.get('device_type', 'cisco_ios'),
                    'protocol': credentials.get('protocol', 'ssh'),
                    'port': credentials.get('port', 22),
                    'timeout': credentials.get('timeout', 30),
                    'created_at': credentials.get('created_at'),
                    'created_by': credentials.get('created_by')
                }
            else:
                safe_credentials = None
            
            return JsonResponse({
                'status': 'success',
                'credentials': safe_credentials
            })
            
        except Exception as e:
            return JsonResponse({
                'status': 'error',
                'message': str(e)
            }, status=500)


class SaveDeviceCredentialsAPIView(LoginRequiredMixin, View):
    """API endpoint to save device credentials."""
    
    def post(self, request, session_id, device_ip):
        """Save custom credentials for a specific device."""
        try:
            session = get_object_or_404(InventoryDiscoverySession, session_id=session_id)
            device = get_object_or_404(DiscoveredDevice, session=session, ip_address=device_ip)
            
            data = json.loads(request.body)
            credentials = data.get('credentials', {})
            
            # Validate credential structure
            required_fields = ['username', 'password']
            if not all(field in credentials for field in required_fields):
                return JsonResponse({
                    'status': 'error',
                    'message': 'Missing required credential fields: username, password'
                }, status=400)
            
            # Store credentials in cache with encryption (in production, use proper encryption)
            cache_key = f"custom_creds_{session_id}_{device_ip}"
            
            # Add additional connection parameters
            credential_data = {
                'username': credentials.get('username'),
                'password': credentials.get('password'),
                'enable_password': credentials.get('enable_password', ''),
                'port': credentials.get('port', 22),
                'timeout': credentials.get('timeout', 30),
                'device_type': credentials.get('device_type', 'cisco_ios'),
                'protocol': credentials.get('protocol', 'ssh'),
                'created_at': timezone.now().isoformat(),
                'created_by': request.user.username
            }
            
            cache.set(cache_key, credential_data, timeout=3600)  # 1 hour timeout
            
            # Mark device as having custom credentials
            device.custom_credentials = True
            device.save()
            
            logger.info(f"Custom credentials saved for device {device_ip} in session {session_id}")
            
            return JsonResponse({
                'status': 'success',
                'message': f'Custom credentials saved for device {device_ip}'
            })
            
        except json.JSONDecodeError:
            return JsonResponse({
                'status': 'error',
                'message': 'Invalid JSON in request body'
            }, status=400)
        except Exception as e:
            logger.error(f"Error saving custom credentials: {e}")
            return JsonResponse({
                'status': 'error',
                'message': str(e)
            }, status=500)


class TestDeviceCredentialsAPIView(LoginRequiredMixin, View):
    """API endpoint to test device credentials."""
    
    def post(self, request, session_id, device_ip):
        """Test custom credentials against a device."""
        try:
            session = get_object_or_404(InventoryDiscoverySession, session_id=session_id)
            device = get_object_or_404(DiscoveredDevice, session=session, ip_address=device_ip)
            
            data = json.loads(request.body)
            credentials = data.get('credentials', {})
            
            if not credentials:
                return JsonResponse({
                    'status': 'error',
                    'message': 'No credentials provided'
                }, status=400)
            
            # Import the device connection tester
            from .device_connection_tester import DeviceCredentialValidator
            
            # Create validator instance
            validator = DeviceCredentialValidator()
            
            # Test connection with the provided credentials
            test_result = validator.validate_credentials(device_ip, credentials)
            
            if test_result['success']:
                logger.info(f"Credential test successful for {device_ip}: {test_result.get('hostname', 'unknown')}")
                
                return JsonResponse({
                    'status': 'success',
                    'message': 'Connection test successful',
                    'device_info': f"Connected to {test_result.get('hostname', 'unknown')} ({test_result.get('model', 'unknown')})",
                    'test_details': {
                        'hostname': test_result.get('hostname'),
                        'model': test_result.get('model'),
                        'platform': test_result.get('platform'),
                        'os_version': test_result.get('os_version'),
                        'detected_device_type': test_result.get('detected_device_type'),
                        'response_time': test_result.get('response_time'),
                        'tested_at': test_result.get('tested_at')
                    }
                })
            else:
                logger.warning(f"Credential test failed for {device_ip}: {test_result.get('error', 'Unknown error')}")
                
                return JsonResponse({
                    'status': 'error',
                    'message': f'Connection test failed: {test_result.get("error", "Unknown error")}',
                    'error_details': {
                        'error_type': test_result.get('error_type'),
                        'response_time': test_result.get('response_time'),
                        'tested_at': test_result.get('tested_at')
                    }
                })
            
        except json.JSONDecodeError:
            return JsonResponse({
                'status': 'error',
                'message': 'Invalid JSON in request body'
            }, status=400)
        except Exception as e:
            logger.error(f"Error testing credentials: {e}")
            return JsonResponse({
                'status': 'error',
                'message': str(e)
            }, status=500)


class TestDeviceTypeDetectionAPIView(LoginRequiredMixin, View):
    """API endpoint to test device credentials with multiple device types for auto-detection."""
    
    def post(self, request, session_id, device_ip):
        """Test credentials with multiple device types to auto-detect the correct one."""
        try:
            session = get_object_or_404(InventoryDiscoverySession, session_id=session_id)
            device = get_object_or_404(DiscoveredDevice, session=session, ip_address=device_ip)
            
            data = json.loads(request.body)
            credentials = data.get('credentials', {})
            
            if not credentials:
                return JsonResponse({
                    'status': 'error',
                    'message': 'No credentials provided'
                }, status=400)
            
            # Import the device connection tester
            from .device_connection_tester import DeviceCredentialValidator
            
            # Create validator instance
            validator = DeviceCredentialValidator()
            
            # Test connection with multiple device types
            test_results = validator.test_multiple_device_types(device_ip, credentials)
            
            if test_results['successful_types']:
                recommended_type = test_results['recommended_type']
                logger.info(f"Device type auto-detection successful for {device_ip}: {recommended_type}")
                
                return JsonResponse({
                    'status': 'success',
                    'message': f'Device type detected: {recommended_type}',
                    'detected_device_type': recommended_type,
                    'successful_types': test_results['successful_types'],
                    'all_results': test_results['results'],
                    'tested_at': test_results['tested_at']
                })
            else:
                logger.warning(f"Device type auto-detection failed for {device_ip}")
                
                return JsonResponse({
                    'status': 'error',
                    'message': 'Could not detect device type with any supported device type',
                    'all_results': test_results['results'],
                    'tested_at': test_results['tested_at']
                })
            
        except json.JSONDecodeError:
            return JsonResponse({
                'status': 'error',
                'message': 'Invalid JSON in request body'
            }, status=400)
        except Exception as e:
            logger.error(f"Error testing device type detection: {e}")
            return JsonResponse({
                'status': 'error',
                'message': str(e)
            }, status=500)


class RetryDeviceDiscoveryAPIView(LoginRequiredMixin, View):
    """API endpoint to retry device discovery with custom credentials."""
    
    def post(self, request, session_id, device_ip):
        """Retry discovery for a specific device using custom credentials."""
        try:
            session = get_object_or_404(InventoryDiscoverySession, session_id=session_id)
            device = get_object_or_404(DiscoveredDevice, session=session, ip_address=device_ip)
            
            # Get custom credentials
            cache_key = f"custom_creds_{session_id}_{device_ip}"
            credentials = cache.get(cache_key)
            
            if not credentials:
                return JsonResponse({
                    'status': 'error',
                    'message': 'No custom credentials found for this device'
                }, status=400)
            
            # Start retry process (this would be implemented with your actual discovery logic)
            # For now, just update the device status to indicate retry is in progress
            device.connection_status = 'discovering'
            device.hostname = f"retrying-{device_ip}"
            device.save()
            
            # In real implementation:
            # 1. Create a new discovery task with custom credentials
            # 2. Queue the task for execution
            # 3. Return task ID for status tracking
            
            logger.info(f"Retry discovery started for {device_ip} with custom credentials")
            
            return JsonResponse({
                'status': 'success',
                'message': f'Retry discovery started for {device_ip}'
            })
            
        except Exception as e:
            logger.error(f"Error retrying discovery: {e}")
            return JsonResponse({
                'status': 'error',
                'message': str(e)
            }, status=500)


class BulkRetryDevicesAPIView(LoginRequiredMixin, View):
    """API endpoint for bulk retry of devices."""
    
    def post(self, request, session_id):
        """Retry discovery for multiple devices."""
        try:
            session = get_object_or_404(InventoryDiscoverySession, session_id=session_id)
            
            data = json.loads(request.body)
            device_ips = data.get('device_ips', [])
            
            if not device_ips:
                return JsonResponse({
                    'status': 'error',
                    'message': 'No device IPs provided'
                }, status=400)
            
            retry_count = 0
            failed_devices = []
            
            for device_ip in device_ips:
                try:
                    device = DiscoveredDevice.objects.get(session=session, ip_address=device_ip)
                    device.connection_status = 'discovering'
                    device.hostname = f"retrying-{device_ip}"
                    device.save()
                    retry_count += 1
                except DiscoveredDevice.DoesNotExist:
                    failed_devices.append(device_ip)
            
            return JsonResponse({
                'status': 'success',
                'message': f'Retry started for {retry_count} devices',
                'retry_count': retry_count,
                'failed_devices': failed_devices
            })
            
        except json.JSONDecodeError:
            return JsonResponse({
                'status': 'error',
                'message': 'Invalid JSON in request body'
            }, status=400)
        except Exception as e:
            return JsonResponse({
                'status': 'error',
                'message': str(e)
            }, status=500)


class DiscoveryTopologyAPIView(LoginRequiredMixin, View):
    """API endpoint to get discovery topology data for visualization."""
    
    def get(self, request, session_id):
        """Get topology data from discovery session for visualization."""
        try:
            session = get_object_or_404(InventoryDiscoverySession, session_id=session_id)
            
            # Get all devices for this session
            devices = session.devices.all().select_related().order_by('discovery_depth', 'discovered_at')
            
            # Transform devices to topology format
            topology_devices = []
            device_connections = []
            device_map = {}
            
            for device in devices:
                # Skip devices with problematic hostnames for topology
                if (device.hostname and 
                    (device.hostname.startswith('unreachable-') or 
                     device.hostname.startswith('failed-') or 
                     device.hostname.startswith('error-') or
                     device.hostname.startswith('timeout-'))):
                    continue
                
                # Create device node for topology
                device_id = f"device_{device.ip_address.replace('.', '_')}"
                device_map[device.ip_address] = device_id
                
                # Determine device status and styling
                status = 'connected' if device.connection_status == 'connected' else 'disconnected'
                if device.connection_status == 'discovering':
                    status = 'discovering'
                
                # Get device type for icon - use device_type_role from discovery if available
                device_type = 'switch'  # default fallback
                
                # First, check if we have device_type_role from discovery analysis
                if device.device_data and isinstance(device.device_data, dict):
                    stored_device_type = device.device_data.get('device_type_role')
                    if stored_device_type:
                        device_type = stored_device_type
                        logger.debug(f"Using stored device_type_role for {device.hostname}: {device_type}")
                    else:
                        # Fallback: analyze show version output if available
                        version_output = device.device_data.get('show_version', '') or device.device_data.get('raw_version_output', '')
                        if version_output:
                            from .jobs import is_switch_device
                            is_switch = is_switch_device(version_output, device.model or '', device.hostname or '', logger)
                            device_type = 'switch' if is_switch else 'router'
                
                # Additional platform-based detection for specific device types
                if device.platform:
                    platform_lower = device.platform.lower()
                    # Only override if we detect specific non-switch/router types
                    if 'firewall' in platform_lower or 'asa' in platform_lower or 'ftd' in platform_lower:
                        device_type = 'firewall'
                    elif 'access-point' in platform_lower or 'ap' in platform_lower or 'wireless' in platform_lower:
                        device_type = 'access-point'
                    elif 'server' in platform_lower or 'host' in platform_lower:
                        device_type = 'server'
                    elif 'load-balancer' in platform_lower or 'f5' in platform_lower:
                        device_type = 'load-balancer'
                
                # Extract interface information from device_data
                interfaces = []
                interface_analysis = {}
                if device.device_data and isinstance(device.device_data, dict):
                    interfaces = device.device_data.get('interfaces', [])
                    interface_analysis = device.device_data.get('interface_analysis', {})
                
                topology_device = {
                    'id': device_id,
                    'name': device.hostname or device.ip_address,
                    'ip_address': device.ip_address,
                    'device_type': device_type,
                    'platform': device.platform or 'Unknown',
                    'model': device.model or 'Unknown',
                    'status': status,
                    'discovery_depth': device.discovery_depth or 0,
                    'discovered_via': device.discovered_via or 'unknown',
                    'position': {
                        'x': (device.discovery_depth or 0) * 200 + 100,  # Horizontal layout by depth
                        'y': len([d for d in topology_devices if d['discovery_depth'] == device.discovery_depth]) * 150 + 100
                    },
                    'interfaces': interfaces,
                    'interface_analysis': interface_analysis,
                    'metadata': {
                        'os_version': device.os_version,
                        'serial_number': device.serial_number,
                        'discovered_at': device.discovered_at.isoformat() if device.discovered_at else None,
                        'parent_device': device.parent_device,
                        'custom_credentials': device.custom_credentials
                    }
                }
                
                topology_devices.append(topology_device)
            
            # Build connections from neighbor information and add disconnected neighbors
            disconnected_neighbors = []
            all_neighbor_ips = set()
            
            for device in devices:
                if device.ip_address not in device_map:
                    continue
                    
                source_device_id = device_map[device.ip_address]
                
                # Get neighbors from device_data
                neighbors = []
                if device.device_data and isinstance(device.device_data, dict):
                    neighbors = device.device_data.get('neighbors', [])
                elif device.neighbor_info:
                    neighbors = device.neighbor_info
                
                # Get interface analysis data for enhanced cable information
                interface_analysis = device.device_data.get('interface_analysis', {}) if device.device_data else {}
                
                # Get all interfaces for this device
                interfaces = []
                if device.device_data and isinstance(device.device_data, dict):
                    interfaces = device.device_data.get('interfaces', [])
                
                # Create connections for each neighbor
                for neighbor in neighbors:
                    if isinstance(neighbor, dict):
                        neighbor_ip = neighbor.get('ip') or neighbor.get('ip_address')
                        neighbor_interface = neighbor.get('local_interface', 'Unknown')
                        remote_interface = neighbor.get('remote_interface', 'Unknown')
                        discovery_method = neighbor.get('method', 'unknown')
                        vlan_info = neighbor.get('vlan', None)
                        trunk_info = neighbor.get('trunk', False)
                        interface_speed = neighbor.get('speed', 'Unknown')
                        interface_duplex = neighbor.get('duplex', 'Unknown')
                        
                        # Get enhanced interface data from interface analysis
                        interface_data = interface_analysis.get(neighbor_interface, {})
                        cable_type = interface_data.get('cable_type', 'discovered')
                        cable_status = interface_data.get('cable_status', 'active')
                        interface_type = interface_data.get('interface_type', 'ethernet')
                        interface_description = interface_data.get('description', '')
                        interface_mtu = interface_data.get('mtu', 'Unknown')
                        interface_admin_status = interface_data.get('admin_status', 'up')
                        interface_oper_status = interface_data.get('oper_status', 'up')
                        
                        # Get VLAN information if available
                        vlan_list = interface_data.get('vlan_list', [])
                        native_vlan = interface_data.get('native_vlan', None)
                        allowed_vlans = interface_data.get('allowed_vlans', [])
                        
                    else:
                        # Handle simple string format
                        neighbor_ip = str(neighbor)
                        neighbor_interface = 'Unknown'
                        remote_interface = 'Unknown'
                        discovery_method = 'unknown'
                        vlan_info = None
                        trunk_info = False
                        interface_speed = 'Unknown'
                        interface_duplex = 'Unknown'
                        cable_type = 'discovered'
                        cable_status = 'active'
                        interface_type = 'ethernet'
                        interface_description = ''
                        interface_mtu = 'Unknown'
                        interface_admin_status = 'up'
                        interface_oper_status = 'up'
                        vlan_list = []
                        native_vlan = None
                        allowed_vlans = []
                    
                    all_neighbor_ips.add(neighbor_ip)
                    
                    if neighbor_ip and neighbor_ip in device_map:
                        target_device_id = device_map[neighbor_ip]
                        
                        # Avoid duplicate connections
                        connection_exists = any(
                            (conn['source'] == source_device_id and conn['target'] == target_device_id) or
                            (conn['source'] == target_device_id and conn['target'] == source_device_id)
                            for conn in device_connections
                        )
                        
                        if not connection_exists:
                            connection = {
                                'id': f"conn_{source_device_id}_{target_device_id}",
                                'source': source_device_id,
                                'target': target_device_id,
                                'source_interface': neighbor_interface,
                                'target_interface': remote_interface,
                                'discovery_method': discovery_method,
                                'status': cable_status,
                                'cable_type': cable_type,
                                'cable_status': cable_status,
                                'interface_type': interface_type,
                                'interface_description': interface_description,
                                'interface_mtu': interface_mtu,
                                'admin_status': interface_admin_status,
                                'oper_status': interface_oper_status,
                                'vlan': vlan_info,
                                'native_vlan': native_vlan,
                                'vlan_list': vlan_list,
                                'allowed_vlans': allowed_vlans,
                                'trunk': trunk_info,
                                'speed': interface_speed,
                                'duplex': interface_duplex,
                                'connection_type': 'ethernet',
                                'cable_length': interface_data.get('cable_length', 'Unknown'),
                                'cable_color': interface_data.get('cable_color', 'Unknown'),
                                'cable_label': interface_data.get('cable_label', ''),
                                'cable_notes': interface_data.get('cable_notes', '')
                            }
                            device_connections.append(connection)
                    else:
                        # This is a disconnected neighbor - add to disconnected list
                        disconnected_neighbors.append({
                            'ip_address': neighbor_ip,
                            'local_interface': neighbor_interface,
                            'remote_interface': remote_interface,
                            'discovery_method': discovery_method,
                            'vlan': vlan_info,
                            'native_vlan': native_vlan,
                            'vlan_list': vlan_list,
                            'allowed_vlans': allowed_vlans,
                            'trunk': trunk_info,
                            'speed': interface_speed,
                            'duplex': interface_duplex,
                            'cable_type': cable_type,
                            'cable_status': cable_status,
                            'interface_type': interface_type,
                            'interface_description': interface_description,
                            'interface_mtu': interface_mtu,
                            'admin_status': interface_admin_status,
                            'oper_status': interface_oper_status,
                            'cable_length': interface_data.get('cable_length', 'Unknown'),
                            'cable_color': interface_data.get('cable_color', 'Unknown'),
                            'cable_label': interface_data.get('cable_label', ''),
                            'cable_notes': interface_data.get('cable_notes', ''),
                            'source_device': source_device_id
                        })
            
            # Add disconnected neighbors as devices
            for i, disconnected in enumerate(disconnected_neighbors):
                if disconnected['ip_address']:
                    disconnected_id = f"disconnected_{disconnected['ip_address'].replace('.', '_')}"
                    
                    # Check if we already have this disconnected device
                    if not any(d['id'] == disconnected_id for d in topology_devices):
                        disconnected_device = {
                            'id': disconnected_id,
                            'name': f"Disconnected: {disconnected['ip_address']}",
                            'ip_address': disconnected['ip_address'],
                            'device_type': 'unknown',
                            'platform': 'Unknown',
                            'model': 'Unknown',
                            'status': 'disconnected',
                            'discovery_depth': 999,  # High depth to place at edge
                            'discovered_via': 'neighbor_discovery',
                            'position': {
                                'x': 1200 + (i % 3) * 200,  # Place on right side
                                'y': 100 + (i // 3) * 150
                            },
                            'metadata': {
                                'disconnected': True,
                                'local_interface': disconnected['local_interface'],
                                'remote_interface': disconnected['remote_interface'],
                                'discovery_method': disconnected['discovery_method'],
                                'vlan': disconnected['vlan'],
                                'trunk': disconnected['trunk'],
                                'speed': disconnected['speed'],
                                'duplex': disconnected['duplex']
                            }
                        }
                        topology_devices.append(disconnected_device)
                        device_map[disconnected['ip_address']] = disconnected_id
                        
                        # Create connection to disconnected device
                        connection = {
                            'id': f"conn_disconnected_{disconnected_id}",
                            'source': disconnected['source_device'],
                            'target': disconnected_id,
                            'source_interface': disconnected['local_interface'],
                            'target_interface': disconnected['remote_interface'],
                            'discovery_method': disconnected['discovery_method'],
                            'status': 'disconnected',
                            'cable_type': 'discovered',
                            'vlan': disconnected['vlan'],
                            'trunk': disconnected['trunk'],
                            'speed': disconnected['speed'],
                            'duplex': disconnected['duplex'],
                            'connection_type': 'ethernet'
                        }
                        device_connections.append(connection)
            
            # Add root device connection if it exists
            if session.router_ip and session.router_ip in device_map:
                root_device_id = device_map[session.router_ip]
                # Connect root device to first level devices
                for device in topology_devices:
                    if device['discovery_depth'] == 1 and device['id'] != root_device_id:
                        connection = {
                            'id': f"conn_root_{device['id']}",
                            'source': root_device_id,
                            'target': device['id'],
                            'source_interface': 'Management',
                            'target_interface': 'Management',
                            'discovery_method': 'root',
                            'status': 'active'
                        }
                        device_connections.append(connection)
            
            # Calculate layout positions if not set
            self._calculateTopologyLayout(topology_devices, device_connections)
            
            response_data = {
                'status': 'success',
                'session_info': {
                    'session_id': str(session.session_id),
                    'location': session.location,
                    'router_ip': session.router_ip,
                    'device_count': len(topology_devices),
                    'connection_count': len(device_connections),
                    'created_at': session.created_at.isoformat(),
                    'status': session.status
                },
                'devices': topology_devices,
                'connections': device_connections
            }
            
            return JsonResponse(response_data)
            
        except Exception as e:
            logger.error(f"Error getting discovery topology data: {str(e)}")
            return JsonResponse({
                'status': 'error',
                'message': str(e)
            }, status=500)
    
    def _calculateTopologyLayout(self, devices, connections):
        """Calculate optimal layout positions for devices."""
        # Group devices by discovery depth
        depth_groups = {}
        for device in devices:
            depth = device['discovery_depth']
            if depth not in depth_groups:
                depth_groups[depth] = []
            depth_groups[depth].append(device)
        
        # Layout devices in a hierarchical structure
        x_spacing = 300
        y_spacing = 150
        start_x = 100
        start_y = 100
        
        for depth, depth_devices in depth_groups.items():
            x = start_x + (depth * x_spacing)
            
            # Center devices vertically within their depth level
            total_height = (len(depth_devices) - 1) * y_spacing
            y_start = start_y + (400 - total_height) // 2
            
            for i, device in enumerate(depth_devices):
                device['position'] = {
                    'x': x,
                    'y': y_start + (i * y_spacing)
                }


class BulkAssignCredentialsAPIView(LoginRequiredMixin, View):
    """API endpoint for bulk credential assignment."""
    
    def post(self, request, session_id):
        """Assign credentials to multiple devices at once."""
        try:
            session = get_object_or_404(InventoryDiscoverySession, session_id=session_id)
            
            data = json.loads(request.body)
            device_ips = data.get('device_ips', [])
            credentials = data.get('credentials', {})
            
            if not all([device_ips, credentials]):
                return JsonResponse({
                    'status': 'error',
                    'message': 'Missing required parameters: device_ips, credentials'
                }, status=400)
            
            updated_count = 0
            failed_devices = []
            
            for device_ip in device_ips:
                try:
                    cache_key = f"custom_creds_{session_id}_{device_ip}"
                    credential_data = {
                        'username': credentials.get('username'),
                        'password': credentials.get('password'),
                        'enable_password': credentials.get('enable_password', ''),
                        'port': credentials.get('port', 22),
                        'timeout': credentials.get('timeout', 30),
                        'device_type': credentials.get('device_type', 'cisco_ios'),
                        'protocol': credentials.get('protocol', 'ssh'),
                        'created_at': timezone.now().isoformat(),
                        'created_by': request.user.username
                    }
                    
                    cache.set(cache_key, credential_data, timeout=3600)
                    
                    # Update device record
                    try:
                        device = DiscoveredDevice.objects.get(session=session, ip_address=device_ip)
                        device.custom_credentials = True
                        device.save()
                    except DiscoveredDevice.DoesNotExist:
                        pass  # Device might not exist yet
                    
                    updated_count += 1
                    
                except Exception as e:
                    failed_devices.append({
                        'device_ip': device_ip,
                        'error': str(e)
                    })
            
            return JsonResponse({
                'status': 'success',
                'message': f'Credentials assigned to {updated_count} devices',
                'updated_count': updated_count,
                'failed_devices': failed_devices
            })
            
        except json.JSONDecodeError:
            return JsonResponse({
                'status': 'error',
                'message': 'Invalid JSON in request body'
            }, status=400)
        except Exception as e:
            return JsonResponse({
                'status': 'error',
                'message': str(e)
            }, status=500)


# Bulk Onboarding API Endpoints

class PrepareBulkOnboardingAPIView(LoginRequiredMixin, View):
    """API endpoint to prepare bulk onboarding for selected devices."""
    
    def post(self, request, session_id):
        """Prepare bulk onboarding by creating batches and triggering bulk jobs."""
        try:
            data = json.loads(request.body)
            device_ips = data.get('device_ips', [])
            global_settings = data.get('global_settings')
            
            if global_settings:
                onboarding_logger.info(f"PrepareBulkOnboardingAPIView: Using global settings: {global_settings}")
            
            if not device_ips:
                return JsonResponse({
                    'status': 'error',
                    'message': 'No devices selected for bulk onboarding'
                }, status=400)
            
            session = get_object_or_404(InventoryDiscoverySession, session_id=session_id)
            
            # Get selected devices and check for duplicates
            selected_devices = session.devices.filter(
                ip_address__in=device_ips,
                selected_for_onboarding=True
            )
            
            if not selected_devices.exists():
                return JsonResponse({
                    'status': 'error',
                    'message': 'No valid selected devices found'
                }, status=400)
            
            # Check for duplicates first
            duplicate_jobs = []
            clean_device_ips = []
            
            for device in selected_devices:
                duplicate_status = self._check_device_duplicate_status(device, session)
                if duplicate_status['is_duplicate']:
                    duplicate_jobs.append({
                        'device': device.ip_address,
                        'hostname': device.hostname or device.ip_address,
                        'message': duplicate_status['message'],
                        'duplicate_info': duplicate_status
                    })
                else:
                    clean_device_ips.append(device.ip_address)
            
            # If we have duplicates, return them for confirmation
            if duplicate_jobs:
                return JsonResponse({
                    'status': 'success',
                    'requires_confirmation': True,
                    'duplicate_jobs': duplicate_jobs,
                    'clean_device_count': len(clean_device_ips),
                    'duplicate_device_count': len(duplicate_jobs),
                    'total_device_count': len(selected_devices)
                })
            
            # No duplicates, proceed with normal bulk onboarding
            job_utils = JobManagementUtils(session)
            result = job_utils.prepare_bulk_onboarding(device_ips, request.user, global_settings)
            
            if result['status'] == 'success':
                return JsonResponse({
                    'status': 'success',
                    'message': f'Bulk onboarding prepared for {len(device_ips)} devices',
                    'batches': result['batches'],
                    'total_batches': result['total_batches'],
                    'device_count': result['total_devices']
                })
            else:
                return JsonResponse({
                    'status': 'error',
                    'message': result['message']
                }, status=400)
                
        except json.JSONDecodeError:
            return JsonResponse({
                'status': 'error',
                'message': 'Invalid JSON in request body'
            }, status=400)
        except Exception as e:
            onboarding_logger.error(f"Error preparing bulk onboarding: {e}")
            return JsonResponse({
                'status': 'error',
                'message': str(e)
            }, status=500)
    
    def _check_device_duplicate_status(self, device, session):
        """Check if device is a duplicate - reuse logic from PrepareOnboardingAPIView."""
        # Import here to avoid circular imports
        prepare_view = PrepareOnboardingAPIView()
        return prepare_view._check_device_duplicate_status(device, session)


class BulkOnboardingStatusAPIView(LoginRequiredMixin, View):
    """API endpoint to get bulk onboarding status for all batches.
    
    This API provides a clean, efficient status response for bulk onboarding operations.
    It includes proper 2-phase progress calculation and avoids duplicate data.
    """
    
    def get(self, request, session_id):
        """Get status of all bulk onboarding jobs for the session."""
        try:
            session = get_object_or_404(InventoryDiscoverySession, session_id=session_id)
            
            # Get job management utils
            job_utils = JobManagementUtils(session)
            
            # Get bulk onboarding status
            status_data = job_utils.get_bulk_onboarding_status()
            
            if status_data['status'] == 'success':
                return JsonResponse({
                    'status': 'success',
                    'operation_type': 'bulk',
                    'batches': status_data['batches'],
                    'summary': status_data['summary']
                })
            else:
                return JsonResponse(status_data, status=404 if status_data['status'] == 'no_batches' else 500)
            
        except Exception as e:
            onboarding_logger.error(f"Error getting bulk onboarding status: {e}")
            return JsonResponse({
                'status': 'error',
                'message': str(e)
            }, status=500)


class RetryBatchAPIView(LoginRequiredMixin, View):
    """API endpoint to retry a specific batch."""
    
    def post(self, request, session_id, batch_number):
        """Retry onboarding for a specific batch."""
        try:
            session = get_object_or_404(InventoryDiscoverySession, session_id=session_id)
            
            # Get job management utils
            job_utils = JobManagementUtils(session)
            
            # Retry batch
            result = job_utils.retry_batch(int(batch_number))
            
            if result['status'] == 'success':
                return JsonResponse({
                    'status': 'success',
                    'message': f'Batch {batch_number} retry initiated',
                    'job_id': result.get('job_id')
                })
            else:
                return JsonResponse({
                    'status': 'error',
                    'message': result['message']
                }, status=400)
                
        except Exception as e:
            logger.error(f"Error retrying batch {batch_number}: {e}")
            return JsonResponse({
                'status': 'error',
                'message': str(e)
            }, status=500)


class TriggerNetworkDataJobAPIView(LoginRequiredMixin, View):
    """API endpoint to manually trigger network data jobs for completed batches."""
    
    def post(self, request, session_id):
        """Force trigger network data jobs for all completed device sync jobs."""
        try:
            session = get_object_or_404(InventoryDiscoverySession, session_id=session_id)
            
            # Get job management utils
            job_utils = JobManagementUtils(session)
            
            # Force trigger network data jobs (pass user from request)
            result = job_utils.force_trigger_network_data_jobs(user=request.user)
            
            if result['status'] == 'success':
                return JsonResponse({
                    'status': 'success',
                    'message': result['message'],
                    'job_result_id': result.get('job_result_id'),
                    'device_count': result.get('device_count')
                })
            else:
                return JsonResponse({
                    'status': 'error',
                    'message': result['message']
                }, status=400)
                
        except Exception as e:
            onboarding_logger.error(f"Error triggering network data jobs: {e}")
            return JsonResponse({
                'status': 'error',
                'message': str(e)
            }, status=500)


class RetryFailedDevicesAPIView(LoginRequiredMixin, View):
    """API endpoint to retry all failed devices across all batches."""
    
    def post(self, request, session_id):
        """Retry onboarding for all failed devices."""
        try:
            session = get_object_or_404(InventoryDiscoverySession, session_id=session_id)
            
            # Get job management utils
            job_utils = JobManagementUtils(session)
            
            # Retry failed devices
            result = job_utils.retry_failed_devices(request.user)
            
            if result['status'] == 'success':
                return JsonResponse({
                    'status': 'success',
                    'message': f'Retry initiated for {result["device_count"]} failed devices',
                    'batches_created': result.get('batches_created', 0)
                })
            else:
                return JsonResponse({
                    'status': 'error',
                    'message': result['message']
                }, status=400)
                
        except Exception as e:
            logger.error(f"Error retrying failed devices: {e}")
            return JsonResponse({
                'status': 'error',
                'message': str(e)
            }, status=500)


# Removed duplicate function-based views - functionality consolidated into class-based views above


class ConfirmDuplicateOnboardingAPIView(LoginRequiredMixin, APIResponseMixin, View):
    """API endpoint to confirm and proceed with duplicate device onboarding."""
    
    def post(self, request, session_id):
        try:
            session = InventoryDiscoverySession.objects.get(session_id=session_id)
            data = json.loads(request.body)
            device_ips = data.get('device_ips', [])
            operation_type = data.get('operation_type', 'single')
            original_data = data.get('original_data', {})
            
            if not device_ips:
                return self.error_response('No device IPs provided', status_code=400)
            
            onboarding_logger.info(f"User confirmed {operation_type} re-onboarding for devices: {device_ips}")
            
            # Get devices and reset their job IDs
            reset_results = []
            for device_ip in device_ips:
                try:
                    device = DiscoveredDevice.objects.get(
                        session=session,
                        ip_address=device_ip
                    )
                    
                    # Reset job IDs
                    if self._reset_device_job_ids(device):
                        reset_results.append({
                            'device_ip': device_ip,
                            'status': 'reset_success',
                            'message': 'Job IDs reset successfully'
                        })
                    else:
                        reset_results.append({
                            'device_ip': device_ip,
                            'status': 'reset_failed',
                            'message': 'Failed to reset job IDs'
                        })
                        
                except DiscoveredDevice.DoesNotExist:
                    reset_results.append({
                        'device_ip': device_ip,
                        'status': 'device_not_found',
                        'message': 'Device not found in session'
                    })
            
            # Now proceed with normal onboarding for successfully reset devices
            successfully_reset = [r for r in reset_results if r['status'] == 'reset_success']
            
            if not successfully_reset:
                return self.error_response(
                    'Failed to reset job IDs for any devices',
                    error_details={'reset_results': reset_results}
                )
            
            # Handle bulk vs single operation
            if operation_type == 'bulk':
                # For bulk operations, trigger bulk onboarding for all originally selected devices
                all_selected_device_ips = original_data.get('device_ips', device_ips)
                global_settings = original_data.get('global_settings')
                
                if global_settings:
                    onboarding_logger.info(f"ConfirmDuplicateOnboardingAPIView: Using global settings for bulk operation: {global_settings}")
                
                # Use JobManagementUtils for bulk onboarding
                from .utils.job_management import JobManagementUtils
                job_utils = JobManagementUtils(session)
                result = job_utils.prepare_bulk_onboarding(all_selected_device_ips, request.user, global_settings)
                
                if result['status'] == 'success':
                    return self.success_response({
                        'status': 'success',
                        'message': f'Bulk re-onboarding confirmed for {len(all_selected_device_ips)} devices',
                        'batches': result['batches'],
                        'total_batches': result['total_batches'],
                        'device_count': result['total_devices'],
                        'reset_results': reset_results
                    })
                else:
                    return self.error_response(result['message'], status_code=400)
            
            # Trigger onboarding for reset devices
            try:
                # Get required objects for onboarding
                from .utils.job_management import JobManagementUtils
                job_utils = JobManagementUtils(session=session)
                required_objects = job_utils.get_required_objects_for_session(session)
                
                onboarding_jobs = []
                failed_jobs = []
                
                for result in successfully_reset:
                    device_ip = result['device_ip']
                    try:
                        device = DiscoveredDevice.objects.get(
                            session=session,
                            ip_address=device_ip
                        )
                        
                        # Create onboarding job (this will now proceed since job IDs are reset)
                        job_result = self._create_device_onboarding_job(
                            device, session, required_objects, request.user
                        )
                        
                        if job_result.get('status') == 'sync_devices_started':
                            onboarding_jobs.append(job_result)
                        else:
                            failed_jobs.append({
                                'device': device_ip,
                                'error': job_result.get('message', 'Unknown error')
                            })
                            
                    except Exception as e:
                        onboarding_logger.error(f"Error creating onboarding job for {device_ip}: {e}")
                        failed_jobs.append({
                            'device': device_ip,
                            'error': str(e)
                        })
                
                return self.success_response({
                    'onboarding_jobs': onboarding_jobs,
                    'failed_jobs': failed_jobs,
                    'reset_results': reset_results,
                    'onboarding_count': len(onboarding_jobs),
                    'message': f'Re-onboarding started for {len(onboarding_jobs)} devices'
                })
                
            except Exception as e:
                onboarding_logger.error(f"Error during confirmed re-onboarding: {e}")
                return self.error_response(
                    f'Failed to start re-onboarding: {str(e)}',
                    error_details={'reset_results': reset_results}
                )
            
        except InventoryDiscoverySession.DoesNotExist:
            return self.error_response('Discovery session not found', status_code=404)
        except json.JSONDecodeError:
            return self.error_response('Invalid JSON data', status_code=400)
        except Exception as e:
            onboarding_logger.error(f"Error in confirm duplicate onboarding: {e}")
            return self.error_response(f'Server error: {str(e)}', status_code=500)
    
    def _reset_device_job_ids(self, device):
        """Reset job IDs for a device to allow re-onboarding."""
        try:
            onboarding_logger.info(f"Resetting job IDs for device {device.ip_address} - user confirmed re-onboarding")
            device.onboarding_job_id = None
            device.network_data_job_id = None
            device.stack_member_job_id = None
            device.network_data_retry_count = 0
            device.save()
            
            # Clear any cached job data
            from .utils.job_management import JobManagementUtils
            job_utils = JobManagementUtils(session=device.session)
            job_utils.clear_network_data_job_cache(device.session.session_id, device.ip_address)
            
            return True
        except Exception as e:
            onboarding_logger.error(f"Error resetting job IDs for device {device.ip_address}: {e}")
            return False
    
    def _create_device_onboarding_job(self, device, session, required_objects, user):
        """Create onboarding job for a single device (duplicate from PrepareOnboardingAPIView)."""
        # Use JobManagementUtils for consistency
        from .utils.job_management import JobManagementUtils
        job_utils = JobManagementUtils(session=session)
        
        # Get platform for device
        platform_obj = job_utils.get_platform_for_device(device)
        if not platform_obj:
            raise Exception(f'No suitable platform found for device {device.ip_address}')
        
        # Validate secrets group associations
        self._validate_secrets_group_associations(required_objects['secrets_group'], device.ip_address)
        
        # Create job data using JobManagementUtils
        job_data = job_utils.build_device_sync_job_data(device, required_objects, platform_obj)
        
        # Execute SSOTSyncDevices job
        try:
            from nautobot.extras.models import Job, JobResult
            sync_devices_job_model = Job.objects.get(job_class_name='SSOTSyncDevices')
            sync_devices_result = JobResult.enqueue_job(
                job_model=sync_devices_job_model,
                user=user,
                **job_data
            )
            
            # Update device record
            device.onboarding_job_id = str(sync_devices_result.id)
            device.save()
            
            # Store network data job parameters for later execution using JobManagementUtils
            network_data_job_data = job_utils.build_network_data_job_data(device, required_objects, platform_obj)
            cache_key = f"network_data_job_{session.session_id}_{device.ip_address}"
            cache.set(cache_key, network_data_job_data, timeout=3600)
            
            return {
                'device': device.ip_address,
                'hostname': device.hostname,
                'sync_devices_job_id': str(sync_devices_result.id),
                'network_data_job_id': None,
                'status': 'sync_devices_started',
                'sync_devices_status': 'running',
                'network_data_status': 'pending'
            }
            
        except Job.DoesNotExist:
            raise Exception('SSOTSyncDevices job not found. Please ensure the device onboarding plugin is properly installed.')
    
    def _validate_secrets_group_associations(self, secrets_group, device_ip):
        """Validate and create Generic associations if needed."""
        from nautobot.extras.choices import SecretsGroupAccessTypeChoices, SecretsGroupSecretTypeChoices
        
        # Check for Generic associations
        has_generic_auth = False
        has_ssh_auth = False
        
        for assoc in secrets_group.secrets_group_associations.all():
            if (assoc.access_type == SecretsGroupAccessTypeChoices.TYPE_GENERIC and 
                assoc.secret_type == SecretsGroupSecretTypeChoices.TYPE_USERNAME):
                has_generic_auth = True
            elif (assoc.access_type == SecretsGroupAccessTypeChoices.TYPE_SSH and 
                  assoc.secret_type == SecretsGroupSecretTypeChoices.TYPE_USERNAME):
                has_ssh_auth = True
        
        if not has_generic_auth and not has_ssh_auth:
            # Try to create Generic associations
            try:
                self._create_generic_associations(secrets_group, device_ip)
            except Exception as e:
                raise Exception(f'Secrets group missing required associations: {str(e)}')
    
    def _create_generic_associations(self, secrets_group, device_ip):
        """Create Generic associations for secrets group if they don't exist."""
        from nautobot.extras.models import Secret, SecretsGroupAssociation
        from nautobot.extras.choices import SecretsGroupAccessTypeChoices, SecretsGroupSecretTypeChoices
        
        # Find username and password secrets
        username_secret = None
        password_secret = None
        
        for assoc in secrets_group.secrets_group_associations.all():
            if assoc.secret_type == SecretsGroupSecretTypeChoices.TYPE_USERNAME:
                username_secret = assoc.secret
            elif assoc.secret_type == SecretsGroupSecretTypeChoices.TYPE_PASSWORD:
                password_secret = assoc.secret
        
        if not username_secret or not password_secret:
            raise Exception(f'SecretsGroup {secrets_group.name} missing username or password secrets')
        
        # Create Generic associations if they don't exist
        generic_username_assoc, created = SecretsGroupAssociation.objects.get_or_create(
            secrets_group=secrets_group,
            secret=username_secret,
            access_type=SecretsGroupAccessTypeChoices.TYPE_GENERIC,
            secret_type=SecretsGroupSecretTypeChoices.TYPE_USERNAME
        )
        
        generic_password_assoc, created = SecretsGroupAssociation.objects.get_or_create(
            secrets_group=secrets_group,
            secret=password_secret,
            access_type=SecretsGroupAccessTypeChoices.TYPE_GENERIC,
            secret_type=SecretsGroupSecretTypeChoices.TYPE_PASSWORD
        )
        
        logger.info(f"Created Generic associations for SecretsGroup {secrets_group.name} for device {device_ip}")