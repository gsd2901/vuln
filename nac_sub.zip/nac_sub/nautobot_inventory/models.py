from django.db import models
from django.core.validators import validate_ipv4_address
import uuid


class InventoryDiscoverySession(models.Model):
    """Track discovery sessions and store results."""
    
    STATUS_CHOICES = [
        ('pending', 'Pending'),
        ('running', 'Running'),
        ('completed', 'Completed'),
        ('failed', 'Failed'),
        ('timeout', 'Timeout'),
        ('stopped', 'Stopped'),
    ]
    
    session_id = models.UUIDField(
        primary_key=True,
        default=uuid.uuid4,
        editable=False,
        help_text="Unique identifier for the discovery session"
    )
    
    location = models.CharField(
        max_length=128,
        help_text="Network location or site name"
    )
    
    router_ip = models.GenericIPAddressField(
        validators=[validate_ipv4_address],
        help_text="IP address of the main router to start discovery from"
    )
    
    username = models.CharField(
        max_length=64,
        help_text="SSH username for device connections"
    )
    
    # Note: In production, this should be encrypted or use a credential store
    password_hash = models.CharField(
        max_length=256,
        help_text="Hashed SSH password (for security)"
    )
    
    secrets_group_name = models.CharField(
        max_length=128,
        blank=True,
        null=True,
        help_text="Name of the secrets group used for this session"
    )
    
    status = models.CharField(
        max_length=32,
        choices=STATUS_CHOICES,
        default='pending',
        help_text="Current status of the discovery session"
    )
    
    device_count = models.IntegerField(
        default=0,
        help_text="Number of devices discovered"
    )
    
    max_depth = models.IntegerField(
        default=4,
        help_text="Maximum network depth for recursive discovery"
    )
    
    discovered_data = models.JSONField(
        default=list,
        help_text="JSON data containing discovered device information"
    )
    
    error_message = models.TextField(
        blank=True,
        null=True,
        help_text="Error message if discovery failed"
    )
    
    progress_info = models.JSONField(
        default=dict,
        help_text="Progress tracking information"
    )
    
    # Parallel discovery enhancements
    parallel_stats = models.JSONField(
        default=dict, 
        blank=True, 
        help_text="Statistics from parallel discovery engine"
    )
    
    max_workers = models.PositiveIntegerField(
        default=50, 
        help_text="Number of parallel workers used for this session"
    )
    
    created_at = models.DateTimeField(
        auto_now_add=True,
        help_text="When the discovery session was created"
    )
    
    updated_at = models.DateTimeField(
        auto_now=True,
        help_text="When the discovery session was last updated"
    )
    
    completed_at = models.DateTimeField(
        blank=True,
        null=True,
        help_text="When the discovery session completed"
    )

    class Meta:
        app_label = 'nautobot_inventory'
        ordering = ['-created_at']
        verbose_name = "Discovery Session"
        verbose_name_plural = "Discovery Sessions"

    def __str__(self):
        return f"Discovery {self.session_id} - {self.location} ({self.status})"

    @property
    def is_active(self):
        """Check if the discovery session is currently running."""
        return self.status in ['pending', 'running']

    @property
    def is_completed(self):
        """Check if the discovery session has completed successfully."""
        return self.status == 'completed'

    def update_progress(self, current_device=None, total_discovered=None, message=None):
        """Update progress information for the discovery session."""
        if not self.progress_info:
            self.progress_info = {}
        
        if current_device:
            self.progress_info['current_device'] = current_device
        if total_discovered is not None:
            self.progress_info['total_discovered'] = total_discovered
            self.device_count = total_discovered
        if message:
            self.progress_info['message'] = message
        
        self.save()


class DiscoveredDevice(models.Model):
    """Individual device discovered during a session."""
    
    session = models.ForeignKey(
        InventoryDiscoverySession,
        on_delete=models.CASCADE,
        related_name='devices',
        help_text="Discovery session this device belongs to"
    )
    
    hostname = models.CharField(
        max_length=128,
        help_text="Device hostname"
    )
    
    ip_address = models.GenericIPAddressField(
        validators=[validate_ipv4_address],
        help_text="Device IP address"
    )
    
    model = models.CharField(
        max_length=128,
        blank=True,
        null=True,
        help_text="Device model"
    )
    
    platform = models.CharField(
        max_length=64,
        blank=True,
        null=True,
        help_text="Device platform/vendor"
    )
    
    os_version = models.CharField(
        max_length=128,
        blank=True,
        null=True,
        help_text="Operating system version"
    )
    
    serial_number = models.CharField(
        max_length=128,
        blank=True,
        null=True,
        help_text="Device serial number"
    )
    
    discovery_depth = models.IntegerField(
        default=0,
        help_text="Network depth at which this device was discovered"
    )
    
    connection_status = models.CharField(
        max_length=32,
        default='discovered',
        help_text="Connection status during discovery"
    )
    
    neighbor_info = models.JSONField(
        default=list,
        help_text="Information about neighboring devices"
    )
    
    device_data = models.JSONField(
        default=dict,
        help_text="Additional device information collected during discovery"
    )
    
    # Parallel discovery enhancements
    parent_device = models.CharField(
        max_length=45,
        blank=True,
        null=True,
        help_text="IP address of the parent device that discovered this device"
    )
    
    DISCOVERY_METHOD_CHOICES = [
        ('root', 'Root Device'),
        ('cdp', 'CDP Discovery'),
        ('lldp', 'LLDP Discovery'),
        ('arp', 'ARP Discovery'),
        ('manual', 'Manual Entry'),
    ]
    
    discovered_via = models.CharField(
        max_length=20,
        choices=DISCOVERY_METHOD_CHOICES,
        default='unknown',
        blank=True,
        help_text="Method used to discover this device"
    )
    
    selected_for_onboarding = models.BooleanField(
        default=False,
        help_text="Whether this device is selected for onboarding"
    )
    
    onboarding_job_id = models.CharField(
        max_length=36,
        blank=True,
        null=True,
        help_text="ID of the onboarding job for this device"
    )
    
    network_data_job_id = models.CharField(
        max_length=36,
        blank=True,
        null=True,
        help_text="ID of the network data sync job for this device"
    )
    
    stack_member_job_id = models.CharField(
        max_length=200,
        blank=True,
        null=True,
        help_text="Status of stack member creation (e.g., 'stack_created_2_members')"
    )
    
    onboarding_status = models.CharField(
        max_length=32,
        blank=True,
        null=True,
        help_text="Status of the onboarding job"
    )
    
    custom_credentials = models.BooleanField(
        default=False,
        help_text="Whether this device has custom credentials configured"
    )
    
    discovered_at = models.DateTimeField(
        auto_now_add=True,
        help_text="When this device was discovered"
    )
    
    network_data_retry_count = models.IntegerField(
        default=0,
        help_text="Number of retry attempts for network data job triggering"
    )

    class Meta:
        app_label = 'nautobot_inventory'
        unique_together = ['session', 'ip_address']
        ordering = ['discovery_depth', 'hostname']
        verbose_name = "Discovered Device"
        verbose_name_plural = "Discovered Devices"

    def __str__(self):
        return f"{self.hostname} ({self.ip_address})"

    @property
    def is_reachable(self):
        """Check if the device was successfully connected to during discovery."""
        return self.connection_status not in ['connection_failed', 'timeout', 'unreachable']
