# nautobot_circuit_telemetry/views.py
from django.shortcuts import render, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.http import JsonResponse, HttpResponse
from django.db.models import Q, Avg, Max, Count
from nautobot.circuits.models import Circuit, Provider, CircuitTermination
from .models import CircuitTelemetryConfig, CircuitMetrics, CircuitAlert
from datetime import datetime, timedelta
import random

def test_circuit_fields(request):
    """Debug view to test circuit field access."""
    from nautobot.circuits.models import Circuit
    
    html = "<h1>Circuit Field Test</h1>"
    
    circuit = Circuit.objects.first()
    if not circuit:
        html += "<p>No circuits found in database</p>"
        return HttpResponse(html)
    
    html += f"""
    <p><strong>Circuit ID:</strong> {circuit.cid}</p>
    <p><strong>Provider:</strong> {circuit.provider.name}</p>
    
    <h3>Testing Terminations Access:</h3>
    """
    
    # Test different ways to access terminations
    terminations_found = False
    
    # Test 1: circuittermination_set
    try:
        terminations = circuit.circuittermination_set.all()
        html += f"<p>✅ circuit.circuittermination_set.all(): Found {terminations.count()} terminations</p>"
        terminations_found = True
    except AttributeError as e:
        html += f"<p>❌ circuit.circuittermination_set: {e}</p>"
    
    # Test 2: terminations
    try:
        terminations = circuit.terminations.all()
        html += f"<p>✅ circuit.terminations.all(): Found {terminations.count()} terminations</p>"
        terminations_found = True
    except AttributeError as e:
        html += f"<p>❌ circuit.terminations: {e}</p>"
    
    # Test 3: Show all attributes with 'term' in the name
    html += "<h3>All attributes containing 'term':</h3><ul>"
    term_attrs = [attr for attr in dir(circuit) if 'term' in attr.lower() and not attr.startswith('_')]
    if term_attrs:
        for attr in term_attrs:
            html += f"<li>{attr}</li>"
    else:
        html += "<li>No attributes found with 'term' in the name</li>"
    html += "</ul>"
    
    # Test basic functionality 
    html += f"<p><strong>✅ Circuit access working!</strong></p>"
    html += f"<p><a href='/plugins/circuit-telemetry/'>Back to Dashboard</a></p>"
    
    return HttpResponse(html)


@login_required
def debug_urls(request):
    """Debug view to show URL configuration."""
    from django.urls import reverse
    from django.conf import settings
    
    urls = []
    try:
        urls.append(('Dashboard', reverse('nautobot_circuit_telemetry:dashboard')))
        urls.append(('Test View', reverse('nautobot_circuit_telemetry:test')))
    except Exception as e:
        urls.append(('Error', str(e)))
    
    html = "<h1>Circuit Telemetry URL Debug</h1><ul>"
    for name, url in urls:
        html += f"<li><strong>{name}:</strong> <a href='{url}'>{url}</a></li>"
    html += "</ul>"
    
    html += f"<p><strong>App in INSTALLED_APPS:</strong> {'nautobot_circuit_telemetry' in settings.INSTALLED_APPS}</p>"
    html += f"<p><strong>Current path:</strong> {request.path}</p>"
    
    return HttpResponse(html)


@login_required
def circuit_dashboard(request):
    """Main circuit telemetry dashboard."""
    
    # Get providers with circuits
    providers = Provider.objects.annotate(
        circuit_count=Count('circuits')
    ).filter(circuit_count__gt=0).order_by('name')
    
    # Get summary stats
    total_circuits = Circuit.objects.count()
    monitored_circuits = CircuitTelemetryConfig.objects.filter(
        monitoring_enabled=True
    ).count()
    
    # Get recent alerts (separate query from count to avoid slice-then-filter issue)
    recent_alerts = CircuitAlert.objects.filter(
        status='open'
    ).order_by('-created_time')[:10]

    summary_data = [
        {"label": "Total Circuits", "value": total_circuits, "icon": "diagram-3", "color": "primary"},        # diagram for circuits
        {"label": "Monitored", "value": monitored_circuits, "icon": "eye", "color": "success"},               # eye for monitored
        {"label": "Open Alerts", "value": len(recent_alerts), "icon": "exclamation-triangle", "color": "warning"},  # triangle alert
        {"label": "Providers", "value": providers.count(), "icon": "building", "color": "info"},              # building for providers
    ]

    telemetry_data = [
        {"label": "Voltage", "value": "230V", "icon": "lightning-charge", "color": "primary"},
        {"label": "Current", "value": "4.5A", "icon": "activity", "color": "success"},
        {"label": "Power", "value": "1035W", "icon": "cpu", "color": "warning"},  # 'cpu' as best metaphor for power
        {"label": "Temperature", "value": "42°C", "icon": "thermometer-half", "color": "danger"},
        {"label": "Efficiency", "value": "87%", "icon": "graph-up", "color": "info"},
    ]

    system_health = [
        {"label": "CPU Usage", "value": 68},
        {"label": "Memory", "value": 75},
        {"label": "Network", "value": 55},
        {"label": "Storage", "value": 80},
        {"label": "Thermal", "value": 60},
    ]

    
    context = {
        'providers': providers,
        'total_circuits': total_circuits,
        'monitored_circuits': monitored_circuits,
        'recent_alerts': recent_alerts,        
        "summary_data": summary_data,
        "telemetry_data": telemetry_data,
        "system_health": system_health,
        'title': 'Circuit Telemetry Dashboard'
    }
    
    return render(request, 'nautobot_circuit_telemetry/dashboard.html', context)


@login_required
def provider_circuits(request, provider_id):
    """Show circuits for a specific provider."""
    
    provider = get_object_or_404(Provider, id=provider_id)
    circuits = Circuit.objects.filter(provider=provider).select_related(
        'provider', 'circuit_type', 'tenant'
    ).prefetch_related('telemetry_config', 'metrics', 'alerts')
    
    # Add telemetry status to each circuit
    circuits_data = []
    for circuit in circuits:
        try:
            telemetry = circuit.telemetry_config
            monitoring_enabled = telemetry.monitoring_enabled
        except CircuitTelemetryConfig.DoesNotExist:
            monitoring_enabled = False
            
        # Get latest metrics
        latest_metric = circuit.metrics.first()
        
        # Get open alerts count
        open_alerts = circuit.alerts.filter(status='open').count()
        
        circuits_data.append({
            'circuit': circuit,
            'monitoring_enabled': monitoring_enabled,
            'latest_metric': latest_metric,
            'open_alerts': open_alerts,
        })
    
    context = {
        'provider': provider,
        'circuits_data': circuits_data,
        'title': f'Circuits - {provider.name}'
    }
    
    return render(request, 'nautobot_circuit_telemetry/provider_circuits.html', context)


@login_required
def circuit_telemetry_detail(request, circuit_id):
    """Show detailed telemetry for a specific circuit."""
    
    circuit = get_object_or_404(Circuit, id=circuit_id)
    
    # Get or create telemetry config
    telemetry_config, created = CircuitTelemetryConfig.objects.get_or_create(
        circuit=circuit,
        defaults={'monitoring_enabled': True}
    )
    
    # Get recent metrics (last 24 hours)
    end_time = datetime.now()
    start_time = end_time - timedelta(hours=24)
    
    recent_metrics = circuit.metrics.filter(
        timestamp__gte=start_time,
        timestamp__lte=end_time
    ).order_by('-timestamp')
    
    # Calculate summary stats
    if recent_metrics:
        avg_utilization_in = recent_metrics.aggregate(
            avg=Avg('utilization_in_percent')
        )['avg'] or 0
        
        avg_utilization_out = recent_metrics.aggregate(
            avg=Avg('utilization_out_percent')
        )['avg'] or 0
        
        max_utilization_in = recent_metrics.aggregate(
            max=Max('utilization_in_percent')
        )['max'] or 0
        
        max_utilization_out = recent_metrics.aggregate(
            max=Max('utilization_out_percent')  
        )['max'] or 0
        
        avg_latency = recent_metrics.filter(
            latency_ms__isnull=False
        ).aggregate(avg=Avg('latency_ms'))['avg']
    else:
        avg_utilization_in = avg_utilization_out = 0
        max_utilization_in = max_utilization_out = 0
        avg_latency = None
    
    # Get recent alerts and calculate open alerts count separately
    recent_alerts_queryset = circuit.alerts.order_by('-created_time')
    recent_alerts = recent_alerts_queryset[:10]  # Latest 10 alerts for display
    open_alerts_count = circuit.alerts.filter(status='open').count()  # Count separately
    
    # Try to get circuit terminations - handle different possible field names
    terminations = []
    for field_name in ['circuittermination_set', 'terminations', 'circuit_terminations']:
        try:
            termination_manager = getattr(circuit, field_name, None)
            if termination_manager:
                terminations = termination_manager.all()
                break
        except AttributeError:
            continue
    
    context = {
        'circuit': circuit,
        'telemetry_config': telemetry_config,
        'recent_metrics': recent_metrics[:50],  # Latest 50 metrics
        'recent_alerts': recent_alerts,
        'terminations': terminations,
        'terminations_count': len(terminations),
        'stats': {
            'avg_utilization_in': round(avg_utilization_in, 2),
            'avg_utilization_out': round(avg_utilization_out, 2),
            'max_utilization_in': round(max_utilization_in, 2),
            'max_utilization_out': round(max_utilization_out, 2),
            'avg_latency': round(avg_latency, 2) if avg_latency else None,
            'total_metrics': recent_metrics.count(),
            'open_alerts': open_alerts_count,  # Use the separately calculated count
        },
        'title': f'Telemetry - {circuit.cid}'
    }
    
    return render(request, 'nautobot_circuit_telemetry/circuit_detail.html', context)


@login_required
def circuit_metrics_api(request, circuit_id):
    """API endpoint for circuit metrics (for charts)."""
    
    circuit = get_object_or_404(Circuit, id=circuit_id)
    
    # Get time range from query params
    hours = int(request.GET.get('hours', 24))
    end_time = datetime.now()
    start_time = end_time - timedelta(hours=hours)
    
    metrics = circuit.metrics.filter(
        timestamp__gte=start_time,
        timestamp__lte=end_time
    ).order_by('timestamp')
    
    # Format data for charts
    data = {
        'labels': [m.timestamp.strftime('%H:%M') for m in metrics],
        'utilization_in': [m.utilization_in_percent for m in metrics],
        'utilization_out': [m.utilization_out_percent for m in metrics],
        'latency': [m.latency_ms for m in metrics if m.latency_ms],
        'packet_loss': [m.packet_loss_percent for m in metrics],
    }
    
    return JsonResponse(data)

@login_required
def dashboard_metrics_api(request):
    """API endpoint for dashboard-level metrics (for charts)."""
    
    # Get time range from query params
    hours = int(request.GET.get('hours', 24))
    end_time = datetime.now()
    start_time = end_time - timedelta(hours=hours)
    
    # Aggregate metrics across all circuits
    all_metrics = CircuitMetrics.objects.filter(
        timestamp__gte=start_time,
        timestamp__lte=end_time
    ).order_by('timestamp')
    
    # Group metrics by time intervals (e.g., hourly)
    time_labels = []
    utilization_data = []
    latency_data = []
    
    # Create hourly buckets
    current_time = start_time
    while current_time <= end_time:
        next_time = current_time + timedelta(hours=1)
        
        # Get metrics in this time bucket
        bucket_metrics = all_metrics.filter(
            timestamp__gte=current_time,
            timestamp__lt=next_time
        )
        
        if bucket_metrics.exists():
            avg_util_in = bucket_metrics.aggregate(
                avg=Avg('utilization_in_percent')
            )['avg'] or 0
            
            avg_util_out = bucket_metrics.aggregate(
                avg=Avg('utilization_out_percent')  
            )['avg'] or 0
            
            avg_latency = bucket_metrics.filter(
                latency_ms__isnull=False
            ).aggregate(avg=Avg('latency_ms'))['avg'] or 0
            
            # Use average of in/out utilization
            avg_utilization = (avg_util_in + avg_util_out) / 2
        else:
            avg_utilization = 0
            avg_latency = 0
        
        time_labels.append(current_time.strftime('%H:%M'))
        utilization_data.append(round(avg_utilization, 2))
        latency_data.append(round(avg_latency, 2))
        
        current_time = next_time
    
    # If no real data, return sample data
    if not time_labels:
        time_labels = [f"{i:02d}:00" for i in range(24)]
        utilization_data = [random.randint(30, 90) for _ in range(24)]
        latency_data = [random.randint(5, 25) for _ in range(24)]
    
    data = {
        'labels': time_labels,
        'utilization': utilization_data,
        'latency': latency_data,
    }
    
    return JsonResponse(data)