# nautobot_circuit_telemetry/urls.py
from django.urls import path
from . import views

app_name = 'nautobot_circuit_telemetry'

urlpatterns = [
    # Debug URLs (remove in production)
    path('test/', views.test_circuit_fields, name='test'),
    path('debug/', views.debug_urls, name='debug'),
    
    # Main dashboard
    path('', views.circuit_dashboard, name='dashboard'),
    
    # Provider-specific circuit views
    path('provider/<uuid:provider_id>/circuits/', 
         views.provider_circuits, 
         name='provider_circuits'),
    
    # Circuit telemetry detail
    path('circuit/<uuid:circuit_id>/', 
         views.circuit_telemetry_detail, 
         name='circuit_detail'),
    
    # API endpoints
    path('api/circuit/<uuid:circuit_id>/metrics/', 
         views.circuit_metrics_api, 
         name='circuit_metrics_api'),

     path('api/dashboard/metrics/', 
          views.dashboard_metrics_api, 
          name='dashboard_metrics_api'),
]