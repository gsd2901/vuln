# nautobot_circuit_telemetry/admin.py
from django.contrib import admin
from django.urls import reverse
from django.utils.html import format_html
from .models import CircuitTelemetryConfig, CircuitMetrics, CircuitAlert


@admin.register(CircuitTelemetryConfig)
class CircuitTelemetryConfigAdmin(admin.ModelAdmin):
    list_display = [
        'circuit_link',
        'monitoring_enabled',
        'polling_interval',
        'bandwidth_threshold',
        'alert_email',
    ]
    list_filter = [
        'monitoring_enabled',
        'circuit__provider',
        'circuit__circuit_type',
        'circuit__status',
    ]
    search_fields = [
        'circuit__cid',
        'circuit__provider__name',
        'alert_email',
    ]
    raw_id_fields = ['circuit']
    
    fieldsets = (
        ('Circuit', {
            'fields': ('circuit',)
        }),
        ('Monitoring Configuration', {
            'fields': (
                'monitoring_enabled',
                'polling_interval',
            )
        }),
        ('Alert Thresholds', {
            'fields': (
                'bandwidth_threshold',
                'latency_threshold',
                'alert_email',
            )
        }),
    )
    
    def circuit_link(self, obj):
        """Link to the circuit admin page."""
        if obj.circuit:
            url = reverse('admin:circuits_circuit_change', args=[obj.circuit.pk])
            return format_html('<a href="{}">{}</a>', url, obj.circuit.cid)
        return "—"
    circuit_link.short_description = "Circuit"
    circuit_link.admin_order_field = "circuit__cid"


@admin.register(CircuitMetrics)
class CircuitMetricsAdmin(admin.ModelAdmin):
    list_display = [
        'circuit_link',
        'timestamp',
        'utilization_in_percent',
        'utilization_out_percent',
        'latency_ms',
        'interface_status'
    ]
    list_filter = [
        'interface_status',
        'circuit__provider',
        'timestamp',
    ]
    search_fields = [
        'circuit__cid',
        'circuit__provider__name',
    ]
    readonly_fields = ['timestamp']
    raw_id_fields = ['circuit']
    date_hierarchy = 'timestamp'
    
    # Disable add/edit in admin - metrics should come from monitoring
    def has_add_permission(self, request):
        return False
        
    def has_change_permission(self, request, obj=None):
        return False
    
    def circuit_link(self, obj):
        """Link to the circuit admin page."""
        if obj.circuit:
            url = reverse('admin:circuits_circuit_change', args=[obj.circuit.pk])
            return format_html('<a href="{}">{}</a>', url, obj.circuit.cid)
        return "—"
    circuit_link.short_description = "Circuit"
    circuit_link.admin_order_field = "circuit__cid"


@admin.register(CircuitAlert)
class CircuitAlertAdmin(admin.ModelAdmin):
    list_display = [
        'circuit_link',
        'alert_type',
        'severity',
        'status',
        'created_time',
        'resolved_time'
    ]
    list_filter = [
        'alert_type',
        'severity',
        'status',
        'circuit__provider',
        'created_time',
    ]
    search_fields = [
        'circuit__cid',
        'circuit__provider__name',
        'message',
    ]
    raw_id_fields = ['circuit']
    readonly_fields = ['created_time']
    date_hierarchy = 'created_time'
    
    fieldsets = (
        ('Alert Information', {
            'fields': (
                'circuit',
                'alert_type',
                'severity',
                'message',
            )
        }),
        ('Status Tracking', {
            'fields': (
                'status',
                'created_time',
                'resolved_time',
            )
        }),
    )
    
    def circuit_link(self, obj):
        """Link to the circuit admin page."""
        if obj.circuit:
            url = reverse('admin:circuits_circuit_change', args=[obj.circuit.pk])
            return format_html('<a href="{}">{}</a>', url, obj.circuit.cid)
        return "—"
    circuit_link.short_description = "Circuit"
    circuit_link.admin_order_field = "circuit__cid"