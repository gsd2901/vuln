# nautobot_circuit_telemetry/models.py
from django.db import models
from django.core.validators import MinValueValidator, MaxValueValidator
from nautobot.apps.models import PrimaryModel
from nautobot.circuits.models import Circuit, Provider, CircuitTermination


class CircuitTelemetryConfig(PrimaryModel):
    """Telemetry configuration for existing Nautobot circuits."""
    
    # One-to-one with existing Circuit model
    circuit = models.OneToOneField(
        Circuit,
        on_delete=models.CASCADE,
        related_name="telemetry_config",
        help_text="Associated circuit from core Nautobot"
    )
    
    # Monitoring settings
    monitoring_enabled = models.BooleanField(default=True)
    polling_interval = models.PositiveIntegerField(
        default=300,
        help_text="Polling interval in seconds"
    )
    
    # Alert settings
    bandwidth_threshold = models.PositiveIntegerField(
        default=80,
        validators=[MinValueValidator(1), MaxValueValidator(100)],
        help_text="Bandwidth utilization threshold (%)"
    )
    
    latency_threshold = models.PositiveIntegerField(
        default=100,
        help_text="Latency threshold in ms"
    )
    
    # Contact info
    alert_email = models.EmailField(blank=True)
    
    class Meta:
        verbose_name = "Circuit Telemetry Config"
        
    def __str__(self):
        return f"Telemetry for {self.circuit.cid}"


class CircuitMetrics(models.Model):
    """Time-series metrics for circuits."""
    
    circuit = models.ForeignKey(
        Circuit,
        on_delete=models.CASCADE,
        related_name="metrics"
    )
    
    timestamp = models.DateTimeField(auto_now_add=True)
    
    # Traffic metrics
    bandwidth_in_mbps = models.FloatField(default=0.0)
    bandwidth_out_mbps = models.FloatField(default=0.0)
    utilization_in_percent = models.FloatField(default=0.0)
    utilization_out_percent = models.FloatField(default=0.0)
    
    # Performance metrics  
    latency_ms = models.FloatField(null=True, blank=True)
    packet_loss_percent = models.FloatField(default=0.0)
    jitter_ms = models.FloatField(null=True, blank=True)
    
    # Status
    interface_status = models.CharField(
        max_length=10,
        choices=[("up", "Up"), ("down", "Down")],
        default="up"
    )
    
    # Error counters
    input_errors = models.BigIntegerField(default=0)
    output_errors = models.BigIntegerField(default=0)
    crc_errors = models.BigIntegerField(default=0)
    
    class Meta:
        ordering = ["-timestamp"]
        indexes = [
            models.Index(fields=["circuit", "-timestamp"]),
        ]
        
    def __str__(self):
        return f"{self.circuit.cid} metrics at {self.timestamp}"


class CircuitAlert(PrimaryModel):
    """Alerts for circuit issues."""
    
    circuit = models.ForeignKey(
        Circuit,
        on_delete=models.CASCADE,
        related_name="alerts"
    )
    
    alert_type = models.CharField(
        max_length=20,
        choices=[
            ("threshold", "Threshold"),
            ("interface", "Interface Down"),
            ("performance", "Performance"),
        ]
    )
    
    severity = models.CharField(
        max_length=10,
        choices=[
            ("critical", "Critical"),
            ("warning", "Warning"), 
            ("info", "Info"),
        ]
    )
    
    message = models.TextField()
    
    status = models.CharField(
        max_length=15,
        choices=[
            ("open", "Open"),
            ("acknowledged", "Acknowledged"),
            ("resolved", "Resolved"),
        ],
        default="open"
    )
    
    created_time = models.DateTimeField(auto_now_add=True)
    resolved_time = models.DateTimeField(null=True, blank=True)
    
    class Meta:
        ordering = ["-created_time"]
        
    def __str__(self):
        return f"{self.alert_type} alert for {self.circuit.cid}"