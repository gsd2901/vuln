"""App declaration for Circuit Telemetry plugin."""

from nautobot.apps import NautobotAppConfig

__version__ = "1.0.0"

class CircuitTelemetryConfig(NautobotAppConfig):
    name = "nautobot_circuit_telemetry"
    verbose_name = "Circuit Telemetry"
    description = "Enhanced telemetry and monitoring for Nautobot circuits"
    author = "Your Organization"
    author_email = "avinash_sharma@hcltech.com"
    base_url = "circuit-telemetry"
    required_settings = []
    default_settings = {
        "enable_monitoring": True,
        "default_polling_interval": 300,
        "retention_days": 90,
    }
    min_version = "1.0.0"
    max_version = "3.0.0"
    caching_config = {}

    def ready(self):
        """Callback when this app is loaded."""
        super().ready()
        
        # Import any signal handlers or background tasks
        try:
            from . import signals
            print("✅ Successfully loaded Circuit Telemetry signals")
        except ImportError:
            pass  # Signals not implemented yet
            
        try:
            from . import jobs
            print("✅ Successfully loaded Circuit Telemetry jobs")
        except ImportError:
            pass  # Jobs not implemented yet

config = CircuitTelemetryConfig