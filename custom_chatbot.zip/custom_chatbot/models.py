from django.db import models
import uuid

class Document(models.Model):
    title = models.CharField(max_length=255)
    content = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.title

# class Conversation(models.Model):
#     session_id = models.CharField(max_length=100)
#     message = models.TextField()
#     response = models.TextField()
#     created_at = models.DateTimeField(auto_now_add=True)

#     def __str__(self):
#         return f"Conversation {self.id}"

class Conversation(models.Model):
    session_id = models.CharField(max_length=100, db_index=True)
    role = models.CharField(max_length=10, default='user')  # 'user' or 'assistant'
    content = models.TextField()
    tool_used = models.CharField(max_length=50, null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['session_id', 'created_at']
    
    def __str__(self):
        return f"{self.session_id}: {self.role} ({self.tool_used})"

# class ChatStatusState(models.Model):
#     instance_id = models.UUIDField(default=uuid.uuid4(), editable=False, primary_key=True, serialize=False, unique=True)
#     key = models.CharField(max_length=100)
#     value = models.TextField()
 
#     class Meta:
#         unique_together = ('instance_id', 'key')
