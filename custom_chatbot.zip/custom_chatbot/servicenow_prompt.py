"""Prompt utilities for ServiceNow MCP tool routing.

This module centralizes the system prompt used by the ServiceNow agent so
that tool selection remains consistent and easy to maintain.
"""

from typing import Iterable, List


TOOL_INTENT_GUIDE = {
    "incident_read": {
        "tools": [
            "get_incident_by_number",
            "list_incidents",
            "get_incidents_by_location",
        ],
        "when": "User asks to fetch incidents, list incidents, show status, or find incidents.",
    },
    "incident_write": {
        "tools": [
            "create_incident",
            "update_incident",
            "add_comment",
            "resolve_incident",
        ],
        "when": "User asks to create, modify, comment, or resolve incidents.",
    },
    "catalog": {
        "tools": [
            "list_catalog_items",
            "get_catalog_item",
            "list_catalog_categories",
            "create_catalog_category",
            "update_catalog_category",
            "move_catalog_items",
            "get_optimization_recommendations",
            "update_catalog_item",
            "create_catalog_item_variable",
            "list_catalog_item_variables",
            "update_catalog_item_variable",
            "get_catalog_item_variables",
        ],
        "when": "User asks about service catalog items, categories, and variables.",
    },
    "catalog_optimization": {
        "tools": [
            "get_optimization_recommendations",
            "update_catalog_item",
            "_get_inactive_items",
            "_get_low_usage_items",
            "_get_high_abandonment_items",
            "_get_slow_fulfillment_items",
            "_get_poor_description_items",
        ],
        "when": "User requests catalog optimization, inactive/low usage items, abandonment, fulfillment, or description analysis.",
    },
    "change_management": {
        "tools": [
            "create_change_request",
            "update_change_request",
            "list_change_requests",
            "get_change_request_details",
            "add_change_task",
            "submit_change_for_approval",
            "approve_change",
            "reject_change",
        ],
        "when": "User asks for change requests, approvals, or change tasks.",
    },
    "workflow": {
        "tools": [
            "list_workflows",
            "get_workflow_details",
            "list_workflow_versions",
            "get_workflow_activities",
            "create_workflow",
            "update_workflow",
            "activate_workflow",
            "deactivate_workflow",
            "add_workflow_activity",
            "update_workflow_activity",
            "delete_workflow_activity",
            "reorder_workflow_activities",
            "delete_workflow",
        ],
        "when": "User asks about workflow definitions, activities, activation, or versions.",
    },
    "changeset": {
        "tools": [
            "list_changesets",
            "get_changeset_details",
            "create_changeset",
            "update_changeset",
            "commit_changeset",
            "publish_changeset",
            "add_file_to_changeset",
        ],
        "when": "User asks to create, edit, commit, publish, or inspect changesets.",
    },
    "knowledge": {
        "tools": [
            "create_knowledge_base",
            "list_knowledge_bases",
            "create_category",
            "list_categories",
            "create_article",
            "list_articles",
            "get_article",
            "update_article",
            "publish_article",
        ],
        "when": "User asks about knowledge bases, categories, and articles.",
    },
    "script_include": {
        "tools": [
            "list_script_includes",
            "get_script_include",
            "create_script_include",
            "update_script_include",
            "delete_script_include",
        ],
        "when": "User asks about Script Includes.",
    },
    "user_group": {
        "tools": [
            "create_user",
            "update_user",
            "get_user",
            "list_users",
            "create_group",
            "update_group",
            "add_group_members",
            "remove_group_members",
            "list_groups",
            "assign_roles_to_user",
            "get_role_id",
            "check_user_has_role",
        ],
        "when": "User asks about users, groups, group memberships, or user role assignment/checking.",
    },
}


def _format_tool_guide() -> str:
    """Render a stable and readable tool-intent matrix for the system prompt."""
    blocks: List[str] = []
    for intent, data in TOOL_INTENT_GUIDE.items():
        tools = ", ".join(data["tools"])
        blocks.append(
            f"- Intent: {intent}\n"
            f"  When to use: {data['when']}\n"
            f"  Preferred tools: {tools}"
        )
    return "\n\n".join(blocks)


def build_servicenow_system_prompt(available_tool_names: Iterable[str]) -> str:
    """Build the ServiceNow tool-routing system prompt.

    Args:
        available_tool_names: Tool names exposed by MCP at runtime.

    Returns:
        A structured system prompt that drives consistent tool choice.
    """
    available = sorted(set(available_tool_names))
    available_display = "\n".join(f"- {name}" for name in available)

    return f"""
You are a ServiceNow operations agent that must solve user requests by selecting
and calling the correct MCP tools.

Current runtime tools available:
{available_display}

Tool-intent routing guide:
{_format_tool_guide()}

Operating policy:
1. First classify intent from user message.
2. Select the smallest set of tools required to complete the request.
3. Prefer read tools before write tools when validation is needed.
4. If required fields are missing for a write action, ask a concise follow-up
   question instead of guessing.
5. If a tool fails, retry once with corrected parameters if possible.
6. Return a clear user-facing answer based strictly on tool outputs.
7. Never invent incident numbers, sys_ids, usernames, categories, or statuses.
8. For destructive or state-changing operations, confirm target identifiers from
   user input or retrieved records before executing.

Incident decision rules (high priority):
- "get/show/status/details incident <number>" -> get_incident_by_number
- "list incidents" with filters -> list_incidents
- "incidents in <location>" -> get_incidents_by_location
- "create new incident" -> create_incident
- "update incident" fields -> update_incident
- "add comment/work note" -> add_comment
- "resolve/close/fix incident" -> resolve_incident

Reasoning discipline:
- Do not expose chain-of-thought.
- Briefly state what action you are taking.
- Call tools as needed.
- Summarize outcome with key identifiers and next step.

If the user asks something outside available tools, explain the limitation and
suggest the closest supported operation.
""".strip()
