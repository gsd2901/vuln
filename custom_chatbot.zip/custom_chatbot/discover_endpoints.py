#!/usr/bin/env python3
"""
Nautobot Endpoint Discoverer
============================
Queries the live Nautobot API root to get every available endpoint
for YOUR specific version/installation, then prints them grouped by app.

Usage:
    python discover_endpoints.py --url https://172.21.17.22 --token your-token --no-verify

This also updates ENDPOINTS in nautobot_fetch_all.py automatically if
--update-fetch-script is passed.
"""

import argparse
import json
import sys

try:
    import requests
    import urllib3
except ImportError:
    print("requests not installed. Run: pip install requests")
    sys.exit(1)


def discover(url: str, token: str, verify: bool) -> dict:
    """Hit /api/ and return {app: [resource, ...]} from the live instance."""
    root = url.rstrip("/") + "/api/"
    headers = {
        "Authorization": f"Token {token}",
        "Accept": "application/json",
    }
    resp = requests.get(root, headers=headers, verify=verify, timeout=15)
    resp.raise_for_status()
    data = resp.json()

    endpoints = {}
    for app_url_label, app_url in data.items():
        # app_url_label is like "circuits", value is the URL
        app = app_url_label.lower().replace("-", "_")
        # Fetch the app root to list its resources
        try:
            app_resp = requests.get(app_url, headers=headers, verify=verify, timeout=15)
            app_resp.raise_for_status()
            app_data = app_resp.json()
            resources = []
            for resource_label in app_data.keys():
                # Convert kebab-case to snake_case for pynautobot attribute access
                resource = resource_label.lower().replace("-", "_")
                resources.append(resource)
            if resources:
                endpoints[app] = resources
        except Exception as e:
            print(f"  ! Could not fetch app '{app}': {e}")

    return endpoints


def main():
    parser = argparse.ArgumentParser(description="Discover live Nautobot API endpoints")
    parser.add_argument("--url",   required=True, help="Nautobot base URL")
    parser.add_argument("--token", required=True, help="Nautobot API token")
    parser.add_argument("--no-verify", action="store_true", help="Disable SSL verification")
    parser.add_argument("--update-fetch-script", default=None,
                        help="Path to nautobot_fetch_all.py to auto-update its ENDPOINTS dict")
    args = parser.parse_args()

    verify = not args.no_verify
    if not verify:
        urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

    print(f"\nDiscovering endpoints on {args.url} ...\n")

    endpoints = discover(args.url, args.token, verify)

    total = sum(len(v) for v in endpoints.values())
    print(f"Found {len(endpoints)} apps, {total} total endpoints:\n")

    for app, resources in endpoints.items():
        print(f"  [{app}]")
        for r in resources:
            print(f"    - {r}")
        print()

    # Print as Python dict ready to paste
    print("\n# ── Ready-to-use ENDPOINTS dict ──────────────────────────────\n")
    print("ENDPOINTS = {")
    for app, resources in endpoints.items():
        print(f'    "{app}": [')
        for r in resources:
            print(f'        "{r}",')
        print("    ],")
    print("}")

    # Optionally patch nautobot_fetch_all.py
    if args.update_fetch_script:
        try:
            with open(args.update_fetch_script, "r") as f:
                src = f.read()

            # Build replacement block
            new_block = "ENDPOINTS = {\n"
            for app, resources in endpoints.items():
                new_block += f'    "{app}": [\n'
                for r in resources:
                    new_block += f'        "{r}",\n'
                new_block += "    ],\n"
            new_block += "}"

            import re
            patched = re.sub(
                r"ENDPOINTS\s*=\s*\{.*?\n\}",
                new_block,
                src,
                flags=re.DOTALL
            )

            with open(args.update_fetch_script, "w") as f:
                f.write(patched)

            print(f"\n  ✓ Updated ENDPOINTS in {args.update_fetch_script}")
        except Exception as e:
            print(f"\n  ✗ Could not update script: {e}")


if __name__ == "__main__":
    main()
