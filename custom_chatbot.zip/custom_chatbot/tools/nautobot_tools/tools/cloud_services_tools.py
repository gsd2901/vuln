"""
Nautobot Cloud cloud_service helpers for MCP server.

Provides simple CRUD helpers for Nautobot Cloud cloud_services.
"""
from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

import pynautobot
from pydantic import BaseModel, Field

from .nautobot_fields_actual import CLOUD_SERVICES_PLAIN_FIELDS, CLOUD_SERVICES_RELATION_FIELDS, CLOUD_SERVICES_MULTI_RELATION_FIELDS
from .nautobot_relation_utils import list_tools, count_tools, get_tools

logger = logging.getLogger(__name__)


class ListCloudServicesParams(BaseModel):
    name: Optional[str] = Field(None, description="Filter by cloud_service name.")
    cloud_account: Optional[str] = Field(None, description="Filter by cloud account name/slug/ID.")
    cloud_networks: Optional[str] = Field(None, description="Filter by cloud network name/slug/ID.")
    cloud_resource_type: Optional[str] = Field(None, description="Filter by cloud resource type name/slug/ID.")
    tags: Optional[str] = Field(None, description="Filter by tag name/slug.")
    query: Optional[str] = Field(None, description="General search query.")
    limit: int = Field(5, description="Maximum number of cloud_services to return.")


class GetCloudServiceParams(BaseModel):
    id: Optional[str] = Field(None, description="CloudService ID or UUID.")
    name: Optional[str] = Field(None, description="CloudService name.")


PLAIN_FIELDS: List[str] = CLOUD_SERVICES_PLAIN_FIELDS
RELATION_FIELDS: List[str] = CLOUD_SERVICES_RELATION_FIELDS
MULTI_RELATION_FIELDS: List[str] = CLOUD_SERVICES_MULTI_RELATION_FIELDS


def list_cloud_services(api: pynautobot.core.api.Api, params: ListCloudServicesParams) -> Dict[str, Any]:
    return list_tools(
        api=api,
        endpoint=api.cloud.cloud_services,
        params=params,
        plain_fields=PLAIN_FIELDS,
        relation_fields=RELATION_FIELDS,
        multi_relation_fields=MULTI_RELATION_FIELDS,
        result_key="cloud_services",
        limit=getattr(params, "limit", 5),
    )


def get_cloud_service(api: pynautobot.core.api.Api, params: GetCloudServiceParams) -> Dict[str, Any]:
    return get_tools(
        api=api,
        endpoint=api.cloud.cloud_services,
        params=params,
        plain_fields=PLAIN_FIELDS,
        relation_fields=RELATION_FIELDS,
        multi_relation_fields=MULTI_RELATION_FIELDS,
        result_key="cloud_services",
        lookup_fields=['id', 'name'],
    )

def count_cloud_service(api: pynautobot.core.api.Api, params: ListCloudServicesParams) -> Dict[str, Any]:
    return count_tools(
        endpoint=api.cloud.cloud_services,
        params=params,
        resource_name="cloud_services",
    )
