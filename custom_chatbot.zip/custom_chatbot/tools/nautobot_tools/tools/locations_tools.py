"""
location_tools

Pydantic-style helpers for Nautobot DCIM Location API.

Provides simple tools: list_locations, get_location, create_location,
update_location, delete_location. Follows the patterns in `vlance_tools.py`.
"""
from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

import pynautobot
from pydantic import BaseModel, Field

from .nautobot_fields_actual import LOCATIONS_PLAIN_FIELDS, LOCATIONS_RELATION_FIELDS, LOCATIONS_MULTI_RELATION_FIELDS
from .nautobot_relation_utils import list_tools, count_tools, get_tools

logger = logging.getLogger(__name__)


class ListLocationsParams(BaseModel):
    id: Optional[str] = Field(None, description="Location UUID/PK")
    name: Optional[str] = Field(None, description="Name to filter (case-insensitive contains)")
    natural_slug: Optional[str] = Field(None, description="Natural slug to filter")
    location_type: Optional[str] = Field(None, description="Location type slug or name")
    parent: Optional[str] = Field(None, description="Parent location name/slug/ID")
    subtree: Optional[str] = Field(None, description="Subtree root location name/slug/ID (best-effort)")
    status: Optional[str] = Field(None, description="Status slug or name")
    tenant_group: Optional[str] = Field(None, description="Tenant group name/slug/ID (best-effort derived from tenant)")
    tenant: Optional[str] = Field(None, description="Tenant name/slug/ID")
    tags: Optional[str] = Field(None, description="Filter by tag name/slug")
    contacts: Optional[str] = Field(None, description="Filter by contacts (best-effort derived value)")
    teams: Optional[str] = Field(None, description="Filter by teams (best-effort derived value)")
    query: Optional[str] = Field(None, description="Free-text contains search on name/description")
    tree_depth: Optional[int] = Field(None, description="Depth of the location within the location tree hierarchy (0 = root)")
    comments: Optional[str] = Field(None, description="Filter by comments field (case-insensitive contains)")
    contact_name: Optional[str] = Field(None, description="Name of the primary contact associated with the location")
    created: Optional[str] = Field(None, description="Filter by creation date (ISO 8601 format, e.g. 2024-01-01)")
    last_updated: Optional[str] = Field(None, description="Filter by last updated datetime (ISO 8601 format, e.g. 2024-01-01T00:00:00Z)")
    contact_email: Optional[str] = Field(None, description="Email address of the primary contact for this location")
    contact_phone: Optional[str] = Field(None, description="Phone number of the primary contact for this location")
    longitude: Optional[float] = Field(None, description="Geographic longitude coordinate of the location (decimal degrees)")
    asn: Optional[int] = Field(None, description="Autonomous System Number (ASN) associated with the location")
    latitude: Optional[float] = Field(None, description="Geographic latitude coordinate of the location (decimal degrees)")
    shipping_address: Optional[str] = Field(None, description="Shipping address of the location (case-insensitive contains)")
    physical_address: Optional[str] = Field(None, description="Physical/street address of the location (case-insensitive contains)")
    description: Optional[str] = Field(None, description="Filter by description field (case-insensitive contains)")
    facility: Optional[str] = Field(None, description="Facility identifier or name assigned to the location (e.g. data center code)")
    circuit_count: Optional[int] = Field(None, description="Filter locations by exact number of circuits associated")
    time_zone: Optional[str] = Field(None, description="Time zone of the location (IANA tz format, e.g. America/New_York)")
    device_count: Optional[int] = Field(None, description="Filter locations by exact number of devices assigned")
    vlan_count: Optional[int] = Field(None, description="Filter locations by exact number of VLANs associated")
    virtual_machine_count: Optional[int] = Field(None, description="Filter locations by exact number of virtual machines assigned")
    prefix_count: Optional[int] = Field(None, description="Filter locations by exact number of IP prefixes associated")
    rack_count: Optional[int] = Field(None, description="Filter locations by exact number of racks assigned")


class GetLocationParams(BaseModel):
    id: Optional[str] = Field(None, description="Location UUID/PK")
    name: Optional[str] = Field(None, description="Location name")
    natural_slug: Optional[str] = Field(None, description="Natural slug")
    location_type: Optional[str] = Field(None, description="Location type slug or name")
    parent: Optional[str] = Field(None, description="Parent location name/slug/ID")
    subtree: Optional[str] = Field(None, description="Subtree root location name/slug/ID (best-effort)")
    status: Optional[str] = Field(None, description="Status slug or name")
    tenant_group: Optional[str] = Field(None, description="Tenant group name/slug/ID (best-effort derived from tenant)")
    tenant: Optional[str] = Field(None, description="Tenant name/slug/ID")
    tags: Optional[str] = Field(None, description="Filter by tag name/slug")
    contacts: Optional[str] = Field(None, description="Filter by contacts (best-effort derived value)")
    teams: Optional[str] = Field(None, description="Filter by teams (best-effort derived value)")
    query: Optional[str] = Field(None, description="Free-text contains search on name/description")
    tree_depth: Optional[int] = Field(None, description="Depth of the location within the location tree hierarchy (0 = root)")
    comments: Optional[str] = Field(None, description="Filter by comments field (case-insensitive contains)")
    contact_name: Optional[str] = Field(None, description="Name of the primary contact associated with the location")
    created: Optional[str] = Field(None, description="Filter by creation date (ISO 8601 format, e.g. 2024-01-01)")
    last_updated: Optional[str] = Field(None, description="Filter by last updated datetime (ISO 8601 format, e.g. 2024-01-01T00:00:00Z)")
    contact_email: Optional[str] = Field(None, description="Email address of the primary contact for this location")
    contact_phone: Optional[str] = Field(None, description="Phone number of the primary contact for this location")
    longitude: Optional[float] = Field(None, description="Geographic longitude coordinate of the location (decimal degrees)")
    asn: Optional[int] = Field(None, description="Autonomous System Number (ASN) associated with the location")
    latitude: Optional[float] = Field(None, description="Geographic latitude coordinate of the location (decimal degrees)")
    shipping_address: Optional[str] = Field(None, description="Shipping address of the location (case-insensitive contains)")
    physical_address: Optional[str] = Field(None, description="Physical/street address of the location (case-insensitive contains)")
    description: Optional[str] = Field(None, description="Filter by description field (case-insensitive contains)")
    facility: Optional[str] = Field(None, description="Facility identifier or name assigned to the location (e.g. data center code)")
    circuit_count: Optional[int] = Field(None, description="Filter locations by exact number of circuits associated")
    time_zone: Optional[str] = Field(None, description="Time zone of the location (IANA tz format, e.g. America/New_York)")
    device_count: Optional[int] = Field(None, description="Filter locations by exact number of devices assigned")
    vlan_count: Optional[int] = Field(None, description="Filter locations by exact number of VLANs associated")
    virtual_machine_count: Optional[int] = Field(None, description="Filter locations by exact number of virtual machines assigned")
    prefix_count: Optional[int] = Field(None, description="Filter locations by exact number of IP prefixes associated")
    rack_count: Optional[int] = Field(None, description="Filter locations by exact number of racks assigned")


PLAIN_FIELDS: List[str] = LOCATIONS_PLAIN_FIELDS
RELATION_FIELDS: List[str] = LOCATIONS_RELATION_FIELDS
MULTI_RELATION_FIELDS: List[str] = LOCATIONS_MULTI_RELATION_FIELDS


def list_locations(api: pynautobot.core.api.Api, params: ListLocationsParams) -> Dict[str, Any]:
    return list_tools(
        api=api,
        endpoint=api.dcim.locations,
        params=params,
        plain_fields=PLAIN_FIELDS,
        relation_fields=RELATION_FIELDS,
        multi_relation_fields=MULTI_RELATION_FIELDS,
        result_key="locations",
        limit=getattr(params, "limit", 5),
    )


def count_locations(api: pynautobot.core.api.Api, params: ListLocationsParams) -> Dict[str, Any]:
    return count_tools(
        endpoint=api.dcim.locations,
        params=params,
        resource_name="locations",
    )


def get_location(api: pynautobot.core.api.Api, params: GetLocationParams) -> Dict[str, Any]:
    return get_tools(
        api=api,
        endpoint=api.dcim.locations,
        params=params,
        plain_fields=PLAIN_FIELDS,
        relation_fields=RELATION_FIELDS,
        multi_relation_fields=MULTI_RELATION_FIELDS,
        result_key="locations",
        lookup_fields=['id', 'natural_slug', 'name'],
    )
