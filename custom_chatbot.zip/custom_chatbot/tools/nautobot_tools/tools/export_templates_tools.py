"""
Nautobot Extras export_template helpers for MCP server.

Provides simple CRUD helpers for Nautobot Extras export_templates.
"""
from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

import pynautobot
from pydantic import BaseModel, Field

from .nautobot_fields_actual import EXPORT_TEMPLATES_PLAIN_FIELDS, EXPORT_TEMPLATES_RELATION_FIELDS, EXPORT_TEMPLATES_MULTI_RELATION_FIELDS
from .nautobot_relation_utils import list_tools, count_tools, get_tools

logger = logging.getLogger(__name__)


class ListExportTemplatesParams(BaseModel):
    name: Optional[str] = Field(None, description="Filter by export_template name.")
    query: Optional[str] = Field(None, description="General search query.")
    limit: int = Field(5, description="Maximum number of export_templates to return.")


class GetExportTemplateParams(BaseModel):
    id: Optional[str] = Field(None, description="ExportTemplate ID or UUID.")
    name: Optional[str] = Field(None, description="ExportTemplate name.")


PLAIN_FIELDS: List[str] = EXPORT_TEMPLATES_PLAIN_FIELDS
RELATION_FIELDS: List[str] = EXPORT_TEMPLATES_RELATION_FIELDS
MULTI_RELATION_FIELDS: List[str] = EXPORT_TEMPLATES_MULTI_RELATION_FIELDS


def list_export_templates(api: pynautobot.core.api.Api, params: ListExportTemplatesParams) -> Dict[str, Any]:
    return list_tools(
        api=api,
        endpoint=api.extras.export_templates,
        params=params,
        plain_fields=PLAIN_FIELDS,
        relation_fields=RELATION_FIELDS,
        multi_relation_fields=MULTI_RELATION_FIELDS,
        result_key="export_templates",
        limit=getattr(params, "limit", 5),
    )


def get_export_template(api: pynautobot.core.api.Api, params: GetExportTemplateParams) -> Dict[str, Any]:
    return get_tools(
        api=api,
        endpoint=api.extras.export_templates,
        params=params,
        plain_fields=PLAIN_FIELDS,
        relation_fields=RELATION_FIELDS,
        multi_relation_fields=MULTI_RELATION_FIELDS,
        result_key="export_templates",
        lookup_fields=['id', 'name'],
    )
def count_export_template(api: pynautobot.core.api.Api, params: ListExportTemplatesParams) -> Dict[str, Any]:
    return count_tools(
        endpoint=api.extras.export_templates,
        params=params,
        resource_name="export_templates",
    )
