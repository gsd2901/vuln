"""
device_tools.py
---------------
Tool functions and parameter models for Nautobot device operations.

Provides:
    - ListDevicesParams         — filters for listing/searching devices
    - GetDeviceParams           — lookup params for fetching a single device
    - GetDeviceResponaseParams  — response model returned by get_device()
    - list_devices()            — list devices with optional filters
    - get_device()               — fetch a single device by id / name / serial etc.

Custom fields (odc, last_network_data_sync, last_synced, last_synced_from_sor,
snmp_location, system_of_record, entry_exit_to_data_closet) are:
  * Filterable via cf_<field_name> params on ListDevicesParams.
  * Always included in the "custom_fields" dict of every returned device record.
"""

from __future__ import annotations
from typing import Any, Dict, List, Optional
import pynautobot.core.api
import requests
from bs4 import BeautifulSoup
import logging

from pydantic import BaseModel, Field
from .nautobot_fields_actual import DEVICES_PLAIN_FIELDS, DEVICES_RELATION_FIELDS, DEVICES_MULTI_RELATION_FIELDS
from .nautobot_relation_utils import (
    DEVICE_CUSTOM_FIELD_KEYS,
    get_tools,
    list_tools,
    count_tools,
)
logger = logging.getLogger(__name__)
# ---------------------------------------------------------------------------
# Field declarations — drives both serialisation and API filtering
# ---------------------------------------------------------------------------

PLAIN_FIELDS: List[str] = DEVICES_PLAIN_FIELDS
RELATION_FIELDS: List[str] = DEVICES_RELATION_FIELDS
MULTI_RELATION_FIELDS: List[str] = DEVICES_MULTI_RELATION_FIELDS

EXTENDED_DEVICE_CUSTOM_FIELD_KEYS: List[str] = DEVICE_CUSTOM_FIELD_KEYS + [
    "cdp_neighbors",
    "lldp_neighbors",]
# ---------------------------------------------------------------------------
# Parameter models
# ---------------------------------------------------------------------------

class ListDevicesParams(BaseModel):
    """Parameters for listing / filtering devices."""

    # ── Identity / lookup ──────────────────────────────────────────────────
    id: Optional[str] = Field(None, description="Device primary key / UUID.")
    name: Optional[str] = Field(None, description="Device name.")

    # primary_ip4: Optional[str] = Field(
    #     None,
    # description=(
    #         "Primary IPv4 address with mask e.g. '10.38.154.233/29'. "
    #         "Pass the IP string DIRECTLY — no UUID resolution needed. "
    #         "Use this when the user provides an IP and asks for device details. "
    #         "Do NOT call getIpAddress or getInterface before this."
    #     ))
    # primary_ip6: Optional[str] = Field(None, description="Primary IPv6 address UUID.")
    # tenant: Optional[str] = Field(None, description="Tenant UUID or slug.")
    rack: Optional[str] = Field(None, description="Rack UUID or name.")
    virtual_chassis: Optional[str] = Field(None, description="Virtual chassis UUID or name.")
    tags: Optional[List[str]] = Field(None, description="List of tag slugs/names.")

    # ── Plain fields ────────────────────────────────────────────────────────
    face: Optional[str] = Field(None, description="Rack face (front/rear).")
    serial: Optional[str] = Field(None, description="Device serial number.")
    # asset_tag: Optional[str] = Field(None, description="Asset tag assigned to the device.")
    position: Optional[float] = Field(None, description="Rack unit position of the device.")
    vc_position: Optional[int] = Field(None, description="Virtual chassis position.")
    vc_priority: Optional[int] = Field(None, description="Virtual chassis priority.")
    device_redundancy_group_priority: Optional[int] = Field(
        None, description="Priority within the device redundancy group."
    )
    comments: Optional[str] = Field(None, description="Free-text comments about the device.")
    local_config_context_data: Optional[dict] = Field(
        None, description="Local config context data (inline JSON)."
    )
    local_config_context_data_owner_object_id: Optional[str] = Field(
        None, description="UUID of the owner object for local config context data."
    )
    local_config_context_schema: Optional[str] = Field(
        None, description="Config context schema reference."
    )
    local_config_context_data_owner_content_type: Optional[str] = Field(
        None, description="Content type of the config context data owner."
    )
    cluster: Optional[str] = Field(None, description="Cluster ID this device belongs to.")
    device_redundancy_group: Optional[str] = Field(
        None, description="Device redundancy group ID."
    )
    controller_managed_device_group: Optional[str] = Field(
        None, description="Controller-managed device group ID."
    )
    created: Optional[str] = Field(None, description="Created timestamp (ISO 8601).")
    last_updated: Optional[str] = Field(None, description="Last-updated timestamp (ISO 8601).")
    parent_bay: Optional[str] = Field(None, description="Parent device bay ID.")

    # ── Relation fields ─────────────────────────────────────────────────────
    device_type: Optional[str] = Field(None, description="Device type UUID or slug.")
    status: Optional[str] = Field(None, description="Status UUID or slug.")
    # role: Optional[str] = Field(None, description="Role UUID or slug.")
    platform: Optional[str] = Field(None, description="Platform UUID or slug.")
    location: Optional[str] = Field(None, description="Location UUID or slug.")

    # ── Pagination ──────────────────────────────────────────────────────────
    limit: Optional[int] = Field(5, description="Maximum number of results to return.")

    # ── Custom field filters ─────────────────────────────────────────────────
    # Each cf_* field maps directly to the Nautobot API filter key of the same
    # name, e.g. cf_system_of_record="nautobot" → ?cf_system_of_record=nautobot
    cf_odc: Optional[str] = Field(
        None, description="Filter by custom field: ODC value."
    )
    cf_last_network_data_sync: Optional[str] = Field(
        None, description="Filter by custom field: last network data sync timestamp."
    )
    cf_last_synced: Optional[str] = Field(
        None, description="Filter by custom field: last synced timestamp."
    )
    cf_last_synced_from_sor: Optional[str] = Field(
        None, description="Filter by custom field: last synced from SOR timestamp."
    )
    cf_power_feed_redundancy:  Optional[str] = Field(None, description="Filter by custom field: Power Feed Redundancy.")
    cf_smps_redundancy:  Optional[str] = Field(None, description="Filter by custom field: SMPS Redundancy.")
    cf_snmp_location: Optional[str] = Field(
        None, description="Filter by custom field: SNMP location string."
    )
    cf_system_of_record: Optional[str] = Field(
        None, description="Filter by custom field: system of record (e.g. 'Nautobot')."
    )
    cf_entry_exit_to_data_closet: Optional[str] = Field(
        None, description="Filter by custom field: entry/exit to data closet."
    )


class GetDeviceParams(BaseModel):
    """Parameters for fetching a single device."""

    id: Optional[str] = Field(None, description="Device UUID — fastest, unambiguous lookup.")
    name: Optional[str] = Field(None, description="Device name (case-insensitive match).")
    # primary_ip4: Optional[str] = Field(
    #     None,
    # description=(
    #         "Primary IPv4 address with mask e.g. '10.38.154.233/29'. "
    #         "Pass the IP string DIRECTLY — no UUID resolution needed. "
    #         "Use this when the user provides an IP and asks for device details. "
    #         "Do NOT call getIpAddress or getInterface before this."
    #     ))
    # primary_ip6: Optional[str] = Field(None, description="Primary IPv6 address UUID.")
    # tenant: Optional[str] = Field(None, description="Tenant UUID or slug.")
    rack: Optional[str] = Field(None, description="Rack UUID or name.")
    virtual_chassis: Optional[str] = Field(None, description="Virtual chassis UUID or name.")
    tags: Optional[List[str]] = Field(None, description="List of tag slugs/names.")
      # ── Plain fields ────────────────────────────────────────────────────────
    face: Optional[str] = Field(None, description="Rack face (front/rear).")
    serial: Optional[str] = Field(None, description="Device serial number.")
    # asset_tag: Optional[str] = Field(None, description="Asset tag assigned to the device.")
    position: Optional[float] = Field(None, description="Rack unit position of the device.")
    vc_position: Optional[int] = Field(None, description="Virtual chassis position.")
    vc_priority: Optional[int] = Field(None, description="Virtual chassis priority.")
    device_redundancy_group_priority: Optional[int] = Field(
        None, description="Priority within the device redundancy group."
    )
    comments: Optional[str] = Field(None, description="Free-text comments about the device.")
    local_config_context_data: Optional[dict] = Field(
        None, description="Local config context data (inline JSON)."
    )
    local_config_context_data_owner_object_id: Optional[str] = Field(
        None, description="UUID of the owner object for local config context data."
    )
    local_config_context_schema: Optional[str] = Field(
        None, description="Config context schema reference."
    )
    local_config_context_data_owner_content_type: Optional[str] = Field(
        None, description="Content type of the config context data owner."
    )
    cluster: Optional[str] = Field(None, description="Cluster ID this device belongs to.")
    device_redundancy_group: Optional[str] = Field(
        None, description="Device redundancy group ID."
    )
    controller_managed_device_group: Optional[str] = Field(
        None, description="Controller-managed device group ID."
    )
    created: Optional[str] = Field(None, description="Created timestamp (ISO 8601).")
    last_updated: Optional[str] = Field(None, description="Last-updated timestamp (ISO 8601).")
    parent_bay: Optional[str] = Field(None, description="Parent device bay ID.")

    # ── Relation fields ─────────────────────────────────────────────────────
    device_type: Optional[str] = Field(None, description="Device type UUID or slug.")
    status: Optional[str] = Field(None, description="Status UUID or slug.")
    # role: Optional[str] = Field(None, description="Role UUID or slug.")
    platform: Optional[str] = Field(None, description="Platform UUID or slug.")
    location: Optional[str] = Field(None, description="Location UUID or slug.")

    # ── Pagination ──────────────────────────────────────────────────────────
    limit: Optional[int] = Field(5, description="Maximum number of results to return.")

    # ── Custom field filters ─────────────────────────────────────────────────
    # Each cf_* field maps directly to the Nautobot API filter key of the same
    # name, e.g. cf_system_of_record="nautobot" → ?cf_system_of_record=nautobot
    cf_odc: Optional[str] = Field(
        None, description="Filter by custom field: ODC value.")
    cf_power_feed_redundancy: Optional[str]  = Field(None, description="Filter by custom field: Power Feed Redundancy.")
    cf_smps_redundancy: Optional[str]  = Field(None, description="Filter by custom field: SMPS Redundancy.")
    cf_last_network_data_sync: Optional[str] = Field(
        None, description="Filter by custom field: last network data sync timestamp."
    )
    cf_last_synced: Optional[str] = Field(
        None, description="Filter by custom field: last synced timestamp."
    )
    cf_last_synced_from_sor: Optional[str] = Field(
        None, description="Filter by custom field: last synced from SOR timestamp."
    )
    cf_snmp_location: Optional[str] = Field(
        None, description="Filter by custom field: SNMP location string."
    )
    cf_system_role: Optional[str]  = Field(None, description="Filter by custom field- System Role.")
    cf_system_of_record: Optional[str] = Field(
        None, description="Filter by custom field: system of record (e.g. 'Nautobot')."
    )
    cf_entry_exit_to_data_closet: Optional[str] = Field(
        None, description="Filter by custom field: entry/exit to data closet."
    )


# ---------------------------------------------------------------------------
# Response model
# ---------------------------------------------------------------------------

class GetDeviceResponaseParams(BaseModel):
    """
    Response model returned by get_device().

    The fields below marked REQUIRED are guaranteed to always be present
    (verbatim) in the response — this is the defense-in-depth contract for
    the mandatory custom fields (ODC, Last Network Data Sync, Last Synced,Last sync from SOR(Sytem Of Record),
    System Role,SNMP Location,System of Record, smps redundancy,power feed redundancy, Entry/Exit to Data Closet) plus the core identity / network
    / redundancy fields the agent must never drop or summarize away.

    All other fields are optional context and may be None if Nautobot did
    not return a value for them.
    """

    # ── REQUIRED — core identity / relation / network fields ───────────────
    id: str = Field(..., description="Device primary key / UUID.")
    name: str = Field(..., description="Device name.")
    serial: str = Field(..., description="Device serial number.")
    # asset_tag: str = Field(..., description="Asset tag assigned to the device.")
    position: str = Field(..., description="Rack unit position of the device.")
    device_type: str = Field(..., description="Device type UUID, slug, or display name.")
    status: str = Field(..., description="Status UUID, slug, or display name.")
    # role: str = Field(..., description="Role UUID, slug, or display name.")
    tenant: str = Field(..., description="Tenant UUID, slug, or display name.")
    platform: str = Field(..., description="Platform UUID, slug, or display name.")
    location: str = Field(..., description="Location UUID, slug, or display name.")
    rack: str = Field(..., description="Rack UUID, slug, or display name.")
    primary_ip4: str = Field(..., description="Primary IPv4 address.")
    primary_ip6: str = Field(..., description="Primary IPv6 address.")
    virtual_chassis: str = Field(..., description="Virtual chassis UUID or name.")

    # ── REQUIRED — mandatory custom fields ──────────────────────────────────
    cf_odc: str = Field(..., description="Filter by custom field: ODC value")
    cf_last_network_data_sync: str = Field(..., description="Custom Field - Last Network Data Sync.")
    cf_last_synced: str = Field(..., description="Custom Field - Last Synced.")
    cf_last_synced_from_sor: str = Field(..., description="Custom Field - Last Synced From SOR.")
    cf_system_role: str = Field(..., description="Custom Field - System Role.")
    cf_snmp_location: str = Field(..., description="Custom Field - SNMP Location.")
    cf_system_of_record: str = Field(..., description="Custom Field - System of Record.")
    cf_entry_exit_to_data_closet: str = Field(..., description="Custom Field - Entry/Exit to Data Closet.")
    cf_smps_redundancy: str = Field(..., description="Custom Field - SMPS Redundancy.")
    cf_power_feed_redundancy: str = Field(..., description="Custom Field - Power Feed Redundancy.")

    # ── Optional — remaining plain fields ───────────────────────────────────
    face: Optional[str] = Field(None, description="Rack face (front/rear).")
    vc_position: Optional[int] = Field(None, description="Virtual chassis position.")
    vc_priority: Optional[int] = Field(None, description="Virtual chassis priority.")
    device_redundancy_group_priority: Optional[int] = Field(
        None, description="Priority within the device redundancy group."
    )
    comments: Optional[str] = Field(None, description="Free-text comments about the device.")
    cluster: Optional[str] = Field(None, description="Cluster ID this device belongs to.")
    device_redundancy_group: Optional[str] = Field(None, description="Device redundancy group ID.")
    controller_managed_device_group: Optional[str] = Field(
        None, description="Controller-managed device group ID."
    )
    created: Optional[str] = Field(None, description="Created timestamp (ISO 8601).")
    last_updated: Optional[str] = Field(None, description="Last-updated timestamp (ISO 8601).")
    parent_bay: Optional[str] = Field(None, description="Parent device bay ID.")
    tags: Optional[List[str]] = Field(None, description="List of tag slugs/names.")

    # ── Optional — full custom_fields passthrough & derived neighbour data ─
    # custom_fields: Optional[Dict[str, Any]] = Field(
    #     None, description="Full raw custom_fields dict as returned by Nautobot."
    # )
    cdp_neighbor_names: Optional[List[str]] = Field(
        None, description="Deduplicated list of CDP neighbour device names."
    )
    lldp_neighbor_names: Optional[List[str]] = Field(
        None, description="Deduplicated list of LLDP neighbour device names."
    )


# ---------------------------------------------------------------------------
# Neighbour extraction helper  (additive — does not touch any existing code)
# ---------------------------------------------------------------------------

def _extract_neighbour_names(device_record: Dict[str, Any]) -> None:
    """
    Inject deduplicated CDP and LLDP neighbour device-name lists into a
    device record dict in-place.

    Reads  custom_fields["cdp_neighbors"]  and
           custom_fields["lldp_neighbors"]
    — each a list of dicts that may contain a "neighbor_name" key —
    and adds two new top-level keys:

        cdp_neighbor_names  : List[str]   (deduplicated, order-preserving)
        lldp_neighbor_names : List[str]   (deduplicated, order-preserving)

    None / empty / missing neighbor_name values are silently skipped.
    Safe to call on any dict; does nothing if custom_fields is absent.
    """
    custom_fields: Dict[str, Any] = device_record.get("custom_fields") or {}

    def _unique_names(neighbour_list: Any) -> List[str]:
        """Return a deduplicated, order-preserving list of non-empty neighbor_name values."""
        if not isinstance(neighbour_list, list):
            return []
        seen: set = set()
        names: List[str] = []
        for entry in neighbour_list:
            if not isinstance(entry, dict):
                continue
            name = entry.get("neighbor_name")
            if name and name not in seen:
                seen.add(name)
                names.append(name)
        return names

    device_record["cdp_neighbor_names"] = _unique_names(
        custom_fields.get("cdp_neighbors")
    )
    device_record["lldp_neighbor_names"] = _unique_names(
        custom_fields.get("lldp_neighbors")
    )
    logger.info(
        "_extract_neighbour_names: cdp=%s lldp=%s",
        device_record["cdp_neighbor_names"],
        device_record["lldp_neighbor_names"],
    )


# ---------------------------------------------------------------------------
# Response-building helper
# ---------------------------------------------------------------------------

_REQUIRED_STR_DEFAULT = "N/A"


def _flatten_value(value: Any) -> Any:
    """
    Flatten pynautobot/Nautobot "choice field" dicts (e.g.
    {'value': 'front', 'label': 'Front'}) down to their human-readable
    'label' (falling back to 'value'), so downstream string coercion never
    blows up on a dict. Leaves all other value types untouched.
    """
    if isinstance(value, dict):
        if "label" in value and value.get("label") not in (None, ""):
            return value.get("label")
        if "value" in value:
            return value.get("value")
    return value


def _coerce_required_str(value: Any) -> str:
    """
    Coerce any value into a non-empty string suitable for a REQUIRED field.

    Nautobot fields are frequently missing / None for a given device (e.g. no
    rack assigned, no primary IP), and some fields (e.g. 'face') come back as
    choice dicts like {'value': 'front', 'label': 'Front'} rather than plain
    strings. Since GetDeviceResponaseParams declares these fields as required
    (defense-in-depth so they can never be silently dropped from the
    response), values are flattened/coerced rather than allowed to raise a
    validation error.
    """
    value = _flatten_value(value)
    if value is None or value == "":
        return _REQUIRED_STR_DEFAULT
    if isinstance(value, (dict, list)):
        return str(value)
    return str(value)


def _coerce_optional_str(value: Any) -> Optional[str]:
    """Same flattening as _coerce_required_str, but preserves None for optional fields."""
    value = _flatten_value(value)
    if value is None:
        return None
    if isinstance(value, (dict, list)):
        return str(value)
    return str(value)


def _build_get_device_response(device_record: Dict[str, Any]) -> GetDeviceResponaseParams:
    """
    Build a GetDeviceResponaseParams instance from a raw device record dict
    (as produced by get_tools() + _extract_neighbour_names()).

    Pulls the mandatory custom fields out of custom_fields explicitly so
    they are always present at the top level of the response, in addition
    to being retained in the raw `custom_fields` passthrough dict.
    """
    custom_fields: Dict[str, Any] = device_record.get("custom_fields") or {}

    return GetDeviceResponaseParams(
        # ── required core fields ────────────────────────────────────────
        id=_coerce_required_str(device_record.get("id")),
        name=_coerce_required_str(device_record.get("name")),
        serial=_coerce_required_str(device_record.get("serial")),
        # asset_tag=_coerce_required_str(device_record.get("asset_tag")),
        position=_coerce_required_str(device_record.get("position")),
        device_type=_coerce_required_str(device_record.get("device_type")),
        status=_coerce_required_str(device_record.get("status")),
        # role=_coerce_required_str(device_record.get("role")),
        tenant=_coerce_required_str(device_record.get("tenant")),
        platform=_coerce_required_str(device_record.get("platform")),
        location=_coerce_required_str(device_record.get("location")),
        rack=_coerce_required_str(device_record.get("rack")),
        primary_ip4=_coerce_required_str(device_record.get("primary_ip4")),
        primary_ip6=_coerce_required_str(device_record.get("primary_ip6")),
        virtual_chassis=_coerce_required_str(device_record.get("virtual_chassis")),

        # ── required mandatory custom fields ────────────────────────────
        cf_odc=_coerce_required_str(custom_fields.get("odc")),
        cf_last_network_data_sync=_coerce_required_str(custom_fields.get("last_network_data_sync")),
        cf_last_synced=_coerce_required_str(custom_fields.get("last_synced")),
        cf_last_synced_from_sor=_coerce_required_str(custom_fields.get("last_synced_from_sor")),
        cf_system_role=_coerce_required_str(custom_fields.get("system_role")),
        cf_snmp_location=_coerce_required_str(custom_fields.get("snmp_location")),
        cf_system_of_record=_coerce_required_str(custom_fields.get("system_of_record")),
        cf_entry_exit_to_data_closet=_coerce_required_str(custom_fields.get("entry_exit_to_data_closet")),
        cf_smps_redundancy=_coerce_required_str(custom_fields.get("smps_redundancy")),
        cf_power_feed_redundancy=_coerce_required_str(custom_fields.get("power_feed_redundancy")),

        # ── optional fields ──────────────────────────────────────────────
        face=_coerce_optional_str(device_record.get("face")),
        vc_position=device_record.get("vc_position"),
        vc_priority=device_record.get("vc_priority"),
        device_redundancy_group_priority=device_record.get("device_redundancy_group_priority"),
        comments=_coerce_optional_str(device_record.get("comments")),
        cluster=_coerce_optional_str(device_record.get("cluster")),
        device_redundancy_group=_coerce_optional_str(device_record.get("device_redundancy_group")),
        controller_managed_device_group=_coerce_optional_str(
            device_record.get("controller_managed_device_group")
        ),
        created=_coerce_optional_str(device_record.get("created")),
        last_updated=_coerce_optional_str(device_record.get("last_updated")),
        parent_bay=_coerce_optional_str(device_record.get("parent_bay")),
        tags=device_record.get("tags"),
        custom_fields=custom_fields,
        cdp_neighbor_names=device_record.get("cdp_neighbor_names"),
        lldp_neighbor_names=device_record.get("lldp_neighbor_names"),
    )


# ---------------------------------------------------------------------------
# Tool functions
# ---------------------------------------------------------------------------

def list_devices(
    api: pynautobot.core.api.Api,
    params: ListDevicesParams,
    # ) -> Dict[str, Any]:
) -> GetDeviceResponaseParams:

    result= list_tools(
        api=api,
        endpoint=api.dcim.devices,
        params=params,
        plain_fields=DEVICES_PLAIN_FIELDS,
        relation_fields=DEVICES_RELATION_FIELDS,
        multi_relation_fields=DEVICES_MULTI_RELATION_FIELDS,
        result_key="devices",
        limit=params.limit or 5,
        custom_field_keys=EXTENDED_DEVICE_CUSTOM_FIELD_KEYS,
    )

      # Inject neighbour name lists into every returned device record.
    for device_record in result.get("devices") or []:
        _extract_neighbour_names(device_record)

    return result


def get_device(
    api: pynautobot.core.api.Api,
    params: GetDeviceParams,
) -> GetDeviceResponaseParams:
    """
    Fetch a single device from Nautobot by id, name, serial.

    IMPORTANT FOR AGENT: Whenever this tool is called — even as part of a
    multi-tool turn alongside other tools — the final response to the user
    MUST always include these custom field values verbatim, never omitted
    or summarized away:
      - Custom Field - Impact ODC                 (cf_odc)
      - Custom Field - Last Network Data Sync     (cf_last_network_data_sync)
      - Custom Field - Last Synced                 (cf_last_synced)
      - Custom Field - smps redundancy             (cf_smps_redundancy)
      - Custom Field - Power Feed Redundancy       (cf_power_feed_redundancy)
      - Custom Field - SNMP Location               (cf_snmp_location)
      - Custom Field - System Role                 (cf_system_role)
      - Custom Field - System of Record            (cf_system_of_record)
      - Custom Field - Entry/Exit to Data Closet    (cf_entry_exit_to_data_closet)
      - Custom Field - Last sync from System of Record    (cf_last_synced_from_sor)

    Do not drop these fields even if the user's question seems focused on
    something else (e.g. interfaces, IPs, rack space) — they must always be
    reported alongside any other requested information when get_device is
    in the tool-call chain for this turn.

    Returns a GetDeviceResponaseParams instance. The core identity fields,
    network fields, redundancy fields, and the mandatory custom fields are
    declared REQUIRED on that model (defense-in-depth), so they are always
    present in the structured response — even when Nautobot itself has no
    value for a given field (in which case a sentinel "N/A" string is used).
    """

    result = get_tools(
        api=api,
        endpoint=api.dcim.devices,
        params=params,
        plain_fields=PLAIN_FIELDS,
        relation_fields=RELATION_FIELDS,
        multi_relation_fields=MULTI_RELATION_FIELDS,
        result_key="device",
        lookup_fields=["id", "name", "serial"],
        name_field="name",
        custom_field_keys=EXTENDED_DEVICE_CUSTOM_FIELD_KEYS,
    )

    device_record = result.get("device") or {}

    # Inject neighbour name lists into the returned device record.
    if device_record:
        _extract_neighbour_names(device_record)

    return _build_get_device_response(device_record)


def count_devices(api: pynautobot.core.api.Api, params: ListDevicesParams) -> Dict[str, Any]:
    """
    Return the total count of devices in Nautobot matching the given filters.

Accepts the same filter parameters as list_devices:
  - Identity:     id, name
  - Physical:     serial, face (front/rear), position (rack unit),
                  vc_position, vc_priority, device_redundancy_group_priority
  - Network:      primary_ip4 (e.g. '10.38.154.233/29'), primary_ip6
  - Relational:   device_type, status, platform, location, cluster,
                  device_redundancy_group, controller_managed_device_group,
                  parent_bay, tenant, rack, virtual_chassis
  - Tags:         tags (list of tag slugs/names)
  - Timestamps:   created, last_updated
  - Custom fields (cf_*):
                  cf_odc, cf_last_network_data_sync, cf_last_synced,
                  cf_last_synced_from_sor, cf_snmp_location,
                  cf_system_of_record, cf_entry_exit_to_data_closet

When filtering by IP address, pass the IP string directly to primary_ip4
(e.g. '10.38.154.233/29') — no UUID resolution or prior tool calls needed.

Returns a single integer representing the number of matching devices.
Useful for dashboards, audits, or pre-checks before running list_devices.
    """
    return count_tools(
        endpoint=api.dcim.devices,
        params=params,
        resource_name="devices",
    )
