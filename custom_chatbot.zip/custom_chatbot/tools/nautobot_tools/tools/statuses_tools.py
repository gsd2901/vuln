"""
Nautobot Extras status helpers for MCP server.

Provides simple CRUD helpers for Nautobot Extras statuses.
"""
from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

import pynautobot
from pydantic import BaseModel, Field

from .nautobot_fields_actual import STATUSES_PLAIN_FIELDS, STATUSES_RELATION_FIELDS, STATUSES_MULTI_RELATION_FIELDS
from .nautobot_relation_utils import list_tools, count_tools, get_tools

logger = logging.getLogger(__name__)


class ListStatussParams(BaseModel):
    name: Optional[str] = Field(None, description="Filter by status name.")
    query: Optional[str] = Field(None, description="General search query.")
    limit: int = Field(5, description="Maximum number of statuses to return.")


class GetStatusParams(BaseModel):
    id: Optional[str] = Field(None, description="Status ID or UUID.")
    name: Optional[str] = Field(None, description="Status name.")


PLAIN_FIELDS: List[str] = STATUSES_PLAIN_FIELDS
RELATION_FIELDS: List[str] = STATUSES_RELATION_FIELDS
MULTI_RELATION_FIELDS: List[str] = STATUSES_MULTI_RELATION_FIELDS


def list_statuses(api: pynautobot.core.api.Api, params: ListStatussParams) -> Dict[str, Any]:
    return list_tools(
        api=api,
        endpoint=api.extras.statuses,
        params=params,
        plain_fields=PLAIN_FIELDS,
        relation_fields=RELATION_FIELDS,
        multi_relation_fields=MULTI_RELATION_FIELDS,
        result_key="statuses",
        limit=getattr(params, "limit", 5),
    )


def get_status(api: pynautobot.core.api.Api, params: GetStatusParams) -> Dict[str, Any]:
    return get_tools(
        api=api,
        endpoint=api.extras.statuses,
        params=params,
        plain_fields=PLAIN_FIELDS,
        relation_fields=RELATION_FIELDS,
        multi_relation_fields=MULTI_RELATION_FIELDS,
        result_key="statuses",
        lookup_fields=['id', 'name'],
    )
def count_status(api: pynautobot.core.api.Api, params: ListStatussParams) -> Dict[str, Any]:
    return count_tools(
        endpoint=api.extras.statuses,
        params=params,
        resource_name="statuses",
    )