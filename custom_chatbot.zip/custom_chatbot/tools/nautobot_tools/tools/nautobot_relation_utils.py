"""
nautobot_relation_utils_parallel.py
-----------------------------------
Parallel list helper variant for higher-throughput record serialization.

This module keeps the same public helper signatures as nautobot_relation_utils,
with an additional parallelized list_tools implementation.

Key change vs original:
  list_tools now uses _raw_filter() instead of endpoint.filter() + endpoint.count().
  pynautobot's .filter() silently paginates ALL records before returning, even when
  you only need `limit` rows. _raw_filter() calls api.http_session.get() directly,
  fetching exactly one page and getting count from the same response — eliminating
  the ~75 s fetch penalty observed in production.

  get_tools() now supports AMBIGUOUS lookups: for lookup fields that are not
  guaranteed unique (e.g. "address", which can legitimately exist in multiple
  namespaces such as Coimbatore and Madurai), it fetches and serializes ALL
  matching records instead of silently returning only the first one. When more
  than one record matches, result[result_key] is a LIST of serialized records
  and result["count"] reflects how many were returned. Unique lookups (id,
  natural_slug) and name-field lookups still resolve to a single record as
  before.

Everything else (get_tools, count_tools, device_to_dict, caching, serialization)
is otherwise unchanged; all call-sites remain compatible — result[result_key]
is a dict when the lookup was unambiguous, or a list of dicts when multiple
records matched.
"""

import logging
import os
import threading
from concurrent.futures import ThreadPoolExecutor
from time import perf_counter
from typing import Any, Dict, List, Optional

import pynautobot
import pynautobot.core.api
import requests
from pydantic import BaseModel

_DEFAULT_LIST_LIMIT = 5
_DEFAULT_MAX_WORKERS = 8
_DEFAULT_LIST_LIMIT = 5
FILTER_MAP: Dict[str, str] = {"query": "q",}      # Nautobot uses 'q' for free-text search

DEVICE_CUSTOM_FIELD_KEYS: List[str] = [
    "odc",
    "last_network_data_sync",
    "last_synced",
    "last_synced_from_sor",
    "snmp_location",
    "power_feed_redundancy",
    "smps_redundancy",
    "system_role",
    "system_of_record",
    "entry_exit_to_data_closet",
]

# Thread-safe cache for relation resolution.
_relation_cache: dict[str, Optional[str]] = {}
_cache_lock = threading.Lock()

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Raw one-page fetch — the core fix
# ---------------------------------------------------------------------------

def _get_token(api: pynautobot.core.api.Api) -> Optional[str]:
    """
    Extract the auth token from a pynautobot Api object.

    pynautobot stores the token under different private attributes depending
    on the version. We try every known location before falling back to the
    NAUTOBOT_TOKEN env var.
    """
    logger.info("_get_token: attempting to extract auth token from api object")

    for attr in ("token", "_token", "api_token"):
        val = getattr(api, attr, None)
        if isinstance(val, str) and val:
            logger.info("_get_token: token found via attribute '%s'", attr)
            return val

    # Some versions store it inside the http_session headers
    session = getattr(api, "http_session", None)
    if session is not None:
        logger.info("_get_token: checking http_session Authorization header")
        auth_header = (getattr(session, "headers", None) or {}).get("Authorization", "")
        if auth_header.startswith("Token "):
            logger.info("_get_token: token found in http_session Authorization header")
            return auth_header[6:]

    logger.info("_get_token: falling back to NAUTOBOT_TOKEN env var")
    return os.getenv("NAUTOBOT_TOKEN")


def _raw_filter(
    api: pynautobot.core.api.Api,
    endpoint: Any,
    limit: int,
    filters: Dict[str, Any],
) -> tuple[list[dict], int]:
    """
    Fetch exactly `limit` records with an explicit Token auth header.

    Bypasses pynautobot's .filter() pagination loop so we never retrieve more
    records than requested. Uses requests directly so the Authorization header
    is always present regardless of how pynautobot configured its session.

    Returns:
        (results, count)  where results is a list of raw dicts and count is
        the total number of matching records reported by the API.
    """
    logger.info("_raw_filter: starting with limit=%d filters=%s", limit, filters)

    token = _get_token(api)
    if not token:
        logger.info("_raw_filter: token resolution failed, raising ValueError")
        raise ValueError(
            "Cannot resolve Nautobot API token from the api object or NAUTOBOT_TOKEN env var."
        )

    # endpoint.url is e.g. "/api/dcim/devices/"
    url = f"{endpoint.url}/"
    logger.info("_raw_filter: resolved url=%s", url)

    logger.info("_raw_filter: sending GET request with params limit=%d offset=0 filters=%s", limit, filters)
    resp = requests.get(
        url,
        headers={
            "Authorization": f"Token {token}",
            "Content-Type": "application/json",
        },
        params={"limit": limit, "offset": 0, **filters},
        timeout=30,
        # Bypass any HTTP_PROXY/HTTPS_PROXY env vars for local Nautobot.
        # requests does NOT honour no_proxy automatically in all versions,
        # so we explicitly set empty proxies to force a direct connection.
        proxies={"http": "", "https": ""},
    )
    logger.info("_raw_filter: received response status=%d", resp.status_code)
    resp.raise_for_status()

    data = resp.json()
    results = data.get("results", [])
    count = data.get("count", 0)
    logger.info("_raw_filter: parsed response results_count=%d total_count=%d", len(results), count)

    return results, count


# ---------------------------------------------------------------------------
# Relation helpers (unchanged)
# ---------------------------------------------------------------------------

def relation_name(rel: Any) -> Optional[str]:
    """Extract a human-readable name from a pynautobot relation object or dict."""
    logger.info("relation_name: resolving name for rel type=%s", type(rel).__name__)

    if rel is None:
        logger.info("relation_name: rel is None, returning None")
        return None

    for attr in ("display", "name", "slug", "label"):
        v = getattr(rel, attr, None)
        if isinstance(v, str) and v:
            logger.info("relation_name: found name via attribute '%s' value='%s'", attr, v)
            return v

    if isinstance(rel, dict):
        for k in ("display", "name", "slug", "label"):
            v = rel.get(k)
            if isinstance(v, str) and v:
                logger.info("relation_name: found name via dict key '%s' value='%s'", k, v)
                return v

    logger.info("relation_name: could not resolve name, returning None")
    return None


def get_cache_key(rel: Any) -> Optional[str]:
    """Return a stable unique key for a relation object (url preferred over id)."""
    logger.info("get_cache_key: computing cache key for rel type=%s", type(rel).__name__)

    if isinstance(rel, dict):
        key = rel.get("url") or (str(rel["id"]) if rel.get("id") else None)
        logger.info("get_cache_key: dict path resolved key=%s", key)
        return key

    url = getattr(rel, "url", None)
    obj_id = getattr(rel, "id", None)
    key = url or (str(obj_id) if obj_id else None)
    logger.info("get_cache_key: object path resolved key=%s", key)
    return key


def resolve_relation_name(api: pynautobot.core.api.Api, rel: Any) -> Optional[str]:
    """Resolve relation display/name with thread-safe cache + HTTP fallback."""
    logger.info("resolve_relation_name: resolving rel type=%s", type(rel).__name__)

    direct = relation_name(rel)
    if direct:
        logger.info("resolve_relation_name: resolved directly without cache/HTTP value='%s'", direct)
        return direct

    cache_key = get_cache_key(rel)
    if cache_key:
        with _cache_lock:
            if cache_key in _relation_cache:
                cached_val = _relation_cache[cache_key]
                logger.info("resolve_relation_name: cache hit key='%s' value='%s'", cache_key, cached_val)
                return cached_val

    logger.info("resolve_relation_name: cache miss for key='%s', attempting HTTP fallback", cache_key)

    result: Optional[str] = None
    try:
        url = rel.get("url") if isinstance(rel, dict) else getattr(rel, "url", None)
        if url:
            logger.info("resolve_relation_name: fetching url='%s'", url)
            token = (
                getattr(api, "token", None)
                or getattr(api, "_token", None)
                or os.getenv("NAUTOBOT_TOKEN")
            )
            headers = {"Authorization": f"Token {token}"} if token else {}
            resp = requests.get(url, headers=headers, timeout=5)
            logger.info("resolve_relation_name: HTTP response status=%d", resp.status_code)
            if resp.ok:
                result = relation_name(resp.json())
                logger.info("resolve_relation_name: HTTP fallback resolved value='%s'", result)
    except Exception:
        logger.info("resolve_relation_name: HTTP fallback raised an exception, result remains None")

    if cache_key:
        with _cache_lock:
            _relation_cache[cache_key] = result
            logger.info("resolve_relation_name: stored in cache key='%s' value='%s'", cache_key, result)

    return result


# ---------------------------------------------------------------------------
# Serialization (updated to handle both raw dicts and pynautobot Record objects)
# ---------------------------------------------------------------------------

def _get_field(obj: Any, field: str) -> Any:
    """Get a field from either a plain dict or a pynautobot Record object."""
    logger.info("_get_field: accessing field='%s' on obj type=%s", field, type(obj).__name__)

    if isinstance(obj, dict):
        val = obj.get(field)
        logger.info("_get_field: dict path field='%s' value=%s", field, val)
        return val

    val = getattr(obj, field, None)
    logger.info("_get_field: getattr path field='%s' value=%s", field, val)
    return val


def device_to_dict(
    api: pynautobot.core.api.Api,
    dev: Any,
    plain_fields: List[str],
    relation_fields: List[str],
    multi_relation_fields: Optional[List[str]] = None,
    custom_field_keys: Optional[List[str]] = None,
) -> Dict[str, Any]:
    """
    Serialize one record using plain/relation/multi-relation field groups.

    Accepts both raw dicts (from _raw_filter) and pynautobot Record objects
    (from get_tools / _lookup_by_name) via _get_field().
    """
    logger.info(
        "device_to_dict: serializing dev type=%s plain_fields=%s relation_fields=%s multi_relation_fields=%s",
        type(dev).__name__, plain_fields, relation_fields, multi_relation_fields,
    )

    result: Dict[str, Any] = {f: _get_field(dev, f) for f in plain_fields}
    logger.info("device_to_dict: plain fields resolved result=%s", result)

    for f in relation_fields:
        logger.info("device_to_dict: resolving relation field='%s'", f)
        result[f] = resolve_relation_name(api, _get_field(dev, f))
        logger.info("device_to_dict: relation field='%s' resolved to '%s'", f, result[f])

    # for f in multi_relation_fields or []:
    #     raw = _get_field(dev, f) or []
    #     result[f] = [
    #         name
    #         for item in raw
    #         if (name := relation_name(item) or resolve_relation_name(api, item)) is not None
    #     ]
    for f in multi_relation_fields or []:
        logger.info("device_to_dict: processing multi_relation field='%s'", f)
        raw = _get_field(dev, f) or []
        logger.info("device_to_dict: multi_relation field='%s' raw item count=%d", f, len(raw))

        if f == "interfaces":
            logger.info("device_to_dict: field='interfaces' using enriched serialization")
            # Return rich objects instead of bare name strings
            enriched = []
            for item in raw:
                iface_id = (
                    item.get("id") if isinstance(item, dict)
                    else getattr(item, "id", None)
                )
                iface_name = relation_name(item) or resolve_relation_name(api, item)
                # Hop 1: fetch full interface to get device stub (stub has no "device" key)
                device_rel = item.get("device") if isinstance(item, dict) else getattr(item, "device", None)
                if device_rel is None:
                    iface_url = item.get("url") if isinstance(item, dict) else getattr(item, "url", None)
                    if iface_url:
                        try:
                            token = _get_token(api)
                            resp = requests.get(iface_url, headers={"Authorization": f"Token {token}"}, proxies={"http": "", "https": ""}, timeout=10)
                            if resp.ok:
                                device_rel = resp.json().get("device")
                        except Exception:
                            pass

                # Hop 2: resolve_relation_name already handles url-fetch + display/name extraction
                device_name = resolve_relation_name(api, device_rel) if device_rel else None
                logger.info(
                    "device_to_dict: interface item iface_id=%s iface_name=%s device_name=%s",
                    iface_id, iface_name, device_name,
                )
                enriched.append({
                    "id": iface_id,
                    "name": iface_name,
                    "device": device_name,
                })
            result[f] = enriched
            logger.info("device_to_dict: interfaces enriched count=%d", len(enriched))

        else:
            result[f] = [
                name
                for item in raw
                if (name := relation_name(item) or resolve_relation_name(api, item)) is not None
            ]
            logger.info("device_to_dict: multi_relation field='%s' resolved names=%s", f, result[f])

    cf_keys = custom_field_keys if custom_field_keys is not None else DEVICE_CUSTOM_FIELD_KEYS
    # NOTE: previously this call passed an extra positional arg
    #   logger.info("device_to_dict: using custom_field_keys=%s", cf_keys, f"dev:,{dev}")
    # which mismatched the single "%s" placeholder and threw a logging
    # "not all arguments converted during string formatting" error on every
    # call. Fixed to only log what the format string expects.
    logger.info("device_to_dict: using custom_field_keys=%s", cf_keys)

    # raw_cf = getattr(dev, "custom_fields", None) or {}
    raw_cf = _get_field(dev, "custom_fields") or {}
    logger.info("device_to_dict: raw_cf type=%s", type(raw_cf).__name__)

    # if isinstance(raw_cf, list):
    #     # Raw dict path: custom_fields as [{"key": ..., "value": ...}, ...]
    #     raw_cf = {item["key"]: item["value"] for item in raw_cf}
    if not isinstance(raw_cf, dict):
    # elif not isinstance(raw_cf, dict):
        # pynautobot Record path: custom_fields is a special object, not a plain dict
        logger.info("device_to_dict: raw_cf is not dict, converting via dict()")
        raw_cf = dict(raw_cf) if raw_cf else {}

    result["custom_fields"] = {key: raw_cf.get(key) for key in cf_keys}
    logger.info("device_to_dict: custom_fields resolved=%s", result["custom_fields"])
    logger.info("device_to_dict: serialization complete for dev type=%s", type(dev).__name__)

    return result


# ---------------------------------------------------------------------------
# list_tools — parallelized + raw-filter
# ---------------------------------------------------------------------------

def list_tools(
    api: pynautobot.core.api.Api,
    endpoint: Any,
    params: BaseModel,
    plain_fields: List[str],
    relation_fields: List[str],
    result_key: str,
    filter_map: Optional[Dict[str, str]] = None,
    exclude_fields: Optional[List[str]] = None,
    multi_relation_fields: Optional[List[str]] = None,
    custom_field_keys: Optional[List[str]] = None,
    limit: int = _DEFAULT_LIST_LIMIT,
    max_workers: int = _DEFAULT_MAX_WORKERS,
) -> Dict[str, Any]:
    """
    Parallelized list helper with single-page raw HTTP fetch.

    Changes vs original:
    - Replaces endpoint.filter() + endpoint.count() + islice() with a single
      _raw_filter() call that fetches exactly `limit` rows and the total count
      in one HTTP round trip.
    - filter and count are no longer sequential — count comes free from the
      same response body.
    - Serialization is still parallelized with ThreadPoolExecutor.
    - All other call-site arguments are identical; this is a drop-in replacement.
    """
    logger.info(
        "list_tools: starting result_key='%s' limit=%d max_workers=%d plain_fields=%s relation_fields=%s",
        result_key, limit, max_workers, plain_fields, relation_fields,
    )

    if filter_map is None:
        filter_map = FILTER_MAP
        logger.info("list_tools: filter_map not provided, using default FILTER_MAP=%s", filter_map)

    exclude_fields = set(exclude_fields or []) | {"limit"}
    logger.info("list_tools: effective exclude_fields=%s", exclude_fields)

    start_total = perf_counter()

    try:
        # Build filters
        t0 = perf_counter()
        filters: Dict[str, Any] = {
            filter_map.get(field, field): value
            for field, value in params.model_dump().items()
            if value is not None and field not in exclude_fields
        }
        t1 = perf_counter()
        logger.info(f"filters :: {filters}")
        logger.info("list_tools: filters built in %.2f ms filters=%s", (t1 - t0) * 1000, filters)

        # Single HTTP call → results + count (replaces filter + count + islice)
        t_fetch_start = perf_counter()
        logger.info("list_tools: calling _raw_filter with limit=%d filters=%s", limit, filters)
        record_list, count = _raw_filter(api, endpoint, limit, filters)
        t_fetch_end = perf_counter()
        logger.info(
            "list_tools: _raw_filter complete records_fetched=%d total_count=%d took_ms=%.2f",
            len(record_list), count, (t_fetch_end - t_fetch_start) * 1000,
        )

        # Parallel serialization
        worker_count = max(1, min(max_workers, len(record_list) or 1))
        logger.info("list_tools: determined worker_count=%d for %d records", worker_count, len(record_list))

        def _serialize(record: Any) -> Dict[str, Any]:
            logger.info("list_tools._serialize: serializing record type=%s", type(record).__name__)
            return device_to_dict(api, record, plain_fields, relation_fields, multi_relation_fields, custom_field_keys=custom_field_keys,)

        t_serialize_start = perf_counter()
        logger.info("list_tools: starting parallel serialization with worker_count=%d", worker_count)
        with ThreadPoolExecutor(max_workers=worker_count) as pool:
            items = list(pool.map(_serialize, record_list))
        t_serialize_end = perf_counter()
        logger.info(
            "list_tools: parallel serialization complete items_count=%d took_ms=%.2f",
            len(items), (t_serialize_end - t_serialize_start) * 1000,
        )

        total_ms = (perf_counter() - start_total) * 1000
        logger.info(
            "list_tools[%s] timings ms: build_filters=%.2f raw_filter+count=%.2f serialize_parallel=%.2f total=%.2f workers=%d records=%d total_count=%d",
            result_key,
            (t1 - t0) * 1000,
            (t_fetch_end - t_fetch_start) * 1000,
            (t_serialize_end - t_serialize_start) * 1000,
            total_ms,
            worker_count,
            len(record_list),
            count,
        )
        logger.info(f"fetched records:{items}")

        logger.info("list_tools: returning success result_key='%s' count=%d", result_key, count)
        return {
            "success": True,
            "message": f"Found {count} {result_key}",
            result_key: items,
        }

    except Exception as e:
        logger.exception("Failed to list %s: %s", result_key, e)
        logger.info("list_tools: returning failure result_key='%s' error='%s'", result_key, e)
        return {"success": False, "message": f"Failed to list {result_key}: {e}", result_key: []}


# ---------------------------------------------------------------------------
# count_tools (unchanged)
# ---------------------------------------------------------------------------

def count_tools(
    endpoint: Any,
    params: BaseModel,
    resource_name: str,
    filter_map: Optional[Dict[str, str]] = None,
    exclude_fields: Optional[List[str]] = None,
) -> Dict[str, Any]:
    """Count helper (same behavior as the serial module)."""
    logger.info("count_tools: starting resource_name='%s'", resource_name)

    # filter_map = filter_map or {}
    if filter_map is None:
        filter_map = FILTER_MAP
        logger.info("count_tools: filter_map not provided, using default FILTER_MAP=%s", filter_map)

    exclude_fields = set(exclude_fields or []) | {"limit"}
    logger.info("count_tools: effective exclude_fields=%s", exclude_fields)

    start_total = perf_counter()

    try:
        filters: Dict[str, Any] = {
            filter_map.get(field, field): value
            for field, value in params.model_dump().items()
            if value is not None and field not in exclude_fields
        }
        logger.info("count_tools: built filters=%s", filters)

        t_count_start = perf_counter()
        logger.info("count_tools: calling endpoint.count with filters=%s", filters)
        count: int = endpoint.count(**filters)
        t_count_end = perf_counter()
        logger.info(
            "count_tools: endpoint.count returned count=%d took_ms=%.2f",
            count, (t_count_end - t_count_start) * 1000,
        )

        logger.info(
            "count_tools[%s] timings ms: endpoint.count=%.2f total=%.2f",
            resource_name,
            (t_count_end - t_count_start) * 1000,
            (perf_counter() - start_total) * 1000,
        )
        logger.info("count_tools: returning success resource_name='%s' count=%d", resource_name, count)
        return {
            "success": True,
            "message": f"Found {count} {resource_name}",
            "count": count,
        }

    except Exception as e:
        logger.exception("Failed to count %s: %s", resource_name, e)
        logger.info("count_tools: returning failure resource_name='%s' error='%s'", resource_name, e)
        return {"success": False, "message": f"Failed to count {resource_name}: {e}"}


# ---------------------------------------------------------------------------
# get_tools — raw HTTP single/multi-record fetch (same fix as list_tools,
# extended to support ambiguous, non-unique lookup values)
# ---------------------------------------------------------------------------

# Fields whose values are guaranteed unique in Nautobot.
_UNIQUE_LOOKUP_FIELDS: frozenset = frozenset({"id", "natural_slug"})


def _raw_get_one(
    api: pynautobot.core.api.Api,
    endpoint: Any,
    filters: Dict[str, Any],
    extra_filters: Optional[Dict[str, Any]] = None,
) -> Optional[Dict[str, Any]]:
    """
    Fetch the first matching record as a raw dict using a direct HTTP call.

    Replaces endpoint.filter(**filters) + next(iter(...)) — avoids pynautobot
    pagination. Fetches limit=2 so we can detect ambiguous matches without
    pulling the full result set.

    extra_filters are merged in so compound queries like
    name=Rack-1 AND location=ABCD1 are sent in a single request.

    Returns the first result dict, or None if no match.

    NOTE: Retained for callers that only ever want a single record (e.g.
    _lookup_by_name's exact-match attempt). For lookup fields that are not
    guaranteed unique, get_tools() now uses _raw_get_all() instead so that
    ALL matching records are surfaced rather than silently dropped.
    """
    logger.info("_raw_get_one: starting filters=%s extra_filters=%s", filters, extra_filters)

    token = _get_token(api)
    if not token:
        logger.info("_raw_get_one: token resolution failed, raising ValueError")
        raise ValueError("Cannot resolve Nautobot API token.")

    url = f"{endpoint.url}/"
    logger.info("_raw_get_one: resolved url=%s", url)

    merged_params = {"limit": 2, "offset": 0, **filters, **(extra_filters or {})}
    logger.info("_raw_get_one: sending GET request with params=%s", merged_params)

    resp = requests.get(
        url,
        headers={
            "Authorization": f"Token {token}",
            "Content-Type": "application/json",
        },
        params=merged_params,
        timeout=30,
        proxies={"http": "", "https": ""},
    )
    logger.info("_raw_get_one: received response status=%d", resp.status_code)
    resp.raise_for_status()

    results = resp.json().get("results", [])
    logger.info("_raw_get_one: results count=%d returning first=%s", len(results), results[0] if results else None)

    return results[0] if results else None


def _raw_get_all(
    api: pynautobot.core.api.Api,
    endpoint: Any,
    filters: Dict[str, Any],
    extra_filters: Optional[Dict[str, Any]] = None,
    max_records: int = 50,
) -> tuple[list[dict], int]:
    """
    Fetch ALL matching records (up to max_records) as raw dicts via a direct
    HTTP call.

    Unlike _raw_get_one (which only ever inspects the first match), this is
    used for lookup fields that are NOT guaranteed unique — e.g. the same IP
    address string can legitimately exist in multiple namespaces (Coimbatore
    vs Madurai). Rather than silently returning only the first match, this
    fetches every matching record so the caller (get_tools) can serialize
    and return the full set.

    Returns:
        (results, count)  where results is a list of raw dicts (bounded by
        max_records) and count is the total number of matches reported by
        the API (data["count"]).
    """
    logger.info(
        "_raw_get_all: starting filters=%s extra_filters=%s max_records=%d",
        filters, extra_filters, max_records,
    )

    token = _get_token(api)
    if not token:
        logger.info("_raw_get_all: token resolution failed, raising ValueError")
        raise ValueError("Cannot resolve Nautobot API token.")

    url = f"{endpoint.url}/"
    logger.info("_raw_get_all: resolved url=%s", url)

    merged_params = {"limit": max_records, "offset": 0, **filters, **(extra_filters or {})}
    logger.info("_raw_get_all: sending GET request with params=%s", merged_params)

    resp = requests.get(
        url,
        headers={
            "Authorization": f"Token {token}",
            "Content-Type": "application/json",
        },
        params=merged_params,
        timeout=30,
        proxies={"http": "", "https": ""},
    )
    logger.info("_raw_get_all: received response status=%d", resp.status_code)
    resp.raise_for_status()

    data = resp.json()
    results = data.get("results", [])
    count = data.get("count", 0)
    logger.info("_raw_get_all: results_fetched=%d total_count=%d", len(results), count)

    return results, count


def _lookup_by_name(
    api: pynautobot.core.api.Api,
    endpoint: Any,
    name_api_field: str,
    value: str,
    extra_filters: Optional[Dict[str, Any]] = None,
) -> Optional[Dict[str, Any]]:
    """
    Resolve one record by name via raw HTTP — __ie exact match, then __ic fallback.

    extra_filters (e.g. {"location": "ABCD1"}) are merged into both attempts
    so the compound query (name + location) is resolved in a single HTTP call.
    Both calls use _raw_get_one so pagination is never triggered.
    """
    logger.info(
        "_lookup_by_name: starting name_api_field='%s' value='%s' extra_filters=%s",
        name_api_field, value, extra_filters,
    )

    # Try case-insensitive exact match first (fastest, usually enough)
    logger.info("_lookup_by_name: trying case-insensitive exact match (__ie) for field='%s' value='%s'", name_api_field, value)
    rec = _raw_get_one(api, endpoint, {f"{name_api_field}__ie": value}, extra_filters)
    if rec is not None:
        logger.info("_lookup_by_name: exact match (__ie) succeeded for value='%s'", value)
        return rec

    logger.info("_lookup_by_name: exact match (__ie) returned no result, falling back to __ic contains search")

    # Fallback: case-insensitive contains, then verify locally
    lower_value = value.strip().lower()
    logger.info("_lookup_by_name: lower_value='%s' for local verification", lower_value)

    token = _get_token(api)
    url = f"{endpoint.url}/"
    logger.info(f"url:{(url)}")

    fallback_params = {"limit": 5, "offset": 0, f"{name_api_field}__ic": value, **(extra_filters or {})}
    logger.info("_lookup_by_name: sending __ic fallback GET with params=%s", fallback_params)

    resp = requests.get(
        url,
        headers={
            "Authorization": f"Token {token}",
            "Content-Type": "application/json",
        },
        params=fallback_params,
        timeout=30,
        proxies={"http": "", "https": ""},
    )
    logger.info("_lookup_by_name: __ic fallback response status=%d", resp.status_code)
    resp.raise_for_status()

    candidates = resp.json().get("results", [])
    logger.info("_lookup_by_name: __ic fallback returned %d candidates", len(candidates))

    for candidate in candidates:
        candidate_val = (candidate.get(name_api_field) or "").strip().lower()
        logger.info("_lookup_by_name: comparing candidate_val='%s' to lower_value='%s'", candidate_val, lower_value)
        if candidate_val == lower_value:
            logger.info("_lookup_by_name: local verification matched candidate for value='%s'", value)
            return candidate

    logger.info("_lookup_by_name: no match found after __ic fallback for value='%s'", value)
    return None


def get_tools(
    api: pynautobot.core.api.Api,
    endpoint: Any,
    params: BaseModel,
    plain_fields: List[str],
    relation_fields: List[str],
    result_key: str,
    custom_field_keys: Optional[List[str]] = None,
    lookup_fields: Optional[List[str]] = None,
    name_field: str = "name",
    filter_map: Optional[Dict[str, str]] = None,
    unique_fields: Optional[List[str]] = None,
    multi_relation_fields: Optional[List[str]] = None,
) -> Dict[str, Any]:
    """
    Generic single/multi-record fetch helper.

    All filter/lookup calls use raw HTTP (_raw_get_one / _raw_get_all /
    _lookup_by_name) instead of pynautobot's endpoint.filter() to avoid the
    pagination penalty. endpoint.get() is still used for unique fields
    (id, natural_slug) since pynautobot resolves those with a single direct
    URL call — no pagination or ambiguity risk.

    Compound queries (e.g. name=Rack-1 AND location=ABCD1) are handled by
    collecting all non-lookup param fields as extra_filters and merging them
    into the lookup HTTP call — so both constraints go in one request:
      GET /api/dcim/racks/?name__ie=Rack-1&location=ABCD1&limit=2

    AMBIGUOUS LOOKUPS: Lookup fields that are not id/natural_slug and not the
    configured name_field (e.g. "address") are NOT guaranteed unique — the
    same value can legitimately exist across multiple namespaces/objects
    (e.g. the same IP address in both a Coimbatore and a Madurai namespace).
    For those fields this function now fetches and returns ALL matching
    records via _raw_get_all() rather than silently keeping only the first
    one. As a result:
      - result[result_key] is a single dict when exactly one record matched.
      - result[result_key] is a LIST of dicts when more than one record
        matched, and result["count"] reflects how many records were returned.
    Callers (and any downstream code / agent prompts) should check whether
    result[result_key] is a list before assuming a single record.

    Call signature is identical to the original; this remains a drop-in
    replacement for existing call-sites — code that only ever hits unique
    lookup fields (id/natural_slug) or the name field sees no behavior change.
    """
    logger.info(
        "get_tools: starting result_key='%s' plain_fields=%s relation_fields=%s lookup_fields=%s name_field='%s'",
        result_key, plain_fields, relation_fields, lookup_fields, name_field,
    )

    lookup_fields = lookup_fields or ["id", "natural_slug", "name"]
    logger.info("get_tools: effective lookup_fields=%s", lookup_fields)

    # filter_map = filter_map or {}
    if filter_map is None:
        filter_map = FILTER_MAP
        logger.info("get_tools: filter_map not provided, using default FILTER_MAP=%s", filter_map)

    all_unique: frozenset = _UNIQUE_LOOKUP_FIELDS | frozenset(unique_fields or [])
    logger.info("get_tools: effective all_unique fields=%s", all_unique)

    param_dict = params.model_dump()
    logger.info("get_tools: param_dict=%s", param_dict)

    start_total = perf_counter()

    # Collect all params that are NOT a lookup field as extra_filters.
    # These narrow the query (e.g. location, site, tenant) and are merged
    # into every lookup attempt so compound queries work correctly.
    lookup_field_set = set(lookup_fields)
    extra_filters: Dict[str, Any] = {
        filter_map.get(f, f): v
        for f, v in param_dict.items()
        if v is not None and f not in lookup_field_set and f != "limit"
    }
    logger.info(f"extra_filters:{(extra_filters)}")
    logger.info("get_tools: computed extra_filters=%s", extra_filters)

    try:
        # matched_records holds every raw record found for the winning
        # lookup field. For unique/name-field lookups this will contain at
        # most one record; for other fields (e.g. "address") it may contain
        # several when the value is ambiguous across namespaces/objects.
        matched_records: List[Dict[str, Any]] = []
        total_count = 0

        for field in lookup_fields:
            value = param_dict.get(field)
            logger.info("get_tools: evaluating lookup field='%s' value=%s", field, value)

            if value is None:
                logger.info("get_tools: field='%s' is None, skipping", field)
                continue

            api_key = filter_map.get(field, field)
            logger.info("get_tools: field='%s' mapped to api_key='%s'", field, api_key)
            t_lookup_start = perf_counter()

            if field in all_unique:
                logger.info("get_tools: field='%s' is a unique field, using endpoint.get()", field)
                # endpoint.get() by id/natural_slug hits /api/.../devices/<id>/
                # directly — no pagination, guaranteed unique.
                single = endpoint.get(**{api_key: value})
                if single is not None:
                    matched_records = [single]
                    total_count = 1
                logger.info("get_tools: endpoint.get() returned rec=%s", single is not None)

            elif field == name_field:
                logger.info("get_tools: field='%s' is name_field, using _lookup_by_name()", field)
                # Name lookups resolve to a single record by design
                # (case-insensitive exact match, then verified __ic fallback).
                single = _lookup_by_name(api, endpoint, api_key, value, extra_filters)
                if single is not None:
                    matched_records = [single]
                    total_count = 1
                logger.info("get_tools: _lookup_by_name() returned rec=%s", single is not None)

            else:
                logger.info(
                    "get_tools: field='%s' is NOT guaranteed unique — using _raw_get_all() "
                    "to fetch every matching record",
                    field,
                )
                records, count = _raw_get_all(api, endpoint, {api_key: value}, extra_filters)
                if records:
                    matched_records = records
                    total_count = count
                logger.info(
                    "get_tools: _raw_get_all() returned %d record(s), api total_count=%d",
                    len(records), count,
                )

            logger.info(
                "get_tools[%s] lookup field='%s' api_key='%s' matches=%d total_count=%d took_ms=%.2f",
                result_key,
                field,
                api_key,
                len(matched_records),
                total_count,
                (perf_counter() - t_lookup_start) * 1000,
            )

            if matched_records:
                logger.info("get_tools: record(s) found via field='%s', stopping lookup loop", field)
                break

        if not matched_records:
            provided = [f for f in lookup_fields if param_dict.get(f) is not None]
            logger.info("get_tools: no record found provided_fields=%s", provided)

            if provided:
                msg = f"{result_key.capitalize()} not found"
            else:
                tried = ", ".join(f"'{f}'" for f in lookup_fields)
                msg = f"Provide at least one of {tried}"

            logger.info(
                "get_tools[%s] finished no-record total_ms=%.2f",
                result_key,
                (perf_counter() - start_total) * 1000,
            )
            logger.info("get_tools: returning failure result_key='%s' msg='%s'", result_key, msg)
            return {"success": False, "message": msg, result_key: None}

        t_serialize_start = perf_counter()

        if len(matched_records) == 1:
            logger.info("get_tools: single record found, starting serialization")
            serialized = device_to_dict(
                api, matched_records[0], plain_fields, relation_fields,
                multi_relation_fields, custom_field_keys=custom_field_keys,
            )
            logger.info(
                "get_tools[%s] timings ms: serialize=%.2f total=%.2f",
                result_key,
                (perf_counter() - t_serialize_start) * 1000,
                (perf_counter() - start_total) * 1000,
            )
            logger.info(f"fetched records:{serialized}")
            logger.info("get_tools: serialization complete result_key='%s'", result_key)
            return {
                "success": True,
                "message": f"{result_key.capitalize()} retrieved",
                result_key: serialized,
                "count": 1,
            }

        # Multiple matches — e.g. the same address/value exists across
        # several namespaces or objects. Serialize and return ALL of them
        # instead of silently keeping only the first, so downstream tools/
        # agents can act on every matching record (e.g. call get_device for
        # each associated device across namespaces).
        logger.info(
            "get_tools: %d ambiguous records found (api total_count=%d), serializing all",
            len(matched_records), total_count,
        )
        serialized_list = [
            device_to_dict(
                api, rec, plain_fields, relation_fields,
                multi_relation_fields, custom_field_keys=custom_field_keys,
            )
            for rec in matched_records
        ]
        logger.info(
            "get_tools[%s] timings ms: serialize=%.2f total=%.2f",
            result_key,
            (perf_counter() - t_serialize_start) * 1000,
            (perf_counter() - start_total) * 1000,
        )
        logger.info(f"fetched records:{serialized_list}")
        logger.info(
            "get_tools: AMBIGUOUS lookup — returning %d records for result_key='%s'",
            len(serialized_list), result_key,
        )
        return {
            "success": True,
            "message": (
                f"Found {len(serialized_list)} matching {result_key} records "
                f"(ambiguous lookup — multiple namespaces/objects share this value)"
            ),
            result_key: serialized_list,
            "count": len(serialized_list),
        }

    except Exception as e:
        logger.exception("Failed to get %s: %s", result_key, e)
        logger.info("get_tools: returning failure result_key='%s' error='%s'", result_key, e)
        return {"success": False, "message": f"Failed to get {result_key}: {e}", result_key: None}


# ---------------------------------------------------------------------------
# Cache management (unchanged)
# ---------------------------------------------------------------------------

def clear_cache() -> None:
    """Clear relation cache (thread-safe)."""
    logger.info("clear_cache: acquiring lock and clearing relation cache")
    with _cache_lock:
        _relation_cache.clear()
    logger.info("clear_cache: relation cache cleared successfully")
