"""
Nautobot Users permission helpers for MCP server.

Provides simple CRUD helpers for Nautobot Users permissions.
"""
from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

import pynautobot
from pydantic import BaseModel, Field

from .nautobot_fields_actual import PERMISSIONS_PLAIN_FIELDS, PERMISSIONS_RELATION_FIELDS, PERMISSIONS_MULTI_RELATION_FIELDS
from .nautobot_relation_utils import list_tools, count_tools, get_tools

logger = logging.getLogger(__name__)


class ListPermissionsParams(BaseModel):
    name: Optional[str] = Field(None, description="Filter by permission name.")
    query: Optional[str] = Field(None, description="General search query.")
    limit: int = Field(5, description="Maximum number of permissions to return.")


class GetPermissionParams(BaseModel):
    id: Optional[str] = Field(None, description="Permission ID or UUID.")
    name: Optional[str] = Field(None, description="Permission name.")


PLAIN_FIELDS: List[str] = PERMISSIONS_PLAIN_FIELDS
RELATION_FIELDS: List[str] = PERMISSIONS_RELATION_FIELDS
MULTI_RELATION_FIELDS: List[str] = PERMISSIONS_MULTI_RELATION_FIELDS


def list_permissions(api: pynautobot.core.api.Api, params: ListPermissionsParams) -> Dict[str, Any]:
    return list_tools(
        api=api,
        endpoint=api.users.permissions,
        params=params,
        plain_fields=PLAIN_FIELDS,
        relation_fields=RELATION_FIELDS,
        multi_relation_fields=MULTI_RELATION_FIELDS,
        result_key="permissions",
        limit=getattr(params, "limit", 5),
    )


def get_permission(api: pynautobot.core.api.Api, params: GetPermissionParams) -> Dict[str, Any]:
    return get_tools(
        api=api,
        endpoint=api.users.permissions,
        params=params,
        plain_fields=PLAIN_FIELDS,
        relation_fields=RELATION_FIELDS,
        multi_relation_fields=MULTI_RELATION_FIELDS,
        result_key="permissions",
        lookup_fields=['id', 'name'],
    )

def count_permission(api: pynautobot.core.api.Api, params: ListPermissionsParams) -> Dict[str, Any]:
    return count_tools(
        endpoint=api.users.permissions,
        params=params,
        resource_name="permissions",
    )
