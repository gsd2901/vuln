from __future__ import annotations

import re
from typing import Any, Dict, Optional

import pynautobot


class ForeignKeyResolver:
    """Resolve human-friendly identifiers to Nautobot object UUIDs.

    Supports:
    - Direct UUID passthrough
    - Lookups by common fields (name, slug, model, natural_slug, prefix, vid)
    - Basic normalization (strip, lowercase, underscore/dash swapping)
    - Case-insensitive fallback over filtered queryset
    """

    LOOKUP_FIELDS = ["name", "slug", "model", "natural_slug", "prefix", "vid"]

    def __init__(self, api: pynautobot.core.api.Api):
        self.api = api

    def resolve(
        self,
        endpoint,
        value: Optional[str],
        extra_filters: Optional[Dict[str, Any]] = None,
    ) -> Optional[str]:
        if value is None or value == "":
            return None

        # Direct UUID passthrough
        if self._is_uuid(value):
            return value

        normalized_candidates = self._normalized_candidates(value)
        filters = extra_filters.copy() if extra_filters else {}

        # Try direct lookups on each candidate and field
        for candidate in normalized_candidates:
            for field in self.LOOKUP_FIELDS:
                try:
                    obj = endpoint.get(**{field: candidate}, **filters)
                    if obj:
                        return obj.id
                except Exception:
                    # Some endpoints may not support all lookup fields
                    continue

        # Case-insensitive fallback over filtered queryset
        try:
            objs = endpoint.filter(**filters)
            for obj in objs:
                for field in self.LOOKUP_FIELDS:
                    attr = getattr(obj, field, None)
                    if isinstance(attr, str):
                        for candidate in normalized_candidates:
                            if attr.strip().lower() == candidate:
                                return obj.id
        except Exception:
            pass

        raise ValueError(f"{getattr(endpoint, 'name', 'object')} '{value}' not found")

    @staticmethod
    def _is_uuid(value: str) -> bool:
        return bool(re.fullmatch(r"[a-f0-9-]{36}", value.strip(), re.IGNORECASE))

    @staticmethod
    def _normalized_candidates(value: str) -> list[str]:
        v = value.strip()
        if not v:
            return []
        base = v.lower()
        candidates = {base}
        # swap - and _ forms
        candidates.add(base.replace("_", "-"))
        candidates.add(base.replace("-", "_"))
        return list(candidates)
