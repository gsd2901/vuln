"""
Nautobot Circuits circuit termination helpers for MCP server.

Provides CRUD helpers for Nautobot Circuits circuit terminations. Functions accept a configured
`pynautobot` API instance and Pydantic param models and return JSON-serializable
dicts with a common envelope.

Example responses mirror Nautobot's circuit termination representation (id, term_side, display,
description, circuit, location, connected_endpoint, etc.).
"""
from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

import pynautobot
from pydantic import BaseModel, Field

from .nautobot_fields_actual import CIRCUIT_TERMINATIONS_PLAIN_FIELDS, CIRCUIT_TERMINATIONS_RELATION_FIELDS, CIRCUIT_TERMINATIONS_MULTI_RELATION_FIELDS
from .nautobot_relation_utils import list_tools, count_tools, get_tools

logger = logging.getLogger(__name__)

class ListCircuitTerminationsParams(BaseModel):
    """Parameters for listing circuit terminations."""

    id: Optional[str] = Field(None, description="Circuit termination primary key/UUID.")
    circuit: Optional[str] = Field(None, description="Filter by circuit ID or cid (best-effort).")
    tags: Optional[List[str]] = Field(None, description="List of tag slugs/names.")
    location: Optional[str] = Field(
        None,
        description=(
            "Filter by the name or UUID of the physical site/location where this "
            "termination is installed (best-effort match)."
        ),
    )
    provider_network: Optional[str] = Field(
        None,
        description=(
            "Filter by the name or UUID of the provider-managed network (e.g. MPLS VPN, "
            "carrier Ethernet service) to which this termination connects (best-effort match)."
        ),
    )
    cloud_network: Optional[str] = Field(
        None,
        description=(
            "Filter by the name or UUID of the cloud network (e.g. AWS VPC, Azure VNet) "
            "to which this termination connects (best-effort match)."
        ),
    )
    term_side: Optional[str] = Field(
        None,
        description=(
            "Filter by the termination side of the circuit. "
            "Accepted values: 'A' (A-side / near end) or 'Z' (Z-side / far end)."
        ),
    )
    port_speed: Optional[int] = Field(
        None,
        description=(
            "Filter by the physical port speed of this termination in Kbps "
            "(e.g. 1000000 for 1 Gbps)."
        ),
    )
    upstream_speed: Optional[int] = Field(
        None,
        description=(
            "Filter by the upstream (ingress) speed of this termination in Kbps when it "
            "differs from the port speed, such as on asymmetric circuits."
        ),
    )
    xconnect_id: Optional[str] = Field(
        None,
        description=(
            "Filter by the cross-connect or demarcation identifier assigned by the "
            "provider or data-centre operator for this termination (e.g. 'XC-00123')."
        ),
    )
    pp_info: Optional[str] = Field(
        None,
        description=(
            "Filter by patch-panel information describing the physical patch-panel port "
            "or label associated with this termination (e.g. 'PP-A / Port 12')."
        ),
    )
    description: Optional[str] = Field(
        None,
        description=(
            "Filter by the free-text description attached to the circuit termination "
            "(case-insensitive substring match)."
        ),
    )
    cable: Optional[str] = Field(
        None,
        description=(
            "Filter by the UUID or label of the cable directly attached to this "
            "termination port."
        ),
    )
    cable_peer_type: Optional[str] = Field(
        None,
        description=(
            "Filter by the content-type of the object at the far end of the attached "
            "cable (e.g. 'dcim.interface', 'circuits.circuittermination')."
        ),
    )
    cable_peer: Optional[str] = Field(
        None,
        description=(
            "Filter by the UUID or identifier of the specific object at the far end "
            "of the attached cable (the cable peer)."
        ),
    )
    connected_endpoint_type: Optional[str] = Field(
        None,
        description=(
            "Filter by the content-type of the ultimately connected endpoint after "
            "resolving all intermediate cables and pass-throughs "
            "(e.g. 'dcim.interface')."
        ),
    )
    connected_endpoint: Optional[str] = Field(
        None,
        description=(
            "Filter by the UUID or identifier of the ultimately connected endpoint "
            "device/interface after traversing the full cable path."
        ),
    )
    connected_endpoint_reachable: Optional[bool] = Field(
        None,
        description=(
            "Filter by whether the connected endpoint is reachable/traceable through "
            "the cable path. True means the full path is intact; False means the path "
            "is broken or incomplete."
        ),
    )
    created: Optional[str] = Field(
        None,
        description=(
            "Filter by the date on which this circuit termination record was created "
            "in Nautobot. Accepts ISO 8601 date format (YYYY-MM-DD)."
        ),
    )
    last_updated: Optional[str] = Field(
        None,
        description=(
            "Filter by the date and time this circuit termination record was last "
            "modified. Accepts ISO 8601 datetime format (YYYY-MM-DDTHH:MM:SSZ)."
        ),
    )
    query: Optional[str] = Field(None, description="Case-insensitive contains filter on description.")
    limit: int = Field(5, description="Maximum number of circuit terminations to return.")


class GetCircuitTerminationParams(BaseModel):
    """Parameters for getting a single circuit termination."""

    id: Optional[str] = Field(None, description="Circuit termination primary key/UUID.")
    tags: Optional[List[str]] = Field(None, description="List of tag slugs/names.")
    circuit: Optional[str] = Field(None, description="Circuit ID/cid to scope lookup.")
    location: Optional[str] = Field(
        None,
        description=(
            "Filter by the name or UUID of the physical site/location where this "
            "termination is installed (best-effort match)."
        ),
    )
    provider_network: Optional[str] = Field(
        None,
        description=(
            "Filter by the name or UUID of the provider-managed network (e.g. MPLS VPN, "
            "carrier Ethernet service) to which this termination connects (best-effort match)."
        ),
    )
    cloud_network: Optional[str] = Field(
        None,
        description=(
            "Filter by the name or UUID of the cloud network (e.g. AWS VPC, Azure VNet) "
            "to which this termination connects (best-effort match)."
        ),
    )
    term_side: Optional[str] = Field(
        None,
        description=(
            "Termination side of the circuit used to identify this endpoint. "
            "Accepted values: 'A' (A-side / near end) or 'Z' (Z-side / far end)."
        ),
    )
    port_speed: Optional[int] = Field(
        None,
        description=(
            "Physical port speed of this termination in Kbps "
            "(e.g. 1000000 for 1 Gbps)."
        ),
    )
    upstream_speed: Optional[int] = Field(
        None,
        description=(
            "Upstream (ingress) speed of this termination in Kbps when it differs "
            "from the port speed, such as on asymmetric circuits."
        ),
    )
    xconnect_id: Optional[str] = Field(
        None,
        description=(
            "Cross-connect or demarcation identifier assigned by the provider or "
            "data-centre operator for this termination (e.g. 'XC-00123')."
        ),
    )
    pp_info: Optional[str] = Field(
        None,
        description=(
            "Patch-panel information describing the physical patch-panel port or label "
            "associated with this termination (e.g. 'PP-A / Port 12')."
        ),
    )
    description: Optional[str] = Field(
        None,
        description=(
            "Free-text description attached to this circuit termination "
            "(case-insensitive substring match)."
        ),
    )
    cable: Optional[str] = Field(
        None,
        description=(
            "UUID or label of the cable directly attached to this termination port."
        ),
    )
    cable_peer_type: Optional[str] = Field(
        None,
        description=(
            "Content-type of the object at the far end of the attached cable "
            "(e.g. 'dcim.interface', 'circuits.circuittermination')."
        ),
    )
    cable_peer: Optional[str] = Field(
        None,
        description=(
            "UUID or identifier of the specific object at the far end of the attached "
            "cable (the cable peer)."
        ),
    )
    connected_endpoint_type: Optional[str] = Field(
        None,
        description=(
            "Content-type of the ultimately connected endpoint after resolving all "
            "intermediate cables and pass-throughs (e.g. 'dcim.interface')."
        ),
    )
    connected_endpoint: Optional[str] = Field(
        None,
        description=(
            "UUID or identifier of the ultimately connected endpoint device/interface "
            "after traversing the full cable path."
        ),
    )
    connected_endpoint_reachable: Optional[bool] = Field(
        None,
        description=(
            "Whether the connected endpoint is reachable/traceable through the cable "
            "path. True means the full path is intact; False means the path is broken "
            "or incomplete."
        ),
    )
    created: Optional[str] = Field(
        None,
        description=(
            "Date on which this circuit termination record was created in Nautobot. "
            "Accepts ISO 8601 date format (YYYY-MM-DD)."
        ),
    )
    last_updated: Optional[str] = Field(
        None,
        description=(
            "Date and time this circuit termination record was last modified. "
            "Accepts ISO 8601 datetime format (YYYY-MM-DDTHH:MM:SSZ)."
        ),
    )
    query: Optional[str] = Field(None, description="Case-insensitive contains filter on description.")

# class ListCircuitTerminationsParams(BaseModel):
#     """Parameters for listing circuit terminations."""
#     id: Optional[str] = Field(None, description="Circuit termination primary key/UUID.")
#     circuit: Optional[str] = Field(None, description="Filter by circuit ID or cid (best-effort).")
#     tags: Optional[List[str]] = Field(None, description="List of tag slugs/names.")
#     location: Optional[str] = Field(None, description="Filter by location name or ID (best-effort).")
#     provider_network: Optional[str] = Field(None, description="Filter by provider network (best-effort).")
#     cloud_network: Optional[str] = Field(None, description="Filter by cloud network (best-effort).")
#     term_side: Optional[str] = Field(None, description="Filter by term side (A/Z).")
#     query: Optional[str] = Field(None, description="Case-insensitive contains filter on description.")
#     limit: int = Field(5, description="Maximum number of circuit terminations to return.")

# class GetCircuitTerminationParams(BaseModel):
#     """Parameters for getting a single circuit termination."""
#     id: Optional[str] = Field(None, description="Circuit termination primary key/UUID.")
#     tags: Optional[List[str]] = Field(None, description="List of tag slugs/names.")
#     term_side: Optional[str] = Field(None, description="Termination side (A/Z).")
#     circuit: Optional[str] = Field(None, description="Circuit ID/cid to scope lookup.")
#     location: Optional[str] = Field(None, description="Filter by location name or ID (best-effort).")
#     provider_network: Optional[str] = Field(None, description="Filter by provider network (best-effort).")
#     cloud_network: Optional[str] = Field(None, description="Filter by cloud network (best-effort).")
#     term_side: Optional[str] = Field(None, description="Filter by term side (A/Z).")
#     query: Optional[str] = Field(None, description="Case-insensitive contains filter on description.")


PLAIN_FIELDS: List[str] = CIRCUIT_TERMINATIONS_PLAIN_FIELDS
RELATION_FIELDS: List[str] = CIRCUIT_TERMINATIONS_RELATION_FIELDS
MULTI_RELATION_FIELDS: List[str] = CIRCUIT_TERMINATIONS_MULTI_RELATION_FIELDS


def list_circuit_terminations(api: pynautobot.core.api.Api, params: ListCircuitTerminationsParams) -> Dict[str, Any]:
    return list_tools(
        api=api,
        endpoint=api.circuits.circuit_terminations,
        params=params,
        plain_fields=PLAIN_FIELDS,
        relation_fields=RELATION_FIELDS,
        multi_relation_fields=MULTI_RELATION_FIELDS,
        result_key="circuit_terminations",
        limit=getattr(params, "limit", 5),
    )


def count_circuit_terminations(api: pynautobot.core.api.Api, params: ListCircuitTerminationsParams) -> Dict[str, Any]:
    return count_tools(
        endpoint=api.circuits.circuit_terminations,
        params=params,
        resource_name="circuit_terminations",
    )


def get_circuit_termination(api: pynautobot.core.api.Api, params: GetCircuitTerminationParams) -> Dict[str, Any]:
    return get_tools(
        api=api,
        endpoint=api.circuits.circuit_terminations,
        params=params,
        plain_fields=PLAIN_FIELDS,
        relation_fields=RELATION_FIELDS,
        multi_relation_fields=MULTI_RELATION_FIELDS,
        result_key="circuit_terminations",
        lookup_fields=['id'],
    )
