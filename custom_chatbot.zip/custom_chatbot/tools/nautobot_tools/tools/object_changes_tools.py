"""
Nautobot Extras object_change helpers for MCP server.

Provides simple CRUD helpers for Nautobot Extras object_changes.
"""
from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

import pynautobot
from pydantic import BaseModel, Field

from .nautobot_fields_actual import (
    OBJECT_CHANGES_PLAIN_FIELDS,
    OBJECT_CHANGES_RELATION_FIELDS,
    OBJECT_CHANGES_MULTI_RELATION_FIELDS,
)
from .nautobot_relation_utils import list_tools, get_tools,count_tools

logger = logging.getLogger(__name__)


class ListObjectChangesParams(BaseModel):
    name: Optional[str] = Field(None, description="Filter by object_change name.")
    query: Optional[str] = Field(None, description="General search query.")
    limit: int = Field(5, description="Maximum number of object_changes to return.")


class GetObjectChangeParams(BaseModel):
    id: Optional[str] = Field(None, description="ObjectChange ID or UUID.")
    name: Optional[str] = Field(None, description="ObjectChange name.")


PLAIN_FIELDS: List[str] = OBJECT_CHANGES_PLAIN_FIELDS
RELATION_FIELDS: List[str] = OBJECT_CHANGES_RELATION_FIELDS
MULTI_RELATION_FIELDS: List[str] = OBJECT_CHANGES_MULTI_RELATION_FIELDS


def list_object_changes(api: pynautobot.core.api.Api, params: ListObjectChangesParams) -> Dict[str, Any]:
    return list_tools(
        api=api,
        endpoint=api.extras.object_changes,
        params=params,
        plain_fields=PLAIN_FIELDS,
        relation_fields=RELATION_FIELDS,
        multi_relation_fields=MULTI_RELATION_FIELDS,
        result_key="object_changes",
        limit=getattr(params, "limit", 5),
    )


def get_object_change(api: pynautobot.core.api.Api, params: GetObjectChangeParams) -> Dict[str, Any]:
    return get_tools(
        api=api,
        endpoint=api.extras.object_changes,
        params=params,
        plain_fields=PLAIN_FIELDS,
        relation_fields=RELATION_FIELDS,
        multi_relation_fields=MULTI_RELATION_FIELDS,
        result_key="object_changes",
        lookup_fields=["id", "natural_slug", "name"],
    )

def count_object_change(api: pynautobot.core.api.Api, params: ListObjectChangesParams) -> Dict[str, Any]:
    return count_tools(
        endpoint=api.extras.object_changes,
        params=params,
        resource_name="object_changes",
    )
