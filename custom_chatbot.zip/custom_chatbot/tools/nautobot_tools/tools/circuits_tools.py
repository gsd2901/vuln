"""
Nautobot Circuits circuit helpers for MCP server.

Provides simple CRUD helpers for Nautobot Circuits circuits. Functions accept a
configured `pynautobot` API instance and Pydantic param models and return
JSON-serializable dicts with a common envelope.

Example responses mirror Nautobot's circuit representation (id, cid,
display, provider, circuit_type, status, description, etc.).
"""
from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

import pynautobot
from pydantic import BaseModel, Field

from .nautobot_fields_actual import CIRCUITS_PLAIN_FIELDS, CIRCUITS_RELATION_FIELDS, CIRCUITS_MULTI_RELATION_FIELDS
from .nautobot_relation_utils import list_tools, count_tools, get_tools

logger = logging.getLogger(__name__)

class ListCircuitsParams(BaseModel):
    """Parameters for listing circuits."""
    id: Optional[str] = Field(
        None,
        description="Circuit primary key/UUID. Uniquely identifies a circuit record in Nautobot's database."
    )
    cid: Optional[str] = Field(
        None,
        description="Circuit ID to retrieve. Human-readable identifier assigned to the circuit by the provider (e.g., 'CKT-12345')."
    )
    install_date: Optional[str] = Field(
        None,
        description="Date the circuit was installed or activated. Accepts ISO 8601 date format (YYYY-MM-DD). Useful for filtering circuits by their go-live date."
    )
    commit_rate: Optional[int] = Field(
        None,
        description="Committed data rate for the circuit in Kbps (kilobits per second). Represents the guaranteed bandwidth agreed upon in the service contract."
    )
    description: Optional[str] = Field(
        None,
        description="Short human-readable description of the circuit. Typically used to summarize the circuit's purpose, endpoints, or service details."
    )
    comments: Optional[str] = Field(
        None,
        description="Free-form notes or additional commentary about the circuit. May include maintenance history, escalation contacts, or operational remarks."
    )
    tenant: Optional[str] = Field(
        None,
        description="Filter by tenant slug/name. Tenant represents the organization or business unit that owns or uses this circuit."
    )
    created: Optional[str] = Field(
        None,
        description="Timestamp when the circuit record was first created in Nautobot. Accepts ISO 8601 datetime format (YYYY-MM-DDTHH:MM:SSZ)."
    )
    last_updated: Optional[str] = Field(
        None,
        description="Timestamp when the circuit record was last modified in Nautobot. Accepts ISO 8601 datetime format (YYYY-MM-DDTHH:MM:SSZ). Useful for auditing recent changes."
    )
    status: Optional[str] = Field(
        None,
        description="Filter by status slug or name (best-effort). Represents the operational state of the circuit (e.g., 'active', 'planned', 'decommissioned', 'offline')."
    )
    provider: Optional[str] = Field(
        None,
        description="Filter by provider name or ID (best-effort). Provider is the carrier or service provider delivering the circuit (e.g., 'AT&T', 'Zayo')."
    )
    circuit_type: Optional[str] = Field(
        None,
        description="Filter by circuit type (best-effort). Classifies the nature of the circuit service (e.g., 'Internet', 'MPLS', 'Dark Fiber', 'P2P')."
    )
    circuit_termination_a: Optional[str] = Field(
        None,
        description="Filter by the A-side termination of the circuit. Refers to the site, device, or location where one end of the circuit is physically terminated."
    )
    circuit_termination_z: Optional[str] = Field(
        None,
        description="Filter by the Z-side termination of the circuit. Refers to the site, device, or location where the far end of the circuit is physically terminated."
    )
    provider_network: Optional[str] = Field(
        None,
        description="Filter by provider network (best-effort). Identifies the provider's internal network or backbone that carries this circuit."
    )
    cloud_network: Optional[str] = Field(
        None,
        description="Filter by cloud network (best-effort). Associates the circuit with a cloud provider network (e.g., AWS Direct Connect, Azure ExpressRoute)."
    )
    location: Optional[str] = Field(
        None,
        description="Filter by location slug/name/ID (best-effort). Narrows results to circuits associated with a specific physical or logical location in Nautobot."
    )
    tenant_group: Optional[str] = Field(
        None,
        description="Filter by tenant group slug/name (best-effort). Tenant groups allow hierarchical grouping of tenants for organizational purposes."
    )
    circuit_redundancy: Optional[str] = Field(
        None,
        description="Filter by circuit redundancy/custom field (best-effort). Indicates whether the circuit is part of a redundant pair or failover configuration."
    )
    tags: Optional[str] = Field(
        None,
        description="Filter by tag slug/name. Tags are user-defined labels applied to circuits for flexible categorization and filtering."
    )
    query: Optional[str] = Field(
        None,
        description="Case-insensitive contains filter on circuit ID (cid) or display name. Useful for partial-match searches without knowing the exact identifier."
    )
    limit: int = Field(
        5,
        description="Maximum number of circuits to return in the response. Defaults to 50,000. Lower this value for faster responses when working with large datasets."
    )


class GetCircuitParams(BaseModel):
    """Parameters for getting a single circuit."""

    id: Optional[str] = Field(
        None,
        description="Circuit primary key/UUID. Uniquely identifies a circuit record in Nautobot's database."
    )
    cid: Optional[str] = Field(
        None,
        description="Circuit ID to retrieve. Human-readable identifier assigned to the circuit by the provider (e.g., 'CKT-12345')."
    )
    install_date: Optional[str] = Field(
        None,
        description="Date the circuit was installed or activated. Accepts ISO 8601 date format (YYYY-MM-DD). Useful for filtering circuits by their go-live date."
    )
    commit_rate: Optional[int] = Field(
        None,
        description="Committed data rate for the circuit in Kbps (kilobits per second). Represents the guaranteed bandwidth agreed upon in the service contract."
    )
    description: Optional[str] = Field(
        None,
        description="Short human-readable description of the circuit. Typically used to summarize the circuit's purpose, endpoints, or service details."
    )
    comments: Optional[str] = Field(
        None,
        description="Free-form notes or additional commentary about the circuit. May include maintenance history, escalation contacts, or operational remarks."
    )
    tenant: Optional[str] = Field(
        None,
        description="Filter by tenant slug/name. Tenant represents the organization or business unit that owns or uses this circuit."
    )
    created: Optional[str] = Field(
        None,
        description="Timestamp when the circuit record was first created in Nautobot. Accepts ISO 8601 datetime format (YYYY-MM-DDTHH:MM:SSZ)."
    )
    last_updated: Optional[str] = Field(
        None,
        description="Timestamp when the circuit record was last modified in Nautobot. Accepts ISO 8601 datetime format (YYYY-MM-DDTHH:MM:SSZ). Useful for auditing recent changes."
    )
    status: Optional[str] = Field(
        None,
        description="Filter by status slug or name (best-effort). Represents the operational state of the circuit (e.g., 'active', 'planned', 'decommissioned', 'offline')."
    )
    provider: Optional[str] = Field(
        None,
        description="Filter by provider name or ID (best-effort). Provider is the carrier or service provider delivering the circuit (e.g., 'AT&T', 'Zayo')."
    )
    circuit_type: Optional[str] = Field(
        None,
        description="Filter by circuit type (best-effort). Classifies the nature of the circuit service (e.g., 'Internet', 'MPLS', 'Dark Fiber', 'P2P')."
    )
    circuit_termination_a: Optional[str] = Field(
        None,
        description="Filter by the A-side termination of the circuit. Refers to the site, device, or location where one end of the circuit is physically terminated."
    )
    circuit_termination_z: Optional[str] = Field(
        None,
        description="Filter by the Z-side termination of the circuit. Refers to the site, device, or location where the far end of the circuit is physically terminated."
    )
    provider_network: Optional[str] = Field(
        None,
        description="Filter by provider network (best-effort). Identifies the provider's internal network or backbone that carries this circuit."
    )
    cloud_network: Optional[str] = Field(
        None,
        description="Filter by cloud network (best-effort). Associates the circuit with a cloud provider network (e.g., AWS Direct Connect, Azure ExpressRoute)."
    )
    location: Optional[str] = Field(
        None,
        description="Filter by location slug/name/ID (best-effort). Narrows results to circuits associated with a specific physical or logical location in Nautobot."
    )
    tenant_group: Optional[str] = Field(
        None,
        description="Filter by tenant group slug/name (best-effort). Tenant groups allow hierarchical grouping of tenants for organizational purposes."
    )
    circuit_redundancy: Optional[str] = Field(
        None,
        description="Filter by circuit redundancy/custom field (best-effort). Indicates whether the circuit is part of a redundant pair or failover configuration."
    )
    tags: Optional[str] = Field(
        None,
        description="Filter by tag slug/name. Tags are user-defined labels applied to circuits for flexible categorization and filtering."
    )
    query: Optional[str] = Field(
        None,
        description="Case-insensitive contains filter on circuit ID (cid) or display name. Useful for partial-match searches without knowing the exact identifier."
    )


# class ListCircuitsParams(BaseModel):
#     """Parameters for listing circuits."""
#     id: Optional[str] = Field(None, description="Circuit primary key/UUID.")
#     cid: Optional[str] = Field(None, description="Circuit ID to retrieve.")
#     provider: Optional[str] = Field(None, description="Filter by provider name or ID (best-effort).")
#     provider_network: Optional[str] = Field(None, description="Filter by provider network (best-effort).")
#     cloud_network: Optional[str] = Field(None, description="Filter by cloud network (best-effort).")
#     status: Optional[str] = Field(None, description="Filter by status slug or name (best-effort).")
#     circuit_type: Optional[str] = Field(None, description="Filter by circuit type (best-effort).")
#     location: Optional[str] = Field(None, description="Filter by location slug/name/ID (best-effort).")
#     tenant: Optional[str] = Field(None, description="Filter by tenant slug/name.")
#     tenant_group: Optional[str] = Field(None, description="Filter by tenant group slug/name (best-effort).")
#     circuit_redundancy: Optional[str] = Field(None, description="Filter by tenant circuit redundancy/custom field (best-effort).")
#     tags: Optional[str] = Field(None, description="Filter by tag slug/name.")
#     query: Optional[str] = Field(None, description="Case-insensitive contains filter on circuit ID (cid) or display name.")
#     limit: int = Field(5, description="Maximum number of circuits to return.")


# class GetCircuitParams(BaseModel):
#     """Parameters for getting a single circuit."""
#     id: Optional[str] = Field(None, description="Circuit primary key/UUID.")
#     cid: Optional[str] = Field(None, description="Circuit ID to retrieve.")
#     provider: Optional[str] = Field(None, description="Filter by provider name or ID (best-effort).")
#     provider_network: Optional[str] = Field(None, description="Filter by provider network (best-effort).")
#     cloud_network: Optional[str] = Field(None, description="Filter by cloud network (best-effort).")
#     status: Optional[str] = Field(None, description="Filter by status slug or name (best-effort).")
#     circuit_type: Optional[str] = Field(None, description="Filter by circuit type (best-effort).")
#     location: Optional[str] = Field(None, description="Filter by location slug/name/ID (best-effort).")
#     tenant: Optional[str] = Field(None, description="Filter by tenant slug/name.")
#     tenant_group: Optional[str] = Field(None, description="Filter by tenant group slug/name (best-effort).")
#     circuit_redundancy: Optional[str] = Field(None, description="Filter by tenant circuit redundancy/custom field (best-effort).")
#     tags: Optional[str] = Field(None, description="Filter by tag slug/name.")
#     query: Optional[str] = Field(None, description="Case-insensitive contains filter on circuit ID (cid) or display name.")


PLAIN_FIELDS: List[str] = CIRCUITS_PLAIN_FIELDS
RELATION_FIELDS: List[str] = CIRCUITS_RELATION_FIELDS
MULTI_RELATION_FIELDS: List[str] = CIRCUITS_MULTI_RELATION_FIELDS


def list_circuits(api: pynautobot.core.api.Api, params: ListCircuitsParams) -> Dict[str, Any]:
    return list_tools(
        api=api,
        endpoint=api.circuits.circuits,
        params=params,
        plain_fields=PLAIN_FIELDS,
        relation_fields=RELATION_FIELDS,
        multi_relation_fields=MULTI_RELATION_FIELDS,
        result_key="circuits",
        limit=getattr(params, "limit", 5),
    )


def count_circuits(api: pynautobot.core.api.Api, params: ListCircuitsParams) -> Dict[str, Any]:
    return count_tools(
        endpoint=api.circuits.circuits,
        params=params,
        resource_name="circuits",
    )


def get_circuit(api: pynautobot.core.api.Api, params: GetCircuitParams) -> Dict[str, Any]:
    return get_tools(
        api=api,
        endpoint=api.circuits.circuits,
        params=params,
        plain_fields=PLAIN_FIELDS,
        relation_fields=RELATION_FIELDS,
        multi_relation_fields=MULTI_RELATION_FIELDS,
        result_key="circuits",
        lookup_fields=['id','cid',],
    )
