"""
Nautobot Dcim virtual_chassis helpers for MCP server.

Provides simple CRUD helpers for Nautobot Dcim virtual_chassis.
"""
from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

import pynautobot
from pydantic import BaseModel, Field

from .nautobot_fields_actual import VIRTUAL_CHASSIS_PLAIN_FIELDS, VIRTUAL_CHASSIS_RELATION_FIELDS, VIRTUAL_CHASSIS_MULTI_RELATION_FIELDS
from .nautobot_relation_utils import list_tools, count_tools, get_tools

logger = logging.getLogger(__name__)

class ListVirtualChassissParams(BaseModel):
    id: Optional[str] = Field(None, description="VirtualChassis ID or UUID.")
    name: Optional[str] = Field(None, description="Filter by virtual chassis name (exact or partial match).")
    master: Optional[str] = Field(None, description="Filter by the master device name, slug, or ID that leads the virtual chassis.")
    member_count: Optional[int] = Field(None, description="Filter by the total number of member devices in the virtual chassis.")
    domain: Optional[str] = Field(None, description="Filter by the virtual chassis domain name used to group and identify the chassis cluster.")
    created: Optional[str] = Field(None, description="Filter by the date the virtual chassis record was created (ISO 8601 format, e.g. 'YYYY-MM-DD').")
    last_updated: Optional[str] = Field(None, description="Filter by the date and time the virtual chassis record was last modified (ISO 8601 format, e.g. 'YYYY-MM-DDTHH:MM:SSZ').")
    location: Optional[str] = Field(None, description="Filter by location name/slug/ID (best-effort via master device).")
    location_type: Optional[str] = Field(None, description="Filter by location type name/slug/ID (best-effort via master device location).")
    tenant_group: Optional[str] = Field(None, description="Filter by tenant group name/slug/ID (best-effort via master device tenant).")
    tenant: Optional[str] = Field(None, description="Filter by tenant name/slug/ID (best-effort via master device).")
    tags: Optional[str] = Field(None, description="Filter by tag name/slug.")
    contacts: Optional[str] = Field(None, description="Filter by contacts (best-effort derived value).")
    teams: Optional[str] = Field(None, description="Filter by teams (best-effort derived value).")
    query: Optional[str] = Field(None, description="General search query.")
    limit: int = Field(5, description="Maximum number of virtual_chassis to return.")


class GetVirtualChassisParams(BaseModel):
    id: Optional[str] = Field(None, description="VirtualChassis ID or UUID.")
    name: Optional[str] = Field(None, description="VirtualChassis name (exact match used to uniquely identify the record).")
    master: Optional[str] = Field(None, description="The master device name, slug, or ID that acts as the primary node of the virtual chassis.")
    member_count: Optional[int] = Field(None, description="The total number of member devices belonging to the virtual chassis.")
    domain: Optional[str] = Field(None, description="The virtual chassis domain name that logically groups member devices into a single chassis cluster.")
    created: Optional[str] = Field(None, description="The date the virtual chassis record was originally created in Nautobot (ISO 8601 format, e.g. 'YYYY-MM-DD').")
    last_updated: Optional[str] = Field(None, description="The timestamp of the most recent update to the virtual chassis record (ISO 8601 format, e.g. 'YYYY-MM-DDTHH:MM:SSZ').")
    location: Optional[str] = Field(None, description="Filter by location name/slug/ID (best-effort via master device).")
    location_type: Optional[str] = Field(None, description="Filter by location type name/slug/ID (best-effort via master device location).")
    tenant_group: Optional[str] = Field(None, description="Filter by tenant group name/slug/ID (best-effort via master device tenant).")
    tenant: Optional[str] = Field(None, description="Filter by tenant name/slug/ID (best-effort via master device).")
    tags: Optional[str] = Field(None, description="Filter by tag name/slug.")
    contacts: Optional[str] = Field(None, description="Filter by contacts (best-effort derived value).")
    teams: Optional[str] = Field(None, description="Filter by teams (best-effort derived value).")
    query: Optional[str] = Field(None, description="General search query.")
    limit: int = Field(5, description="Maximum number of virtual_chassis to return.")


# class ListVirtualChassissParams(BaseModel):
#     id: Optional[str] = Field(None, description="VirtualChassis ID or UUID.")
#     name: Optional[str] = Field(None, description="Filter by virtual_chassis name.")
#     location: Optional[str] = Field(None, description="Filter by location name/slug/ID (best-effort via master device).")
#     location_type: Optional[str] = Field(None, description="Filter by location type name/slug/ID (best-effort via master device location).")
#     tenant_group: Optional[str] = Field(None, description="Filter by tenant group name/slug/ID (best-effort via master device tenant).")
#     tenant: Optional[str] = Field(None, description="Filter by tenant name/slug/ID (best-effort via master device).")
#     tags: Optional[str] = Field(None, description="Filter by tag name/slug.")
#     contacts: Optional[str] = Field(None, description="Filter by contacts (best-effort derived value).")
#     teams: Optional[str] = Field(None, description="Filter by teams (best-effort derived value).")
#     query: Optional[str] = Field(None, description="General search query.")
#     limit: int = Field(5, description="Maximum number of virtual_chassis to return.")


# class GetVirtualChassisParams(BaseModel):
#     id: Optional[str] = Field(None, description="VirtualChassis ID or UUID.")
#     name: Optional[str] = Field(None, description="VirtualChassis name.")
#     location: Optional[str] = Field(None, description="Filter by location name/slug/ID (best-effort via master device).")
#     location_type: Optional[str] = Field(None, description="Filter by location type name/slug/ID (best-effort via master device location).")
#     tenant_group: Optional[str] = Field(None, description="Filter by tenant group name/slug/ID (best-effort via master device tenant).")
#     tenant: Optional[str] = Field(None, description="Filter by tenant name/slug/ID (best-effort via master device).")
#     tags: Optional[str] = Field(None, description="Filter by tag name/slug.")
#     contacts: Optional[str] = Field(None, description="Filter by contacts (best-effort derived value).")
#     teams: Optional[str] = Field(None, description="Filter by teams (best-effort derived value).")
#     query: Optional[str] = Field(None, description="General search query.")
#     limit: int = Field(5, description="Maximum number of virtual_chassis to return.")


PLAIN_FIELDS: List[str] = VIRTUAL_CHASSIS_PLAIN_FIELDS
RELATION_FIELDS: List[str] = VIRTUAL_CHASSIS_RELATION_FIELDS
MULTI_RELATION_FIELDS: List[str] = VIRTUAL_CHASSIS_MULTI_RELATION_FIELDS


def list_virtual_chassis(api: pynautobot.core.api.Api, params: ListVirtualChassissParams) -> Dict[str, Any]:
    return list_tools(
        api=api,
        endpoint=api.dcim.virtual_chassis,
        params=params,
        plain_fields=PLAIN_FIELDS,
        relation_fields=RELATION_FIELDS,
        multi_relation_fields=MULTI_RELATION_FIELDS,
        result_key="virtual_chassis",
        limit=getattr(params, "limit", 5),
    )


def count_virtual_chassis(api: pynautobot.core.api.Api, params: ListVirtualChassissParams) -> Dict[str, Any]:
    return count_tools(
        endpoint=api.dcim.virtual_chassis,
        params=params,
        resource_name="virtual_chassis",
    )


def get_virtual_chassis(api: pynautobot.core.api.Api, params: GetVirtualChassisParams) -> Dict[str, Any]:
    return get_tools(
        api=api,
        endpoint=api.dcim.virtual_chassis,
        params=params,
        plain_fields=PLAIN_FIELDS,
        relation_fields=RELATION_FIELDS,
        multi_relation_fields=MULTI_RELATION_FIELDS,
        result_key="virtual_chassis",
        lookup_fields=['id', 'name'],
    )
