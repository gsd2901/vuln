"""
Nautobot Dcim power_panel helpers for MCP server.

Provides simple CRUD helpers for Nautobot Dcim power_panels.
"""
from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

import pynautobot
from pydantic import BaseModel, Field

from .nautobot_fields_actual import POWER_PANELS_PLAIN_FIELDS, POWER_PANELS_RELATION_FIELDS, POWER_PANELS_MULTI_RELATION_FIELDS
from .nautobot_relation_utils import list_tools, count_tools, get_tools

logger = logging.getLogger(__name__)


class ListPowerPanelsParams(BaseModel):
    """Parameters for listing Power Panels."""
    id: Optional[str] = Field(None, description="PowerPanel ID or UUID.")
    location: Optional[str] = Field(None, description="Filter by location slug/name/ID.")
    rack_group: Optional[str] = Field(None, description="Filter by rack group slug/name/ID.")
    tenant_group: Optional[str] = Field(None, description="Filter by tenant group slug/name (best-effort).")
    panel_type: Optional[str] = Field(None, description="Filter by panel type.")
    breaker_position_count: Optional[int] = Field(None, description="Filter by breaker position count.")
    power_path: Optional[str] = Field(None, description="Filter by power path.")
    tags: Optional[str] = Field(None, description="Filter by tag slug/name.")
    name: Optional[str] = Field(None, description="Filter by power_panel name.")
    query: Optional[str] = Field(None, description="General search query.")
    limit: int = Field(5, description="Maximum number of power_panels to return.")


class GetPowerPanelParams(BaseModel):
    """Parameters for getting a single power panel."""

    id: Optional[str] = Field(None, description="PowerPanel ID or UUID.")
    name: Optional[str] = Field(None, description="PowerPanel name.")
    location: Optional[str] = Field(None, description="Filter by location slug/name/ID.")
    rack_group: Optional[str] = Field(None, description="Filter by rack group slug/name/ID.")
    tenant_group: Optional[str] = Field(None, description="Filter by tenant group slug/name (best-effort).")
    panel_type: Optional[str] = Field(None, description="Filter by panel type.")
    breaker_position_count: Optional[int] = Field(None, description="Filter by breaker position count.")
    power_path: Optional[str] = Field(None, description="Filter by power path.")
    tags: Optional[str] = Field(None, description="Filter by tag slug/name.")
    name: Optional[str] = Field(None, description="Filter by power_panel name.")
    query: Optional[str] = Field(None, description="General search query.")


PLAIN_FIELDS: List[str] = POWER_PANELS_PLAIN_FIELDS
RELATION_FIELDS: List[str] = POWER_PANELS_RELATION_FIELDS
MULTI_RELATION_FIELDS: List[str] = POWER_PANELS_MULTI_RELATION_FIELDS


def list_power_panels(api: pynautobot.core.api.Api, params: ListPowerPanelsParams) -> Dict[str, Any]:
    return list_tools(
        api=api,
        endpoint=api.dcim.power_panels,
        params=params,
        plain_fields=PLAIN_FIELDS,
        relation_fields=RELATION_FIELDS,
        multi_relation_fields=MULTI_RELATION_FIELDS,
        result_key="power_panels",
        limit=getattr(params, "limit", 5),
    )

def count_power_panel(api: pynautobot.core.api.Api, params: ListPowerPanelsParams) -> Dict[str, Any]:
    return count_tools(
        endpoint=api.dcim.power_panels,
        params=params,
        resource_name="power_panels",
    )


def get_power_panel(api: pynautobot.core.api.Api, params: GetPowerPanelParams) -> Dict[str, Any]:
    return get_tools(
        api=api,
        endpoint=api.dcim.power_panels,
        params=params,
        plain_fields=PLAIN_FIELDS,
        relation_fields=RELATION_FIELDS,
        multi_relation_fields=MULTI_RELATION_FIELDS,
        result_key="power_panels",
        lookup_fields=['id', 'name'],
    )
