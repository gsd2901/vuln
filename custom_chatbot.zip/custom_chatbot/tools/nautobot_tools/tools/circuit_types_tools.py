"""
Nautobot Circuits circuit_type helpers for MCP server.

Provides simple CRUD helpers for Nautobot Circuits circuit_types.
"""
from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

import pynautobot
from pydantic import BaseModel, Field

from .nautobot_fields_actual import CIRCUIT_TYPES_PLAIN_FIELDS, CIRCUIT_TYPES_RELATION_FIELDS, CIRCUIT_TYPES_MULTI_RELATION_FIELDS
from .nautobot_relation_utils import list_tools, count_tools, get_tools

logger = logging.getLogger(__name__)

class ListCircuitTypesParams(BaseModel):
    name: Optional[str] = Field(None, description="Filter by circuit_type name.")
    query: Optional[str] = Field(None, description="General search query.")
    limit: int = Field(5, description="Maximum number of circuit_types to return.")
    tags: Optional[str] = Field(None, description="Filter by tag slug/name.")
    circuit_count: Optional[int] = Field(
        None,
        description="Filter by the number of circuits associated with a circuit type.",
    )
    description: Optional[str] = Field(
        None,
        description="Filter by the human-readable description of the circuit type.",
    )
    created: Optional[str] = Field(
        None,
        description=(
            "Filter by the date the circuit type was created. "
            "Accepts ISO 8601 date format (e.g. '2024-01-15')."
        ),
    )
    last_updated: Optional[str] = Field(
        None,
        description=(
            "Filter by the date and time the circuit type was last modified. "
            "Accepts ISO 8601 datetime format (e.g. '2024-01-15T10:30:00Z')."
        ),
    )


class GetCircuitTypeParams(BaseModel):
    id: Optional[str] = Field(None, description="CircuitType ID or UUID.")
    name: Optional[str] = Field(None, description="CircuitType name.")
    tags: Optional[str] = Field(None, description="Filter by tag slug/name.")
    circuit_count: Optional[int] = Field(
        None,
        description="The number of circuits currently associated with this circuit type.",
    )
    description: Optional[str] = Field(
        None,
        description="A human-readable description providing additional context about the circuit type.",
    )
    created: Optional[str] = Field(
        None,
        description=(
            "The date on which this circuit type record was created in Nautobot. "
            "Accepts ISO 8601 date format (e.g. '2024-01-15')."
        ),
    )
    last_updated: Optional[str] = Field(
        None,
        description=(
            "The date and time this circuit type record was last modified in Nautobot. "
            "Accepts ISO 8601 datetime format (e.g. '2024-01-15T10:30:00Z')."
        ),
    )


# class ListCircuitTypesParams(BaseModel):
#     name: Optional[str] = Field(None, description="Filter by circuit_type name.")
#     query: Optional[str] = Field(None, description="General search query.")
#     limit: int = Field(5, description="Maximum number of circuit_types to return.")


# class GetCircuitTypeParams(BaseModel):
#     id: Optional[str] = Field(None, description="CircuitType ID or UUID.")
#     name: Optional[str] = Field(None, description="CircuitType name.")
    


PLAIN_FIELDS: List[str] = CIRCUIT_TYPES_PLAIN_FIELDS
RELATION_FIELDS: List[str] = CIRCUIT_TYPES_RELATION_FIELDS
MULTI_RELATION_FIELDS: List[str] = CIRCUIT_TYPES_MULTI_RELATION_FIELDS


def list_circuit_types(api: pynautobot.core.api.Api, params: ListCircuitTypesParams) -> Dict[str, Any]:
    return list_tools(
        api=api,
        endpoint=api.circuits.circuit_types,
        params=params,
        plain_fields=PLAIN_FIELDS,
        relation_fields=RELATION_FIELDS,
        multi_relation_fields=MULTI_RELATION_FIELDS,
        result_key="circuit_types",
        limit=getattr(params, "limit", 5),
    )


def count_circuit_types(api: pynautobot.core.api.Api, params: ListCircuitTypesParams) -> Dict[str, Any]:
    return count_tools(
        endpoint=api.circuits.circuit_types,
        params=params,
        resource_name="circuit_types",
    )


def get_circuit_type(api: pynautobot.core.api.Api, params: GetCircuitTypeParams) -> Dict[str, Any]:
    return get_tools(
        api=api,
        endpoint=api.circuits.circuit_types,
        params=params,
        plain_fields=PLAIN_FIELDS,
        relation_fields=RELATION_FIELDS,
        multi_relation_fields=MULTI_RELATION_FIELDS,
        result_key="circuit_types",
        lookup_fields=['id', 'name'],
    )
