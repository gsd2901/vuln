"""
Nautobot Dcim module helpers for MCP server.

Provides simple CRUD helpers for Nautobot Dcim modules.
"""
from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

import pynautobot
from pydantic import BaseModel, Field

from .nautobot_fields_actual import MODULES_PLAIN_FIELDS, MODULES_RELATION_FIELDS, MODULES_MULTI_RELATION_FIELDS
from .nautobot_relation_utils import list_tools, count_tools, get_tools

logger = logging.getLogger(__name__)


class ListModulesParams(BaseModel):
    name: Optional[str] = Field(None, description="Filter by module name.")
    tenant_group: Optional[str] = Field(None, description="Filter by tenant group name/slug/ID (best-effort via tenant).")
    status: Optional[str] = Field(None, description="Filter by status name/slug/ID.")
    role: Optional[str] = Field(None, description="Filter by role name/slug/ID.")
    manufacturer: Optional[str] = Field(None, description="Filter by manufacturer name/slug/ID (best-effort via module type).")
    model: Optional[str] = Field(None, description="Filter by model (best-effort via module type).")
    tags: Optional[str] = Field(None, description="Filter by tag name/slug.")
    location: Optional[str] = Field(None, description="Filter by location name/slug/ID.")
    device: Optional[str] = Field(None, description="Filter by device name/slug/ID.")
    tenant: Optional[str] = Field(None, description="Filter by tenant name/slug/ID.")
    mac_address: Optional[str] = Field(None, description="Filter by MAC address (best-effort derived value).")
    module_family: Optional[str] = Field(None, description="Filter by module family (best-effort via module type).")
    has_console_ports: Optional[bool] = Field(None, description="Filter by presence of console ports (best-effort via module type).")
    has_console_server_ports: Optional[bool] = Field(None, description="Filter by presence of console server ports (best-effort via module type).")
    has_power_ports: Optional[bool] = Field(None, description="Filter by presence of power ports (best-effort via module type).")
    has_power_outlets: Optional[bool] = Field(None, description="Filter by presence of power outlets (best-effort via module type).")
    has_interfaces: Optional[bool] = Field(None, description="Filter by presence of interfaces (best-effort via module type).")
    has_front_ports: Optional[bool] = Field(None, description="Filter by presence of front ports (best-effort via module type).")
    has_rear_ports: Optional[bool] = Field(None, description="Filter by presence of rear ports (best-effort via module type).")
    query: Optional[str] = Field(None, description="General search query.")
    limit: int = Field(5, description="Maximum number of modules to return.")


class GetModuleParams(BaseModel):
    id: Optional[str] = Field(None, description="Module ID or UUID.")
    name: Optional[str] = Field(None, description="Module name.")


PLAIN_FIELDS: List[str] = MODULES_PLAIN_FIELDS
RELATION_FIELDS: List[str] = MODULES_RELATION_FIELDS
MULTI_RELATION_FIELDS: List[str] = MODULES_MULTI_RELATION_FIELDS


def list_modules(api: pynautobot.core.api.Api, params: ListModulesParams) -> Dict[str, Any]:
    return list_tools(
        api=api,
        endpoint=api.dcim.modules,
        params=params,
        plain_fields=PLAIN_FIELDS,
        relation_fields=RELATION_FIELDS,
        multi_relation_fields=MULTI_RELATION_FIELDS,
        result_key="modules",
        limit=getattr(params, "limit", 5),
    )


def get_module(api: pynautobot.core.api.Api, params: GetModuleParams) -> Dict[str, Any]:
    return get_tools(
        api=api,
        endpoint=api.dcim.modules,
        params=params,
        plain_fields=PLAIN_FIELDS,
        relation_fields=RELATION_FIELDS,
        multi_relation_fields=MULTI_RELATION_FIELDS,
        result_key="modules",
        lookup_fields=['id', 'name'],
    )
def count_module(api: pynautobot.core.api.Api, params: ListModulesParams) -> Dict[str, Any]:
    return count_tools(
        endpoint=api.dcim.modules,
        params=params,
        resource_name="modules",
    )