"""
Nautobot Extras custom_link helpers for MCP server.

Provides simple CRUD helpers for Nautobot Extras custom_links.
"""
from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

import pynautobot
from pydantic import BaseModel, Field

from .nautobot_fields_actual import CUSTOM_LINKS_PLAIN_FIELDS, CUSTOM_LINKS_RELATION_FIELDS, CUSTOM_LINKS_MULTI_RELATION_FIELDS
from .nautobot_relation_utils import list_tools, count_tools, get_tools

logger = logging.getLogger(__name__)


class ListCustomLinksParams(BaseModel):
    name: Optional[str] = Field(None, description="Filter by custom_link name.")
    query: Optional[str] = Field(None, description="General search query.")
    limit: int = Field(5, description="Maximum number of custom_links to return.")


class GetCustomLinkParams(BaseModel):
    id: Optional[str] = Field(None, description="CustomLink ID or UUID.")
    name: Optional[str] = Field(None, description="CustomLink name.")


PLAIN_FIELDS: List[str] = CUSTOM_LINKS_PLAIN_FIELDS
RELATION_FIELDS: List[str] = CUSTOM_LINKS_RELATION_FIELDS
MULTI_RELATION_FIELDS: List[str] = CUSTOM_LINKS_MULTI_RELATION_FIELDS


def list_custom_links(api: pynautobot.core.api.Api, params: ListCustomLinksParams) -> Dict[str, Any]:
    return list_tools(
        api=api,
        endpoint=api.extras.custom_links,
        params=params,
        plain_fields=PLAIN_FIELDS,
        relation_fields=RELATION_FIELDS,
        multi_relation_fields=MULTI_RELATION_FIELDS,
        result_key="custom_links",
        limit=getattr(params, "limit", 5),
    )


def get_custom_link(api: pynautobot.core.api.Api, params: GetCustomLinkParams) -> Dict[str, Any]:
    return get_tools(
        api=api,
        endpoint=api.extras.custom_links,
        params=params,
        plain_fields=PLAIN_FIELDS,
        relation_fields=RELATION_FIELDS,
        multi_relation_fields=MULTI_RELATION_FIELDS,
        result_key="custom_links",
        lookup_fields=['id', 'name'],
    )

def count_custom_link(api: pynautobot.core.api.Api, params: ListCustomLinksParams) -> Dict[str, Any]:
    return count_tools(
        endpoint=api.extras.custom_links,
        params=params,
        resource_name="custom_links",
    )
