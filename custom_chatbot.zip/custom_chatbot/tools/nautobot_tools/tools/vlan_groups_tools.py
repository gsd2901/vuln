"""
Nautobot Ipam vlan_group helpers for MCP server.

Provides simple CRUD helpers for Nautobot Ipam vlan_groups.
"""
from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

import pynautobot
from pydantic import BaseModel, Field

from .nautobot_fields_actual import VLAN_GROUPS_PLAIN_FIELDS, VLAN_GROUPS_RELATION_FIELDS, VLAN_GROUPS_MULTI_RELATION_FIELDS
from .nautobot_relation_utils import list_tools, count_tools, get_tools

logger = logging.getLogger(__name__)


class ListVlanGroupsParams(BaseModel):
    name: Optional[str] = Field(None, description="Filter by vlan_group name.")
    location: Optional[str] = Field(None, description="Filter by location name/slug/ID.")
    contacts: Optional[str] = Field(None, description="Filter by contacts (best-effort derived value).")
    teams: Optional[str] = Field(None, description="Filter by teams (best-effort derived value).")
    query: Optional[str] = Field(None, description="General search query.")
    limit: int = Field(5, description="Maximum number of vlan_groups to return.")


class GetVlanGroupParams(BaseModel):
    id: Optional[str] = Field(None, description="VlanGroup ID or UUID.")
    name: Optional[str] = Field(None, description="VlanGroup name.")


PLAIN_FIELDS: List[str] = VLAN_GROUPS_PLAIN_FIELDS
RELATION_FIELDS: List[str] = VLAN_GROUPS_RELATION_FIELDS
MULTI_RELATION_FIELDS: List[str] = VLAN_GROUPS_MULTI_RELATION_FIELDS


def list_vlan_groups(api: pynautobot.core.api.Api, params: ListVlanGroupsParams) -> Dict[str, Any]:
    return list_tools(
        api=api,
        endpoint=api.ipam.vlan_groups,
        params=params,
        plain_fields=PLAIN_FIELDS,
        relation_fields=RELATION_FIELDS,
        multi_relation_fields=MULTI_RELATION_FIELDS,
        result_key="vlan_groups",
        limit=getattr(params, "limit", 5),
    )


def count_vlan_groups(api: pynautobot.core.api.Api, params: ListVlanGroupsParams) -> Dict[str, Any]:
    return count_tools(
        endpoint=api.ipam.vlan_groups,
        params=params,
        resource_name="vlan_groups",
    )


def get_vlan_group(api: pynautobot.core.api.Api, params: GetVlanGroupParams) -> Dict[str, Any]:
    return get_tools(
        api=api,
        endpoint=api.ipam.vlan_groups,
        params=params,
        plain_fields=PLAIN_FIELDS,
        relation_fields=RELATION_FIELDS,
        multi_relation_fields=MULTI_RELATION_FIELDS,
        result_key="vlan_groups",
        lookup_fields=['id', 'name'],
    )
