"""

Nautobot Ipam vlan helpers for MCP server.

Provides simple CRUD helpers for Nautobot Ipam vlans.

"""

from __future__ import annotations

import logging

import os

from typing import Any, Dict, List, Optional

import requests

import pynautobot

from pydantic import BaseModel, Field

logger = logging.getLogger(__name__)


# ---------------------------

# Param models

# ---------------------------

class ListVlansParams(BaseModel):

    location: Optional[str] = Field(None, description="Filter by location slug/name/ID.")

    vlan_group: Optional[str] = Field(None, description="Filter by VLAN group slug/name/ID.")

    status: Optional[str] = Field(None, description="Filter by status slug/name.")

    role: Optional[str] = Field(None, description="Filter by role slug/name.")

    tenant: Optional[str] = Field(None, description="Filter by tenant slug/name.")

    name: Optional[str] = Field(None, description="Filter by vlan name.")

    platform: Optional[str] = Field(None, description="Filter by platform slug/name.")

    device_type: Optional[str] = Field(None, description="Filter by device-type slug/name.")

    query: Optional[str] = Field(None, description="General search query.")

    limit: int = Field(5, description="Maximum number of vlans to return.")
 
 
class CountVlansParams(BaseModel):

    location: Optional[str] = Field(None, description="Filter by location slug/name/ID.")

    vlan_group: Optional[str] = Field(None, description="Filter by VLAN group slug/name/ID.")

    status: Optional[str] = Field(None, description="Filter by status slug/name.")

    role: Optional[str] = Field(None, description="Filter by role slug/name.")

    tenant: Optional[str] = Field(None, description="Filter by tenant slug/name.")

    name: Optional[str] = Field(None, description="Filter by vlan name.")

    platform: Optional[str] = Field(None, description="Filter by platform slug/name.")

    device_type: Optional[str] = Field(None, description="Filter by device-type slug/name.")

    query: Optional[str] = Field(None, description="General search query.")
 
 
class GetVlanParams(BaseModel):

    id: Optional[str] = Field(None, description="Vlan ID or UUID.")

    name: Optional[str] = Field(None, description="Vlan name.")


class CreateVlanParams(BaseModel):

    name: str = Field(..., description="Name of the vlan.")

    description: Optional[str] = Field(None, description="Description.")

    tags: Optional[List[str]] = Field(None, description="List of tag names.")

    custom_fields: Optional[Dict[str, Any]] = Field(None, description="Custom fields dict.")


class UpdateVlanParams(BaseModel):

    id: Optional[str] = Field(None, description="Vlan ID or UUID.")

    name: Optional[str] = Field(None, description="Vlan name to find by.")

    description: Optional[str] = Field(None, description="Description.")

    tags: Optional[List[str]] = Field(None, description="Tags list to set.")

    custom_fields: Optional[Dict[str, Any]] = Field(None, description="Custom fields to set.")


class DeleteVlanParams(BaseModel):

    id: Optional[str] = Field(None, description="Vlan ID or UUID.")

    name: Optional[str] = Field(None, description="Vlan name to find by.")


# ---------------------------

# Helpers

# ---------------------------
 
def _best_effort_filter_value(value: Optional[str]) -> Optional[str]:

    return value or None

def _get_vlan_by_id_or_name(api: pynautobot.core.api.Api, *, id: Optional[str], name: Optional[str]):

    if id:

        return api.ipam.vlans.get(id)

    if name:

        results = api.ipam.vlans.filter(name=name)

        for r in results:

            return r

    return None


def _relation_name(rel: Any) -> Optional[str]:

    if rel is None:

        return None

    for attr in ("display", "name", "slug", "label"):

        v = getattr(rel, attr, None)

        if isinstance(v, str) and v:

            return v

    if isinstance(rel, dict):

        for k in ("display", "name", "slug", "label"):

            v = rel.get(k)

            if isinstance(v, str) and v:

                return v

    return None


def _resolve_relation_name(api: pynautobot.core.api.Api, rel: Any) -> Optional[str]:

    """Return a display/name for a relation, attempting API lookup when needed."""

    direct = _relation_name(rel)

    if direct:

        return direct

    try:

        if isinstance(rel, dict):

            obj_id = rel.get("id")

            obj_type = rel.get("object_type") or rel.get("object_type_name")

            if obj_id and obj_type and "." in obj_type:

                app, model = obj_type.split(".", 1)

                plural_map = {

                    "status": "statuses",

                    "role": "roles",

                    "tenant": "tenants",

                    "manufacturer": "manufacturers",

                    "device": "devices",

                    "location": "locations",

                    "interface": "interfaces",

                    "cable": "cables",

                    "vlan_group": "vlan_groups",

                    "namespace": "namespaces",

                    "prefix": "prefixes",

                    "ipaddress": "ip-addresses",

                    "tenantgroup": "tenant-groups",

                    "cloudaccount": "cloud-accounts",

                    "cloudnetwork": "cloud-networks",

                    "cloudresourcetype": "cloud-resource-types",

                    "secretsgroup": "secrets-groups",

                    "gitrepository": "git-repositories",

                    "configcontextschema": "config-context-schemas",

                    "devicefamily": "device-families",

                    "rackgroup": "rack-groups",

                    "softwareversion": "software-versions",

                    "module": "modules",

                    "inventoryitem": "inventory-items",

                }

                model_name = model.split(".")[-1]

                plural = plural_map.get(model_name, model_name + "s")

                app_attr = getattr(api, app, None)

                if app_attr is not None and hasattr(app_attr, plural):

                    resource = getattr(app_attr, plural)

                    fetched = resource.get(obj_id)

                    if fetched:

                        return _relation_name(fetched)

    except Exception:

        pass

    try:

        if isinstance(rel, dict) and rel.get("url"):

            url = rel.get("url")

            token = getattr(api, "token", None) or getattr(api, "_token", None) or os.getenv("NAUTOBOT_TOKEN")

            headers = {"Authorization": f"Token {token}"} if token else {}

            resp = requests.get(url, headers=headers, timeout=5)

            if resp.ok:

                try:

                    data = resp.json()

                    disp = data.get("display")

                    if isinstance(disp, str) and disp:

                        return disp

                    val = _relation_name(data)

                    if val:

                        return val

                except Exception:

                    pass

    except Exception:

        pass

    return None
 
 
def _build_vlan_filters(params) -> Dict[str, Any]:

    """Build the shared filter dict from any Params model that has vlan filter fields."""

    filters: Dict[str, Any] = {}

    if getattr(params, "location", None):

        filters["location"] = _best_effort_filter_value(params.location)

    if getattr(params, "vlan_group", None):

        filters["vlan_group"] = _best_effort_filter_value(params.vlan_group)

    if getattr(params, "status", None):

        filters["status"] = _best_effort_filter_value(params.status)

    if getattr(params, "role", None):

        filters["role"] = _best_effort_filter_value(params.role)

    if getattr(params, "tenant", None):

        filters["tenant"] = _best_effort_filter_value(params.tenant)

    if getattr(params, "name", None):

        filters["name__ic"] = params.name

    if getattr(params, "platform", None):

        filters["platform"] = _best_effort_filter_value(params.platform)

    if getattr(params, "device_type", None):

        filters["device_type"] = _best_effort_filter_value(params.device_type)

    if getattr(params, "query", None):

        filters["q"] = params.query

    return filters
 
 
# ---------------------------

# Tool implementations

# ---------------------------
 
def count_vlans(api: pynautobot.core.api.Api, params: CountVlansParams) -> Dict[str, Any]:

    """

    Return only the count of VLANs matching the given filters.
 
    Uses the API's top-level ``count`` field (a single lightweight request

    with limit=1) instead of paginating through all records, making it

    orders of magnitude faster for large datasets.
 
    Example use-case: "How many VLANs are present in the Chennai location?"

    """

    try:

        filters = _build_vlan_filters(params)
 
        # limit=1 so only one record comes back in 'results', but the server

        # still populates the top-level 'count' with the full match total.

        response = api.ipam.vlans.filter(limit=1, **filters)
 
        count = None
 
        # Preferred: read count from the raw HTTP response (zero extra pagination)

        raw = getattr(response, "_response", None)

        if raw is not None and hasattr(raw, "json"):

            data = raw.json()

            count = data.get("count")
 
        # Fallback: pynautobot sometimes exposes .count directly on the list

        if count is None:

            count = getattr(response, "count", None)
 
        # Last resort: iterate (slow, but always correct)

        if count is None:

            logger.warning("Could not read 'count' from API response; falling back to iteration.")

            count = sum(1 for _ in api.ipam.vlans.filter(**filters))
 
        filter_desc = ", ".join(f"{k}={v}" for k, v in filters.items()) or "no filters"

        return {

            "success": True,

            "message": f"Found {count} vlan(s) matching [{filter_desc}]",

            "count": count,

        }

    except Exception as e:

        logger.exception("Failed to count vlans: %s", e)

        return {"success": False, "message": f"Failed to count vlans: {e}", "count": None}
 
 
def list_vlans(api: pynautobot.core.api.Api, params: ListVlansParams) -> Dict[str, Any]:

    try:

        filters = _build_vlan_filters(params)
 
        vlans = api.ipam.vlans.filter(**filters)

        items: List[Dict[str, Any]] = []

        count = 0

        for item in vlans:

            items.append(

                {

                    "id": getattr(item, "id", None),

                    "display": getattr(item, "display", None),

                    "name": getattr(item, "name", None),

                    "description": getattr(item, "description", None),

                    "location": _resolve_relation_name(api, getattr(item, "location", None)),

                    "vlan_group": _resolve_relation_name(api, getattr(item, "vlan_group", None)),

                    "status": _resolve_relation_name(api, getattr(item, "status", None)),

                    "role": _resolve_relation_name(api, getattr(item, "role", None)),

                    "tenant": _resolve_relation_name(api, getattr(item, "tenant", None)),

                    "prefix_count": getattr(item, "prefix_count", None),

                    "vid": getattr(item, "vid", None),

                }

            )

            count += 1

            if count >= params.limit:

                break

        return {"success": True, "message": f"Found {len(items)} vlans", "vlans": items}

    except Exception as e:

        logger.exception("Failed to list vlans: %s", e)

        return {"success": False, "message": f"Failed to list vlans: {e}", "vlans": []}


def get_vlan(api: pynautobot.core.api.Api, params: GetVlanParams) -> Dict[str, Any]:

    try:

        rec = _get_vlan_by_id_or_name(api, id=params.id, name=params.name)

        if not rec:

            return {"success": False, "message": "Vlan not found", "vlan": None}

        rec_dict = dict(rec)

        # Extract relation fields

        vlan_group_raw = rec_dict.get("vlan_group")

        status_raw = rec_dict.get("status")

        location_raw = rec_dict.get("location")

        role_raw = rec_dict.get("role")

        tenant_raw = rec_dict.get("tenant")

        # Build response with resolved display names and raw objects

        result_dict = rec_dict.copy()

        result_dict["vlan_group"] = _resolve_relation_name(api, vlan_group_raw)

        result_dict["vlan_group_raw"] = vlan_group_raw

        result_dict["status"] = _resolve_relation_name(api, status_raw)

        result_dict["status_raw"] = status_raw

        result_dict["role"] = _resolve_relation_name(api, role_raw)

        result_dict["role_raw"] = role_raw

        result_dict["tenant"] = _resolve_relation_name(api, tenant_raw)

        result_dict["tenant_raw"] = tenant_raw

        result_dict["location"] = _resolve_relation_name(api, location_raw)

        result_dict["location_raw"] = location_raw

        return {"success": True, "message": "Vlan retrieved", "vlan": result_dict}

    except Exception as e:

        logger.exception("Failed to get vlan: %s", e)

        return {"success": False, "message": f"Failed to get vlan: {e}", "vlan": None}


def create_vlan(api: pynautobot.core.api.Api, params: CreateVlanParams) -> Dict[str, Any]:

    try:

        payload: Dict[str, Any] = {

            "name": params.name,

        }

        if params.description is not None:

            payload["description"] = params.description

        if params.tags is not None:

            payload["tags"] = params.tags

        if params.custom_fields is not None:

            payload["custom_fields"] = params.custom_fields

        rec = api.ipam.vlans.create(payload)

        return {"success": True, "message": "Vlan created", "vlan": dict(rec)}

    except Exception as e:

        logger.exception("Failed to create vlan: %s", e)

        return {"success": False, "message": f"Failed to create vlan: {e}", "vlan": None}


def update_vlan(api: pynautobot.core.api.Api, params: UpdateVlanParams) -> Dict[str, Any]:

    try:

        rec = _get_vlan_by_id_or_name(api, id=params.id, name=params.name)

        if not rec:

            return {"success": False, "message": "Vlan not found", "vlan": None}

        payload: Dict[str, Any] = {}

        if params.description is not None:

            payload["description"] = params.description

        if params.tags is not None:

            payload["tags"] = params.tags

        if params.custom_fields is not None:

            payload["custom_fields"] = params.custom_fields

        if not payload:

            return {"success": True, "message": "No changes provided", "vlan": dict(rec)}

        success = rec.update(payload)

        if not success:

            return {"success": False, "message": "Update failed", "vlan": None}

        refreshed = api.ipam.vlans.get(rec.id)

        return {"success": True, "message": "Vlan updated", "vlan": dict(refreshed) if refreshed else None}

    except Exception as e:

        logger.exception("Failed to update vlan: %s", e)

        return {"success": False, "message": f"Failed to update vlan: {e}", "vlan": None}


def delete_vlan(api: pynautobot.core.api.Api, params: DeleteVlanParams) -> Dict[str, Any]:

    try:

        rec = _get_vlan_by_id_or_name(api, id=params.id, name=params.name)

        if not rec:

            return {"success": False, "message": "Vlan not found"}

        success = rec.delete()

        return {"success": success, "message": "Vlan deleted" if success else "Delete failed"}

    except Exception as e:

        logger.exception("Failed to delete vlan: %s", e)

        return {"success": False, "message": f"Failed to delete vlan: {e}"}
 