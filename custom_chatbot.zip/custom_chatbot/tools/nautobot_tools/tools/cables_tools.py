"""
Nautobot Dcim cable helpers for MCP server.

Provides simple CRUD helpers for Nautobot Dcim cables.
"""
from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

import pynautobot
from pydantic import BaseModel, Field

from .nautobot_fields_actual import CABLES_PLAIN_FIELDS, CABLES_RELATION_FIELDS, CABLES_MULTI_RELATION_FIELDS
from .nautobot_relation_utils import list_tools, count_tools, get_tools

logger = logging.getLogger(__name__)

class ListCablesParams(BaseModel):
    location: Optional[str] = Field(
        None,
        description=(
            "Filter cables by the physical location where they are installed. "
            "Accepts a location slug (e.g. 'new-york-dc1'), human-readable name "
            "(e.g. 'New York DC1'), or numeric/UUID ID as returned by the Nautobot "
            "locations API. Narrows results to cables whose termination endpoints "
            "reside in the specified location."
        ),
    )
    status: Optional[str] = Field(
        None,
        description=(
            "Filter cables by their operational status. Accepts a status slug "
            "(e.g. 'active', 'planned', 'decommissioned') or human-readable label. "
            "Status values are site-specific and must match slugs configured in "
            "Nautobot's Status model for the Cable content type."
        ),
    )
    rack: Optional[str] = Field(
        None,
        description=(
            "Filter cables by the rack that contains at least one of their "
            "termination endpoints. Accepts a rack numeric ID or rack name "
            "(e.g. 'Rack-A01'). Useful for auditing all cabling within a "
            "specific rack enclosure."
        ),
    )
    role: Optional[str] = Field(
        None,
        description=(
            "Filter cables by their assigned functional role. Accepts a role slug "
            "(e.g. 'uplink', 'management', 'storage') or role name. Roles are "
            "user-defined in Nautobot and help categorise cables by their purpose "
            "in the network."
        ),
    )
    color: Optional[str] = Field(
        None,
        description=(
            "Filter cables by their physical color. Accepts a 6-digit RGB hex "
            "string without the leading '#' (e.g. 'aa1409' for red, 'ffffff' for "
            "white). Color values correspond to the standard Nautobot cable color "
            "palette."
        ),
    )
    device: Optional[str] = Field(
        None,
        description=(
            "Filter cables by a device connected to either termination endpoint. "
            "Accepts a device slug, human-readable name (e.g. 'core-sw-01'), or "
            "numeric/UUID ID. Returns all cables that have at least one end "
            "terminated on an interface, console port, or power port belonging to "
            "the specified device."
        ),
    )
    tenant: Optional[str] = Field(
        None,
        description=(
            "Filter cables by the tenant (customer or organisational unit) they are "
            "associated with. Accepts a tenant slug (e.g. 'acme-corp'), "
            "human-readable name, or numeric/UUID ID. Tenancy is inherited from "
            "the termination devices or assigned directly to the cable."
        ),
    )
    type: Optional[str] = Field(
        None,
        description=(
            "Filter cables by their physical media type. Accepts Nautobot cable-type "
            "slugs such as 'cat6', 'smf-os2', 'mmf-om4', 'dac-active', "
            "'coaxial-rg6', etc. Refer to Nautobot's CableTypeChoices enumeration "
            "for the full list of accepted values."
        ),
    )
    tags: Optional[str] = Field(
        None,
        description=(
            "Filter cables by one or more user-defined tags. Accepts a tag slug or "
            "name (e.g. 'backbone', 'audit-2025'). To filter by multiple tags, "
            "pass a comma-separated string of slugs. Only cables that carry ALL "
            "specified tags are returned (AND logic)."
        ),
    )
    name: Optional[str] = Field(
        None,
        description=(
            "Filter cables by their human-readable label/name. Accepts an exact "
            "string or a case-insensitive partial match depending on the Nautobot "
            "version in use. Useful when cables have been assigned structured "
            "naming conventions (e.g. 'CAB-NYC-001')."
        ),
    )
    query: Optional[str] = Field(
        None,
        description=(
            "Free-text search query applied across multiple cable fields including "
            "label, description, and termination details. Equivalent to the search "
            "bar in the Nautobot UI. Use this for ad-hoc lookups when the exact "
            "filter field is unknown."
        ),
    )
    limit: Optional[int] = Field(
        5,
        description=(
            "Maximum number of cable records to return in a single response. "
            "Defaults to 5. Increase this value (e.g. 50 or 100) to retrieve "
            "larger result sets, keeping in mind that very high limits may impact "
            "response latency. The Nautobot API may enforce its own server-side "
            "maximum."
        ),
    )


class GetCableParams(BaseModel):
    id: Optional[str] = Field(
        None,
        description=(
            "Unique identifier of the cable to retrieve. Accepts either a numeric "
            "integer ID or a UUID string (e.g. '3f8a1c2d-…') as assigned by "
            "Nautobot. When provided, this takes precedence over all other filters "
            "and returns exactly one cable record."
        ),
    )
    name: Optional[str] = Field(
        None,
        description=(
            "Human-readable label/name of the cable to retrieve. Accepts an exact "
            "string match. Use this when you know the cable's label but not its "
            "numeric or UUID ID (e.g. 'CAB-NYC-001')."
        ),
    )
    location: Optional[str] = Field(
        None,
        description=(
            "Narrow the lookup to cables installed at the specified physical "
            "location. Accepts a location slug (e.g. 'new-york-dc1'), "
            "human-readable name, or numeric/UUID ID. Combine with 'name' or "
            "other filters to resolve ambiguous cable identifiers across sites."
        ),
    )
    status: Optional[str] = Field(
        None,
        description=(
            "Narrow the lookup to cables with the given operational status. Accepts "
            "a status slug (e.g. 'active', 'planned', 'decommissioned') or "
            "human-readable label as configured in Nautobot's Status model for the "
            "Cable content type."
        ),
    )
    rack: Optional[str] = Field(
        None,
        description=(
            "Narrow the lookup to cables that have at least one termination endpoint "
            "in the specified rack. Accepts a rack numeric ID or rack name "
            "(e.g. 'Rack-A01'). Useful when retrieving a specific cable within a "
            "known rack."
        ),
    )
    role: Optional[str] = Field(
        None,
        description=(
            "Narrow the lookup to cables assigned the specified functional role. "
            "Accepts a role slug (e.g. 'uplink', 'management') or role name. "
            "Combine with other filters to pinpoint a cable when multiple cables "
            "share the same name across different roles."
        ),
    )
    color: Optional[str] = Field(
        None,
        description=(
            "Narrow the lookup to cables of the specified physical color. Accepts a "
            "6-digit RGB hex string without the leading '#' "
            "(e.g. 'aa1409' for red). Useful as a secondary discriminator when "
            "other identifiers are ambiguous."
        ),
    )
    device: Optional[str] = Field(
        None,
        description=(
            "Narrow the lookup to cables connected to the specified device. Accepts "
            "a device slug, human-readable name (e.g. 'core-sw-01'), or "
            "numeric/UUID ID. Returns cables that have at least one termination "
            "endpoint on an interface, console port, or power port of that device."
        ),
    )
    tenant: Optional[str] = Field(
        None,
        description=(
            "Narrow the lookup to cables associated with the specified tenant. "
            "Accepts a tenant slug (e.g. 'acme-corp'), human-readable name, or "
            "numeric/UUID ID. Tenancy may be inherited from the termination devices "
            "or assigned directly to the cable."
        ),
    )
    type: Optional[str] = Field(
        None,
        description=(
            "Narrow the lookup to cables of the specified physical media type. "
            "Accepts Nautobot cable-type slugs such as 'cat6', 'smf-os2', "
            "'mmf-om4', 'dac-active', 'coaxial-rg6', etc. Refer to Nautobot's "
            "CableTypeChoices enumeration for the complete list of accepted values."
        ),
    )
    tags: Optional[str] = Field(
        None,
        description=(
            "Narrow the lookup to cables carrying the specified tag(s). Accepts a "
            "tag slug or name (e.g. 'backbone'). To match multiple tags, pass a "
            "comma-separated string of slugs; only cables that carry ALL specified "
            "tags are returned (AND logic)."
        ),
    )
    query: Optional[str] = Field(
        None,
        description=(
            "Free-text search string applied across cable label, description, and "
            "termination details. Use when the exact filter field is unknown. "
            "Equivalent to the search bar in the Nautobot UI."
        ),
    )
    limit: Optional[int] = Field(
        5,
        description=(
            "Maximum number of candidate cable records to evaluate before returning "
            "the best match. Defaults to 5. Increase this value when the initial "
            "filters are broad and you need to inspect more candidates to identify "
            "the correct cable. The Nautobot API may enforce its own server-side "
            "maximum."
        ),
    )

# class ListCablesParams(BaseModel):
#     location: Optional[str] = Field(None, description="Filter by location slug/name/ID.")
#     status: Optional[str] = Field(None, description="Filter by status slug/name.")
#     rack: Optional[str] = Field(None, description="Filter by rack ID or name.")
#     role: Optional[str] = Field(None, description="Filter by role slug/name.")
#     color: Optional[str] = Field(None, description="Filter by cable color.")
#     device: Optional[str] = Field(None, description="Filter by device slug/name/ID.")
#     tenant: Optional[str] = Field(None, description="Filter by tenant slug/name.")
#     type: Optional[str] = Field(None, description="Filter by cable type.")
#     tags: Optional[str] = Field(None, description="Filter by tag slug/name.")
#     name: Optional[str] = Field(None, description="Filter by cable name.")
#     query: Optional[str] = Field(None, description="General search query.")
#     limit: Optional[int] = Field(5, description="Maximum number of cables to return.")


# class GetCableParams(BaseModel):
#     id: Optional[str] = Field(None, description="Cable ID or UUID.")
#     name: Optional[str] = Field(None, description="Cable name.")
#     location: Optional[str] = Field(None, description="Filter by location slug/name/ID.")
#     status: Optional[str] = Field(None, description="Filter by status slug/name.")
#     rack: Optional[str] = Field(None, description="Filter by rack ID or name.")
#     role: Optional[str] = Field(None, description="Filter by role slug/name.")
#     color: Optional[str] = Field(None, description="Filter by cable color.")
#     device: Optional[str] = Field(None, description="Filter by device slug/name/ID.")
#     tenant: Optional[str] = Field(None, description="Filter by tenant slug/name.")
#     type: Optional[str] = Field(None, description="Filter by cable type.")
#     tags: Optional[str] = Field(None, description="Filter by tag slug/name.")
#     query: Optional[str] = Field(None, description="General search query.")
#     limit: Optional[int] = Field(5, description="Maximum number of cables to return.")


PLAIN_FIELDS: List[str] = CABLES_PLAIN_FIELDS
RELATION_FIELDS: List[str] = CABLES_RELATION_FIELDS
MULTI_RELATION_FIELDS: List[str] = CABLES_MULTI_RELATION_FIELDS


def list_cables(api: pynautobot.core.api.Api, params: ListCablesParams) -> Dict[str, Any]:
    return list_tools(
        api=api,
        endpoint=api.dcim.cables,
        params=params,
        plain_fields=PLAIN_FIELDS,
        relation_fields=RELATION_FIELDS,
        multi_relation_fields=MULTI_RELATION_FIELDS,
        result_key="cables",
        limit=getattr(params, "limit", 5),
    )


def count_cables(api: pynautobot.core.api.Api, params: ListCablesParams) -> Dict[str, Any]:
    return count_tools(
        endpoint=api.dcim.cables,
        params=params,
        resource_name="cables",
    )


def get_cable(api: pynautobot.core.api.Api, params: GetCableParams) -> Dict[str, Any]:
    return get_tools(
        api=api,
        endpoint=api.dcim.cables,
        params=params,
        plain_fields=PLAIN_FIELDS,
        relation_fields=RELATION_FIELDS,
        multi_relation_fields=MULTI_RELATION_FIELDS,
        result_key="cables",
        lookup_fields=['id', 'name'],
    )
