"""
Nautobot Circuits provider helpers for MCP server.

Provides simple CRUD helpers for Nautobot Circuits providers.
"""
from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

import pynautobot
from pydantic import BaseModel, Field

from .nautobot_fields_actual import PROVIDERS_PLAIN_FIELDS, PROVIDERS_RELATION_FIELDS, PROVIDERS_MULTI_RELATION_FIELDS
from .nautobot_relation_utils import list_tools, count_tools, get_tools

logger = logging.getLogger(__name__)


class ListProvidersParams(BaseModel):
    """Parameters for listing Providers."""
    name: Optional[str] = Field(None, description="Filter by provider name.")
    location: Optional[str] = Field(None, description="Filter by location (best-effort derived value).")
    asn: Optional[str] = Field(None, description="Filter by ASN.")
    tags: Optional[str] = Field(None, description="Filter by tag name/slug.")
    emails_circuit_maintenances: Optional[str] = Field(None, description="Filter by emails for Circuit Maintenance app (best-effort derived value).")
    provider_parser_circuit_maintenances: Optional[str] = Field(None, description="Filter by provider parser for Circuit Maintenance app (best-effort derived value).")
    contacts: Optional[str] = Field(None, description="Filter by contacts (best-effort derived value).")
    teams: Optional[str] = Field(None, description="Filter by teams (best-effort derived value).")
    query: Optional[str] = Field(None, description="General search query.")
    limit: int = Field(5, description="Maximum number of providers to return.")


class GetProviderParams(BaseModel):
    """Parameters for getting a single provider."""
    id: Optional[str] = Field(None, description="Provider ID or UUID.")
    name: Optional[str] = Field(None, description="Provider name.")
    location: Optional[str] = Field(None, description="Filter by location (best-effort derived value).")
    asn: Optional[str] = Field(None, description="Filter by ASN.")
    tags: Optional[str] = Field(None, description="Filter by tag name/slug.")
    emails_circuit_maintenances: Optional[str] = Field(None, description="Filter by emails for Circuit Maintenance app (best-effort derived value).")
    provider_parser_circuit_maintenances: Optional[str] = Field(None, description="Filter by provider parser for Circuit Maintenance app (best-effort derived value).")
    contacts: Optional[str] = Field(None, description="Filter by contacts (best-effort derived value).")
    teams: Optional[str] = Field(None, description="Filter by teams (best-effort derived value).")
    query: Optional[str] = Field(None, description="General search query.")


PLAIN_FIELDS: List[str] = PROVIDERS_PLAIN_FIELDS
RELATION_FIELDS: List[str] = PROVIDERS_RELATION_FIELDS
MULTI_RELATION_FIELDS: List[str] = PROVIDERS_MULTI_RELATION_FIELDS


def list_providers(api: pynautobot.core.api.Api, params: ListProvidersParams) -> Dict[str, Any]:
    return list_tools(
        api=api,
        endpoint=api.circuits.providers,
        params=params,
        plain_fields=PLAIN_FIELDS,
        relation_fields=RELATION_FIELDS,
        multi_relation_fields=MULTI_RELATION_FIELDS,
        result_key="providers",
        limit=getattr(params, "limit", 5),
    )


def get_provider(api: pynautobot.core.api.Api, params: GetProviderParams) -> Dict[str, Any]:
    return get_tools(
        api=api,
        endpoint=api.circuits.providers,
        params=params,
        plain_fields=PLAIN_FIELDS,
        relation_fields=RELATION_FIELDS,
        multi_relation_fields=MULTI_RELATION_FIELDS,
        result_key="providers",
        lookup_fields=['id', 'name'],
    )

def count_provider(api: pynautobot.core.api.Api, params: ListProvidersParams) -> Dict[str, Any]:
    return count_tools(
        endpoint=api.circuits.providers,
        params=params,
        resource_name="providers",
    )
