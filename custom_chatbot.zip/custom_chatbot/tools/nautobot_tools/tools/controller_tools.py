"""
Nautobot DCIM controller helpers for MCP server.

Provides CRUD helpers for Nautobot DCIM controllers. Functions accept a configured
`pynautobot` API instance and Pydantic param models and return JSON-serializable
dicts with a common envelope.

Example responses mirror Nautobot's controller representation (id, name, display,
natural_slug, capabilities, description, status, location, platform, role, tenant,
external_integration, controller_device, controller_device_redundancy_group, etc.).
"""
from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

import pynautobot
from pydantic import BaseModel, Field

from .nautobot_fields_actual import (
    CONTROLLERS_PLAIN_FIELDS,
    CONTROLLERS_RELATION_FIELDS,
    CONTROLLERS_MULTI_RELATION_FIELDS,
)
from .nautobot_relation_utils import list_tools, count_tools, get_tools

logger = logging.getLogger(__name__)


class ListControllersParams(BaseModel):
    """Parameters for listing controllers."""
    id: Optional[str] = Field(None, description="Controller primary key/UUID.")
    name: Optional[str] = Field(None, description="Filter by controller name.")
    status: Optional[str] = Field(None, description="Filter by status slug or name (best-effort).")
    location: Optional[str] = Field(None, description="Filter by location name or ID (best-effort).")
    platform: Optional[str] = Field(None, description="Filter by platform name or ID (best-effort).")
    role: Optional[str] = Field(None, description="Filter by role name or ID (best-effort).")
    tenant: Optional[str] = Field(None, description="Filter by tenant name or ID (best-effort).")
    external_integration: Optional[str] = Field(None, description="Filter by external integration name or ID (best-effort).")
    controller_device: Optional[str] = Field(None, description="Filter by controller device name or ID (best-effort).")
    controller_device_redundancy_group: Optional[str] = Field(None, description="Filter by controller device redundancy group name or ID (best-effort).")
    capabilities: Optional[str] = Field(None, description="Filter by capability (best-effort).")
    tags: Optional[str] = Field(None, description="Filter by tag slug/name.")
    query: Optional[str] = Field(None, description="Case-insensitive contains filter on controller name.")
    limit: int = Field(5, description="Maximum number of controllers to return.")


class GetControllerParams(BaseModel):
    """Parameters for getting a single controller."""

    id: Optional[str] = Field(None, description="Controller primary key/UUID.")
    name: Optional[str] = Field(None, description="Controller name to retrieve.")
    natural_slug: Optional[str] = Field(None, description="Controller natural slug.")
    status: Optional[str] = Field(None, description="Filter by status slug or name (best-effort).")
    location: Optional[str] = Field(None, description="Filter by location name or ID (best-effort).")
    platform: Optional[str] = Field(None, description="Filter by platform name or ID (best-effort).")
    role: Optional[str] = Field(None, description="Filter by role name or ID (best-effort).")
    tenant: Optional[str] = Field(None, description="Filter by tenant name or ID (best-effort).")
    external_integration: Optional[str] = Field(None, description="Filter by external integration name or ID (best-effort).")
    controller_device: Optional[str] = Field(None, description="Filter by controller device name or ID (best-effort).")
    controller_device_redundancy_group: Optional[str] = Field(None, description="Filter by controller device redundancy group name or ID (best-effort).")
    capabilities: Optional[str] = Field(None, description="Filter by capability (best-effort).")
    tags: Optional[str] = Field(None, description="Filter by tag slug/name.")
    query: Optional[str] = Field(None, description="Case-insensitive contains filter on controller name.")


PLAIN_FIELDS: List[str] = CONTROLLERS_PLAIN_FIELDS
RELATION_FIELDS: List[str] = CONTROLLERS_RELATION_FIELDS
MULTI_RELATION_FIELDS: List[str] = CONTROLLERS_MULTI_RELATION_FIELDS


def list_controller(api: pynautobot.core.api.Api, params: ListControllersParams) -> Dict[str, Any]:
    return list_tools(
        api=api,
        endpoint=api.dcim.controllers,
        params=params,
        plain_fields=CONTROLLERS_PLAIN_FIELDS,
        relation_fields=CONTROLLERS_RELATION_FIELDS,
        multi_relation_fields=CONTROLLERS_MULTI_RELATION_FIELDS,
        result_key="controllers",
        limit=getattr(params, "limit", 5),
    )


def get_controller(api: pynautobot.core.api.Api, params: GetControllerParams) -> Dict[str, Any]:
    return get_tools(
        api=api,
        endpoint=api.dcim.controllers,
        params=params,
        plain_fields=CONTROLLERS_PLAIN_FIELDS,
        relation_fields=CONTROLLERS_RELATION_FIELDS,
        multi_relation_fields=CONTROLLERS_MULTI_RELATION_FIELDS,
        result_key="controllers",
        lookup_fields=['id', 'name', 'natural_slug'],
    )

def count_controller(api: pynautobot.core.api.Api, params: ListControllersParams) -> Dict[str, Any]:
    return count_tools(
        endpoint=api.dcim.controllers,
        params=params,
        resource_name="controllers",
    )
