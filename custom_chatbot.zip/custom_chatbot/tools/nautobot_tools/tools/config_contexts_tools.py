"""
Nautobot Extras config_context helpers for MCP server.

Provides simple CRUD helpers for Nautobot Extras config_contexts.
"""
from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

import pynautobot
from pydantic import BaseModel, Field

from .nautobot_fields_actual import CONFIG_CONTEXTS_PLAIN_FIELDS, CONFIG_CONTEXTS_RELATION_FIELDS, CONFIG_CONTEXTS_MULTI_RELATION_FIELDS
from .nautobot_relation_utils import list_tools, count_tools, get_tools

logger = logging.getLogger(__name__)

class ListConfigContextsParams(BaseModel):
    # --- Existing core fields ---
    id: Optional[str] = Field(
        None,
        description="Filter by ConfigContext UUID or numeric ID.",
    )
    name: Optional[str] = Field(
        None,
        description="Filter by the exact name of the config context.",
    )
    query: Optional[str] = Field(
        None,
        description="General search query applied across name and description fields.",
    )
    limit: int = Field(
        5,
        description="Maximum number of config contexts to return in the response.",
    )

    # --- Scope / assignment filters ---
    locations: Optional[str] = Field(
        None,
        description=(
            "Filter by one or more location slugs or UUIDs (comma-separated). "
            "Returns config contexts that are assigned to the specified locations."
        ),
    )
    roles: Optional[str] = Field(
        None,
        description=(
            "Filter by one or more device-role slugs or UUIDs (comma-separated). "
            "Returns config contexts assigned to the specified device roles."
        ),
    )
    device_types: Optional[str] = Field(
        None,
        description=(
            "Filter by one or more device-type slugs or UUIDs (comma-separated). "
            "Returns config contexts scoped to the specified device types."
        ),
    )
    device_redundancy_groups: Optional[str] = Field(
        None,
        description=(
            "Filter by one or more device-redundancy-group slugs or UUIDs "
            "(comma-separated). Returns config contexts assigned to those redundancy groups."
        ),
    )
    platforms: Optional[str] = Field(
        None,
        description=(
            "Filter by one or more platform slugs or UUIDs (comma-separated). "
            "Returns config contexts scoped to the specified platforms (e.g. Cisco IOS, Junos)."
        ),
    )
    cluster_groups: Optional[str] = Field(
        None,
        description=(
            "Filter by one or more cluster-group slugs or UUIDs (comma-separated). "
            "Returns config contexts assigned to the specified cluster groups."
        ),
    )
    clusters: Optional[str] = Field(
        None,
        description=(
            "Filter by one or more cluster slugs or UUIDs (comma-separated). "
            "Returns config contexts scoped to the specified virtualization clusters."
        ),
    )
    tenant_groups: Optional[str] = Field(
        None,
        description=(
            "Filter by one or more tenant-group slugs or UUIDs (comma-separated). "
            "Returns config contexts assigned to the specified tenant groups."
        ),
    )
    tenants: Optional[str] = Field(
        None,
        description=(
            "Filter by one or more tenant slugs or UUIDs (comma-separated). "
            "Returns config contexts scoped to the specified tenants."
        ),
    )
    tags: Optional[str] = Field(
        None,
        description=(
            "Filter by one or more tag slugs (comma-separated). "
            "Returns config contexts that carry all of the specified tags."
        ),
    )

    # --- Ownership / schema fields ---
    owner_content_type: Optional[str] = Field(
        None,
        description=(
            "Filter by the Django content-type string of the owning object "
            "(e.g. 'extras.gitrepository'). Identifies which model type owns this context."
        ),
    )
    owner: Optional[str] = Field(
        None,
        description=(
            "Filter by the slug or UUID of the owning object "
            "(used together with owner_content_type to locate the specific owner instance)."
        ),
    )
    owner_object_id: Optional[str] = Field(
        None,
        description=(
            "Filter by the UUID of the specific owner object instance. "
            "Useful when the owner is identified by UUID rather than slug."
        ),
    )
    weight: Optional[int] = Field(
        None,
        description=(
            "Filter by the numeric priority weight of the config context. "
            "Higher values take precedence when multiple contexts apply to the same device."
        ),
    )
    description: Optional[str] = Field(
        None,
        description="Filter by a partial or exact match on the config context description.",
    )
    is_active: Optional[bool] = Field(
        None,
        description=(
            "Filter by active status. Set to True to return only active config contexts, "
            "False to return only inactive ones."
        ),
    )
    data: Optional[str] = Field(
        None,
        description=(
            "Filter or search within the JSON data payload of the config context. "
            "The value is matched against the serialised JSON body."
        ),
    )
    config_context_schema: Optional[str] = Field(
        None,
        description=(
            "Filter by the slug or UUID of the ConfigContextSchema used to validate "
            "this context's data payload."
        ),
    )

    # --- Timestamp filters ---
    created: Optional[str] = Field(
        None,
        description=(
            "Filter by the creation date of the config context (ISO 8601 format, "
            "e.g. '2024-01-15' or '2024-01-15T10:30:00Z')."
        ),
    )
    last_updated: Optional[str] = Field(
        None,
        description=(
            "Filter by the date/time the config context was last modified "
            "(ISO 8601 format, e.g. '2024-06-01T00:00:00Z')."
        ),
    )


class GetConfigContextParams(BaseModel):
    # --- Existing core fields ---
    id: Optional[str] = Field(
        None,
        description="UUID or numeric ID of the config context to retrieve.",
    )
    name: Optional[str] = Field(
        None,
        description="Exact name of the config context to retrieve.",
    )
    query: Optional[str] = Field(None, description="General search query.")
    # --- Scope / assignment fields ---
    locations: Optional[str] = Field(
        None,
        description=(
            "One or more location slugs or UUIDs (comma-separated) to match against "
            "the config context's assigned locations."
        ),
    )
    roles: Optional[str] = Field(
        None,
        description=(
            "One or more device-role slugs or UUIDs (comma-separated) to match against "
            "the config context's assigned device roles."
        ),
    )
    device_types: Optional[str] = Field(
        None,
        description=(
            "One or more device-type slugs or UUIDs (comma-separated) to match against "
            "the config context's scoped device types."
        ),
    )
    device_redundancy_groups: Optional[str] = Field(
        None,
        description=(
            "One or more device-redundancy-group slugs or UUIDs (comma-separated) "
            "to match against the config context's assigned redundancy groups."
        ),
    )
    platforms: Optional[str] = Field(
        None,
        description=(
            "One or more platform slugs or UUIDs (comma-separated) to match against "
            "the config context's scoped platforms."
        ),
    )
    cluster_groups: Optional[str] = Field(
        None,
        description=(
            "One or more cluster-group slugs or UUIDs (comma-separated) to match against "
            "the config context's assigned cluster groups."
        ),
    )
    clusters: Optional[str] = Field(
        None,
        description=(
            "One or more cluster slugs or UUIDs (comma-separated) to match against "
            "the config context's scoped virtualization clusters."
        ),
    )
    tenant_groups: Optional[str] = Field(
        None,
        description=(
            "One or more tenant-group slugs or UUIDs (comma-separated) to match against "
            "the config context's assigned tenant groups."
        ),
    )
    tenants: Optional[str] = Field(
        None,
        description=(
            "One or more tenant slugs or UUIDs (comma-separated) to match against "
            "the config context's scoped tenants."
        ),
    )
    tags: Optional[str] = Field(
        None,
        description=(
            "One or more tag slugs (comma-separated) that the config context must carry."
        ),
    )

    # --- Ownership / schema fields ---
    owner_content_type: Optional[str] = Field(
        None,
        description=(
            "Django content-type string of the owning object "
            "(e.g. 'extras.gitrepository') to narrow down the context owner."
        ),
    )
    owner: Optional[str] = Field(
        None,
        description=(
            "Slug or UUID of the specific owning object instance "
            "(used together with owner_content_type)."
        ),
    )
    owner_object_id: Optional[str] = Field(
        None,
        description="UUID of the owning object instance when identified by UUID.",
    )
    weight: Optional[int] = Field(
        None,
        description=(
            "Numeric priority weight of the config context. "
            "Higher values take precedence when multiple contexts apply to the same device."
        ),
    )
    description: Optional[str] = Field(
        None,
        description="Human-readable description of the config context.",
    )
    is_active: Optional[bool] = Field(
        None,
        description=(
            "Whether the config context is currently active. "
            "Inactive contexts are not rendered on devices."
        ),
    )
    data: Optional[str] = Field(
        None,
        description=(
            "The JSON data payload associated with the config context. "
            "Matched or returned as the serialised JSON body."
        ),
    )
    config_context_schema: Optional[str] = Field(
        None,
        description=(
            "Slug or UUID of the ConfigContextSchema used to validate "
            "this context's data payload."
        ),
    )

    # --- Timestamp fields ---
    created: Optional[str] = Field(
        None,
        description=(
            "ISO 8601 creation date/time of the config context "
            "(e.g. '2024-01-15' or '2024-01-15T10:30:00Z')."
        ),
    )
    last_updated: Optional[str] = Field(
        None,
        description=(
            "ISO 8601 date/time the config context was last modified "
            "(e.g. '2024-06-01T00:00:00Z')."
        ),
    )


# class ListConfigContextsParams(BaseModel):
#     id: Optional[str] = Field(None, description="ConfigContext ID or UUID.")
#     name: Optional[str] = Field(None, description="Filter by config_context name.")
#     query: Optional[str] = Field(None, description="General search query.")
#     limit: int = Field(5, description="Maximum number of config_contexts to return.")


# class GetConfigContextParams(BaseModel):
#     id: Optional[str] = Field(None, description="ConfigContext ID or UUID.")
#     query: Optional[str] = Field(None, description="General search query.")
#     name: Optional[str] = Field(None, description="ConfigContext name.")


PLAIN_FIELDS: List[str] = CONFIG_CONTEXTS_PLAIN_FIELDS
RELATION_FIELDS: List[str] = CONFIG_CONTEXTS_RELATION_FIELDS
MULTI_RELATION_FIELDS: List[str] = CONFIG_CONTEXTS_MULTI_RELATION_FIELDS


def list_config_contexts(api: pynautobot.core.api.Api, params: ListConfigContextsParams) -> Dict[str, Any]:
    return list_tools(
        api=api,
        endpoint=api.extras.config_contexts,
        params=params,
        plain_fields=PLAIN_FIELDS,
        relation_fields=RELATION_FIELDS,
        multi_relation_fields=MULTI_RELATION_FIELDS,
        result_key="config_contexts",
        limit=getattr(params, "limit", 5),
    )


def get_config_context(api: pynautobot.core.api.Api, params: GetConfigContextParams) -> Dict[str, Any]:
    return get_tools(
        api=api,
        endpoint=api.extras.config_contexts,
        params=params,
        plain_fields=PLAIN_FIELDS,
        relation_fields=RELATION_FIELDS,
        multi_relation_fields=MULTI_RELATION_FIELDS,
        result_key="config_contexts",
        lookup_fields=['id', 'name'],
    )

def count_config_context(api: pynautobot.core.api.Api, params: ListConfigContextsParams) -> Dict[str, Any]:
    return count_tools(
        endpoint=api.extras.config_contexts,
        params=params,
        resource_name="config_contexts",
    )
