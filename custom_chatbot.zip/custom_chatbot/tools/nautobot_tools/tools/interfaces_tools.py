"""
Nautobot DCIM interface helpers for MCP server.

Provides simple CRUD helpers for Nautobot DCIM interfaces. Functions accept a
configured `pynautobot` API instance and Pydantic param models and return
JSON-serializable dicts with a common envelope.

Example responses mirror Nautobot's interface representation (id, name,
display, description, device, status, role, type, etc.).
"""
from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

import pynautobot
from pydantic import BaseModel, Field

from .nautobot_fields_actual import INTERFACES_PLAIN_FIELDS, INTERFACES_RELATION_FIELDS, INTERFACES_MULTI_RELATION_FIELDS
from .nautobot_relation_utils import list_tools, count_tools, get_tools

logger = logging.getLogger(__name__)


class ListInterfacesParams(BaseModel):
    """Parameters for listing interfaces."""
    id: Optional[str] = Field(None, description="Interface primary key/UUID.")
    cf_interface_type: Optional[str] = Field(
    None,
    description=(
       "Filter by interface classification type (custom field). "
        "IMPORTANT: Use this field whenever the user asks about 'logical interfaces', "
        "'physical interfaces', or 'other interfaces'. "
        "Accepted values (case-sensitive): "
        "  'physical' — hardware ports (Ethernet, GigabitEthernet, TenGig, SFP, etc.), "
        "  'logical'  — software-defined interfaces (Loopback, Vlan, Tunnel, Port-channel, "
        "               Bundle-Ether, ae, irb, subinterfaces with '.' suffix), "
        "  'other'    — interfaces that don't fit physical or logical. "
        "Examples: user says 'logical interfaces' → cf_interface_type='logical'; "
        "          user says 'physical ports' → cf_interface_type='physical'."
    ),
    )
    name: Optional[str] = Field(None, description="Interface name to retrieve.")
    # name: Optional[str] = Field(None, description="Interface name to filter by. "
    #     "Physical interfaces typically begin with: 'Ethernet', 'Gi', 'TenGig', 'FortyGig', 'HundredGig','TwentyFiveGig' "
    #     "'xe-', 'ge-', 'et-', or 'mgmt' (e.g. 'GigabitEthernet0/0', 'xe-0/0/0', 'mgmt0'). "
    #     "Logical/virtual interfaces typically begin with: 'Loopback', 'Vlan', 'Tunnel', "
    #     "'Port-channel', 'Bundle-Ether', 'ae', 'irb', 'bdi', or contain a '.' denoting a subinterface "
    #     "(e.g. 'Loopback0', 'Vlan100', 'ae1', ). "
    #     "Use the exact interface name for precise lookup, or combine with 'query' for a contains-based search.")
    device: Optional[str] = Field(None, description="Filter by device name or ID (best-effort).")
    status: Optional[str] = Field(None, description="Filter by status slug or name (best-effort).")
    role: Optional[str] = Field(None, description="Filter by role slug or name (best-effort).")
    type: Optional[str] = Field(
        None,
        description=(
            "Filter by interface type slug (best-effort). "
            "Common values: '1000base-t', '10gbase-x-sfpp', 'lag', 'virtual', 'bridge', etc."
        ),
    )
    enabled: Optional[bool] = Field(
        None,
        description=(
            "Filter by whether the interface is administratively enabled (True) or disabled (False). "
            "Maps to the 'enabled' boolean field on the Interface object."
        ),
    )
    tags: Optional[str] = Field(None, description="Filter by tag slug/name.")
    mgmt_only: Optional[bool] = Field(
        None,
        description=(
            "Filter by mgmt_only status. "
            "When True, returns only out-of-band management interfaces; "
            "when False, returns only in-band interfaces."
        ),
    )
    query: Optional[str] = Field(None, description="Case-insensitive contains filter on interface name.")
    ip_addresses: Optional[str] = Field(None, description="IP address to retrieve, e.g. '1.1.1.1/32'.")
    limit: Optional[int] = Field(5, description="Maximum number of interface to return.")
     # --- Parameters added from the extended field list ---
    display: Optional[str] = Field(
        None,
        description=(
            "Filter by the human-readable display name of the interface as rendered by Nautobot "
            "(typically '<device> : <interface name>'). Useful for exact-match lookups when the "
            "full display string is known."
        ),
    )
    label: Optional[str] = Field(
        None,
        description=(
            "Filter by the operator-assigned physical label printed on or near the port "
            "(e.g. a patch-panel label or silk-screen identifier). "
            "Distinct from 'name', which is the logical interface identifier."
        ),
    )
    mtu: Optional[int] = Field(
        None,
        description=(
            "Filter by Maximum Transmission Unit (MTU) size in bytes configured on the interface. "
            "Common values: 1500 (standard Ethernet), 9000 (jumbo frames). "
            "Returns interfaces whose MTU exactly matches the supplied integer."
        ),
    )
    description: Optional[str] = Field(
        None,
        description=(
            "Filter by the free-text description field on the interface. "
            "Performs a case-insensitive contains match, useful for finding interfaces "
            "annotated with circuit IDs, peer names, or service tags."
        ),
    )
    mac_address: Optional[str] = Field(
        None,
        description=(
            "Filter by the MAC address assigned to the interface. "
            "Accepts standard colon-separated notation (e.g. 'AA:BB:CC:DD:EE:FF'). "
            "Returns interfaces whose burned-in or configured MAC matches the supplied value."
        ),
    )
    mode: Optional[str] = Field(
        None,
        description=(
            "Filter by the Layer 2 switchport mode of the interface. "
            "Accepted values: 'access' (untagged single VLAN), "
            "'tagged' (802.1Q trunk carrying multiple VLANs), "
            "'tagged-all' (trunk allowing all VLANs). "
            "Leave unset for routed/Layer 3 interfaces that have no switchport mode."
        ),
    )


class GetInterfaceParams(BaseModel):
    """Parameters for getting a single interface."""

    id: Optional[str] = Field(None, description="Interface primary key/UUID.")
    cf_interface_type: Optional[str] = Field(
    None,
    description=(
        "Filter by interface classification type (custom field). "
        "IMPORTANT: Use this field whenever the user asks about 'logical interfaces', "
        "'physical interfaces', or 'other interfaces'. "
        "Accepted values (case-sensitive): "
        "  'physical' — hardware ports (Ethernet, GigabitEthernet, TenGig, SFP, etc.), "
        "  'logical'  — software-defined interfaces (Loopback, Vlan, Tunnel, Port-channel, "
        "               Bundle-Ether, ae, irb, subinterfaces with '.' suffix), "
        "  'other'    — interfaces that don't fit physical or logical. "
        "Examples: user says 'logical interfaces' → cf_interface_type='logical'; "
        "          user says 'physical ports' → cf_interface_type='physical'."
    ),
    )
    name: Optional[str] = Field(None, description="Interface name to retrieve.")
    # name: Optional[str] = Field(None, description="Interface name to filter by. "
    #     "Physical interfaces typically begin with: 'Ethernet', 'Gi', 'TenGig', 'FortyGig', 'HundredGig','TwentyFiveGig' "
    #     "'xe-', 'ge-', 'et-', or 'mgmt' (e.g. 'GigabitEthernet0/0', 'xe-0/0/0', 'mgmt0'). "
    #     "Logical/virtual interfaces typically begin with: 'Loopback', 'Vlan', 'Tunnel', "
    #     "'Port-channel', 'Bundle-Ether', 'ae', 'irb', 'bdi', or contain a '.' denoting a subinterface "
    #     "(e.g. 'Loopback0', 'Vlan100', 'ae1', ). "
    #     "Use the exact interface name for precise lookup, or combine with 'query' for a contains-based search.")
    device: Optional[str] = Field(None, description="Device name/ID to scope the name lookup.")
    ip_addresses: Optional[str] = Field(None, description="IP address to retrieve, e.g. '1.1.1.1/32'.")
    mgmt_only: Optional[bool] = Field(None, description="Filter by mgmt_only status.")
    query: Optional[str] = Field(None, description="Case-insensitive contains filter on interface name.")
    status: Optional[str] = Field(None, description="Filter by status slug or name (best-effort).")
    role: Optional[str] = Field(None, description="Filter by role slug or name (best-effort).")
    type: Optional[str] = Field(
        None,
        description=(
            "Filter by interface type slug (best-effort). "
            "Common values: '1000base-t', '10gbase-x-sfpp', 'lag', 'virtual', 'bridge', etc."
        ),
    )
    enabled: Optional[bool] = Field(
        None,
        description=(
            "Filter by whether the interface is administratively enabled (True) or disabled (False) otherwise configured or up intercaes "
            "Maps to the 'enabled' boolean field on the Interface object."
        ),
    )
    # enabled: Optional[bool] = Field(None, description="Filter by enabled or up interfaces or configured status.")
    tags: Optional[str] = Field(None, description="Filter by tag slug/name.")
     # --- Parameters added from the extended field list ---
    display: Optional[str] = Field(
        None,
        description=(
            "Filter by the human-readable display name of the interface as rendered by Nautobot "
            "(typically '<device> : <interface name>'). Useful for exact-match lookups when the "
            "full display string is known."
        ),
    )
    label: Optional[str] = Field(
        None,
        description=(
            "Filter by the operator-assigned physical label printed on or near the port "
            "(e.g. a patch-panel label or silk-screen identifier). "
            "Distinct from 'name', which is the logical interface identifier."
        ),
    )
    mtu: Optional[int] = Field(
        None,
        description=(
            "Filter by Maximum Transmission Unit (MTU) size in bytes configured on the interface. "
            "Common values: 1500 (standard Ethernet), 9000 (jumbo frames). "
            "Returns interfaces whose MTU exactly matches the supplied integer."
        ),
    )
    description: Optional[str] = Field(
        None,
        description=(
            "Filter by the free-text description field on the interface. "
            "Performs a case-insensitive contains match, useful for finding interfaces "
            "annotated with circuit IDs, peer names, or service tags."
        ),
    )
    mac_address: Optional[str] = Field(
        None,
        description=(
            "Filter by the MAC address assigned to the interface. "
            "Accepts standard colon-separated notation (e.g. 'AA:BB:CC:DD:EE:FF'). "
            "Returns interfaces whose burned-in or configured MAC matches the supplied value."
        ),
    )
    mode: Optional[str] = Field(
        None,
        description=(
            "Filter by the Layer 2 switchport mode of the interface. "
            "Accepted values: 'access' (untagged single VLAN), "
            "'tagged' (802.1Q trunk carrying multiple VLANs), "
            "'tagged-all' (trunk allowing all VLANs). "
            "Leave unset for routed/Layer 3 interfaces that have no switchport mode."
        ),
    )


PLAIN_FIELDS: List[str] = INTERFACES_PLAIN_FIELDS
RELATION_FIELDS: List[str] = INTERFACES_RELATION_FIELDS
MULTI_RELATION_FIELDS: List[str] = INTERFACES_MULTI_RELATION_FIELDS
INTERFACE_CUSTOM_FIELD_KEYS: List[str] = [
    "interface_type",
    "last_synced",
    "last_synced_from_sor",
    "system_of_record",
]


def list_interfaces(api: pynautobot.core.api.Api, params: ListInterfacesParams) -> Dict[str, Any]:
    """
    List interfaces matching the given filters.
    
    To list logical interfaces: set cf_interface_type='logical'.
    To list physical interfaces: set cf_interface_type='physical'.
    Always set 'device' to scope results to a specific device.
    """
    return list_tools(
        api=api,
        endpoint=api.dcim.interfaces,
        params=params,
        plain_fields=PLAIN_FIELDS,
        relation_fields=RELATION_FIELDS,
        multi_relation_fields=MULTI_RELATION_FIELDS,
        custom_field_keys=INTERFACE_CUSTOM_FIELD_KEYS,
        result_key="interfaces",
        limit=getattr(params, "limit", 5),
    )


def count_interfaces(api: pynautobot.core.api.Api, params: ListInterfacesParams) -> Dict[str, Any]:
    """
    Count interfaces matching the given filters.
    
    To count logical interfaces: set cf_interface_type='logical'.
    To count physical interfaces: set cf_interface_type='physical'.
    Always set 'device' to scope results to a specific device.
    """
    return count_tools(
        endpoint=api.dcim.interfaces,
        params=params,
        resource_name="interfaces",
    )


def get_interface(api: pynautobot.core.api.Api, params: GetInterfaceParams) -> Dict[str, Any]:
    return get_tools(
        api=api,
        endpoint=api.dcim.interfaces,
        params=params,
        plain_fields=PLAIN_FIELDS,
        relation_fields=RELATION_FIELDS,
        multi_relation_fields=MULTI_RELATION_FIELDS,
        custom_field_keys=INTERFACE_CUSTOM_FIELD_KEYS,
        result_key="interfaces",
        lookup_fields=['id', 'name',"ip_addresses"],
    )
