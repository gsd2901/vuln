"""
Nautobot Tenancy tenant helpers for MCP server.

Provides simple CRUD helpers for Nautobot Tenancy tenants.
"""
from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

import pynautobot
from pydantic import BaseModel, Field

from .nautobot_fields_actual import TENANTS_PLAIN_FIELDS, TENANTS_RELATION_FIELDS, TENANTS_MULTI_RELATION_FIELDS
from .nautobot_relation_utils import list_tools, count_tools, get_tools

logger = logging.getLogger(__name__)


class ListTenantsParams(BaseModel):
    name: Optional[str] = Field(None, description="Filter by tenant name.")
    tenant_group: Optional[str] = Field(None, description="Filter by tenant group name/slug/ID.")
    tags: Optional[str] = Field(None, description="Filter by tag name/slug.")
    contacts: Optional[str] = Field(None, description="Filter by contacts (best-effort derived value).")
    teams: Optional[str] = Field(None, description="Filter by teams (best-effort derived value).")
    query: Optional[str] = Field(None, description="General search query.")
    limit: int = Field(5, description="Maximum number of tenants to return.")


class GetTenantParams(BaseModel):
    id: Optional[str] = Field(None, description="Tenant ID or UUID.")
    name: Optional[str] = Field(None, description="Tenant name.")


PLAIN_FIELDS: List[str] = TENANTS_PLAIN_FIELDS
RELATION_FIELDS: List[str] = TENANTS_RELATION_FIELDS
MULTI_RELATION_FIELDS: List[str] = TENANTS_MULTI_RELATION_FIELDS


def list_tenants(api: pynautobot.core.api.Api, params: ListTenantsParams) -> Dict[str, Any]:
    return list_tools(
        api=api,
        endpoint=api.tenancy.tenants,
        params=params,
        plain_fields=PLAIN_FIELDS,
        relation_fields=RELATION_FIELDS,
        multi_relation_fields=MULTI_RELATION_FIELDS,
        result_key="tenants",
        limit=getattr(params, "limit", 5),
    )


def get_tenant(api: pynautobot.core.api.Api, params: GetTenantParams) -> Dict[str, Any]:
    return get_tools(
        api=api,
        endpoint=api.tenancy.tenants,
        params=params,
        plain_fields=PLAIN_FIELDS,
        relation_fields=RELATION_FIELDS,
        multi_relation_fields=MULTI_RELATION_FIELDS,
        result_key="tenants",
        lookup_fields=['id', 'name'],
    )
def count_tenant(api: pynautobot.core.api.Api, params: ListTenantsParams) -> Dict[str, Any]:
    return count_tools(
        endpoint=api.tenancy.tenants,
        params=params,
        resource_name="tenants",
    )
