
import logging
from typing import Any, Dict, List, Optional
import requests
import pynautobot
from pydantic import BaseModel, Field

from .nautobot_fields_actual import DEVICE_TYPES_PLAIN_FIELDS, DEVICE_TYPES_RELATION_FIELDS, DEVICE_TYPES_MULTI_RELATION_FIELDS
from .nautobot_relation_utils import list_tools, count_tools, get_tools,_get_token
from .device_types_tools import get_device_type, GetDeviceTypeParams
import pynautobot

api = pynautobot.api(url="http://127.0.0.1:8080", token="d688ad08c85b15fa98b5cb8a0743b2f95157792b")
result = get_device_type(api, GetDeviceTypeParams(model="Cisco C9300-24P"))

print(result["device_types"].get("u_height"))   # should print 3 (or whatever the real value is)