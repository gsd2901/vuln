"""
Nautobot IPAM prefix helpers for MCP server.

Provides simple CRUD helpers for Nautobot IPAM prefixes. Functions accept a
configured `pynautobot` API instance and Pydantic param models and return
JSON-serializable dicts with a common envelope.

Example responses mirror Nautobot's prefix representation (id, prefix,
display, description, status, role, namespace, etc.).
"""
from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

import pynautobot
from pydantic import BaseModel, Field

from .nautobot_fields_actual import PREFIXES_PLAIN_FIELDS, PREFIXES_RELATION_FIELDS, PREFIXES_MULTI_RELATION_FIELDS
from .nautobot_relation_utils import list_tools, count_tools, get_tools

logger = logging.getLogger(__name__)


class ListPrefixesParams(BaseModel):
    # ── Identity / core ────────────────────────────────────────────────────────
    id: Optional[str] = Field(
        None,
        description=(
            "Filter by the prefix's primary key (UUID). "
            "Returns the single prefix whose UUID matches exactly."
        ),
    )
    prefix: Optional[str] = Field(
        None,
        description=(
            "Exact prefix CIDR string to match (e.g. '10.0.0.0/8'). "
            "Must include the mask length."
        ),
    )
    type: Optional[str] = Field(
        None,
        description=(
            "Filter by prefix type. "
            "Accepted values: 'container', 'network', 'pool'."
        ),
    )
    network: Optional[str] = Field(
        None,
        description=(
            "Filter by the network address portion of the prefix "
            "(e.g. '10.0.0.0'). Does not include the mask length."
        ),
    )
    broadcast: Optional[str] = Field(
        None,
        description=(
            "Filter by the broadcast address of the prefix "
            "(e.g. '10.255.255.255'). Useful for IPv4 subnets."
        ),
    )
    prefix_length: Optional[int] = Field(
        None,
        description=(
            "Filter by prefix length (CIDR mask). "
            "Integer between 0–32 for IPv4 or 0–128 for IPv6."
        ),
    )
    ip_version: Optional[int] = Field(
        None,
        description="Filter by IP version. Accepted values: 4 (IPv4) or 6 (IPv6).",
    )
    date_allocated: Optional[str] = Field(
        None,
        description=(
            "Filter by the date the prefix was allocated. "
            "ISO-8601 date string (e.g. '2024-01-15')."
        ),
    )
    description: Optional[str] = Field(
        None,
        description=(
            "Case-insensitive substring filter on the prefix's free-text "
            "description field."
        ),
    )

    # ── Relationships ──────────────────────────────────────────────────────────
    role: Optional[str] = Field(
        None,
        description=(
            "Filter by the role assigned to this prefix. "
            "Accepts role slug or name (best-effort match)."
        ),
    )
    parent: Optional[str] = Field(
        None,
        description=(
            "Filter by the parent prefix CIDR or UUID. "
            "Returns all direct children of the specified parent prefix."
        ),
    )
    tenant: Optional[str] = Field(
        None,
        description=(
            "Filter by the owning tenant. "
            "Accepts tenant slug or name (best-effort match)."
        ),
    )
    tenant_group: Optional[str] = Field(
        None,
        description=(
            "Filter by the tenant group that owns this prefix. "
            "Accepts tenant-group slug or name (best-effort match)."
        ),
    )
    vlan: Optional[str] = Field(
        None,
        description=(
            "Filter by the associated VLAN. "
            "Accepts VLAN ID (VID), name, or UUID."
        ),
    )
    rir: Optional[str] = Field(
        None,
        description=(
            "Filter by the Regional Internet Registry (RIR) responsible for "
            "this prefix (e.g. 'ARIN', 'RIPE'). "
            "Accepts RIR slug or name (best-effort match)."
        ),
    )
    namespace: Optional[str] = Field(
        None,
        description=(
            "Filter by the IPAM namespace this prefix belongs to. "
            "Accepts namespace slug or name (best-effort match)."
        ),
    )
    locations: Optional[str] = Field(
        None,
        description=(
            "Filter by one or more associated locations. "
            "Comma-separated slugs, names, or UUIDs (best-effort match)."
        ),
    )
    location: Optional[str] = Field(
        None,
        description="Filter by a single location slug, name, or UUID.",
    )
    tags: Optional[str] = Field(
        None,
        description=(
            "Filter by one or more tags applied to the prefix. "
            "Comma-separated tag slugs or names."
        ),
    )
    vrfs: Optional[str] = Field(
        None,
        description=(
            "Filter by one or more associated VRFs. "
            "Comma-separated VRF names, route-distinguishers, or UUIDs."
        ),
    )
    vrf: Optional[str] = Field(
        None,
        description=(
            "Filter by a single VRF slug, name, or UUID."
        ),
    )
    present_in_vrf: Optional[str] = Field(
        None,
        description=(
            "Return only prefixes that are present (reachable) within the "
            "specified VRF. Accepts VRF name or UUID (best-effort)."
        ),
    )

    # ── Timestamps ─────────────────────────────────────────────────────────────
    created: Optional[str] = Field(
        None,
        description=(
            "Filter by the date/time the prefix record was created in Nautobot. "
            "ISO-8601 datetime string (e.g. '2024-01-15T00:00:00Z')."
        ),
    )
    last_updated: Optional[str] = Field(
        None,
        description=(
            "Filter by the date/time the prefix record was last modified. "
            "ISO-8601 datetime string (e.g. '2024-06-01T12:00:00Z')."
        ),
    )

    # ── Lifecycle / state ──────────────────────────────────────────────────────
    status: Optional[str] = Field(
        None,
        description=(
            "Filter by prefix lifecycle status. "
            "Accepts status slug or name (e.g. 'active', 'reserved', 'deprecated')."
        ),
    )

    # ── Search / pagination ────────────────────────────────────────────────────
    query: Optional[str] = Field(
        None,
        description=(
            "Case-insensitive substring filter applied across searchable "
            "prefix fields (prefix string, description, etc.)."
        ),
    )
    limit: int = Field(
        5,
        description=(
            "Maximum number of prefix records to return in a single response. "
            "Defaults to 5; increase for bulk lookups."
        ),
    )


class GetPrefixParams(BaseModel):
    query: Optional[str] = Field(None, description="Case-insensitive contains filter on prefix.")
    limit: Optional[int] = Field(default=None, description="Maximum number of prefixes to return.")
    id: Optional[str] = Field(
        None,
        description=(
            "Primary key (UUID) of the prefix to retrieve. "
            "When provided, returns the exact prefix record with that UUID."
        ),
    )
    prefix: Optional[str] = Field(
        None,
        description=(
            "Exact CIDR prefix string to look up (e.g. '192.168.1.0/24'). "
            "Must include the mask length. "
            "Used as a fallback identifier when 'id' is not supplied."
        ),
    )
    network: Optional[str] = Field(
        None,
        description=(
            "Network address portion of the prefix to look up "
            "(e.g. '192.168.1.0'). "
            "Combine with 'prefix_length' for an unambiguous lookup."
        ),
    )
    broadcast: Optional[str] = Field(
        None,
        description=(
            "Broadcast address of the prefix (e.g. '192.168.1.255'). "
            "Can help disambiguate overlapping subnets in the same namespace."
        ),
    )
    prefix_length: Optional[int] = Field(
        None,
        description=(
            "CIDR mask length of the prefix to retrieve "
            "(0–32 for IPv4, 0–128 for IPv6). "
            "Combine with 'network' for an unambiguous lookup."
        ),
    )
    ip_version: Optional[int] = Field(
        None,
        description=(
            "IP version of the prefix: 4 for IPv4 or 6 for IPv6. "
            "Useful when 'network' alone is ambiguous."
        ),
    )
    date_allocated: Optional[str] = Field(
        None,
        description=(
            "Allocation date of the target prefix. "
            "ISO-8601 date string (e.g. '2024-01-15'). "
            "Narrows results when multiple prefixes share the same CIDR."
        ),
    )
    description: Optional[str] = Field(
        None,
        description=(
            "Free-text description of the prefix. "
            "Used as a supplementary filter when other identifiers are broad."
        ),
    )
    type: Optional[str] = Field(
        None,
        description=(
            "Prefix type to match: 'container', 'network', or 'pool'. "
            "Helps narrow lookups when CIDR alone is not unique."
        ),
    )
    role: Optional[str] = Field(
        None,
        description=(
            "Role slug or name assigned to this prefix "
            "(e.g. 'loopback', 'infrastructure'). "
            "Supplementary filter for disambiguation."
        ),
    )
    parent: Optional[str] = Field(
        None,
        description=(
            "Parent prefix CIDR or UUID. "
            "Restricts the lookup to prefixes that are direct children of the "
            "specified parent."
        ),
    )
    tenant: Optional[str] = Field(
        None,
        description=(
            "Tenant slug or name that owns the prefix. "
            "Supplementary filter to disambiguate prefixes shared across tenants."
        ),
    )
    vlan: Optional[str] = Field(
        None,
        description=(
            "VLAN VID, name, or UUID associated with this prefix. "
            "Useful when looking up a prefix tied to a specific Layer 2 segment."
        ),
    )
    rir: Optional[str] = Field(
        None,
        description=(
            "Regional Internet Registry (RIR) slug or name responsible for "
            "this prefix (e.g. 'ARIN', 'RIPE'). "
            "Supplementary filter for public address space lookups."
        ),
    )
    created: Optional[str] = Field(
        None,
        description=(
            "Creation timestamp of the prefix record in Nautobot. "
            "ISO-8601 datetime string. Supplementary disambiguation filter."
        ),
    )
    last_updated: Optional[str] = Field(
        None,
        description=(
            "Last-modified timestamp of the prefix record. "
            "ISO-8601 datetime string. Supplementary disambiguation filter."
        ),
    )
    status: Optional[str] = Field(
        None,
        description=(
            "Lifecycle status slug or name of the prefix "
            "(e.g. 'active', 'reserved', 'deprecated'). "
            "Supplementary filter for disambiguation."
        ),
    )
    namespace: Optional[str] = Field(
        None,
        description=(
            "IPAM namespace slug or name this prefix belongs to. "
            "Critical for disambiguating identical CIDRs that exist in "
            "different namespaces."
        ),
    )
    locations: Optional[str] = Field(
        None,
        description=(
            "Comma-separated location slugs, names, or UUIDs associated with "
            "this prefix. Supplementary filter for site-scoped lookups."
        ),
    )
    tags: Optional[str] = Field(
        None,
        description=(
            "Comma-separated tag slugs or names applied to the prefix. "
            "Supplementary filter to scope lookups by operational tag."
        ),
    )
    vrfs: Optional[str] = Field(
        None,
        description=(
            "Comma-separated VRF names, route-distinguishers, or UUIDs "
            "associated with this prefix. "
            "Supplementary filter for multi-VRF environments."
        ),
    )



# class ListPrefixesParams(BaseModel):
#     type: Optional[str] = Field(None, description="Filter by prefix type.")
#     ip_version: Optional[int] = Field(None, description="Filter by IP version (4 or 6).")
#     prefix_length: Optional[int] = Field(None, description="Filter by prefix length.")
#     present_in_vrf: Optional[str] = Field(None, description="Filter by present-in-VRF (best-effort).")
#     locations: Optional[str] = Field(None, description="Filter by associated locations (best-effort).")
#     tenant_group: Optional[str] = Field(None, description="Filter by tenant group slug/name (best-effort).")
#     rir: Optional[str] = Field(None, description="Filter by RIR (best-effort).")
#     namespace: Optional[str] = Field(None, description="Namespace slug or name (best-effort).")
#     tenant: Optional[str] = Field(None, description="Tenant slug/name (best-effort).")
#     status: Optional[str] = Field(None, description="Status slug or name (best-effort).")
#     location: Optional[str] = Field(None, description="Filter by location slug/name/ID.")
#     vrf: Optional[str] = Field(None, description="Filter by vrf slug/name/ID.")
#     role: Optional[str] = Field(None, description="Role slug or name (best-effort).")
#     tags: Optional[str] = Field(None, description="Filter by tag slug/name.")
#     prefix: Optional[str] = Field(None, description="Prefix string to match (e.g. 10.0.0.0/8).")
#     query: Optional[str] = Field(None, description="Case-insensitive contains filter on prefix.")
#     limit: int = Field(5, description="Maximum number of prefixes to return.")


# class GetPrefixParams(BaseModel):
#     id: Optional[str] = Field(None, description="Prefix primary key/UUID.")
#     prefix: Optional[str] = Field(None, description="Prefix string (e.g. 10.0.0.0/8).")


PLAIN_FIELDS: List[str] = PREFIXES_PLAIN_FIELDS
RELATION_FIELDS: List[str] = PREFIXES_RELATION_FIELDS
MULTI_RELATION_FIELDS: List[str] = PREFIXES_MULTI_RELATION_FIELDS


def list_prefixes(api: pynautobot.core.api.Api, params: ListPrefixesParams) -> Dict[str, Any]:
    return list_tools(
        api=api,
        endpoint=api.ipam.prefixes,
        params=params,
        plain_fields=PLAIN_FIELDS,
        relation_fields=RELATION_FIELDS,
        multi_relation_fields=MULTI_RELATION_FIELDS,
        result_key="prefixes",
        limit=getattr(params, "limit", 5),
    )


def count_prefixes(api: pynautobot.core.api.Api, params: ListPrefixesParams) -> Dict[str, Any]:
    return count_tools(
        endpoint=api.ipam.prefixes,
        params=params,
        resource_name="prefixes",
    )


def get_prefix(api: pynautobot.core.api.Api, params: GetPrefixParams) -> Dict[str, Any]:
    return get_tools(
        api=api,
        endpoint=api.ipam.prefixes,
        params=params,
        plain_fields=PLAIN_FIELDS,
        relation_fields=RELATION_FIELDS,
        multi_relation_fields=MULTI_RELATION_FIELDS,
        result_key="prefixes",
        lookup_fields=['id', 'prefix'],
    )
