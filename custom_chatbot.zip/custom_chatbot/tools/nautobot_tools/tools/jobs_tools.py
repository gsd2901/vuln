"""
Nautobot Extras job helpers for MCP server.

Provides simple CRUD helpers for Nautobot Extras jobs.
"""
from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

import pynautobot
from pydantic import BaseModel, Field

from .nautobot_fields_actual import JOBS_PLAIN_FIELDS, JOBS_RELATION_FIELDS, JOBS_MULTI_RELATION_FIELDS
from .nautobot_relation_utils import list_tools, count_tools, get_tools

logger = logging.getLogger(__name__)


class ListJobsParams(BaseModel):
    name: Optional[str] = Field(None, description="Filter by job name.")
    query: Optional[str] = Field(None, description="General search query.")
    limit: int = Field(5, description="Maximum number of jobs to return.")


class GetJobParams(BaseModel):
    id: Optional[str] = Field(None, description="Job ID or UUID.")
    name: Optional[str] = Field(None, description="Job name.")


PLAIN_FIELDS: List[str] = JOBS_PLAIN_FIELDS
RELATION_FIELDS: List[str] = JOBS_RELATION_FIELDS
MULTI_RELATION_FIELDS: List[str] = JOBS_MULTI_RELATION_FIELDS


def list_jobs(api: pynautobot.core.api.Api, params: ListJobsParams) -> Dict[str, Any]:
    return list_tools(
        api=api,
        endpoint=api.extras.jobs,
        params=params,
        plain_fields=PLAIN_FIELDS,
        relation_fields=RELATION_FIELDS,
        multi_relation_fields=MULTI_RELATION_FIELDS,
        result_key="jobs",
        limit=getattr(params, "limit", 5),
    )


def get_job(api: pynautobot.core.api.Api, params: GetJobParams) -> Dict[str, Any]:
    return get_tools(
        api=api,
        endpoint=api.extras.jobs,
        params=params,
        plain_fields=PLAIN_FIELDS,
        relation_fields=RELATION_FIELDS,
        multi_relation_fields=MULTI_RELATION_FIELDS,
        result_key="jobs",
        lookup_fields=['id', 'name'],
    )
def count_job(api: pynautobot.core.api.Api, params: ListJobsParams) -> Dict[str, Any]:
    return count_tools(
        endpoint=api.extras.jobs,
        params=params,
        resource_name="jobs",
    )
