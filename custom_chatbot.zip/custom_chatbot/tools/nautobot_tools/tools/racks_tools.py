"""
Nautobot DCIM rack helpers for MCP server.

Provides simple CRUD helpers for Nautobot DCIM racks. Functions accept a
configured `pynautobot` API instance and Pydantic param models and return
JSON-serializable dicts with a common envelope.

Example responses mirror Nautobot's rack representation (id, name, display,
location, status, role, tenant, u_height, width, etc.).
"""
from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

import pynautobot
from pydantic import BaseModel, Field

from .nautobot_fields_actual import RACKS_PLAIN_FIELDS, RACKS_RELATION_FIELDS, RACKS_MULTI_RELATION_FIELDS
from .nautobot_relation_utils import list_tools, count_tools, get_tools

logger = logging.getLogger(__name__)

class ListRacksParams(BaseModel):
    """Parameters for listing racks."""

    # --- Existing fields ---
    id: Optional[str] = Field(None, description="Rack primary key/UUID.")
    name: Optional[str] = Field(None, description="Rack name to filter by.")
    location: Optional[str] = Field(None, description="Filter by location name or ID (best-effort).")
    tenant_group: Optional[str] = Field(None, description="Filter by tenant group slug/name (best-effort).")
    status: Optional[str] = Field(None, description="Filter by status slug or name (best-effort).")
    role: Optional[str] = Field(None, description="Filter by role slug or name (best-effort).")
    type: Optional[str] = Field(None, description="Filter by rack type.")
    tags: Optional[str] = Field(None, description="Filter by tag slug/name.")
    width: Optional[str] = Field(
        None,
        description=(
            "Filter by rack width enum value. Represents the internal usable width of the rack "
            "in inches (e.g., '19' for a standard 19-inch rack, '23' for a 23-inch rack)."
        ),
    )
    tenant: Optional[str] = Field(None, description="Filter by tenant slug or name (best-effort).")
    rack_group: Optional[str] = Field(
        None,
        description=(
            "Filter by rack group slug or name (best-effort). Rack groups are used to logically "
            "organize racks within a location (e.g., a row or cage in a data center)."
        ),
    )
    query: Optional[str] = Field(None, description="Case-insensitive contains filter on rack name.")
    limit: int = Field(5, description="Maximum number of racks to return.")
    facility_id: Optional[str] = Field(
        None,
        description=(
            "Filter by the facility-assigned identifier for the rack. This is an external "
            "reference ID provided by the data center or colocation facility operator."
        ),
    )

    # --- New fields ---
    outer_unit: Optional[str] = Field(
        None,
        description=(
            "Filter by the unit of measurement used for the rack's outer dimensions. "
            "Accepted values are 'mm' (millimeters) or 'in' (inches)."
        ),
    )
    device_count: Optional[str] = Field(
        None,
        description=(
            "Filter by the number of devices currently installed in the rack. "
            "Can be used to find racks with a specific device population."
        ),
    )
    power_feed_count: Optional[str] = Field(
        None,
        description=(
            "Filter by the number of power feeds connected to the rack. "
            "Useful for identifying racks with a specific power redundancy configuration."
        ),
    )
    serial: Optional[str] = Field(
        None,
        description=(
            "Filter by the rack's serial number as assigned by the manufacturer. "
            "Typically used for asset tracking and hardware inventory purposes."
        ),
    )
    asset_tag: Optional[str] = Field(
        None,
        description=(
            "Filter by the rack's unique asset tag. This is an internal identifier "
            "used by the organization for inventory and asset management."
        ),
    )
    u_height: Optional[str] = Field(
        None,
        description=(
            "Filter by the total height of the rack measured in rack units (U). "
            "Common values are 42U (standard full-height) or 22U (half-height)."
        ),
    )
    desc_units: Optional[str] = Field(
        None,
        description=(
            "Filter by the rack unit numbering direction. If 'true' or enabled, rack units "
            "are numbered from top to bottom (descending); otherwise numbered bottom to top."
        ),
    )
    outer_width: Optional[str] = Field(
        None,
        description=(
            "Filter by the physical outer width of the rack enclosure, expressed in the unit "
            "defined by 'outer_unit'. Represents the total external width including the frame."
        ),
    )
    outer_depth: Optional[str] = Field(
        None,
        description=(
            "Filter by the physical outer depth of the rack enclosure, expressed in the unit "
            "defined by 'outer_unit'. Represents the total external depth including doors and frame."
        ),
    )
    comments: Optional[str] = Field(
        None,
        description=(
            "Filter or search by free-text comments associated with the rack. "
            "Comments may include installation notes, maintenance history, or operational remarks."
        ),
    )
    created: Optional[str] = Field(
        None,
        description=(
            "Filter by the date the rack record was created in Nautobot. "
            "Accepts ISO 8601 date format (e.g., '2024-01-15') or datetime string."
        ),
    )
    last_updated: Optional[str] = Field(
        None,
        description=(
            "Filter by the date and time the rack record was last modified in Nautobot. "
            "Accepts ISO 8601 datetime format (e.g., '2024-06-01T12:00:00Z')."
        ),
    )


class GetRackParams(BaseModel):
    """Parameters for getting a single rack."""

    # --- Existing fields ---
    id: Optional[str] = Field(None, description="Rack primary key/UUID.")
    name: Optional[str] = Field(None, description="Rack name to retrieve.")
    location: Optional[str] = Field(
        None,
        description="Retrieve by location name or ID (example: TN_MDU_SEZT1_1F_ITR_1).",
    )
    query: Optional[str] = Field(None, description="Case-insensitive contains filter on rack name or location.")
    facility_id: Optional[str] = Field(
        None,
        description=(
            "Rack facility ID to retrieve. This is the external reference identifier "
            "assigned by the data center or colocation facility operator."
        ),
    )
    tenant_group: Optional[str] = Field(None, description="Filter by tenant group slug/name (best-effort).")
    status: Optional[str] = Field(None, description="Filter by status slug or name (best-effort).")
    role: Optional[str] = Field(None, description="Filter by role slug or name (best-effort).")
    type: Optional[str] = Field(None, description="Filter by rack type.")
    tags: Optional[str] = Field(None, description="Filter by tag slug/name.")
    width: Optional[str] = Field(
        None,
        description=(
            "Filter by rack width enum value. Represents the internal usable width of the rack "
            "in inches (e.g., '19' for a standard 19-inch rack, '23' for a 23-inch rack)."
        ),
    )
    tenant: Optional[str] = Field(None, description="Filter by tenant slug or name (best-effort).")
    rack_group: Optional[str] = Field(
        None,
        description=(
            "Filter by rack group slug or name (best-effort). Rack groups are used to logically "
            "organize racks within a location (e.g., a row or cage in a data center)."
        ),
    )

    # --- New fields ---
    outer_unit: Optional[str] = Field(
        None,
        description=(
            "The unit of measurement for the rack's outer dimensions. "
            "Accepted values are 'mm' (millimeters) or 'in' (inches)."
        ),
    )
    device_count: Optional[str] = Field(
        None,
        description=(
            "The number of devices currently installed in this rack. "
            "Reflects the populated device inventory at the time of retrieval."
        ),
    )
    power_feed_count: Optional[str] = Field(
        None,
        description=(
            "The number of power feeds connected to this rack. "
            "Indicates the power circuit count for redundancy or capacity planning."
        ),
    )
    serial: Optional[str] = Field(
        None,
        description=(
            "The manufacturer-assigned serial number of the rack chassis. "
            "Used for warranty tracking and hardware asset management."
        ),
    )
    asset_tag: Optional[str] = Field(
        None,
        description=(
            "The organization's internal unique asset tag for this rack. "
            "Used for inventory audits and physical asset tracking."
        ),
    )
    u_height: Optional[str] = Field(
        None,
        description=(
            "The total usable height of the rack in rack units (U). "
            "Common values include 42U for full-height and 22U for half-height racks."
        ),
    )
    desc_units: Optional[str] = Field(
        None,
        description=(
            "Indicates the rack unit numbering direction. When enabled ('true'), units are "
            "numbered from top (U1 at top) to bottom; otherwise numbered from bottom to top."
        ),
    )
    outer_width: Optional[str] = Field(
        None,
        description=(
            "The total physical outer width of the rack enclosure in the unit specified by "
            "'outer_unit'. Includes the rack frame and any side panels or mounting brackets."
        ),
    )
    outer_depth: Optional[str] = Field(
        None,
        description=(
            "The total physical outer depth of the rack enclosure in the unit specified by "
            "'outer_unit'. Includes front and rear doors, cable management, and the frame."
        ),
    )
    comments: Optional[str] = Field(
        None,
        description=(
            "Free-text comments associated with the rack record. May contain installation notes, "
            "cabling remarks, maintenance history, or other operational information."
        ),
    )
    created: Optional[str] = Field(
        None,
        description=(
            "The date the rack record was originally created in Nautobot. "
            "Returned in ISO 8601 date format (e.g., '2024-01-15')."
        ),
    )
    last_updated: Optional[str] = Field(
        None,
        description=(
            "The date and time the rack record was last modified in Nautobot. "
            "Returned in ISO 8601 datetime format (e.g., '2024-06-01T12:00:00Z')."
        ),
    )


# class ListRacksParams(BaseModel):
#     """Parameters for listing racks."""
#     id: Optional[str] = Field(None, description="Rack primary key/UUID.")
#     name: Optional[str] = Field(None, description="Rack name to retrieve.")
#     location: Optional[str] = Field(None, description="Filter by location name or ID (best-effort).")
#     tenant_group: Optional[str] = Field(None, description="Filter by tenant group slug/name (best-effort).")
#     status: Optional[str] = Field(None, description="Filter by status slug or name (best-effort).")
#     role: Optional[str] = Field(None, description="Filter by role slug or name (best-effort).")
#     type: Optional[str] = Field(None, description="Filter by rack type.")
#     tags: Optional[str] = Field(None, description="Filter by tag slug/name.")
#     width: Optional[str] = Field(None, description="Filter by rack width enum value.")
#     tenant: Optional[str] = Field(None, description="Filter by tenant slug or name (best-effort).")
#     rack_group: Optional[str] = Field(None, description="Filter by rack group (best-effort).")
#     query: Optional[str] = Field(None, description="Case-insensitive contains filter on rack name.")
#     limit: int = Field(5, description="Maximum number of racks to return.")
#     facility_id: Optional[str] = Field(None, description="Rack facility ID to retrieve.")



# class GetRackParams(BaseModel):
#     """Parameters for getting a single rack."""
#     id: Optional[str] = Field(None, description="Rack primary key/UUID.")
#     name: Optional[str] = Field(None, description="Rack name to retrieve.")
#     location: Optional[str] = Field(None, description="retrieve location name or ID (example:TN_MDU_SEZT1_1F_ITR_1 ).")
#     query: Optional[str] = Field(None, description="Case-insensitive contains filter on rack name or location.")
#     facility_id: Optional[str] = Field(None, description="Rack facility ID to retrieve.")
#     tenant_group: Optional[str] = Field(None, description="Filter by tenant group slug/name (best-effort).")
#     status: Optional[str] = Field(None, description="Filter by status slug or name (best-effort).")
#     role: Optional[str] = Field(None, description="Filter by role slug or name (best-effort).")
#     type: Optional[str] = Field(None, description="Filter by rack type.")
#     tags: Optional[str] = Field(None, description="Filter by tag slug/name.")
#     width: Optional[str] = Field(None, description="Filter by rack width enum value.")
#     tenant: Optional[str] = Field(None, description="Filter by tenant slug or name (best-effort).")
#     rack_group: Optional[str] = Field(None, description="Filter by rack group (best-effort).")


PLAIN_FIELDS: List[str] = RACKS_PLAIN_FIELDS
RELATION_FIELDS: List[str] = RACKS_RELATION_FIELDS
MULTI_RELATION_FIELDS: List[str] = RACKS_MULTI_RELATION_FIELDS


def list_racks(api: pynautobot.core.api.Api, params: ListRacksParams) -> Dict[str, Any]:
    return list_tools(
        api=api,
        endpoint=api.dcim.racks,
        params=params,
        plain_fields=PLAIN_FIELDS,
        relation_fields=RELATION_FIELDS,
        multi_relation_fields=MULTI_RELATION_FIELDS,
        result_key="racks",
        limit=getattr(params, "limit", 5),
    )


def count_racks(api: pynautobot.core.api.Api, params: ListRacksParams) -> Dict[str, Any]:
    return count_tools(
        endpoint=api.dcim.racks,
        params=params,
        resource_name="racks",
    )


def get_rack(api: pynautobot.core.api.Api, params: GetRackParams) -> Dict[str, Any]:
    return get_tools(
        api=api,
        endpoint=api.dcim.racks,
        params=params,
        plain_fields=PLAIN_FIELDS,
        relation_fields=RELATION_FIELDS,
        multi_relation_fields=MULTI_RELATION_FIELDS,
        result_key="racks",
        lookup_fields=['id', 'name'],
    )
