"""
Nautobot Dcim manufacturer helpers for MCP server.

Provides simple CRUD helpers for Nautobot Dcim manufacturers.
"""
from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

import pynautobot
from pydantic import BaseModel, Field

from .nautobot_fields_actual import MANUFACTURERS_PLAIN_FIELDS, MANUFACTURERS_RELATION_FIELDS, MANUFACTURERS_MULTI_RELATION_FIELDS
from .nautobot_relation_utils import list_tools, count_tools, get_tools

logger = logging.getLogger(__name__)


class ListManufacturersParams(BaseModel):
    name: Optional[str] = Field(None, description="Filter by manufacturer name.")
    device_types: Optional[str] = Field(None, description="Filter by related device type name/model/ID.")
    platforms: Optional[str] = Field(None, description="Filter by related platform name/slug/ID.")
    query: Optional[str] = Field(None, description="General search query.")
    limit: int = Field(5, description="Maximum number of manufacturers to return.")


class GetManufacturerParams(BaseModel):
    id: Optional[str] = Field(None, description="Manufacturer ID or UUID.")
    name: Optional[str] = Field(None, description="Manufacturer name.")


PLAIN_FIELDS: List[str] = MANUFACTURERS_PLAIN_FIELDS
RELATION_FIELDS: List[str] = MANUFACTURERS_RELATION_FIELDS
MULTI_RELATION_FIELDS: List[str] = MANUFACTURERS_MULTI_RELATION_FIELDS


def list_manufacturers(api: pynautobot.core.api.Api, params: ListManufacturersParams) -> Dict[str, Any]:
    return list_tools(
        api=api,
        endpoint=api.dcim.manufacturers,
        params=params,
        plain_fields=PLAIN_FIELDS,
        relation_fields=RELATION_FIELDS,
        multi_relation_fields=MULTI_RELATION_FIELDS,
        result_key="manufacturers",
        limit=getattr(params, "limit", 5),
    )


def get_manufacturer(api: pynautobot.core.api.Api, params: GetManufacturerParams) -> Dict[str, Any]:
    return get_tools(
        api=api,
        endpoint=api.dcim.manufacturers,
        params=params,
        plain_fields=PLAIN_FIELDS,
        relation_fields=RELATION_FIELDS,
        multi_relation_fields=MULTI_RELATION_FIELDS,
        result_key="manufacturers",
        lookup_fields=['id', 'name'],
    )
def count_manufacturer(api: pynautobot.core.api.Api, params: ListManufacturersParams) -> Dict[str, Any]:
    return count_tools(
        endpoint=api.dcim.manufacturers,
        params=params,
        resource_name="manufacturers",
    )
