"""
Nautobot Extras job_result helpers for MCP server.

Provides simple CRUD helpers for Nautobot Extras job_results.
"""
from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

import pynautobot
from pydantic import BaseModel, Field

from .nautobot_fields_actual import JOB_RESULTS_PLAIN_FIELDS, JOB_RESULTS_RELATION_FIELDS, JOB_RESULTS_MULTI_RELATION_FIELDS
from .nautobot_relation_utils import list_tools, count_tools, get_tools

logger = logging.getLogger(__name__)


class ListJobResultsParams(BaseModel):
    name: Optional[str] = Field(None, description="Filter by job_result name.")
    query: Optional[str] = Field(None, description="General search query.")
    limit: int = Field(5, description="Maximum number of job_results to return.")


class GetJobResultParams(BaseModel):
    id: Optional[str] = Field(None, description="JobResult ID or UUID.")
    name: Optional[str] = Field(None, description="JobResult name.")


PLAIN_FIELDS: List[str] = JOB_RESULTS_PLAIN_FIELDS
RELATION_FIELDS: List[str] = JOB_RESULTS_RELATION_FIELDS
MULTI_RELATION_FIELDS: List[str] = JOB_RESULTS_MULTI_RELATION_FIELDS


def list_job_results(api: pynautobot.core.api.Api, params: ListJobResultsParams) -> Dict[str, Any]:
    return list_tools(
        api=api,
        endpoint=api.extras.job_results,
        params=params,
        plain_fields=PLAIN_FIELDS,
        relation_fields=RELATION_FIELDS,
        multi_relation_fields=MULTI_RELATION_FIELDS,
        result_key="job_results",
        limit=getattr(params, "limit", 5),
    )


def get_job_result(api: pynautobot.core.api.Api, params: GetJobResultParams) -> Dict[str, Any]:
    return get_tools(
        api=api,
        endpoint=api.extras.job_results,
        params=params,
        plain_fields=PLAIN_FIELDS,
        relation_fields=RELATION_FIELDS,
        multi_relation_fields=MULTI_RELATION_FIELDS,
        result_key="job_results",
        lookup_fields=['id', 'name'],
    )
def count_job_result(api: pynautobot.core.api.Api, params: ListJobResultsParams) -> Dict[str, Any]:
    return count_tools(
        endpoint=api.extras.job_results,
        params=params,
        resource_name="job_results",
    )
