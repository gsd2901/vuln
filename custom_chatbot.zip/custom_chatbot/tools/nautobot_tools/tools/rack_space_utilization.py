"""
Nautobot DCIM rack utilization helper for MCP server.

Calculates rack space utilization by:
  1. Calling get_rack() from rack_tools to resolve rack_uuid and rack_u_height.
  2. Fetching all raw device dicts in the rack via _raw_filter (preserves
     device_type.id UUID before pynautobot serialises it away).
  3. Resolving each unique device-type UUID once via direct REST call (dt_cache).
  4. Applying: utilization_pct = int((sum_of_u_heights / rack_u_height) * 100)
"""
from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

import requests
import pynautobot
from pydantic import BaseModel, Field

from .racks_tools import get_rack, GetRackParams
from .nautobot_relation_utils import _get_field, _get_token, _raw_filter

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Param model
# ---------------------------------------------------------------------------

class GetRackUtilizationParams(BaseModel):
    id: Optional[str] = Field(
        None,
        description="UUID of the rack to calculate utilization for.",
    )
    name: Optional[str] = Field(
        None,
        description="Name of the rack to calculate utilization for.",
    )
    location: Optional[str] = Field(
        None,
        description=(
            "Location slug/name to narrow the rack lookup when name alone "
            "may match multiple racks (e.g. 'TN_MDU_SEZT1_1F_ITR_1')."
        ),
    )
    facility_id: Optional[str] = Field(
        None,
        description="Facility-assigned rack ID to narrow the lookup.",
    )


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _fetch_devices_in_rack(
    api: pynautobot.core.api.Api,
    rack_uuid: str,
) -> List[Dict[str, Any]]:
    """
    Return raw device dicts for every device assigned to *rack_uuid*.

    _raw_filter signature: _raw_filter(api, endpoint, limit, filters)
    We pass api as first arg and api.dcim.devices as endpoint so the
    function can resolve the URL and token correctly.
    """
    # _raw_filter returns (results_list, total_count) — unpack accordingly.
    results, count = _raw_filter(
        api,                    # api  (position 0)
        api.dcim.devices,       # endpoint (position 1)
        500,                    # limit (position 2) — racks never exceed 500U
        {"rack": rack_uuid},    # filters (position 3)
    )
    logger.info(
        "_fetch_devices_in_rack: rack=%s  device_count=%d  api_total=%d",
        rack_uuid, len(results), count,
    )
    return results


def _fetch_device_type_u_height(
    api: pynautobot.core.api.Api,
    dt_uuid: str,
    token: str,
) -> int:
    """
    Fetch u_height for one device-type UUID via direct REST call.

    Mirrors the pattern used in _resolve_prefix_uuids (ip_address_tools.py):
    explicit Authorization header, empty proxy, 30 s timeout.
    """
    resp = requests.get(
        f"{api.base_url}/dcim/device-types/{dt_uuid}/",
        headers={
            "Authorization": f"Token {token}",
            "Content-Type": "application/json",
        },
        timeout=30,
        proxies={"http": "", "https": ""},
    )
    resp.raise_for_status()
    data = resp.json()
    u_height = int(data.get("u_height", 0))
    logger.info(
        "_fetch_device_type_u_height: dt_uuid=%s  model=%s  u_height=%d",
        dt_uuid, data.get("display", ""), u_height,
    )
    return u_height


# ---------------------------------------------------------------------------
# Public tool function
# ---------------------------------------------------------------------------

def get_rack_utilization(
    api: pynautobot.core.api.Api,
    params: GetRackUtilizationParams,
) -> Dict[str, Any]:
    """
    Calculate space utilization for a rack.

    Steps
    -----
    1. Call get_rack() (imported from rack_tools) with the supplied filters
       to resolve rack_uuid and rack_u_height.
    2. Fetch all raw device dicts via _raw_filter so device_type.id UUIDs
       are preserved.
    3. Build a dt_cache: for each unique device-type UUID make exactly one
       REST call to /dcim/device-types/{uuid}/ and cache its u_height.
    4. Sum u_heights across all devices and compute:
           utilization_pct = int((sum_u / rack_u_height) * 100)

    Returns
    -------
    {
        "success": bool,
        "message": str,
        "rack_name": str,
        "rack_u_height": int,
        "used_u": int,
        "free_u": int,
        "utilization_pct": int,        # e.g. 63  means 63 %
        "device_count": int,
        "device_type_breakdown": [
            {
                "device_type_id": str,
                "u_height": int,
                "count": int,
                "subtotal_u": int,
            },
            ...
        ],
    }
    """
    # ------------------------------------------------------------------
    # Step 1 — resolve rack via existing get_rack()
    # ------------------------------------------------------------------
    rack_params = GetRackParams(
        id=params.id,
        name=params.name,
        location=params.location,
        facility_id=params.facility_id,
    )
    rack_result = get_rack(api, rack_params)

    if not rack_result.get("success"):
        return {
            "success": False,
            "message": rack_result.get("message", "Rack lookup failed."),
        }

    rack = rack_result.get("racks", {})          # get_rack uses result_key="racks"
    rack_uuid: str = _get_field(rack, "id")
    rack_name: str = _get_field(rack, "name") or rack_uuid
    rack_u_height: int = int(_get_field(rack, "u_height") or 0)

    if not rack_uuid:
        return {"success": False, "message": "Rack record has no id field."}

    if rack_u_height == 0:
        return {
            "success": False,
            "message": f"Rack '{rack_name}' has u_height=0; cannot calculate utilization.",
        }

    logger.info(
        "get_rack_utilization: rack='%s'  id=%s  u_height=%d",
        rack_name, rack_uuid, rack_u_height,
    )

    # ------------------------------------------------------------------
    # Step 2 — fetch raw device dicts (device_type.id preserved)
    # ------------------------------------------------------------------
    devices = _fetch_devices_in_rack(api, rack_uuid)
    device_count = len(devices)

    if device_count == 0:
        return {
            "success": True,
            "message": f"Rack '{rack_name}' has no devices.",
            "rack_name": rack_name,
            "rack_u_height": rack_u_height,
            "used_u": 0,
            "free_u": rack_u_height,
            "utilization_pct": 0,
            "device_count": 0,
            "device_type_breakdown": [],
        }

    # ------------------------------------------------------------------
    # Step 3 — resolve unique device-type UUIDs (dt_cache)
    # ------------------------------------------------------------------
    token: str = _get_token(api)
    if not token:
        return {"success": False, "message": "Cannot resolve Nautobot API token."}

    dt_cache: Dict[str, int] = {}      # dt_uuid -> u_height
    dt_count: Dict[str, int] = {}      # dt_uuid -> device count in this rack

    for dev in devices:
        dt_field = _get_field(dev, "device_type")
        dt_uuid: str = (
            dt_field.get("id", "") if isinstance(dt_field, dict) else str(dt_field or "")
        )

        if not dt_uuid:
            logger.warning(
                "get_rack_utilization: device %s has no device_type.id — skipping",
                _get_field(dev, "id"),
            )
            continue

        dt_count[dt_uuid] = dt_count.get(dt_uuid, 0) + 1

        if dt_uuid not in dt_cache:
            try:
                dt_cache[dt_uuid] = _fetch_device_type_u_height(api, dt_uuid, token)
            except Exception as exc:
                logger.warning(
                    "get_rack_utilization: failed to fetch device-type %s: %s — treating as 0U",
                    dt_uuid, exc,
                )
                dt_cache[dt_uuid] = 0

    # ------------------------------------------------------------------
    # Step 4 — sum U heights and apply formula
    # ------------------------------------------------------------------
    sum_u: int = sum(
        dt_cache.get(dt_uuid, 0) * count
        for dt_uuid, count in dt_count.items()
    )
    utilization_pct: int = int((sum_u / rack_u_height) * 100)
    free_u: int = max(rack_u_height - sum_u, 0)

    breakdown = [
        {
            "device_type_id": dt_uuid,
            "u_height": dt_cache.get(dt_uuid, 0),
            "count": count,
            "subtotal_u": dt_cache.get(dt_uuid, 0) * count,
        }
        for dt_uuid, count in dt_count.items()
    ]

    logger.info(
        "get_rack_utilization: rack='%s'  used_u=%d  rack_u_height=%d  utilization=%d%%",
        rack_name, sum_u, rack_u_height, utilization_pct,
    )

    return {
        "success": True,
        "message": (
            f"Rack '{rack_name}' is {utilization_pct}% utilized "
            f"({sum_u}U used / {rack_u_height}U total, {free_u}U free)."
        ),
        "rack_name": rack_name,
        "rack_u_height": rack_u_height,
        "used_u": sum_u,
        "free_u": free_u,
        "utilization_pct": utilization_pct,
        "device_count": device_count,
        "device_type_breakdown": breakdown,
    }
