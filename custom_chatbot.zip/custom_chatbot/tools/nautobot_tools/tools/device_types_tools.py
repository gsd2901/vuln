"""
Nautobot Dcim device_type helpers for MCP server.

Provides simple CRUD helpers for Nautobot Dcim device_types.
"""
from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional
import requests
import pynautobot
from pydantic import BaseModel, Field

from .nautobot_fields_actual import DEVICE_TYPES_PLAIN_FIELDS, DEVICE_TYPES_RELATION_FIELDS, DEVICE_TYPES_MULTI_RELATION_FIELDS
from .nautobot_relation_utils import list_tools, count_tools, get_tools,_get_token

logger = logging.getLogger(__name__)


class ListDeviceTypesParams(BaseModel):
    # Identity / lookup
    id: Optional[str] = Field(None, description="Device Type primary key/UUID.")
    name: Optional[str] = Field(None, description="Filter by device type name.")
     # Images
    front_image: Optional[bool] = Field(
        None,
        description=(
            "When True, filters for device types that have a front-panel image uploaded. "
            "When False, filters for device types that lack a front image. "
            "Omit to return device types regardless of front image availability."
        ),
    )
    rear_image: Optional[bool] = Field(
        None,
        description=(
            "When True, filters for device types that have a rear-panel image uploaded. "
            "When False, filters for device types that lack a rear image. "
            "Omit to return device types regardless of rear image availability."
        ),
    )
    # Inventory / usage
    device_count: Optional[int] = Field(
        None,
        description=(
            "Filter by the number of instantiated devices of this type currently in "
            "Nautobot. For example, pass 0 to find device types with no deployed "
            "devices, or a positive integer to match a specific deployment count."
        ),
    )

    # Annotations
    comments: Optional[str] = Field(
        None,
        description=(
            "Free-text search within the comments field of device types. "
            "Useful for finding types annotated with specific notes, EOL dates, "
            "procurement details, or other free-form metadata."
        ),
    )

    # Timestamps
    created: Optional[str] = Field(
        None,
        description=(
            "Filter by the date the device type record was created in Nautobot. "
            "Accepts ISO 8601 date strings (e.g. '2024-01-15') or date-range "
            "qualifiers supported by the Nautobot API (e.g. 'gte:2024-01-01')."
        ),
    )
    last_updated: Optional[str] = Field(
        None,
        description=(
            "Filter by the date/time the device type record was last modified. "
            "Accepts ISO 8601 datetime strings (e.g. '2024-06-01T00:00:00Z') or "
            "range qualifiers (e.g. 'gte:2024-06-01') to find recently changed records."
        ),
    )
     # Physical / rack properties
    u_height: Optional[int] = Field(
        None,
        description=(
            "Height of the device type in rack units (U), e.g. 1, 2, 4. "
            "Use to filter for 1U switches, 2U servers, or any specific rack height."
        ),
    )
    is_full_depth: Optional[bool] = Field(
        None,
        description=(
            "When True, returns only device types that occupy the full depth of a rack "
            "(front and rear). When False, returns half-depth or shallow devices. "
            "Omit to return both."
        ),
    )

    device_family: Optional[str] = Field(None, description="Filter by device family name/slug/ID.")
    subdevice_role: Optional[str] = Field(None, description="Filter by subdevice role (parent/child).")
    has_console_ports: Optional[bool] = Field(None, description="Filter by whether the device type has console ports.")
    has_console_server_ports: Optional[bool] = Field(None, description="Filter by whether the device type has console server ports.")
    has_power_ports: Optional[bool] = Field(None, description="Filter by whether the device type has power ports.")
    has_power_outlets: Optional[bool] = Field(None, description="Filter by whether the device type has power outlets.")
    has_interfaces: Optional[bool] = Field(None, description="Filter by whether the device type has interfaces.")
    has_pass_through_ports: Optional[bool] = Field(None, description="Filter by whether the device type has pass-through ports.")
    software_image_files: Optional[str] = Field(None, description="Filter by software image file name/slug/ID.")
    validated_software: Optional[str] = Field(None, description="Filter by validated software version name/slug/ID.")
    tags: Optional[str] = Field(None, description="Filter by tag name/slug.")
    query: Optional[str] = Field(None, description="General search query.")
    limit: int = Field(5, description="Maximum number of device_types to return.")
    model: Optional[str] = Field(None, description=(
    "IMPORTANT: This field must contain ONLY the bare model number, never a vendor name. "
    "If the user says 'Cisco C9300-24P', this field must be 'C9300-24P' only. "
    "If the user says 'Juniper EX4300-48P', this field must be 'EX4300-48P' only. "
    "Strip any leading manufacturer/vendor word before setting this value. "
    "Examples: 'C9300-24P', 'AIR-AP2802I-D-K9', 'EX4300-48P', 'DCS-7050CX3'."
    ),)
    manufacturer: Optional[str] = Field(None,   description=(
        "Manufacturer name or slug, e.g. 'cisco', 'juniper', 'arista'. "
        "Infer from the model string if the user includes a vendor prefix "
        "(e.g. 'Cisco C9300-24P' → manufacturer='cisco', model='C9300-24P')."
    ),)


class GetDeviceTypeParams(BaseModel):
    id: Optional[str] = Field(None, description="DeviceType ID or UUID.")
    name: Optional[str] = Field(None, description="DeviceType name.")
    model: Optional[str] = Field(None, description=(
    "IMPORTANT: This field must contain ONLY the bare model number, never a vendor name. "
    "If the user says 'Cisco C9300-24P', this field must be 'C9300-24P' only. "
    "If the user says 'Juniper EX4300-48P', this field must be 'EX4300-48P' only. "
    "Strip any leading manufacturer/vendor word before setting this value. "
    "Examples: 'C9300-24P', 'AIR-AP2802I-D-K9', 'EX4300-48P', 'DCS-7050CX3'."
    ),)
    manufacturer: Optional[str] = Field(None,   description=(
        "Manufacturer name or slug, e.g. 'cisco', 'juniper', 'arista'. "
        "Infer from the model string if the user includes a vendor prefix "
        "(e.g. 'Cisco C9300-24P' → manufacturer='cisco', model='C9300-24P')."
    ),)
    query: Optional[str] = Field(None, description="General search query.")
      # Images
    front_image: Optional[bool] = Field(
        None,
        description=(
            "When True, filters for device types that have a front-panel image uploaded. "
            "When False, filters for device types that lack a front image. "
            "Omit to return device types regardless of front image availability."
        ),
    )
    rear_image: Optional[bool] = Field(
        None,
        description=(
            "When True, filters for device types that have a rear-panel image uploaded. "
            "When False, filters for device types that lack a rear image. "
            "Omit to return device types regardless of rear image availability."
        ),
    )
    # Inventory / usage
    device_count: Optional[int] = Field(
        None,
        description=(
            "Filter by the number of instantiated devices of this type currently in "
            "Nautobot. For example, pass 0 to find device types with no deployed "
            "devices, or a positive integer to match a specific deployment count."
        ),
    )

    # Annotations
    comments: Optional[str] = Field(
        None,
        description=(
            "Free-text search within the comments field of device types. "
            "Useful for finding types annotated with specific notes, EOL dates, "
            "procurement details, or other free-form metadata."
        ),
    )

    # Timestamps
    created: Optional[str] = Field(
        None,
        description=(
            "Filter by the date the device type record was created in Nautobot. "
            "Accepts ISO 8601 date strings (e.g. '2024-01-15') or date-range "
            "qualifiers supported by the Nautobot API (e.g. 'gte:2024-01-01')."
        ),
    )
    last_updated: Optional[str] = Field(
        None,
        description=(
            "Filter by the date/time the device type record was last modified. "
            "Accepts ISO 8601 datetime strings (e.g. '2024-06-01T00:00:00Z') or "
            "range qualifiers (e.g. 'gte:2024-06-01') to find recently changed records."
        ),
    )
     # Physical / rack properties
    u_height: Optional[int] = Field(
        None,
        description=(
            "Height of the device type in rack units (U), e.g. 1, 2, 4. "
            "Use to filter for 1U switches, 2U servers, or any specific rack height."
        ),
    )
    is_full_depth: Optional[bool] = Field(
        None,
        description=(
            "When True, returns only device types that occupy the full depth of a rack "
            "(front and rear). When False, returns half-depth or shallow devices. "
            "Omit to return both."
        ),
    )
    device_family: Optional[str] = Field(None, description="Filter by device family name/slug/ID.")
    subdevice_role: Optional[str] = Field(None, description="Filter by subdevice role (parent/child).")
    has_console_ports: Optional[bool] = Field(None, description="Filter by whether the device type has console ports.")
    has_console_server_ports: Optional[bool] = Field(None, description="Filter by whether the device type has console server ports.")
    has_power_ports: Optional[bool] = Field(None, description="Filter by whether the device type has power ports.")
    has_power_outlets: Optional[bool] = Field(None, description="Filter by whether the device type has power outlets.")
    has_interfaces: Optional[bool] = Field(None, description="Filter by whether the device type has interfaces.")
    has_pass_through_ports: Optional[bool] = Field(None, description="Filter by whether the device type has pass-through ports.")
    software_image_files: Optional[str] = Field(None, description="Filter by software image file name/slug/ID.")
    validated_software: Optional[str] = Field(None, description="Filter by validated software version name/slug/ID.")
    tags: Optional[str] = Field(None, description="Filter by tag name/slug.")
    query: Optional[str] = Field(None, description="General search query.")
    limit: int = Field(5, description="Maximum number of device_types to return.")


PLAIN_FIELDS: List[str] = DEVICE_TYPES_PLAIN_FIELDS
RELATION_FIELDS: List[str] = DEVICE_TYPES_RELATION_FIELDS
MULTI_RELATION_FIELDS: List[str] = DEVICE_TYPES_MULTI_RELATION_FIELDS


def list_device_types(api: pynautobot.core.api.Api, params: ListDeviceTypesParams) -> Dict[str, Any]:
    return list_tools(
        api=api,
        endpoint=api.dcim.device_types,
        params=params,
        plain_fields=PLAIN_FIELDS,
        relation_fields=RELATION_FIELDS,
        multi_relation_fields=MULTI_RELATION_FIELDS,
        result_key="device_types",
        filter_map={"query": "q"},
        limit=getattr(params, "limit", 5),
    )


def count_device_types(api: pynautobot.core.api.Api, params: ListDeviceTypesParams) -> Dict[str, Any]:
    return count_tools(
        endpoint=api.dcim.device_types,
        params=params,
        resource_name="device_types",
    )


def get_device_type(api: pynautobot.core.api.Api, params: GetDeviceTypeParams) -> Dict[str, Any]:
    return get_tools(
        api=api,
        endpoint=api.dcim.device_types,
        params=params,
        plain_fields=PLAIN_FIELDS,
        relation_fields=RELATION_FIELDS,
        multi_relation_fields=MULTI_RELATION_FIELDS,
        filter_map={"query": "q"},
        result_key="device_types",
        lookup_fields=['id',"model","natural_slug","manufacturer"],
    )

