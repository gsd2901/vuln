"""
Nautobot Cloud cloud_account helpers for MCP server.

Provides simple CRUD helpers for Nautobot Cloud cloud_accounts.
"""
from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

import pynautobot
from pydantic import BaseModel, Field

from .nautobot_fields_actual import CLOUD_ACCOUNTS_PLAIN_FIELDS, CLOUD_ACCOUNTS_RELATION_FIELDS, CLOUD_ACCOUNTS_MULTI_RELATION_FIELDS
from .nautobot_relation_utils import list_tools, count_tools, get_tools

logger = logging.getLogger(__name__)


class ListCloudAccountsParams(BaseModel):
    name: Optional[str] = Field(None, description="Filter by cloud account name.")
    account_number: Optional[str] = Field(None, description="Filter by account number.")
    provider: Optional[str] = Field(None, description="Filter by provider (manufacturer) name/slug/ID.")
    secrets_group: Optional[str] = Field(None, description="Filter by secrets group name/ID.")
    tags: Optional[str] = Field(None, description="Filter by tag name/slug.")
    query: Optional[str] = Field(None, description="General search query.")
    limit: int = Field(5, description="Maximum number of cloud accounts to return.")


class GetCloudAccountParams(BaseModel):
    id: Optional[str] = Field(None, description="CloudAccount ID or UUID.")
    name: Optional[str] = Field(None, description="CloudAccount name.")


PLAIN_FIELDS: List[str] = CLOUD_ACCOUNTS_PLAIN_FIELDS
RELATION_FIELDS: List[str] = CLOUD_ACCOUNTS_RELATION_FIELDS
MULTI_RELATION_FIELDS: List[str] = CLOUD_ACCOUNTS_MULTI_RELATION_FIELDS


def list_cloud_accounts(api: pynautobot.core.api.Api, params: ListCloudAccountsParams) -> Dict[str, Any]:
    return list_tools(
        api=api,
        endpoint=api.cloud.cloud_accounts,
        params=params,
        plain_fields=PLAIN_FIELDS,
        relation_fields=RELATION_FIELDS,
        multi_relation_fields=MULTI_RELATION_FIELDS,
        result_key="cloud_accounts",
        limit=getattr(params, "limit", 5),
    )


def get_cloud_account(api: pynautobot.core.api.Api, params: GetCloudAccountParams) -> Dict[str, Any]:
    return get_tools(
        api=api,
        endpoint=api.cloud.cloud_accounts,
        params=params,
        plain_fields=PLAIN_FIELDS,
        relation_fields=RELATION_FIELDS,
        multi_relation_fields=MULTI_RELATION_FIELDS,
        result_key="cloud_accounts",
        lookup_fields=['id', 'name'],
    )
def count_cloud_account(api: pynautobot.core.api.Api, params: ListCloudAccountsParams) -> Dict[str, Any]:
    return count_tools(
        endpoint=api.cloud.cloud_accounts,
        params=params,
        resource_name="cloud_accounts",
    )
