"""
Nautobot Dcim platform helpers for MCP server.

Provides simple CRUD helpers for Nautobot Dcim platforms.
"""
from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

import pynautobot
from pydantic import BaseModel, Field

from .nautobot_fields_actual import PLATFORMS_PLAIN_FIELDS, PLATFORMS_RELATION_FIELDS, PLATFORMS_MULTI_RELATION_FIELDS
from .nautobot_relation_utils import list_tools, count_tools, get_tools

logger = logging.getLogger(__name__)


class ListPlatformsParams(BaseModel):
    name: Optional[str] = Field(None, description="Filter by platform name.")
    query: Optional[str] = Field(None, description="General search query.")
    limit: int = Field(5, description="Maximum number of platforms to return.")


class GetPlatformParams(BaseModel):
    id: Optional[str] = Field(None, description="Platform ID or UUID.")
    name: Optional[str] = Field(None, description="Platform name.")


PLAIN_FIELDS: List[str] = PLATFORMS_PLAIN_FIELDS
RELATION_FIELDS: List[str] = PLATFORMS_RELATION_FIELDS
MULTI_RELATION_FIELDS: List[str] = PLATFORMS_MULTI_RELATION_FIELDS


def list_platforms(api: pynautobot.core.api.Api, params: ListPlatformsParams) -> Dict[str, Any]:
    return list_tools(
        api=api,
        endpoint=api.dcim.platforms,
        params=params,
        plain_fields=PLAIN_FIELDS,
        relation_fields=RELATION_FIELDS,
        multi_relation_fields=MULTI_RELATION_FIELDS,
        result_key="platforms",
        limit=getattr(params, "limit", 5),
    )


def get_platform(api: pynautobot.core.api.Api, params: GetPlatformParams) -> Dict[str, Any]:
    return get_tools(
        api=api,
        endpoint=api.dcim.platforms,
        params=params,
        plain_fields=PLAIN_FIELDS,
        relation_fields=RELATION_FIELDS,
        multi_relation_fields=MULTI_RELATION_FIELDS,
        result_key="platforms",
        lookup_fields=['id', 'name'],
    )

def count_platform(api: pynautobot.core.api.Api, params: ListPlatformsParams) -> Dict[str, Any]:
    return count_tools(
        endpoint=api.dcim.platforms,
        params=params,
        resource_name="platforms",
    )
