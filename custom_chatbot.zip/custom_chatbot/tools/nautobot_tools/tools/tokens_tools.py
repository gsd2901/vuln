"""
Nautobot Users token helpers for MCP server.

Provides simple CRUD helpers for Nautobot Users tokens.
"""
from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

import pynautobot
from pydantic import BaseModel, Field

from .nautobot_fields_actual import TOKENS_PLAIN_FIELDS, TOKENS_RELATION_FIELDS, TOKENS_MULTI_RELATION_FIELDS
from .nautobot_relation_utils import list_tools, count_tools, get_tools

logger = logging.getLogger(__name__)


class ListTokensParams(BaseModel):
    name: Optional[str] = Field(None, description="Filter by token name.")
    query: Optional[str] = Field(None, description="General search query.")
    limit: int = Field(5, description="Maximum number of tokens to return.")


class GetTokenParams(BaseModel):
    id: Optional[str] = Field(None, description="Token ID or UUID.")
    name: Optional[str] = Field(None, description="Token name.")


PLAIN_FIELDS: List[str] = TOKENS_PLAIN_FIELDS
RELATION_FIELDS: List[str] = TOKENS_RELATION_FIELDS
MULTI_RELATION_FIELDS: List[str] = TOKENS_MULTI_RELATION_FIELDS


def list_tokens(api: pynautobot.core.api.Api, params: ListTokensParams) -> Dict[str, Any]:
    return list_tools(
        api=api,
        endpoint=api.users.tokens,
        params=params,
        plain_fields=PLAIN_FIELDS,
        relation_fields=RELATION_FIELDS,
        multi_relation_fields=MULTI_RELATION_FIELDS,
        result_key="tokens",
        limit=getattr(params, "limit", 5),
    )


def get_token(api: pynautobot.core.api.Api, params: GetTokenParams) -> Dict[str, Any]:
    return get_tools(
        api=api,
        endpoint=api.users.tokens,
        params=params,
        plain_fields=PLAIN_FIELDS,
        relation_fields=RELATION_FIELDS,
        multi_relation_fields=MULTI_RELATION_FIELDS,
        result_key="tokens",
        lookup_fields=['id', 'name'],
    )
def count_token(api: pynautobot.core.api.Api, params: ListTokensParams) -> Dict[str, Any]:
    return count_tools(
        endpoint=api.users.tokens,
        params=params,
        resource_name="tokens",
    )
