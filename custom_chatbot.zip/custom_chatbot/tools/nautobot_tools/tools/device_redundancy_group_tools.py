"""
Nautobot DCIM device redundancy group helpers for MCP server.

Provides CRUD helpers for Nautobot DCIM device redundancy groups. Functions accept
a configured `pynautobot` API instance and Pydantic param models and return
JSON-serializable dicts with a common envelope.

Example responses mirror Nautobot's device redundancy group representation (id,
name, display, natural_slug, failover_strategy, description, comments, status,
secrets_group, etc.).
"""
from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

import pynautobot
from pydantic import BaseModel, Field

from .nautobot_fields_actual import (
    DEVICE_REDUNDANCY_GROUPS_PLAIN_FIELDS,
    DEVICE_REDUNDANCY_GROUPS_RELATION_FIELDS,
    DEVICE_REDUNDANCY_GROUPS_MULTI_RELATION_FIELDS,
)
from .nautobot_relation_utils import list_tools, count_tools, get_tools

logger = logging.getLogger(__name__)


class ListDeviceRedundancyGroupsParams(BaseModel):
    """Parameters for listing device redundancy groups."""
    id: Optional[str] = Field(None, description="Device redundancy group primary key/UUID.")
    name: Optional[str] = Field(None, description="Filter by device redundancy group name.")
    failover_strategy: Optional[str] = Field(None, description="Filter by failover strategy (e.g. active-active, active-passive).")
    status: Optional[str] = Field(None, description="Filter by status slug or name (best-effort).")
    secrets_group: Optional[str] = Field(None, description="Filter by secrets group name or ID (best-effort).")
    tags: Optional[str] = Field(None, description="Filter by tag slug/name.")
    query: Optional[str] = Field(None, description="Case-insensitive contains filter on device redundancy group name.")
    limit: int = Field(5, description="Maximum number of device redundancy groups to return.")


class GetDeviceRedundancyGroupParams(BaseModel):
    """Parameters for getting a single device redundancy group."""

    id: Optional[str] = Field(None, description="Device redundancy group primary key/UUID.")
    name: Optional[str] = Field(None, description="Device redundancy group name to retrieve.")
    natural_slug: Optional[str] = Field(None, description="Device redundancy group natural slug.")
    failover_strategy: Optional[str] = Field(None, description="Filter by failover strategy (e.g. active-active, active-passive).")
    status: Optional[str] = Field(None, description="Filter by status slug or name (best-effort).")
    secrets_group: Optional[str] = Field(None, description="Filter by secrets group name or ID (best-effort).")
    tags: Optional[str] = Field(None, description="Filter by tag slug/name.")
    query: Optional[str] = Field(None, description="Case-insensitive contains filter on device redundancy group name.")


PLAIN_FIELDS: List[str] = DEVICE_REDUNDANCY_GROUPS_PLAIN_FIELDS
RELATION_FIELDS: List[str] = DEVICE_REDUNDANCY_GROUPS_RELATION_FIELDS
MULTI_RELATION_FIELDS: List[str] = DEVICE_REDUNDANCY_GROUPS_MULTI_RELATION_FIELDS


def list_device_redundancy_groups(api: pynautobot.core.api.Api, params: ListDeviceRedundancyGroupsParams) -> Dict[str, Any]:
    return list_tools(
        api=api,
        endpoint=api.dcim.device_redundancy_groups,
        params=params,
        plain_fields=DEVICE_REDUNDANCY_GROUPS_PLAIN_FIELDS,
        relation_fields=DEVICE_REDUNDANCY_GROUPS_RELATION_FIELDS,
        multi_relation_fields=DEVICE_REDUNDANCY_GROUPS_MULTI_RELATION_FIELDS,
        result_key="device_redundancy_groups",
        limit=getattr(params, "limit", 5),
    )


def get_device_redundancy_group(api: pynautobot.core.api.Api, params: GetDeviceRedundancyGroupParams) -> Dict[str, Any]:
    return get_tools(
        api=api,
        endpoint=api.dcim.device_redundancy_groups,
        params=params,
        plain_fields=DEVICE_REDUNDANCY_GROUPS_PLAIN_FIELDS,
        relation_fields=DEVICE_REDUNDANCY_GROUPS_RELATION_FIELDS,
        multi_relation_fields=DEVICE_REDUNDANCY_GROUPS_MULTI_RELATION_FIELDS,
        # lookup_fields=["id", "name"],
        result_key="device_redundancy_groups",
        lookup_fields=['id', 'name', 'natural_slug'],
    )

def count_device_redundancy_group(api: pynautobot.core.api.Api, params: ListDeviceRedundancyGroupsParams) -> Dict[str, Any]:
    return count_tools(
        endpoint=api.dcim.device_redundancy_groups,
        params=params,
        resource_name="device_redundancy_groups",
    )