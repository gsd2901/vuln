"""
Nautobot Tenancy tenant_group helpers for MCP server.

Provides simple CRUD helpers for Nautobot Tenancy tenant_groups.
"""
from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

import pynautobot
from pydantic import BaseModel, Field

from .nautobot_fields_actual import TENANT_GROUPS_PLAIN_FIELDS, TENANT_GROUPS_RELATION_FIELDS, TENANT_GROUPS_MULTI_RELATION_FIELDS
from .nautobot_relation_utils import list_tools, count_tools, get_tools

logger = logging.getLogger(__name__)


class ListTenantGroupsParams(BaseModel):
    name: Optional[str] = Field(None, description="Filter by tenant_group name.")
    query: Optional[str] = Field(None, description="General search query.")
    limit: int = Field(5, description="Maximum number of tenant_groups to return.")


class GetTenantGroupParams(BaseModel):
    id: Optional[str] = Field(None, description="TenantGroup ID or UUID.")
    name: Optional[str] = Field(None, description="TenantGroup name.")


PLAIN_FIELDS: List[str] = TENANT_GROUPS_PLAIN_FIELDS
RELATION_FIELDS: List[str] = TENANT_GROUPS_RELATION_FIELDS
MULTI_RELATION_FIELDS: List[str] = TENANT_GROUPS_MULTI_RELATION_FIELDS


def list_tenant_groups(api: pynautobot.core.api.Api, params: ListTenantGroupsParams) -> Dict[str, Any]:
    return list_tools(
        api=api,
        endpoint=api.tenancy.tenant_groups,
        params=params,
        plain_fields=PLAIN_FIELDS,
        relation_fields=RELATION_FIELDS,
        multi_relation_fields=MULTI_RELATION_FIELDS,
        result_key="tenant_groups",
        limit=getattr(params, "limit", 5),
    )


def get_tenant_group(api: pynautobot.core.api.Api, params: GetTenantGroupParams) -> Dict[str, Any]:
    return get_tools(
        api=api,
        endpoint=api.tenancy.tenant_groups,
        params=params,
        plain_fields=PLAIN_FIELDS,
        relation_fields=RELATION_FIELDS,
        multi_relation_fields=MULTI_RELATION_FIELDS,
        result_key="tenant_groups",
        lookup_fields=['id', 'name'],
    )
def count_tenant_group(api: pynautobot.core.api.Api, params: ListTenantGroupsParams) -> Dict[str, Any]:
    return count_tools(
        endpoint=api.tenancy.tenant_groups,
        params=params,
        resource_name="tenant_groups",
    )
