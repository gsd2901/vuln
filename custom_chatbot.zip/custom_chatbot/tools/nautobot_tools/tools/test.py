import os
import pynautobot

from vlans_tools import (
    list_vlans,
    # count_vlans,
    get_vlan,
    ListVlansParams,
    # CountVlansParams,
    GetVlanParams,
    CreateVlanParams,
    UpdateVlanParams,
    DeleteVlanParams,
)

# Setup API
# NAUTOBOT_URL="http://127.0.0.1:8099"
NAUTOBOT_URL="http://127.0.0.1:8099"
# NAUTOBOT_TOKEN="746bfc450f9602bdb587915400cfda8b5adda85b" 
# NAUTOBOT_TOKEN=os.getenv("NAUTOBOT_TOKEN")
NAUTOBOT_TOKEN="d688ad08c85b15fa98b5cb8a0743b2f95157792b"
api = pynautobot.api(
    url=NAUTOBOT_URL,
    token=NAUTOBOT_TOKEN,
)

# ---------------------------
# Test functions one by one
# ---------------------------

# def test_list():
#     params = ListVlansParams(limit=5)
#     result = list_vlans(api, params)
#     print("LIST RESULT:", result)

# def test_list():
#     params = CountVlansParams(limit=5)
#     result = count_vlans(api, params)
#     print("LIST RESULT:", result)

# def test_list_by_vlan_group():
#     params = ListVlansParams(vlan_group__name="AMS VLAN", limit=30)
    # result = list_vlans(api, params)
    # print("RESULT:", result)


# def test_get():
#     params = GetVlanParams(name="site_ams01")
#     result = get_vlan(api, params)
#     print("GET RESULT:", result)

# def list_vlans(api, params):
#     filters = {}
#     if params.vlan_group:
#         filters["vlan_group__name"] = params.vlan_group

#     print("DEBUG filters:", filters)                    # see what's sent
#     vlans = api.ipam.vlans.filter(**filters)
#     raw = list(vlans)
#     print("DEBUG raw count from API:", len(raw))       # if 0, filter is ignored

# Run this once to confirm the correct endpoint name
# print(dir(api.ipam))   # look for vlan_groups or vlan-groups
# groups = list(api.ipam.vlan_groups.filter(name="AMS VLAN"))
# print("Found groups:", groups)
# print("Group ID:", groups[0].id if groups else "NOT FOUND")

import logging
import os
from typing import Any, Dict, List, Optional

import requests
import pynautobot
from pydantic import BaseModel, Field
logger = logging.getLogger(__name__)

class CountVlansParams(BaseModel):
    location: Optional[str] = Field(None, description="Filter by location slug/name/ID.")
    vlan_group: Optional[str] = Field(None, description="Filter by VLAN group slug/name/ID.")
    status: Optional[str] = Field(None, description="Filter by status slug/name.")
    role: Optional[str] = Field(None, description="Filter by role slug/name.")
    tenant: Optional[str] = Field(None, description="Filter by tenant slug/name.")
    name: Optional[str] = Field(None, description="Filter by vlan name.")
    role: Optional[str] = Field(None, description="Filter by role slug/name.")
    status: Optional[str] = Field(None, description="Filter by status slug/name.")
    tenant: Optional[str] = Field(None, description="Filter by tenant slug/name.")
    platform: Optional[str] = Field(None, description="Filter by platform slug/name.")
    device_type: Optional[str] = Field(None, description="Filter by device-type slug/name.")
    query: Optional[str] = Field(None, description="General search query.")
    vlan_group: Optional[str] = Field(None, description="Filter by vlan group name.")  
    limit: int = Field(50000, description="Maximum number of vlans to return.")

def count_vlans(api: pynautobot.core.api.Api, params: ListVlansParams) -> Dict[str, Any]:
    try:
        filters: Dict[str, Any] = {}
        if params.location:
            filters["location"] = _best_effort_filter_value(params.location)
        if params.vlan_group:
            filters["vlan_group"] = _best_effort_filter_value(params.vlan_group)
        if params.status:
            filters["status"] = _best_effort_filter_value(params.status)
        if params.role:
            filters["role"] = _best_effort_filter_value(params.role)
        if params.tenant:
            filters["tenant"] = _best_effort_filter_value(params.tenant)
        if params.name:
            filters["name__ic"] =  params.name
        if params.platform:
            filters["platform"] = _best_effort_filter_value(params.platform)
        if params.device_type:
            filters["device_type"] = _best_effort_filter_value(params.device_type)
        if params.query:
            filters["q"] = params.query

        count: int = api.dcim.devices.count(**filters) 
        print(count)
        return {
            "success": True,
            "message": f"Found {count} vlan(s)]",
            "count": count}
    except Exception as e:
        logger.exception("Failed to list vlans: %s", e)
        return {"success": False, "message": f"Failed to count vlans: {e}", "vlans": []}



def test_cntvlan():
    params = CountVlansParams(vlan_group__name="AMS VLAN", limit=3)
    result = count_vlans(api, params)
    print("RESULT:", result)



if __name__ == "__main__":
    # test_list()
    # test_get()
    # test_list_by_vlan_group()
    # list_vlans()
    test_cntvlan()