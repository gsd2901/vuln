"""
Nautobot Extras custom_field helpers for MCP server.

Provides simple CRUD helpers for Nautobot Extras custom_fields.
"""
from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

import pynautobot
from pydantic import BaseModel, Field

from .nautobot_fields_actual import CUSTOM_FIELDS_PLAIN_FIELDS, CUSTOM_FIELDS_RELATION_FIELDS, CUSTOM_FIELDS_MULTI_RELATION_FIELDS
from .nautobot_relation_utils import list_tools, count_tools, get_tools

logger = logging.getLogger(__name__)


class ListCustomFieldsParams(BaseModel):
    name: Optional[str] = Field(None, description="Filter by custom_field name.")
    query: Optional[str] = Field(None, description="General search query.")
    limit: int = Field(5, description="Maximum number of custom_fields to return.")


class GetCustomFieldParams(BaseModel):
    id: Optional[str] = Field(None, description="CustomField ID or UUID.")
    name: Optional[str] = Field(None, description="CustomField name.")


PLAIN_FIELDS: List[str] = CUSTOM_FIELDS_PLAIN_FIELDS
RELATION_FIELDS: List[str] = CUSTOM_FIELDS_RELATION_FIELDS
MULTI_RELATION_FIELDS: List[str] = CUSTOM_FIELDS_MULTI_RELATION_FIELDS


def list_custom_fields(api: pynautobot.core.api.Api, params: ListCustomFieldsParams) -> Dict[str, Any]:
    return list_tools(
        api=api,
        endpoint=api.extras.custom_fields,
        params=params,
        plain_fields=PLAIN_FIELDS,
        relation_fields=RELATION_FIELDS,
        multi_relation_fields=MULTI_RELATION_FIELDS,
        result_key="custom_fields",
        limit=getattr(params, "limit", 5),
    )


def get_custom_field(api: pynautobot.core.api.Api, params: GetCustomFieldParams) -> Dict[str, Any]:
    return get_tools(
        api=api,
        endpoint=api.extras.custom_fields,
        params=params,
        plain_fields=PLAIN_FIELDS,
        relation_fields=RELATION_FIELDS,
        multi_relation_fields=MULTI_RELATION_FIELDS,
        result_key="custom_fields",
        lookup_fields=['id', 'name'],
    )

def count_custom_field(api: pynautobot.core.api.Api, params: ListCustomFieldsParams) -> Dict[str, Any]:
    return count_tools(
        endpoint=api.extras.custom_fields,
        params=params,
        resource_name="custom_fields",
    )
