"""
Nautobot Dcim module_type helpers for MCP server.

Provides simple CRUD helpers for Nautobot Dcim module_types.
"""
from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

import pynautobot
from pydantic import BaseModel, Field

from .nautobot_fields_actual import MODULE_TYPES_PLAIN_FIELDS, MODULE_TYPES_RELATION_FIELDS, MODULE_TYPES_MULTI_RELATION_FIELDS
from .nautobot_relation_utils import list_tools, count_tools, get_tools

logger = logging.getLogger(__name__)


class ListModuleTypesParams(BaseModel):
    name: Optional[str] = Field(None, description="Filter by module_type name.")
    manufacturer: Optional[str] = Field(None, description="Filter by manufacturer name/slug/ID.")
    module_family: Optional[str] = Field(None, description="Filter by module family name/slug/ID.")
    has_console_ports: Optional[bool] = Field(None, description="Filter by presence of console ports.")
    has_console_server_ports: Optional[bool] = Field(None, description="Filter by presence of console server ports.")
    has_power_ports: Optional[bool] = Field(None, description="Filter by presence of power ports.")
    has_power_outlets: Optional[bool] = Field(None, description="Filter by presence of power outlets.")
    has_interfaces: Optional[bool] = Field(None, description="Filter by presence of interfaces.")
    tags: Optional[str] = Field(None, description="Filter by tag name/slug.")
    query: Optional[str] = Field(None, description="General search query.")
    limit: int = Field(5, description="Maximum number of module_types to return.")


class GetModuleTypeParams(BaseModel):
    id: Optional[str] = Field(None, description="ModuleType ID or UUID.")
    name: Optional[str] = Field(None, description="ModuleType name.")


PLAIN_FIELDS: List[str] = MODULE_TYPES_PLAIN_FIELDS
RELATION_FIELDS: List[str] = MODULE_TYPES_RELATION_FIELDS
MULTI_RELATION_FIELDS: List[str] = MODULE_TYPES_MULTI_RELATION_FIELDS


def list_module_types(api: pynautobot.core.api.Api, params: ListModuleTypesParams) -> Dict[str, Any]:
    return list_tools(
        api=api,
        endpoint=api.dcim.module_types,
        params=params,
        plain_fields=PLAIN_FIELDS,
        relation_fields=RELATION_FIELDS,
        multi_relation_fields=MULTI_RELATION_FIELDS,
        result_key="module_types",
        limit=getattr(params, "limit", 5),
    )


def get_module_type(api: pynautobot.core.api.Api, params: GetModuleTypeParams) -> Dict[str, Any]:
    return get_tools(
        api=api,
        endpoint=api.dcim.module_types,
        params=params,
        plain_fields=PLAIN_FIELDS,
        relation_fields=RELATION_FIELDS,
        multi_relation_fields=MULTI_RELATION_FIELDS,
        result_key="module_types",
        lookup_fields=['id', 'name'],
    )
def count_module_type(api: pynautobot.core.api.Api, params: ListModuleTypesParams) -> Dict[str, Any]:
    return count_tools(
        endpoint=api.dcim.module_types,
        params=params,
        resource_name="module_types",
    )
