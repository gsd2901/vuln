"""
Nautobot Ipam vrf helpers for MCP server.

Provides simple CRUD helpers for Nautobot Ipam vrfs.
"""
from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

import pynautobot
from pydantic import BaseModel, Field

from .nautobot_fields_actual import VRFS_PLAIN_FIELDS, VRFS_RELATION_FIELDS, VRFS_MULTI_RELATION_FIELDS
from .nautobot_relation_utils import list_tools, count_tools, get_tools

logger = logging.getLogger(__name__)

class ListVrfsParams(BaseModel):
    # --- Identity & Core Fields ---
    id: Optional[str] = Field(
        None,
        description=(
            "Filter by the VRF's unique UUID (e.g. '7742e599-725b-420a-900e-e249edd3d09f'). "
            "Useful for exact-match lookups when the UUID is already known."
        ),
    )
    name: Optional[str] = Field(
        None,
        description=(
            "Filter by VRF name (e.g. 'BCP-VDI-RDSH-GILLEAD-CHN'). "
            "Supports partial or exact matching depending on Nautobot query behaviour."
        ),
    )
    rd: Optional[str] = Field(
        None,
        description=(
            "Filter by Route Distinguisher (RD) in standard notation (e.g. '65000:100'). "
            "The RD uniquely identifies a VRF within an MPLS/BGP network. May be null if not assigned."
        ),
    )
    description: Optional[str] = Field(
        None,
        description=(
            "Filter by free-text description associated with the VRF. "
            "Useful for searching VRFs that carry a specific descriptive annotation."
        ),
    )

    # --- Status & Classification ---
    status: Optional[str] = Field(
        None,
        description=(
            "Filter by the VRF's operational status slug or name (e.g. 'active', 'deprecated'). "
            "Maps to Nautobot's Status object; use the slug value for reliable matching."
        ),
    )
    namespace: Optional[str] = Field(
        None,
        description=(
            "Filter by the parent Namespace slug or UUID. "
            "In Nautobot, a Namespace provides IP address uniqueness scope; "
            "every VRF belongs to exactly one Namespace (e.g. 'Global')."
        ),
    )

    # --- Tenancy ---
    tenant_group: Optional[str] = Field(
        None,
        description=(
            "Filter by tenant group slug/name (best-effort). "
            "Narrows results to VRFs whose assigned Tenant belongs to this group."
        ),
    )
    tenant: Optional[str] = Field(
        None,
        description=(
            "Filter by the slug or name of the Tenant this VRF is assigned to. "
            "Useful for multi-tenant environments where VRFs are scoped per customer or business unit."
        ),
    )

    # --- Related Objects ---
    devices: Optional[str] = Field(
        None,
        description=(
            "Filter by a related Device UUID or name. "
            "Returns VRFs that are associated with the specified device "
            "(i.e. the device has an interface in this VRF)."
        ),
    )
    virtual_machines: Optional[str] = Field(
        None,
        description=(
            "Filter by a related Virtual Machine UUID or name. "
            "Returns VRFs associated with interfaces belonging to the specified VM."
        ),
    )
    virtual_device_contexts: Optional[str] = Field(
        None,
        description=(
            "Filter by a related Virtual Device Context (VDC) UUID or name. "
            "VDCs are logical partitions of a physical device; this filters VRFs "
            "that are referenced by a specific VDC."
        ),
    )
    prefixes: Optional[str] = Field(
        None,
        description=(
            "Filter by a prefix (CIDR notation, e.g. '10.0.0.0/8') assigned to the VRF. "
            "Returns VRFs that contain or are associated with the specified prefix."
        ),
    )

    # --- Route Targets ---
    import_targets: Optional[str] = Field(
        None,
        description=(
            "Filter by import Route Target value (e.g. '65000:100'). "
            "Import targets define which routes are imported into this VRF from other VRFs "
            "in an MPLS L3VPN topology."
        ),
    )
    export_targets: Optional[str] = Field(
        None,
        description=(
            "Filter by export Route Target value (e.g. '65000:200'). "
            "Export targets define which routes are advertised out of this VRF "
            "to other VRFs in an MPLS L3VPN topology."
        ),
    )

    # --- Timestamps ---
    created: Optional[str] = Field(
        None,
        description=(
            "Filter by the ISO-8601 creation timestamp of the VRF record "
            "(e.g. '2026-02-03T05:03:09.214558-06:00'). "
            "Supports date-range queries depending on Nautobot filter support."
        ),
    )
    last_updated: Optional[str] = Field(
        None,
        description=(
            "Filter by the ISO-8601 timestamp of the most recent update to the VRF record "
            "(e.g. '2026-02-03T05:04:35.305217-06:00'). "
            "Useful for change-detection or audit workflows."
        ),
    )

    # --- Tags & Search ---
    tags: Optional[str] = Field(
        None,
        description=(
            "Filter by one or more tag slugs or names (comma-separated). "
            "Tags are free-form labels applied to VRFs for grouping or policy purposes."
        ),
    )
    query: Optional[str] = Field(
        None,
        description=(
            "General full-text search query applied across multiple VRF fields "
            "(name, RD, description, etc.). Use for broad discovery when specific "
            "field values are not known."
        ),
    )

    # --- Pagination ---
    limit: int = Field(
        5,
        description=(
            "Maximum number of VRF records to return in a single response. "
            "Defaults to 5. Increase for bulk queries; use in combination with an "
            "offset or pagination token for large datasets."
        ),
    )


class GetVrfParams(BaseModel):
    id: Optional[str] = Field(
        None,
        description=(
            "The unique UUID of the VRF to retrieve "
            "(e.g. '7742e599-725b-420a-900e-e249edd3d09f'). "
            "Takes precedence over 'name' when both are supplied. "
            "Use when you have the exact identifier from a prior list or lookup call."
        ),
    )
    name: Optional[str] = Field(
        None,
        description=(
            "The exact name of the VRF to retrieve (e.g. 'BCP-VDI-RDSH-GILLEAD-CHN'). "
            "Used as a fallback when 'id' is not available. "
            "If multiple VRFs share the same name across namespaces, "
            "prefer using 'id' for an unambiguous lookup."
        ),
    )
    rd: Optional[str] = Field(
        None,
        description=(
            "The Route Distinguisher of the VRF to retrieve (e.g. '65000:100'). "
            "Can be used as an alternative lookup key when the UUID and name are unknown "
            "but the RD is known from router configuration."
        ),
    )
    description: Optional[str] = Field(
        None,
        description=(
            "Filter by free-text description associated with the VRF. "
            "Useful for searching VRFs that carry a specific descriptive annotation."
        ),
    )
    namespace: Optional[str] = Field(
        None,
        description=(
            "The Namespace slug or UUID to scope the VRF lookup. "
            "Disambiguates VRFs with identical names that exist in different Namespaces."
        ),
    )
    
    # --- Status & Classification ---
    status: Optional[str] = Field(
        None,
        description=(
            "Filter by the VRF's operational status slug or name (e.g. 'active', 'deprecated'). "
            "Maps to Nautobot's Status object; use the slug value for reliable matching."
        ),
    )
    namespace: Optional[str] = Field(
        None,
        description=(
            "Filter by the parent Namespace slug or UUID. "
            "In Nautobot, a Namespace provides IP address uniqueness scope; "
            "every VRF belongs to exactly one Namespace (e.g. 'Global')."
        ),
    )

    # --- Tenancy ---
    tenant_group: Optional[str] = Field(
        None,
        description=(
            "Filter by tenant group slug/name (best-effort). "
            "Narrows results to VRFs whose assigned Tenant belongs to this group."
        ),
    )
    tenant: Optional[str] = Field(
        None,
        description=(
            "Filter by the slug or name of the Tenant this VRF is assigned to. "
            "Useful for multi-tenant environments where VRFs are scoped per customer or business unit."
        ),
    )

    # --- Related Objects ---
    devices: Optional[str] = Field(
        None,
        description=(
            "Filter by a related Device UUID or name. "
            "Returns VRFs that are associated with the specified device "
            "(i.e. the device has an interface in this VRF)."
        ),
    )
    virtual_machines: Optional[str] = Field(
        None,
        description=(
            "Filter by a related Virtual Machine UUID or name. "
            "Returns VRFs associated with interfaces belonging to the specified VM."
        ),
    )
    virtual_device_contexts: Optional[str] = Field(
        None,
        description=(
            "Filter by a related Virtual Device Context (VDC) UUID or name. "
            "VDCs are logical partitions of a physical device; this filters VRFs "
            "that are referenced by a specific VDC."
        ),
    )
    prefixes: Optional[str] = Field(
        None,
        description=(
            "Filter by a prefix (CIDR notation, e.g. '10.0.0.0/8') assigned to the VRF. "
            "Returns VRFs that contain or are associated with the specified prefix."
        ),
    )

    # --- Route Targets ---
    import_targets: Optional[str] = Field(
        None,
        description=(
            "Filter by import Route Target value (e.g. '65000:100'). "
            "Import targets define which routes are imported into this VRF from other VRFs "
            "in an MPLS L3VPN topology."
        ),
    )
    export_targets: Optional[str] = Field(
        None,
        description=(
            "Filter by export Route Target value (e.g. '65000:200'). "
            "Export targets define which routes are advertised out of this VRF "
            "to other VRFs in an MPLS L3VPN topology."
        ),
    )

    # --- Timestamps ---
    created: Optional[str] = Field(
        None,
        description=(
            "Filter by the ISO-8601 creation timestamp of the VRF record "
            "(e.g. '2026-02-03T05:03:09.214558-06:00'). "
            "Supports date-range queries depending on Nautobot filter support."
        ),
    )
    last_updated: Optional[str] = Field(
        None,
        description=(
            "Filter by the ISO-8601 timestamp of the most recent update to the VRF record "
            "(e.g. '2026-02-03T05:04:35.305217-06:00'). "
            "Useful for change-detection or audit workflows."
        ),
    )

    # --- Tags & Search ---
    tags: Optional[str] = Field(
        None,
        description=(
            "Filter by one or more tag slugs or names (comma-separated). "
            "Tags are free-form labels applied to VRFs for grouping or policy purposes."
        ),
    )
    query: Optional[str] = Field(
        None,
        description=(
            "General full-text search query applied across multiple VRF fields "
            "(name, RD, description, etc.). Use for broad discovery when specific "
            "field values are not known."
        ),
    )

    # --- Pagination ---
    limit: int = Field(
        5,
        description=(
            "Maximum number of VRF records to return in a single response. "
            "Defaults to 5. Increase for bulk queries; use in combination with an "
            "offset or pagination token for large datasets."
        ),
    )


# class ListVrfsParams(BaseModel):
#     import_targets: Optional[str] = Field(None, description="Filter by import targets (best-effort).")
#     export_targets: Optional[str] = Field(None, description="Filter by export targets (best-effort).")
#     status: Optional[str] = Field(None, description="Filter by status slug/name (best-effort).")
#     tenant_group: Optional[str] = Field(None, description="Filter by tenant group slug/name (best-effort).")
#     tenant: Optional[str] = Field(None, description="Filter by tenant slug/name (best-effort).")
#     tags: Optional[str] = Field(None, description="Filter by tag slug/name.")
#     name: Optional[str] = Field(None, description="Filter by vrf name.")
#     query: Optional[str] = Field(None, description="General search query.")
#     limit: int = Field(5, description="Maximum number of vrfs to return.")


# class GetVrfParams(BaseModel):
#     id: Optional[str] = Field(None, description="Vrf ID or UUID.")
#     name: Optional[str] = Field(None, description="Vrf name.")


PLAIN_FIELDS: List[str] = VRFS_PLAIN_FIELDS
RELATION_FIELDS: List[str] = VRFS_RELATION_FIELDS
MULTI_RELATION_FIELDS: List[str] = VRFS_MULTI_RELATION_FIELDS


def list_vrfs(api: pynautobot.core.api.Api, params: ListVrfsParams) -> Dict[str, Any]:
    return list_tools(
        api=api,
        endpoint=api.ipam.vrfs,
        params=params,
        plain_fields=PLAIN_FIELDS,
        relation_fields=RELATION_FIELDS,
        multi_relation_fields=MULTI_RELATION_FIELDS,
        result_key="vrfs",
        limit=getattr(params, "limit", 5),
    )


def count_vrfs(api: pynautobot.core.api.Api, params: ListVrfsParams) -> Dict[str, Any]:
    return count_tools(
        endpoint=api.ipam.vrfs,
        params=params,
        resource_name="vrfs",
    )


def get_vrf(api: pynautobot.core.api.Api, params: GetVrfParams) -> Dict[str, Any]:
    return get_tools(
        api=api,
        endpoint=api.ipam.vrfs,
        params=params,
        plain_fields=PLAIN_FIELDS,
        relation_fields=RELATION_FIELDS,
        multi_relation_fields=MULTI_RELATION_FIELDS,
        result_key="vrfs",
        lookup_fields=['id', 'name'],
    )
