"""
Nautobot Ipam vlan helpers for MCP server.

Provides simple CRUD helpers for Nautobot Ipam vlans.
"""
from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

import pynautobot
from pydantic import BaseModel, Field

from .nautobot_fields_actual import VLANS_PLAIN_FIELDS, VLANS_RELATION_FIELDS, VLANS_MULTI_RELATION_FIELDS
from .nautobot_relation_utils import list_tools, count_tools, get_tools

logger = logging.getLogger(__name__)


class ListVlansParams(BaseModel):
    location: Optional[str] = Field(None, description="Filter by location slug/name/ID.")
    tags: Optional[str] = Field(None, description=(
            "Comma-separated tag slugs or names applied to the vlans. "
            "Supplementary filter to scope lookups by operational tag."
        ),)
    id: Optional[str] = Field(None, description="Vlan ID or UUID.")
    vlan_group: Optional[str] = Field(None, description="Filter by VLAN group slug/name/ID.")
    status: Optional[str] = Field(None, description="Filter by status slug/name.")
    role: Optional[str] = Field(None, description="Filter by role slug/name.")
    tenant: Optional[str] = Field(None, description="Filter by tenant slug/name.")
    name: Optional[str] = Field(None, description="Filter by vlan name. Supports partial matching. "
        "Common naming conventions: "
        "MGMT = Management, MDU = Madurai,")
    role: Optional[str] = Field(None, description="Filter by role slug/name.")
    status: Optional[str] = Field(None, description="Filter by status slug/name.")
    tenant: Optional[str] = Field(None, description="Filter by tenant slug/name.")
    platform: Optional[str] = Field(None, description="Filter by platform slug/name.")
    device_type: Optional[str] = Field(None, description="Filter by device-type slug/name.")
    query: Optional[str] = Field(None, description="General search query.")
    vlan_group: Optional[str] = Field(None, description="Filter by vlan group name.")  
    limit: int = Field(5, description="Maximum number of vlans to return.")
    prefix_count: Optional[int] = Field(
        None,
        description=(
            "Filter VLANs by the number of prefixes associated with them. "
            "Useful for finding VLANs that have (or lack) assigned IP prefixes."
        ),
    )
    created: Optional[str] = Field(
        None,
        description=(
            "Filter by the date the VLAN record was created. "
            "Accepts ISO 8601 date format (YYYY-MM-DD) or datetime (YYYY-MM-DDTHH:MM:SSZ). "
            "Supports lookup suffixes such as __gte, __lte for range queries."
        ),
    )
    last_updated: Optional[str] = Field(
        None,
        description=(
            "Filter by the date and time the VLAN record was last modified. "
            "Accepts ISO 8601 datetime format (YYYY-MM-DDTHH:MM:SSZ). "
            "Supports lookup suffixes such as __gte, __lte for range queries."
        ),
    )
    vid: Optional[int] = Field(
        None,
        description=(
            "Filter by VLAN ID number (802.1Q tag, 1–4094). "
            "Use to narrow results to a specific VLAN tag value."
        ),
    )
    description: Optional[str] = Field(
        None,
        description=(
            "Filter by the human-readable description assigned to the VLAN. "
            "Supports partial/case-insensitive matching depending on the Nautobot API version."
        ),
    ) 


class GetVlanParams(BaseModel):
    id: Optional[str] = Field(None, description="Vlan ID or UUID.")
    tags: Optional[str] = Field(
        None,
        description=(
            "Comma-separated tag slugs or names applied to the vlans. "
            "Supplementary filter to scope lookups by operational tag."
        ),
    )
    name: Optional[str] = Field(None, description="Filter by vlan name. Supports partial matching. "
        "Common naming conventions: "
        "MGMT = Management, MDU = Madurai,")
    location: Optional[str] = Field(None, description="Filter by location slug/name/ID.")
    vlan_group: Optional[str] = Field(None, description="Filter by VLAN group slug/name/ID.")
    status: Optional[str] = Field(None, description="Filter by status slug/name.")
    role: Optional[str] = Field(None, description="Filter by role slug/name.")
    tenant: Optional[str] = Field(None, description="Filter by tenant slug/name.")
    name: Optional[str] = Field(None, description="Filter by vlan name.")
    role: Optional[str] = Field(None, description="Filter by role slug/name.")
    status: Optional[str] = Field(None, description="Filter by status slug/name.")
    tenant: Optional[str] = Field(None, description="Filter by tenant slug/name.")
    platform: Optional[str] = Field(None, description="Filter by platform slug/name.")
    device_type: Optional[str] = Field(None, description="Filter by device-type slug/name.")
    query: Optional[str] = Field(None, description="General search query.")
    vlan_group: Optional[str] = Field(None, description="Filter by vlan group name.") 
    prefix_count: Optional[int] = Field(
        None,
        description=(
            "Filter VLANs by the number of prefixes associated with them. "
            "Useful for finding VLANs that have (or lack) assigned IP prefixes."
        ),
    )
    created: Optional[str] = Field(
        None,
        description=(
            "Filter by the date the VLAN record was created. "
            "Accepts ISO 8601 date format (YYYY-MM-DD) or datetime (YYYY-MM-DDTHH:MM:SSZ). "
            "Supports lookup suffixes such as __gte, __lte for range queries."
        ),
    )
    last_updated: Optional[str] = Field(
        None,
        description=(
            "Filter by the date and time the VLAN record was last modified. "
            "Accepts ISO 8601 datetime format (YYYY-MM-DDTHH:MM:SSZ). "
            "Supports lookup suffixes such as __gte, __lte for range queries."
        ),
    )
    vid: Optional[int] = Field(
        None,
        description=(
            "Filter by VLAN ID number (802.1Q tag, 1–4094). "
            "Use to narrow results to a specific VLAN tag value."
        ),
    )
    description: Optional[str] = Field(
        None,
        description=(
            "Filter by the human-readable description assigned to the VLAN. "
            "Supports partial/case-insensitive matching depending on the Nautobot API version."
        ),
    ) 


PLAIN_FIELDS: List[str] = VLANS_PLAIN_FIELDS
RELATION_FIELDS: List[str] = VLANS_RELATION_FIELDS
MULTI_RELATION_FIELDS: List[str] = VLANS_MULTI_RELATION_FIELDS


def list_vlans(api: pynautobot.core.api.Api, params: ListVlansParams) -> Dict[str, Any]:
    return list_tools(
        api=api,
        endpoint=api.ipam.vlans,
        params=params,
        plain_fields=PLAIN_FIELDS,
        relation_fields=RELATION_FIELDS,
        multi_relation_fields=MULTI_RELATION_FIELDS,
        result_key="vlans",
        limit=getattr(params, "limit", 5),
    )


def count_vlans(api: pynautobot.core.api.Api, params: ListVlansParams) -> Dict[str, Any]:
    return count_tools(
        endpoint=api.ipam.vlans,
        params=params,
        resource_name="vlans",
    )


def get_vlan(api: pynautobot.core.api.Api, params: GetVlanParams) -> Dict[str, Any]:
    return get_tools(
        api=api,
        endpoint=api.ipam.vlans,
        params=params,
        plain_fields=PLAIN_FIELDS,
        relation_fields=RELATION_FIELDS,
        multi_relation_fields=MULTI_RELATION_FIELDS,
        result_key="vlans",
        lookup_fields=['id', 'name'],
    )
