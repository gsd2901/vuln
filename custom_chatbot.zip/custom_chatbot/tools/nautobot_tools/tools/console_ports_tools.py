"""
Nautobot Dcim console_port helpers for MCP server.

Provides simple CRUD helpers for Nautobot Dcim console_ports.
"""
from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

import pynautobot
from pydantic import BaseModel, Field

from .nautobot_fields_actual import CONSOLE_PORTS_PLAIN_FIELDS, CONSOLE_PORTS_RELATION_FIELDS, CONSOLE_PORTS_MULTI_RELATION_FIELDS
from .nautobot_relation_utils import list_tools, count_tools, get_tools

logger = logging.getLogger(__name__)


class ListConsolePortsParams(BaseModel):
    name: Optional[str] = Field(None, description="Filter by console port name.")
    location: Optional[str] = Field(None, description="Filter by location name/slug/ID.")
    device: Optional[str] = Field(None, description="Filter by device name/ID.")
    query: Optional[str] = Field(None, description="General search query.")
    limit: int = Field(5, description="Maximum number of console_ports to return.")


class GetConsolePortParams(BaseModel):
    id: Optional[str] = Field(None, description="ConsolePort ID or UUID.")
    name: Optional[str] = Field(None, description="ConsolePort name.")


PLAIN_FIELDS: List[str] = CONSOLE_PORTS_PLAIN_FIELDS
RELATION_FIELDS: List[str] = CONSOLE_PORTS_RELATION_FIELDS
MULTI_RELATION_FIELDS: List[str] = CONSOLE_PORTS_MULTI_RELATION_FIELDS


def list_console_ports(api: pynautobot.core.api.Api, params: ListConsolePortsParams) -> Dict[str, Any]:
    return list_tools(
        api=api,
        endpoint=api.dcim.console_ports,
        params=params,
        plain_fields=PLAIN_FIELDS,
        relation_fields=RELATION_FIELDS,
        multi_relation_fields=MULTI_RELATION_FIELDS,
        result_key="console_ports",
        limit=getattr(params, "limit", 5),
    )


def get_console_port(api: pynautobot.core.api.Api, params: GetConsolePortParams) -> Dict[str, Any]:
    return get_tools(
        api=api,
        endpoint=api.dcim.console_ports,
        params=params,
        plain_fields=PLAIN_FIELDS,
        relation_fields=RELATION_FIELDS,
        multi_relation_fields=MULTI_RELATION_FIELDS,
        result_key="console_ports",
        lookup_fields=['id', 'name'],
    )

def count_console_port(api: pynautobot.core.api.Api, params: ListConsolePortsParams) -> Dict[str, Any]:
    return count_tools(
        endpoint=api.dcim.console_ports,
        params=params,
        resource_name="console_ports",
    )
