"""
Nautobot Dcim inventory_item helpers for MCP server.

Provides simple CRUD helpers for Nautobot Dcim inventory_items.
"""
from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

import pynautobot
from pydantic import BaseModel, Field

from .nautobot_fields_actual import INVENTORY_ITEMS_PLAIN_FIELDS, INVENTORY_ITEMS_RELATION_FIELDS, INVENTORY_ITEMS_MULTI_RELATION_FIELDS
from .nautobot_relation_utils import list_tools, count_tools, get_tools

logger = logging.getLogger(__name__)


class ListInventoryItemsParams(BaseModel):
    name: Optional[str] = Field(None, description="Filter by inventory_item name.")
    query: Optional[str] = Field(None, description="General search query.")
    limit: int = Field(5, description="Maximum number of inventory_items to return.")


class GetInventoryItemParams(BaseModel):
    id: Optional[str] = Field(None, description="InventoryItem ID or UUID.")
    name: Optional[str] = Field(None, description="InventoryItem name.")


PLAIN_FIELDS: List[str] = INVENTORY_ITEMS_PLAIN_FIELDS
RELATION_FIELDS: List[str] = INVENTORY_ITEMS_RELATION_FIELDS
MULTI_RELATION_FIELDS: List[str] = INVENTORY_ITEMS_MULTI_RELATION_FIELDS


def list_inventory_items(api: pynautobot.core.api.Api, params: ListInventoryItemsParams) -> Dict[str, Any]:
    return list_tools(
        api=api,
        endpoint=api.dcim.inventory_items,
        params=params,
        plain_fields=PLAIN_FIELDS,
        relation_fields=RELATION_FIELDS,
        multi_relation_fields=MULTI_RELATION_FIELDS,
        result_key="inventory_items",
        limit=getattr(params, "limit", 5),
    )


def get_inventory_item(api: pynautobot.core.api.Api, params: GetInventoryItemParams) -> Dict[str, Any]:
    return get_tools(
        api=api,
        endpoint=api.dcim.inventory_items,
        params=params,
        plain_fields=PLAIN_FIELDS,
        relation_fields=RELATION_FIELDS,
        multi_relation_fields=MULTI_RELATION_FIELDS,
        result_key="inventory_items",
        lookup_fields=['id', 'name'],
    )
def count_inventory_item(api: pynautobot.core.api.Api, params: ListInventoryItemsParams) -> Dict[str, Any]:
    return count_tools(
        endpoint=api.dcim.inventory_items,
        params=params,
        resource_name="inventory_items",
    )
