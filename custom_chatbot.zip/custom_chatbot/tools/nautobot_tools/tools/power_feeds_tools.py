"""
Nautobot DCIM power feed helpers for MCP server.

Provides CRUD helpers for Nautobot DCIM power feeds. Functions accept a configured
`pynautobot` API instance and Pydantic param models and return JSON-serializable
dicts with a common envelope.

Example responses mirror Nautobot's power feed representation (id, name,
display, description, power_panel, type, supply, phase, voltage, amperage, etc.).
"""
from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

import pynautobot
from pydantic import BaseModel, Field

from .nautobot_fields_actual import POWER_FEEDS_PLAIN_FIELDS, POWER_FEEDS_RELATION_FIELDS, POWER_FEEDS_MULTI_RELATION_FIELDS
from .nautobot_relation_utils import list_tools, count_tools, get_tools

logger = logging.getLogger(__name__)


class ListPowerFeedsParams(BaseModel):
    """Parameters for listing power feeds."""
    id: Optional[str] = Field(None, description="Power feed primary key/UUID.")
    location: Optional[str] = Field(None, description="Filter by locations name or ID (best-effort).")
    power_panel: Optional[str] = Field(None, description="Filter by power panel name or ID (best-effort).")
    destination_panel: Optional[str] = Field(None, description="Filter by destination panel name or ID (best-effort).")
    rack: Optional[str] = Field(None, description="Filter by rack name or ID (best-effort).")
    power_path: Optional[str] = Field(None, description="Filter by power path (best-effort).")
    status: Optional[str] = Field(None, description="Filter by status slug or name (best-effort).")
    type: Optional[str] = Field(None, description="Filter by power feed type (best-effort).")
    supply: Optional[str] = Field(None, description="Filter by supply type (ac/dc).")
    voltage: Optional[int] = Field(None, description="Filter by voltage.")
    amperage: Optional[int] = Field(None, description="Filter by amperage.")
    phase: Optional[str] = Field(None, description="Filter by phase (single-phase/three-phase).")
    tags: Optional[str] = Field(None, description="Filter by tag slug/name.")
    max_utilization: Optional[int] = Field(None, description="Filter by maximum utilization percentage.")
    breaker_position: Optional[str] = Field(None, description="Filter by breaker position.")
    breaker_pole_count: Optional[int] = Field(None, description="Filter by breaker pole count.")
    query: Optional[str] = Field(None, description="Case-insensitive contains filter on power feed name.")
    limit: int = Field(5, description="Maximum number of power feeds to return.")


class GetPowerFeedParams(BaseModel):
    """Parameters for getting a single power feed."""

    id: Optional[str] = Field(None, description="Power feed primary key/UUID.")
    name: Optional[str] = Field(None, description="Power feed name to retrieve.")
    location: Optional[str] = Field(None, description="Filter by locations name or ID (best-effort).")
    power_panel: Optional[str] = Field(None, description="Filter by power panel name or ID (best-effort).")
    destination_panel: Optional[str] = Field(None, description="Filter by destination panel name or ID (best-effort).")
    rack: Optional[str] = Field(None, description="Filter by rack name or ID (best-effort).")
    power_path: Optional[str] = Field(None, description="Filter by power path (best-effort).")
    status: Optional[str] = Field(None, description="Filter by status slug or name (best-effort).")
    type: Optional[str] = Field(None, description="Filter by power feed type (best-effort).")
    supply: Optional[str] = Field(None, description="Filter by supply type (ac/dc).")
    voltage: Optional[int] = Field(None, description="Filter by voltage.")
    amperage: Optional[int] = Field(None, description="Filter by amperage.")
    phase: Optional[str] = Field(None, description="Filter by phase (single-phase/three-phase).")
    tags: Optional[str] = Field(None, description="Filter by tag slug/name.")
    max_utilization: Optional[int] = Field(None, description="Filter by maximum utilization percentage.")
    breaker_position: Optional[str] = Field(None, description="Filter by breaker position.")
    breaker_pole_count: Optional[int] = Field(None, description="Filter by breaker pole count.")
    query: Optional[str] = Field(None, description="Case-insensitive contains filter on power feed name.")


PLAIN_FIELDS: List[str] = POWER_FEEDS_PLAIN_FIELDS
RELATION_FIELDS: List[str] = POWER_FEEDS_RELATION_FIELDS
MULTI_RELATION_FIELDS: List[str] = POWER_FEEDS_MULTI_RELATION_FIELDS


def list_power_feeds(api: pynautobot.core.api.Api, params: ListPowerFeedsParams) -> Dict[str, Any]:
    return list_tools(
        api=api,
        endpoint=api.dcim.power_feeds,
        params=params,
        plain_fields=POWER_FEEDS_PLAIN_FIELDS,
        relation_fields=POWER_FEEDS_RELATION_FIELDS,
        multi_relation_fields=POWER_FEEDS_MULTI_RELATION_FIELDS,
        result_key="power_feeds",
        limit=getattr(params, "limit", 5),
    )


def get_power_feed(api: pynautobot.core.api.Api, params: GetPowerFeedParams) -> Dict[str, Any]:
    return get_tools(
        api=api,
        endpoint=api.dcim.power_feeds,
        params=params,
        plain_fields=POWER_FEEDS_PLAIN_FIELDS,
        relation_fields=POWER_FEEDS_RELATION_FIELDS,
        multi_relation_fields=POWER_FEEDS_MULTI_RELATION_FIELDS,
        result_key="power_feeds",
        lookup_fields=['id', 'name',"display"],
    )

def count_power_feed(api: pynautobot.core.api.Api, params: ListPowerFeedsParams) -> Dict[str, Any]:
    return count_tools(
        endpoint=api.dcim.power_feeds,
        params=params,
        resource_name="power_feeds",
    )
