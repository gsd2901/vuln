"""
Nautobot Ipam ip_address helpers for MCP server.

Provides simple CRUD helpers for Nautobot Ipam ip_addresses.
"""
from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional
import requests
import pynautobot
from pydantic import BaseModel, Field

from .nautobot_fields_actual import IP_ADDRESSES_PLAIN_FIELDS, IP_ADDRESSES_RELATION_FIELDS, IP_ADDRESSES_MULTI_RELATION_FIELDS
from .nautobot_relation_utils import list_tools, count_tools, get_tools,_get_token

logger = logging.getLogger(__name__)

class ListIpAddresssParams(BaseModel):
    # --- Existing parameters ---
    parent: Optional[str] = Field(None, description="Filter by parent prefix (ID/network). (for example: 00d83c44-390c-4ede-b9ea-be88733a5b0e)")
    id: Optional[str] = Field(None, description="Unique identifier (UUID) of the IP address object.")
    ip_version: Optional[int] = Field(None, description="Filter by IP version (4 or 6).")
    status: Optional[str] = Field(None, description="Filter by status slug/name.")
    role: Optional[str] = Field(
        None,
        description=(
            "Functional role assigned to this IP address (e.g. 'loopback', 'secondary', "
            "'anycast', 'vip', 'vrrp', 'hsrp', 'glbp', 'carp'). Filter by role slug/name."
        ),
    )
    tenant: Optional[str] = Field(
        None,
        description="Tenant that owns or is associated with this IP address. Filter by tenant slug/name.",
    )
    tenant_group: Optional[str] = Field(None, description="Filter by tenant group slug/name.")
    type: Optional[str] = Field(
        None,
        description=(
            "Address type classification. One of: 'host' (single host /32 or /128), "
            "'network' (network/subnet address), or 'anycast' (shared anycast address)."
        ),
    )
    name: Optional[str] = Field(None, description="Filter by address string (contains).")
    tags: Optional[str] = Field(None, description="Filter by tag slug/name.")
    query: Optional[str] = Field(None, description="General search query.")
    limit: int = Field(5, description="Maximum number of ip_addresses to return.")

    # --- Newly added parameters from the provided list ---
    address: Optional[str] = Field(
        None,
        description=(
            "Full IP address with prefix length to filter on, e.g. '192.168.1.10/24' or "
            "'2001:db8::1/64'. Combines host bits and mask in a single CIDR string."
        ),
    )
    host: Optional[str] = Field(
        None,
        description=(
            "Host portion of the IP address without the prefix length, e.g. '192.168.1.10'. "
            "Use this to filter by exact host address regardless of mask."
        ),
    )
    mask_length: Optional[int] = Field(
        None,
        description=(
            "Prefix length (subnet mask bits) of the IP address, e.g. 24 for /24 or 128 for /128. "
            "Valid range: 0–32 for IPv4, 0–128 for IPv6."
        ),
    )
    dns_name: Optional[str] = Field(
        None,
        description=(
            "Fully qualified domain name (FQDN) associated with this IP address, e.g. "
            "'router1.example.com'. Filter by DNS name (exact or contains)."
        ),
    )
    description: Optional[str] = Field(
        None,
        description=(
            "Human-readable description or note attached to the IP address record. "
            "Filter by description text (contains)."
        ),
    )
    nat_inside: Optional[str] = Field(
        None,
        description=(
            "ID or address of the inside (private) NAT IP address that this public IP translates to. "
            "Used to filter IP addresses by their NAT inside mapping."
        ),
    )
    created: Optional[str] = Field(
        None,
        description=(
            "Date or datetime when the IP address record was created in Nautobot, "
            "in ISO 8601 format (e.g. '2024-01-15' or '2024-01-15T10:30:00Z'). "
            "Supports filtering by exact date or date range."
        ),
    )
    last_updated: Optional[str] = Field(
        None,
        description=(
            "Date or datetime when the IP address record was last modified, "
            "in ISO 8601 format (e.g. '2024-06-01' or '2024-06-01T08:00:00Z'). "
            "Supports filtering by exact date or date range."
        ),
    )
    nat_outside_list: Optional[str] = Field(
        None,
        description=(
            "List of outside (public) NAT IP address IDs or addresses that map to this inside IP. "
            "Filter by one or more NAT outside entries (comma-separated IDs or CIDR strings)."
        ),
    )
    interfaces: Optional[str] = Field(
        None,
        description=(
            "ID or name of the physical/logical device interface this IP address is assigned to. "
            "Filter to return IP addresses that are bound to the specified interface."
        ),
    )
    vm_interfaces: Optional[str] = Field(
        None,
        description=(
            "ID or name of the virtual machine interface this IP address is assigned to. "
            "Filter to return IP addresses that are bound to the specified VM interface."
        ),
    )


class GetIpAddressParams(BaseModel):
    # --- Existing parameters ---
    limit: Optional[int] = Field(default=None, description="Max records to return when the IP exists in multiple namespaces")
    id: Optional[str] = Field(None, description="Unique identifier (UUID) of the IP address object.")
    name: Optional[str] = Field(None, description="IpAddress name.")
    address: Optional[str] = Field(
        None,
        description=(
            "Full IP address with prefix length, e.g. '1.1.1.1/32' or '2001:db8::1/64'. "
            "Combines host bits and mask in a single CIDR string."
        ),
    )
    tags: Optional[str] = Field(None, description="Filter by tag slug/name.")
    parent: Optional[str] = Field(None, description="Filter by parent prefix (ID/network).")
    ip_version: Optional[int] = Field(None, description="Filter by IP version (4 or 6).")
    status: Optional[str] = Field(None, description="Filter by status slug/name.")
    role: Optional[str] = Field(
        None,
        description=(
            "Functional role assigned to this IP address (e.g. 'loopback', 'secondary', "
            "'anycast', 'vip', 'vrrp', 'hsrp', 'glbp', 'carp'). Filter by role slug/name."
        ),
    )
    tenant: Optional[str] = Field(
        None,
        description="Tenant that owns or is associated with this IP address. Filter by tenant slug/name.",
    )
    query: Optional[str] = Field(None, description="General search query.")
    tenant_group: Optional[str] = Field(None, description="Filter by tenant group slug/name.")
    type: Optional[str] = Field(
        None,
        description=(
            "Address type classification. One of: 'host' (single host /32 or /128), "
            "'network' (network/subnet address), or 'anycast' (shared anycast address)."
        ),
    )

    # --- Newly added parameters from the provided list ---
    host: Optional[str] = Field(
        None,
        description=(
            "Host portion of the IP address without the prefix length, e.g. '192.168.1.10'. "
            "Use this to filter by exact host address regardless of mask."
        ),
    )
    mask_length: Optional[int] = Field(
        None,
        description=(
            "Prefix length (subnet mask bits) of the IP address, e.g. 24 for /24 or 128 for /128. "
            "Valid range: 0–32 for IPv4, 0–128 for IPv6."
        ),
    )
    dns_name: Optional[str] = Field(
        None,
        description=(
            "Fully qualified domain name (FQDN) associated with this IP address, e.g. "
            "'router1.example.com'. Filter by DNS name (exact or contains)."
        ),
    )
    description: Optional[str] = Field(
        None,
        description=(
            "Human-readable description or note attached to the IP address record. "
            "Filter by description text (contains)."
        ),
    )
    nat_inside: Optional[str] = Field(
        None,
        description=(
            "ID or address of the inside (private) NAT IP address that this public IP translates to. "
            "Used to retrieve the IP address by its NAT inside mapping."
        ),
    )
    created: Optional[str] = Field(
        None,
        description=(
            "Date or datetime when the IP address record was created in Nautobot, "
            "in ISO 8601 format (e.g. '2024-01-15' or '2024-01-15T10:30:00Z'). "
            "Supports filtering by exact date or date range."
        ),
    )
    last_updated: Optional[str] = Field(
        None,
        description=(
            "Date or datetime when the IP address record was last modified, "
            "in ISO 8601 format (e.g. '2024-06-01' or '2024-06-01T08:00:00Z'). "
            "Supports filtering by exact date or date range."
        ),
    )
    nat_outside_list: Optional[str] = Field(
        None,
        description=(
            "List of outside (public) NAT IP address IDs or addresses that map to this inside IP. "
            "Filter by one or more NAT outside entries (comma-separated IDs or CIDR strings)."
        ),
    )
    interfaces: Optional[str] = Field(
        None,
        description=(
            "ID or name of the physical/logical device interface this IP address is assigned to. "
            "Retrieve IP addresses that are bound to the specified interface."
        ),
    )
    vm_interfaces: Optional[str] = Field(
        None,
        description=(
            "ID or name of the virtual machine interface this IP address is assigned to. "
            "Retrieve IP addresses that are bound to the specified VM interface."
        ),
    )

PLAIN_FIELDS: List[str] = IP_ADDRESSES_PLAIN_FIELDS
RELATION_FIELDS: List[str] = IP_ADDRESSES_RELATION_FIELDS
MULTI_RELATION_FIELDS: List[str] = IP_ADDRESSES_MULTI_RELATION_FIELDS
FILTER_MAP: Dict[str, str] = {  "query": "q",}

def _is_uuid(value: str) -> bool:
    """Return True if value looks like a UUID (already resolved)."""
    import re
    return bool(re.fullmatch(
        r"[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}",
        value.strip(),
        re.IGNORECASE,
    ))

def _resolve_prefix_uuids(api: pynautobot.core.api.Api, cidr: str) -> List[str]:

    """

    Return ALL prefix UUIDs matching a CIDR string across all namespaces.
 
    e.g. '10.28.8.180/30' may exist in Chennai AND Madurai namespaces —

    both UUIDs are returned so IP addresses from all namespaces are fetched.

    """

    token = _get_token(api)

    if not token:

        raise ValueError("Cannot resolve Nautobot API token.")
 
    resp = requests.get(

        f"{api.base_url}/ipam/prefixes/",

        headers={
            "Authorization": f"Token {token}",
            "Content-Type": "application/json",
        },
        params={"prefix": cidr, "limit": 50},   # 50 is safe; same CIDR in 50 namespaces is unlikely
        timeout=30,
        proxies={"http": "", "https": ""},

    )

    resp.raise_for_status()

    results = resp.json().get("results", [])

    uuids = [r["id"] for r in results if r.get("id")]

    logger.info("_resolve_prefix_uuids: '%s' -> %s", cidr, uuids)

    return uuids

 
def list_ip_addresses(api: pynautobot.core.api.Api, params: ListIpAddresssParams) -> Dict[str, Any]:

    if not (params.parent and not _is_uuid(params.parent)):

        # parent is already a UUID or not set — pass straight through

        return list_tools(

            api=api,

            endpoint=api.ipam.ip_addresses,

            params=params,

            plain_fields=PLAIN_FIELDS,

            relation_fields=RELATION_FIELDS,

            multi_relation_fields=MULTI_RELATION_FIELDS,

            result_key="ip_addresses",

            filter_map=FILTER_MAP,

            limit=getattr(params, "limit", 5),

        )
 
    cidr = params.parent

    uuids = _resolve_prefix_uuids(api, cidr)
 
    if not uuids:

        return {

            "success": False,

            "message": f"Prefix '{cidr}' not found in any namespace.",

            "ip_addresses": [],

        }
 
    if len(uuids) == 1:

        # Fast path — single namespace, no merge needed

        resolved = params.model_copy(deep=True)

        resolved.parent = uuids[0]

        return list_tools(
            api=api,
            endpoint=api.ipam.ip_addresses,
            params=resolved,
            plain_fields=PLAIN_FIELDS,
            relation_fields=RELATION_FIELDS,
            multi_relation_fields=MULTI_RELATION_FIELDS,
            result_key="ip_addresses",
            filter_map=FILTER_MAP,
            limit=getattr(params, "limit", 5),

        )
 
    # Multiple namespaces — call list_tools once per UUID and merge

    logger.info("list_ip_addresses: prefix '%s' found in %d namespaces, merging", cidr, len(uuids))

    all_items = []

    total_count = 0

    limit = getattr(params, "limit", 5)
 
    for uuid in uuids:

        resolved = params.model_copy(deep=True)

        resolved.parent = uuid

        result = list_tools(

            api=api,

            endpoint=api.ipam.ip_addresses,

            params=resolved,

            plain_fields=PLAIN_FIELDS,

            relation_fields=RELATION_FIELDS,

            multi_relation_fields=MULTI_RELATION_FIELDS,

            result_key="ip_addresses",

            filter_map=FILTER_MAP,

            limit=limit,

        )

        if result.get("success"):

            all_items.extend(result.get("ip_addresses", []))

            total_count += result.get("count", len(result.get("ip_addresses", [])))
 
    return {

        "success": True,

        "message": f"Found {total_count} ip_addresses across {len(uuids)} namespaces for prefix '{cidr}'",

        "ip_addresses": all_items,

    }
 
 
def count_ip_addresses(api: pynautobot.core.api.Api, params: ListIpAddresssParams) -> Dict[str, Any]:

    """

Count IP address records in Nautobot IPAM matching the given filters.

Returns the total number of IP addresses that satisfy the specified criteria,
without fetching the full records. Accepts the same filter parameters as
list_ip_addresses — including parent prefix by UUID or CIDR string (resolved
automatically across all namespaces), hostname (dns_name), host address, IP version,
status, role, type, tenant, tags, and more.

Useful for capacity checks, auditing subnet utilization, or validating filter
criteria before running a full list query.

Examples:
- Count all IPs in a subnet:         parent="10.28.8.0/30"
- Count active loopbacks:            status="active", role="loopback"
- Count IPs for a tenant:            tenant="acme-corp"
- Count IPv6 addresses:              ip_version=6

    """

    if not (params.parent and not _is_uuid(params.parent)):

        return count_tools(

            endpoint=api.ipam.ip_addresses,

            params=params,

            filter_map=FILTER_MAP,

            resource_name="ip_addresses",

        )
 
    cidr = params.parent

    uuids = _resolve_prefix_uuids(api, cidr)
 
    if not uuids:

        return {

            "success": False,

            "message": f"Prefix '{cidr}' not found in any namespace.",

            "count": 0,

        }
 
    total = 0

    for uuid in uuids:

        resolved = params.model_copy(deep=True)

        resolved.parent = uuid

        result = count_tools(

            endpoint=api.ipam.ip_addresses,

            params=resolved,

            filter_map=FILTER_MAP,

            resource_name="ip_addresses",

        )

        if result.get("success"):

            total += result.get("count", 0)
 
    return {

        "success": True,

        "message": f"Found {total} ip_addresses across {len(uuids)} namespaces for prefix '{cidr}'",

        "count": total,

    }
 

def get_ip_address(api: pynautobot.core.api.Api, params: GetIpAddressParams) -> Dict[str, Any]:
    """
    Retrieve IP address record(s) from Nautobot IPAM by address, id, name or query
    Use `query` as a general fallback search (maps to Nautobot's `q=` filter) when
   you're unsure whether the value is an exact address, host, or dns_name.
    IMPORTANT FOR AGENT: The same address string can exist in multiple
    namespaces (e.g. Coimbatore and Madurai). If this tool's result contains
    a LIST under "ip_addresses" (not a single object) and "count" > 1, this
    means the address is ambiguous. In that case:
      - Do NOT stop after the first entry.
      - For each returned record, inspect its "interfaces" list; if non-empty,
        resolve the associated device and call get_device for it.
      - Report device details for every distinct device found, not just one.
    """
    return get_tools(
        api=api,
        endpoint=api.ipam.ip_addresses,
        params=params,
        plain_fields=PLAIN_FIELDS,
        relation_fields=RELATION_FIELDS,
        multi_relation_fields=MULTI_RELATION_FIELDS,
        filter_map=FILTER_MAP,
        result_key="ip_addresses",
        lookup_fields=['id', 'name', 'address' ,'query'],
    )


