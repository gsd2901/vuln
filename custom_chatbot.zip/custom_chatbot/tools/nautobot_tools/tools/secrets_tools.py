"""
Nautobot Extras secret helpers for MCP server.

Provides simple CRUD helpers for Nautobot Extras secrets.
"""
from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

import pynautobot
from pydantic import BaseModel, Field

from .nautobot_fields_actual import SECRETS_PLAIN_FIELDS, SECRETS_RELATION_FIELDS, SECRETS_MULTI_RELATION_FIELDS
from .nautobot_relation_utils import list_tools, count_tools, get_tools

logger = logging.getLogger(__name__)


class ListSecretsParams(BaseModel):
    name: Optional[str] = Field(None, description="Filter by secret name.")
    query: Optional[str] = Field(None, description="General search query.")
    limit: int = Field(5, description="Maximum number of secrets to return.")


class GetSecretParams(BaseModel):
    id: Optional[str] = Field(None, description="Secret ID or UUID.")
    name: Optional[str] = Field(None, description="Secret name.")


PLAIN_FIELDS: List[str] = SECRETS_PLAIN_FIELDS
RELATION_FIELDS: List[str] = SECRETS_RELATION_FIELDS
MULTI_RELATION_FIELDS: List[str] = SECRETS_MULTI_RELATION_FIELDS


def list_secrets(api: pynautobot.core.api.Api, params: ListSecretsParams) -> Dict[str, Any]:
    return list_tools(
        api=api,
        endpoint=api.extras.secrets,
        params=params,
        plain_fields=PLAIN_FIELDS,
        relation_fields=RELATION_FIELDS,
        multi_relation_fields=MULTI_RELATION_FIELDS,
        result_key="secrets",
        limit=getattr(params, "limit", 5),
    )


def get_secret(api: pynautobot.core.api.Api, params: GetSecretParams) -> Dict[str, Any]:
    return get_tools(
        api=api,
        endpoint=api.extras.secrets,
        params=params,
        plain_fields=PLAIN_FIELDS,
        relation_fields=RELATION_FIELDS,
        multi_relation_fields=MULTI_RELATION_FIELDS,
        result_key="secrets",
        lookup_fields=['id', 'name'],
    )
def count_secret(api: pynautobot.core.api.Api, params: ListSecretsParams) -> Dict[str, Any]:
    return count_tools(
        endpoint=api.extras.secrets,
        params=params,
        resource_name="secrets",
    )

