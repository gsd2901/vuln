"""
Nautobot Cloud cloud_resource_type helpers for MCP server.

Provides simple CRUD helpers for Nautobot Cloud cloud_resource_types.
"""
from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

import pynautobot
from pydantic import BaseModel, Field

from .nautobot_fields_actual import CLOUD_RESOURCE_TYPES_PLAIN_FIELDS, CLOUD_RESOURCE_TYPES_RELATION_FIELDS, CLOUD_RESOURCE_TYPES_MULTI_RELATION_FIELDS
from .nautobot_relation_utils import list_tools, count_tools, get_tools

logger = logging.getLogger(__name__)


class ListCloudResourceTypesParams(BaseModel):
    name: Optional[str] = Field(None, description="Filter by cloud_resource_type name.")
    content_types: Optional[str] = Field(None, description="Filter by content type(s), e.g. cloud.cloudservice.")
    provider: Optional[str] = Field(None, description="Filter by provider (manufacturer) name/slug/ID.")
    tags: Optional[str] = Field(None, description="Filter by tag name/slug.")
    query: Optional[str] = Field(None, description="General search query.")
    limit: int = Field(5, description="Maximum number of cloud_resource_types to return.")


class GetCloudResourceTypeParams(BaseModel):
    id: Optional[str] = Field(None, description="CloudResourceType ID or UUID.")
    name: Optional[str] = Field(None, description="CloudResourceType name.")


PLAIN_FIELDS: List[str] = CLOUD_RESOURCE_TYPES_PLAIN_FIELDS
RELATION_FIELDS: List[str] = CLOUD_RESOURCE_TYPES_RELATION_FIELDS
MULTI_RELATION_FIELDS: List[str] = CLOUD_RESOURCE_TYPES_MULTI_RELATION_FIELDS


def list_cloud_resource_types(api: pynautobot.core.api.Api, params: ListCloudResourceTypesParams) -> Dict[str, Any]:
    return list_tools(
        api=api,
        endpoint=api.cloud.cloud_resource_types,
        params=params,
        plain_fields=PLAIN_FIELDS,
        relation_fields=RELATION_FIELDS,
        multi_relation_fields=MULTI_RELATION_FIELDS,
        result_key="cloud_resource_types",
        limit=getattr(params, "limit", 5),
    )


def get_cloud_resource_type(api: pynautobot.core.api.Api, params: GetCloudResourceTypeParams) -> Dict[str, Any]:
    return get_tools(
        api=api,
        endpoint=api.cloud.cloud_resource_types,
        params=params,
        plain_fields=PLAIN_FIELDS,
        relation_fields=RELATION_FIELDS,
        multi_relation_fields=MULTI_RELATION_FIELDS,
        result_key="cloud_resource_types",
        lookup_fields=['id', 'name'],
    )
def count_cloud_resource_type(api: pynautobot.core.api.Api, params: ListCloudResourceTypesParams) -> Dict[str, Any]:
    return count_tools(
        endpoint=api.cloud.cloud_resource_types,
        params=params,
        resource_name="cloud_resource_types",
    )
