"""
Nautobot Extras tag helpers for MCP server.

Provides simple CRUD helpers for Nautobot Extras tags.
"""
from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

import pynautobot
from pydantic import BaseModel, Field

from .nautobot_fields_actual import TAGS_PLAIN_FIELDS, TAGS_RELATION_FIELDS, TAGS_MULTI_RELATION_FIELDS
from .nautobot_relation_utils import list_tools, count_tools, get_tools

logger = logging.getLogger(__name__)


class ListTagsParams(BaseModel):
    name: Optional[str] = Field(None, description="Filter by tag name.")
    query: Optional[str] = Field(None, description="General search query.")
    limit: int = Field(5, description="Maximum number of tags to return.")


class GetTagParams(BaseModel):
    id: Optional[str] = Field(None, description="Tag ID or UUID.")
    name: Optional[str] = Field(None, description="Tag name.")


PLAIN_FIELDS: List[str] = TAGS_PLAIN_FIELDS
RELATION_FIELDS: List[str] = TAGS_RELATION_FIELDS
MULTI_RELATION_FIELDS: List[str] = TAGS_MULTI_RELATION_FIELDS


def list_tags(api: pynautobot.core.api.Api, params: ListTagsParams) -> Dict[str, Any]:
    return list_tools(
        api=api,
        endpoint=api.extras.tags,
        params=params,
        plain_fields=PLAIN_FIELDS,
        relation_fields=RELATION_FIELDS,
        multi_relation_fields=MULTI_RELATION_FIELDS,
        result_key="tags",
        limit=getattr(params, "limit", 5),
    )


def get_tag(api: pynautobot.core.api.Api, params: GetTagParams) -> Dict[str, Any]:
    return get_tools(
        api=api,
        endpoint=api.extras.tags,
        params=params,
        plain_fields=PLAIN_FIELDS,
        relation_fields=RELATION_FIELDS,
        multi_relation_fields=MULTI_RELATION_FIELDS,
        result_key="tags",
        lookup_fields=['id', 'name'],
    )
def count_tag(api: pynautobot.core.api.Api, params: ListTagsParams) -> Dict[str, Any]:
    return count_tools(
        endpoint=api.extras.tags,
        params=params,
        resource_name="tags",
    )
