from nautobot.ipam.models import VLAN, Prefix
from nautobot.dcim.models import Interface
from django.core.exceptions import ObjectDoesNotExist
 
def get_vlan_details_sync(vlan_vid, site_name=None):
    try:
        if site_name:
            vlan = VLAN.objects.get(vid=vlan_vid, site__name=site_name)
        else:
            vlan = VLAN.objects.get(vid=vlan_vid)
 
        # Base VLAN Info
        vlan_info = (
            f"VLAN ID: {vlan.vid}\n"
            f"Name: {vlan.name}\n"
            f"Status: {vlan.status.name if vlan.status else 'None'}\n"
            f"Role: {vlan.role.name if vlan.role else 'None'}\n"
            f"Tenant: {vlan.tenant.name if vlan.tenant else 'None'}\n"
            f"VLAN Group: {vlan.vlan_group.name if vlan.vlan_group else 'None'}\n"
            f"Description: {vlan.description or 'None'}\n"
            f"Created: {vlan.created}\n"
            f"Last Updated: {vlan.last_updated}\n"
        )
 
        # Locations associated with the VLAN
        location_info = (
            ", ".join([location.name for location in vlan.locations.all()])
            if vlan.locations.exists()
            else "None"
        )
 
        vlan_info += f"Locations: {location_info}\n"
 
        # Prefix Details associated with this VLAN
        prefixes = Prefix.objects.filter(vlan=vlan)
        if prefixes.exists():
            prefix_list = "\n  " + "\n  ".join(
                [
                    f"Prefix: {prefix.prefix}, Network: {prefix.network}, "
                    f"Broadcast: {prefix.broadcast}, Prefix Length: {prefix.prefix_length}, "
                    f"IP Version: {prefix.ip_version}, Status: {prefix.status.name if prefix.status else 'None'}, "
                    f"Role: {prefix.role.name if prefix.role else 'None'}, "
                    f"Description: {prefix.description or 'None'}, "
                    f"Created: {prefix.created}, Last Updated: {prefix.last_updated}"
                    for prefix in prefixes
                ]
            )
        else:
            prefix_list = "  None"
 
        prefix_info = f"\nAssociated Prefixes ({prefixes.count()}):{prefix_list}"
 
        # Interfaces using this VLAN
        untagged_ifaces = Interface.objects.filter(untagged_vlan=vlan)
        tagged_ifaces = Interface.objects.filter(tagged_vlans=vlan)
 
        def summarize_ifaces(ifaces):
            summary = []
            for iface in ifaces[:10]:
                dev_name = iface.device.name if iface.device else "Unknown Device"
                summary.append(f"{dev_name} - {iface.name}")
            if ifaces.count() > 10:
                summary.append(f"...and {ifaces.count() - 10} more")
            return "\n  " + "\n  ".join(summary) if summary else "  None"
 
        vlan_usage = (
            f"\nUntagged Interfaces ({untagged_ifaces.count()}):{summarize_ifaces(untagged_ifaces)}"
            f"\n\nTagged Interfaces ({tagged_ifaces.count()}):{summarize_ifaces(tagged_ifaces)}"
        )
 
        # Additional Fields for Prefix Info (from JSON)
        prefix_details = []
        for prefix in prefixes:
            details = {
                "object_type": "ipam.prefix",
                "display": f"{prefix.prefix}: {prefix.description}",
                "url": f"https://demo.nautobot.com/api/ipam/prefixes/{prefix.id}/?format=json",
                "natural_slug": prefix.natural_slug,
                "prefix": prefix.prefix,
                "type": {"value": "network", "label": "Network"},
                "network": prefix.network,
                "broadcast": prefix.broadcast,
                "prefix_length": prefix.prefix_length,
                "ip_version": prefix.ip_version,
                "date_allocated": prefix.date_allocated,
                "description": prefix.description,
                "status": {
                    "id": prefix.status.id if prefix.status else None,
                    "object_type": "extras.status",
                    "url": f"https://demo.nautobot.com/api/extras/statuses/{prefix.status.id}/?format=json" if prefix.status else None
                },
                "role": {
                    "id": prefix.role.id if prefix.role else None,
                    "object_type": "extras.role",
                    "url": f"https://demo.nautobot.com/api/extras/roles/{prefix.role.id}/?format=json" if prefix.role else None
                },
                "parent": None,  # Handle if parent exists
                "namespace": {
                    "id": prefix.namespace.id if prefix.namespace else None,
                    "object_type": "ipam.namespace",
                    "url": f"https://demo.nautobot.com/api/ipam/namespaces/{prefix.namespace.id}/?format=json" if prefix.namespace else None
                },
                "tenant": None,  # Handle if tenant exists
                "vlan": None,  # Handle if VLAN exists
                "rir": None,  # Handle if RIR exists
                "locations": [],  # Handle locations if applicable
                "created": prefix.created,
                "last_updated": prefix.last_updated,
                "tags": [],  # Handle if tags exist
                "notes_url": f"https://demo.nautobot.com/api/ipam/prefixes/{prefix.id}/notes/?format=json",
                "custom_fields": {},  # Handle custom fields if applicable
                "vrfs": []  # Handle VRF if applicable
            }
            prefix_details.append(details)
 
        prefix_details_info = f"\nPrefix Details: {prefix_details}"
 
        return vlan_info + prefix_info + vlan_usage + prefix_details_info
 
    except ObjectDoesNotExist:
        return f"VLAN with ID '{vlan_vid}' not found" + (f" at site '{site_name}'." if site_name else ".")