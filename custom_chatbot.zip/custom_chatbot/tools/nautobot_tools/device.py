from nautobot.dcim.models import Device, Interface
from django.core.exceptions import ObjectDoesNotExist
from nautobot_mcp.tools.registry import register_tool

import logging
import random
# from dataclasses import dataclass
from typing import Dict, List, Optional
from django.conf import settings
from asgiref.sync import sync_to_async

import requests

# from tools.auth.auth_manager import AuthManager
# from config import ServerConfig

logger = logging.getLogger(__name__)

@register_tool
async def get_device_by_name(name: str) -> str:
    """Get platform details by name."""

    @sync_to_async
    def get_device_details_sync(device_name):
        """
        Fetch detailed information about a device by its name.
        Includes metadata like site, role, platform, status, interfaces, and more.
        """
        try:
            # settings.PLUGINNED_APPS.add("nautobot_plugin")
            
            device = Device.objects.get(name=device_name)
    
            device_info = {
                "Name": device.name,
                "Display Name": str(device),
                "Device Role": device.device_role.name if device.device_role else "None",
                "Device Type": device.device_type.model if device.device_type else "None",
                "Manufacturer": device.device_type.manufacturer.name if device.device_type and device.device_type.manufacturer else "None",
                "Platform": device.platform.name if device.platform else "None",
                "Serial": device.serial or "None",
                "Asset Tag": device.asset_tag or "None",
                "Status": device.status.name if device.status else "None",
                "Site": device.site.name if device.site else "None",
                "Location": device.location.name if device.location else "None",
                "Rack": device.rack.name if device.rack else "None",
                "Tenant": device.tenant.name if device.tenant else "None",
                "Description": device.description or "None",
                "Primary IP4": str(device.primary_ip4) if device.primary_ip4 else "None",
                "Primary IP6": str(device.primary_ip6) if device.primary_ip6 else "None",
                "Created": str(device.created),
                "Last Updated": str(device.last_updated),
                "Tags": [tag.name for tag in device.tags.all()] if device.tags.exists() else [],
                "Custom Fields": device.custom_field_data or {},
            }
    
            # Interfaces
            interfaces = Interface.objects.filter(device=device)
            interface_list = []
            for iface in interfaces:
                interface_list.append({
                    "Name": iface.name,
                    "Type": iface.type,
                    "Enabled": iface.enabled,
                    "MAC Address": iface.mac_address,
                    "MTU": iface.mtu,
                    "Mode": iface.mode,
                    "Description": iface.description,
                    "Tagged VLANs": [vlan.vid for vlan in iface.tagged_vlans.all()],
                    "Untagged VLAN": iface.untagged_vlan.vid if iface.untagged_vlan else None,
                    "IP Addresses": [str(ip.address) for ip in iface.ip_addresses.all()],
                })
    
            device_info["Interfaces"] = interface_list
    
            return device_info
    
        except ObjectDoesNotExist:
            return {"error": f"Device '{device_name}' not found."}
    return await get_device_details_sync(name)