"""Run helper for `vlans_tools` - get or list vlans.

Usage examples:
  python run_vlans.py --id <id>
  python run_vlans.py --name "<name>"
  python run_vlans.py --list
  python run_vlans.py --list --name "<partial_name>"

Reads Nautobot connection info from environment `NAUTOBOT_URL` and
`NAUTOBOT_TOKEN` unless provided via CLI.
"""
from __future__ import annotations

import argparse
import os
import json
import sys
from typing import Optional

import pynautobot

# NAUTOBOT_URL="http://127.0.0.1:8099"
# NAUTOBOT_TOKEN="746bfc450f9602bdb587915400cfda8b5adda85b" 

from dotenv import load_dotenv
load_dotenv()

# Add parent directory to path to import from tools folder
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


from tools.vlans_tools import (
    list_vlans,
    get_vlan,)


def _build_api(url: str, token: str):
    return pynautobot.api(url, token=token)


def main(argv: Optional[list[str]] = None) -> int:
    p = argparse.ArgumentParser(description="Run vlans_tools against Nautobot")
    p.add_argument("--id", help="Vlan UUID/ID")
    p.add_argument("--name", help="Vlan name")
    p.add_argument("--query", help="General search query")
    p.add_argument("--list", action="store_true", help="List vlans instead of getting a single one")
    p.add_argument("--nautobot-url", help="Nautobot base URL", default=NAUTOBOT_URL)
    p.add_argument("--token", help="Nautobot API token", default=NAUTOBOT_TOKEN)
    args = p.parse_args(argv)

    if not args.nautobot_url or args.token is None:
        print("Nautobot URL and token must be provided via --nautobot-url/--token or NAUTOBOT_URL/NAUTOBOT_TOKEN", file=sys.stderr)
        return 2

    api = _build_api(args.nautobot_url, args.token)

    # List mode
    if args.list:
        params = ListVlansParams(
            name=args.name,
            query=args.query,
        )
        result = list_vlans(api, params)
        print(json.dumps(result, indent=2, default=str))
        return 0

    # Get mode (default)
    if not args.id and not args.name:
        print("Either --id or --name must be provided or use --list", file=sys.stderr)
        return 2

    params = GetVlanParams(id=args.id, name=args.name)
    result = get_vlan(api, params)

    print(json.dumps(result, indent=2, default=str))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
