#!/usr/bin/env python3
"""
Nautobot API Fetcher + Field Constants Generator
=================================================
Fetches data from all Nautobot endpoints using pynautobot and
auto-generates a nautobot_fields.py with PLAIN / RELATION / MULTI_RELATION
field constants derived from the actual API responses.

Usage:
    pip install pynautobot
    python nautobot_fetch_all.py --url https://your-nautobot --token your-token

Optional flags:
    --output      results.json        Save raw data (default: nautobot_results.json)
    --fields-out  nautobot_fields.py  Generated field constants file (default: nautobot_fields.py)
    --limit       100                 Max records per endpoint (default: 50)
    --endpoint    dcim.devices        Fetch only one endpoint
    --no-verify                       Disable SSL certificate verification
"""

import argparse
import json
import sys
from datetime import datetime

try:
    import pynautobot
except ImportError:
    print("pynautobot is not installed. Run: pip install pynautobot")
    sys.exit(1)


ENDPOINTS = {
    "apps": [
        "installed_apps",
        "ssot",
        "golden_config",
        "firewall",
        "nautobot_device_lifecycle_mgmt",
        "design_builder",
        "welcome_wizard",
        "nautobot_data_validation_engine",
        "nautobot_ui",
        "script_manager",
        "tool_integration",
        "bgp",
        "juniper_mist",
    ],
    "circuits": [
        "circuit_terminations",
        "circuit_types",
        "circuits",
        "provider_networks",
        "providers",
    ],
    "cloud": [
        "cloud_accounts",
        "cloud_network_prefix_assignments",
        "cloud_networks",
        "cloud_resource_types",
        "cloud_service_network_assignments",
        "cloud_services",
    ],
    "dcim": [
        "cables",
        "connected_device",
        "console_connections",
        "console_port_templates",
        "console_ports",
        "console_server_port_templates",
        "console_server_ports",
        "controller_managed_device_groups",
        "controllers",
        "device_bay_templates",
        "device_bays",
        "device_families",
        "device_redundancy_groups",
        "device_types",
        "device_types_to_software_image_files",
        "devices",
        "front_port_templates",
        "front_ports",
        "interface_connections",
        "interface_redundancy_group_associations",
        "interface_redundancy_groups",
        "interface_templates",
        "interface_vdc_assignments",
        # "interfaces",
        "inventory_items",
        "location_types",
        "locations",
        "manufacturers",
        "module_bay_templates",
        "module_bays",
        "module_types",
        "modules",
        "platforms",
        "power_connections",
        "power_feeds",
        "power_outlet_templates",
        "power_outlets",
        "power_panels",
        "power_port_templates",
        "power_ports",
        "rack_groups",
        "rack_reservations",
        "racks",
        "rear_port_templates",
        "rear_ports",
        "software_image_files",
        "software_versions",
        "virtual_chassis",
        "virtual_device_contexts",
    ],
    "extras": [
        "computed_fields",
        "config_context_schemas",
        "config_contexts",
        "contact_associations",
        "contacts",
        "content_types",
        "custom_field_choices",
        "custom_fields",
        "custom_links",
        "dynamic_group_memberships",
        "dynamic_groups",
        "export_templates",
        "external_integrations",
        "file_proxies",
        "git_repositories",
        "graphql_queries",
        "image_attachments",
        "job_buttons",
        "job_hooks",
        # "job_logs",
        "job_queue_assignments",
        "job_queues",
        "job_results",
        "jobs",
        "metadata_choices",
        "metadata_types",
        "notes",
        # "object_changes",
        "object_metadata",
        "relationship_associations",
        "relationships",
        "roles",
        "saved_views",
        "scheduled_jobs",
        "secrets",
        "secrets_groups",
        "secrets_groups_associations",
        "static_group_associations",
        "statuses",
        "tags",
        "teams",
        "user_saved_view_associations",
        "webhooks",
    ],
    "ipam": [
        "ip_address_to_interface",
        "ip_addresses",
        "namespaces",
        "prefix_location_assignments",
        "prefixes",
        "rirs",
        "route_targets",
        "services",
        "vlan_groups",
        "vlan_location_assignments",
        "vlans",
        "vrf_device_assignments",
        "vrf_prefix_assignments",
        "vrfs",
    ],
    "plugins": [
        "installed_plugins",
        "ssot",
        "golden_config",
        "firewall",
        "nautobot_device_lifecycle_mgmt",
        "design_builder",
        "welcome_wizard",
        "nautobot_data_validation_engine",
        "nautobot_ui",
        "script_manager",
        "tool_integration",
        "bgp",
        "juniper_mist",
    ],
    "status": [
        "django_version",
        "installed_apps",
        "nautobot_version",
        "nautobot_apps",
        "plugins",
        "python_version",
        "celery_workers_running",
    ],
    "tenancy": [
        "tenant_groups",
        "tenants",
    ],
    "users": [
        "config",
        "groups",
        "permissions",
        "tokens",
        "users",
    ],
    "virtualization": [
        "cluster_groups",
        "cluster_types",
        "clusters",
        "interfaces",
        "virtual_machines",
    ],
    "wireless": [
        "controller_managed_device_group_radio_profile_assignments",
        "controller_managed_device_group_wireless_network_assignments",
        "radio_profiles",
        "supported_data_rates",
        "wireless_networks",
    ],
}

SKIP_KEYS = {"object_type", "url", "display", "notes_url", "natural_slug", "custom_fields"}


def record_to_dict(record) -> dict:
    """
    Safely convert a pynautobot Record to a plain dict using its
    built-in dict representation — avoids all recursion issues.
    Falls back to __dict__ only if needed.
    """
    # pynautobot Records support dict() / behave like dicts
    try:
        return dict(record)
    except Exception:
        pass

    # Fallback: shallow copy of the internal _full_cache or __dict__
    try:
        data = record._full_cache        # internal raw JSON cache
        if isinstance(data, dict):
            return data
    except AttributeError:
        pass

    try:
        return {k: v for k, v in record.__dict__.items() if not k.startswith("_")}
    except Exception:
        return {}


def safe_value(value):
    """
    Convert a field value to something JSON-safe without deep recursion.
    pynautobot nested FK objects also support dict(), so we stay shallow.
    """
    if value is None or isinstance(value, (str, int, float, bool)):
        return value

    if isinstance(value, list):
        result = []
        for item in value:
            if item is None or isinstance(item, (str, int, float, bool)):
                result.append(item)
            else:
                try:
                    result.append(dict(item))
                except Exception:
                    result.append(str(item))
        return result

    # dict-like (nested FK object or plain dict)
    try:
        return dict(value)
    except Exception:
        return str(value)


def flatten_record(record) -> dict:
    """
    Return a one-level-deep plain dict for a record.
    Nested FK objects become {id, object_type, url} dicts.
    Lists of FK objects become lists of dicts.
    """
    raw = record_to_dict(record)
    flat = {}
    for key, value in raw.items():
        flat[key] = safe_value(value)
    return flat


def classify_fields(record: dict):
    """
    Split keys of a flat record dict into:
      plain          - scalar or inline dict without 'id'
      relation       - single FK dict containing 'id'
      multi_relation - list
    """
    plain, relation, multi_relation = [], [], []

    for key, value in record.items():
        if key in SKIP_KEYS:
            continue
        if isinstance(value, list):
            multi_relation.append(key)
        elif isinstance(value, dict) and "id" in value:
            relation.append(key)
        else:
            plain.append(key)

    return plain, relation, multi_relation


def merge_fields(existing: list, new_fields: list) -> list:
    seen = set(existing)
    for f in new_fields:
        if f not in seen:
            existing.append(f)
            seen.add(f)
    return existing


def fetch_endpoint(app_obj, resource_name: str, limit: int):
    endpoint = getattr(app_obj, resource_name, None)
    if endpoint is None:
        return None, f"Attribute '{resource_name}' not found on app"
    try:
        results = []
        for record in endpoint.all():
            if len(results) >= limit:
                break
            results.append(flatten_record(record))
        return results, None
    except Exception as e:
        err = str(e)
        # Treat 404s as "not available in this version" rather than hard errors
        if "could not be found" in err or "404" in err:
            return None, f"NOT_FOUND: {err}"
        return None, err


def generate_fields_py(field_map: dict, output_path: str):
    lines = [
        '"""',
        "Nautobot API Field Constants",
        "Auto-generated by nautobot_fetch_all.py",
        f"Generated at: {datetime.now().isoformat()}",
        "",
        "Field categories:",
        "  PLAIN_FIELDS          - primitive scalar values (str, int, bool, null, inline dicts)",
        "  RELATION_FIELDS       - single FK/nested object with {id, object_type, url}",
        "  MULTI_RELATION_FIELDS - list of FK/nested objects (many-to-many / tags)",
        '"""',
        "",
        "from typing import List",
        "",
    ]

    for app_name, resources in field_map.items():
        lines += [
            "",
            "# " + "=" * 78,
            f"# {app_name.upper()}",
            "# " + "=" * 78,
            "",
        ]
        for resource_name, fields in resources.items():
            prefix = resource_name.upper()
            if fields.get("error"):
                lines.append(f"# {prefix}: skipped — {fields['error']}")
                lines.append("")
                continue
            lines.append(f"{prefix}_PLAIN_FIELDS: List[str] = {json.dumps(fields.get('plain', []))}")
            lines.append(f"{prefix}_RELATION_FIELDS: List[str] = {json.dumps(fields.get('relation', []))}")
            lines.append(f"{prefix}_MULTI_RELATION_FIELDS: List[str] = {json.dumps(fields.get('multi_relation', []))}")
            lines.append("")

    with open(output_path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines))

    print(f"\n  Fields file written → {output_path}")


def main():
    parser = argparse.ArgumentParser(
        description="Fetch Nautobot endpoints and generate field constants"
    )
    parser.add_argument("--url",        required=True,                   help="Nautobot base URL")
    parser.add_argument("--token",      required=True,                   help="Nautobot API token")
    parser.add_argument("--output",     default="nautobot_results.json", help="Raw JSON output file")
    parser.add_argument("--fields-out", default="nautobot_fields.py",    help="Generated field constants file")
    parser.add_argument("--limit",      type=int, default=50,            help="Max records per endpoint (default: 50)")
    parser.add_argument("--endpoint",   default=None,                    help="Single endpoint, e.g. dcim.devices")
    parser.add_argument("--no-verify",  action="store_true",             help="Disable SSL certificate verification")
    args = parser.parse_args()

    print(f"\n{'='*60}")
    print(f"  Nautobot API Fetcher + Field Generator")
    print(f"{'='*60}")
    print(f"  URL        : {args.url}")
    print(f"  Limit      : {args.limit} records per endpoint")
    print(f"  Raw output : {args.output}")
    print(f"  Fields out : {args.fields_out}")
    print(f"{'='*60}\n")

    try:
        nb = pynautobot.api(url=args.url, token=args.token)
        if args.no_verify:
            import requests, urllib3
            session = requests.Session()
            session.verify = False
            nb.http_session = session
            urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
            print("  SSL verification disabled.\n")
    except Exception as e:
        print(f"[ERROR] Could not connect: {e}")
        sys.exit(1)

    targets = ENDPOINTS
    if args.endpoint:
        parts = args.endpoint.split(".")
        if len(parts) != 2:
            print("[ERROR] --endpoint must be <app>.<resource>, e.g. dcim.devices")
            sys.exit(1)
        app, resource = parts
        if app not in ENDPOINTS or resource not in ENDPOINTS.get(app, []):
            print(f"[ERROR] Unknown endpoint: {args.endpoint}")
            sys.exit(1)
        targets = {app: [resource]}

    raw_results = {}
    field_map   = {}
    summary     = {"fetched": 0, "empty": 0, "errors": 0, "skipped": 0, "not_found": 0}
    start_time  = datetime.now()

    for app_name, resources in targets.items():
        print(f"[{app_name.upper()}]")
        raw_results[app_name] = {}
        field_map[app_name]   = {}

        try:
            app_obj = getattr(nb, app_name)
        except AttributeError:
            msg = f"App '{app_name}' not available in this Nautobot version"
            print(f"  ! {msg} — skipping")
            for r in resources:
                raw_results[app_name][r] = {"error": msg}
                field_map[app_name][r]   = {"error": msg}
                summary["skipped"] += 1
            print()
            continue

        for resource in resources:
            label = f"{app_name}.{resource}"
            data, error = fetch_endpoint(app_obj, resource, args.limit)

            if error:
                if error.startswith("NOT_FOUND"):
                    print(f"  ~  {label:<50} not available in this Nautobot version")
                    raw_results[app_name][resource] = {"error": error}
                    field_map[app_name][resource]   = {"error": "endpoint not found"}
                    summary["not_found"] += 1
                else:
                    print(f"  ✗  {label:<50} ERROR: {error}")
                    raw_results[app_name][resource] = {"error": error}
                    field_map[app_name][resource]   = {"error": error}
                    summary["errors"] += 1
                continue

            raw_results[app_name][resource] = data

            plain_acc, relation_acc, multi_acc = [], [], []
            for record in data:
                p, r, m = classify_fields(record)
                merge_fields(plain_acc,    p)
                merge_fields(relation_acc, r)
                merge_fields(multi_acc,    m)

            field_map[app_name][resource] = {
                "plain":          plain_acc,
                "relation":       relation_acc,
                "multi_relation": multi_acc,
            }

            if not data:
                print(f"  -  {label:<50} 0 records")
                summary["empty"] += 1
            else:
                print(f"  ✓  {label:<50} {len(data):>4} records  "
                      f"plain={len(plain_acc)}  rel={len(relation_acc)}  multi={len(multi_acc)}")
                summary["fetched"] += 1

        print()

    # Save raw JSON
    output_data = {
        "meta": {
            "url": args.url,
            "fetched_at": datetime.now().isoformat(),
            "limit_per_endpoint": args.limit,
            "duration_seconds": round((datetime.now() - start_time).total_seconds(), 2),
            "summary": summary,
        },
        "data": raw_results,
    }
    with open(args.output, "w", encoding="utf-8") as f:
        json.dump(output_data, f, indent=2, default=str)
    print(f"  Raw data saved → {args.output}")

    # Generate nautobot_fields.py
    generate_fields_py(field_map, args.fields_out)

    print(f"\n{'='*60}")
    print(f"  Done in {output_data['meta']['duration_seconds']}s")
    print(f"  ✓ Fetched    : {summary['fetched']} endpoints")
    print(f"  - Empty      : {summary['empty']} endpoints")
    print(f"  ~ Not found  : {summary['not_found']} endpoints (skipped)")
    print(f"  ✗ Errors     : {summary['errors']} endpoints")
    print(f"  o Skipped    : {summary['skipped']} endpoints")
    print(f"  Raw data     : {args.output}")
    print(f"  Fields file  : {args.fields_out}")
    print(f"{'='*60}\n")


if __name__ == "__main__":
    main()