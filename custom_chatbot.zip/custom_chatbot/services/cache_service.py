"""
Caching service for vulnerability management data with smart TTL logic.
"""

import hashlib
import json
import logging
import time
from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional, Tuple

from django.core.cache import cache
from django.conf import settings

# Import functions with fallback handling
try:
    from ..vulnerebility_management.db.quries_postgresql import collect_impacted_devices
except ImportError:
    try:
        from vulnerebility_management.db.quries_postgresql import collect_impacted_devices
    except ImportError:
        collect_impacted_devices = None

logger = logging.getLogger(__name__)


class VMCacheService:
    """
    Smart caching service for vulnerability management data.
    
    Features:
    - TTL validation based on last scan time in database
    - Automatic cache invalidation when data is fresher than cache
    - Pagination support
    - Performance monitoring
    """
    
    # Default cache settings
    DEFAULT_TTL = 900  # 15 minutes
    MIN_TTL = 300      # 5 minutes minimum
    MAX_TTL = 3600     # 1 hour maximum
    
    # Cache key prefixes
    KEY_PREFIX = "vm_cache"
    DEVICES_KEY = "impacted_devices"
    ADVISORIES_KEY = "impacted_advisories"
    LAST_SCAN_KEY = "last_scan_time"
    
    @classmethod
    def _generate_cache_key(cls, endpoint: str, dnac_id: Optional[str] = None, **params) -> str:
        """Generate a consistent cache key for the given parameters."""
        key_parts = [cls.KEY_PREFIX, endpoint]
        
        if dnac_id:
            key_parts.append(f"dnac:{dnac_id}")
        
        # Add other parameters in sorted order for consistency
        if params:
            param_str = "&".join(f"{k}={v}" for k, v in sorted(params.items()))
            key_parts.append(f"params:{param_str}")
        
        key = ":".join(key_parts)
        
        # Hash if key is too long (Redis key limit is 512MB, but keep it reasonable)
        if len(key) > 200:
            key_hash = hashlib.md5(key.encode()).hexdigest()
            key = f"{cls.KEY_PREFIX}:hash:{key_hash}"
        
        return key
    
    @classmethod
    def _get_db_last_scan_time(cls, dnac_id: Optional[str] = None) -> Optional[datetime]:
        """Get the last scan time from database to validate cache freshness."""
        try:
            # Use the raw collection to get timestamp info
            try:
                from ..vulnerebility_management.db.database_postgresql import _collection
            except ImportError:
                from vulnerebility_management.db.database_postgresql import _collection
            
            with _collection("impacteddevices") as collection:
                # Get the most recent document based on created_at
                filter_doc = {"dnac_id": dnac_id} if dnac_id else {}
                recent_docs = collection.find(filter_doc, projection={"created_at": 1})
                
                if not recent_docs:
                    return None
                
                latest_time = None
                for doc in recent_docs:
                    if 'created_at' in doc:
                        doc_time = doc['created_at']
                        if isinstance(doc_time, str):
                            try:
                                doc_time = datetime.fromisoformat(doc_time.replace('Z', '+00:00'))
                            except ValueError:
                                continue
                        elif hasattr(doc_time, 'replace'):  # datetime object
                            pass  # Already a datetime
                        else:
                            continue
                        
                        if latest_time is None or doc_time > latest_time:
                            latest_time = doc_time
                
                return latest_time
                
        except Exception as e:
            logger.warning(f"Failed to get last scan time from database: {e}")
            # Fallback: assume cache is valid for a shorter time if we can't check DB
            return None
    
    @classmethod
    def _is_cache_valid(cls, cache_entry: Dict[str, Any], dnac_id: Optional[str] = None) -> bool:
        """
        Check if cached data is still valid by comparing with database scan time.
        
        Args:
            cache_entry: The cached entry with metadata
            dnac_id: DNAC instance ID
            
        Returns:
            True if cache is still valid, False if needs refresh
        """
        try:
            cache_time = cache_entry.get('cached_at')
            if not cache_time:
                return False
            
            # Parse cache timestamp
            if isinstance(cache_time, str):
                cache_time = datetime.fromisoformat(cache_time.replace('Z', '+00:00'))
            
            # Get database last scan time
            db_scan_time = cls._get_db_last_scan_time(dnac_id)
            
            # If no database scan time available, check TTL
            if db_scan_time is None:
                ttl_expired = datetime.now() - cache_time > timedelta(seconds=cls.DEFAULT_TTL)
                if ttl_expired:
                    logger.info("Cache TTL expired, no database scan time available")
                return not ttl_expired
            
            # If database has newer data than cache, invalidate
            if db_scan_time > cache_time:
                logger.info(f"Database has newer data (DB: {db_scan_time}, Cache: {cache_time})")
                return False
            
            # Check if cache is within TTL limits
            cache_age = datetime.now() - cache_time
            max_age = timedelta(seconds=cache_entry.get('ttl', cls.DEFAULT_TTL))
            
            is_valid = cache_age < max_age
            if not is_valid:
                logger.info(f"Cache TTL expired: age={cache_age}, max_age={max_age}")
            
            return is_valid
            
        except Exception as e:
            logger.error(f"Error validating cache: {e}")
            return False
    
    @classmethod
    def get_cached_data(cls, endpoint: str, dnac_id: Optional[str] = None, 
                       page: int = 1, page_size: int = 50, **params) -> Optional[Dict[str, Any]]:
        """
        Get cached data with smart validation.
        
        Args:
            endpoint: API endpoint name
            dnac_id: DNAC instance ID
            page: Page number for pagination
            page_size: Number of items per page
            **params: Additional cache parameters
            
        Returns:
            Cached data dict or None if cache miss/invalid
        """
        try:
            start_time = time.time()
            
            # Generate cache key without pagination for main data
            main_key = cls._generate_cache_key(endpoint, dnac_id, **params)
            
            # Get main cached entry
            cache_entry = cache.get(main_key)
            if not cache_entry:
                logger.debug(f"Cache miss for key: {main_key}")
                return None
            
            # Validate cache freshness
            if not cls._is_cache_valid(cache_entry, dnac_id):
                logger.info(f"Cache invalid for key: {main_key}")
                cls.invalidate_cache(endpoint, dnac_id, **params)
                return None
            
            # Extract full data
            full_data = cache_entry.get('data', [])
            total_count = len(full_data)
            
            # Apply pagination
            start_idx = (page - 1) * page_size
            end_idx = start_idx + page_size
            paginated_data = full_data[start_idx:end_idx]
            
            # Performance timing
            elapsed_time = (time.time() - start_time) * 1000
            logger.info(f"Cache hit for {endpoint}, returned {len(paginated_data)}/{total_count} items in {elapsed_time:.1f}ms")
            
            return {
                'data': paginated_data,
                'pagination': {
                    'page': page,
                    'page_size': page_size,
                    'total_count': total_count,
                    'total_pages': (total_count + page_size - 1) // page_size,
                    'has_next': end_idx < total_count,
                    'has_previous': page > 1
                },
                'cache_info': {
                    'cached_at': cache_entry.get('cached_at'),
                    'ttl': cache_entry.get('ttl'),
                    'cache_hit': True,
                    'elapsed_ms': elapsed_time
                }
            }
            
        except Exception as e:
            logger.error(f"Error retrieving cached data: {e}")
            return None
    
    @classmethod
    def set_cached_data(cls, endpoint: str, data: List[Dict[str, Any]], 
                       dnac_id: Optional[str] = None, ttl: Optional[int] = None, **params) -> bool:
        """
        Cache data with metadata and smart TTL.
        
        Args:
            endpoint: API endpoint name
            data: Data to cache
            dnac_id: DNAC instance ID
            ttl: Custom TTL in seconds (optional)
            **params: Additional cache parameters
            
        Returns:
            True if successfully cached
        """
        try:
            start_time = time.time()
            
            # Use default TTL if not specified
            if ttl is None:
                ttl = cls.DEFAULT_TTL
            
            # Clamp TTL to reasonable bounds
            ttl = max(cls.MIN_TTL, min(ttl, cls.MAX_TTL))
            
            # Create cache entry with metadata
            cache_entry = {
                'data': data,
                'cached_at': datetime.now().isoformat(),
                'ttl': ttl,
                'total_count': len(data),
                'endpoint': endpoint,
                'dnac_id': dnac_id,
                'params': params
            }
            
            # Generate cache key
            cache_key = cls._generate_cache_key(endpoint, dnac_id, **params)
            
            # Store in cache
            success = cache.set(cache_key, cache_entry, timeout=ttl)
            
            # Performance timing
            elapsed_time = (time.time() - start_time) * 1000
            
            if success:
                logger.info(f"Cached {len(data)} items for {endpoint} (TTL: {ttl}s) in {elapsed_time:.1f}ms")
            else:
                logger.error(f"Failed to cache data for {endpoint}")
            
            return success
            
        except Exception as e:
            logger.error(f"Error caching data: {e}")
            return False
    
    @classmethod
    def invalidate_cache(cls, endpoint: str, dnac_id: Optional[str] = None, **params) -> bool:
        """
        Invalidate specific cache entries.
        
        Args:
            endpoint: API endpoint name
            dnac_id: DNAC instance ID (optional)
            **params: Additional cache parameters
            
        Returns:
            True if cache was invalidated
        """
        try:
            cache_key = cls._generate_cache_key(endpoint, dnac_id, **params)
            result = cache.delete(cache_key)
            
            if result:
                logger.info(f"Cache invalidated for key: {cache_key}")
            else:
                logger.debug(f"No cache entry found for key: {cache_key}")
            
            return result
            
        except Exception as e:
            logger.error(f"Error invalidating cache: {e}")
            return False
    
    @classmethod
    def invalidate_all_vm_cache(cls) -> int:
        """
        Invalidate all VM-related cache entries.
        
        Returns:
            Number of cache entries invalidated
        """
        try:
            # This is Django cache backend specific - for Redis we might need different approach
            if hasattr(cache, 'delete_pattern'):
                # django-redis backend supports pattern deletion
                pattern = f"{cls.KEY_PREFIX}:*"
                deleted = cache.delete_pattern(pattern)
                logger.info(f"Invalidated {deleted} cache entries with pattern: {pattern}")
                return deleted
            else:
                # Fallback for other cache backends
                # Note: This is not efficient for large cache, but works as fallback
                logger.warning("Cache backend doesn't support pattern deletion, using manual invalidation")
                
                # Invalidate known endpoint patterns
                endpoints = [cls.DEVICES_KEY, cls.ADVISORIES_KEY]
                deleted = 0
                
                for endpoint in endpoints:
                    # Try common dnac_id values and no dnac_id
                    for dnac_id in [None, 'default', 'primary']:
                        if cls.invalidate_cache(endpoint, dnac_id):
                            deleted += 1
                
                logger.info(f"Manually invalidated {deleted} cache entries")
                return deleted
                
        except Exception as e:
            logger.error(f"Error invalidating all VM cache: {e}")
            return 0
    
    @classmethod
    def get_cache_stats(cls) -> Dict[str, Any]:
        """
        Get cache statistics and health information.
        
        Returns:
            Dictionary with cache statistics
        """
        try:
            stats = {
                'cache_backend': str(type(cache).__name__),
                'default_ttl': cls.DEFAULT_TTL,
                'timestamp': datetime.now().isoformat()
            }
            
            # Try to get cache backend specific stats
            if hasattr(cache, 'get_stats'):
                stats['backend_stats'] = cache.get_stats()
            
            return stats
            
        except Exception as e:
            logger.error(f"Error getting cache stats: {e}")
            return {'error': str(e)}