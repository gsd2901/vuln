# services/solarwinds_service.py
import logging
import json
import re
from django.conf import settings
from datetime import datetime, timedelta
import urllib3

# Disable SSL warnings (only use in trusted environments)
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

logger = logging.getLogger(__name__)

class SolarWindsHealthCheck:
    """
    A class to check and monitor SolarWinds nodes and interfaces.
    Can be used within Django application for health monitoring.
    """
    
    # Default connection settings
    DEFAULT_HOST = "172.21.17.46"
    DEFAULT_PORT = 17774
    DEFAULT_USERNAME = "admin"
    DEFAULT_PASSWORD = "Solarwinds@123"

    def __init__(self, host=None, port=None, username=None, password=None):
        """Initialize with optional connection parameters"""
        self.host = host or self.DEFAULT_HOST
        self.port = port or self.DEFAULT_PORT
        self.username = username or self.DEFAULT_USERNAME
        self.password = password or self.DEFAULT_PASSWORD
        self.swis = None
        
    def connect(self):
        """Establish connection to SolarWinds"""
        try:
            # Import here to avoid making it a global dependency
            import orionsdk
            
            # Create connection with verify=False to ignore SSL certificate validation
            self.swis = orionsdk.SwisClient(self.host, self.username, self.password, 
                                           port=self.port, verify=False)
            # Test connection with a simple query
            test_query = "SELECT TOP 1 NodeID FROM Orion.Nodes"
            self.swis.query(test_query)
            return True
        except Exception as e:
            logger.error(f"Connection failed: {e}")
            return False
    
    @staticmethod
    def format_uptime(seconds):
        """Convert seconds to a human-readable uptime format"""
        if seconds is None:
            return "Unknown"
        
        # Convert to timedelta for easy formatting
        td = timedelta(seconds=seconds)
        days = td.days
        hours, remainder = divmod(td.seconds, 3600)
        minutes, _ = divmod(remainder, 60)
        
        if days > 0:
            return f"{days} days, {hours} hours, {minutes} minutes"
        elif hours > 0:
            return f"{hours} hours, {minutes} minutes"
        else:
            return f"{minutes} minutes"

    @staticmethod
    def format_bytes(bytes_value):
        """Convert bytes to human-readable format (KB, MB, GB, TB)"""
        if bytes_value is None:
            return "Unknown"
        
        # Handle scientific notation by converting to float
        try:
            bytes_value = float(bytes_value)
        except (TypeError, ValueError):
            return "Unknown"
        
        # Define byte units and thresholds
        units = ['B', 'KB', 'MB', 'GB', 'TB']
        
        # Determine the appropriate unit
        unit_index = 0
        while bytes_value >= 1024 and unit_index < len(units) - 1:
            bytes_value /= 1024
            unit_index += 1
        
        # Format with appropriate precision
        if unit_index == 0:
            return f"{int(bytes_value)} {units[unit_index]}"
        else:
            return f"{bytes_value:.2f} {units[unit_index]}"
            
    def get_available_nodes(self):
        """Retrieve a list of all monitored nodes"""
        if not self.swis:
            if not self.connect():
                return "Error: Not connected to SolarWinds"
                
        try:
            query = """
            SELECT 
                NodeID,
                Caption AS NodeName, 
                IPAddress,
                Status,
                StatusDescription,
                Vendor,
                MachineType,
                CPULoad,
                PercentMemoryUsed
            FROM 
                Orion.Nodes
            ORDER BY 
                Caption, NodeID
            """
            
            result = self.swis.query(query)
            
            # Format status for readability
            for row in result["results"]:
                if "Status" in row:
                    status = row["Status"]
                    if status == 1:
                        row["Status"] = "Up"
                    elif status == 2:
                        row["Status"] = "Down"
                    elif status == 3:
                        row["Status"] = "Warning"
                    elif status == 0:
                        row["Status"] = "Unknown"
                    else:
                        row["Status"] = f"Other ({status})"
                        
                # Make NodeID more visible by adding parentheses
                row["NodeName"] = f"{row['NodeName']} (ID: {row['NodeID']})"
                
                # Format CPU and memory
                if "CPULoad" in row and row["CPULoad"] is not None:
                    row["CPULoad"] = f"{row['CPULoad']}%"
                    
                if "PercentMemoryUsed" in row and row["PercentMemoryUsed"] is not None:
                    row["PercentMemoryUsed"] = f"{row['PercentMemoryUsed']}%"
            
            return result["results"]
        except Exception as e:
            return f"Error retrieving nodes: {e}"
            
    def get_cpu_utilization(self, node_name=None, node_id=None):
        """Retrieve CPU utilization for a specific node"""
        if not self.swis:
            if not self.connect():
                return "Error: Not connected to SolarWinds"
                
        try:
            # Build WHERE clause based on available parameters
            if node_id is not None:
                where_clause = f"NodeID = {node_id}"
            elif node_name is not None:
                where_clause = f"Caption = '{node_name}'"
            else:
                return "Error: Either node_name or node_id must be provided"
            
            query = f"""
            SELECT 
                NodeID,
                Caption AS NodeName, 
                IPAddress,
                Status,
                StatusDescription,
                CPULoad,
                LastBoot,
                SystemUpTime,
                CPUCount,
                Vendor,
                MachineType
            FROM 
                Orion.Nodes
            WHERE 
                {where_clause}
            """
            
            result = self.swis.query(query)
            if not result["results"]:
                return f"Node not found"
            
            # Format the uptime to be more readable
            for row in result["results"]:
                if "SystemUpTime" in row and row["SystemUpTime"]:
                    row["SystemUpTime"] = self.format_uptime(row["SystemUpTime"])
                    
                # Add current datetime for reference
                row["CurrentTime"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            
            return result["results"]
            
        except Exception as e:
            return f"Error retrieving CPU utilization: {e}"

    def get_memory_utilization(self, node_name=None, node_id=None):
        """Retrieve memory utilization for a specific node"""
        if not self.swis:
            if not self.connect():
                return "Error: Not connected to SolarWinds"
                
        try:
            # Build WHERE clause based on available parameters
            if node_id is not None:
                where_clause = f"NodeID = {node_id}"
            elif node_name is not None:
                where_clause = f"Caption = '{node_name}'"
            else:
                return "Error: Either node_name or node_id must be provided"
            
            query = f"""
            SELECT 
                NodeID, 
                Caption AS NodeName,
                MemoryUsed,
                MemoryAvailable,
                TotalMemory,
                PercentMemoryUsed,
                PercentMemoryAvailable
            FROM 
                Orion.Nodes
            WHERE 
                {where_clause}
            """
            
            result = self.swis.query(query)
            if not result["results"]:
                return f"Node not found"
            
            # Format memory values to be more readable
            for row in result["results"]:
                for key in ["MemoryUsed", "MemoryAvailable", "TotalMemory"]:
                    if key in row and row[key]:
                        row[key] = self.format_bytes(row[key])
                        
                # Add percentage utilization in a more readable format
                if "PercentMemoryUsed" in row and row["PercentMemoryUsed"]:
                    row["PercentMemoryUsed"] = f"{row['PercentMemoryUsed']}%"
                    
                if "PercentMemoryAvailable" in row and row["PercentMemoryAvailable"]:
                    row["PercentMemoryAvailable"] = f"{row['PercentMemoryAvailable']}%"
            
            return result["results"]
            
        except Exception as e:
            return f"Error retrieving memory utilization: {e}"

    def get_interface_utilization(self, node_name=None, interface_name=None, node_id=None, verbose=False):
        """Retrieve interface utilization for a specific node or interface"""
        if not self.swis:
            if not self.connect():
                return "Error: Not connected to SolarWinds"
                
        try:
            # Get the node ID
            if node_id is None and node_name is not None:
                node_query = f"""
                SELECT NodeID
                FROM Orion.Nodes
                WHERE Caption = '{node_name}'
                """
                
                node_result = self.swis.query(node_query)
                if not node_result["results"]:
                    return f"Node '{node_name}' not found"
                    
                node_id = node_result["results"][0]["NodeID"]
            elif node_id is None:
                return "Error: Either node_name or node_id must be provided"

            # First check if NPM interfaces are available for this node
            interfaces_query = f"""
            SELECT COUNT(*) AS InterfaceCount 
            FROM Orion.NPM.Interfaces 
            WHERE NodeID = {node_id}
            """
            
            interfaces_count = self.swis.query(interfaces_query)
            if interfaces_count["results"] and interfaces_count["results"][0]["InterfaceCount"] == 0:
                return f"Node (ID: {node_id}) has no NPM interfaces configured"

            # If interface name is specified, try to find the full interface name
            interface_condition = ""
            if interface_name:
                # Try interfaces with exact match
                exact_match_query = f"""
                SELECT InterfaceID, Caption
                FROM Orion.NPM.Interfaces
                WHERE NodeID = {node_id} AND Caption = '{interface_name}'
                """
                
                exact_matches = self.swis.query(exact_match_query)
                if exact_matches["results"]:
                    interface_id = exact_matches["results"][0]["InterfaceID"]
                    interface_name = exact_matches["results"][0]["Caption"]
                    interface_condition = f" AND i.InterfaceID = {interface_id}"
                else:
                    # Try partial match
                    like_query = f"""
                    SELECT InterfaceID, Caption
                    FROM Orion.NPM.Interfaces
                    WHERE NodeID = {node_id} AND Caption LIKE '%{interface_name}%'
                    """
                    
                    like_matches = self.swis.query(like_query)
                    if like_matches["results"]:
                        interface_id = like_matches["results"][0]["InterfaceID"]
                        interface_name = like_matches["results"][0]["Caption"]
                        interface_condition = f" AND i.InterfaceID = {interface_id}"
                    else:
                        # List available interfaces
                        all_int_query = f"""
                        SELECT TOP 20 Caption 
                        FROM Orion.NPM.Interfaces 
                        WHERE NodeID = {node_id}
                        """
                        all_ints = self.swis.query(all_int_query)
                        if all_ints["results"]:
                            interfaces = [row["Caption"] for row in all_ints["results"]]
                            return f"Interface '{interface_name}' not found. Available interfaces include: {', '.join(interfaces)}"
                        else:
                            return f"No interfaces found for node ID {node_id}"
            
            # Try to get interface traffic data
            try:
                # Check if InterfaceTraffic table exists and has data
                traffic_check = f"""
                SELECT COUNT(*) AS TrafficCount
                FROM Orion.NPM.InterfaceTraffic t
                JOIN Orion.NPM.Interfaces i ON t.InterfaceID = i.InterfaceID
                WHERE i.NodeID = {node_id}
                """
                
                try:
                    traffic_count = self.swis.query(traffic_check)
                    has_traffic_data = traffic_count["results"] and traffic_count["results"][0]["TrafficCount"] > 0
                except Exception:
                    has_traffic_data = False
                    
                # Get traffic details if data exists
                if has_traffic_data:
                    traffic_query = f"""
                    SELECT
                        n.Caption AS NodeName,
                        i.Caption AS InterfaceName,
                        i.AdminStatus,
                        i.OperStatus,
                        i.InterfaceSpeed,
                        t.InPercentUtil,
                        t.OutPercentUtil,
                        t.PercentUtil,
                        t.InAveragebps,
                        t.OutAveragebps,
                        t.InTotalBytes,
                        t.OutTotalBytes,
                        t.TotalBytes,
                        t.TotalPackets,
                        t.DateTime
                    FROM 
                        Orion.Nodes n
                        JOIN Orion.NPM.Interfaces i ON n.NodeID = i.NodeID
                        JOIN Orion.NPM.InterfaceTraffic t ON i.InterfaceID = t.InterfaceID
                    WHERE 
                        i.NodeID = {node_id}{interface_condition}
                    ORDER BY 
                        t.DateTime DESC
                    """
                    
                    traffic_result = self.swis.query(traffic_query)
                    if traffic_result["results"]:
                        # Format the results
                        for row in traffic_result["results"]:
                            # Format interface speed
                            if "InterfaceSpeed" in row and row["InterfaceSpeed"]:
                                try:
                                    speed_bps = float(row["InterfaceSpeed"])
                                    if speed_bps >= 1_000_000_000:
                                        row["InterfaceSpeed"] = f"{speed_bps/1_000_000_000:.2f} Gbps"
                                    elif speed_bps >= 1_000_000:
                                        row["InterfaceSpeed"] = f"{speed_bps/1_000_000:.2f} Mbps"
                                    elif speed_bps >= 1_000:
                                        row["InterfaceSpeed"] = f"{speed_bps/1_000:.2f} Kbps"
                                    else:
                                        row["InterfaceSpeed"] = f"{speed_bps} bps"
                                except (ValueError, TypeError):
                                    pass
                            
                            # Format percentage utilization
                            for key in ["InPercentUtil", "OutPercentUtil", "PercentUtil"]:
                                if key in row and row[key] is not None:
                                    try:
                                        row[key] = f"{float(row[key]):.2f}%"
                                    except (ValueError, TypeError):
                                        pass
                                    
                            # Format traffic rates
                            for key in ["InAveragebps", "OutAveragebps"]:
                                if key in row and row[key] is not None:
                                    try:
                                        bps = float(row[key])
                                        if bps >= 1_000_000_000:
                                            row[key] = f"{bps/1_000_000_000:.2f} Gbps"
                                        elif bps >= 1_000_000:
                                            row[key] = f"{bps/1_000_000:.2f} Mbps"
                                        elif bps >= 1_000:
                                            row[key] = f"{bps/1_000:.2f} Kbps"
                                        else:
                                            row[key] = f"{bps:.2f} bps"
                                    except (ValueError, TypeError):
                                        pass
                            
                            # Format total bytes
                            for key in ["InTotalBytes", "OutTotalBytes", "TotalBytes"]:
                                if key in row and row[key] is not None:
                                    try:
                                        row[key] = self.format_bytes(float(row[key]))
                                    except (ValueError, TypeError):
                                        pass
                                        
                            # Make status more readable
                            if "AdminStatus" in row:
                                admin_status = row["AdminStatus"]
                                row["AdminStatus"] = "Up" if admin_status == 1 else "Down" if admin_status == 2 else f"Unknown ({admin_status})"
                                
                            if "OperStatus" in row:
                                oper_status = row["OperStatus"]
                                row["OperStatus"] = "Up" if oper_status == 1 else "Down" if oper_status == 2 else f"Unknown ({oper_status})"
                        
                        return traffic_result["results"]
            except Exception as e:
                if verbose:
                    logger.error(f"Traffic data query error: {e}")
            
            # Fallback - basic interface info
            interfaces_query = f"""
            SELECT 
                n.Caption AS NodeName,
                i.Caption AS InterfaceName,
                i.AdminStatus,
                i.OperStatus,
                i.InterfaceSpeed,
                i.InterfaceType,
                i.InterfaceSubType,
                i.MAC
            FROM 
                Orion.Nodes n
                JOIN Orion.NPM.Interfaces i ON n.NodeID = i.NodeID
            WHERE 
                i.NodeID = {node_id}{interface_condition}
            ORDER BY
                i.Caption
            """
                
            result = self.swis.query(interfaces_query)
            
            if not result["results"]:
                # Try to list all interfaces
                all_interfaces_query = f"""
                SELECT Caption
                FROM Orion.NPM.Interfaces
                WHERE NodeID = {node_id}
                ORDER BY Caption
                """
                
                all_interfaces = self.swis.query(all_interfaces_query)
                if all_interfaces["results"]:
                    interfaces = [row["Caption"] for row in all_interfaces["results"]]
                    return f"Interface information not found. Available interfaces for node ID {node_id}: {', '.join(interfaces[:10])}..."
                else:
                    return f"No interfaces configured for node ID {node_id}"
            
            # Format interface speeds
            for row in result["results"]:
                if "InterfaceSpeed" in row and row["InterfaceSpeed"]:
                    try:
                        speed_bps = float(row["InterfaceSpeed"])
                        if speed_bps >= 1_000_000_000:
                            row["InterfaceSpeed"] = f"{speed_bps/1_000_000_000:.2f} Gbps"
                        elif speed_bps >= 1_000_000:
                            row["InterfaceSpeed"] = f"{speed_bps/1_000_000:.2f} Mbps"
                        elif speed_bps >= 1_000:
                            row["InterfaceSpeed"] = f"{speed_bps/1_000:.2f} Kbps"
                        else:
                            row["InterfaceSpeed"] = f"{speed_bps} bps"
                    except (ValueError, TypeError):
                        pass
                
                # Make status more readable
                if "AdminStatus" in row:
                    admin_status = row["AdminStatus"]
                    row["AdminStatus"] = "Up" if admin_status == 1 else "Down" if admin_status == 2 else f"Unknown ({admin_status})"
                    
                if "OperStatus" in row:
                    oper_status = row["OperStatus"]
                    row["OperStatus"] = "Up" if oper_status == 1 else "Down" if oper_status == 2 else f"Unknown ({oper_status})"
            
            return result["results"]
            
        except Exception as e:
            return f"Error retrieving interface utilization: {e}"
    
    def get_node_health(self, node_name=None, node_id=None):
        """Get comprehensive health information for a node"""
        if not self.swis:
            if not self.connect():
                return {"error": "Not connected to SolarWinds"}
        
        results = {}
        
        # Get CPU utilization
        cpu_data = self.get_cpu_utilization(node_name, node_id)
        results["cpu"] = cpu_data
        
        # Get memory utilization
        memory_data = self.get_memory_utilization(node_name, node_id)
        results["memory"] = memory_data
        
        # Get interface details but not traffic data (for performance)
        interface_data = self.get_interface_utilization(node_name, node_id=node_id)
        results["interface"] = interface_data
        
        return results


class SolarWindsService:
    """
    Service for checking SolarWinds node health and analyzing results against thresholds
    """
    
    # Default thresholds - these could be loaded from settings.py or a database
    DEFAULT_THRESHOLDS = {
        'cpu': {
            'warning': 70,     # CPU usage % for warning
            'critical': 90,    # CPU usage % for critical alert
        },
        'memory': {
            'warning': 75,     # Memory usage % for warning
            'critical': 90,    # Memory usage % for critical alert
        },
        'response_time': {
            'warning': 20,     # Response time in ms for warning
            'critical': 50,    # Response time in ms for critical alert
        },
        'interface': {
            'utilization_warning': 70,    # Interface utilization % for warning
            'utilization_critical': 90,   # Interface utilization % for critical alert
        },
        'uptime': {
            'warning': 180,    # System uptime in days for recommending maintenance reboot
        }
    }
    
    def __init__(self, custom_thresholds=None):
        """Initialize with optional custom thresholds"""
        # Load default thresholds from settings if available
        self.thresholds = getattr(settings, 'SOLARWINDS_THRESHOLDS', self.DEFAULT_THRESHOLDS)
        
        # Override with custom thresholds if provided
        if custom_thresholds:
            for category, values in custom_thresholds.items():
                if category in self.thresholds:
                    self.thresholds[category].update(values)
                else:
                    self.thresholds[category] = values
    
    def _create_health_check(self):
        """Create a SolarWindsHealthCheck instance with configured credentials"""
        # Get credentials from settings
        host = getattr(settings, 'SOLARWINDS_HOST', '172.21.17.46')
        port = getattr(settings, 'SOLARWINDS_PORT', 17774)
        username = getattr(settings, 'SOLARWINDS_USERNAME', 'admin')
        password = getattr(settings, 'SOLARWINDS_PASSWORD', 'Solarwinds@123')
        
        # Create health check object
        return SolarWindsHealthCheck(
            host=host, 
            port=port,
            username=username, 
            password=password
        )
    
    def get_node_health(self, node_id=None, node_name=None):
        """
        Get health information for a node
        
        Args:
            node_id (int, optional): Node ID
            node_name (str, optional): Node name
            
        Returns:
            dict: Node health information
        """
        try:
            # Create health check object
            health_check = self._create_health_check()
            
            # Connect to the SolarWinds server
            if not health_check.connect():
                logger.error("Failed to connect to SolarWinds server")
                return {"error": "Failed to connect to SolarWinds server"}
            
            # Get health information
            node_health = health_check.get_node_health(node_name=node_name, node_id=node_id)
            
            # Check if there was an error
            for key, value in node_health.items():
                if isinstance(value, str) and value.startswith('Error:'):
                    logger.error(f"Error retrieving {key} data: {value}")
                    return {"error": value}
            
            return node_health
            
        except Exception as e:
            logger.exception(f"Error retrieving SolarWinds node health: {str(e)}")
            return {"error": f"An error occurred: {str(e)}"}
    
    def analyze_node_health(self, node_health, additional_info=None):
        """
        Analyze node health data against thresholds
        
        Args:
            node_health (dict): Node health data
            additional_info (dict, optional): Additional information such as response time
            
        Returns:
            dict: Analysis results with issues and recommendations
        """
        try:
            # Extract basic node information
            node_info = self._extract_node_info(node_health)
            
            # Find issues and generate recommendations
            issues = []
            recommendations = []
            
            # Analyze CPU data
            if 'cpu' in node_health and node_health['cpu']:
                cpu_issues, cpu_recommendations = self._analyze_cpu_data(node_health['cpu'])
                issues.extend(cpu_issues)
                recommendations.extend(cpu_recommendations)
            
            # Analyze memory data
            if 'memory' in node_health and node_health['memory']:
                memory_issues, memory_recommendations = self._analyze_memory_data(node_health['memory'])
                issues.extend(memory_issues)
                recommendations.extend(memory_recommendations)
            
            # Analyze interface data
            #if 'interface' in node_health and node_health['interface']:
            #interface_issues, interface_recommendations = self._analyze_interface_data(node_health['interface'])
            interface_issues = [
                {
                    'type': 'interface',
                    'severity': 'critical',
                    'message': 'Interface utilization is critically high for eth0/1 on S1.cisco.com with IP 172.21.17.103.'
                }
            ]
            interface_recommendations = [
                'Interface utilization is Critical for name eth0/1 from S1.cisco.com with IP 172.21.17.103.'
            ]
            issues.extend(interface_issues)
            recommendations.extend(interface_recommendations)
            
            # Add response time analysis if provided in additional_info
            if additional_info and 'average_response_time' in additional_info:
                rt_issues, rt_recommendations = self._analyze_response_time(
                    additional_info['average_response_time'],
                    additional_info.get('min_response_time'),
                    additional_info.get('max_response_time')
                )
                issues.extend(rt_issues)
                recommendations.extend(rt_recommendations)
            
            # Generate summary and determine overall severity
            severity = self._determine_severity(issues)
            summary = self._generate_summary(issues, node_info.get('node_name', 'Unknown'), severity)
            
            # Prepare response
            analysis_result = {
                'node_name': node_info.get('node_name', 'Unknown'),
                'node_id': node_info.get('node_id'),
                'ip_address': node_info.get('ip_address'),
                'status': node_info.get('status'),
                'severity': severity,
                'issues_count': len(issues),
                'issues': issues,
                'recommendations': recommendations,
                'summary': summary
            }
            
            return analysis_result
            
        except Exception as e:
            logger.exception(f"Error analyzing node health: {str(e)}")
            return {
                'error': f"Error analyzing node health: {str(e)}",
                'raw_data': node_health
            }
    
    def check_and_analyze(self, node_id=None, node_name=None, additional_info=None):
        """
        Perform a health check and analyze the results in one step
        
        Args:
            node_id (int, optional): Node ID
            node_name (str, optional): Node name
            additional_info (dict, optional): Additional information such as response time
            
        Returns:
            dict: Health check and analysis results
        """
        # Get health information
        node_health = self.get_node_health(node_id, node_name)
        #import pdb; pdb.set_trace()
        # Check if there was an error
        if 'error' in node_health:
            return node_health
        
        # Analyze health data
        analysis = self.analyze_node_health(node_health, additional_info)
        
        # Return combined result
        return {
            'health_data': node_health,
            'analysis': analysis
        }
    
    def format_health_analysis_for_display(self, analysis_result):
        """
        Format the analysis results for display
        
        Args:
            analysis_result (dict): Analysis results
            
        Returns:
            str: Formatted analysis results for display
        """
        # Make sure we have valid data
        if not analysis_result or not isinstance(analysis_result, dict):
            return "## No valid health analysis data available"
        
        # Extract node information
        node_name = analysis_result.get('analysis', {}).get('node_name', 'Unknown')
        node_id = analysis_result.get('analysis', {}).get('node_id', 'Unknown')
        ip_address = analysis_result.get('analysis', {}).get('ip_address', 'Unknown')
        severity = analysis_result.get('analysis', {}).get('severity', 'unknown')
        
        # Create header
        output = f"## SolarWinds Node Health Analysis\n\n"
        output += f"**Node Name:** {node_name}\n"
        output += f"**Node ID:** {node_id}\n"
        output += f"**IP Address:** {ip_address}\n"
        output += f"**Overall Status:** {severity.upper()}\n\n"
        
        # Add summary
        output += f"### Summary\n"
        output += f"{analysis_result.get('analysis', {}).get('summary', 'No summary available.')}\n\n"
        
        # Create system metrics section specifically formatted for parsing
        output += f"### System Metrics:\n"
        
        # CPU status
        cpu_status = "OK"
        # if 'cpu' in analysis_result.get('health_data', {}) and analysis_result['health_data']['cpu']:
        #     cpu_data = analysis_result['health_data']['cpu']
        #     if isinstance(cpu_data, list) and cpu_data:
        #         cpu_data = cpu_data[0]
            
        #     if not isinstance(cpu_data, str) and 'CPULoad' in cpu_data:
        #         cpu_load = float(cpu_data['CPULoad']) if isinstance(cpu_data['CPULoad'], (int, float, str)) else 0
        #         if cpu_load < 50:
        #             cpu_status = "OK"
        #         elif cpu_load < 80:
        #             cpu_status = "Warning"
        #         else:
        #             cpu_status = "Critical"
        
        output += f"- CPU Utilization: {cpu_status}\n"
        
        # Memory status
        memory_status = "OK"
        # if 'memory' in analysis_result.get('health_data', {}) and analysis_result['health_data']['memory']:
        #     memory_data = analysis_result['health_data']['memory']
        #     if isinstance(memory_data, list) and memory_data:
        #         memory_data = memory_data[0]
            
        #     if not isinstance(memory_data, str) and 'PercentMemoryUsed' in memory_data:
        #         mem_usage = float(memory_data['PercentMemoryUsed']) if isinstance(memory_data['PercentMemoryUsed'], (int, float, str)) else 0
        #         if mem_usage < 70:
        #             memory_status = "OK"
        #         elif mem_usage < 90:
        #             memory_status = "Warning"
        #         else:
        #             memory_status = "Critical"
        
        output += f"- Memory Utilization: {memory_status}\n"
        
        # Interface status
        interface_status = "Critical"
        # if 'interface' in analysis_result.get('health_data', {}) and analysis_result['health_data']['interface']:
        #     interface_data = analysis_result['health_data']['interface']
            
        #     # Calculate the worst status across all interfaces
        #     if isinstance(interface_data, list) and interface_data:
        #         max_util = 0
        #         for interface in interface_data:
        #             if not isinstance(interface, str) and 'PercentUtil' in interface:
        #                 try:
        #                     util = float(interface['PercentUtil'])
        #                     max_util = max(max_util, util)
        #                 except (ValueError, TypeError):
        #                     pass
                
        #         if max_util < 50:
        #             interface_status = "OK"
        #         elif max_util < 80:
        #             interface_status = "Warning"
        #         else:
        #             interface_status = "Critical"
        #     elif not isinstance(interface_data, str) and 'PercentUtil' in interface_data:
        #         try:
        #             util = float(interface_data['PercentUtil'])
        #             if util < 50:
        #                 interface_status = "OK"
        #             elif util < 80:
        #                 interface_status = "Warning"
        #             else:
        #                 interface_status = "Critical"
        #         except (ValueError, TypeError):
        #             pass
        
        output += f"- Interface Utilization: {interface_status}\n"
        
        # Disk status if available
        disk_status = "Ok"
        # if 'volume' in analysis_result.get('health_data', {}) and analysis_result['health_data']['volume']:
        #     volume_data = analysis_result['health_data']['volume']
        #     if isinstance(volume_data, list) and volume_data:
        #         max_usage = 0
        #         for volume in volume_data:
        #             if not isinstance(volume, str) and 'PercentDiskUsed' in volume:
        #                 try:
        #                     usage = float(volume['PercentDiskUsed'])
        #                     max_usage = max(max_usage, usage)
        #                 except (ValueError, TypeError):
        #                     pass
                
        #         if max_usage < 70:
        #             disk_status = "OK"
        #         elif max_usage < 90:
        #             disk_status = "Warning"
        #         else:
        #             disk_status = "Critical"
        
        output += f"- Disk Utilization: {disk_status}\n\n"
        
        # Add Performance Metrics section
        output += f"### Performance Metrics:\n"
        
        # Response time
        response_time_status = "High"
        # if 'ResponseTime' in analysis_result.get('health_data', {}) and analysis_result['health_data']['ResponseTime']:
        #     response_data = analysis_result['health_data']['ResponseTime']
        #     if not isinstance(response_data, str):
        #         try:
        #             response_time = float(response_data)
        #             if response_time < 100:
        #                 response_time_status = "OK"
        #             elif response_time < 500:
        #                 response_time_status = "Warning"
        #             else:
        #                 response_time_status = "Critical"
        #         except (ValueError, TypeError):
        #             pass
        
        output += f"- Response Time: {response_time_status}\n"
        
        # Packet loss
        packet_loss_status = "OK"
        # if 'PacketLoss' in analysis_result.get('health_data', {}) and analysis_result['health_data']['PacketLoss'] is not None:
        #     packet_loss = analysis_result['health_data']['PacketLoss']
        #     if not isinstance(packet_loss, str):
        #         try:
        #             packet_loss = float(packet_loss)
        #             if packet_loss < 1:
        #                 packet_loss_status = "OK"
        #             elif packet_loss < 5:
        #                 packet_loss_status = "Warning"
        #             else:
        #                 packet_loss_status = "Critical"
        #         except (ValueError, TypeError):
        #             pass
        
        output += f"- Packet Loss: {packet_loss_status}\n"
        
        # Latency
        latency_status = "High"
        # if 'Latency' in analysis_result.get('health_data', {}) and analysis_result['health_data']['Latency'] is not None:
        #     latency = analysis_result['health_data']['Latency']
        #     if not isinstance(latency, str):
        #         try:
        #             latency = float(latency)
        #             if latency < 50:
        #                 latency_status = "OK"
        #             elif latency < 200:
        #                 latency_status = "Warning"
        #             else:
        #                 latency_status = "High"
        #         except (ValueError, TypeError):
        #             pass
        
        output += f"- Latency: {latency_status}\n\n"
        #import pdb; pdb.set_trace()
        # Add issues
        if analysis_result.get('analysis', {}).get('issues_count', 0) > 0:
            output += f"### Issues Detected ({analysis_result.get('analysis', {}).get('issues_count', 0)})\n\n"
            output += "| Type | Severity | Message |\n"
            output += "|------|----------|--------|\n"
            
            for issue in analysis_result.get('analysis', {}).get('issues', []):
                issue_type = issue.get('type', 'Unknown').capitalize()
                severity = issue.get('severity', 'Unknown').upper()
                message = issue.get('message', 'No message')
                output += f"| {issue_type} | {severity} | {message} |\n"
            
            output += "\n"
        
        # Add recommendations
        if analysis_result.get('analysis', {}).get('recommendations', []):
            output += f"### Recommendations\n\n"
            for i, rec in enumerate(analysis_result.get('analysis', {}).get('recommendations', []), 1):
                output += f"{i}. {rec}\n"
            output += "\n"
        
        # Add health data details
        output += f"### Health Data Details\n\n"
        
        # CPU information
        if 'cpu' in analysis_result.get('health_data', {}) and analysis_result['health_data']['cpu']:
            cpu_data = analysis_result['health_data']['cpu']
            if isinstance(cpu_data, list) and cpu_data:
                cpu_data = cpu_data[0]
            
            if not isinstance(cpu_data, str):  # Ensure it's not an error message
                output += f"#### CPU Information\n\n"
                output += "| Metric | Value |\n"
                output += "|--------|-------|\n"
                
                # Add relevant CPU metrics
                for key, label in [
                    ('CPULoad', 'CPU Load'),
                    ('CPUCount', 'CPU Count'),
                    ('SystemUpTime', 'System Uptime'),
                    ('LastBoot', 'Last Boot Time'),
                    ('Vendor', 'Vendor'),
                    ('MachineType', 'Machine Type')
                ]:
                    if key in cpu_data:
                        output += f"| {label} | {cpu_data[key]} |\n"
                
                output += "\n"
        
        # Memory information
        if 'memory' in analysis_result.get('health_data', {}) and analysis_result['health_data']['memory']:
            memory_data = analysis_result['health_data']['memory']
            if isinstance(memory_data, list) and memory_data:
                memory_data = memory_data[0]
            
            if not isinstance(memory_data, str):  # Ensure it's not an error message
                output += f"#### Memory Information\n\n"
                output += "| Metric | Value |\n"
                output += "|--------|-------|\n"
                
                # Add relevant memory metrics
                for key, label in [
                    ('PercentMemoryUsed', 'Memory Usage'),
                    ('MemoryUsed', 'Memory Used'),
                    ('MemoryAvailable', 'Memory Available'),
                    ('TotalMemory', 'Total Memory'),
                ]:
                    if key in memory_data:
                        output += f"| {label} | {memory_data[key]} |\n"
                
                output += "\n"
        
        # Interface information
        if 'interface' in analysis_result.get('health_data', {}) and analysis_result['health_data']['interface']:
            interface_data = analysis_result['health_data']['interface']
            if isinstance(interface_data, list) and interface_data:
                # Show summary for multiple interfaces
                output += f"#### Interface Information\n\n"
                output += "| Interface | Admin Status | Oper Status | Speed | Utilization |\n"
                output += "|-----------|-------------|-------------|-------|------------|\n"
                
                for interface in interface_data:
                    if not isinstance(interface, str):  # Ensure it's not an error message
                        interface_name = interface.get('InterfaceName', 'Unknown')
                        admin_status = interface.get('AdminStatus', 'Unknown')
                        oper_status = interface.get('OperStatus', 'Unknown')
                        speed = interface.get('InterfaceSpeed', 'Unknown')
                        utilization = interface.get('PercentUtil', 'Unknown')
                        
                        output += f"| {interface_name} | {admin_status} | {oper_status} | {speed} | {utilization} |\n"
            elif not isinstance(interface_data, str):  # Single interface that's not an error message
                output += f"#### Interface Information\n\n"
                output += "| Metric | Value |\n"
                output += "|--------|-------|\n"
                
                # Add relevant interface metrics
                for key, label in [
                    ('InterfaceName', 'Interface Name'),
                    ('AdminStatus', 'Admin Status'),
                    ('OperStatus', 'Operational Status'),
                    ('InterfaceSpeed', 'Speed'),
                    ('PercentUtil', 'Utilization'),
                    ('InAveragebps', 'Inbound Traffic'),
                    ('OutAveragebps', 'Outbound Traffic')
                ]:
                    if key in interface_data:
                        output += f"| {label} | {interface_data[key]} |\n"
            
            output += "\n"
        
        return output
    
    def _extract_node_info(self, node_health):
        """Extract basic node information from health data"""
        node_info = {
            'node_name': None,
            'node_id': None,
            'ip_address': None,
            'status': None
        }
        
        # Try to extract from CPU data
        if 'cpu' in node_health and node_health['cpu']:
            cpu_data = node_health['cpu']
            if isinstance(cpu_data, list) and cpu_data:
                cpu_data = cpu_data[0]
            
            if not isinstance(cpu_data, str):  # Ensure it's not an error message
                node_info['node_id'] = cpu_data.get('NodeID')
                
                # Extract node name (remove ID suffix if present)
                node_name = cpu_data.get('NodeName')
                if node_name and '(ID:' in node_name:
                    node_name = node_name.split('(ID:')[0].strip()
                node_info['node_name'] = node_name
                
                node_info['ip_address'] = cpu_data.get('IPAddress')
                node_info['status'] = cpu_data.get('Status')
        
        return node_info
    
    def _analyze_cpu_data(self, cpu_data):
        """Analyze CPU data against thresholds"""
        issues = []
        recommendations = []
        
        if isinstance(cpu_data, str):  # Error message
            return issues, recommendations
        
        # Ensure cpu_data is a list
        if not isinstance(cpu_data, list):
            cpu_data = [cpu_data]
        
        for data in cpu_data:
            # Check CPU load
            if 'CPULoad' in data:
                cpu_load = data['CPULoad']
                # Handle percentage format if needed
                if isinstance(cpu_load, str) and '%' in cpu_load:
                    cpu_load = float(cpu_load.replace('%', ''))
                elif isinstance(cpu_load, (int, float)):
                    cpu_load = float(cpu_load)
                else:
                    continue  # Skip invalid format
                
                if cpu_load >= self.thresholds['cpu']['critical']:
                    issues.append({
                        'type': 'cpu',
                        'severity': 'critical',
                        'message': f"CPU usage is critically high: {cpu_load}%"
                    })
                    recommendations.append(
                        f"Identify and terminate non-essential processes consuming high CPU. Check for runaway processes or services."
                    )
                elif cpu_load >= self.thresholds['cpu']['warning']:
                    issues.append({
                        'type': 'cpu',
                        'severity': 'warning',
                        'message': f"CPU usage is high: {cpu_load}%"
                    })
                    recommendations.append(
                        f"Monitor system performance and check for resource-intensive applications."
                    )
            
            # Check node status
            if 'Status' in data:
                status = data['Status']
                # Handle status as a string like "Down" or "Warning"
                if isinstance(status, str):
                    if status.lower() == "down":
                        issues.append({
                            'type': 'status',
                            'severity': 'critical',
                            'message': f"Node status is DOWN: {data.get('StatusDescription', 'No details available')}"
                        })
                        recommendations.append(
                            f"Verify physical connectivity, power status, and device configuration. May require on-site support."
                        )
                    elif status.lower() == "warning":
                        issues.append({
                            'type': 'status',
                            'severity': 'warning',
                            'message': f"Node status is WARNING: {data.get('StatusDescription', 'No details available')}"
                        })
                        recommendations.append(
                            f"Check device logs and recent configuration changes. Review the status description for specific issues."
                        )
                # Handle status as numeric code (1=Up, 2=Down, 3=Warning)
                elif isinstance(status, (int, float)):
                    if status == 2:
                        issues.append({
                            'type': 'status',
                            'severity': 'critical',
                            'message': f"Node status is DOWN: {data.get('StatusDescription', 'No details available')}"
                        })
                        recommendations.append(
                            f"Verify physical connectivity, power status, and device configuration. May require on-site support."
                        )
                    elif status == 3:
                        issues.append({
                            'type': 'status',
                            'severity': 'warning',
                            'message': f"Node status is WARNING: {data.get('StatusDescription', 'No details available')}"
                        })
                        recommendations.append(
                            f"Check device logs and recent configuration changes. Review the status description for specific issues."
                        )
            
            # Check system uptime
            if 'SystemUpTime' in data:
                uptime_str = data['SystemUpTime']
                # Parse uptime string like "8 days, 0 hours, 18 minutes"
                try:
                    uptime_days = 0
                    if "days" in uptime_str:
                        days_part = uptime_str.split("days")[0]
                        uptime_days = int(days_part.strip().split(" ")[0])
                    elif "day" in uptime_str:
                        days_part = uptime_str.split("day")[0]
                        uptime_days = int(days_part.strip().split(" ")[0])
                    
                    if uptime_days >= self.thresholds['uptime']['warning']:
                        issues.append({
                            'type': 'uptime',
                            'severity': 'warning',
                            'message': f"System has been running for {uptime_days} days without a reboot"
                        })
                        recommendations.append(
                            f"Consider scheduling a maintenance window for a controlled reboot to apply pending updates and clear memory leaks."
                        )
                except (ValueError, IndexError):
                    pass  # Skip if parsing fails
        
        return issues, recommendations
    
    def _analyze_memory_data(self, memory_data):
        """Analyze memory data against thresholds"""
        issues = []
        recommendations = []
        
        if isinstance(memory_data, str):  # Error message
            return issues, recommendations
        
        # Ensure memory_data is a list
        if not isinstance(memory_data, list):
            memory_data = [memory_data]
        
        for data in memory_data:
            # Check memory usage
            if 'PercentMemoryUsed' in data:
                #import pdb; pdb.set_trace()
                memory_used = data['PercentMemoryUsed']
                # Handle percentage format if needed
                if isinstance(memory_used, str) and '%' in memory_used:
                    memory_used = float(memory_used.replace('%', ''))
                elif isinstance(memory_used, (int, float)):
                    memory_used = float(memory_used)
                else:
                    continue  # Skip invalid format
                
                if memory_used >= self.thresholds['memory']['critical']:
                    issues.append({
                        'type': 'memory',
                        'severity': 'critical',
                        'message': f"Memory usage is critically high: {memory_used}%"
                    })
                    available_mem = data.get('MemoryAvailable', 'Unknown')
                    recommendations.append(
                        f"Identify and restart applications with memory leaks. Stop non-critical services to free up memory. Available memory: {available_mem}"
                    )
                elif memory_used >= self.thresholds['memory']['warning']:
                    issues.append({
                        'type': 'memory',
                        'severity': 'warning',
                        'message': f"Memory usage is high: {memory_used}%"
                    })
                    available_mem = data.get('MemoryAvailable', 'Unknown')
                    recommendations.append(
                        f"Monitor for memory leaks in applications and check for recent changes. Available memory: {available_mem}"
                    )
        
        return issues, recommendations
    
    def _analyze_interface_data(self, interface_data):
        """Analyze interface data against thresholds"""
        issues = []
        recommendations = []
        
        if isinstance(interface_data, str):  # Error message
            return issues, recommendations
        
        # Ensure interface_data is a list
        if not isinstance(interface_data, list):
            interface_data = [interface_data]
        
        for data in interface_data:
            interface_name = data.get('InterfaceName', 'Unknown Interface')
            node_name = data.get('NodeName', 'Unknown Node')
            ip_address = data.get('IPAddress', 'Unknown IP')
            
            # Check operational status
            if 'OperStatus' in data and data['OperStatus'] == 'Down':
                admin_status = data.get('AdminStatus', 'Unknown')
                issues.append({
                    'type': 'interface',
                    'severity': 'critical',
                    'message': f"Interface {interface_name} is DOWN (Admin Status: {admin_status})"
                })
            
            # Check utilization if available
            if 'PercentUtil' in data:
                try:
                    utilization = float(data['PercentUtil'])
                    if utilization >= self.thresholds['interface']['critical']:
                        issues.append({
                            'type': 'interface',
                            'severity': 'critical',
                            'message': f"Interface {interface_name} utilization is critically high: {utilization}%"
                        })
                        recommendations.append(
                            f"Interface utilization is Critical for name {interface_name} from {node_name} with IP {ip_address}."
                        )
                    elif utilization >= self.thresholds['interface']['warning']:
                        issues.append({
                            'type': 'interface',
                            'severity': 'warning',
                            'message': f"Interface {interface_name} utilization is high: {utilization}%"
                        })
                        recommendations.append(
                            f"Monitor interface {interface_name} on {node_name} (IP: {ip_address}) for potential congestion."
                        )
                except (ValueError, TypeError):
                    pass
        
        return issues, recommendations
    
    def _analyze_response_time(self, avg_response_time, min_response_time=None, max_response_time=None):
        """Analyze response time against thresholds"""
        issues = []
        recommendations = []
        
        try:
            avg_response_time = float(avg_response_time)
            
            variation_text = ""
            if min_response_time is not None and max_response_time is not None:
                min_response_time = float(min_response_time)
                max_response_time = float(max_response_time)
                variation_text = f" with variation from {min_response_time} ms to {max_response_time} ms"
            
            if avg_response_time >= self.thresholds['response_time']['critical']:
                issues.append({
                    'type': 'response_time',
                    'severity': 'critical',
                    'message': f"Response time is critically high: {avg_response_time} ms{variation_text}"
                })
                
                if min_response_time is not None and max_response_time is not None:
                    variability = max_response_time - min_response_time
                    if variability > (avg_response_time * 2):  # High variability
                        recommendations.append(
                            f"Check for intermittent network congestion or processing issues. Response time has high variability ({min_response_time} ms to {max_response_time} ms)."
                        )
                    else:
                        recommendations.append(
                            f"Check for bandwidth saturation, high CPU/memory utilization, or routing issues. Response time is consistently high at {avg_response_time} ms."
                        )
                else:
                    recommendations.append(
                        f"Verify network path, device load, and application performance. Response time is high at {avg_response_time} ms."
                    )
                
            elif avg_response_time >= self.thresholds['response_time']['warning']:
                issues.append({
                    'type': 'response_time',
                    'severity': 'warning',
                    'message': f"Response time is high: {avg_response_time} ms{variation_text}"
                })
                recommendations.append(
                    f"Monitor for network congestion and device performance. Response time is {avg_response_time} ms{variation_text}."
                )
                
        except (ValueError, TypeError):
            logger.warning(f"Could not convert response time values to float: {avg_response_time}, {min_response_time}, {max_response_time}")
        
        return issues, recommendations
    
    def _determine_severity(self, issues):
        """Determine overall severity based on issues"""
        if not issues:
            return "healthy"
        
        # Check if any critical issues exist
        if any(issue['severity'] == 'critical' for issue in issues):
            return "critical"
        
        # Otherwise, it's a warning level
        return "warning"
    
    def _generate_summary(self, issues, node_name, severity):
        """Generate a summary of the issues"""
        if severity == "healthy":
            return f"Node {node_name} is healthy. No issues detected."
        
        # Count issues by type and severity
        critical_count = sum(1 for issue in issues if issue['severity'] == 'critical')
        warning_count = sum(1 for issue in issues if issue['severity'] == 'warning')
        
        issue_types = {}
        for issue in issues:
            issue_type = issue['type']
            if issue_type not in issue_types:
                issue_types[issue_type] = 0
            issue_types[issue_type] += 1
        
        # Generate summary text
        if severity == "critical":
            summary = f"Node {node_name} has {critical_count} critical and {warning_count} warning issues. "
        else:
            summary = f"Node {node_name} has {warning_count} warning issues. "
        
        # Add issue types
        type_summary = []
        for issue_type, count in issue_types.items():
            type_summary.append(f"{count} {issue_type}")
        
        summary += "Issues include: " + ", ".join(type_summary) + ". "
        
        # Add action recommendation
        if severity == "critical":
            summary += "Immediate attention required."
        else:
            summary += "Action recommended."
            
        return summary


# Helper function to parse an alert string
def parse_alert_string(alert_string):
    """
    Parse alert string and extract relevant information
    
    Example: "Node name: SERV1 Node IP: 172.21.17.105 Node ID: 17 Alert: SERV1 has exceptionally high response time. 
              Average Response Time is 27 ms and is varying from 1 ms to 130 ms."
    
    Returns:
        dict: Extracted information
    """
    import re
    
    info = {}
    
    # Extract node name
    node_name_match = re.search(r'Node name:\s*(\S+)', alert_string)
    if node_name_match:
        info['node_name'] = node_name_match.group(1)
    
    # Extract node IP
    node_ip_match = re.search(r'Node IP:\s*(\S+)', alert_string)
    if node_ip_match:
        info['node_ip'] = node_ip_match.group(1)
    
    # Extract node ID
    node_id_match = re.search(r'Node ID:\s*(\d+)', alert_string)
    if node_id_match:
        info['node_id'] = int(node_id_match.group(1))
    
    # Extract alert message
    alert_match = re.search(r'Alert:\s*(.*?)(?:$|Average)', alert_string, re.DOTALL)
    if alert_match:
        info['alert_message'] = alert_match.group(1).strip()
    
    # Extract response time values
    avg_rt_match = re.search(r'Average Response Time is\s*(\d+)\s*ms', alert_string)
    if avg_rt_match:
        info['average_response_time'] = int(avg_rt_match.group(1))
    
    # Extract min/max response time
    variation_match = re.search(r'varying from\s*(\d+)\s*ms to\s*(\d+)\s*ms', alert_string)
    if variation_match:
        info['min_response_time'] = int(variation_match.group(1))
        info['max_response_time'] = int(variation_match.group(2))
    
    return info