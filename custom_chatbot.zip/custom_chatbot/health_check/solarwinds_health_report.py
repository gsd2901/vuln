# Example script that imports the SolarWindsHealthCheck class
from solarwinds_health_check import SolarWindsHealthCheck
import json

def main():
    # Create health check object with custom credentials if needed
    health_check = SolarWindsHealthCheck(
        host="172.21.17.46", 
        port=17774,
        username="admin", 
        password="Solarwinds@123"
    )
    
    # Connect to the SolarWinds server
    if not health_check.connect():
        print("Failed to connect to SolarWinds server")
        return
    
    # Get list of nodes
    nodes = health_check.get_available_nodes()

    # Find a specific node - example of parsing the output
    node_id = 20

    # Get CPU, memory and interface information
    node_health = health_check.get_node_health(node_id=node_id)
    
    # Output as JSON
    print(json.dumps(node_health, indent=2, default=str))
    
    # Or you could just get specific information
    #interfaces = health_check.get_interface_utilization(node_id=node_id)
    #print(json.dumps(interfaces, indent=2, default=str))
    
if __name__ == "__main__":
    main()