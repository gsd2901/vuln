# SolarWinds Health Check Script

A Python tool for monitoring node health, CPU/memory utilization, and interface status in SolarWinds environments.

## Overview

This script provides a simple command-line interface to check the health of network devices monitored by SolarWinds. It can be used either as a standalone command-line tool or imported as a class into other Python applications.

## Installation

1. Clone the repository:
```bash
git clone https://github.com/yourusername/solarwinds-health-check.git
cd solarwinds-health-check
```

2. Install dependencies:
```bash
pip install -r requirements.txt
```

Requirements include:
- orionsdk
- python-dotenv
- tabulate
- requests

## Basic Usage

```bash
python solarwinds_health_check.py --node "Router1" --check all
```

## Command-line Arguments

| Argument | Description | Default |
|----------|-------------|---------|
| `--host` | SolarWinds host IP address | 172.21.17.46 |
| `--port` | SolarWinds port | 17774 |
| `--username` | SolarWinds username | admin |
| `--password` | SolarWinds password | Solarwinds@123 |
| `--node` | Node name to check | *Required* |
| `--node-id` | Node ID to check (more specific than node name) | None |
| `--interface` | Specific interface name (optional) | None |
| `--check` | Type of check to perform | all |
| `--format` | Output format (table or json) | table |
| `--explore-table` | Table name to explore schema | None |

## Supported Commands

### List All Nodes
```bash
python solarwinds_health_check.py --check list-nodes
```

### Check CPU Utilization
```bash
# By node name
python solarwinds_health_check.py --node "R1.cisco.com" --check cpu

# By specific node ID (recommended for duplicate names)
python solarwinds_health_check.py --node-id 16 --check cpu
```

### Check Memory Utilization
```bash
python solarwinds_health_check.py --node "R1.cisco.com" --check memory
```

### Check Interface Information
```bash
# List all interfaces for a node
python solarwinds_health_check.py --node-id 20 --check interface

# Check specific interface
python solarwinds_health_check.py --node-id 16 --check interface --interface "GigabitEthernet0/0"
```

### Check All Information
```bash
python solarwinds_health_check.py --node "R1.cisco.com" --check all
```

### JSON Output
Add the `--format json` parameter to get JSON output instead of tables:
```bash
python solarwinds_health_check.py --node "R1.cisco.com" --check all --format json
```

### Schema Exploration
For troubleshooting and exploring SolarWinds database structure:
```bash
# List available tables
python solarwinds_health_check.py --check explore

# Explore specific table schema
python solarwinds_health_check.py --check explore --explore-table "Orion.NPM.Interfaces"
```

## Using as a Python Library

The script can be imported and used in other Python code:

```python
from solarwinds_health_check import SolarWindsHealthCheck

# Initialize the health check
health_check = SolarWindsHealthCheck(
    host="172.21.17.46", 
    port=17774,
    username="admin", 
    password="Solarwinds@123"
)

# Connect to SolarWinds
health_check.connect()

# Get node health data
node_health = health_check.get_node_health(node_id=16)
```

## Example Output

### CPU Utilization (Table Format)
```
=== CPU Utilization ===
+--------+--------------+---------------+--------+--------------------+---------+-----------------------------+----------------------+----------+--------+------------------+---------------------+
| NodeID | NodeName     | IPAddress     | Status | StatusDescription  | CPULoad | LastBoot                    | SystemUpTime         | CPUCount | Vendor | MachineType      | CurrentTime         |
+========+==============+===============+========+====================+=========+=============================+======================+==========+========+==================+=====================+
| 16     | R1.cisco.com | 172.21.17.101 | Up     | Node status is Up. | 32      | 2025-04-29T13:19:00.0000000 | 6 days, 1 hours, 10m | 1        | Cisco  | Cisco Router     | 2025-05-05 14:31:50 |
+--------+--------------+---------------+--------+--------------------+---------+-----------------------------+----------------------+----------+--------+------------------+---------------------+
```

## Troubleshooting

- **Connection Issues**: Verify that the SolarWinds server is reachable and that the credentials are correct.
- **No Data Available**: Check if the node exists and monitoring is configured correctly.
- **Duplicate Node Names**: Use the `--node-id` parameter to specifically target a node by its ID.
