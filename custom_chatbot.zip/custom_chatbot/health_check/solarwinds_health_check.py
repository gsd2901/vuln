#!/usr/bin/env python3

import orionsdk
from dotenv import load_dotenv
import os
import argparse
import json
from datetime import datetime, timedelta
from tabulate import tabulate
import urllib3
import requests

# Disable SSL warnings (only use in trusted environments)
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# Load environment variables from .env file
load_dotenv()

class SolarWindsHealthCheck:
    """
    A class to check and monitor SolarWinds nodes and interfaces.
    Can be used as a standalone script or imported into other Python code.
    """
    
    # Default connection settings
    DEFAULT_HOST = "172.21.17.46"
    DEFAULT_PORT = 17774
    DEFAULT_USERNAME = "admin"
    DEFAULT_PASSWORD = "Solarwinds@123"

    def __init__(self, host=None, port=None, username=None, password=None):
        """Initialize with optional connection parameters"""
        self.host = host or self.DEFAULT_HOST
        self.port = port or self.DEFAULT_PORT
        self.username = username or self.DEFAULT_USERNAME
        self.password = password or self.DEFAULT_PASSWORD
        self.swis = None
        
    def connect(self):
        """Establish connection to SolarWinds"""
        try:
            # Create connection with verify=False to ignore SSL certificate validation
            self.swis = orionsdk.SwisClient(self.host, self.username, self.password, 
                                           port=self.port, verify=False)
            # Test connection with a simple query
            test_query = "SELECT TOP 1 NodeID FROM Orion.Nodes"
            self.swis.query(test_query)
            return True
        except Exception as e:
            print(f"Connection failed: {e}")
            return False
    
    @staticmethod
    def format_uptime(seconds):
        """Convert seconds to a human-readable uptime format"""
        if seconds is None:
            return "Unknown"
        
        # Convert to timedelta for easy formatting
        td = timedelta(seconds=seconds)
        days = td.days
        hours, remainder = divmod(td.seconds, 3600)
        minutes, _ = divmod(remainder, 60)
        
        if days > 0:
            return f"{days} days, {hours} hours, {minutes} minutes"
        elif hours > 0:
            return f"{hours} hours, {minutes} minutes"
        else:
            return f"{minutes} minutes"

    @staticmethod
    def format_bytes(bytes_value):
        """Convert bytes to human-readable format (KB, MB, GB, TB)"""
        if bytes_value is None:
            return "Unknown"
        
        # Handle scientific notation by converting to float
        try:
            bytes_value = float(bytes_value)
        except (TypeError, ValueError):
            return "Unknown"
        
        # Define byte units and thresholds
        units = ['B', 'KB', 'MB', 'GB', 'TB']
        
        # Determine the appropriate unit
        unit_index = 0
        while bytes_value >= 1024 and unit_index < len(units) - 1:
            bytes_value /= 1024
            unit_index += 1
        
        # Format with appropriate precision
        if unit_index == 0:
            return f"{int(bytes_value)} {units[unit_index]}"
        else:
            return f"{bytes_value:.2f} {units[unit_index]}"

    def get_available_tables(self):
        """Get list of available tables in SolarWinds"""
        if not self.swis:
            if not self.connect():
                return "Error: Not connected to SolarWinds"
                
        try:
            query = "SELECT Definition FROM Metadata.Entity"
            result = self.swis.query(query)
            tables = [row["Definition"] for row in result["results"]]
            return tables
        except Exception as e:
            return f"Error getting tables: {e}"

    def get_table_schema(self, table_name):
        """Get schema for a specific table"""
        if not self.swis:
            if not self.connect():
                return "Error: Not connected to SolarWinds"
                
        try:
            query = f"SELECT EntityName, Name, Type FROM Metadata.Property WHERE EntityName = '{table_name}'"
            result = self.swis.query(query)
            return result["results"]
        except Exception as e:
            return f"Error getting schema: {e}"
            
    def get_available_nodes(self):
        """Retrieve a list of all monitored nodes"""
        if not self.swis:
            if not self.connect():
                return "Error: Not connected to SolarWinds"
                
        try:
            query = """
            SELECT 
                NodeID,
                Caption AS NodeName, 
                IPAddress,
                Status,
                StatusDescription,
                Vendor,
                MachineType,
                CPULoad,
                PercentMemoryUsed
            FROM 
                Orion.Nodes
            ORDER BY 
                Caption, NodeID
            """
            
            result = self.swis.query(query)
            
            # Format status for readability
            for row in result["results"]:
                if "Status" in row:
                    status = row["Status"]
                    if status == 1:
                        row["Status"] = "Up"
                    elif status == 2:
                        row["Status"] = "Down"
                    elif status == 3:
                        row["Status"] = "Warning"
                    elif status == 0:
                        row["Status"] = "Unknown"
                    else:
                        row["Status"] = f"Other ({status})"
                        
                # Make NodeID more visible by adding parentheses
                row["NodeName"] = f"{row['NodeName']} (ID: {row['NodeID']})"
                
                # Format CPU and memory
                if "CPULoad" in row and row["CPULoad"] is not None:
                    row["CPULoad"] = f"{row['CPULoad']}%"
                    
                if "PercentMemoryUsed" in row and row["PercentMemoryUsed"] is not None:
                    row["PercentMemoryUsed"] = f"{row['PercentMemoryUsed']}%"
            
            return result["results"]
        except Exception as e:
            return f"Error retrieving nodes: {e}"
            
    def get_cpu_utilization(self, node_name=None, node_id=None):
        """Retrieve CPU utilization for a specific node"""
        if not self.swis:
            if not self.connect():
                return "Error: Not connected to SolarWinds"
                
        try:
            # Build WHERE clause based on available parameters
            if node_id is not None:
                where_clause = f"NodeID = {node_id}"
            elif node_name is not None:
                where_clause = f"Caption = '{node_name}'"
            else:
                return "Error: Either node_name or node_id must be provided"
            
            query = f"""
            SELECT 
                NodeID,
                Caption AS NodeName, 
                IPAddress,
                Status,
                StatusDescription,
                CPULoad,
                LastBoot,
                SystemUpTime,
                CPUCount,
                Vendor,
                MachineType
            FROM 
                Orion.Nodes
            WHERE 
                {where_clause}
            """
            
            result = self.swis.query(query)
            if not result["results"]:
                return f"Node not found"
            
            # Format the uptime to be more readable
            for row in result["results"]:
                if "SystemUpTime" in row and row["SystemUpTime"]:
                    row["SystemUpTime"] = self.format_uptime(row["SystemUpTime"])
                    
                # Add current datetime for reference
                row["CurrentTime"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            
            return result["results"]
            
        except Exception as e:
            return f"Error retrieving CPU utilization: {e}"

    def get_memory_utilization(self, node_name=None, node_id=None):
        """Retrieve memory utilization for a specific node"""
        if not self.swis:
            if not self.connect():
                return "Error: Not connected to SolarWinds"
                
        try:
            # Build WHERE clause based on available parameters
            if node_id is not None:
                where_clause = f"NodeID = {node_id}"
            elif node_name is not None:
                where_clause = f"Caption = '{node_name}'"
            else:
                return "Error: Either node_name or node_id must be provided"
            
            query = f"""
            SELECT 
                NodeID, 
                Caption AS NodeName,
                MemoryUsed,
                MemoryAvailable,
                TotalMemory,
                PercentMemoryUsed,
                PercentMemoryAvailable
            FROM 
                Orion.Nodes
            WHERE 
                {where_clause}
            """
            
            result = self.swis.query(query)
            if not result["results"]:
                return f"Node not found"
            
            # Format memory values to be more readable
            for row in result["results"]:
                for key in ["MemoryUsed", "MemoryAvailable", "TotalMemory"]:
                    if key in row and row[key]:
                        row[key] = self.format_bytes(row[key])
                        
                # Add percentage utilization in a more readable format
                if "PercentMemoryUsed" in row and row["PercentMemoryUsed"]:
                    row["PercentMemoryUsed"] = f"{row['PercentMemoryUsed']}%"
                    
                if "PercentMemoryAvailable" in row and row["PercentMemoryAvailable"]:
                    row["PercentMemoryAvailable"] = f"{row['PercentMemoryAvailable']}%"
            
            return result["results"]
            
        except Exception as e:
            return f"Error retrieving memory utilization: {e}"

    def get_interface_utilization(self, node_name=None, interface_name=None, node_id=None, verbose=False):
        """Retrieve interface utilization for a specific node or interface"""
        import pdb; pdb.set_trace()
        if not self.swis:
            if not self.connect():
                return "Error: Not connected to SolarWinds"
                
        try:
            # Get the node ID
            if node_id is None and node_name is not None:
                node_query = f"""
                SELECT NodeID
                FROM Orion.Nodes
                WHERE Caption = '{node_name}'
                """
                
                node_result = self.swis.query(node_query)
                if not node_result["results"]:
                    return f"Node '{node_name}' not found"
                    
                node_id = node_result["results"][0]["NodeID"]
            elif node_id is None:
                return "Error: Either node_name or node_id must be provided"

            # First check if NPM interfaces are available for this node
            interfaces_query = f"""
            SELECT COUNT(*) AS InterfaceCount 
            FROM Orion.NPM.Interfaces 
            WHERE NodeID = {node_id}
            """
            
            interfaces_count = self.swis.query(interfaces_query)
            if interfaces_count["results"] and interfaces_count["results"][0]["InterfaceCount"] == 0:
                return f"Node (ID: {node_id}) has no NPM interfaces configured"

            # If interface name is specified but doesn't contain the middle dot,
            # try to find the full interface name
            interface_condition = ""
            if interface_name:
                # First try to get interfaces with exact match
                exact_match_query = f"""
                SELECT InterfaceID, Caption
                FROM Orion.NPM.Interfaces
                WHERE NodeID = {node_id} AND Caption = '{interface_name}'
                """
                
                exact_matches = self.swis.query(exact_match_query)
                if exact_matches["results"]:
                    interface_id = exact_matches["results"][0]["InterfaceID"]
                    interface_name = exact_matches["results"][0]["Caption"]
                    interface_condition = f" AND i.InterfaceID = {interface_id}"
                    if verbose:
                        print(f"Using interface: {interface_name}")
                else:
                    # Try partial match
                    like_query = f"""
                    SELECT InterfaceID, Caption
                    FROM Orion.NPM.Interfaces
                    WHERE NodeID = {node_id} AND Caption LIKE '%{interface_name}%'
                    """
                    
                    like_matches = self.swis.query(like_query)
                    if like_matches["results"]:
                        interface_id = like_matches["results"][0]["InterfaceID"]
                        interface_name = like_matches["results"][0]["Caption"]
                        interface_condition = f" AND i.InterfaceID = {interface_id}"
                        if verbose:
                            print(f"Using interface: {interface_name}")
                    else:
                        # List available interfaces
                        all_int_query = f"""
                        SELECT TOP 20 Caption 
                        FROM Orion.NPM.Interfaces 
                        WHERE NodeID = {node_id}
                        """
                        all_ints = self.swis.query(all_int_query)
                        if all_ints["results"]:
                            interfaces = [row["Caption"] for row in all_ints["results"]]
                            return f"Interface '{interface_name}' not found. Available interfaces include: {', '.join(interfaces)}"
                        else:
                            return f"No interfaces found for node ID {node_id}"
            
            # Try to get interface traffic data from the NPM.InterfaceTraffic table
            try:
                # First check if InterfaceTraffic table exists and has data for this node
                traffic_check = f"""
                SELECT COUNT(*) AS TrafficCount
                FROM Orion.NPM.InterfaceTraffic t
                JOIN Orion.NPM.Interfaces i ON t.InterfaceID = i.InterfaceID
                WHERE i.NodeID = {node_id}
                """
                
                try:
                    traffic_count = self.swis.query(traffic_check)
                    has_traffic_data = traffic_count["results"] and traffic_count["results"][0]["TrafficCount"] > 0
                except Exception:
                    has_traffic_data = False
                    
                # Only try to get traffic details if data exists
                if has_traffic_data:
                    traffic_query = f"""
                    SELECT
                        n.Caption AS NodeName,
                        i.Caption AS InterfaceName,
                        i.AdminStatus,
                        i.OperStatus,
                        i.InterfaceSpeed,
                        t.InPercentUtil,
                        t.OutPercentUtil,
                        t.PercentUtil,
                        t.InAveragebps,
                        t.OutAveragebps,
                        t.InTotalBytes,
                        t.OutTotalBytes,
                        t.TotalBytes,
                        t.TotalPackets,
                        t.DateTime
                    FROM 
                        Orion.Nodes n
                        JOIN Orion.NPM.Interfaces i ON n.NodeID = i.NodeID
                        JOIN Orion.NPM.InterfaceTraffic t ON i.InterfaceID = t.InterfaceID
                    WHERE 
                        i.NodeID = {node_id}{interface_condition}
                    ORDER BY 
                        t.DateTime DESC
                    """
                    
                    traffic_result = self.swis.query(traffic_query)
                    if traffic_result["results"]:
                        # Format the results
                        for row in traffic_result["results"]:
                            # Format interface speed
                            if "InterfaceSpeed" in row and row["InterfaceSpeed"]:
                                try:
                                    speed_bps = float(row["InterfaceSpeed"])
                                    if speed_bps >= 1_000_000_000:
                                        row["InterfaceSpeed"] = f"{speed_bps/1_000_000_000:.2f} Gbps"
                                    elif speed_bps >= 1_000_000:
                                        row["InterfaceSpeed"] = f"{speed_bps/1_000_000:.2f} Mbps"
                                    elif speed_bps >= 1_000:
                                        row["InterfaceSpeed"] = f"{speed_bps/1_000:.2f} Kbps"
                                    else:
                                        row["InterfaceSpeed"] = f"{speed_bps} bps"
                                except (ValueError, TypeError):
                                    # Keep original value if conversion fails
                                    pass
                            
                            # Format percentage utilization
                            for key in ["InPercentUtil", "OutPercentUtil", "PercentUtil"]:
                                if key in row and row[key] is not None:
                                    try:
                                        row[key] = f"{float(row[key]):.2f}%"
                                    except (ValueError, TypeError):
                                        # Keep original value if conversion fails
                                        pass
                                    
                            # Format traffic rates
                            for key in ["InAveragebps", "OutAveragebps"]:
                                if key in row and row[key] is not None:
                                    try:
                                        bps = float(row[key])
                                        if bps >= 1_000_000_000:
                                            row[key] = f"{bps/1_000_000_000:.2f} Gbps"
                                        elif bps >= 1_000_000:
                                            row[key] = f"{bps/1_000_000:.2f} Mbps"
                                        elif bps >= 1_000:
                                            row[key] = f"{bps/1_000:.2f} Kbps"
                                        else:
                                            row[key] = f"{bps:.2f} bps"
                                    except (ValueError, TypeError):
                                        # Keep original value if conversion fails
                                        pass
                            
                            # Format total bytes
                            for key in ["InTotalBytes", "OutTotalBytes", "TotalBytes"]:
                                if key in row and row[key] is not None:
                                    try:
                                        row[key] = self.format_bytes(float(row[key]))
                                    except (ValueError, TypeError):
                                        # Keep original value if conversion fails
                                        pass
                                        
                            # Make status more readable
                            if "AdminStatus" in row:
                                admin_status = row["AdminStatus"]
                                row["AdminStatus"] = "Up" if admin_status == 1 else "Down" if admin_status == 2 else f"Unknown ({admin_status})"
                                
                            if "OperStatus" in row:
                                oper_status = row["OperStatus"]
                                row["OperStatus"] = "Up" if oper_status == 1 else "Down" if oper_status == 2 else f"Unknown ({oper_status})"
                        
                        return traffic_result["results"]
            except Exception as e:
                if verbose:
                    print(f"Traffic data query error: {e}")
            
            # Fallback - basic interface info
            interfaces_query = f"""
            SELECT 
                n.Caption AS NodeName,
                i.Caption AS InterfaceName,
                i.AdminStatus,
                i.OperStatus,
                i.InterfaceSpeed,
                i.InterfaceType,
                i.InterfaceSubType,
                i.MAC
            FROM 
                Orion.Nodes n
                JOIN Orion.NPM.Interfaces i ON n.NodeID = i.NodeID
            WHERE 
                i.NodeID = {node_id}{interface_condition}
            ORDER BY
                i.Caption
            """
                
            result = self.swis.query(interfaces_query)
            
            if not result["results"]:
                # If we requested a specific interface and got no results, try to list all interfaces
                all_interfaces_query = f"""
                SELECT Caption
                FROM Orion.NPM.Interfaces
                WHERE NodeID = {node_id}
                ORDER BY Caption
                """
                
                all_interfaces = self.swis.query(all_interfaces_query)
                if all_interfaces["results"]:
                    interfaces = [row["Caption"] for row in all_interfaces["results"]]
                    return f"Interface information not found. Available interfaces for node ID {node_id}: {', '.join(interfaces[:10])}..."
                else:
                    return f"No interfaces configured for node ID {node_id}"
            
            # Format interface speeds
            for row in result["results"]:
                if "InterfaceSpeed" in row and row["InterfaceSpeed"]:
                    try:
                        speed_bps = float(row["InterfaceSpeed"])
                        if speed_bps >= 1_000_000_000:
                            row["InterfaceSpeed"] = f"{speed_bps/1_000_000_000:.2f} Gbps"
                        elif speed_bps >= 1_000_000:
                            row["InterfaceSpeed"] = f"{speed_bps/1_000_000:.2f} Mbps"
                        elif speed_bps >= 1_000:
                            row["InterfaceSpeed"] = f"{speed_bps/1_000:.2f} Kbps"
                        else:
                            row["InterfaceSpeed"] = f"{speed_bps} bps"
                    except (ValueError, TypeError):
                        # Keep original value if conversion fails
                        pass
                
                # Make status more readable
                if "AdminStatus" in row:
                    admin_status = row["AdminStatus"]
                    row["AdminStatus"] = "Up" if admin_status == 1 else "Down" if admin_status == 2 else f"Unknown ({admin_status})"
                    
                if "OperStatus" in row:
                    oper_status = row["OperStatus"]
                    row["OperStatus"] = "Up" if oper_status == 1 else "Down" if oper_status == 2 else f"Unknown ({oper_status})"
            
            return result["results"]
            
        except Exception as e:
            return f"Error retrieving interface utilization: {e}"
    
    def get_node_health(self, node_name=None, node_id=None):
        """Get comprehensive health information for a node"""
        if not self.swis:
            if not self.connect():
                return {"error": "Not connected to SolarWinds"}
        
        results = {}
        
        # Get CPU utilization
        cpu_data = self.get_cpu_utilization(node_name, node_id)
        results["cpu"] = cpu_data
        
        # Get memory utilization
        memory_data = self.get_memory_utilization(node_name, node_id)
        results["memory"] = memory_data
        
        # Get interface details but not traffic data (for performance)
        interface_data = self.get_interface_utilization(node_name, node_id=node_id)
        results["interface"] = interface_data
        
        return results

# Command line interface - only used when script is run directly
def main():
    parser = argparse.ArgumentParser(description="SolarWinds Health Check Script")
    parser.add_argument("--host", default=SolarWindsHealthCheck.DEFAULT_HOST, help="SolarWinds host IP address")
    parser.add_argument("--port", default=SolarWindsHealthCheck.DEFAULT_PORT, help="SolarWinds port")
    parser.add_argument("--username", default=SolarWindsHealthCheck.DEFAULT_USERNAME, help="SolarWinds username")
    parser.add_argument("--password", default=SolarWindsHealthCheck.DEFAULT_PASSWORD, help="SolarWinds password")
    parser.add_argument("--node", help="Node name to check")
    parser.add_argument("--node-id", type=int, help="Node ID to check (more specific than node name)")
    parser.add_argument("--interface", help="Specific interface name (optional)")
    parser.add_argument("--check", choices=["cpu", "memory", "interface", "all", "explore", "list-nodes"], default="all", 
                        help="Type of check to perform")
    parser.add_argument("--format", choices=["table", "json"], default="table", 
                        help="Output format")
    parser.add_argument("--explore-table", help="Table name to explore schema")
    
    args = parser.parse_args()
    
    # Create health check object
    health_check = SolarWindsHealthCheck(args.host, args.port, args.username, args.password)
    
    # Connect to SolarWinds
    if not health_check.connect():
        return
    
    # List all available nodes
    if args.check == "list-nodes":
        nodes = health_check.get_available_nodes()
        print("\n=== Available Nodes ===")
        print(format_output(nodes, args.format))
        return
        
    # Special explore mode to help debug schema issues
    if args.check == "explore":
        if args.explore_table:
            print(f"\n=== Schema for {args.explore_table} ===")
            schema = health_check.get_table_schema(args.explore_table)
            print(format_output(schema, args.format))
        else:
            print("\n=== Available Tables ===")
            tables = health_check.get_available_tables()
            print(f"Found {len(tables)} tables")
            print("\nSample tables:")
            for table in sorted(tables)[:20]:
                print(f"- {table}")
        return
        
    # Make --node or --node-id required for operations other than list-nodes and explore
    if not args.node and not args.node_id:
        print("Error: Either --node or --node-id argument is required for this operation")
        return
        
    results = {}
    
    # Run requested checks
    if args.check == "cpu" or args.check == "all":
        cpu_data = health_check.get_cpu_utilization(args.node, node_id=args.node_id)
        print("\n=== CPU Utilization ===")
        print(format_output(cpu_data, args.format))
        results["cpu"] = cpu_data
        
    if args.check == "memory" or args.check == "all":
        memory_data = health_check.get_memory_utilization(args.node, node_id=args.node_id)
        print("\n=== Memory Utilization ===")
        print(format_output(memory_data, args.format))
        results["memory"] = memory_data
        
    if args.check == "interface" or args.check == "all":
        interface_data = health_check.get_interface_utilization(args.node, interface_name=args.interface, 
                                                            node_id=args.node_id, verbose=True)
        print("\n=== Interface Utilization ===")
        print(format_output(interface_data, args.format))
        results["interface"] = interface_data
    
    # Return full results in JSON if requested
    if args.format == "json" and args.check == "all":
        print("\n=== Complete Results ===")
        print(json.dumps(results, indent=2, default=str))

# Helper function for command-line output formatting
def format_output(data, output_format="table"):
    """
    Format the output data based on the specified format
    """
    if isinstance(data, str):
        return data
        
    if output_format == "json":
        return json.dumps(data, indent=2, default=str)
    elif output_format == "table":
        if not data:
            return "No data available"
        if isinstance(data, list) and len(data) > 0:
            headers = data[0].keys()
            rows = [list(item.values()) for item in data]
            return tabulate(rows, headers=headers, tablefmt="grid")
        return "No data available"
    else:
        return str(data)

if __name__ == "__main__":
    main()