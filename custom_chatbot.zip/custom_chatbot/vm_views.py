"""
Vulnerability Management Views.

Django views for displaying vulnerability management data in 
discovery.html-style interfaces.
"""

import asyncio
import json
import logging
import time
from typing import Any, Dict, List, Optional

from django.contrib.auth.mixins import LoginRequiredMixin
from django.http import JsonResponse, HttpResponse
from django.shortcuts import render
from django.template.loader import get_template
from django.template import TemplateDoesNotExist
from django.views import View
from django.views.generic import TemplateView

from .services.vulnerability_service import vm_service, VMServiceException
from .services.cache_service import VMCacheService

# Import direct service (no HTTP calls)
try:
    from .services.vulnerability_service_direct import direct_vm_service
    DIRECT_VM_SERVICE_AVAILABLE = direct_vm_service is not None and direct_vm_service.initialized
except ImportError:
    direct_vm_service = None
    DIRECT_VM_SERVICE_AVAILABLE = False

logger = logging.getLogger(__name__)


def _normalize_vm_device(item: Any, index: int) -> Dict[str, Any]:
    """Build template-safe dicts from impacted_devices API (often only hostname + advisoryIds)."""
    if not isinstance(item, dict):
        return {
            "id": str(index),
            "hostname": str(item),
            "device_name": str(item),
            "model": "",
            "ip_address": "N/A",
            "ip": "N/A",
            "advisory_id": "N/A",
            "advisory_title": "",
            "severity": "Medium",
        }

    hostname = (
        item.get("hostname")
        or item.get("deviceName")
        or item.get("name")
        or "Unknown Device"
    )
    advisory_ids = item.get("advisoryIds") or item.get("advisory_ids") or []
    if isinstance(advisory_ids, list):
        advisory_display = ", ".join(str(x) for x in advisory_ids) if advisory_ids else "N/A"
    else:
        advisory_display = str(advisory_ids) if advisory_ids else "N/A"

    ip_val = (
        item.get("managementIpAddress")
        or item.get("ipAddress")
        or item.get("ip_address")
        or item.get("ip")
        or "N/A"
    )
    severity = item.get("sir") or item.get("severity") or "Medium"
    device_id = (
        item.get("id")
        or item.get("instanceUuid")
        or item.get("deviceId")
        or item.get("instanceId")
        or hostname
    )

    return {
        "id": str(device_id),
        "hostname": hostname,
        "device_name": hostname,
        "model": item.get("model") or item.get("platformId") or item.get("softwareType") or "",
        "ip_address": ip_val,
        "ip": ip_val,
        "advisory_id": advisory_display,
        "advisory_title": item.get("advisory_title") or item.get("title") or "",
        "severity": severity,
    }


def _first_cve(raw: Dict[str, Any]) -> str:
    cve = raw.get("cve_id") or raw.get("cveId")
    if cve:
        return str(cve)
    cves = raw.get("cves") or raw.get("cve_ids") or []
    if isinstance(cves, list) and cves:
        return str(cves[0])
    return ""


def _normalize_vm_advisory(item: Any, index: int) -> Dict[str, Any]:
    """Build template-safe dicts from impacted_advisories API (often only advisoryId + deviceCount)."""
    if not isinstance(item, dict):
        return {
            "id": f"ADV-{index}",
            "advisory_id": f"ADV-{index}",
            "title": str(item),
            "severity": "High",
            "published_date": "N/A",
            "description": "",
            "cve_id": "",
            "impact_devices": 0,
            "affected_products": "",
            "workaround": None,
            "url": "",
        }

    aid = item.get("advisoryId") or item.get("advisory_id") or item.get("id") or f"ADV-{index}"
    aid = str(aid)
    device_count = item.get("deviceCount") or item.get("device_count") or item.get("devices_affected") or 0
    title = item.get("title") or item.get("summary") or aid
    severity = item.get("sir") or item.get("severity") or "High"
    published = (
        item.get("published_date")
        or item.get("date")
        or item.get("publicationDate")
        or item.get("firstPublished")
        or "N/A"
    )
    workaround = item.get("workaround")
    if workaround is None and item.get("workaround_available") is not None:
        workaround = bool(item.get("workaround_available"))

    return {
        "id": aid,
        "advisory_id": aid,
        "title": title,
        "severity": severity,
        "published_date": str(published) if published is not None else "N/A",
        "description": item.get("description") or item.get("summary") or "",
        "cve_id": _first_cve(item),
        "impact_devices": device_count,
        "affected_products": item.get("affected_products") or item.get("affectedProducts") or "",
        "workaround": workaround,
        "url": item.get("url") or item.get("publicationUrl") or "",
    }


class VMBaseView(LoginRequiredMixin, TemplateView):
    """Base view for vulnerability management pages with fallback handling."""
    
    def get_template_names(self):
        """Return template names with fallback options."""
        template_names = []
        if hasattr(self, 'template_name') and self.template_name:
            template_names.append(self.template_name)
        
        # Add fallback template
        template_names.append('custom_chatbot/vm/fallback.html')
        return template_names
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context.update({
            'page_title': 'Vulnerability Management',
            'breadcrumbs': [
                {'name': 'Home', 'url': '/'},
                {'name': 'Plugins', 'url': '/plugins/'},
                {'name': 'Custom Chatbot', 'url': '/plugins/custom-chatbot/'},
                {'name': 'Vulnerability Management', 'url': '/plugins/custom-chatbot/vm/'},
            ]
        })
        return context
    
    def dispatch(self, request, *args, **kwargs):
        """Enhanced dispatch with error handling."""
        try:
            return super().dispatch(request, *args, **kwargs)
        except Exception as e:
            logger.error(f"Error in VM view {self.__class__.__name__}: {e}")
            # Return a simple error response
            context = {
                'page_title': 'Error',
                'error': f'An error occurred: {str(e)}',
                'breadcrumbs': []
            }
            return render(request, 'custom_chatbot/vm/fallback.html', context)


class VMDashboardView(VMBaseView):
    """Main vulnerability management dashboard."""
    template_name = "custom_chatbot/vm/dashboard.html"
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        
        try:
            # Use direct service if available, otherwise fallback to HTTP service
            if DIRECT_VM_SERVICE_AVAILABLE:
                logger.info("VMDashboardView: Using direct vulnerability service")
                # Get DNAC instances directly
                dnac_instances = direct_vm_service.get_dnac_instances_safe()
                context['dnac_instances'] = dnac_instances
                
                # Check if using fallback data (direct service handles fallbacks internally)
                is_fallback = dnac_instances and any(d.get('host', '').startswith('dnac-') for d in dnac_instances)
                if is_fallback:
                    context['service_warning'] = "Vulnerability management service is currently unavailable - showing example data"
                    
                # Skip intro message for direct service (not implemented)
                context['intro_card'] = None
                
            else:
                logger.info("VMDashboardView: Using HTTP vulnerability service")
                # Get intro message/card data with fallback
                try:
                    intro_data = asyncio.run(vm_service.get_intro_message())
                    context['intro_card'] = intro_data
                except VMServiceException:
                    context['intro_card'] = None
                    context['service_warning'] = "Introduction data unavailable"
                
                # Get DNAC instances with fallback
                dnac_instances = asyncio.run(vm_service.get_dnac_instances_safe())
                context['dnac_instances'] = dnac_instances
                
                # Check if using fallback data
                if dnac_instances and dnac_instances[0].get('status') == 'unavailable':
                    context['service_warning'] = "Vulnerability management service is currently unavailable"
            
        except Exception as e:
            logger.error(f"Error fetching dashboard data: {e}")
            context['error'] = f"Unable to load dashboard data: {str(e)}"
            context['dnac_instances'] = []
            
        context['page_title'] = 'Vulnerability Management Dashboard'
        return context


class VMDevicesView(VMBaseView):
    """Display impacted devices in discovery.html-style interface.

    Device rows load asynchronously via /vm/api/impacted_devices/ so the page shell
    renders immediately (skeleton UI) while data is fetched.
    """
    template_name = "custom_chatbot/vm/devices.html"
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        dnac_id = self.request.GET.get('dnac_id')
        context["dnac_id"] = dnac_id or ""
        context["devices"] = []
        context['page_title'] = 'Impacted Devices'
        context['breadcrumbs'].append({'name': 'Impacted Devices', 'url': ''})
        return context


class VMAdvisoriesView(VMBaseView):
    """Display advisory information with action cards.

    Advisory cards load asynchronously via /vm/api/impacted_advisories/ so the page
    shell renders immediately (skeleton UI) while data is fetched.
    """
    template_name = "custom_chatbot/vm/advisories.html"
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        dnac_id = self.request.GET.get('dnac_id')
        context["dnac_id"] = dnac_id or ""
        context["advisories"] = []
        context['page_title'] = 'Security Advisories'
        context['breadcrumbs'].append({'name': 'Security Advisories', 'url': ''})
        return context


class VMDiscoveryView(VMBaseView):
    """Discovery scan interface and results."""
    template_name = "custom_chatbot/vm/discovery.html"
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        dnac_id = self.request.GET.get('dnac_id')
        
        try:
            # Get latest discovery report with fallback handling
            discovery_data = asyncio.run(vm_service.get_latest_discovery_report_safe())
            context['discovery_data'] = discovery_data
            context['dnac_id'] = dnac_id
            
            # Check if using fallback data
            if discovery_data.get('status') == 'service_unavailable':
                context['service_warning'] = "Vulnerability management service is currently unavailable"
            
        except Exception as e:
            logger.error(f"Error fetching discovery data: {e}")
            context['error'] = f"Unable to load discovery data: {str(e)}"
            context['discovery_data'] = {}
            
        context['page_title'] = 'Vulnerability Discovery'
        context['breadcrumbs'].append({'name': 'Discovery', 'url': ''})
        return context


class VMReportView(VMBaseView):
    """Display detailed vulnerability report."""
    template_name = "custom_chatbot/vm/report.html"
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        scan_id = kwargs.get('scan_id', 'latest')
        
        try:
            # Get discovery results - fetches from database, no scan required
            if hasattr(vm_service, 'get_discovery_result_safe'):
                # Direct service
                report_data = vm_service.get_discovery_result_safe()
            else:
                # API service
                report_data = asyncio.run(vm_service.get_discovery_result())
            context['report_data'] = report_data
            context['scan_id'] = scan_id
            
        except Exception as e:
            logger.error(f"Error fetching report data: {e}")
            context['error'] = str(e)
            context['report_data'] = {}
            
        context['page_title'] = f'Vulnerability Report - {scan_id}'
        context['breadcrumbs'].extend([
            {'name': 'Discovery', 'url': '/plugins/custom-chatbot/vm/discovery/'},
            {'name': f'Report {scan_id}', 'url': ''}
        ])
        return context


class VMTriggerDiscoveryView(LoginRequiredMixin, View):
    """AJAX endpoint to trigger vulnerability discovery scan."""
    
    def post(self, request, *args, **kwargs):
        try:
            dnac_id = request.POST.get('dnac_id')
            
            # Trigger discovery scan
            result = asyncio.run(vm_service.trigger_advisory_discovery(dnac_id))
            
            return JsonResponse({
                'success': True,
                'message': 'Discovery scan initiated successfully',
                'data': result
            })
            
        except Exception as e:
            logger.error(f"Error triggering discovery: {e}")
            return JsonResponse({
                'success': False,
                'message': f'Failed to trigger discovery scan: {str(e)}'
            }, status=500)


class VMCreateTicketView(LoginRequiredMixin, View):
    """AJAX endpoint to create ServiceNow tickets."""
    
    def post(self, request, *args, **kwargs):
        try:
            # Parse request data
            if request.content_type == 'application/json':
                data = json.loads(request.body)
            else:
                data = request.POST.dict()
            
            # Create ServiceNow ticket
            result = asyncio.run(vm_service.create_snow_ticket(data))
            
            return JsonResponse({
                'success': True,
                'message': 'ServiceNow ticket created successfully',
                'data': result
            })
            
        except Exception as e:
            logger.error(f"Error creating ticket: {e}")
            return JsonResponse({
                'success': False,
                'message': f'Failed to create ticket: {str(e)}'
            }, status=500)


class VMAPIProxyView(LoginRequiredMixin, View):
    """Proxy view to call VM API endpoints from frontend JavaScript."""
    
    def get(self, request, endpoint, *args, **kwargs):
        """Handle GET requests to VM API endpoints with caching and pagination support."""
        try:
            start_time = time.time()
            dnac_id = request.GET.get('dnac_id')
            
            # Parse pagination parameters
            page = int(request.GET.get('page', 1))
            page_size = int(request.GET.get('page_size', 50))
            force_refresh = request.GET.get('refresh') == 'true'
            
            # Validate pagination parameters
            page = max(1, page)
            page_size = max(1, min(page_size, 200))  # Limit max page size
            
            logger.info(f"VM API request: {endpoint}, dnac_id={dnac_id}, page={page}, page_size={page_size}, refresh={force_refresh}")
            
            # Check cache first for cacheable endpoints
            cached_response = None
            if not force_refresh and endpoint in ['impacted_devices', 'impacted_advisories', 'advisory_details']:
                cached_response = VMCacheService.get_cached_data(
                    endpoint=endpoint,
                    dnac_id=dnac_id,
                    page=page,
                    page_size=page_size
                )
                
                if cached_response:
                    logger.info(f"Cache hit for {endpoint}, returning cached data")
                    return JsonResponse({
                        'success': True,
                        'data': cached_response['data'],
                        'pagination': cached_response['pagination'],
                        'cache_info': cached_response['cache_info'],
                        'message': 'Data retrieved from cache'
                    })
            
            # Cache miss or force refresh - fetch fresh data
            logger.info(f"Fetching fresh data for {endpoint}")
            
            if endpoint == 'dnac_instances':
                result = asyncio.run(vm_service.get_dnac_instances_safe())
            elif endpoint == 'impacted_devices':
                if DIRECT_VM_SERVICE_AVAILABLE:
                    result = direct_vm_service.get_impacted_devices_safe(dnac_id)
                else:
                    result = asyncio.run(vm_service.get_impacted_devices_safe(dnac_id))
            elif endpoint == 'impacted_advisories':
                if DIRECT_VM_SERVICE_AVAILABLE:
                    result = direct_vm_service.get_impacted_advisories_safe(dnac_id)
                else:
                    result = asyncio.run(vm_service.get_impacted_advisories_safe(dnac_id))
            elif endpoint == 'advisory_details':
                # Use enhanced advisories endpoint for detailed information
                if DIRECT_VM_SERVICE_AVAILABLE:
                    result = direct_vm_service.enhanced_advisories_endpoint(dnac_id)
                else:
                    # For HTTP service, fall back to basic advisories
                    result = asyncio.run(vm_service.get_impacted_advisories_safe(dnac_id))
            elif endpoint == 'discovery_report':
                result = asyncio.run(vm_service.get_latest_discovery_report_safe())
            else:
                return JsonResponse({
                    'success': False,
                    'message': f'Unknown endpoint: {endpoint}',
                    'error_type': 'invalid_endpoint'
                }, status=404)
            
            # Check if result indicates service unavailability
            is_fallback = False
            warning_message = None
            
            if endpoint == 'dnac_instances' and result and result[0].get('status') == 'unavailable':
                is_fallback = True
                warning_message = "Vulnerability management service is currently unavailable"
            elif endpoint == 'impacted_devices' and result and len(result) == 1 and result[0].get('status') == 'Service unavailable':
                is_fallback = True
                warning_message = "Vulnerability management service is currently unavailable"
                result = []
            elif endpoint == 'impacted_advisories' and result and len(result) == 1 and result[0].get('id') == 'SERVICE_UNAVAILABLE':
                is_fallback = True
                warning_message = "Vulnerability management service is currently unavailable"
                result = []
            elif endpoint == 'discovery_report' and result and result.get('status') == 'service_unavailable':
                is_fallback = True
                warning_message = "Vulnerability management service is currently unavailable"
            
            # Process and normalize data
            payload = result
            if endpoint == 'impacted_devices' and isinstance(result, list):
                if not is_fallback:
                    payload = [_normalize_vm_device(d, i) for i, d in enumerate(result)]
            elif endpoint in ['impacted_advisories', 'advisory_details'] and isinstance(result, list):
                if not is_fallback:
                    payload = [_normalize_vm_advisory(a, i) for i, a in enumerate(result)]

            # Cache the full dataset if it's cacheable and not fallback
            if not is_fallback and isinstance(payload, list) and endpoint in ['impacted_devices', 'impacted_advisories', 'advisory_details']:
                try:
                    VMCacheService.set_cached_data(
                        endpoint=endpoint,
                        data=payload,
                        dnac_id=dnac_id
                    )
                    logger.info(f"Cached {len(payload)} items for {endpoint}")
                except Exception as e:
                    logger.error(f"Failed to cache data for {endpoint}: {e}")
            
            # Apply pagination for list endpoints
            pagination_info = None
            if isinstance(payload, list) and endpoint in ['impacted_devices', 'impacted_advisories', 'advisory_details']:
                total_count = len(payload)
                start_idx = (page - 1) * page_size
                end_idx = start_idx + page_size
                payload = payload[start_idx:end_idx]
                
                pagination_info = {
                    'page': page,
                    'page_size': page_size,
                    'total_count': total_count,
                    'total_pages': (total_count + page_size - 1) // page_size,
                    'has_next': end_idx < total_count,
                    'has_previous': page > 1
                }
            
            # Calculate elapsed time
            elapsed_time = (time.time() - start_time) * 1000
            
            response_data = {
                'success': True,
                'data': payload,
                'performance': {
                    'elapsed_ms': round(elapsed_time, 2),
                    'cache_hit': False,
                    'items_count': len(payload) if isinstance(payload, list) else 1
                }
            }
            
            if pagination_info:
                response_data['pagination'] = pagination_info
            
            if is_fallback:
                response_data['warning'] = warning_message
                response_data['using_fallback'] = True
            
            logger.info(f"VM API response: {endpoint} completed in {elapsed_time:.1f}ms, returned {len(payload) if isinstance(payload, list) else 1} items")
            
            return JsonResponse(response_data)
            
        except VMServiceException as e:
            logger.error(f"VM Service error for endpoint {endpoint}: {e}")
            return JsonResponse({
                'success': False,
                'message': str(e),
                'error_type': e.error_type,
                'endpoint': e.endpoint
            }, status=500)
            
        except Exception as e:
            logger.error(f"Unexpected error calling VM API endpoint {endpoint}: {e}")
            return JsonResponse({
                'success': False,
                'message': f'An unexpected error occurred: {str(e)}',
                'error_type': 'unexpected_error',
                'endpoint': endpoint
            }, status=500)


class VMCacheManagementView(LoginRequiredMixin, View):
    """API endpoint for managing VM cache."""
    
    def post(self, request, action, *args, **kwargs):
        """Handle cache management actions."""
        try:
            if action == 'invalidate':
                endpoint = request.POST.get('endpoint')
                dnac_id = request.POST.get('dnac_id')
                
                if endpoint:
                    # Invalidate specific endpoint
                    success = VMCacheService.invalidate_cache(endpoint, dnac_id)
                    message = f"Cache invalidated for {endpoint}" if success else f"No cache found for {endpoint}"
                else:
                    # Invalidate all VM cache
                    count = VMCacheService.invalidate_all_vm_cache()
                    message = f"Invalidated {count} cache entries"
                
                return JsonResponse({
                    'success': True,
                    'message': message
                })
            
            elif action == 'stats':
                stats = VMCacheService.get_cache_stats()
                return JsonResponse({
                    'success': True,
                    'data': stats
                })
            
            else:
                return JsonResponse({
                    'success': False,
                    'message': f'Unknown action: {action}'
                }, status=400)
                
        except Exception as e:
            logger.error(f"Cache management error: {e}")
            return JsonResponse({
                'success': False,
                'message': 'Cache management operation failed',
                'error': str(e)
            }, status=500)