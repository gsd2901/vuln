#!/usr/bin/env python
"""
Test script to verify direct vulnerability management integration.
This bypasses FastAPI and calls functions directly from test_endpoints.py approach.
"""

import os
import sys
import django

# Setup Django
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'nautobot.settings')
django.setup()

from services.vulnerability_service_direct import direct_vm_service

def test_direct_vm_integration():
    """Test the direct vulnerability management integration."""
    
    print("=" * 60)
    print("TESTING DIRECT VULNERABILITY MANAGEMENT INTEGRATION")
    print("=" * 60)
    
    if not direct_vm_service:
        print("❌ Direct VM service not available")
        return False
        
    if not direct_vm_service.initialized:
        print("❌ Direct VM service not initialized")
        return False
    
    print("✅ Direct VM service initialized successfully")
    
    # Test 1: Get DNAC instances
    print("\n1. Testing DNAC Instances:")
    try:
        instances = direct_vm_service.get_dnac_instances_safe()
        print(f"   Found {len(instances)} DNAC instances:")
        for inst in instances:
            print(f"     - {inst['id']}: {inst['host']}:{inst['port']}")
        print("   ✅ DNAC instances test passed")
    except Exception as e:
        print(f"   ❌ DNAC instances test failed: {e}")
        return False
    
    # Test 2: Get impacted devices  
    print("\n2. Testing Impacted Devices:")
    try:
        devices = direct_vm_service.get_impacted_devices_safe()
        print(f"   Found {len(devices)} impacted devices:")
        for i, device in enumerate(devices[:3]):  # Show first 3
            print(f"     - {device.get('hostname', 'N/A')}: {device.get('ip_address', 'N/A')}")
        print("   ✅ Impacted devices test passed")
    except Exception as e:
        print(f"   ❌ Impacted devices test failed: {e}")
        return False
    
    # Test 3: Get impacted advisories
    print("\n3. Testing Impacted Advisories:")
    try:
        advisories = direct_vm_service.get_impacted_advisories_safe()
        print(f"   Found {len(advisories)} advisories:")
        for i, advisory in enumerate(advisories[:3]):  # Show first 3
            print(f"     - {advisory.get('advisory_id', 'N/A')}: {advisory.get('severity', 'N/A')}")
        print("   ✅ Impacted advisories test passed")
    except Exception as e:
        print(f"   ❌ Impacted advisories test failed: {e}")
        return False
    
    # Test 4: Get discovery report
    print("\n4. Testing Discovery Report:")
    try:
        report = direct_vm_service.get_latest_report_safe()
        if isinstance(report, dict):
            print(f"   Report status: {report.get('message', 'N/A')}")
            print(f"   Scan ID: {report.get('scan_id', 'N/A')}")
        print("   ✅ Discovery report test passed")
    except Exception as e:
        print(f"   ❌ Discovery report test failed: {e}")
        return False
    
    print("\n" + "=" * 60)
    print("✅ ALL TESTS PASSED - Direct VM integration is working!")
    print("=" * 60)
    
    return True

def test_chatbot_integration():
    """Test chatbot node integration."""
    print("\n" + "=" * 60)
    print("TESTING CHATBOT NODE INTEGRATION")
    print("=" * 60)
    
    # Import chatbot view
    try:
        from views import ChatbotView
        
        # Create a mock state
        test_state = {
            "session_id": "test_session_001",
            "query": "dnac instances", 
            "history": []
        }
        
        # Create chatbot instance and test VM node
        chatbot = ChatbotView()
        result = chatbot._vulnerability_management_node(test_state)
        
        print("Chatbot VM node result:")
        print(f"  Type: {result.get('result', {}).get('type', 'N/A')}")
        print(f"  Action: {result.get('result', {}).get('action', 'N/A')}")
        print(f"  Data count: {len(result.get('result', {}).get('data', []))}")
        
        if result.get('result', {}).get('type') == 'dnac_instances':
            print("✅ Chatbot VM node integration working!")
        else:
            print("❌ Chatbot VM node integration failed")
            return False
            
    except Exception as e:
        print(f"❌ Chatbot integration test failed: {e}")
        return False
    
    return True

if __name__ == "__main__":
    success = test_direct_vm_integration()
    
    if success:
        success = test_chatbot_integration()
    
    if success:
        print("\n🎉 ALL INTEGRATION TESTS PASSED!")
        print("The vulnerability management integration is working without FastAPI!")
    else:
        print("\n💥 SOME TESTS FAILED!")
        sys.exit(1)