import requests
from requests.auth import HTTPBasicAuth
import json
import logging
from typing import TypedDict
api_token = "rduBaT50kHZjMrho9FBRkJe5bbNGHrjzIwarnQOVJiLdWyK27UtGKbitaPnjHTBQ"
headers = {"Authorization": f"Token {api_token}", "Accept": "application/json"}
headers= {
        'Authorization': f'Bearer ${api_token}',
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        }
# # resp = requests.get("http://172.21.17.46:17774/SolarWinds/InformationService/v3/Json/Query?query=SELECT+NodeID,Caption+FROM+Orion.Nodes",headers=headers, verify=False)
# import requests

# from requests.auth import HTTPBasicAuth
# resp = requests.post('http://172.21.17.46:17774/SolarWinds/InformationService/v3/Json/Query?query=SELECT+NodeID,Caption+FROM+Orion.Nodes', auth=HTTPBasicAuth('admin', 'Solarwinds@123'),verify=False)

# # import requests
# # from requests.auth import HTTPBasicAuth
# # import urllib3

# # # Disable warnings
# # urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# resp = requests.get(
#     'https://172.21.17.46:17774/SolarWinds/InformationService/v3/Json/Query?query=SELECT+NodeID,Caption+FROM+Orion.Nodes',
#     #  'https://172.21.17.46:17774/SolarWinds/InformationService/v3/Json/Query?query=SELECT+Uri+FROM+Orion.Pollers+ORDER+BY+PollerID+WITH+ROWS+1+TO+3+WITH+TOTALROWS',
#     auth=HTTPBasicAuth('admin', 'Solarwinds@123'),
#     # headers=headers,
#     verify=False
# )
# print(resp.status_code)
# if resp.status_code == 200:
#     print(resp.json())
# else:
#     print(f"Failed to retrieve alerts: {resp.status_code}")


# # Define the database connection string
# from langchain_community.agent_toolkits import create_sql_agent
# from sqlalchemy import create_engine, text
# from sqlalchemy.orm import sessionmaker
# from langchain.utilities import SQLDatabase
# from langchain.agents import create_sql_agent
# from langchain.chat_models import ChatOpenAI
# from custom_chatbot.nautobot_querytool import ChatOpenRouter
# import os
# # Initialize the language model
# llm = ChatOpenRouter(model_name="openai/gpt-4.1")

# from dotenv import load_dotenv
# import os

# load_dotenv()  # Load variables from .env file

# # # Create the SQL agent
# # # Define your MySQL database connection details
# # db_url = f"mysql+pymysql://{os.getenv('SOLARWINDS_DB_USER')}:{os.getenv('SOLARWINDS_DB_PASSWORD')}@{os.getenv('SOLARWINDS_DB_HOST')}:{os.getenv('SOLARWINDS_DB_PORT')}/{os.getenv('SOLARWINDS_DB_NAME')}"
# # # Set up MySQL connection

# # print(f"Connecting to database at {db_url}")
# # db = SQLDatabase.from_uri(db_url)
# # # Create an SQLAlchemy engine
# # engine = create_engine(db_url)

# # # Create a session
# # Session = sessionmaker(bind=engine)
# # session = Session()

# # # Create the SQL agent
# # # agent = create_sql_agent(engine)
# # agent = create_sql_agent(llm=llm, db=db, verbose=True)

# # def generate_query(user_input):
# #     # Use LangChain to parse the user input and generate an SQL query
# #     query = agent.invoke(user_input)

# #     return query

# # # Example user input
# # user_input = "Retrieve all nodes and their statuses from the SolarWinds database"
# # # user_input = "SELECT * FROM Orion.Nodes WHERE Status = 'Up'"

# # # Generate the SQL query based on user input
# # query = generate_query(user_input)
# # print(f"Generated SQL Query: {query}")
# # # Execute the query using SQLAlchemy
# # results = session.execute(text(query)).fetchall()

# # # Print the results
# # for row in results:
# #     print(row)

# # # Close the session
# # session.close()
# # from langchain import create_sql_agent

import requests
import urllib3
from requests.auth import HTTPBasicAuth
from langchain_core.prompts import ChatPromptTemplate
 
# from langchain.chat_models import ChatOpenAI
from langchain.tools import Tool
from langchain.agents import AgentExecutor, create_tool_calling_agent
from langgraph.graph import StateGraph, END
from custom_chatbot.nautobot_querytool import ChatOpenRouter
from dotenv import load_dotenv
import os
# Load environment variables from .env file
load_dotenv()

llm = ChatOpenRouter(model_name="openai/gpt-4.1")

# https://172.21.17.46:17774/SolarWinds/InformationService/v3/Json/Query?query=SELECT+NodeID,Caption+FROM+Orion.Nodes',
#     #  'https://172.21.17.46:17774/SolarWinds/InformationService/v3/Json/Query?query=SELECT+Uri+FROM+Orion.Pollers+ORDER+BY+PollerID+WITH+ROWS+1+TO+3+WITH+TOTALROWS',
#     auth=HTTPBasicAuth('admin', 'Solarwinds@123'),
#     # headers=headers,

# === 🔐 SolarWinds API ===
SOLARWINDS_HOST = "https://172.21.17.46:17774"
USERNAME = "admin"
PASSWORD = "Solarwinds@123"
 
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
 
def run_swql_query(swql: str) -> str:
    url = f"{SOLARWINDS_HOST}/SolarWinds/InformationService/v3/Json/Query"
    params = {"query": swql}
    try:
        response = requests.get(url, params=params, auth=HTTPBasicAuth(USERNAME, PASSWORD), verify=False)
        response.raise_for_status()
        results = response.json()['results']
        if not results:
            return "No results found."
        return "\n".join(str(row) for row in results[:5])
    except Exception as e:
        return f"[Error]: {e}"
 
# === 🧠 LLM ===
# llm = ChatOpenAI(model="gpt-4", temperature=0)
 
# === 🛠️ Tools ===
 
def generate_swql(nl_query: str) -> str:
    
    prompt = f"""
    You are a SolarWinds SWQL expert.
    Generate a valid SWQL query to fulfill the user's request.
    
    User request: {nl_query}
    SWQL:
    """
    print(f"Generating SWQL for: {nl_query} and prompt: {prompt}")
    response = llm.invoke(prompt)
    return response.content.strip()
    # return "SELECT NodeID, Caption FROM Orion.Nodes"
 
tools = [
    Tool(
        name="GenerateSWQL",
        func=generate_swql,
        description="Use to convert a natural language query into a valid SWQL query."
    ),
    Tool(
        name="RunSWQLQuery",
        func=run_swql_query,
        description="Use to execute a SWQL query and return results from SolarWinds."
    )
]

prompt = ChatPromptTemplate.from_messages([
    ("system", "You are a network inventory specialist. Use tools to query Nautobot."),
    ("human", "{input}"),
    ("placeholder", "{agent_scratchpad}"),
])
 
# === 🔁 LangGraph ReAct Agent ===
agent = create_tool_calling_agent(llm, tools, prompt)
agent_executor = AgentExecutor(agent=agent, tools=tools, verbose=True)

class QueryState(TypedDict):
    query: str

 
# === 🚀 Run the agent ==
def run_agent(state: QueryState) -> str:
    try:
        # result = agent_executor.invoke({"messages":nl_query})
        result = agent_executor.invoke({"input":state["query"]})

        return result
    except Exception as e:
        return f"[Error]: {e}"
# === 🌳 State Graph ===
graph = StateGraph(QueryState)
graph.add_node("react_agent", run_agent)
graph.set_entry_point("react_agent")
graph.set_finish_point("react_agent")
 
var_graph = graph.compile()
response = var_graph.invoke({"query": "Give status of interfaces for the node with name Branch1_SDA_FUSION_P48.nplab.local "})
                            #  "what are the nodes available?"})
                            #  "what are the ip addresses for the node Branch1_SDA_FUSION_P48.nplab.local?"})
print(response)
