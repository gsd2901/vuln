import requests
from bs4 import BeautifulSoup

import requests
import urllib3
from requests.auth import HTTPBasicAuth
from langchain_core.prompts import ChatPromptTemplate
 
# from langchain.chat_models import ChatOpenAI
from langchain.tools import Tool
from langchain.agents import AgentExecutor, create_tool_calling_agent
from langgraph.graph import StateGraph, END
from custom_chatbot.nautobot_querytool import ChatOpenRouter
from dotenv import load_dotenv
import os
# Load environment variables from .env file
load_dotenv()

llm = ChatOpenRouter(model_name="openai/gpt-4.1")

SOLARWINDS_HOST = "https://172.21.17.46:17774"
USERNAME = "admin"
PASSWORD = "Solarwinds@123"
import orionsdk

swis = orionsdk.SwisClient('172.21.17.46', USERNAME, PASSWORD)

if swis is None:
    print("Failed to connect to SolarWinds API.")
else:   
    print("Connected to SolarWinds API successfully.")
    aliases = swis.invoke('Metadata.Entity', 'GetAliases', 'SELECT B.Caption FROM Orion.Nodes B')

    print(aliases)

# Fetch available fields for the Orion.Nodes entity
def fetch_entity_fields_with_metadata(entity_name):
    query = f"""
    SELECT Name, Type, IsNullable, Description 
    FROM Metadata.Property 
    WHERE EntityName = '{entity_name}'
    """
    result = swis.query(query)
    return result['results']
 
# Match user query to an entity (e.g., Orion.Nodes, Orion.Interfaces)
def detect_entity(user_query):
    # Simple matching logic for entity
    entities = ['Orion.Nodes', 'Orion.NPM.Interfaces']  # Add more entities as needed
    for entity in entities:
        if entity.split('.')[-1].lower() in user_query.lower():
            return entity
    return 'Orion.Nodes'
 
# Select relevant fields based on user query and entity
def select_fields_with_llm(user_query, entity_name, field_metadata):
    formatted_fields = format_metadata_for_prompt(field_metadata)
 
    prompt = f"""
    You are a SWQL expert. A user asks a natural language question about SolarWinds data. 
    Given the available fields in the entity '{entity_name}', return a comma-separated list of the most relevant fields (max 6) needed to answer the question.
    
    User Query: "{user_query}"
    
    Available Fields:
    {formatted_fields}
    """
    
    response = llm.invoke(prompt)
    return response.content.strip().split(", ")

# Format metadata for prompt
def format_metadata_for_prompt(field_metadata):
    formatted_fields = []
    for field in field_metadata:
        name = field['Name']
        
        is_nullable = field['IsNullable']
        
        description = field['Description']
        
        formatted_fields.append(f"{name} ( Nullable: {is_nullable}) - {description}")
    
    return "\n".join(formatted_fields)


def generate_where_clause_with_llm(user_query, entity_name, field_metadata):
    formatted_fields = format_metadata_for_prompt(field_metadata)
 
    prompt = f"""
    You are a SWQL expert. A user has asked a query about the entity '{entity_name}'.
    Based on the following field metadata, suggest a correct SWQL WHERE clause to filter the results, if needed.
    
    User Query: "{user_query}"
    
    Available Fields:
    {formatted_fields}
    
    Return ONLY the WHERE clause (e.g., WHERE Status = 1 or WHERE IPAddress LIKE '10.%').
    If no filtering is needed, return an empty string.
    """
    response = llm.invoke(prompt)
    return response.content.strip()

def run_swql_query(swql: str) -> str:
    url = f"{SOLARWINDS_HOST}/SolarWinds/InformationService/v3/Json/Query"
    params = {"query": swql}
    try:
        response = requests.get(url, params=params, auth=HTTPBasicAuth(USERNAME, PASSWORD), verify=False)
        response.raise_for_status()
        results = response.json()['results']
        if not results:
            return "No results found."
        return "\n".join(str(row) for row in results[:5])
    except Exception as e:
        return f"[Error]: {e}"
     
# Main function to generate SWQL from user input
def generate_swql(user_query):
    # Step 1: Detect the entity based on user query
    entity = detect_entity(user_query)
    if not entity:
        return "Could not detect entity."
    print(f"Detected entity: {entity}")   
    # Fetch metadata
    metadata = fetch_entity_fields_with_metadata(entity)
    
    # Select fields
    fields = select_fields_with_llm(user_query, entity, metadata)
    
    # Generate WHERE clause
    where_clause = generate_where_clause_with_llm(user_query, entity, metadata)
    
    # Build final query
    swql_query = f"SELECT {', '.join(fields)} FROM {entity} {where_clause}"
    print(swql_query)
    
    # Step 5: Run the SWQL query
    return swql_query
 
# Example usage
user_query = "Give status of interfaces for the node with name Branch1_SDA_FUSION_P48.nplab.local "
swql_query = generate_swql(user_query)

print("Generated SWQL query:", swql_query)

swql_result = run_swql_query(swql_query)
print("Results for SQL query:", swql_result)


# SELECT NodeID ,Caption,IPAddress,Status,MachineType,Vendor%2C+Location+FROM+Orion.Nodes
