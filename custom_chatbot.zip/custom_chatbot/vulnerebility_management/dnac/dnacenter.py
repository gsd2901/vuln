import logging
import requests
from config import BASE_DIR
logger = logging.getLogger(__name__)
logger.addHandler(logging.StreamHandler())
logger.setLevel(logging.INFO)

class DNAC:
    def __init__(self, host, username, password, port=443):
        """
        Initialize with Cisco DNA Center host, port, and credentials.
        """
        self.host = host
        self.username = username
        self.password = password
        self.port = port
        self.base_url = f"https://{self.host}:{self.port}/dna/intent/api/v1/"
        self.header = {'content-type': 'application/json'}

    def login(self):
        """
        Authenticate and generate a token for subsequent API calls.
        """
        url = f"https://{self.host}:{self.port}/dna/system/api/v1/auth/token"
        req = requests.post(url=url, verify=False, headers=self.header, auth=(self.username, self.password))

        if req.status_code == 200:
            token = req.json()['Token']
            self.header["x-auth-token"] = token
            logger.info(f"DNAC Login token generated")
            # print(f"Generated Token: {token}")
        else:
            logger.debug(f"Login failed: {req.status_code}, {req.text}")
            print(f"Login failed: {req.status_code}, {req.text}")
    def get(self, path, params=None):
        """
        Make a GET request to a DNA Center API.
        :param path: API endpoint (e.g., '/network-device')
        :param params: Optional query parameters for GET request
        :return: Response as JSON or error message.
        """
        url = f"{self.base_url}{path}"
        response = requests.get(url=url, headers=self.header, params=params, verify=False)
        logger.info(f"GET request - Debug DNAC url: {url}")
    
        if response.status_code == 200:
            return response.json()
        else:
            error_msg = f"GET request failed: {response.status_code}, {response.text}"
            logger.debug(error_msg)
            # ✅ Always return a dict so ['response'] never fails
            return {"response": [], "error": error_msg}
            
    # def get(self, path, params=None):
    #     """
    #     Make a GET request to a DNA Center API.
    #     :param path: API endpoint (e.g., '/network-device')
    #     :param params: Optional query parameters for GET request
    #     :return: Response as JSON or error message.
    #     """
    #     url = f"{self.base_url}{path}"
    #     response = requests.get(url=url, headers=self.header, params=params, verify=False)
    #     logger.info(f"GET request - Debug DNAC url: {url}")

    #     if response.status_code == 200:
    #         response_data = response.json()
    #         # logger.info(f"GET request - Debug DNAC response: {response_data}")
    #         return response_data
    #     else:
    #         logger.debug(f"GET request failed: {response.status_code}, {response.text}")
    #         return f"GET request failed: {response.status_code}, {response.text}"
    def put(self, path, payload):
        """
        Make a PUT request to update an existing record.
        :param path: API endpoint (e.g., '/network-device/<id>')
        :param payload: Data to update the record
        :return: Response as JSON or error message.
        """
        url = f"{self.base_url}{path}"
        response = requests.put(url=url, headers=self.header, json=payload, verify=False)
        logger.info(f"PUT request - Debug DNAC url: {url}")
    
        if response.status_code == 200:
            return response.json()
        else:
            error_msg = f"PUT request failed: {response.status_code}, {response.text}"
            logger.debug(error_msg)
            return {"response": [], "error": error_msg} 

    def post(self, path, payload):
        """
        Make a POST request to a DNA Center API.
        :param path: API endpoint (e.g., '/site')
        :param payload: Data to send in POST request
        :return: Response as JSON or error message.
        """
        url = f"{self.base_url}{path}"
        response = requests.post(url=url, headers=self.header, json=payload, verify=False)
        logger.info(f"POST request - Debug DNAC url: {url}")

        if response.status_code == 201:
            # logger.info(f"POST request - Debug DNAC response: {pprint(response.json())}")
            return response.json()
        else:
            logger.debug(f"POST request failed:{response.status_code}, {response.text}")
            return response.json()

    # def put(self, path, payload):
    #     """
    #     Make a PUT request to update an existing record.
    #     :param path: API endpoint (e.g., '/network-device/<id>')
    #     :param payload: Data to update the record
    #     :return: Response as JSON or error message.
    #     """
    #     url = f"{self.base_url}{path}"
    #     response = requests.put(url=url, headers=self.header, json=payload, verify=False)
    #     logger.info(f"PUT request - Debug DNAC url: {url}")

    #     if response.status_code == 200:
    #         # logger.info(f"PUT request - Debug DNAC response: {pprint(response.json())}")
    #         return response.json()
    #     else:
    #         logger.debug(f"PUT request failed: {response.status_code}, {response.text}")
    #         return f"PUT request failed: {response.status_code}, {response.text}"

    def delete(self, path):
        """
        Make a DELETE request to remove a resource.
        :param path: API endpoint (e.g., '/network-device/<id>')
        :return: Response message or error message.
        """
        url = f"{self.base_url}{path}"
        response = requests.delete(url=url, headers=self.header, verify=False)
        logger.info(f"DELETE request - Debug DNAC url: {url}")

        if response.status_code == 204:
            logger.info({"message": "Resource deleted successfully"})
            return {"message": "Resource deleted successfully"}
        else:
            logger.debug(f"DELETE request failed: {response.status_code}, {response.text}")
            return f"DELETE request failed: {response.status_code}, {response.text}"

    def get_device_list(self, params=None):
        """
        Returns the network device details for the given device ID
        :param id:
        :return:
        """
        return self.get(path=f"network-device", params=params)

    def get_device_count(self):
        """
        Returns the total number of network devices reported by DNAC.
        Used to detect pagination truncation in get_all_devices().
        :return: int (0 if the count could not be determined)
        """
        resp = self.get(path="network-device/count")
        try:
            return int(resp.get("response", 0))
        except (TypeError, ValueError):
            logger.warning(f"Could not parse device count response: {resp}")
            return 0

    def get_all_devices(self, page_size=500):
        """
        Returns the FULL network device list, paginating through all pages.

        DNAC's network-device endpoint caps each response at a default page
        size (commonly 500) when no offset/limit is supplied. get_device_list()
        alone only returns the first page, silently truncating results for any
        site with more devices than the page size. This method loops using
        offset/limit until a short (or empty) page is returned, then cross-checks
        the total against get_device_count() and logs a warning on mismatch.

        :param page_size: page size to request per call (default 500)
        :return: list of all device dicts across every page
        """
        all_devices = []
        offset = 1
        while True:
            params = {"offset": offset, "limit": page_size}
            resp = self.get(path="network-device", params=params)
            page = resp.get("response", []) or []
            if not page:
                break
            all_devices.extend(page)
            logger.info(f"[PAGINATION] Fetched {len(page)} devices at offset={offset} (running total={len(all_devices)})")
            if len(page) < page_size:
                break
            offset += page_size

        expected_count = self.get_device_count()
        if expected_count and len(all_devices) != expected_count:
            logger.warning(
                f"[PAGINATION] Device count mismatch: fetched {len(all_devices)} but "
                f"DNAC reports {expected_count} total devices. Results may still be incomplete."
            )
        return all_devices

    def get_device_by_id(self, id):
        """
        Returns the network device details for the given device ID
        :param id:
        :return:
        """
        return self.get(path=f"network-device/{id}")

    def get_device_data_given_uuid(self, id):
        """
        Returns the device data for the given device Uuid in the specified start and end time range.
        When there is no start and end time specified returns the latest available data for the given Id.
        :param id:
        :return:
        """
        return self.get(path=f"networkDevices/{id}")

    def get_advisories_list(self):
        """
        Retrieves list of advisories on the network
        :return:
        """
        return self.get(path=f"security-advisory/advisory")

    def get_advisories_summary(self):
        """
        Retrieves summary of advisories on the network.
        :return:
        """
        return self.get(path=f"security-advisory/advisory/aggregate")

    def get_advisories_per_device(self, deviceId):
        """
        Retrieves list of advisories for a device
        :param deviceId:
        :return:
        """
        return self.get(path=f"security-advisory/device/{deviceId}/advisory")

    def get_advisory_device_detail(self, deviceId):
        """
        Retrieves advisory device details for a device
        :param deviceId:
        :return:
        """
        return self.get(path=f"security-advisory/device/{deviceId}")

    def get_devices_per_advisory(self, advisoryId):
        """
        Retrieves list of devices for an advisory
        :param advisoryId:
        :return:
        """
        return self.get(path=f"security-advisory/advisory/{advisoryId}/device")

    def get_device_config_by_id(self, networkDeviceId):
        """
        Returns the device config by specified device ID
        :param networkDeviceId:
        :return:
        """
        return self.get(path=f"network-device/{networkDeviceId}/config")

    def get_configuration_archive_details(self, params=None):
        """
        Returns the historical device configurations (running configuration , startup configuration , vlan if applicable) by specified criteria
        :param params:
        :return:
        """
        return self.get(path="network-device-config", params=params)

