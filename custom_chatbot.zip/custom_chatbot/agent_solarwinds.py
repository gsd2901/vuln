
from langchain.prompts import ChatPromptTemplate
# from langchain.output_parsers import StrOutputParser, JsonOutputParser
from langchain.agents import AgentExecutor, create_tool_calling_agent
# from langchain.chat_models import ChatOpenAI
from langchain_core.tools import tool
from langchain.prompts import MessagesPlaceholder
 
agent_prompt = ChatPromptTemplate.from_messages([
    ("system", "You are an intelligent agent that helps users get data from SolarWinds using SWQL."
    " Use tools to generate queries and get results."),
    ("human", "{input}"),
    ("placeholder", "{agent_scratchpad}")
])
 
from custom_chatbot.nautobot_querytool import ChatOpenRouter
from dotenv import load_dotenv
import os
# Load environment variables from .env file
load_dotenv()
SOLARWINDS_HOST = "https://172.21.17.46:17774"
USERNAME = "admin"
PASSWORD = "Solarwinds@123"
import orionsdk

llm = ChatOpenRouter(model_name="openai/gpt-4.1")
swis = orionsdk.SwisClient('172.21.17.46', USERNAME, PASSWORD)

# 2. Define known entity relationships
ENTITY_RELATIONSHIPS = {
    "Interfaces": {
        "Nodes": "Interfaces.NodeID = Nodes.NodeID"
    },
    "Alerts": {
        "Nodes": "Alerts.EntityUri = Nodes.Uri"
    },
    "Events": {
        "Nodes": "Events.NodeID = Nodes.NodeID"
    },
    "Volumes": {
        "Nodes": "Volumes.NodeID = Nodes.NodeID"
    }
}
 
# 3. Fetch available fields dynamically
def fetch_available_fields(entity_name: str):
    metadata_query = f"""
    SELECT Name FROM Metadata.Property 
    WHERE EntityName = '{entity_name}'
    """
    try:
        result = swis.query(metadata_query)
        return [row["Name"] for row in result["results"]]
    except Exception as e:
        return []
 
# 4. Complex query prompt template with LLM (JOINs, ORDER BY, etc.)
complex_query_prompt = ChatPromptTemplate.from_messages([
    ("system", "You are a SWQL expert that writes advanced SWQL queries using SELECT, JOIN, WHERE, ORDER BY, and aggregations."),
    ("user", """User request: {user_request}
 
Available entities: {entity_list}
Available fields: {available_fields}
Known relationships (as joinable ON clauses):
{relationships}
 
Generate a valid SWQL query with proper:
- SELECT fields (relevant ones)
- JOINs if needed (using relationship mappings)
- WHERE clauses (if user specifies filtering)
- ORDER BY and LIMIT (if user asks for sorted/top results)
 
Respond with the FULL SWQL QUERY ONLY, nothing else.
agent_scratchpad: {agent_scratchpad}
""")
])
 
# 5. Tool to generate complex SWQL query
@tool
def generate_advanced_swql(user_request: str) -> str:
    """
    Uses LLM to generate a complex SWQL query with JOINs, ORDER BY, and filtering.
    """
    try:
        # Get list of entities
        entity_list = list(ENTITY_RELATIONSHIPS.keys())
        # Fetch all fields available for each entity
        all_fields = []
        for entity in entity_list:
            fields = fetch_available_fields(entity)
            all_fields.extend([f"{entity}.{field}" for field in fields])
        # Prepare relationships for JOINs
        relationship_str = "\n".join(
            [f"{src}.{dst}: {join}" for src, rels in ENTITY_RELATIONSHIPS.items() for dst, join in rels.items()]
        )
 
        query_prompt = complex_query_prompt.format(
            user_request=user_request,
            entity_list=", ".join(entity_list),
            available_fields=", ".join(all_fields),
            relationships=relationship_str
        )
        print("Generating SWQL for:::::::::::::", user_request, "and prompt:", query_prompt)
        # Use LLM to generate the SWQL query based on the prompt
        response = llm.invoke(query_prompt)
 
        return response.strip()
 
    except Exception as e:
        return f"Failed to generate query: {e}"
 
# 6. Tool to execute SWQL query
@tool
def run_swql_query(swql_query: str) -> str:
    """Executes a SWQL query and returns the results."""
    try:
        result = swis.query(swql_query)
        rows = result["results"]
        if not rows:
            return "No results found."
        return str(rows[:5])  # Return first 5 for brevity
    except Exception as e:
        return f"Error executing SWQL: {e}"
 
# 7. Set up the tools for the agent
tools = [generate_advanced_swql, run_swql_query]
 
# 8. Define the agent's behavior
agent = create_tool_calling_agent(llm, tools, agent_prompt)
agent_executor = AgentExecutor(agent=agent, tools=tools, verbose=True)
 
# 9. Example user query invocation
query = "Give Alerts for the node with name Branch1_SDA_FUSION_P48.nplab.local"

# "Give Interface utilisation for the node with name Branch1_SDA_FUSION_P48.nplab.local"
# "Give Interfaces with their Bandwidth Usage"
# "Give Nodes by Response Time"
# "Give Top 10 Nodes by CPU Load"
# "Give Nodes and their Interface Status"
response = agent_executor.invoke({"input": query, "agent_scratchpad": ""}) 
print(response["output"])