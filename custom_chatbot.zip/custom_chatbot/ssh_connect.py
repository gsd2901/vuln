import paramiko
import time
import asyncio

def run_ssh_command(host,username, password, command):
    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    
    try:
        ssh.connect(host, username=username, password=password)
        
        # Create a channel with pty
        stdin, stdout, stderr = ssh.exec_command(f'sudo -S {command}', get_pty=True)
        
        # Send password
        stdin.write(f'{password}\n')
        stdin.flush()
        
        # Wait briefly for command execution
        time.sleep(0.5)
        
        # Read output while ignoring the password prompt
        output = []
        while True:
            # Check if there's data available
            if stdout.channel.recv_ready():
                line = stdout.readline().strip()
                if line and line != password:  # Filter out password echo
                    output.append(line)
            elif stdout.channel.exit_status_ready():
                break
            time.sleep(0.1)
        
        # Get any remaining output
        remaining = stdout.read().decode().strip()
        if remaining and remaining != password:
            output.append(remaining)
        
        # Get errors (excluding password prompt)
        error = stderr.read().decode().strip()
        if error and 'password' not in error.lower():
            print(f"Error: {error}")
        
        return '\n'.join(output)
    finally:
        ssh.close()


async def async_run_ssh_command(host, user, password, command):
    loop = asyncio.get_event_loop()
    return await loop.run_in_executor(None, run_ssh_command, host, user, password, command)
