import os
from pathlib import Path
from urllib.parse import urlparse
import psycopg2

from langchain_community.document_loaders import PyPDFLoader
# from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_text_splitter import RecursiveCharacterTextSplitter
from langchain.vectorstores.pgvector import PGVector
from langchain.embeddings import HuggingFaceEmbeddings
from custom_chatbot.nautobot_querytool import ChatOpenRouter
from langchain.chains import RetrievalQA
from dotenv import load_dotenv
from langchain.prompts import PromptTemplate

class RAGPipeline:
    def __init__(self, docs_path: str, collection_name: str, db_connection_string: str):
        load_dotenv()
        self.docs_path = Path(docs_path)
        self.collection_name = collection_name
        self.connection_string = db_connection_string
        self.embeddings = HuggingFaceEmbeddings(model_name="sentence-transformers/all-MiniLM-L6-v2")
        self.vectorstore = None
        self.qa_chain = None

    def collection_exists(self) -> bool:
        parsed = urlparse(self.connection_string)
        db_name = parsed.path.lstrip('/')
        conn = psycopg2.connect(
            dbname=db_name,
            user=parsed.username,
            password=parsed.password,
            host=parsed.hostname,
            port=parsed.port
        )
        cursor = conn.cursor()
        cursor.execute("""
            SELECT EXISTS (
                SELECT FROM pg_tables
                WHERE schemaname = 'public' AND tablename = %s
            );
        """, (self.collection_name,))
        exists = cursor.fetchone()[0]
        cursor.close()
        conn.close()
        return exists

    def load_documents(self):
        all_docs = []
        for file in self.docs_path.glob("*.pdf"):
            loader = PyPDFLoader(str(file))
            docs = loader.load()
            all_docs.extend(docs)
        return all_docs

    def split_documents(self, documents):
        splitter = RecursiveCharacterTextSplitter(chunk_size=500, chunk_overlap=50)
        return splitter.split_documents(documents)

    def setup_vectorstore(self):
        if self.collection_exists():
            print(f"[INFO] Collection '{self.collection_name}' already exists. Skipping embedding.")
            self.vectorstore = PGVector(
                collection_name=self.collection_name,
                connection_string=self.connection_string,
                embedding_function=self.embeddings
            )
        else:
            print(f"[INFO] Creating new collection '{self.collection_name}' and storing embeddings...")
            docs = self.load_documents()
            splits = self.split_documents(docs)
            print(f"[DEBUG] Number of splits: {len(splits)}")
            self.vectorstore = PGVector.from_documents(
                documents=splits,
                embedding=self.embeddings,
                collection_name=self.collection_name,
                connection_string=self.connection_string
            )

    def setup_qa_chain(self):
        if not self.vectorstore:
            raise ValueError("Vector store is not initialized.")
        retriever = self.vectorstore.as_retriever(search_kwargs={"k": 5})
        llm = ChatOpenRouter(model_name="openai/gpt-4.1")
        
        # Create a proper PromptTemplate object
        QA_PROMPT = PromptTemplate(
            template="""Use the following context to answer the question in just one concise sentence:
            Context: {context}
            Question: {question}
            One-sentence answer:""",
            input_variables=["context", "question"]
        )
        
        self.qa_chain = RetrievalQA.from_chain_type(
            llm=llm,
            retriever=retriever,
            return_source_documents=True,
            chain_type_kwargs={"prompt": QA_PROMPT}
        )

    def query(self, question: str):
        if not self.qa_chain:
            raise ValueError("QA chain not initialized.")
        return self.qa_chain.invoke({"query": question})
