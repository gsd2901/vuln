"""
check_schema.py
----------------
Prints the top-level keys and a sample of the response from /api/?format=json
to help identify the correct schema URL.
"""
import os
import requests
from dotenv import load_dotenv

load_dotenv()

NAUTOBOT_URL = os.getenv("NAUTOBOT_URL", "http://localhost:8100")
TOKEN = os.getenv("NAUTOBOT_TOKEN", "your-token-here")

URLS_TO_CHECK = [
    "/api/?format=json",
    "/api/schema/",
    "/api/swagger/",
    "/api/redoc/",
    "/api/openapi/",
    "/api/openapi.json",
    "/api/openapi.yaml",
    "/api/swagger.yaml",
]

for path in URLS_TO_CHECK:
    url = f"{NAUTOBOT_URL}{path}"
    try:
        resp = requests.get(
            url,
            headers={"Authorization": f"Token {TOKEN}"},
            timeout=10,
            proxies={"http": "", "https": ""},
        )
        print(f"\n{'='*60}")
        print(f"URL    : {url}")
        print(f"Status : {resp.status_code}")
        if resp.ok:
            try:
                data = resp.json()
                print(f"Type   : JSON")
                print(f"Keys   : {list(data.keys())[:10]}")
            except Exception:
                print(f"Type   : non-JSON (maybe YAML?)")
                print(f"Preview: {resp.text[:300]}")
    except Exception as e:
        print(f"\n{url} → error: {e}")