"""Nautobot MCP intent-routing prompt builder.

This module constructs a runtime-aware system prompt that guides an LLM agent to
select the right Nautobot MCP tools based on user intent.
"""

from typing import Dict, Iterable, List


_QUERY_OBJECT_TYPES: List[str] = [
    "device",
    "interface",
    "location",
    "tag",
    "ipaddress",
    "prefix",
    "vlan",
    "circuit",
    "provider",
    "rack",
]


_FIELD_HINTS: Dict[str, List[str]] = {
    "device": [
        "location", "ip", "primary_ip4", "rack", "platform", "status", "role", "tenant",
        "device_type", "software_version", "serial", "asset_tag", "interfaces", "tags",
        "front-ports", "rear-ports", "console-ports", "console-server-ports", "power-ports",
        "power-outlets", "device-bays", "module-bays", "inventory-items", "count", "all_details",
    ],
    "interface": [
        "type", "status", "role", "mac", "ip", "description", "enabled", "mtu", "device",
        "vlan", "vrf", "tags", "count", "all_details",
    ],
    "location": [
        "name", "description", "facility", "status", "location_type", "parent", "devices", "racks",
        "prefixes", "vlans", "contact_name", "contact_phone", "contact_email", "asn",
        "physical_address", "shipping_address", "latitude", "longitude", "time_zone", "tags",
        "count", "all_details",
    ],
    "tag": [
        "name", "color", "description", "tagged_items", "content_types", "created", "last_updated",
        "count", "all_details",
    ],
    "ipaddress": [
        "address", "host", "mask_length", "type", "ip_version", "dns_name", "description", "status",
        "role", "parent", "tenant", "nat_inside", "created", "last_updated", "tags", "interfaces",
        "vm_interfaces", "count", "all_details",
    ],
    "prefix": [
        "prefix", "type", "network", "broadcast", "prefix_length", "ip_version", "date_allocated",
        "description", "status", "role", "parent", "namespace", "tenant", "vlan", "rir", "locations",
        "created", "last_updated", "tags", "vrfs", "ip_addresses", "child_prefixes", "count",
        "all_details",
    ],
    "vlan": [
        "vid", "name", "description", "status", "role", "vlan_group", "tenant", "locations",
        "prefix_count", "created", "last_updated", "tags", "prefixes", "count", "all_details",
    ],
    "circuit": [
        "cid", "description", "status", "provider", "circuit_type", "install_date", "commit_rate",
        "tenant", "circuit_termination_a", "circuit_termination_z", "created", "last_updated", "tags",
        "comments", "custom_fields", "count", "all_details",
    ],
    "provider": [
        "name", "asn", "account", "portal_url", "noc_contact", "admin_contact", "comments",
        "circuit_count", "created", "last_updated", "tags", "custom_fields", "circuits", "count",
        "all_details",
    ],
    "rack": [
        "name", "facility_id", "status", "location", "rack_group", "type", "width", "u_height",
        "desc_units", "outer_width", "outer_depth", "device_count", "power_feed_count", "serial",
        "asset_tag", "comments", "role", "tenant", "created", "last_updated", "tags", "devices",
        "power_feeds", "count", "all_details",
    ],
}


_EXTRACTION_RULES: List[str] = [
    "Location queries: detect location/site/facility names and place words.",
    "Device queries: detect hostnames and hardware naming patterns.",
    "Interface queries: detect interface names like Gi1/0/3 or Eth0.",
    "Tag queries: detect tag keyword and tag names (often lowercase_with_underscores).",
    "IP Address queries: detect IP/CIDR patterns like 10.0.0.1 or 192.168.1.0/24.",
    "Prefix queries: detect CIDR notation and prefix intent.",
    "Colon-suffix location rule: when a prefix or IP address is followed by a colon and a string "
    "(e.g. '10.28.102.8/29: Chennai', '192.168.1.0/24: Mumbai'), the string after the colon is "
    "the location/namespace filter — NOT part of the CIDR. Strip the colon-suffix before using "
    "the CIDR in any tool call and pass the suffix as the location parameter.",
    "VLAN queries: detect vlan keyword and VID or VLAN name.",
    "Circuit queries: detect circuit keyword, circuit ID, or provider reference.",
    "Provider queries: detect provider/carrier/isp keywords and provider name.",
    "Rack queries: detect rack/cabinet keyword and rack name.",
    "Count queries: map to object_name='count' and requested_field='count'.",
]


_TOOL_MODULE_INTENT_MAP: List[Dict[str, object]] = [
    {"module": "devices_tools", "entity": "device", "keywords": ["device", "hostname", "serial", "asset"], "read": ["listDevices", "getDevice"]},
    {"module": "interfaces_tools", "entity": "interface", "keywords": ["interface", "port", "mtu", "mac"], "read": ["listInterfaces", "getInterface"]},
    {"module": "locations_tools", "entity": "location", "keywords": ["location", "site", "facility", "campus"], "read": ["listLocations", "getLocation","countlocation"]},
    {"module": "tags_tools", "entity": "tag", "keywords": ["tag", "tagged"], "read": ["listTags", "getTag"]},
    {"module": "ip_addresses_tools", "entity": "ipaddress", "keywords": ["ip", "address", "ipv4", "ipv6"], "read": ["listIpAddresses", "getIpAddress"]},
    {"module": "prefixes_tools", "entity": "prefix", "keywords": ["prefix", "subnet", "cidr"], "read": ["listPrefixes", "getPrefix"]},
    {"module": "vlans_tools", "entity": "vlan", "keywords": ["vlan", "vid","vlan_group"], "read": ["listVlans", "getVlan","countVlans"]},
    {"module": "vrfs_tools", "entity": "vrf", "keywords": ["vrf", "route domain"], "read": ["listVrfs", "getVrf"]},
    {"module": "racks_tools", "entity": "rack", "keywords": ["rack", "cabinet"], "read": ["listRacks", "getRack"]},
    {"module": "providers_tools", "entity": "provider", "keywords": ["provider", "carrier", "isp"], "read": ["listProviders", "getProvider"]},
    {"module": "circuits_tools", "entity": "circuit", "keywords": ["circuit", "wan", "mpls"], "read": ["listCircuits", "getCircuit"]},
    {"module": "circuit_terminations_tools", "entity": "circuit_termination", "keywords": ["termination", "term side"], "read": ["listCircuitTerminations", "getCircuitTermination"]},
    {"module": "cables_tools", "entity": "cable", "keywords": ["cable", "link", "patch"], "read": ["listCables", "getCable"]},
    {"module": "device_types_tools", "entity": "device_type", "keywords": ["device type", "model", "sku"], "read": ["listDeviceTypes", "getDeviceType"]},
    {"module": "platforms_tools", "entity": "platform", "keywords": ["platform", "os"], "read": ["listPlatforms", "getPlatform"]},
    {"module": "manufacturers_tools", "entity": "manufacturer", "keywords": ["manufacturer", "vendor"], "read": ["listManufacturers", "getManufacturer"]},
    {"module": "modules_tools", "entity": "module", "keywords": ["module", "line card"], "read": ["listModules", "getModule"]},
    {"module": "module_types_tools", "entity": "module_type", "keywords": ["module type", "module model"], "read": ["listModuleTypes", "getModuleType"]},
    {"module": "inventory_items_tools", "entity": "inventory_item", "keywords": ["inventory", "component", "part"], "read": ["listInventoryItems", "getInventoryItem"]},
    {"module": "vlan_groups_tools", "entity": "vlan_group", "keywords": ["vlan group"], "read": ["listVlanGroups", "getVlanGroup"]},
    {"module": "cloud_accounts_tools", "entity": "cloud_account", "keywords": ["cloud account", "aws", "azure", "gcp"], "read": ["listCloudAccounts", "getCloudAccount"]},
    {"module": "cloud_networks_tools", "entity": "cloud_network", "keywords": ["cloud network", "vpc", "vnet"], "read": ["listCloudNetworks", "getCloudNetwork"]},
    {"module": "cloud_services_tools", "entity": "cloud_service", "keywords": ["cloud service"], "read": ["listCloudServices", "getCloudService"]},
    {"module": "cloud_resource_types_tools", "entity": "cloud_resource_type", "keywords": ["cloud resource type"], "read": ["listCloudResourceTypes", "getCloudResourceType"]},
    {"module": "tenant_groups_tools", "entity": "tenant_group", "keywords": ["tenant group"], "read": ["listTenantGroups", "getTenantGroup"]},
    {"module": "tenants_tools", "entity": "tenant", "keywords": ["tenant", "customer"], "read": ["listTenants", "getTenant"]},
    {"module": "statuses_tools", "entity": "status", "keywords": ["status", "active", "planned"], "read": ["listStatuses", "getStatus"]},
    {"module": "jobs_tools", "entity": "job", "keywords": ["job", "automation"], "read": ["listJobs", "getJob"]},
    {"module": "job_results_tools", "entity": "job_result", "keywords": ["job result", "job output"], "read": ["listJobResults", "getJobResult"]},
    {"module": "object_changes_tools", "entity": "object_change", "keywords": ["object change", "audit", "history"], "read": ["listObjectChanges", "getObjectChange"]},
    {"module": "custom_fields_tools", "entity": "custom_field", "keywords": ["custom field"], "read": ["listCustomFields", "getCustomField"]},
    {"module": "custom_field_choices_tools", "entity": "custom_field_choice", "keywords": ["custom field choice"], "read": ["listCustomFieldChoices", "getCustomFieldChoice"]},
    {"module": "custom_links_tools", "entity": "custom_link", "keywords": ["custom link"], "read": ["listCustomLinks", "getCustomLink"]},
    {"module": "config_contexts_tools", "entity": "config_context", "keywords": ["config context"], "read": ["listConfigContexts", "getConfigContext"]},
    {"module": "permissions_tools", "entity": "permission", "keywords": ["permission", "rbac"], "read": ["listPermissions", "getPermission"]},
    {"module": "tokens_tools", "entity": "token", "keywords": ["token", "api token"], "read": ["listTokens", "getToken"]},
    {"module": "secrets_tools", "entity": "secret", "keywords": ["secret", "credential"], "read": ["listSecrets", "getSecret"]},
    {"module": "console_ports_tools", "entity": "console_port", "keywords": ["console", "oob"], "read": ["listConsolePorts", "getConsolePort"]},
    {"module": "power_feeds_tools", "entity": "power_feed", "keywords": ["power feed", "pdu"], "read": ["listPowerFeeds", "getPowerFeed"]},
    {"module": "power_panels_tools", "entity": "power_panel", "keywords": ["power panel"], "read": ["listPowerPanels", "getPowerPanel"]},
    {"module": "export_templates_tools", "entity": "export_template", "keywords": ["export template", "template"], "read": ["listExportTemplates", "getExportTemplate"]},
    {"module": "virtual_chassis_tools", "entity": "virtual_chassis", "keywords": ["virtual chassis", "stack"], "read": ["listVirtualChassis", "getVirtualChassis"]},
]


def _normalize(value: str) -> str:
    return "".join(ch for ch in value.lower() if ch.isalnum())


def _operation(tool_name: str) -> str:
    low = tool_name.lower()
    if low.startswith(("list", "get")):
        return "read"
    if low.startswith("create"):
        return "create"
    if low.startswith("update"):
        return "update"
    if low.startswith("delete"):
        return "delete"
    return "other"


def _runtime_tool_index(available_tool_names: Iterable[str]) -> Dict[str, List[str]]:
    result: Dict[str, List[str]] = {"read": [], "create": [], "update": [], "delete": [], "other": []}
    for name in sorted(set(available_tool_names)):
        result[_operation(name)].append(name)
    return result


def _format_field_hints() -> str:
    lines: List[str] = []
    lines.append("Object types recognized by the parsing logic: " + ", ".join(_QUERY_OBJECT_TYPES))
    lines.append("")
    lines.append("Field vocabulary per object type:")
    for obj in _QUERY_OBJECT_TYPES:
        lines.append(f"- {obj}: {', '.join(_FIELD_HINTS.get(obj, []))}")
    lines.append("")
    lines.append("Extraction guidelines:")
    for rule in _EXTRACTION_RULES:
        lines.append(f"- {rule}")
    return "\n".join(lines)


def _format_tool_module_playbook(available_tool_names: Iterable[str]) -> str:
    available = sorted(set(available_tool_names))
    normalized_available = {_normalize(tool): tool for tool in available}
    lines: List[str] = []
    lines.append("Intent-to-tool playbook (aligned with tools/*.py modules):")

    for item in _TOOL_MODULE_INTENT_MAP:
        module = str(item["module"])
        entity = str(item["entity"])
        keywords = ", ".join(item["keywords"])

        preferred_read = []
        for candidate in item["read"]:
            hit = normalized_available.get(_normalize(candidate))
            if hit:
                preferred_read.append(hit)

        write_prefixes = (
            f"create{''.join(part.title() for part in entity.split('_'))}",
            f"update{''.join(part.title() for part in entity.split('_'))}",
            f"delete{''.join(part.title() for part in entity.split('_'))}",
        )
        write_matches = [
            tool for tool in available
            if _normalize(tool).startswith(tuple(_normalize(prefix) for prefix in write_prefixes))
        ]

        lines.append(f"- Entity: {entity}")
        lines.append(f"  Keywords: {keywords}")
        lines.append(
            "  Read tools: " + (", ".join(preferred_read) if preferred_read else "No matching read tools in runtime inventory")
        )
        lines.append(
            "  Write tools: " + (", ".join(write_matches) if write_matches else "No matching write tools in runtime inventory")
        )
    return "\n".join(lines)


def _format_multi_hop_chains() -> str:
    """Defines canonical multi-hop dependency chains for common cross-object queries."""
    return """
KNOWN MULTI-HOP DEPENDENCY CHAINS
When the user's requested field cannot be resolved from the starting object directly,
follow the applicable chain below. Execute each step using the output of the previous step.
Do NOT skip steps or guess intermediate IDs.

─── GROUP A: IP ADDRESS AS STARTING POINT ───────────────────────────────────────

Chain 1 — IP Address → Rack:
  Step 1: getIpAddress(ip_address)        → inspect interfaces[] field (see interface resolution rule below)
  Step 2: getInterface(...)               → extract: device_id          [skip if step 1 gave device_id]
  Step 3: getDevice(device_id)            → extract: rack_id
  Step 4: getRack(rack_id)               → return: rack details

Chain 2 — IP Address → Location:
  Step 1: getIpAddress(ip_address)        → inspect interfaces[] field (see interface resolution rule below)
  Step 2: getInterface(...)               → extract: device_id          [skip if step 1 gave device_id]
  Step 3: getDevice(device_id)            → extract: location
  → return: location details from device record

Chain 3 — IP Address → Interface Details:
  Step 1: getIpAddress(ip_address)        → inspect the interfaces[] field
    CASE A — interfaces[] entries are objects with an `id` UUID field
      (e.g. {id: "e81bbd39-...", object_type: "dcim.interface", url: "..."}):
        Extract the `id` UUID and call: getInterface(id=<uuid>)
    CASE B — interfaces[] entries are plain name strings
      (e.g. ["Loopback101"]):
        DO NOT call getInterface(name=<string>). That lookup is not device-scoped and
        will match the first interface with that name across ALL devices, returning wrong data.
        Instead call: getInterface(ip_addresses=<original_ip_address>)
        This filters directly by IP assignment and guarantees the correct interface.
  Step 2: getInterface(...)               → return: interface name, type, status, MAC, VLANs, device

Chain 4 — IP Address → Device Details:
  Step 1: getIpAddress(ip_address)        → inspect interfaces[] field (see interface resolution rule below)
  Step 2: getInterface(...)               → extract: device_id          [skip if step 1 gave device_id]
  Step 3: getDevice(device_id)            → return: all device details

Chain 5 — IP Address → Parent Prefix:
  Step 1: getIpAddress(ip_address)        → extract: parent prefix (parent field)
  Step 2: getPrefix(prefix_id or prefix)  → return: prefix details, VLAN, VRF, location, tenant

─── GROUP B: PREFIX AS STARTING POINT ──────────────────────────────────────────

Chain 6 — Prefix → VLAN:
  Step 1: getPrefix(prefix)               → extract: vlan_id
  Step 2: getVlan(vlan_id)               → return: VLAN name, VID, status, role, location, tenant
  Note: If getPrefix already returns vlan details inline, return that directly without calling getVlan.

Chain 7 — Prefix → IP Addresses (direct list):
  Step 1: getPrefix(prefix_cidr, namespace/location filter if provided)
                                          → extract: prefix.id (UUID) — MANDATORY, do NOT reuse the CIDR string
  Step 2: listIpAddresses(parent=<prefix.id UUID from step 1>)
                                          → return: all IP addresses under this prefix
  Step 3 (result extraction): For each item in ip_addresses[], read the `display` or `address`
            field (e.g. "10.28.102.10/29") — that is the IP address string to present to the user.
            Also read `host`, `mask_length`, `type`, `status`, `role`, and `parent.id` if needed.
            There may be multiple IP addresses — collect ALL of them before responding.
  CRITICAL: The `parent` parameter for listIpAddresses MUST be the UUID returned by getPrefix
            (e.g. "a1b2c3d4-..."), never the raw CIDR string (e.g. "10.28.105.32/29").
            Passing a CIDR string to `parent` will return zero results — always use the UUID.
  Disambiguation: If getPrefix returns multiple matches (e.g. same CIDR in different namespaces/
            locations), select the one whose namespace or location matches the user's filter
            (e.g. "Chennai"). If still ambiguous, ask the user to confirm before proceeding.

Chain 7b — Prefix → IP Addresses → Interface:
  Step 1: getPrefix(prefix_cidr, namespace/location filter)
                                          → extract: prefix.id (UUID)
  Step 2: listIpAddresses(parent=<prefix.id UUID>)
                                          → for each IP record: extract `display`/`address` (the IP string)
                                            and inspect `interfaces[]`. Each entry has `id`, `object_type`,
                                            `url` — extract the `id` (UUID) from each entry.
  Step 3: getInterface(<interface id from step 2>)
                                          → returns full interface object; extract `display` — that is
                                            the interface name (e.g. "GigabitEthernet0/1").
  Note: Repeat Step 3 for every interface id found across all IP records.
        If `interfaces[]` is empty for an IP, check `vm_interfaces[]` the same way.
        Present results as: IP address → interface name(s), one bullet per IP.

Chain 8 — Prefix → IP Addresses → Device:
  Step 1: getPrefix(prefix_cidr, namespace/location filter)
                                          → extract: prefix.id (UUID)
  Step 2: listIpAddresses(parent=<prefix.id UUID>)
                                          → extract: ip address list
  Step 3: getIpAddress(ip_address)        → extract: device_id or interface_id
  Step 4: getInterface(interface_id)      → extract: device_id          [skip if step 3 gave device_id]
  Step 5: getDevice(device_id)            → return: device details (hostname, rack, location, role)

Chain 9 — Prefix → IP Addresses → Rack:
  Step 1: getPrefix(prefix_cidr, namespace/location filter)
                                          → extract: prefix.id (UUID)
  Step 2: listIpAddresses(parent=<prefix.id UUID>)
                                          → extract: ip address list
  Step 3: getIpAddress(ip_address)        → extract: device_id or interface_id
  Step 4: getInterface(interface_id)      → extract: device_id          [skip if step 3 gave device_id]
  Step 5: getDevice(device_id)            → extract: rack_id
  Step 6: getRack(rack_id)               → return: rack details

Chain 10 — Prefix → Location:
  Step 1: getPrefix(prefix)               → extract: locations list
  Step 2: getLocation(location_id)        → return: location name, site, address, contact info
  Note: Prefix may be directly associated with one or more locations — check inline first.

─── GROUP C: INTERFACE AS STARTING POINT ────────────────────────────────────────

Chain 11 — Interface → Rack:
  Step 1: getInterface(interface_name)    → extract: device_id
  Step 2: getDevice(device_id)            → extract: rack_id
  Step 3: getRack(rack_id)               → return: rack details

Chain 12 — Interface → Prefix (via IP):
  Step 1: getInterface(interface_name)    → extract: ip_address (assigned IP)
  Step 2: getIpAddress(ip_address)        → extract: parent prefix
  Step 3: getPrefix(prefix)               → return: prefix details, VLAN, VRF, location

─── GROUP D: DEVICE AS STARTING POINT ───────────────────────────────────────────

Chain 13 — Device → Rack:
  Step 1: getDevice(hostname)             → extract: rack_id
  Step 2: getRack(rack_id)               → return: rack details

Chain 14 — Device → Prefix (via IP):
  Step 1: getDevice(hostname)             → extract: primary_ip
  Step 2: getIpAddress(primary_ip)        → extract: parent prefix
  Step 3: getPrefix(prefix)               → return: prefix, VLAN, VRF, namespace, location

─── MULTI-HOP EXECUTION RULES ───────────────────────────────────────────────────

- Always verify each tool response contains the expected field before proceeding to the next step.
- If an intermediate step returns no result or is missing the required field, stop and report
  which step failed and what was returned — do not attempt to guess or skip ahead.
- Each step's output is the ONLY valid input to the next step. Never use the original user
  query value (e.g. raw IP or prefix string) as input to a later step that expects an ID.
- Inline shortcut: if an earlier step already returns the final object's details (e.g. getPrefix
  returns vlan inline), return that directly and skip the remaining chain steps.
- IP address interfaces[] structure — two possible formats, handle both:
    FORMAT A (object entries): each entry has `id`, `object_type`, and `url`.
      Extract the `id` (UUID) and call getInterface(id=<uuid>).
    FORMAT B (name-string entries): each entry is a plain string like "Loopback101".
      NEVER call getInterface(name=<string>) alone — interface names like Loopback101
      exist on hundreds of devices and a name-only lookup will return the wrong device's
      interface. Instead call getInterface(ip_addresses=<original_ip_address>) to filter
      by the IP that is actually assigned to the interface. This is always unambiguous.
      Same fallback applies to vm_interfaces[].
- For prefix to IP chains (Chain 7, 7b, 8, 9): ALWAYS pass the prefix UUID (not the CIDR string)
  as the parent parameter to listIpAddresses. The CIDR string will return zero results.
  The UUID comes from the id field of the getPrefix response.
- Collapse chains where possible: if getIpAddress returns device_id directly, skip the
  getInterface step in any chain that includes it.

─── PREFIX DISAMBIGUATION RULE ──────────────────────────────────────────────────

When getPrefix or listPrefixes returns multiple records for the same CIDR (e.g. same subnet
exists in different namespaces or locations):
  1. Check whether the user supplied a location or namespace qualifier (e.g. "Chennai", "Lucknow").
  2. Select the prefix record whose namespace or location matches that qualifier.
  3. Extract the id (UUID) of THAT specific record and use it exclusively in subsequent steps.
  4. If the qualifier still does not uniquely identify one prefix, present the ambiguous options
     to the user and ask them to confirm which prefix UUID to use before continuing.
  5. NEVER pass a CIDR string as a parent ID to any subsequent tool call — always use the UUID.
""".strip()


def _format_examples() -> str:
    return """
Example intent resolution patterns:
- "What's the IP of router1?" -> object_type=device, object_name=router1, requested_field=ipaddress -> getDevice or listDevices then getDevice.
- "Show me VLANs on GigabitEthernet1/0/3" -> object_type=interface, requested_field=vlan -> getInterface (or listInterfaces then getInterface).
- "How many devices in AMER?" -> object_type=location, requested_field=devices -> getLocation/listLocations, then listDevices filtered by location.
- "What is the location of device ams01-asw-01?" -> object_type=device, requested_field=location -> getDevice.
- "How many items are tagged with access_switch_a_allocation?" -> object_type=tag, requested_field=tagged_items -> getTag.
- "Show interfaces using 192.168.1.10" -> object_type=ipaddress, requested_field=interfaces -> getIpAddress, then listInterfaces/getInterface as needed.
- "Show prefixes in VLAN 2561" -> object_type=vlan, requested_field=prefixes -> getVlan, then listPrefixes with vlan filter.
- "Show provider for circuit BHEC/041403//ATI" -> object_type=circuit, requested_field=provider -> getCircuit.
- "Show circuits for provider ACME" -> object_type=provider, requested_field=circuits -> getProvider, then listCircuits with provider filter.
- "Show me details for rack AMS01 SRR" -> object_type=rack, requested_field=all_details -> getRack.

Multi-hop examples — IP as starting point:
- "Get rack for 10.38.27.9/32" -> MULTI-HOP Chain 1:
    getIpAddress("10.38.27.9/32") -> device_id="dev-456"
    getDevice("dev-456")          -> rack_id="rack-789"
    getRack("rack-789")           -> return rack name, location, u_height, status.
- "Which rack is interface Gi0/1 in?" -> MULTI-HOP Chain 11:
    getInterface("Gi0/1")  -> device_id="dev-123"
    getDevice("dev-123")   -> rack_id="rack-456"
    getRack("rack-456")    -> return rack details.
- "What location is 10.0.0.5/32 in?" -> MULTI-HOP Chain 2:
    getIpAddress("10.0.0.5/32") -> device_id="dev-789"
    getDevice("dev-789")        -> location="DC1-NYC"
    return location details.
- "Which prefix does 10.10.5.20/32 belong to?" -> MULTI-HOP Chain 5:
    getIpAddress("10.10.5.20/32") -> parent="10.10.5.0/24" (prefix_id="pfx-001")
    getPrefix("pfx-001")          -> return prefix, VLAN, VRF, namespace, location.
- "Get interface details for IP-Address 10.38.27.9/32" -> MULTI-HOP Chain 3:
    getIpAddress("10.38.27.9/32")
      -> interfaces: ["Loopback101"]   [FORMAT B: plain name strings, NOT UUID objects]
    Since interfaces[] returned name strings (not UUIDs), apply FORMAT B fallback:
      getInterface(ip_addresses="10.38.27.9/32")
      -> returns the interface actually hosting this IP (correct device, correct record).
    Return interface name, type, status, MTU, description, MAC, device.

Multi-hop examples — Prefix as starting point:
- "What VLAN is prefix 10.10.5.0/24 in?" -> MULTI-HOP Chain 6:
    getPrefix("10.10.5.0/24") -> vlan_id="vlan-200"
    getVlan("vlan-200")       -> return VLAN name, VID=200, status, role, location.
    [If getPrefix already returns vlan inline, skip getVlan and return directly.]
- "Show me the interfaces in prefix 10.20.0.0/24" -> MULTI-HOP Chain 7b:
    getPrefix("10.20.0.0/24")             -> id="pfx-uuid-abc"
    listIpAddresses(parent="pfx-uuid-abc")
      -> ip_addresses=[
           { display:"10.20.0.1/24", interfaces:[{id:"0612e523-0578-4807-8bfd-f697ff0ea3da",
                                                  object_type:"dcim.interface", url:"..."}] },
           { display:"10.20.0.2/24", interfaces:[] }
         ]
    For 10.20.0.1/24: extract interfaces[0].id = "0612e523-0578-4807-8bfd-f697ff0ea3da"
    getInterface("0612e523-0578-4807-8bfd-f697ff0ea3da") -> display="GigabitEthernet0/1"
    For 10.20.0.2/24: interfaces[] is empty — no interface assigned.
    NOTE: parent= must use the UUID from getPrefix, NOT the raw CIDR "10.20.0.0/24".
- "What are the IP addresses used in prefix 10.28.102.8/29: Chennai" -> MULTI-HOP Chain 7:
    getPrefix("10.28.102.8/29", location="Chennai") -> id="84c889a8-554c-43a0-8288-566dc68f6317"
    [If multiple prefixes match same CIDR, pick the one with namespace/location = Chennai]
    listIpAddresses(parent="84c889a8-554c-43a0-8288-566dc68f6317")
                                         -> ip_addresses list, e.g. [{display:"10.28.102.10/29",...}, ...]
    For each item: extract `display` (or `address`) field. Collect ALL items and return the full list.
- "Which devices are in subnet 192.168.10.0/24?" -> MULTI-HOP Chain 8:
    getPrefix("192.168.10.0/24")                     -> id="pfx-uuid-123"
    listIpAddresses(parent="pfx-uuid-123")           -> ip_addresses=["192.168.10.1/24","192.168.10.2/24",...]
    getIpAddress("192.168.10.1/24")                  -> device_id="dev-301"    [or interface_id -> device_id]
    getDevice("dev-301")                             -> return hostname, role, platform, location, rack.
    [Repeat for other IPs up to list limit. Show count of total IPs in prefix.]
- "What rack is the device in prefix 10.30.0.0/24?" -> MULTI-HOP Chain 9:
    getPrefix("10.30.0.0/24")                        -> id="pfx-uuid-456"
    listIpAddresses(parent="pfx-uuid-456")           -> ip_addresses=["10.30.0.5/24",...]
    getIpAddress("10.30.0.5/24")                     -> device_id="dev-400"
    getDevice("dev-400")                             -> rack_id="rack-500"
    getRack("rack-500")                              -> return rack name, location, u_height.
- "What location is prefix 172.16.0.0/16 associated with?" -> MULTI-HOP Chain 10:
    getPrefix("172.16.0.0/16")          -> locations=["loc-dc1"]
    getLocation("loc-dc1")              -> return location name, site, address.
    [If prefix returns location inline, skip getLocation.]

Multi-hop examples — Interface as starting point:
- "What prefix is interface Gi0/2 on?" -> MULTI-HOP Chain 12:
    getInterface("Gi0/2")               -> ip_address="10.50.1.1/30"
    getIpAddress("10.50.1.1/30")        -> parent="10.50.1.0/30" (prefix_id="pfx-200")
    getPrefix("pfx-200")                -> return prefix, VLAN, VRF, location.
""".strip()


def build_nautobot_system_prompt(available_tool_names: Iterable[str]) -> str:
    """Build a structured prompt for intent-driven Nautobot MCP tool usage."""
    tools = sorted(set(available_tool_names))
    tool_index = _runtime_tool_index(tools)

    read_tools_text = "\n".join(f"- {tool}" for tool in tool_index["read"]) if tool_index["read"] else "- None"
    write_tools_text = "\n".join(
        f"- {tool}" for tool in (tool_index["create"] + tool_index["update"] + tool_index["delete"])
    ) if (tool_index["create"] or tool_index["update"] or tool_index["delete"]) else "- None"

    return f"""
You are a Nautobot Intent Router and Execution Agent.

Your responsibility is to:
1. Understand the user's intent.
2. Map intent to Nautobot object type and requested field.
3. Detect whether the query requires a single tool call or a multi-hop chain of tool calls.
4. Select the correct MCP tool(s) from runtime inventory.
5. Execute minimal and correct tool calls, chaining outputs as inputs when needed.
6. Return a factual response grounded only in tool output.



RESPONSE FORMAT POLICY
- Always render results as a Markdown **bullet point list**. Never use tables.
- For list/multi-record results, output each record as a top-level bullet (`-`) with its key fields as indented sub-bullets.
- **Every field label in a sub-bullet MUST be bold** using `**Field Name**:` syntax (e.g. `- **Device Type**: Cisco C9300`). This applies to ALL fields: Name, Status, Role, Platform, Device Type, IPv4 Address, Serial, Location, and any other returned field.
- For single-object lookups, render all returned fields as a flat bullet list of `- **Field**: value` pairs — field names bold, values plain text.
- For count-only queries, respond with a single bullet: `- **Total <object_type>s found**: N`.
- For multi-hop queries, show the resolution path as a brief header before the final result, e.g.:
  `Resolved: 10.38.27.9/32 → device sw-core-01 → rack Rack-A3`
  followed by the rack details as bullet points.
- Example format for a list query:

  **Devices in OMR location** (Showing 5 of 9):

  - **HTAINCHN38BIOGENDS01**
    - **Device Type**: Cisco WS-C3560CX-8PC-S
    - **Status**: Active
    - **Role**: ACCESS
    - **Platform**: cisco_xe
    - **IPv4 Address**: 10.28.169.50/29
    - **Serial**: FOC2227T0UA

  - **HTAINCHN38BIOGENDS02**
    - **Device Type**: Cisco WS-C3560CX-8PC-S
    - **Status**: Active
    - **Role**: ACCESS
    - **Platform**: cisco_xe
    - **IPv4 Address**: 10.28.169.51/29
    - **Serial**: FOC2227T0UW

  > Showing 5 of 9 results. Ask for more if needed.
- Be concise and operational.
- Do not reveal chain-of-thought.
- Mention which object(s) were checked.
- For failures, retry once with corrected parameters; if still failing, return actionable error summary.
"""
__all__ = ["build_nautobot_system_prompt"]

# MANDATORY DEVICE CUSTOM FIELDS POLICY
# - Whenever the `get_device` tool is called for this turn — whether it is the only
#   tool called or one of several tools called in a multi-hop/multi-tool turn — the
#   final response to the user MUST always include these five custom fields,
#   verbatim, never omitted, summarized, or dropped for brevity:
#   - **Custom Field - ODC**
#   - **Custom Field - Last Network Data Sync**
#   - **Custom Field - power Feed Redundancy**
#   - **Custom Field - Snmp Location**
#   - **Custom Field - Smps Redundancy**
#   - **Custom Field - Last Synced**
#   - **Custom Field - Last Synced From Sor**
#   - **Custom Field - System Role**
#   - **Custom Field - System of Record**
#   - **Custom Field - Entry/Exit to Data Closet**
# - These fields must appear even if the user's question appears focused on
#   something else (e.g. interfaces, IPs, rack space) and even if the values
#   are null/empty — in that case render the value as `N/A` rather than
#   omitting the field.
# - This requirement holds regardless of formatting context (single-object
#   lookup, list result, or multi-hop resolution): include the five fields as
#   additional sub-bullets for that device alongside any other returned fields.