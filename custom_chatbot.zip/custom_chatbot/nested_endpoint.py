"""
discover_nested_endpoints.py
-----------------------------
Discovers all nested sub-resource endpoints in Nautobot by:
1. Fetching /api/ -> app URLs -> resource URLs
2. Fetching one real UUID per parent resource
3. Probing a known list of sub-resource slugs against each parent
4. Recording 200/400 responses as valid nested endpoints

Usage:
    python discover_nested_endpoints.py

Output:
    nested_endpoints.txt
"""

import os
import requests
from collections import defaultdict
from dotenv import load_dotenv

load_dotenv()

# NAUTOBOT_URL = os.getenv("NAUTOBOT_URL", "http://localhost:8100")
# TOKEN = os.getenv("NAUTOBOT_TOKEN", "your-token-here")
OUTPUT_FILE = "nested_endpoints.txt"

HEADERS = {
    "Authorization": f"Token {TOKEN}",
    "Content-Type": "application/json",
}

SKIP_APPS = {"apps", "graphql", "plugins", "status"}

# All known Nautobot sub-resource slugs to probe
SUB_RESOURCES = [
    "ip-addresses",
    "prefixes",
    "interfaces",
    "devices",
    "vlans",
    "vrfs",
    "racks",
    "locations",
    "circuits",
    "cables",
    "providers",
    "tags",
    "console-ports",
    "power-ports",
    "power-outlets",
    "rear-ports",
    "front-ports",
    "device-bays",
    "module-bays",
    "inventory-items",
    "napalm",
    "render-config",
    "available-ips",
    "available-prefixes",
    "units",
    "elevation",
    "members",
    "terminations",
    "paths",
]


def get(url) -> dict:
    resp = requests.get(
        url, headers=HEADERS, timeout=30, proxies={"http": "", "https": ""}
    )
    resp.raise_for_status()
    return resp.json()


def fetch_all_resource_paths() -> list[str]:
    root = get(f"{NAUTOBOT_URL}/api/?format=json")
    paths = []
    for app, app_url in root.items():
        if app in SKIP_APPS or not isinstance(app_url, str):
            continue
        try:
            app_index = get(app_url if "format=json" in app_url else app_url + "?format=json")
        except Exception as e:
            print(f"  Skipping app {app}: {e}")
            continue
        for resource, resource_url in app_index.items():
            if not isinstance(resource_url, str):
                continue
            path = resource_url.replace(NAUTOBOT_URL, "").split("?")[0].rstrip("/") + "/"
            paths.append(path)
    return paths


def fetch_real_uuid(path: str) -> str | None:
    url = f"{NAUTOBOT_URL}{path}?limit=1&format=json"
    try:
        resp = requests.get(
            url, headers=HEADERS, timeout=10, proxies={"http": "", "https": ""}
        )
        if not resp.ok:
            return None
        results = resp.json().get("results", [])
        if results and results[0].get("id"):
            return results[0]["id"]
    except Exception:
        pass
    return None


def probe_nested_endpoints(base_paths: list[str]) -> dict:
    grouped = defaultdict(list)

    resources = []
    for path in base_paths:
        parts = [p for p in path.strip("/").split("/") if p]
        if len(parts) == 3:
            resources.append((parts[1], parts[2], path))

    print("Fetching real UUIDs for each resource ...")
    real_uuids = {}
    for app, resource, path in resources:
        uid = fetch_real_uuid(path)
        real_uuids[(app, resource)] = uid
        print(f"  {app}/{resource} -> {uid or 'no records'}")

    total_probes = len(resources) * len(SUB_RESOURCES)
    print(f"\nProbing {len(resources)} parents x {len(SUB_RESOURCES)} sub-resources = {total_probes} combinations ...")

    for app, parent, _ in resources:
        uid = real_uuids.get((app, parent))
        if not uid:
            continue

        for sub_resource in SUB_RESOURCES:
            probe_url = f"{NAUTOBOT_URL}/api/{app}/{parent}/{uid}/{sub_resource}/"
            try:
                resp = requests.get(
                    probe_url,
                    headers=HEADERS,
                    timeout=10,
                    proxies={"http": "", "https": ""},
                )
                if resp.status_code in (200, 400):
                    entry = {
                        "path": f"/api/{app}/{parent}/{{id}}/{sub_resource}/",
                        "sub_resource": sub_resource,
                        "methods": ["GET"],
                        "probe_status": resp.status_code,
                    }
                    grouped[f"{app}/{parent}"].append(entry)
                    print(f"  FOUND: /api/{app}/{parent}/{{id}}/{sub_resource}/ [{resp.status_code}]")
            except Exception:
                pass

    return dict(sorted(grouped.items()))


def write_output(grouped: dict, output_file: str):
    lines = []
    lines.append("=" * 70)
    lines.append("NAUTOBOT NESTED ENDPOINTS DISCOVERY")
    lines.append(f"Source: {NAUTOBOT_URL}")
    lines.append("=" * 70)
    lines.append("")

    total = 0
    for parent_key, endpoints in grouped.items():
        lines.append(f"[{parent_key}]")
        for ep in endpoints:
            lines.append(f"  {ep['path']}")
            lines.append(f"    sub_resource : {ep['sub_resource']}")
            lines.append(f"    methods      : {', '.join(ep['methods'])}")
            lines.append(f"    probe_status : {ep['probe_status']}")
            lines.append(f"    tool_name    : list_{parent_key.split('/')[1].replace('-', '_')}_{ep['sub_resource'].replace('-', '_')}")
            lines.append("")
            total += 1

    lines.append("=" * 70)
    lines.append(f"Total nested endpoints found: {total}")
    lines.append("=" * 70)

    with open(output_file, "w") as f:
        f.write("\n".join(lines))

    print(f"\nWritten {total} nested endpoints to {output_file}")


def main():
    print(f"Fetching resource paths from {NAUTOBOT_URL} ...")
    base_paths = fetch_all_resource_paths()
    print(f"Found {len(base_paths)} base resource endpoints.")
    grouped = probe_nested_endpoints(base_paths)
    write_output(grouped, OUTPUT_FILE)


if __name__ == "__main__":
    main()