import os
import requests
from dotenv import load_dotenv

load_dotenv()

NAUTOBOT_URL = os.getenv("NAUTOBOT_URL", "http://localhost:8100")
TOKEN = os.getenv("NAUTOBOT_TOKEN", "your-token-here")

resp = requests.get(
    f"{NAUTOBOT_URL}/api/?format=json",
    headers={"Authorization": f"Token {TOKEN}"},
    timeout=30,
    proxies={"http": "", "https": ""},
)
import json
print(json.dumps(resp.json(), indent=2))