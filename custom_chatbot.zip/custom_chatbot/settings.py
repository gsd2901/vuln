"""
Settings for the Custom Chatbot plugin with Vulnerability Management integration.
"""

import os

# Vulnerability Management API settings
VMAPI_BASE_URL = os.getenv("VMAPI_BASE_URL", "http://localhost:8099")
VMAPI_TIMEOUT = int(os.getenv("VMAPI_TIMEOUT", "30"))

# Chatbot settings
CHATBOT_DEBUG = os.getenv("CHATBOT_DEBUG", "False").lower() == "true"
CHATBOT_LOG_LEVEL = os.getenv("CHATBOT_LOG_LEVEL", "INFO")

# FastAPI integration fallback settings
ENABLE_VM_FALLBACK = os.getenv("ENABLE_VM_FALLBACK", "True").lower() == "true"
VM_FALLBACK_MESSAGE = os.getenv(
    "VM_FALLBACK_MESSAGE", 
    "Vulnerability management service is currently unavailable"
)