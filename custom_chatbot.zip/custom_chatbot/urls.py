from django.urls import path
from .views import ChatbotView, chat_status, DnacInstancesView
from .vm_views import (
    VMDashboardView,
    VMDevicesView,
    VMAdvisoriesView,
    VMDiscoveryView,
    VMReportView,
    VMTriggerDiscoveryView,
    VMCreateTicketView,
    VMAPIProxyView,
    VMCacheManagementView,
)
from . import psirt_native_views as psirt

app_name = "custom_chatbot"

urlpatterns = [
    # Existing chatbot endpoints
    path('chat/', ChatbotView.as_view(), name='chatbot'),
    path('chat_status/', chat_status, name='chat_status'),
    path('dnac-instances/', DnacInstancesView.as_view(), name='dnac_instances'),
    
    # Vulnerability Management UI pages
    path('vm/', VMDashboardView.as_view(), name='vm_dashboard'),
    path('vm/devices/', VMDevicesView.as_view(), name='vm_devices'),
    path('vm/advisories/', VMAdvisoriesView.as_view(), name='vm_advisories'),
    path('vm/discovery/', VMDiscoveryView.as_view(), name='vm_discovery'),
    path('vm/reports/<str:scan_id>/', VMReportView.as_view(), name='vm_report'),
    path('vm/reports/', VMReportView.as_view(), name='vm_report_latest'),
    
    # Vulnerability Management AJAX endpoints
    path('vm/trigger-discovery/', VMTriggerDiscoveryView.as_view(), name='vm_trigger_discovery'),
    path('vm/create-ticket/', VMCreateTicketView.as_view(), name='vm_create_ticket'),
    path('vm/api/<str:endpoint>/', VMAPIProxyView.as_view(), name='vm_api_proxy'),
    path('vm/cache/<str:action>/', VMCacheManagementView.as_view(), name='vm_cache_management'),

    # PSIRT Chatbot (native Django port of psirt_chatbot.py) endpoints
    path('psirt/api/chat/', psirt.psirt_chat, name='psirt_chat'),
    path('psirt/api/history/', psirt.psirt_history, name='psirt_history'),
    path('psirt/api/clear/', psirt.psirt_clear, name='psirt_clear'),
    path('psirt/api/applicability_summary/', psirt.psirt_applicability_summary, name='psirt_applicability_summary'),
    path('psirt/api/device_advisories/', psirt.psirt_device_advisories, name='psirt_device_advisories'),
    path('psirt/api/diagnose/', psirt.psirt_diagnose, name='psirt_diagnose'),
    path('psirt/api/trigger_scan/', psirt.psirt_trigger_scan, name='psirt_trigger_scan'),
    path('psirt/api/status/', psirt.psirt_status, name='psirt_status'),
    path('psirt/api/assess/', psirt.psirt_assess, name='psirt_assess'),
    path('psirt/api/job/<str:job_id>/', psirt.psirt_job_status, name='psirt_job_status'),
    path('psirt/api/job/<str:job_id>/export/', psirt.psirt_job_export, name='psirt_job_export'),
    path('psirt/api/jobs/', psirt.psirt_jobs_list, name='psirt_jobs_list'),
    path('psirt/api/dnac/assess-all/', psirt.psirt_dnac_assess_all, name='psirt_dnac_assess_all'),
    path('psirt/api/dnac/test/', psirt.psirt_dnac_test, name='psirt_dnac_test'),
    path('psirt/api/dnac/devices/', psirt.psirt_dnac_devices, name='psirt_dnac_devices'),
    path('psirt/api/dnac/advisories/', psirt.psirt_dnac_advisories, name='psirt_dnac_advisories'),
    path('psirt/api/dnac/advisory/<str:advisory_id>/devices/', psirt.psirt_dnac_advisory_devices, name='psirt_dnac_advisory_devices'),
    path('psirt/api/generate_remediation/', psirt.psirt_generate_remediation, name='psirt_generate_remediation'),
]