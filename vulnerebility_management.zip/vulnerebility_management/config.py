import os
 
BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__)))

# ServiceNow Configs
SERVICENOW_INSTANCE_URL = "https://hclpocm1.service-now.com/"
SERVICENOW_BOT_USERNAME = "advisory_bot@hcltech.com"
SERVICENOW_BOT_PASSWORD = "May@2025"  # Replace with your ServiceNow bot password
SERVICENOW_USER_USERNAME = "demo_engg1@hcltech.com"
SERVICENOW_USER_PASSWORD = "May@2025"  # Replace with your ServiceNow user password

# LLM Configs
# OPENAI_API_URL = "https://openrouter.ai/api/v1"
# OPENAI_API_KEY = "sk-proj-0ULENJUXNF764cBAJI32T3BlbkFJu4R9CICgVGhKVsEmTlf9"
# MODEL_NAME="openai/gpt-4o-2024-08-06"
# OPENROUTER_API_KEY="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"


# Embedding Config
EMBEDDING_MODEL = "openai/text-embedding-3-small"

# DNA CENTER Configuration
DNAC_HOST = "10.98.45.247"
DNAC_USERNAME = "HCLTech_GenAI_NetDev"
DNAC_PASSWORD = "Sotnetbot@25"

# Multiple DNA Center instances configuration
# Key is a logical DNAC identifier (e.g. "primary", "lab1").
# The default entry wraps the legacy single-DNAC settings above so existing
# code keeps working if no dnac_id is provided.
DNAC_INSTANCES = { "us": {
        "host": "10.121.88.167",
        "username": "HCLTech_GenAI_NetDev",
        "password": "TosPasNaut@2026Rts##gwl^QOP",
        "port": 443,
    },
    "noida": {
        "host": "10.98.45.247",
        "username": "HCLTech_GenAI_NetDev",
        "password": "TosPasNaut@2026Rts##gwl^QOP",
        "port": 443,
    },
    "vj": {
        "host": "10.153.2.49",
        "username": "HCLTech_GenAI_NetDev",
        "password": "TosPasNaut@2026Rts##gwl^QOP",
        "port": 443,
    },
}


AZURE_OPENAI_API_KEY="5kRpMIyDt06ImaRoayI76KuQuO9Cdt9s32YEh7lCZ9BK5sEIqZDbJQQJ99CAAC77bzfXJ3w3AAABACOGLOOn"
# Cisco Vulnerabilty Api Configuration
API_CLIENT_ID = "hvdgxb6mv5s4vfcg6a7vx72j"
API_CLIENT_SECRET = "J49YspwGawU9vjtBapGprUE8"
API_GRANT_TYPE = "client_credentials"