"""
psirt_chatbot.py
────────────────
Drop this file into your rag_agent_project/ root and run:

    python psirt_chatbot.py

Port: 5050 (change PORT below if needed)
"""

import json
import logging
import os
import sys
import time
import threading
import datetime as _dt
from datetime import datetime

import urllib3
import requests
import httpx
from flask import Flask, jsonify, render_template_string, request, session, send_file

try:
    from netmiko import ConnectHandler, NetmikoTimeoutException, NetmikoAuthenticationException
    _NETMIKO_AVAILABLE = True
except ImportError:
    _NETMIKO_AVAILABLE = False

try:
    from langchain_openai import AzureChatOpenAI
    _LANGCHAIN_AVAILABLE = True
except ImportError:
    _LANGCHAIN_AVAILABLE = False

# ChromaDB for advisory profile caching
try:
    import chromadb
    _chroma_client = chromadb.PersistentClient(
        path=os.environ.get("CHROMA_DB_PATH", "./psirt_chroma_db"))
    _advisory_collection = _chroma_client.get_or_create_collection(
        name="advisory_profiles", metadata={"hnsw:space": "cosine"})
    CHROMA_AVAILABLE = True
except ImportError:
    CHROMA_AVAILABLE = False
    _advisory_collection = None

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# ── Make project root importable ─────────────────────────────────────────────
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
if BASE_DIR not in sys.path:
    sys.path.insert(0, BASE_DIR)

PARENT_DIR = os.path.dirname(BASE_DIR)
if PARENT_DIR not in sys.path:
    sys.path.insert(0, PARENT_DIR)

# ── Logging ───────────────────────────────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)
logger = logging.getLogger("psirt_chatbot")

# ── Config ────────────────────────────────────────────────────────────────────
PORT       = 5050
SECRET_KEY = os.environ.get("FLASK_SECRET_KEY", "psirt-chatbot-secret-2025")

# ── Flask app ─────────────────────────────────────────────────────────────────
app = Flask(__name__)
app.secret_key = SECRET_KEY

# ── Azure OpenAI (for advisory extraction + applicability analysis) ────────────
AZURE_OPENAI_API_KEY    = "5kRpMIyDt06ImaRoayI76KuQuO9Cdt9s32YEh7lCZ9BK5sEIqZDbJQQJ99CAAC77bzfXJ3w3AAABACOGLOOn"
AZURE_OPENAI_ENDPOINT   = "https://git-nw-openai-llm-prod.openai.azure.com/"
AZURE_OPENAI_DEPLOYMENT = "gpt-5.4"

_proxy_url = os.environ.get("https_proxy") or os.environ.get("HTTPS_PROXY", "")
if _proxy_url and not _proxy_url.startswith(("http://", "https://")):
    _proxy_url = "http://" + _proxy_url

_azure_http_client = httpx.Client(
    verify=False,
    proxy=_proxy_url if _proxy_url else None,
    timeout=httpx.Timeout(60.0, connect=15.0),
) if _LANGCHAIN_AVAILABLE else None

openai_client = AzureChatOpenAI(
    azure_deployment=AZURE_OPENAI_DEPLOYMENT,
    api_version="2025-04-01-preview",
    azure_endpoint=AZURE_OPENAI_ENDPOINT,
    http_client=_azure_http_client,
    temperature=0,
    api_key=AZURE_OPENAI_API_KEY,
    max_retries=3,
) if _LANGCHAIN_AVAILABLE else None

# ── requests session for Cisco portal fetches (goes through corporate proxy) ──
_no_proxy_session = requests.Session()
_no_proxy_session.verify = False
if _proxy_url:
    _no_proxy_session.proxies = {"http": _proxy_url, "https": _proxy_url}

# ── In-memory Cisco advisory text cache ───────────────────────────────────────
_cisco_advisory_cache: dict = {}   # advisory_id → full text

# ── In-memory job store (keyed by job_id) ─────────────────────────────────────
jobs: dict = {}

# ── Feature → verification commands ───────────────────────────────────────────
FEATURE_COMMANDS = {
    "snmp":           ["show running-config | include snmp-server community",
                       "show running-config | include snmp-server group",
                       "show snmp user", "show snmp community",
                       "show running-config | section snmp-server"],
    "secure boot":    ["show version", "show platform integrity",
                       "show software authenticity running",
                       "show platform sudi certificate", "show rom-monitor",
                       "show platform integrity sign nonce 12345"],
    "tls":            ["show running-config | include ip http",
                       "show running-config | include ip http secure-server",
                       "show running-config | section line vty",
                       "show running-config | include transport input",
                       "show running-config | include ssl",
                       "show ip http server status", "show ip http secure-status"],
    "ssl":            ["show running-config | include ip http",
                       "show ip http server status", "show ip http secure-status",
                       "show running-config | include ssl"],
    "privilege escalation": ["show running-config | include privilege",
                              "show running-config | section username",
                              "show running-config | include aaa",
                              "show privilege", "tclsh",
                              "show running-config | include tclsh"],
    "privesc":        ["show running-config | include privilege",
                       "show running-config | section username",
                       "show privilege", "tclsh",
                       "show running-config | include tclsh"],
    "bgp":            ["show running-config | include router bgp", "show bgp summary"],
    "ospf":           ["show running-config | include router ospf", "show ip ospf"],
    "ssh":            ["show running-config | include ip ssh", "show ip ssh"],
    "http":           ["show running-config | include ip http",
                       "show ip http server status", "show ip http secure-status"],
    "nat":            ["show running-config | include ip nat", "show ip nat translations"],
    "ipsec":          ["show running-config | include crypto map", "show crypto session"],
    "ikev2":          ["show running-config | include crypto ikev2",
                       "show crypto ikev2 sa",
                       "show running-config | section crypto ikev2"],
    "mpls":           ["show running-config | include mpls", "show mpls interfaces"],
    "ntp":            ["show running-config | include ntp server", "show ntp status"],
    "aaa":            ["show running-config | include aaa", "show aaa servers"],
    "tacacs":         ["show running-config | include tacacs",
                       "show running-config | section aaa", "show aaa servers"],
    "netconf":        ["show running-config | include netconf", "show netconf-yang sessions"],
    "restconf":       ["show running-config | include restconf"],
    "bootp":          ["show running-config | include ip bootp",
                       "show running-config | include no ip bootp server"],
    "nbar":           ["show running-config | include ip nbar",
                       "show running-config | section policy-map",
                       "show ip nbar protocol-discovery"],
    "default":        ["show version", "show running-config | include version"],
}

FEATURE_ALIASES = {
    "transport layer security": "tls", "secure sockets layer": "ssl",
    "privilege": "privilege escalation", "privilege escalation": "privilege escalation",
    "privesc": "privilege escalation", "cli": "privilege escalation",
    "command line interface": "privilege escalation", "command injection": "http",
    "web ui": "http", "web management": "http", "boot": "secure boot",
    "secure boot bypass": "secure boot", "rommon": "secure boot",
    "ikev2": "ikev2", "ike": "ikev2", "tacacs+": "tacacs", "tacacs": "tacacs",
    "bootp": "bootp", "nbar": "nbar",
}

ALWAYS_RUN = ["show version"]

DNAC_DEVICE_TYPE_MAP = {
    "Cisco Catalyst 9300 Series Switches":    "cisco_xe",
    "Cisco Catalyst 9200 Series Switches":    "cisco_xe",
    "Cisco Catalyst 9400 Series Switches":    "cisco_xe",
    "Cisco Catalyst 9500 Series Switches":    "cisco_xe",
    "Cisco Catalyst 9600 Series Switches":    "cisco_xe",
    "Cisco ASR 1000 Series Routers":          "cisco_xe",
    "Cisco ISR 4000 Series":                  "cisco_xe",
    "Cisco Nexus 9000 Series Switches":       "cisco_nxos",
    "Cisco Nexus 7000 Series Switches":       "cisco_nxos",
    "Cisco Nexus 5000 Series Switches":       "cisco_nxos",
    "Cisco ASR 9000 Series Aggregation Services Routers": "cisco_xr",
    "Cisco NCS 5500 Series":                  "cisco_xr",
}

# ── RAG agent (lazy-loaded once) ──────────────────────────────────────────────
_agent = None


def get_agent():
    global _agent
    if _agent is None:
        try:
            from rag_langchain_agent import RAGLangChainAgent
        except Exception:
            try:
                from rag_agent_project.rag_langchain_agent import RAGLangChainAgent
            except Exception as exc:
                logger.error("Could not import RAGLangChainAgent: %s", exc)
                return None
        try:
            _agent = RAGLangChainAgent(auto_load_data=True)
            logger.info("RAGLangChainAgent loaded successfully.")
        except Exception as exc:
            logger.error("RAGLangChainAgent init failed: %s", exc)
    return _agent


# ── PSIRT DB helpers ──────────────────────────────────────────────────────────

def _get_applicability_summary(dnac_id=None):
    try:
        from psirt.db_queries import get_summary_counts, get_applicable_advisories_for_dnac
        counts     = get_summary_counts(dnac_id=dnac_id)
        applicable = get_applicable_advisories_for_dnac(
            dnac_id=dnac_id, verdicts=["APPLICABLE", "NEEDS_REVIEW"])
        return {"counts": counts, "applicable": applicable}
    except Exception as exc:
        logger.debug("Applicability summary unavailable: %s", exc)
        return None


def _get_device_advisories(device_id, dnac_id=None):
    try:
        from psirt.db_queries import get_applicable_advisories_for_device
        return get_applicable_advisories_for_device(device_id, dnac_id)
    except Exception:
        return []


def _psirt_available():
    try:
        import psirt.db_queries  # noqa
        return True
    except Exception:
        return False


# ── Session helpers ───────────────────────────────────────────────────────────

def _session_history():
    if "history" not in session:
        session["history"] = []
    return session["history"]


def _append_history(role, content):
    hist = _session_history()
    hist.append({"role": role, "content": content,
                 "ts": datetime.utcnow().isoformat()})
    session["history"] = hist[-40:]


# ── Routes ────────────────────────────────────────────────────────────────────

@app.route("/")
def index():
    return render_template_string(HTML_TEMPLATE)


@app.route("/api/chat", methods=["POST"])
def chat():
    data     = request.get_json(force=True)
    user_msg = (data.get("message") or "").strip()
    if not user_msg:
        return jsonify({"error": "Empty message"}), 400

    _append_history("user", user_msg)
    agent = get_agent()
    if agent is None:
        reply = "⚠️ Agent could not be initialised. Check server logs."
    else:
        try:
            reply = agent.ask(user_msg)
        except Exception as exc:
            logger.error("Agent error: %s", exc, exc_info=True)
            reply = f"⚠️ Error processing your request: {exc}"

    _append_history("assistant", reply)
    return jsonify({"reply": reply})


@app.route("/api/history")
def history():
    return jsonify(_session_history())


@app.route("/api/clear", methods=["POST"])
def clear():
    session.pop("history", None)
    return jsonify({"status": "cleared"})


@app.route("/api/applicability_summary")
def applicability_summary():
    dnac_id = request.args.get("dnac_id") or None
    summary = _get_applicability_summary(dnac_id)
    if summary is None:
        return jsonify({"error": "PSIRT module unavailable"}), 503
    return jsonify(summary)


@app.route("/api/device_advisories")
def device_advisories():
    device_id = request.args.get("device_id", "").strip()
    dnac_id   = request.args.get("dnac_id") or None
    if not device_id:
        return jsonify({"error": "device_id required"}), 400
    rows = _get_device_advisories(device_id, dnac_id)
    return jsonify({"device_id": device_id, "dnac_id": dnac_id, "advisories": rows})


@app.route("/api/diagnose")
def diagnose():
    """
    Full breakdown of all assessed advisory-device pairs.
    Includes needs_review_reason so the UI can show distinct icons per cause.
    """
    dnac_id = request.args.get("dnac_id") or None
    try:
        from psirt.db_queries import get_verdict_breakdown, get_needs_review_detail
        breakdown = get_verdict_breakdown(dnac_id=dnac_id)
        nr_detail = get_needs_review_detail(dnac_id=dnac_id)

        # Collection method distribution
        methods = {}
        for r in breakdown:
            m = r.get("collection_method") or "unknown"
            methods[m] = methods.get(m, 0) + 1

        # needs_review_reason distribution — new field from updated app.py
        nr_reasons = {}
        for r in breakdown:
            if r.get("verdict") == "NEEDS_REVIEW":
                reason = r.get("needs_review_reason") or "unknown"
                nr_reasons[reason] = nr_reasons.get(reason, 0) + 1

        return jsonify({
            "dnac_id":              dnac_id,
            "total_checked":        len(breakdown),
            "collection_methods":   methods,
            "needs_review_count":   len(nr_detail),
            "needs_review_reasons": nr_reasons,   # NEW — surfaced to UI
            "needs_review_detail":  nr_detail,
            "breakdown":            breakdown,
        })
    except Exception as exc:
        return jsonify({"error": str(exc)}), 500


@app.route("/api/trigger_scan", methods=["POST"])
def trigger_scan():
    data         = request.get_json(force=True) or {}
    dnac_id      = data.get("dnac_id")      or None
    ssh_username = data.get("ssh_username") or ""
    ssh_password = data.get("ssh_password") or ""
    ssh_port     = int(data.get("ssh_port") or 22)

    try:
        from run_scan import run_scan as _run_scan
        result      = _run_scan(dnac_id=dnac_id, wait=False,
                                ssh_username=ssh_username,
                                ssh_password=ssh_password,
                                ssh_port=ssh_port)
        status_code = 200 if result["status"] == "ok" else 500
        return jsonify(result), status_code
    except Exception as exc:
        logger.error("trigger_scan error: %s", exc, exc_info=True)
        return jsonify({"status": "error", "error": str(exc)}), 500


@app.route("/api/status")
def status():
    agent = get_agent()
    return jsonify({
        "agent_ready":  agent is not None,
        "psirt_module": _psirt_available(),
        "timestamp":    datetime.utcnow().isoformat(),
    })


# ═══════════════════════════════════════════════════════════════════════════════
# ── ChromaDB advisory profile cache helpers ───────────────────────────────────
# ═══════════════════════════════════════════════════════════════════════════════

def get_advisory_profile_from_cache(advisory_id: str):
    if not CHROMA_AVAILABLE or not advisory_id:
        return None
    try:
        results = _advisory_collection.get(ids=[advisory_id], include=["metadatas"])
        if results and results["ids"]:
            raw = results["metadatas"][0].get("profile_json", "")
            if raw:
                return json.loads(raw)
    except Exception:
        pass
    return None


def save_advisory_profile_to_cache(advisory_id: str, profile: dict) -> None:
    if not CHROMA_AVAILABLE or not advisory_id or not profile:
        return
    try:
        summary_doc = (
            f"Advisory: {advisory_id} | CVE: {profile.get('cve', 'N/A')} | "
            f"Feature: {profile.get('vulnerable_feature', 'N/A')} | "
            f"Platforms: {', '.join(profile.get('affected_platforms', []))}"
        )
        _advisory_collection.upsert(
            ids=[advisory_id],
            documents=[summary_doc],
            metadatas=[{
                "advisory_id":  advisory_id,
                "cve":          profile.get("cve", ""),
                "feature":      profile.get("vulnerable_feature", ""),
                "profile_json": json.dumps(profile),
            }]
        )
    except Exception:
        pass


# ── Fetch full Cisco advisory text ────────────────────────────────────────────

def fetch_cisco_advisory_text(advisory_id: str) -> str:
    if advisory_id in _cisco_advisory_cache:
        return _cisco_advisory_cache[advisory_id]

    import re
    json_url = f"https://sec.cloudapps.cisco.com/security/center/content/CiscoSecurityAdvisory/{advisory_id}/json"
    html_url = f"https://sec.cloudapps.cisco.com/security/center/content/CiscoSecurityAdvisory/{advisory_id}"
    headers  = {"User-Agent": "Mozilla/5.0"}

    def _get(url, **kw):
        return _no_proxy_session.get(url, **kw)

    try:
        resp = _get(json_url, timeout=15, headers=headers)
        if resp.status_code == 200:
            data  = resp.json()
            parts = []
            for field in ("summary", "affectedProducts", "vulnerableProducts",
                          "indicatorsOfCompromise", "workarounds",
                          "fixedSoftware", "softwareVersions"):
                val = data.get(field, "")
                if val:
                    clean = re.sub(r"<[^>]+>", " ", str(val))
                    clean = re.sub(r"[ \t]{2,}", " ", clean).strip()
                    parts.append(f"=== {field} ===\n{clean}")
            text = "\n\n".join(parts)
            if text:
                _cisco_advisory_cache[advisory_id] = text
                return text
    except Exception:
        pass

    try:
        resp = _get(html_url, timeout=15, headers=headers)
        resp.raise_for_status()
        html = resp.text
        target_sections = [
            "Summary", "Affected Products", "Vulnerable Products",
            "Products Confirmed Not Vulnerable", "Indicators of Compromise",
            "Workarounds", "Fixed Software", "Software Versions"
        ]
        section_pattern = re.compile(
            r'<(?:h[123]|div[^>]*)[^>]*>\s*(' +
            '|'.join(re.escape(s) for s in target_sections) +
            r')\s*</(?:h[123]|div)>(.*?)(?=<(?:h[123]|div[^>]*)[^>]*>\s*(?:' +
            '|'.join(re.escape(s) for s in target_sections) +
            r')|$)',
            re.IGNORECASE | re.DOTALL
        )
        parts = []
        for m in section_pattern.finditer(html):
            heading = m.group(1).strip()
            clean   = re.sub(r"<[^>]+>", " ", m.group(2))
            clean   = re.sub(r"[ \t]{2,}", " ", clean)
            clean   = re.sub(r"\n{3,}", "\n\n", clean).strip()
            if clean:
                parts.append(f"=== {heading} ===\n{clean}")
        text = "\n\n".join(parts) if parts else re.sub(r"<[^>]+>", " ", html)[:30000]
        _cisco_advisory_cache[advisory_id] = text
        return text
    except Exception:
        _cisco_advisory_cache[advisory_id] = ""
        return ""


# ── Extract advisory profile via GPT ─────────────────────────────────────────

def extract_advisory_profile(advisory_text: str, advisory_id: str = "") -> dict:
    if advisory_id:
        cached = get_advisory_profile_from_cache(advisory_id)
        if cached and (cached.get("affected_versions") or cached.get("fixed_releases")):
            return cached

    if not openai_client:
        raise RuntimeError("AzureChatOpenAI not available")

    prompt = f"""Extract structured info from this Cisco PSIRT advisory. Return ONLY valid JSON.

ADVISORY:
{advisory_text}

Return JSON:
{{
  "advisory_id": "...",
  "cve": "CVE-XXXX-XXXXX",
  "title": "...",
  "vulnerable_feature": "main feature name in lowercase (e.g. snmp, bgp, ssh, secure boot)",
  "affected_platforms": ["list of platform families, e.g. IOS XE, IOS, NX-OS"],
  "affected_versions": ["e.g. '17.9.x before 17.9.5', '16.12.x before 16.12.10'"],
  "fixed_releases": {{"train": "first_fixed_version"}},
  "fixed_in": "earliest recommended fixed release",
  "impact": "brief impact description",
  "workaround": "workaround if any, else null",
  "verification_commands": ["exact IOS/IOS-XE show commands from the advisory"]
}}

CRITICAL:
- For affected_versions: parse every row in the Fixed Software table.
- For verification_commands: extract ONLY CLI commands (show, debug, etc). No prose.
- Never return empty affected_versions if a Fixed Software section exists."""

    last_exc = None
    for attempt in range(3):
        try:
            resp = openai_client.invoke([{"role": "user", "content": prompt}])
            raw  = resp.content.replace("```json", "").replace("```", "").strip()
            profile = json.loads(raw)
            break
        except Exception as e:
            last_exc = e
            time.sleep(2 ** attempt)
    else:
        raise last_exc

    cache_key = advisory_id or profile.get("advisory_id", "")
    if cache_key:
        save_advisory_profile_to_cache(cache_key, profile)
    return profile


# ── 3-layer applicability analysis ────────────────────────────────────────────

def analyse_applicability(advisory_profile: dict, device: dict, command_outputs: dict) -> dict:
    if not openai_client:
        raise RuntimeError("AzureChatOpenAI not available")

    outputs_text = "\n".join(f"$ {cmd}\n{out}" for cmd, out in command_outputs.items())

    prompt = f"""You are a Cisco PSIRT applicability engine. Run a 3-layer check. Return ONLY valid JSON.

ADVISORY PROFILE:
{json.dumps(advisory_profile, indent=2)}

DEVICE:
Hostname: {device.get('hostname', device.get('host'))}
Platform/Model: {device.get('platform', 'Unknown')}
Software Version: {device.get('version', 'Unknown')}

COMMAND OUTPUTS:
{outputs_text}

Return JSON:
{{
  "verdict": "APPLICABLE" | "NOT_APPLICABLE" | "NEEDS_REVIEW",
  "layer1": {{"result": "PASS"|"FAIL"|"UNKNOWN", "detail": "..."}},
  "layer2": {{"result": "PASS"|"FAIL"|"UNKNOWN", "detail": "..."}},
  "layer3": {{"result": "PASS"|"FAIL"|"UNKNOWN", "detail": "..."}},
  "summary": "2-3 sentence explanation",
  "action": "recommended next step for operator",
  "evidence": "key facts from output that led to verdict"
}}

Rules:
- PASS = device IS in affected scope; FAIL = NOT in scope
- APPLICABLE = all 3 PASS; NOT_APPLICABLE = any layer clearly FAIL
- NEEDS_REVIEW = genuinely insufficient data only

CRITICAL Layer 2: If fixed_releases empty/null → all versions vulnerable → Layer 2 PASS.
If populated: device >= first_fixed → NOT_APPLICABLE; device < first_fixed → PASS.
Train not in fixed_releases → NOT_APPLICABLE.

CRITICAL Layer 3: privilege escalation/cli features always PASS on IOS XE.
For secure boot: PASS if show platform integrity has Boot Loader Hash.
For tls: PASS if HTTPS server enabled."""

    last_exc = None
    for attempt in range(3):
        try:
            resp = openai_client.invoke([{"role": "user", "content": prompt}])
            raw  = resp.content.replace("```json", "").replace("```", "").strip()
            return json.loads(raw)
        except Exception as e:
            last_exc = e
            time.sleep(2 ** attempt)
    raise last_exc


# ── Version-only verdict (when command collection fails) ──────────────────────

def _version_only_verdict(profile: dict, device_version: str, platform: str) -> str:
    import re

    def parse_ver(v):
        v = re.sub(r'[a-zA-Z]', '', v or "")
        parts = re.split(r'[.\-]', v)
        result = []
        for p in parts:
            try:
                result.append(int(p))
            except ValueError:
                pass
        return tuple(result)

    def ver_train(v):
        m = re.match(r'(\d+\.\d+)', v or "")
        return m.group(1) if m else ""

    if not device_version or device_version.strip().lower() in ("unknown", "n/a", ""):
        device_version = ""
    if not platform or platform.strip().lower() in ("unknown", "n/a", ""):
        platform = ""

    affected_platforms = [p.lower() for p in (profile.get("affected_platforms") or [])]
    if affected_platforms and platform:
        plat_lower = platform.lower()
        IOS_XE_PREFIXES = ("c9", "c8", "c38", "c36", "c35", "c45", "c65",
                           "asr1", "isr4", "csr1", "cat9", "cat8", "ws-c")
        IOS_PREFIXES    = ("c29", "c37", "c26", "c28", "c18", "c19", "ws-c29", "ws-c37")
        NXOS_PREFIXES   = ("n9k", "n7k", "n5k", "n3k", "n2k", "nexus")
        plat_clean = plat_lower.replace(" ", "").replace(",", "")
        device_os = None
        if any(plat_clean.startswith(px) for px in IOS_XE_PREFIXES):
            device_os = "ios xe"
        elif any(plat_clean.startswith(px) for px in IOS_PREFIXES):
            device_os = "ios"
        elif any(plat_clean.startswith(px) for px in NXOS_PREFIXES):
            device_os = "nx-os"
        l1_pass = (
            any(ap in plat_lower or plat_lower in ap for ap in affected_platforms)
            or (device_os and any(device_os in ap or ap in device_os for ap in affected_platforms))
        )
        if not l1_pass:
            return "NOT_APPLICABLE"

    fixed_releases = profile.get("fixed_releases") or {}
    if not fixed_releases:
        if not device_version and not platform:
            return "NEEDS_REVIEW"
        return "APPLICABLE"
    if not device_version:
        return "NEEDS_REVIEW"

    device_train = ver_train(device_version)
    if not device_train:
        return "NEEDS_REVIEW"

    matched_first_fixed = None
    for train_key, first_fixed in fixed_releases.items():
        if ver_train(train_key.replace(".x", "")) == device_train:
            matched_first_fixed = first_fixed
            break

    if matched_first_fixed is None:
        return "NOT_APPLICABLE"

    dev_parsed   = parse_ver(device_version)
    fixed_parsed = parse_ver(matched_first_fixed)
    if not dev_parsed or not fixed_parsed:
        return "NEEDS_REVIEW"
    return "NOT_APPLICABLE" if dev_parsed >= fixed_parsed else "APPLICABLE"


# ── DNAC Command Runner ───────────────────────────────────────────────────────

def dnac_run_commands(host: str, token: str, device_uuid: str,
                      commands: list, verify_ssl: bool,
                      poll_interval: int = 3, max_wait: int = 120) -> dict:
    headers = {"X-Auth-Token": token, "Content-Type": "application/json"}
    payload = {"commands": commands, "deviceUuids": [device_uuid]}
    url = f"https://{host}/dna/intent/api/v1/network-device-poller/cli/read-request"
    resp = requests.post(url, headers=headers, json=payload, verify=verify_ssl, timeout=30)
    resp.raise_for_status()

    task_id = resp.json().get("response", {}).get("taskId")
    if not task_id:
        raise RuntimeError("DNAC Command Runner did not return a taskId")

    task_url = f"https://{host}/dna/intent/api/v1/task/{task_id}"
    elapsed  = 0
    file_id  = None
    while elapsed < max_wait:
        time.sleep(poll_interval)
        elapsed += poll_interval
        t = requests.get(task_url, headers=headers, verify=verify_ssl, timeout=15).json()
        task_data = t.get("response", {})
        if task_data.get("isError"):
            raise RuntimeError(f"Command Runner task error: {task_data.get('failureReason', task_data.get('progress', 'unknown'))}")
        progress  = task_data.get("progress", "")
        completed = bool(task_data.get("endTime"))
        if not completed:
            try:
                prog_json = json.loads(progress)
                if prog_json.get("fileId"):
                    completed = True
            except Exception:
                pass
        if completed:
            try:
                file_id = json.loads(progress).get("fileId")
            except Exception:
                file_id = progress.strip() if progress.strip() else None
            break

    if not file_id:
        raise RuntimeError("Command Runner task did not complete in time")

    file_resp = requests.get(
        f"https://{host}/dna/intent/api/v1/file/{file_id}",
        headers=headers, verify=verify_ssl, timeout=30)
    file_resp.raise_for_status()

    outputs = {}
    for entry in file_resp.json():
        for status_key in ("SUCCESS", "FAILURE", "success", "failure"):
            for cmd, out in entry.get("commandResponses", {}).get(status_key, {}).items():
                outputs[cmd] = out
    return outputs


_DNAC_JS_ERROR_MARKER   = "Failed to execute JavaScript"
_DNAC_AUTH_ERROR_MARKER = "Authentication failed during the login attempt"


def dnac_collect(dnac_host: str, token: str, device_uuid: str,
                 commands: list, verify_ssl: bool) -> dict:
    try:
        outputs = dnac_run_commands(dnac_host, token, device_uuid, commands, verify_ssl)
        for marker, label in [
            (_DNAC_JS_ERROR_MARKER,   "DNAC JS template error ($finaMap)"),
            (_DNAC_AUTH_ERROR_MARKER, "DNAC authentication error on device"),
        ]:
            failed = [cmd for cmd, out in outputs.items() if marker in str(out)]
            if failed and len(failed) == len(outputs):
                return {"status": "error",
                        "error": f"{label} — SSH fallback needed. Sample: {outputs[failed[0]][:200]}"}
            for cmd in failed:
                outputs.pop(cmd)
        return {"status": "success", "outputs": outputs}
    except requests.exceptions.HTTPError as e:
        code = e.response.status_code if e.response is not None else 0
        if code == 403:
            return {"status": "error",
                    "error": "DNAC Command Runner returned 403 — check Network Automation license"}
        return {"status": "error", "error": f"DNAC HTTP {code}: {e}"}
    except Exception as e:
        return {"status": "error", "error": str(e)}


# ── SSH fallback ──────────────────────────────────────────────────────────────

def ssh_collect(ssh_cfg: dict, commands: list) -> dict:
    if not _NETMIKO_AVAILABLE:
        return {"status": "error", "error": "netmiko not installed"}
    try:
        conn    = ConnectHandler(**ssh_cfg)
        outputs = {}
        for cmd in commands:
            try:
                outputs[cmd] = conn.send_command(cmd, read_timeout=30)
            except Exception as e:
                outputs[cmd] = f"[ERROR running command: {e}]"
        conn.disconnect()
        return {"status": "success", "outputs": outputs}
    except NetmikoAuthenticationException:
        return {"status": "error", "error": "SSH authentication failed — check credentials"}
    except NetmikoTimeoutException:
        return {"status": "error", "error": "SSH timed out — check host/port/reachability"}
    except Exception as e:
        return {"status": "error", "error": str(e)}


# ── DNAC API helpers ──────────────────────────────────────────────────────────

def _dnac_device_type(family: str, series: str) -> str:
    for key, dtype in DNAC_DEVICE_TYPE_MAP.items():
        if key.lower() in (series or "").lower() or key.lower() in (family or "").lower():
            return dtype
    combined = f"{family} {series}".lower()
    if "nxos" in combined or "nexus" in combined:
        return "cisco_nxos"
    if "xr" in combined or "asr 9" in combined or "ncs" in combined:
        return "cisco_xr"
    return "cisco_xe"


def dnac_get_token(host: str, username: str, password: str, verify_ssl: bool) -> str:
    resp = requests.post(
        f"https://{host}/dna/system/api/v1/auth/token",
        auth=(username, password), verify=verify_ssl, timeout=15)
    resp.raise_for_status()
    return resp.json()["Token"]


def dnac_get_devices(host: str, token: str, verify_ssl: bool) -> list:
    headers = {"X-Auth-Token": token, "Content-Type": "application/json"}
    devices, offset, limit = [], 1, 500
    while True:
        resp = requests.get(
            f"https://{host}/dna/intent/api/v1/network-device?offset={offset}&limit={limit}",
            headers=headers, verify=verify_ssl, timeout=30)
        resp.raise_for_status()
        page = resp.json().get("response", [])
        if not page:
            break
        devices.extend(page)
        if len(page) < limit:
            break
        offset += limit
    return devices


def dnac_get_advisories(host: str, token: str, verify_ssl: bool) -> list:
    headers = {"X-Auth-Token": token, "Content-Type": "application/json"}
    resp = requests.get(
        f"https://{host}/dna/intent/api/v1/security-advisory/advisory",
        headers=headers, verify=verify_ssl, timeout=30)
    resp.raise_for_status()
    return resp.json().get("response", [])


def dnac_get_device_by_id(host: str, token: str, device_id: str, verify_ssl: bool) -> dict:
    headers = {"X-Auth-Token": token, "Content-Type": "application/json"}
    resp = requests.get(
        f"https://{host}/dna/intent/api/v1/network-device/{device_id}",
        headers=headers, verify=verify_ssl, timeout=15)
    resp.raise_for_status()
    return resp.json().get("response", {})


def dnac_get_advisory_affected_devices(host: str, token: str, advisory_id: str, verify_ssl: bool) -> list:
    headers = {"X-Auth-Token": token, "Content-Type": "application/json"}
    resp = requests.get(
        f"https://{host}/dna/intent/api/v1/security-advisory/advisory/{advisory_id}/device",
        headers=headers, verify=verify_ssl, timeout=30)
    resp.raise_for_status()
    return resp.json().get("response", [])


# ── DB persistence helper (shared by both job runners) ────────────────────────

def _db_persist_result(
    advisory_id: str,
    device_id: str,
    dnac_id,
    result: dict,
) -> None:
    """
    Silently write a UI-assessment verdict into the advisory_applicability
    PostgreSQL table so the Scan DB tab can display it.
    Errors are caught and logged at DEBUG level so they never break the job.
    """
    if not advisory_id or not device_id:
        return
    try:
        from psirt.db_queries import update_applicability_result, upsert_applicability_pending
    except Exception:
        return  # psirt module not available — skip silently

    def _layer_str(val) -> str:
        if isinstance(val, dict):
            return val.get("result", "")
        return str(val) if val else ""

    try:
        upsert_applicability_pending(
            advisory_id       = advisory_id,
            device_id         = device_id,
            hostname          = result.get("hostname", ""),
            management_ip     = result.get("host", ""),
            platform          = result.get("platform", ""),
            software_version  = result.get("version") or result.get("dnac_version", ""),
            dnac_id           = dnac_id,
            scan_triggered_at = result.get("timestamp", datetime.utcnow().isoformat()),
        )
        update_applicability_result(
            advisory_id        = advisory_id,
            device_id          = device_id,
            dnac_id            = dnac_id,
            verdict            = result.get("verdict", "NEEDS_REVIEW"),
            summary            = result.get("summary", ""),
            evidence           = result.get("evidence", ""),
            layer1             = _layer_str(result.get("layer1", "")),
            layer2             = _layer_str(result.get("layer2", "")),
            layer3             = _layer_str(result.get("layer3", "")),
            layer4             = _layer_str(result.get("layer4", "")),
            collection_method  = result.get("collection_method", ""),
            action             = result.get("action", ""),
            mitigation         = result.get("mitigation"),
            needs_review_reason= result.get("needs_review_reason", ""),
        )
        logger.debug("[DB] Persisted %s × %s → %s", advisory_id, device_id, result.get("verdict"))
    except Exception as exc:
        logger.debug("[DB] Persist failed for %s × %s: %s", advisory_id, device_id, exc)


# ── Single-advisory job runner ────────────────────────────────────────────────

def run_job(job_id: str, advisory_text: str, devices: list):
    job = jobs[job_id]
    job["status"]     = "running"
    job["started_at"] = datetime.utcnow().isoformat()

    try:
        job["log"].append("Extracting advisory profile…")
        profile = extract_advisory_profile(advisory_text, advisory_id="")
        job["advisory_profile"] = profile
        job["log"].append(f"Advisory parsed: {profile.get('cve')} — feature: {profile.get('vulnerable_feature')}")
    except Exception as e:
        job["status"] = "failed"
        job["error"]  = f"Failed to parse advisory: {e}"
        return

    advisory_cmds = profile.get("verification_commands") or []
    feature_key   = (profile.get("vulnerable_feature") or "").lower()
    commands = list(set(ALWAYS_RUN + advisory_cmds)) if advisory_cmds else list(set(
        ALWAYS_RUN + FEATURE_COMMANDS.get(feature_key, FEATURE_COMMANDS["default"])))
    job["log"].append(f"Will run {len(commands)} commands per device.")

    results = []
    for i, device in enumerate(devices):
        hostname = device.get("hostname") or device.get("host")
        job["log"].append(f"[{i+1}/{len(devices)}] Collecting from {hostname}…")

        device_result = {
            "hostname":  hostname,
            "host":      device.get("host"),
            "platform":  device.get("platform", "Unknown"),
            "version":   device.get("version", "Unknown"),
            "timestamp": datetime.utcnow().isoformat(),
        }

        dnac_id   = device.get("dnac_id", "")
        dnac_host = device.get("dnac_host", "")
        dnac_user = device.get("dnac_username", "")
        dnac_pass = device.get("dnac_password", "")
        verify_ssl = device.get("dnac_verify_ssl", False)

        if dnac_id and dnac_host and dnac_user and dnac_pass:
            try:
                token  = dnac_get_token(dnac_host, dnac_user, dnac_pass, verify_ssl)
                result = dnac_collect(dnac_host, token, dnac_id, commands, verify_ssl)
            except Exception as e:
                result = {"status": "error", "error": str(e)}
            method = "dnac_command_runner"
        else:
            ssh_cfg = {
                "host":         device["host"],
                "port":         int(device.get("port", 22)),
                "username":     device.get("username", ""),
                "password":     device.get("password", ""),
                "device_type":  device.get("device_type", "cisco_ios"),
                "timeout":      30,
                "auth_timeout": 20,
            }
            result = ssh_collect(ssh_cfg, commands)
            method = "ssh"

        device_result["collection_method"] = method
        if result["status"] == "error":
            device_result["verdict"] = "NEEDS_REVIEW"
            device_result["summary"] = f"Collection failed ({method}): {result['error']}"
            device_result["needs_review_reason"] = "collection_failed"
            job["log"].append(f"  ✗ {result['error']}")
        else:
            device_result["command_outputs"] = result["outputs"]
            job["log"].append(f"  ✓ Collected — analysing…")
            try:
                analysis = analyse_applicability(profile, device, result["outputs"])
                device_result.update(analysis)
                job["log"].append(f"  → Verdict: {analysis.get('verdict')}")
            except Exception as e:
                device_result["verdict"] = "NEEDS_REVIEW"
                device_result["summary"] = f"Analysis failed: {e}"
                device_result["needs_review_reason"] = "insufficient_data"

        # ── Persist to PostgreSQL so Scan DB tab can show this result ──────────
        _adv_id  = profile.get("advisory_id") or profile.get("cve") or ""
        _dev_id  = device.get("dnac_id") or device.get("host", hostname)
        _dnac_id = device.get("dnac_host") or None   # no config key in manual jobs
        _db_persist_result(_adv_id, _dev_id, _dnac_id, device_result)

        results.append(device_result)
        job["results"]  = results
        job["progress"] = round((i + 1) / len(devices) * 100)

    counts = {"APPLICABLE": 0, "NOT_APPLICABLE": 0, "NEEDS_REVIEW": 0}
    for r in results:
        counts[r.get("verdict", "NEEDS_REVIEW")] = counts.get(r.get("verdict", "NEEDS_REVIEW"), 0) + 1
    job["status"]       = "done"
    job["finished_at"]  = datetime.utcnow().isoformat()
    job["summary_counts"] = counts


# ── Bulk DNAC job runner ──────────────────────────────────────────────────────

def run_dnac_bulk_job(job_id: str, dnac_host: str, dnac_user: str, dnac_pass: str,
                      verify_ssl: bool, advisory_ids_filter=None,
                      ssh_username: str = "", ssh_password: str = ""):
    job = jobs[job_id]
    job["status"]     = "running"
    job["started_at"] = datetime.utcnow().isoformat()
    try:
        _run_dnac_bulk_job_inner(job, job_id, dnac_host, dnac_user, dnac_pass,
                                 verify_ssl, advisory_ids_filter, ssh_username, ssh_password)
    except Exception as e:
        job["status"] = "failed"
        job["error"]  = f"Unexpected error: {e}"
        job["log"].append(f"✗ Job crashed: {e}")


def _run_dnac_bulk_job_inner(job, job_id, dnac_host, dnac_user, dnac_pass,
                              verify_ssl, advisory_ids_filter,
                              ssh_username="", ssh_password=""):
    try:
        job["log"].append("Authenticating to DNAC…")
        token = dnac_get_token(dnac_host, dnac_user, dnac_pass, verify_ssl)
        token_issued_at = time.time()
        job["log"].append("DNAC authentication successful.")
    except Exception as e:
        job["status"] = "failed"
        job["error"]  = f"DNAC auth failed: {e}"
        return

    def fresh_token():
        nonlocal token, token_issued_at
        if time.time() - token_issued_at > 1500:
            try:
                token = dnac_get_token(dnac_host, dnac_user, dnac_pass, verify_ssl)
                token_issued_at = time.time()
                job["log"].append("  ↻ DNAC token refreshed.")
            except Exception as _te:
                job["log"].append(f"  ⚠ Token refresh failed: {_te}")
        return token

    try:
        job["log"].append("Fetching advisories from DNAC…")
        raw_advisories = dnac_get_advisories(dnac_host, token, verify_ssl)
        job["log"].append(f"Found {len(raw_advisories)} advisories in DNAC.")
    except Exception as e:
        job["status"] = "failed"
        job["error"]  = f"Failed to fetch advisories: {e}"
        return

    pairs = []
    for adv in raw_advisories:
        advisory_id = adv.get("advisoryId", "")
        if not advisory_id:
            continue
        if advisory_ids_filter and advisory_id not in advisory_ids_filter:
            continue
        try:
            affected = dnac_get_advisory_affected_devices(dnac_host, token, advisory_id, verify_ssl)
            if affected:
                job["log"].append(f"Advisory {advisory_id}: {len(affected)} impacted device(s).")
                for dev in affected:
                    if isinstance(dev, str):
                        uuid = dev
                        dev  = None
                        try:
                            dev = dnac_get_device_by_id(dnac_host, token, uuid, verify_ssl)
                        except requests.exceptions.HTTPError as _he:
                            if _he.response is not None and _he.response.status_code not in (403, 404):
                                job["log"].append(f"  ⚠ UUID {uuid}: HTTP error {_he}")
                        except Exception as _e:
                            job["log"].append(f"  ⚠ UUID {uuid}: lookup failed ({_e})")

                        if not dev:
                            try:
                                _h = {"X-Auth-Token": token, "Content-Type": "application/json"}
                                _r = requests.get(
                                    f"https://{dnac_host}/dna/intent/api/v1/security-devices/{uuid}",
                                    headers=_h, verify=verify_ssl, timeout=15)
                                if _r.status_code == 200:
                                    dev = _r.json().get("response", {})
                                    if dev:
                                        dev["family"] = dev.get("deviceType", "ASA/FTD")
                            except Exception:
                                pass

                        if not dev:
                            dev = {"id": uuid, "hostname": uuid, "managementIpAddress": "",
                                   "softwareVersion": "", "platformId": "", "_uuid_only": True}
                        elif not dev.get("managementIpAddress") and not dev.get("platformId"):
                            dev["_uuid_only"] = True

                    if ssh_username and "username" not in dev:
                        dev = dict(dev)
                        dev["username"] = ssh_username
                        dev["password"] = ssh_password
                    pairs.append((adv, dev))
            else:
                job["log"].append(f"Advisory {advisory_id}: 0 impacted devices — skipping.")
        except Exception as e:
            job["log"].append(f"Advisory {advisory_id}: could not fetch devices ({e}) — skipping.")

    if not pairs:
        job["status"] = "done"
        job["log"].append("No advisory-device pairs found in DNAC.")
        job["summary_counts"] = {"APPLICABLE": 0, "NOT_APPLICABLE": 0, "NEEDS_REVIEW": 0}
        return

    job["log"].append(f"Total pairs to assess: {len(pairs)}")
    job["total_pairs"] = len(pairs)

    _uuid_type_cache: dict = {}
    for adv_meta, dev_meta in pairs:
        _uuid = dev_meta.get("id", "")
        if not _uuid or _uuid in _uuid_type_cache:
            continue
        _aid = adv_meta.get("advisoryId", "").lower()
        if "asa" in _aid or "ftd" in _aid:
            _uuid_type_cache[_uuid] = "asa_ftd"
        elif dev_meta.get("family") or dev_meta.get("platformId"):
            _uuid_type_cache[_uuid] = "ios"

    results = []
    for i, (adv, dev) in enumerate(pairs):
        advisory_id = adv.get("advisoryId", "")
        hostname    = dev.get("hostname") or dev.get("managementIpAddress", "unknown")
        device_uuid = dev.get("id", "")
        token       = fresh_token()

        job["log"].append(f"[{i+1}/{len(pairs)}] {advisory_id} × {hostname}…")
        job["progress"] = round((i + 1) / len(pairs) * 100)

        pair_result = {
            "advisory_id":      advisory_id,
            "cves":             adv.get("cves", []),
            "sir":              adv.get("sir", ""),
            "cvss":             adv.get("cvssBaseScore", ""),
            "publication_url":  adv.get("publicationUrl", ""),
            "hostname":         hostname,
            "host":             dev.get("managementIpAddress", ""),
            "platform":         dev.get("platformId", dev.get("series", "")),
            "dnac_version":     dev.get("softwareVersion", ""),
            "dnac_family":      dev.get("family", ""),
            "dnac_reachability": dev.get("reachabilityStatus", ""),
            "timestamp":        datetime.utcnow().isoformat(),
            "dnac_impacted":    True,
        }

        cached_profile = get_advisory_profile_from_cache(advisory_id)
        if cached_profile:
            job["log"].append(f"  ✓ Profile from ChromaDB cache.")
            profile = cached_profile
        else:
            dnac_summary = (
                f"Advisory ID: {advisory_id}\n"
                f"CVE(s): {', '.join(adv.get('cves', [])) or adv.get('cveId', 'N/A')}\n"
                f"Security Impact Rating: {adv.get('sir', 'N/A')}\n"
                f"CVSS Base Score: {adv.get('cvssBaseScore', 'N/A')}\n"
                f"Publication URL: {adv.get('publicationUrl', 'N/A')}\n"
                f"Detection Type: {adv.get('defaultDetectionType', 'N/A')}\n"
            )
            cisco_full = fetch_cisco_advisory_text(advisory_id)
            advisory_text = (dnac_summary + "\n\n--- Full Cisco Advisory ---\n" + cisco_full
                             if cisco_full else dnac_summary)
            try:
                profile = extract_advisory_profile(advisory_text, advisory_id=advisory_id)
            except Exception as e:
                err_str = f"{type(e).__name__}: {e}"
                job["log"].append(f"  ✗ GPT unavailable — {err_str}")
                profile = {
                    "advisory_id": advisory_id,
                    "cve": (adv.get("cves") or [adv.get("cveId", "N/A")])[0],
                    "title": advisory_id,
                    "vulnerable_feature": adv.get("defaultDetectionType", "unknown").lower(),
                    "affected_platforms": [], "affected_versions": [], "fixed_releases": {},
                    "fixed_in": "", "impact": f"Parsing failed: {err_str}",
                    "workaround": None, "verification_commands": [],
                }
                v = _version_only_verdict(profile, pair_result.get("dnac_version", ""),
                                          pair_result.get("platform", ""))
                pair_result["verdict"] = v if v in ("APPLICABLE", "NOT_APPLICABLE") else "NEEDS_REVIEW"
                pair_result["summary"] = (f"GPT unavailable. Version-only → {pair_result['verdict']}.")
                results.append(pair_result)
                job["results"] = results
                continue

        pair_result["advisory_profile"] = profile

        advisory_cmds = profile.get("verification_commands") or []
        feature_key   = (profile.get("vulnerable_feature") or "").lower()
        commands = list(set(ALWAYS_RUN + advisory_cmds)) if advisory_cmds else list(set(
            ALWAYS_RUN + FEATURE_COMMANDS.get(feature_key, FEATURE_COMMANDS["default"])))

        collection_method = "dnac_command_runner"
        collect_result = (dnac_collect(dnac_host, token, device_uuid, commands, verify_ssl)
                          if device_uuid else
                          {"status": "error", "error": "No DNAC device UUID"})

        if collect_result["status"] == "error":
            dev_host = dev.get("managementIpAddress") or dev.get("host", "")
            dev_user = dev.get("username", "")
            dev_pass = dev.get("password", "")

            if not dev_host and device_uuid:
                try:
                    d2 = dnac_get_device_by_id(dnac_host, fresh_token(), device_uuid, verify_ssl)
                    if d2:
                        dev_host = d2.get("managementIpAddress", "")
                        if d2.get("hostname"):
                            pair_result["hostname"] = d2["hostname"]
                        if d2.get("platformId"):
                            pair_result["platform"] = d2["platformId"]
                        if d2.get("softwareVersion"):
                            pair_result["dnac_version"] = d2["softwareVersion"]
                except Exception:
                    pass

            dnac_err = collect_result["error"]
            if dev_host and dev_user and dev_pass:
                job["log"].append(f"  ⚠ DNAC CR failed ({dnac_err}) — retrying SSH…")
                ssh_cfg = {
                    "host":         dev_host,
                    "port":         int(dev.get("port", 22)),
                    "username":     dev_user,
                    "password":     dev_pass,
                    "device_type":  dev.get("device_type") or _dnac_device_type(
                                        dev.get("family", ""), dev.get("series", "")),
                    "timeout":      30,
                    "auth_timeout": 20,
                }
                collect_result    = ssh_collect(ssh_cfg, commands)
                collection_method = "ssh_fallback"
                if collect_result["status"] == "error":
                    job["log"].append(f"  ✗ SSH also failed: {collect_result['error']}")
                else:
                    job["log"].append(f"  ✓ SSH succeeded.")
            else:
                job["log"].append(f"  ✗ DNAC failed ({dnac_err}) — no SSH fallback available.")

        pair_result["collection_method"] = collection_method

        if collect_result["status"] == "error":
            pair_result["collection_status"] = "failed"
            pair_result["collection_error"]  = collect_result["error"]
            device_version = pair_result.get("dnac_version", "")
            fixed_releases = profile.get("fixed_releases") or {}
            version_verdict = _version_only_verdict(profile, device_version, pair_result.get("platform", ""))

            if version_verdict == "APPLICABLE":
                reason = ("No fixed release published yet." if not fixed_releases
                          else "Device version is below the first fixed release.")
                pair_result["verdict"] = "APPLICABLE"
                pair_result["summary"] = (f"Collection failed ({collect_result['error']}). "
                                          f"Version-only → APPLICABLE. {reason}")
                pair_result["evidence"] = f"fixed_releases={fixed_releases}, device_version={device_version}"
                pair_result["needs_review_reason"] = ""
            elif version_verdict == "NOT_APPLICABLE":
                pair_result["verdict"] = "NOT_APPLICABLE"
                pair_result["summary"] = (f"Collection failed ({collect_result['error']}). "
                                          f"Version-only: {device_version} >= first fixed → NOT_APPLICABLE.")
                pair_result["evidence"] = f"fixed_releases={fixed_releases}, device_version={device_version}"
                pair_result["needs_review_reason"] = ""
            else:
                adv_platforms = [p.lower() for p in (profile.get("affected_platforms") or [])]
                dev_family    = (dev.get("family", "") or "").lower()
                adv_covers_asa = any(x in " ".join(adv_platforms)
                                     for x in ("asa", "ftd", "firewall", "firepower", "secure firewall"))
                is_asa_ftd = (
                    any(x in dev_family for x in ("asa", "ftd", "firepower", "firewall", "security"))
                    or "asa" in advisory_id.lower() or "ftd" in advisory_id.lower()
                    or _uuid_type_cache.get(device_uuid) == "asa_ftd"
                )
                if is_asa_ftd and adv_covers_asa and not fixed_releases:
                    pair_result["verdict"] = "APPLICABLE"
                    pair_result["summary"] = "ASA/FTD device — advisory covers ASA/FTD, no fix published → APPLICABLE."
                    pair_result["needs_review_reason"] = ""
                elif is_asa_ftd and adv_covers_asa:
                    pair_result["verdict"] = "NEEDS_REVIEW"
                    pair_result["summary"] = "ASA/FTD device — no version data to compare. Manual review required."
                    pair_result["needs_review_reason"] = "insufficient_data"
                else:
                    pair_result["verdict"] = "NOT_APPLICABLE"
                    pair_result["summary"] = (f"Collection failed and insufficient version data → NOT_APPLICABLE.")
                    pair_result["needs_review_reason"] = ""
        else:
            pair_result["collection_status"] = "success"
            pair_result["command_outputs"]   = collect_result["outputs"]
            job["log"].append(f"  ✓ Commands collected — analysing…")
            try:
                analysis = analyse_applicability(
                    profile, {"hostname": hostname, "platform": pair_result["platform"],
                              "version": pair_result["dnac_version"]},
                    collect_result["outputs"])
                pair_result.update(analysis)
                verdict  = analysis.get("verdict", "NEEDS_REVIEW")
                fp_label = " ← FALSE POSITIVE" if verdict == "NOT_APPLICABLE" else ""
                job["log"].append(f"  → Verdict: {verdict}{fp_label}")
                pair_result["needs_review_reason"] = "insufficient_data" if verdict == "NEEDS_REVIEW" else ""
            except Exception as e:
                pair_result["verdict"] = "NEEDS_REVIEW"
                pair_result["summary"] = f"GPT analysis failed: {e}"
                pair_result["needs_review_reason"] = "insufficient_data"

        # ── Persist to PostgreSQL so Scan DB tab can show this result ──────────
        _db_persist_result(
            advisory_id = advisory_id,
            device_id   = device_uuid or hostname,
            dnac_id     = None,   # bulk UI job — no config-key dnac_id
            result      = {**pair_result,
                           "host":     pair_result.get("host", ""),
                           "version":  pair_result.get("dnac_version", ""),
                           "platform": pair_result.get("platform", "")},
        )

        results.append(pair_result)
        job["results"] = results

    counts = {"APPLICABLE": 0, "NOT_APPLICABLE": 0, "NEEDS_REVIEW": 0}
    for r in results:
        v = r.get("verdict", "NEEDS_REVIEW")
        counts[v] = counts.get(v, 0) + 1
    job["status"]        = "done"
    job["finished_at"]   = datetime.utcnow().isoformat()
    job["summary_counts"] = counts
    job["log"].append(f"Done. Confirmed: {counts['APPLICABLE']} | "
                      f"False Positives: {counts['NOT_APPLICABLE']} | "
                      f"Needs Review: {counts['NEEDS_REVIEW']}")


# ═══════════════════════════════════════════════════════════════════════════════
# ── New API routes (from app_y.py) ────────────────────────────────────────────
# ═══════════════════════════════════════════════════════════════════════════════

@app.route("/api/assess", methods=["POST"])
def assess():
    """Start a single-advisory assessment job."""
    data         = request.get_json(force=True) or {}
    advisory_text = data.get("advisory_text", "").strip()
    devices       = data.get("devices", [])
    if not advisory_text:
        return jsonify({"error": "advisory_text is required"}), 400
    if not devices:
        return jsonify({"error": "at least one device is required"}), 400

    job_id = datetime.utcnow().strftime("%Y%m%d_%H%M%S_%f")
    jobs[job_id] = {
        "job_id": job_id, "status": "queued", "progress": 0,
        "log": [], "results": [], "advisory_profile": {},
        "summary_counts": {}, "created_at": datetime.utcnow().isoformat(),
    }
    threading.Thread(target=run_job, args=(job_id, advisory_text, devices), daemon=True).start()
    return jsonify({"job_id": job_id})


@app.route("/api/job/<job_id>")
def job_status(job_id):
    job = jobs.get(job_id)
    if not job:
        return jsonify({"error": "Job not found"}), 404
    return jsonify(job)


@app.route("/api/job/<job_id>/export")
def export_json(job_id):
    job = jobs.get(job_id)
    if not job:
        return jsonify({"error": "Job not found"}), 404
    if job.get("job_type") == "dnac_bulk":
        export = {
            "export_meta": {"tool": "PSIRT Applicability Manager", "job_id": job_id,
                            "job_type": "dnac_bulk", "exported_at": datetime.utcnow().isoformat()},
            "summary": job.get("summary_counts", {}),
            "total_pairs": job.get("total_pairs", len(job.get("results", []))),
            "pairs": job.get("results", []),
        }
    else:
        export = {
            "export_meta": {"tool": "PSIRT Applicability Manager", "job_id": job_id,
                            "exported_at": datetime.utcnow().isoformat()},
            "advisory": job.get("advisory_profile", {}),
            "summary":  job.get("summary_counts", {}),
            "devices":  job.get("results", []),
        }
    filepath = f"/tmp/psirt_results_{job_id}.json"
    with open(filepath, "w") as f:
        json.dump(export, f, indent=2)
    return send_file(filepath, mimetype="application/json", as_attachment=True,
                     download_name=f"psirt_results_{job_id}.json")


@app.route("/api/jobs")
def list_jobs():
    summary = [{"job_id": jid, "status": j["status"], "progress": j["progress"],
                "device_count": len(j.get("results", [])), "summary_counts": j.get("summary_counts", {}),
                "created_at": j.get("created_at")}
               for jid, j in jobs.items()]
    return jsonify(sorted(summary, key=lambda x: x["created_at"], reverse=True))


@app.route("/api/dnac/assess-all", methods=["POST"])
def dnac_assess_all():
    """Start bulk assessment of all DNAC advisory-device pairs."""
    data         = request.get_json(force=True) or {}
    host         = (data.get("host") or "").strip()
    username     = (data.get("username") or "").strip()
    password     = data.get("password", "")
    ssh_username = (data.get("ssh_username") or username).strip()
    ssh_password = data.get("ssh_password") or password
    verify_ssl   = bool(data.get("verify_ssl", False))
    advisory_ids_filter = data.get("advisory_ids", None)

    if not host or not username or not password:
        return jsonify({"error": "host, username, and password are required"}), 400

    job_id = "bulk_" + datetime.utcnow().strftime("%Y%m%d_%H%M%S_%f")
    jobs[job_id] = {
        "job_id": job_id, "job_type": "dnac_bulk", "status": "queued", "progress": 0,
        "log": [], "results": [], "summary_counts": {}, "created_at": datetime.utcnow().isoformat(),
    }
    threading.Thread(
        target=run_dnac_bulk_job,
        args=(job_id, host, username, password, verify_ssl, advisory_ids_filter,
              ssh_username, ssh_password),
        daemon=True).start()
    return jsonify({"job_id": job_id})


@app.route("/api/dnac/test", methods=["POST"])
def dnac_test():
    data       = request.get_json(force=True) or {}
    host       = (data.get("host") or "").strip()
    username   = (data.get("username") or "").strip()
    password   = data.get("password", "")
    verify_ssl = bool(data.get("verify_ssl", False))
    if not host or not username or not password:
        return jsonify({"error": "host, username, and password are required"}), 400
    try:
        dnac_get_token(host, username, password, verify_ssl)
        return jsonify({"status": "ok", "message": f"Connected to DNAC at {host}"})
    except requests.exceptions.ConnectionError:
        return jsonify({"error": f"Cannot reach DNAC at {host}"}), 502
    except requests.exceptions.HTTPError as e:
        status = e.response.status_code if e.response is not None else 0
        return jsonify({"error": f"DNAC returned HTTP {status}"}), 502
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/api/dnac/devices", methods=["POST"])
def dnac_devices():
    data         = request.get_json(force=True) or {}
    host         = (data.get("host") or "").strip()
    username     = (data.get("username") or "").strip()
    password     = data.get("password", "")
    verify_ssl   = bool(data.get("verify_ssl", False))
    ssh_username = (data.get("ssh_username") or username).strip()
    ssh_password = data.get("ssh_password") or password
    if not host or not username or not password:
        return jsonify({"error": "host, username, and password are required"}), 400
    try:
        token       = dnac_get_token(host, username, password, verify_ssl)
        raw_devices = dnac_get_devices(host, token, verify_ssl)
    except Exception as e:
        return jsonify({"error": str(e)}), 502

    formatted = []
    for d in raw_devices:
        if not d.get("managementIpAddress"):
            continue
        formatted.append({
            "host":          d.get("managementIpAddress", ""),
            "hostname":      d.get("hostname", d.get("managementIpAddress", "")),
            "port":          22,
            "username":      ssh_username,
            "password":      ssh_password,
            "device_type":   _dnac_device_type(d.get("family", ""), d.get("series", "")),
            "platform":      d.get("platformId", d.get("series", "")),
            "dnac_id":       d.get("id", ""),
            "dnac_host":     host,
            "dnac_username": username,
            "dnac_password": password,
            "dnac_verify_ssl": verify_ssl,
            "dnac_family":   d.get("family", ""),
            "dnac_series":   d.get("series", ""),
            "dnac_version":  d.get("softwareVersion", ""),
            "dnac_role":     d.get("role", ""),
            "dnac_reachability": d.get("reachabilityStatus", ""),
        })
    return jsonify({"count": len(formatted), "devices": formatted})


@app.route("/api/dnac/advisories", methods=["POST"])
def dnac_advisories():
    data             = request.get_json(force=True) or {}
    host             = (data.get("host") or "").strip()
    username         = (data.get("username") or "").strip()
    password         = data.get("password", "")
    verify_ssl       = bool(data.get("verify_ssl", False))
    include_affected = bool(data.get("include_affected_devices", False))
    if not host or not username or not password:
        return jsonify({"error": "host, username, and password are required"}), 400
    try:
        token          = dnac_get_token(host, username, password, verify_ssl)
        raw_advisories = dnac_get_advisories(host, token, verify_ssl)
    except requests.exceptions.HTTPError as e:
        status = e.response.status_code if e.response is not None else 0
        if status == 403:
            return jsonify({"error": "DNAC 403 — Security Advisories API requires Network Security license"}), 403
        return jsonify({"error": f"DNAC HTTP {status}"}), 502
    except Exception as e:
        return jsonify({"error": str(e)}), 500

    formatted = []
    for adv in raw_advisories:
        advisory_id      = adv.get("advisoryId", "")
        affected_devices = []
        if include_affected and advisory_id:
            try:
                affected_devices = [
                    {"hostname": d.get("hostname", ""), "managementIp": d.get("managementIpAddress", ""),
                     "platformId": d.get("platformId", ""), "softwareVersion": d.get("softwareVersion", "")}
                    for d in dnac_get_advisory_affected_devices(host, token, advisory_id, verify_ssl)
                ]
            except Exception:
                pass
        formatted.append({
            "advisoryId":    advisory_id,
            "cveId":         adv.get("cveId") or adv.get("cves", [None])[0],
            "cves":          adv.get("cves", []),
            "publicationUrl": adv.get("publicationUrl", ""),
            "sir":           adv.get("sir", ""),
            "cvssBaseScore": adv.get("cvssBaseScore", ""),
            "defaultDetectionType": adv.get("defaultDetectionType", ""),
            "affectedDeviceCount":  adv.get("affectedDeviceCount", len(affected_devices)),
            "affectedDevices": affected_devices,
            "advisoryText": (
                f"Advisory ID: {advisory_id}\n"
                f"CVE: {', '.join(adv.get('cves', [])) or adv.get('cveId', 'N/A')}\n"
                f"CVSS Base Score: {adv.get('cvssBaseScore', 'N/A')}\n"
                f"Security Impact Rating: {adv.get('sir', 'N/A')}\n"
                f"Publication URL: {adv.get('publicationUrl', 'N/A')}\n"
            ),
        })
    return jsonify({"count": len(formatted), "advisories": formatted})


@app.route("/api/dnac/advisory/<advisory_id>/devices", methods=["POST"])
def dnac_advisory_devices(advisory_id: str):
    data         = request.get_json(force=True) or {}
    host         = (data.get("host") or "").strip()
    username     = (data.get("username") or "").strip()
    password     = data.get("password", "")
    verify_ssl   = bool(data.get("verify_ssl", False))
    ssh_username = (data.get("ssh_username") or username).strip()
    ssh_password = data.get("ssh_password") or password
    if not host or not username or not password:
        return jsonify({"error": "host, username, and password are required"}), 400
    try:
        token = dnac_get_token(host, username, password, verify_ssl)
        raw   = dnac_get_advisory_affected_devices(host, token, advisory_id, verify_ssl)
    except Exception as e:
        return jsonify({"error": str(e)}), 502

    formatted = [
        {
            "host":          d.get("managementIpAddress", ""),
            "hostname":      d.get("hostname", d.get("managementIpAddress", "")),
            "port":          22,
            "username":      ssh_username,
            "password":      ssh_password,
            "device_type":   _dnac_device_type(d.get("family", ""), d.get("series", "")),
            "platform":      d.get("platformId", d.get("series", "")),
            "dnac_id":       d.get("id", ""),
            "dnac_host":     host,
            "dnac_username": username,
            "dnac_password": password,
            "dnac_verify_ssl": verify_ssl,
            "dnac_version":  d.get("softwareVersion", ""),
            "dnac_reachability": d.get("reachabilityStatus", ""),
        }
        for d in raw if d.get("managementIpAddress")
    ]
    return jsonify({"count": len(formatted), "devices": formatted})


# ── HTML template ─────────────────────────────────────────────────────────────
HTML_TEMPLATE = r"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<title>PSIRT Applicability Manager</title>
<style>
  *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
  :root {
    --bg: #f5f4f0; --surface: #ffffff; --surface2: #f0ede8; --border: #d8d4cc;
    --border2: #c8c4bc; --text: #1a1a18; --text2: #5a5a54; --text3: #8a8a84;
    --green: #1a7a4a; --green-bg: #eaf5ef; --red: #b03020; --red-bg: #fcecea;
    --amber: #8a5c00; --amber-bg: #fef6e4; --blue: #1a5090; --blue-bg: #e8f0fb;
    --mono: 'Courier New', monospace; --radius: 8px; --radius-lg: 12px;
  }
  body { font-family: 'Georgia', serif; background: var(--bg); color: var(--text); min-height: 100vh; font-size: 14px; line-height: 1.6; }
  .topbar { background: var(--text); color: #f5f4f0; padding: 14px 32px; display: flex; align-items: center; gap: 12px; }
  .topbar-logo { font-size: 16px; font-weight: bold; letter-spacing: 0.02em; font-family: 'Georgia', serif; }
  .topbar-sub { font-size: 12px; color: #aaa; margin-left: auto; font-family: monospace; }
  .layout { display: grid; grid-template-columns: 340px 1fr; gap: 0; min-height: calc(100vh - 49px); }
  .sidebar { background: var(--surface); border-right: 1px solid var(--border); padding: 24px 20px; display: flex; flex-direction: column; gap: 20px; overflow-y: auto; }
  .main { padding: 24px 28px; overflow-y: auto; }
  .section-label { font-family: monospace; font-size: 10px; letter-spacing: 0.1em; text-transform: uppercase; color: var(--text3); margin-bottom: 6px; }
  textarea, input[type="text"], input[type="number"], input[type="password"], select { width: 100%; border: 1px solid var(--border); border-radius: var(--radius); padding: 8px 10px; font-size: 13px; font-family: var(--mono); background: var(--surface); color: var(--text); transition: border-color 0.15s; outline: none; }
  textarea:focus, input:focus, select:focus { border-color: var(--text); }
  textarea { resize: vertical; }
  .btn { display: inline-flex; align-items: center; gap: 6px; padding: 8px 16px; border-radius: var(--radius); font-size: 13px; font-family: monospace; cursor: pointer; border: 1px solid var(--border); background: var(--surface); color: var(--text); transition: all 0.15s; text-decoration: none; }
  .btn:hover { background: var(--surface2); border-color: var(--border2); }
  .btn-primary { background: var(--text); color: #f5f4f0; border-color: var(--text); }
  .btn-primary:hover { background: #333; }
  .btn-primary:disabled { opacity: 0.45; cursor: not-allowed; }
  .btn-sm { padding: 5px 10px; font-size: 11px; }
  .btn-danger { color: var(--red); border-color: #f0b0a8; }
  .btn-danger:hover { background: var(--red-bg); }
  .btn-export { color: var(--blue); border-color: #b0c8f0; }
  .btn-export:hover { background: var(--blue-bg); }
  .device-table-wrap { overflow-x: auto; }
  table { width: 100%; border-collapse: collapse; font-size: 12px; font-family: var(--mono); }
  th { background: var(--surface2); padding: 7px 10px; text-align: left; font-size: 10px; letter-spacing: 0.08em; text-transform: uppercase; color: var(--text2); border-bottom: 1px solid var(--border); }
  td { padding: 7px 10px; border-bottom: 1px solid var(--border); vertical-align: middle; }
  tr:last-child td { border-bottom: none; }
  tr:hover td { background: var(--surface2); }
  .del-row { cursor: pointer; color: var(--text3); background: none; border: none; font-size: 16px; line-height: 1; }
  .del-row:hover { color: var(--red); }
  .add-device-form { background: var(--surface2); border: 1px solid var(--border); border-radius: var(--radius-lg); padding: 14px; display: none; flex-direction: column; gap: 10px; margin-top: 10px; }
  .add-device-form.open { display: flex; }
  .form-row { display: grid; grid-template-columns: 1fr 1fr; gap: 8px; }
  .form-row-3 { display: grid; grid-template-columns: 1fr 1fr 80px; gap: 8px; }
  .field-label { font-size: 10px; color: var(--text3); font-family: monospace; letter-spacing: 0.06em; text-transform: uppercase; margin-bottom: 3px; }
  .badge { display: inline-block; padding: 2px 8px; border-radius: 99px; font-size: 10px; font-family: monospace; letter-spacing: 0.05em; font-weight: bold; text-transform: uppercase; }
  .badge-applicable { background: var(--green-bg); color: var(--green); }
  .badge-not { background: var(--red-bg); color: var(--red); }
  .badge-review { background: var(--amber-bg); color: var(--amber); }
  .badge-pending { background: var(--surface2); color: var(--text3); }
  .badge-running { background: var(--blue-bg); color: var(--blue); }
  .results-header { display: flex; align-items: center; gap: 12px; margin-bottom: 16px; }
  .results-title { font-size: 16px; font-weight: bold; font-family: 'Georgia', serif; }
  .summary-bar { display: flex; gap: 10px; margin-bottom: 20px; flex-wrap: wrap; }
  .stat-card { background: var(--surface); border: 1px solid var(--border); border-radius: var(--radius); padding: 10px 16px; min-width: 110px; text-align: center; }
  .stat-num { font-size: 24px; font-weight: bold; font-family: monospace; }
  .stat-label { font-size: 10px; color: var(--text3); text-transform: uppercase; letter-spacing: 0.08em; font-family: monospace; }
  .stat-applicable .stat-num { color: var(--green); }
  .stat-not .stat-num { color: var(--red); }
  .stat-review .stat-num { color: var(--amber); }
  .device-card { background: var(--surface); border: 1px solid var(--border); border-radius: var(--radius-lg); margin-bottom: 12px; overflow: hidden; }
  .device-card-header { display: flex; align-items: center; gap: 10px; padding: 12px 16px; cursor: pointer; border-bottom: 1px solid transparent; transition: background 0.1s; }
  .device-card-header:hover { background: var(--surface2); }
  .device-card.open .device-card-header { border-bottom-color: var(--border); }
  .device-hostname { font-family: monospace; font-weight: bold; font-size: 13px; flex: 1; }
  .device-meta { font-size: 11px; color: var(--text3); font-family: monospace; }
  .device-card-body { display: none; padding: 16px; }
  .device-card.open .device-card-body { display: block; }
  .layer-grid { display: flex; flex-direction: column; gap: 6px; margin: 12px 0; }
  .layer-row { display: flex; align-items: flex-start; gap: 10px; padding: 8px 12px; border-radius: var(--radius); background: var(--surface2); font-size: 12px; }
  .layer-dot { width: 8px; height: 8px; border-radius: 50%; flex-shrink: 0; margin-top: 4px; }
  .dot-pass { background: var(--green); }
  .dot-fail { background: var(--red); }
  .dot-unknown { background: var(--amber); }
  .layer-name { font-family: monospace; font-size: 10px; text-transform: uppercase; letter-spacing: 0.06em; color: var(--text3); min-width: 85px; margin-top: 2px; }
  .layer-detail { color: var(--text); flex: 1; line-height: 1.5; }
  .evidence-block { background: var(--surface2); border: 1px solid var(--border); border-radius: var(--radius); padding: 10px 12px; font-family: var(--mono); font-size: 11px; color: var(--text2); white-space: pre-wrap; max-height: 200px; overflow-y: auto; margin-top: 8px; }
  .action-box { border-left: 3px solid var(--border2); padding: 8px 12px; margin-top: 10px; font-size: 12px; color: var(--text2); }
  .progress-wrap { margin: 12px 0; }
  .progress-bar-bg { background: var(--surface2); border-radius: 99px; height: 6px; }
  .progress-bar-fill { background: var(--text); border-radius: 99px; height: 6px; transition: width 0.3s; }
  .log-box { background: #1a1a18; color: #b0f0c0; font-family: var(--mono); font-size: 11px; border-radius: var(--radius); padding: 10px 12px; max-height: 160px; overflow-y: auto; line-height: 1.7; margin-top: 10px; }
  .empty-state { text-align: center; padding: 48px 24px; color: var(--text3); font-family: monospace; font-size: 13px; }
  .advisory-card { background: var(--surface); border: 1px solid var(--border); border-radius: var(--radius-lg); padding: 14px 16px; margin-bottom: 16px; font-size: 12px; font-family: monospace; }
  .advisory-card-title { font-size: 13px; font-weight: bold; margin-bottom: 8px; color: var(--text); font-family: 'Georgia', serif; }
  .advisory-kv { display: grid; grid-template-columns: 120px 1fr; gap: 4px 12px; }
  .advisory-k { color: var(--text3); }
  .advisory-v { color: var(--text); }
  .tabs { display: flex; gap: 0; border-bottom: 1px solid var(--border); margin-bottom: 20px; }
  .tab { padding: 8px 18px; font-family: monospace; font-size: 12px; cursor: pointer; border: none; background: none; color: var(--text3); border-bottom: 2px solid transparent; margin-bottom: -1px; }
  .tab.active { color: var(--text); border-bottom-color: var(--text); }
  .tab-content { display: none; }
  .tab-content.active { display: block; }
  .spinner { width: 14px; height: 14px; border: 2px solid var(--border); border-top-color: var(--text); border-radius: 50%; animation: spin 0.7s linear infinite; display: inline-block; vertical-align: middle; }
  @keyframes spin { to { transform: rotate(360deg); } }
  .dash-metric-grid { display: grid; grid-template-columns: repeat(4,1fr); gap: 10px; margin-bottom: 1.5rem; }
  .dash-metric { background: var(--surface); border: 1px solid var(--border); border-radius: 8px; padding: 14px 16px; }
  .dash-metric-label { font-size: 11px; color: var(--text3); margin: 0 0 4px; font-family: var(--mono); text-transform: uppercase; letter-spacing: .04em; }
  .dash-metric-value { font-size: 28px; font-weight: 700; margin: 0; line-height: 1; }
  .dash-metric-sub { font-size: 11px; color: var(--text3); margin: 4px 0 0; }
  .dash-charts-row { display: grid; grid-template-columns: 1fr 1fr; gap: 14px; margin-bottom: 14px; }
  .dash-card { background: var(--surface); border: 1px solid var(--border); border-radius: 8px; padding: 14px 16px; }
  .dash-card-title { font-size: 11px; color: var(--text3); text-transform: uppercase; letter-spacing: .04em; font-family: var(--mono); margin: 0 0 10px; }
  .dash-legend { display: flex; flex-wrap: wrap; gap: 10px; margin-bottom: 10px; font-size: 11px; color: var(--text3); }
  .dash-legend span { display: flex; align-items: center; gap: 4px; }
  .dash-legend-dot { width: 9px; height: 9px; border-radius: 2px; flex-shrink: 0; }
  .adv-breakdown-table { width: 100%; border-collapse: collapse; font-size: 12px; }
  .adv-breakdown-table th { font-size: 10px; color: var(--text3); text-align: left; padding: 0 8px 7px 0; border-bottom: 1px solid var(--border); font-family: var(--mono); text-transform: uppercase; }
  .adv-breakdown-table td { padding: 8px 8px 8px 0; border-bottom: 1px solid var(--border); vertical-align: middle; }
  .adv-breakdown-table tr:last-child td { border-bottom: none; }
  .mini-bar-wrap { display: flex; gap: 2px; align-items: center; }
  .mini-bar-seg { height: 7px; border-radius: 2px; min-width: 3px; }
  .why-btn { font-size: 11px; background: none; border: 1px solid var(--border); border-radius: 4px; padding: 2px 8px; cursor: pointer; color: var(--text3); font-family: var(--mono); transition: background .15s; margin-left: 8px; }
  .why-btn:hover { background: var(--surface2); color: var(--text); }
  .why-drawer { display: none; margin: 8px 0 0; background: var(--surface2); border-radius: 6px; padding: 12px 14px; font-size: 12px; line-height: 1.6; }
  .why-drawer.open { display: block; }
  .why-layers { display: grid; grid-template-columns: auto 1fr; gap: 4px 10px; margin: 8px 0; font-size: 12px; align-items: start; }
  .why-layer-name { color: var(--text3); font-family: var(--mono); white-space: nowrap; padding-top: 1px; }
  .why-layer-detail { color: var(--text); }
  .why-evidence { margin-top: 8px; padding: 8px 10px; background: var(--bg); border-radius: 4px; font-family: var(--mono); font-size: 11px; color: var(--text3); border-left: 3px solid var(--border); }
  .why-action { margin-top: 8px; font-size: 12px; color: var(--amber); }
  .verdict-pill { display: inline-block; font-size: 10px; font-weight: 600; padding: 1px 7px; border-radius: 999px; }
  .vp-app { background: rgba(40,180,80,.12); color: var(--green); }
  .vp-na  { background: rgba(220,50,50,.12); color: var(--red); }
  .vp-nr  { background: rgba(210,140,30,.12); color: var(--amber); }
</style>
</head>
<body>
<div class="topbar">
  <div class="topbar-logo">⬡ PSIRT Applicability Manager</div>
  <div class="topbar-sub">Cisco IOS / IOS XE · Netmiko SSH</div>
</div>
<div class="layout">
  <aside class="sidebar">
    <div>
      <div class="section-label">Advisory text</div>
      <textarea id="advisory-text" rows="8" placeholder="Paste Cisco PSIRT advisory, CVE description, or PSIRT JSON…"></textarea>
      <button class="btn btn-sm" onclick="loadSampleAdvisory()" style="margin-top:6px">Load sample advisory</button>
    </div>
    <div>
      <div class="section-label" style="margin-bottom:8px">Device inventory</div>
      <div class="device-table-wrap" id="device-table-wrap">
        <table id="device-table">
          <thead><tr><th>Host</th><th>Type</th><th>Platform</th><th></th></tr></thead>
          <tbody id="device-tbody"></tbody>
        </table>
      </div>
      <div id="add-device-form" class="add-device-form">
        <div class="form-row-3">
          <div><div class="field-label">Hostname/IP *</div><input type="text" id="f-host" placeholder="192.168.1.1" /></div>
          <div><div class="field-label">Hostname label</div><input type="text" id="f-hostname" placeholder="SW1" /></div>
          <div><div class="field-label">Port</div><input type="number" id="f-port" value="22" min="1" max="65535" /></div>
        </div>
        <div class="form-row">
          <div><div class="field-label">Username *</div><input type="text" id="f-user" placeholder="admin" /></div>
          <div><div class="field-label">Password *</div><input type="password" id="f-pass" placeholder="••••••••" /></div>
        </div>
        <div class="form-row">
          <div><div class="field-label">Device type</div>
            <select id="f-dtype">
              <option value="cisco_ios">cisco_ios</option>
              <option value="cisco_xe">cisco_xe</option>
              <option value="cisco_nxos">cisco_nxos</option>
              <option value="cisco_xr">cisco_xr</option>
            </select>
          </div>
          <div><div class="field-label">Platform/Model</div><input type="text" id="f-platform" placeholder="C9300-48U" /></div>
        </div>
        <div style="display:flex;gap:8px;margin-top:4px">
          <button class="btn btn-primary btn-sm" onclick="addDevice()">Add device</button>
          <button class="btn btn-sm" onclick="toggleAddForm()">Cancel</button>
        </div>
      </div>
      <div style="display:flex;gap:8px;margin-top:10px;flex-wrap:wrap">
        <button class="btn btn-sm" onclick="toggleAddForm()">+ Add device</button>
        <button class="btn btn-sm" onclick="loadSampleDevices()">Load samples</button>
        <button class="btn btn-sm btn-danger" onclick="clearDevices()">Clear all</button>
      </div>
    </div>
    <div>
      <div class="section-label" style="margin-bottom:8px">
        DNA Center
        <span id="dnac-status-dot" style="display:inline-block;width:8px;height:8px;border-radius:50%;background:var(--text3);margin-left:6px;vertical-align:middle" title="Not connected"></span>
      </div>
      <div id="dnac-form" style="display:flex;flex-direction:column;gap:8px">
        <div class="form-row">
          <div><div class="field-label">DNAC Host / IP</div><input type="text" id="dnac-host" placeholder="sandboxdnac.cisco.com" /></div>
          <div><div class="field-label">Port</div><input type="number" id="dnac-port" value="443" style="width:70px"/></div>
        </div>
        <div class="form-row">
          <div><div class="field-label">DNAC Username</div><input type="text" id="dnac-user" placeholder="devnetuser" /></div>
          <div><div class="field-label">DNAC Password</div><input type="password" id="dnac-pass" placeholder="••••••••" /></div>
        </div>
        <div style="display:flex;align-items:center;gap:8px">
          <label style="font-size:11px;color:var(--text3);display:flex;align-items:center;gap:4px;cursor:pointer">
            <input type="checkbox" id="dnac-verify-ssl" /> Verify SSL
          </label>
        </div>
        <div style="font-size:11px;color:var(--text3);margin-top:2px">SSH credentials for fetched devices (leave blank to reuse DNAC credentials):</div>
        <div class="form-row">
          <div><div class="field-label">SSH Username</div><input type="text" id="dnac-ssh-user" placeholder="(same as DNAC)" /></div>
          <div><div class="field-label">SSH Password</div><input type="password" id="dnac-ssh-pass" placeholder="(same as DNAC)" /></div>
        </div>
        <div style="display:flex;gap:6px;flex-wrap:wrap;margin-top:2px">
          <button class="btn btn-sm" onclick="dnacTest()">Test connection</button>
          <button class="btn btn-sm" onclick="dnacFetchDevices()">Import devices</button>
          <button class="btn btn-sm" onclick="openDnacAdvisories()">Browse advisories</button>
          <button class="btn btn-primary" style="width:100%;margin-top:4px" onclick="dnacAssessAll()">&#9654; Assess All DNAC Impacted Pairs</button>
          <div style="font-size:10px;color:var(--text3);margin-top:3px">or Browse advisories to select specific ones</div>
        </div>
        <div id="dnac-msg" style="font-size:11px;min-height:14px;font-family:monospace;margin-top:2px"></div>
      </div>
    </div>
    <div id="dnac-adv-panel" style="display:none;margin-top:10px">
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:6px">
        <div class="field-label" style="margin:0">DNAC Advisories</div>
        <button class="btn btn-sm" onclick="closeDnacAdvisories()" style="padding:2px 6px">x</button>
      </div>
      <label style="font-size:11px;color:var(--text3);display:flex;align-items:center;gap:4px;cursor:pointer;margin-bottom:6px">
        <input type="checkbox" id="dnac-adv-include-affected" checked /> Fetch affected devices per advisory
      </label>
      <div style="display:flex;gap:5px;margin-bottom:6px;flex-wrap:wrap">
        <button class="btn btn-sm btn-primary" style="flex:1" onclick="dnacFetchAdvisories()">Fetch from DNAC</button>
        <button class="btn btn-sm" onclick="dnacSelectAll(true)">All</button>
        <button class="btn btn-sm" onclick="dnacSelectAll(false)">None</button>
      </div>
      <div id="dnac-adv-list" style="max-height:240px;overflow-y:auto;font-size:11px;font-family:monospace"></div>
      <button id="dnac-run-selected-btn" class="btn btn-primary" style="width:100%;margin-top:6px;display:none" onclick="dnacAssessSelected()">&#9654; Assess Selected Advisories</button>
    </div>
    <button class="btn btn-primary" id="run-btn" onclick="startAssessment()">&#9654; Run assessment</button>
  </aside>

  <main class="main">
    <div class="tabs">
      <button class="tab active" onclick="showTab('results')">Results</button>
      <button class="tab" onclick="showTab('dashboard')">Dashboard</button>
      <button class="tab" onclick="showTab('log')">Job log</button>
      <button class="tab" onclick="showTab('history')">History</button>
      <button class="tab" onclick="showTab('dbresults')">Scan DB</button>
    </div>
    <div class="tab-content active" id="tab-results">
      <div id="results-area"><div class="empty-state">No assessment run yet.<br>Add devices and paste an advisory, then click Run.</div></div>
    </div>
    <div class="tab-content" id="tab-dashboard">
      <div id="dashboard-area"><div class="empty-state">Run an assessment to see the dashboard.</div></div>
    </div>
    <div class="tab-content" id="tab-log">
      <div id="log-area"><div class="empty-state">Job log will appear here.</div></div>
    </div>
    <div class="tab-content" id="tab-history">
      <div id="history-area"><div class="empty-state">Completed jobs will appear here.</div></div>
    </div>
    <div class="tab-content" id="tab-dbresults">
      <div style="display:flex;align-items:flex-end;gap:10px;margin-bottom:18px;flex-wrap:wrap;padding-bottom:14px;border-bottom:1px solid var(--border)">
        <div>
          <div class="section-label" style="margin-bottom:4px">DNAC ID</div>
          <input type="text" id="db-dnac-id" placeholder="e.g. noida  (blank = all)" style="width:220px;font-size:12px" />
        </div>
        <button class="btn btn-primary" onclick="loadDbResults()">Load DB results</button>
        <button class="btn btn-sm" id="db-refresh-btn" onclick="toggleDbAutoRefresh()" title="Poll the DB every 10 s while a scan is running">⟳ Auto-refresh</button>
        <span id="db-refresh-status" style="font-size:11px;color:var(--text3);font-family:monospace"></span>
      </div>
      <div id="db-results-area"><div class="empty-state">Enter a DNAC ID and click "Load DB results" to view scan results stored in the database.</div></div>
    </div>
  </main>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.1/chart.umd.js"></script>
<script>
let devices = [];
let currentJobId = null;
let pollInterval = null;
let jobHistory = [];

function renderDeviceTable() {
  const tbody = document.getElementById('device-tbody');
  if (!devices.length) {
    tbody.innerHTML = '<tr><td colspan="4" style="color:var(--text3);text-align:center;padding:12px;font-family:monospace;font-size:11px">No devices added</td></tr>';
    return;
  }
  tbody.innerHTML = devices.map((d, i) => `
    <tr>
      <td>${d.hostname || d.host}</td>
      <td><span style="font-size:10px;color:var(--text3)">${d.device_type}</span></td>
      <td><span style="font-size:10px;color:var(--text3)">${d.platform || '—'}</span></td>
      <td><button class="del-row" onclick="removeDevice(${i})" title="Remove">×</button></td>
    </tr>`).join('');
}

function addDevice() {
  const host = document.getElementById('f-host').value.trim();
  const username = document.getElementById('f-user').value.trim();
  const password = document.getElementById('f-pass').value;
  if (!host || !username || !password) { alert('Host, username, and password are required.'); return; }
  devices.push({
    host, hostname: document.getElementById('f-hostname').value.trim() || host,
    port: parseInt(document.getElementById('f-port').value) || 22,
    username, password,
    device_type: document.getElementById('f-dtype').value,
    platform: document.getElementById('f-platform').value.trim(),
  });
  ['f-host','f-hostname','f-user','f-pass','f-platform'].forEach(id => document.getElementById(id).value = '');
  document.getElementById('f-port').value = '22';
  renderDeviceTable();
  document.getElementById('add-device-form').classList.remove('open');
}

function removeDevice(i) { devices.splice(i, 1); renderDeviceTable(); }
function clearDevices() { devices = []; renderDeviceTable(); }
function toggleAddForm() { document.getElementById('add-device-form').classList.toggle('open'); }

function loadSampleDevices() {
  devices = [
    { host:'192.168.1.10', hostname:'SW1-C9300', port:22, username:'admin', password:'cisco123', device_type:'cisco_xe', platform:'C9300-48U' },
    { host:'192.168.1.11', hostname:'SW2-C9200L', port:22, username:'admin', password:'cisco123', device_type:'cisco_xe', platform:'C9200L-48P' },
    { host:'192.168.1.20', hostname:'RTR1-ASR', port:22, username:'admin', password:'cisco123', device_type:'cisco_ios', platform:'ASR1001-X' },
  ];
  renderDeviceTable();
}

function loadSampleAdvisory() {
  document.getElementById('advisory-text').value = `Advisory ID: cisco-sa-snmp-x4LPhte
CVE: CVE-2025-20352
CVSS Score: 8.6 (High)
Title: Cisco IOS and IOS XE Software SNMP Remote Code Execution and Denial of Service Vulnerability

Affected Feature: SNMP
Affected Platforms: IOS, IOS XE
Affected Versions: 16.x, 17.x through 17.9.4
Fixed In: 17.9.6 and later

Detection Commands:
  show running-config | include snmp-server community
  show running-config | include snmp-server group
  show snmp user`;
}

async function startAssessment() {
  const advisory = document.getElementById('advisory-text').value.trim();
  if (!advisory) { alert('Please paste an advisory first.'); return; }
  if (!devices.length) { alert('Please add at least one device.'); return; }
  const btn = document.getElementById('run-btn');
  btn.disabled = true; btn.innerHTML = '<span class="spinner"></span> Running…';
  showTab('results');
  try {
    const resp = await fetch('/api/assess', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ advisory_text: advisory, devices })
    });
    const data = await resp.json();
    if (data.error) { alert('Error: ' + data.error); btn.disabled=false; btn.innerHTML='&#9654; Run assessment'; return; }
    currentJobId = data.job_id;
    startPolling(data.job_id);
  } catch(e) {
    alert('Request failed: ' + e.message);
    btn.disabled=false; btn.innerHTML='&#9654; Run assessment';
  }
}

function startPolling(jobId) {
  clearInterval(pollInterval);
  window._pollStart = Date.now(); window._pollJobId = jobId;
  pollInterval = setInterval(() => pollJob(jobId), 2000);
  pollJob(jobId);
}

async function pollJob(jobId) {
  if (Date.now() - (window._pollStart || 0) > 30 * 60 * 1000) {
    clearInterval(pollInterval);
    document.getElementById('run-btn').disabled = false;
    document.getElementById('run-btn').innerHTML = '&#9654; Run assessment';
    return;
  }
  try {
    const resp = await fetch(`/api/job/${jobId}`);
    const job = await resp.json();
    renderResults(job);
    renderLog(job);
    if (job.status === 'done' || job.status === 'failed') {
      clearInterval(pollInterval);
      document.getElementById('run-btn').disabled = false;
      document.getElementById('run-btn').innerHTML = '&#9654; Run assessment';
      if (!jobHistory.find(j => j.job_id === jobId)) { jobHistory.unshift(job); renderHistory(); }
    }
  } catch(e) { console.error('Poll error:', e); }
}

function verdictBadge(v) {
  if (!v) return '<span class="badge badge-pending">pending</span>';
  if (v === 'APPLICABLE') return '<span class="badge badge-applicable">Applicable</span>';
  if (v === 'NOT_APPLICABLE') return '<span class="badge badge-not">Not applicable</span>';
  return '<span class="badge badge-review">Needs review</span>';
}
function dotClass(r) { return r==='PASS'?'dot-pass':r==='FAIL'?'dot-fail':'dot-unknown'; }

var renderResults = function(job) {
  window._lastJob = job;
  if (document.getElementById('tab-dashboard').classList.contains('active')) renderDashboard(job);
  const area = document.getElementById('results-area');
  if (job.status === 'queued') { area.innerHTML = `<div class="empty-state"><span class="spinner"></span><br><br>Queued…</div>`; return; }
  let html = '';
  const p = job.advisory_profile || {};
  if (p.cve) {
    html += `<div class="advisory-card">
      <div class="advisory-card-title">${p.title || p.advisory_id || 'Advisory'}</div>
      <div class="advisory-kv">
        <span class="advisory-k">CVE</span><span class="advisory-v">${p.cve || '—'}</span>
        <span class="advisory-k">Feature</span><span class="advisory-v">${p.vulnerable_feature || '—'}</span>
        <span class="advisory-k">Platforms</span><span class="advisory-v">${(p.affected_platforms||[]).join(', ') || '—'}</span>
        <span class="advisory-k">Fixed in</span><span class="advisory-v">${p.fixed_in || '—'}</span>
        <span class="advisory-k">Workaround</span><span class="advisory-v">${p.workaround || 'None'}</span>
      </div></div>`;
  }
  if (job.status === 'done') {
    const sc = job.summary_counts || {};
    html += `<div class="results-header">
      <div class="results-title">Assessment results</div>
      <button class="btn btn-sm btn-export" onclick="exportJSON('${job.job_id}')">&#11015; Export JSON</button>
    </div>
    <div class="summary-bar">
      <div class="stat-card stat-applicable"><div class="stat-num">${sc.APPLICABLE||0}</div><div class="stat-label">Applicable</div></div>
      <div class="stat-card stat-not"><div class="stat-num">${sc.NOT_APPLICABLE||0}</div><div class="stat-label">Not affected</div></div>
      <div class="stat-card stat-review"><div class="stat-num">${sc.NEEDS_REVIEW||0}</div><div class="stat-label">Needs review</div></div>
      <div class="stat-card"><div class="stat-num">${(job.results||[]).length}</div><div class="stat-label">Total devices</div></div>
    </div>`;
  } else {
    const pct = job.progress || 0;
    html += `<div class="results-header"><div class="results-title"><span class="spinner"></span> Running… ${pct}%</div></div>
    <div class="progress-wrap"><div class="progress-bar-bg"><div class="progress-bar-fill" style="width:${pct}%"></div></div></div>`;
  }
  for (const r of (job.results || [])) {
    const open = (r.verdict==='APPLICABLE'||r.verdict==='NEEDS_REVIEW')?'open':'';
    const cardId = 'dc-'+((r.hostname||r.host||Math.random()).toString().replace(/[^a-z0-9]/gi,'_'));
    const drawerId = cardId+'_why';
    html += `<div class="device-card ${open}" id="${cardId}">
      <div class="device-card-header" onclick="toggleCard('${cardId}')">
        <span class="device-hostname">${r.hostname||r.host||'—'}</span>
        <span class="device-meta">${r.host||''} · ${r.platform||''} · ${r.version||r.dnac_version||''}</span>
        ${verdictBadge(r.verdict)}
        <button class="why-btn" onclick="event.stopPropagation();toggleWhy('${drawerId}')">Why?</button>
        <span style="color:var(--text3);font-size:12px;margin-left:4px">▾</span>
      </div>
      <div class="device-card-body">
        <div class="why-drawer" id="${drawerId}">${buildWhyDrawer(r)}</div>
      </div>
    </div>`;
  }
  if (!job.results||!job.results.length) html += `<div class="empty-state"><span class="spinner"></span><br><br>Connecting to devices…</div>`;
  area.innerHTML = html;
};

function buildWhyDrawer(r) {
  const vClass = r.verdict==='APPLICABLE'?'vp-app':r.verdict==='NOT_APPLICABLE'?'vp-na':'vp-nr';
  const vLabel = r.verdict==='APPLICABLE'?'Applicable':r.verdict==='NOT_APPLICABLE'?'Not applicable':'Needs review';
  let html = `<div style="margin-bottom:8px"><span class="verdict-pill ${vClass}">${vLabel}</span></div>`;
  if (r.summary) html += `<p style="margin:0 0 8px;font-size:12px;line-height:1.6;color:var(--text)">${r.summary}</p>`;
  const dotC = res => res==='PASS'?'dot-pass':res==='FAIL'?'dot-fail':'dot-unknown';
  if (r.layer1||r.layer2||r.layer3) {
    html += `<div class="why-layers">`;
    [[r.layer1,'L1 · Platform'],[r.layer2,'L2 · Version'],[r.layer3,'L3 · Feature']].forEach(([l,name]) => {
      if (!l) return;
      const res = typeof l==='object'?l.result:l, det = typeof l==='object'?(l.detail||''):'';
      html += `<div class="why-layer-name"><span class="layer-dot ${dotC(res)}" style="display:inline-block;vertical-align:middle;margin-right:5px"></span>${name}</div>
               <div class="why-layer-detail">${det||res}</div>`;
    });
    html += `</div>`;
  }
  if (r.evidence) html += `<div class="why-evidence">${r.evidence}</div>`;
  if (r.action) html += `<div class="why-action">⟶ ${r.action}</div>`;
  if (r.collection_error) html += `<div style="margin-top:8px;font-size:11px;font-family:var(--mono);color:var(--red)">Collection error: ${r.collection_error}</div>`;
  return html;
}

function toggleCard(id) { document.getElementById(id).classList.toggle('open'); }
function toggleWhy(id) { const el=document.querySelector('[id="'+id+'"]'); if(el) el.classList.toggle('open'); }
function toggleDashAdv(id) { const el=document.getElementById(id); if(!el)return; el.style.display=(el.style.display==='none'||!el.style.display)?'table-row':'none'; }

function renderLog(job) {
  const logs = job.log || [];
  document.getElementById('log-area').innerHTML = logs.length
    ? `<div class="log-box">${logs.map(l => '› ' + l).join('\n')}</div>`
    : '<div class="empty-state">No log entries yet.</div>';
}

function renderHistory() {
  const area = document.getElementById('history-area');
  if (!jobHistory.length) { area.innerHTML = '<div class="empty-state">No completed jobs yet.</div>'; return; }
  area.innerHTML = jobHistory.map(j => {
    const sc = j.summary_counts || {};
    let label = (j.advisory_profile||{}).cve || '';
    if (!label && j.results && j.results.length) {
      const advIds = [...new Set(j.results.map(r=>r.advisory_id).filter(Boolean))];
      label = advIds.length===1 ? advIds[0].replace('cisco-sa-','') : `${advIds.length} advisories`;
    }
    label = label || 'Unknown advisory';
    return `<div style="display:flex;align-items:center;gap:12px;padding:10px 0;border-bottom:1px solid var(--border);font-family:monospace;font-size:12px">
      <span style="color:var(--text3)">${j.job_id}</span>
      <span style="flex:1">${label}</span>
      <span style="color:var(--green)">${sc.APPLICABLE||0} applicable</span>
      <span style="color:var(--red)">${sc.NOT_APPLICABLE||0} false positive</span>
      <span style="color:var(--amber)">${sc.NEEDS_REVIEW||0} review</span>
      <button class="btn btn-sm btn-export" onclick="exportJSON('${j.job_id}')">&#11015; JSON</button>
    </div>`;
  }).join('');
}

function exportJSON(jobId) { window.open(`/api/job/${jobId}/export`, '_blank'); }

function showTab(name) {
  const names = ['results','dashboard','log','history','dbresults'];
  document.querySelectorAll('.tab').forEach((t,i) => t.classList.toggle('active', names[i]===name));
  document.querySelectorAll('.tab-content').forEach(tc => tc.classList.toggle('active', tc.id==='tab-'+name));
  if (name==='dashboard') renderDashboard(window._lastJob||{results:[]});
}

// ── Scan DB tab ───────────────────────────────────────────────────────────────
let _dbRefreshInterval = null;

function toggleDbAutoRefresh() {
  const btn = document.getElementById('db-refresh-btn');
  const status = document.getElementById('db-refresh-status');
  if (_dbRefreshInterval) {
    clearInterval(_dbRefreshInterval); _dbRefreshInterval = null;
    btn.textContent = '⟳ Auto-refresh'; status.textContent = '';
  } else {
    _dbRefreshInterval = setInterval(loadDbResults, 10000);
    btn.textContent = '⏹ Stop refresh'; status.textContent = 'Refreshing every 10 s…';
    loadDbResults();
  }
}

async function loadDbResults() {
  const dnacId = (document.getElementById('db-dnac-id').value || '').trim() || null;
  const area   = document.getElementById('db-results-area');
  area.innerHTML = '<div class="empty-state"><span class="spinner"></span><br><br>Loading from database…</div>';
  try {
    const qs = dnacId ? '?dnac_id=' + encodeURIComponent(dnacId) : '';
    const [diagResp, summResp] = await Promise.all([
      fetch('/api/diagnose' + qs),
      fetch('/api/applicability_summary' + qs),
    ]);
    const diag = await diagResp.json();
    const summ = await summResp.json();
    if (diag.error) { area.innerHTML = '<div class="empty-state" style="color:var(--red)">Error: ' + diag.error + '</div>'; return; }
    renderDbResults(diag, summ);
  } catch(e) {
    area.innerHTML = '<div class="empty-state" style="color:var(--red)">Network error: ' + e.message + '</div>';
  }
}

function renderDbResults(diag, summ) {
  const area      = document.getElementById('db-results-area');
  const counts    = summ.counts || {};
  const total     = diag.total_checked || 0;
  const methods   = diag.collection_methods || {};
  const nrReasons = diag.needs_review_reasons || {};
  const breakdown = diag.breakdown || [];

  if (!total && !breakdown.length) {
    area.innerHTML = '<div class="empty-state">No scan results found in the database for this DNAC.<br><br>Run a scan first:<br><code style="background:var(--surface2);padding:3px 8px;border-radius:4px">python run_scan.py --dnac &lt;id&gt;</code></div>';
    return;
  }

  const vBadge = v => ({
    APPLICABLE:     '<span class="badge badge-applicable">Applicable</span>',
    NOT_APPLICABLE: '<span class="badge badge-not">Not applicable</span>',
    NEEDS_REVIEW:   '<span class="badge badge-review">Needs review</span>',
    PENDING:        '<span class="badge badge-pending">Pending</span>',
    MITIGATED:      '<span class="badge" style="background:#e8f0fb;color:var(--blue)">Mitigated</span>',
  }[v] || '<span class="badge badge-pending">' + (v||'—') + '</span>');

  const methodLabel = m => ({
    dnac_command_runner:       '🌐 DNAC command runner',
    ssh_fallback:              '🔒 SSH fallback',
    version_only:              '📋 Version only',
    version_only_insufficient: '📋 Version only (insufficient)',
    pending:                   '⏳ Pending',
  }[m] || m || '—');

  const nrLabel = r => ({
    no_fixed_release:  'No fixed release published',
    collection_failed: 'Command collection failed',
    insufficient_data: 'Insufficient version data',
    unknown:           'Unknown',
  }[r] || r || 'Unknown');

  // ── Summary stat cards ─────────────────────────────────────────────────────
  let html = '<div class="summary-bar" style="flex-wrap:wrap;margin-bottom:16px">';
  html += '<div class="stat-card stat-applicable"><div class="stat-num">' + (counts.APPLICABLE||0) + '</div><div class="stat-label">Applicable</div></div>';
  html += '<div class="stat-card stat-not"><div class="stat-num">'        + (counts.NOT_APPLICABLE||0) + '</div><div class="stat-label">Not applicable</div></div>';
  html += '<div class="stat-card stat-review"><div class="stat-num">'     + (counts.NEEDS_REVIEW||0) + '</div><div class="stat-label">Needs review</div></div>';
  html += '<div class="stat-card"><div class="stat-num" style="color:var(--blue)">' + (counts.MITIGATED||0) + '</div><div class="stat-label">Mitigated</div></div>';
  html += '<div class="stat-card"><div class="stat-num" style="color:var(--text3)">' + (counts.PENDING||0) + '</div><div class="stat-label">Pending</div></div>';
  html += '<div class="stat-card"><div class="stat-num">' + total + '</div><div class="stat-label">Total checked</div></div>';
  html += '</div>';

  // ── Collection methods + NR reasons side-by-side ───────────────────────────
  html += '<div class="dash-charts-row" style="margin-bottom:16px">';
  html += '<div class="dash-card"><p class="dash-card-title">Collection methods</p>';
  html += '<table style="width:100%;font-size:12px;font-family:var(--mono)"><thead><tr>';
  html += '<th style="text-align:left;padding:4px 0;color:var(--text3);font-size:10px;text-transform:uppercase;letter-spacing:.06em">Method</th>';
  html += '<th style="text-align:right;padding:4px 0;color:var(--text3);font-size:10px;text-transform:uppercase;letter-spacing:.06em">Count</th>';
  html += '</tr></thead><tbody>';
  const mEntries = Object.entries(methods);
  if (mEntries.length) {
    mEntries.forEach(([m,c]) => { html += '<tr><td style="padding:6px 0">' + methodLabel(m) + '</td><td style="text-align:right;font-weight:600">' + c + '</td></tr>'; });
  } else { html += '<tr><td colspan="2" style="color:var(--text3);padding:6px 0">No data</td></tr>'; }
  html += '</tbody></table></div>';

  html += '<div class="dash-card"><p class="dash-card-title">Needs review — reasons</p>';
  html += '<table style="width:100%;font-size:12px;font-family:var(--mono)"><thead><tr>';
  html += '<th style="text-align:left;padding:4px 0;color:var(--text3);font-size:10px;text-transform:uppercase;letter-spacing:.06em">Reason</th>';
  html += '<th style="text-align:right;padding:4px 0;color:var(--text3);font-size:10px;text-transform:uppercase;letter-spacing:.06em">Count</th>';
  html += '</tr></thead><tbody>';
  const nrEntries = Object.entries(nrReasons);
  if (nrEntries.length) {
    nrEntries.forEach(([r,c]) => { html += '<tr><td style="padding:6px 0">' + nrLabel(r) + '</td><td style="text-align:right;font-weight:600;color:var(--amber)">' + c + '</td></tr>'; });
  } else { html += '<tr><td colspan="2" style="color:var(--text3);padding:6px 0">None</td></tr>'; }
  html += '</tbody></table></div>';
  html += '</div>';

  // ── Filter bar ─────────────────────────────────────────────────────────────
  html += '<div style="display:flex;gap:8px;margin-bottom:12px;align-items:center;flex-wrap:wrap">';
  html += '<span style="font-size:11px;color:var(--text3);font-family:monospace">Filter:</span>';
  const filters = [
    ['ALL',           'All (' + total + ')',                         'var(--text)'],
    ['APPLICABLE',    'Applicable (' + (counts.APPLICABLE||0) + ')', 'var(--green)'],
    ['NOT_APPLICABLE','Not applicable (' + (counts.NOT_APPLICABLE||0) + ')', 'var(--red)'],
    ['NEEDS_REVIEW',  'Needs review (' + (counts.NEEDS_REVIEW||0) + ')',     'var(--amber)'],
    ['PENDING',       'Pending (' + (counts.PENDING||0) + ')',       'var(--text3)'],
  ];
  filters.forEach(([v, label, color]) => {
    html += '<button class="btn btn-sm" id="db-filter-' + v + '" style="color:' + color + '" onclick="filterDbTable(\'' + v + '\')">' + label + '</button>';
  });
  html += '<input type="text" id="db-search" placeholder="Search advisory / hostname…" style="width:200px;font-size:12px;padding:5px 8px;margin-left:auto" oninput="filterDbTable(window._dbFilter||\'ALL\')" />';
  html += '</div>';

  // ── Breakdown table ────────────────────────────────────────────────────────
  html += '<div class="device-table-wrap"><table id="db-table">';
  html += '<thead><tr><th>Advisory ID</th><th>Hostname</th><th>SW Version</th><th>Verdict</th><th>Method</th><th></th></tr></thead>';
  html += '<tbody id="db-tbody">';

  breakdown.forEach((r, idx) => {
    const safeId   = 'db_why_' + idx;
    const advShort = (r.advisoryId || '—').replace('cisco-sa-', '');
    const searchKey = ((r.advisoryId||'') + ' ' + (r.hostname||'')).toLowerCase();
    html += '<tr class="db-row" data-verdict="' + (r.verdict||'') + '" data-search="' + searchKey + '">';
    html += '<td style="font-family:monospace;font-size:11px;max-width:180px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="' + (r.advisoryId||'') + '">' + advShort + '</td>';
    html += '<td style="font-family:monospace;font-size:12px;font-weight:600">' + (r.hostname||'—') + '</td>';
    html += '<td style="font-family:monospace;font-size:11px">' + (r.softwareVersion||'—') + '</td>';
    html += '<td>' + vBadge(r.verdict) + '</td>';
    html += '<td style="font-size:11px;color:var(--text3);font-family:monospace;white-space:nowrap">' + methodLabel(r.collection_method) + '</td>';
    html += '<td><button class="why-btn" onclick="toggleDbWhy(\'' + safeId + '\')">Why?</button></td>';
    html += '</tr>';
    // Collapsible detail row
    html += '<tr class="db-why-row" data-verdict="' + (r.verdict||'') + '" data-search="' + searchKey + '" style="display:none">';
    html += '<td colspan="6" style="padding:0;background:var(--surface2)">';
    html += '<div id="' + safeId + '" style="padding:12px 16px">';
    html += buildWhyDrawer(r);
    if (r.summary) html += '<div style="margin-top:8px;font-size:12px;color:var(--text2);line-height:1.6">' + r.summary + '</div>';
    if (r.action)  html += '<div class="why-action" style="margin-top:6px">⟶ ' + r.action + '</div>';
    if (r.mitigation && r.mitigation.mitigated) {
      html += '<div style="margin-top:6px;font-size:11px;color:var(--blue);font-family:var(--mono)">🛡 Compensating controls detected (confidence: ' + (r.mitigation.mitigation_confidence||'?') + ')</div>';
    }
    html += '</div></td></tr>';
  });

  html += '</tbody></table></div>';
  area.innerHTML = html;
  window._dbFilter = 'ALL';
  // Highlight All filter as active
  const allBtn = document.getElementById('db-filter-ALL');
  if (allBtn) allBtn.style.fontWeight = '700';
}

function toggleDbWhy(id) {
  const whyRow = document.getElementById(id);
  if (!whyRow) return;
  const tr = whyRow.closest('tr');
  tr.style.display = tr.style.display === 'none' ? '' : 'none';
}

function filterDbTable(verdict) {
  window._dbFilter = verdict;
  const search = ((document.getElementById('db-search') || {}).value || '').toLowerCase();
  document.querySelectorAll('#db-tbody .db-row').forEach(row => {
    const matchV = verdict === 'ALL' || row.dataset.verdict === verdict;
    const matchS = !search || (row.dataset.search || '').includes(search);
    const show   = matchV && matchS;
    row.style.display = show ? '' : 'none';
    const whyRow = row.nextElementSibling;
    if (whyRow && whyRow.classList.contains('db-why-row')) {
      // Keep why-rows hidden unless already expanded
      if (!show) whyRow.style.display = 'none';
    }
  });
  ['ALL','APPLICABLE','NOT_APPLICABLE','NEEDS_REVIEW','PENDING'].forEach(v => {
    const btn = document.getElementById('db-filter-' + v);
    if (btn) btn.style.fontWeight = v === verdict ? '700' : '400';
  });
}

let _dashCharts = [];
function renderDashboard(job) {
  const area = document.getElementById('dashboard-area');
  const results = job.results || [];
  if (!results.length) { area.innerHTML = '<div class="empty-state">No results yet.</div>'; return; }
  _dashCharts.forEach(c => { try{c.destroy();}catch(e){} }); _dashCharts = [];
  const counts={APPLICABLE:0,NOT_APPLICABLE:0,NEEDS_REVIEW:0};
  const advMap={}, famMap={}, verMap={}, methodMap={dnac_command_runner:0,ssh_fallback:0,unknown:0};
  const shortId = id => (id||'').replace('cisco-sa-','').split('-').slice(0,3).join('-');
  results.forEach(r => {
    const v=r.verdict||'NEEDS_REVIEW'; counts[v]=(counts[v]||0)+1;
    const aid=r.advisory_id||'unknown';
    if (!advMap[aid]) advMap[aid]={APPLICABLE:0,NOT_APPLICABLE:0,NEEDS_REVIEW:0,total:0};
    advMap[aid][v]++; advMap[aid].total++;
    const fam=r.dnac_family||'Unknown';
    if (!famMap[fam]) famMap[fam]={APPLICABLE:0,NOT_APPLICABLE:0,NEEDS_REVIEW:0};
    famMap[fam][v]++;
    const ver=(r.dnac_version||r.version||'').split('.').slice(0,2).join('.')+'.x';
    if (ver!=='.x') verMap[ver]=(verMap[ver]||0)+1;
    const m=r.collection_method||'unknown'; methodMap[m]=(methodMap[m]||0)+1;
  });
  const total=results.length, pct=n=>Math.round((n/total)*100), advIds=Object.keys(advMap);
  let advRows='';
  advIds.forEach(aid => {
    const d=advMap[aid], maxW=150;
    const appW=Math.max(Math.round((d.APPLICABLE/d.total)*maxW),d.APPLICABLE?3:0);
    const naW=Math.max(Math.round((d.NOT_APPLICABLE/d.total)*maxW),d.NOT_APPLICABLE?3:0);
    const nrW=Math.max(Math.round((d.NEEDS_REVIEW/d.total)*maxW),d.NEEDS_REVIEW?3:0);
    const badge=d.NEEDS_REVIEW>0?'<span class="badge badge-review">Review</span>':d.APPLICABLE>0?'<span class="badge badge-applicable">Applicable</span>':'<span class="badge badge-not">Clean</span>';
    advRows+=`<tr>
      <td style="font-size:12px;max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="${aid}">${shortId(aid)}</td>
      <td style="font-weight:600">${d.total}</td>
      <td><div class="mini-bar-wrap">
        ${appW?`<div class="mini-bar-seg" style="background:#46a846;width:${appW}px" title="${d.APPLICABLE} applicable"></div>`:''}
        ${naW?`<div class="mini-bar-seg" style="background:#dc3232;width:${naW}px" title="${d.NOT_APPLICABLE} not applicable"></div>`:''}
        ${nrW?`<div class="mini-bar-seg" style="background:#d4901a;width:${nrW}px" title="${d.NEEDS_REVIEW} needs review"></div>`:''}
        <span style="font-size:10px;color:var(--text3);margin-left:5px">${d.APPLICABLE}A · ${d.NOT_APPLICABLE}N · ${d.NEEDS_REVIEW}R</span>
      </div></td>
      <td>${badge}</td>
      <td><button class="why-btn" onclick="toggleDashAdv('dash_adv_${aid.replace(/[^a-z0-9]/gi,'_')}')">▾ Devices</button></td>
    </tr>
    <tr id="dash_adv_${aid.replace(/[^a-z0-9]/gi,'_')}" style="display:none">
      <td colspan="5" style="padding:0;background:var(--surface2)">
        <div style="padding:8px 12px">
          ${results.filter(r=>(r.advisory_id||'unknown')===aid).map(r => {
            const vbadge=r.verdict==='APPLICABLE'?'badge-applicable':r.verdict==='NOT_APPLICABLE'?'badge-not':'badge-review';
            const vLabel=r.verdict==='APPLICABLE'?'Confirmed':r.verdict==='NOT_APPLICABLE'?'False Positive':'Needs Review';
            const dId='dash_why_'+((r.hostname||r.host||'x')+'_'+(r.advisory_id||'x')).replace(/[^a-z0-9]/gi,'_');
            return `<div style="padding:8px 0;border-bottom:1px solid var(--border)">
              <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap">
                <span style="font-family:monospace;font-size:12px;font-weight:600;flex:1">${r.hostname||r.host||'—'}</span>
                <span style="font-size:11px;color:var(--text3);font-family:monospace">${r.dnac_version||r.version||'?'}</span>
                <span class="badge ${vbadge}" style="font-size:10px">${vLabel}</span>
                <button class="why-btn" onclick="toggleWhy('${dId}')">Why?</button>
              </div>
              <div class="why-drawer" id="${dId}">${buildWhyDrawer(r)}</div>
            </div>`;
          }).join('')}
        </div>
      </td>
    </tr>`;
  });
  const fams=Object.keys(famMap), verKeys=Object.keys(verMap).sort();
  const verH=Math.max(160,verKeys.length*36+60);
  const collLabels=Object.keys(methodMap).filter(k=>methodMap[k]>0);
  const collColors={dnac_command_runner:'#3b82f6',ssh_fallback:'#8b5cf6',unknown:'#888'};
  area.innerHTML=`<div style="padding:0.5rem 0 1.5rem">
    <div class="dash-metric-grid">
      <div class="dash-metric"><p class="dash-metric-label">Pairs assessed</p><p class="dash-metric-value" style="color:var(--text)">${total}</p><p class="dash-metric-sub">${advIds.length} advisories</p></div>
      <div class="dash-metric"><p class="dash-metric-label">Confirmed applicable</p><p class="dash-metric-value" style="color:var(--green)">${counts.APPLICABLE}</p><p class="dash-metric-sub">${pct(counts.APPLICABLE)}% of pairs</p></div>
      <div class="dash-metric"><p class="dash-metric-label">Not applicable (False Positive)</p><p class="dash-metric-value" style="color:var(--red)">${counts.NOT_APPLICABLE}</p><p class="dash-metric-sub">${pct(counts.NOT_APPLICABLE)}% of pairs</p></div>
      <div class="dash-metric"><p class="dash-metric-label">Needs review</p><p class="dash-metric-value" style="color:var(--amber)">${counts.NEEDS_REVIEW}</p><p class="dash-metric-sub">${pct(counts.NEEDS_REVIEW)}% of pairs</p></div>
    </div>
    <div class="dash-charts-row">
      <div class="dash-card"><p class="dash-card-title">Verdict distribution</p>
        <div class="dash-legend">
          <span><span class="dash-legend-dot" style="background:#46a846"></span>Applicable ${counts.APPLICABLE}</span>
          <span><span class="dash-legend-dot" style="background:#dc3232"></span>False Positive ${counts.NOT_APPLICABLE}</span>
          <span><span class="dash-legend-dot" style="background:#d4901a"></span>Needs review ${counts.NEEDS_REVIEW}</span>
        </div>
        <div style="position:relative;width:100%;height:200px"><canvas id="dash-donut"></canvas></div>
      </div>
      <div class="dash-card"><p class="dash-card-title">Verdicts per advisory</p>
        <div class="dash-legend">
          <span><span class="dash-legend-dot" style="background:#46a846"></span>Applicable</span>
          <span><span class="dash-legend-dot" style="background:#dc3232"></span>False Positive</span>
          <span><span class="dash-legend-dot" style="background:#d4901a"></span>Needs review</span>
        </div>
        <div style="position:relative;width:100%;height:200px"><canvas id="dash-bar"></canvas></div>
      </div>
    </div>
    <div class="dash-card" style="margin-bottom:14px"><p class="dash-card-title">Advisory breakdown</p>
      <table class="adv-breakdown-table">
        <thead><tr><th>Advisory</th><th>Devices</th><th style="min-width:180px">Verdict spread</th><th>Status</th><th>Reason</th></tr></thead>
        <tbody>${advRows}</tbody>
      </table>
    </div>
    <div class="dash-charts-row">
      <div class="dash-card"><p class="dash-card-title">By device family</p>
        <div style="position:relative;width:100%;height:180px"><canvas id="dash-fam"></canvas></div>
      </div>
      <div class="dash-card"><p class="dash-card-title">Collection method</p>
        <div class="dash-legend">
          <span><span class="dash-legend-dot" style="background:#3b82f6"></span>DNAC ${methodMap.dnac_command_runner||0}</span>
          <span><span class="dash-legend-dot" style="background:#8b5cf6"></span>SSH fallback ${methodMap.ssh_fallback||0}</span>
        </div>
        <div style="position:relative;width:100%;height:180px"><canvas id="dash-coll"></canvas></div>
      </div>
    </div>
    <div class="dash-card"><p class="dash-card-title">Software version distribution</p>
      <div style="position:relative;width:100%;height:${verH}px"><canvas id="dash-ver"></canvas></div>
    </div>
  </div>`;

  requestAnimationFrame(() => {
    if (typeof Chart === 'undefined') { setTimeout(() => renderDashboard(job), 300); return; }
    _dashCharts.push(new Chart(document.getElementById('dash-donut'),{type:'doughnut',data:{labels:['Applicable','Not applicable','Needs review'],datasets:[{data:[counts.APPLICABLE,counts.NOT_APPLICABLE,counts.NEEDS_REVIEW],backgroundColor:['#46a846','#dc3232','#d4901a'],borderWidth:0,hoverOffset:6}]},options:{responsive:true,maintainAspectRatio:false,cutout:'65%',plugins:{legend:{display:false}}}}));
    _dashCharts.push(new Chart(document.getElementById('dash-bar'),{type:'bar',data:{labels:advIds.map(shortId),datasets:[{label:'Applicable',data:advIds.map(a=>advMap[a].APPLICABLE),backgroundColor:'#46a846',borderRadius:2},{label:'Not applicable',data:advIds.map(a=>advMap[a].NOT_APPLICABLE),backgroundColor:'#dc3232',borderRadius:2},{label:'Needs review',data:advIds.map(a=>advMap[a].NEEDS_REVIEW),backgroundColor:'#d4901a',borderRadius:2}]},options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{display:false}},scales:{x:{stacked:true,ticks:{font:{size:9},autoSkip:false,maxRotation:40},grid:{display:false}},y:{stacked:true,ticks:{font:{size:10}},grid:{color:'rgba(128,128,128,.1)'}}}}}));
    _dashCharts.push(new Chart(document.getElementById('dash-fam'),{type:'bar',data:{labels:fams,datasets:[{label:'Applicable',data:fams.map(f=>famMap[f].APPLICABLE),backgroundColor:'#46a846',borderRadius:2},{label:'Not applicable',data:fams.map(f=>famMap[f].NOT_APPLICABLE),backgroundColor:'#dc3232',borderRadius:2},{label:'Needs review',data:fams.map(f=>famMap[f].NEEDS_REVIEW),backgroundColor:'#d4901a',borderRadius:2}]},options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{display:false}},scales:{x:{stacked:true,ticks:{font:{size:10}},grid:{display:false}},y:{stacked:true,ticks:{font:{size:10}},grid:{color:'rgba(128,128,128,.1)'}}}}}));
    _dashCharts.push(new Chart(document.getElementById('dash-coll'),{type:'doughnut',data:{labels:collLabels,datasets:[{data:collLabels.map(k=>methodMap[k]),backgroundColor:collLabels.map(k=>collColors[k]||'#888'),borderWidth:0,hoverOffset:4}]},options:{responsive:true,maintainAspectRatio:false,cutout:'58%',plugins:{legend:{display:false}}}}));
    _dashCharts.push(new Chart(document.getElementById('dash-ver'),{type:'bar',data:{labels:verKeys,datasets:[{label:'Devices',data:verKeys.map(k=>verMap[k]),backgroundColor:'#3b82f6',borderRadius:3,barPercentage:0.6}]},options:{indexAxis:'y',responsive:true,maintainAspectRatio:false,plugins:{legend:{display:false}},scales:{x:{ticks:{font:{size:10}},grid:{color:'rgba(128,128,128,.1)'}},y:{ticks:{font:{size:10}},grid:{display:false}}}}}));
  });
}

renderDeviceTable();

function dnacCreds() {
  const host=document.getElementById('dnac-host').value.trim();
  const port=document.getElementById('dnac-port').value.trim()||'443';
  return {
    host: host.includes(':')?host:`${host}:${port}`,
    username: document.getElementById('dnac-user').value.trim(),
    password: document.getElementById('dnac-pass').value,
    verify_ssl: document.getElementById('dnac-verify-ssl').checked,
    ssh_username: document.getElementById('dnac-ssh-user').value.trim(),
    ssh_password: document.getElementById('dnac-ssh-pass').value,
  };
}
function dnacMsg(text, color) {
  const el=document.getElementById('dnac-msg'); el.style.color=color||'var(--text3)'; el.textContent=text;
}
function dnacSetDot(status) {
  const dot=document.getElementById('dnac-status-dot');
  const colors={ok:'#22c55e',error:'#ef4444',loading:'#f59e0b'};
  dot.style.background=colors[status]||'var(--text3)';
  dot.title=status==='ok'?'Connected':status==='error'?'Connection failed':'Connecting...';
}
async function dnacTest() {
  const c=dnacCreds();
  if (!c.host||!c.username||!c.password){dnacMsg('Host, username, and password required.','var(--red)');return;}
  dnacMsg('Testing connection...','var(--text3)'); dnacSetDot('loading');
  try {
    const r=await fetch('/api/dnac/test',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(c)});
    const d=await r.json();
    if (!r.ok){dnacMsg('Error: '+d.error,'var(--red)');dnacSetDot('error');}
    else{dnacMsg(d.message||'Connected!','#22c55e');dnacSetDot('ok');}
  } catch(e){dnacMsg('Network error: '+e.message,'var(--red)');dnacSetDot('error');}
}
async function dnacFetchDevices() {
  const c=dnacCreds();
  if (!c.host||!c.username||!c.password){dnacMsg('Host, username, and password required.','var(--red)');return;}
  dnacMsg('Fetching devices...','var(--text3)'); dnacSetDot('loading');
  try {
    const r=await fetch('/api/dnac/devices',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(c)});
    const d=await r.json();
    if (!r.ok){dnacMsg('Error: '+d.error,'var(--red)');dnacSetDot('error');return;}
    const existing=new Set(devices.map(d=>d.host)); let added=0;
    for (const dev of d.devices){if (!existing.has(dev.host)){devices.push(dev);existing.add(dev.host);added++;}}
    renderDeviceTable(); dnacSetDot('ok');
    dnacMsg(`Imported ${added} new device(s) (${d.count} total from DNAC).`,'#22c55e');
  } catch(e){dnacMsg('Network error: '+e.message,'var(--red)');dnacSetDot('error');}
}
function openDnacAdvisories(){document.getElementById('dnac-adv-panel').style.display='block';document.getElementById('dnac-adv-list').innerHTML='<span style="color:var(--text3)">Click "Fetch from DNAC" to load advisories.</span>';}
function closeDnacAdvisories(){document.getElementById('dnac-adv-panel').style.display='none';}
async function dnacFetchAdvisories() {
  const c=dnacCreds();
  if (!c.host||!c.username||!c.password){dnacMsg('Host, username, and password required.','var(--red)');return;}
  const includeAffected=document.getElementById('dnac-adv-include-affected').checked;
  const listEl=document.getElementById('dnac-adv-list');
  listEl.innerHTML='<span style="color:var(--text3)">Loading advisories from DNAC...</span>'; dnacSetDot('loading');
  try {
    const r=await fetch('/api/dnac/advisories',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({...c,include_affected_devices:includeAffected})});
    const d=await r.json();
    if (!r.ok){listEl.innerHTML=`<span style="color:var(--red)">Error: ${d.error}</span>`;dnacSetDot('error');return;}
    dnacSetDot('ok'); dnacMsg(`${d.count} advisories loaded.`,'#22c55e');
    if (!d.advisories.length){listEl.innerHTML='<span style="color:var(--text3)">No advisories found.</span>';return;}
    document.getElementById('dnac-run-selected-btn').style.display='block';
    const sirColors={Critical:'#ef4444',High:'#f97316',Medium:'#eab308',Low:'#22c55e'};
    listEl.innerHTML=d.advisories.map((adv,i)=>{
      const sirColor=sirColors[adv.sir]||'var(--text3)';
      const affectedInfo=adv.affectedDeviceCount!=null?`<span style="color:var(--text3)"> | ${adv.affectedDeviceCount} device(s)</span>`:'';
      return `<div style="border:1px solid var(--border);border-radius:4px;padding:7px 9px;margin-bottom:5px;background:var(--surface)">
        <div style="display:flex;align-items:center;gap:6px;flex-wrap:wrap">
          <input type="checkbox" class="dnac-adv-checkbox" data-id="${adv.advisoryId}" data-index="${i}" checked style="flex-shrink:0;cursor:pointer" onchange="dnacUpdateRunBtn()" />
          <span style="font-weight:bold;flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-family:monospace;font-size:11px" title="${adv.advisoryId}">${adv.advisoryId}</span>
          <span style="color:${sirColor};font-size:10px;font-weight:bold;white-space:nowrap">${adv.sir||''}${affectedInfo}</span>
        </div>
        ${adv.cves.length?`<div style="color:var(--text3);font-size:10px;margin-top:2px;padding-left:20px">${adv.cves.join(', ')}</div>`:''}
        <div style="display:flex;gap:5px;margin-top:5px;flex-wrap:wrap;padding-left:20px">
          <button class="btn btn-sm btn-primary" style="font-size:10px;padding:2px 7px" onclick="dnacUseAdvisory(${i})">Use advisory</button>
          ${includeAffected&&adv.affectedDevices&&adv.affectedDevices.length?`<button class="btn btn-sm" style="font-size:10px;padding:2px 7px" onclick="dnacImportAffectedDevices(${i})">Import ${adv.affectedDevices.length} affected</button>`:''}
        </div>
      </div>`;
    }).join('');
    dnacUpdateRunBtn();
    window._dnacAdvisories=d.advisories;
  } catch(e){listEl.innerHTML=`<span style="color:var(--red)">Network error: ${e.message}</span>`;dnacSetDot('error');}
}
function dnacUseAdvisory(i){const adv=(window._dnacAdvisories||[])[i];if(!adv)return;document.getElementById('advisory-text').value=adv.advisoryText;dnacMsg('Advisory loaded.','#22c55e');}
async function dnacImportAffectedDevices(i) {
  const adv=(window._dnacAdvisories||[])[i]; if(!adv)return;
  const c=dnacCreds(), sshUser=c.ssh_username||c.username, sshPass=c.ssh_password||c.password;
  let devicesToAdd=adv.affectedDevices||[];
  if (!devicesToAdd.length){
    try{
      const r=await fetch(`/api/dnac/advisory/${encodeURIComponent(adv.advisoryId)}/devices`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(c)});
      const d=await r.json(); if(!r.ok){dnacMsg('Error: '+d.error,'var(--red)');return;} devicesToAdd=d.devices;
    }catch(e){dnacMsg('Error: '+e.message,'var(--red)');return;}
  } else {
    devicesToAdd=devicesToAdd.map(d=>({host:d.managementIp||'',hostname:d.hostname||d.managementIp||'',port:22,username:sshUser,password:sshPass,device_type:'cisco_xe',platform:d.platformId||''})).filter(d=>d.host);
  }
  const existing=new Set(devices.map(d=>d.host)); let added=0;
  for (const d of devicesToAdd){if(d.host&&!existing.has(d.host)){devices.push(d);existing.add(d.host);added++;}}
  renderDeviceTable(); dnacMsg(`Imported ${added} affected device(s).`,'#22c55e');
}
function dnacSelectAll(checked){document.querySelectorAll('.dnac-adv-checkbox').forEach(cb=>cb.checked=checked);dnacUpdateRunBtn();}
function dnacUpdateRunBtn(){
  const checked=document.querySelectorAll('.dnac-adv-checkbox:checked'), btn=document.getElementById('dnac-run-selected-btn');
  if(!btn)return;
  if(checked.length===0){btn.textContent='Select at least one advisory';btn.disabled=true;}
  else{btn.disabled=false;btn.innerHTML=`&#9654; Assess ${checked.length} Selected Advisor${checked.length===1?'y':'ies'}`;}
}
async function dnacAssessAll() {
  const c=dnacCreds();
  if (!c.host||!c.username||!c.password){dnacMsg('Host, username, and password required.','var(--red)');return;}
  dnacMsg('Starting bulk assessment...','var(--text3)'); dnacSetDot('loading');
  try{
    const r=await fetch('/api/dnac/assess-all',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(c)});
    const d=await r.json();
    if(!r.ok){dnacMsg('Error: '+d.error,'var(--red)');dnacSetDot('error');return;}
    dnacMsg('Bulk job started.','#22c55e'); dnacSetDot('ok');
    showTab('results'); startPolling(d.job_id);
  }catch(e){dnacMsg('Error: '+e.message,'var(--red)');dnacSetDot('error');}
}

const _renderResultsBase=renderResults;
renderResults=function(job){
  window._lastJob=job;
  if(job.job_type==='dnac_bulk'){renderBulkResults(job);if(document.getElementById('tab-dashboard').classList.contains('active'))renderDashboard(job);}
  else{_renderResultsBase(job);}
};

function renderBulkResults(job) {
  const el=document.getElementById('results-area'); if(!el)return;
  const counts=job.summary_counts||{}, pairs=job.results||[];
  const byAdvisory={};
  for(const p of pairs){const aid=p.advisory_id||'Unknown';if(!byAdvisory[aid])byAdvisory[aid]={adv:p,pairs:[]};byAdvisory[aid].pairs.push(p);}
  const verdictLabel={APPLICABLE:'CONFIRMED',NOT_APPLICABLE:'FALSE POSITIVE',NEEDS_REVIEW:'NEEDS REVIEW'};
  let html=`<div class="summary-bar">
    <div class="stat-card stat-applicable"><div class="stat-num">${counts.APPLICABLE||0}</div><div class="stat-label">Confirmed</div></div>
    <div class="stat-card stat-not"><div class="stat-num">${counts.NOT_APPLICABLE||0}</div><div class="stat-label">False Positives</div></div>
    <div class="stat-card stat-review"><div class="stat-num">${counts.NEEDS_REVIEW||0}</div><div class="stat-label">Needs Review</div></div>
    <div class="stat-card"><div class="stat-num">${pairs.length}</div><div class="stat-label">Total Pairs</div></div>
  </div>`;
  if(job.status==='running'){const pct=job.progress||0;html+=`<div class="progress-wrap"><div class="progress-bar-bg"><div class="progress-bar-fill" style="width:${pct}%"></div></div><div style="font-size:11px;color:var(--text3);margin-top:4px;font-family:monospace">Assessing pairs… ${pct}%</div></div>`;}
  for(const[aid,group]of Object.entries(byAdvisory)){
    const p0=group.adv;
    const confirmed=group.pairs.filter(p=>p.verdict==='APPLICABLE').length;
    const falsePos=group.pairs.filter(p=>p.verdict==='NOT_APPLICABLE').length;
    const needsReview=group.pairs.filter(p=>p.verdict==='NEEDS_REVIEW').length;
    html+=`<div class="device-card" style="margin-bottom:14px">
      <div style="background:var(--surface2);padding:10px 16px;display:flex;align-items:center;gap:10px;flex-wrap:wrap;border-bottom:1px solid var(--border)">
        <div style="flex:1;min-width:0">
          <div style="font-weight:bold;font-size:13px;font-family:monospace">${aid}</div>
          <div style="font-size:11px;color:var(--text3);font-family:monospace">${(p0.cves||[]).join(', ')||'—'} | SIR: ${p0.sir||'?'} | CVSS: ${p0.cvss||'?'}</div>
        </div>
        <div style="font-size:11px;display:flex;gap:10px;font-family:monospace">
          ${confirmed?`<span style="color:var(--green)">✓ ${confirmed} confirmed</span>`:''}
          ${falsePos?`<span style="color:var(--red)">✗ ${falsePos} false positive${falsePos!==1?'s':''}</span>`:''}
          ${needsReview?`<span style="color:var(--amber)">? ${needsReview} review</span>`:''}
        </div>
      </div>`;
    for(const pair of group.pairs){
      const vl=verdictLabel[pair.verdict]||pair.verdict;
      const vbadge=pair.verdict==='APPLICABLE'?'badge-applicable':pair.verdict==='NOT_APPLICABLE'?'badge-not':'badge-review';
      const safeId=((pair.hostname||pair.host||'x')+'_'+(pair.advisory_id||'x')).replace(/[^a-z0-9]/gi,'_');
      const drawerId='why_bulk_'+safeId;
      html+=`<div style="padding:10px 16px;border-top:1px solid var(--border)">
        <div style="display:flex;align-items:flex-start;gap:10px">
          <div style="flex:1;min-width:0">
            <div style="font-weight:600;font-size:12px;font-family:monospace">${pair.hostname||pair.host||'—'}</div>
            <div style="font-size:11px;color:var(--text3);font-family:monospace">${pair.platform||''} | v${pair.dnac_version||'?'} | ${pair.host||''}</div>
            ${pair.collection_error?`<div style="font-size:11px;color:var(--red);margin-top:2px">⚠ ${pair.collection_error}</div>`:''}
          </div>
          <div style="display:flex;align-items:center;gap:6px;padding-top:2px;flex-shrink:0">
            <span class="badge ${vbadge}">${vl}</span>
            <button class="why-btn" onclick="toggleWhy('${drawerId}')">Why?</button>
          </div>
        </div>
        <div class="why-drawer" id="${drawerId}">${buildWhyDrawer(pair)}</div>
      </div>`;
    }
    html+=`</div>`;
  }
  if(!pairs.length&&job.status!=='running')html+=`<div class="empty-state">No pairs found yet.</div>`;
  if(job.status==='done'&&job.job_id)html+=`<div style="margin-top:10px"><button class="btn btn-sm btn-export" onclick="exportJSON('${job.job_id}')">&#11015; Export JSON</button></div>`;
  el.innerHTML=html;
}

async function dnacAssessSelected() {
  const c=dnacCreds();
  if(!c.host||!c.username||!c.password){dnacMsg('Host, username, and password required.','var(--red)');return;}
  const checked=document.querySelectorAll('.dnac-adv-checkbox:checked');
  if(!checked.length){dnacMsg('Select at least one advisory.','var(--text3)');return;}
  const advisoryIds=Array.from(checked).map(cb=>cb.dataset.id);
  dnacMsg(`Starting assessment for ${advisoryIds.length} advisory(ies)...`,'var(--text3)'); dnacSetDot('loading');
  try{
    const r=await fetch('/api/dnac/assess-all',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({...c,advisory_ids:advisoryIds})});
    const d=await r.json();
    if(!r.ok){dnacMsg('Error: '+d.error,'var(--red)');dnacSetDot('error');return;}
    dnacMsg(`Job started for ${advisoryIds.length} advisor${advisoryIds.length===1?'y':'ies'}.`,'#22c55e'); dnacSetDot('ok');
    closeDnacAdvisories(); showTab('results'); startPolling(d.job_id);
  }catch(e){dnacMsg('Error: '+e.message,'var(--red)');dnacSetDot('error');}
}
</script>
</body>
</html>
"""

# ── Entrypoint ────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    logger.info("Starting PSIRT Chatbot on http://0.0.0.0:%d", PORT)
    get_agent()
    app.run(host="0.0.0.0", port=PORT, debug=False, threaded=True)