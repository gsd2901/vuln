"""
PATCH INSTRUCTIONS for  rag_agent_project/tools/utils.py
──────────────────────────────────────────────────────────
Add the import block near the top, then call trigger_applicability_scan()
at the end of store_advisory_data().

--- STEP 1: add import near top of file (after existing imports) ---

    from psirt.background_scanner import trigger_applicability_scan

--- STEP 2: at the very end of store_advisory_data(), before the
            closing `except Exception` block, add ---

        # ── Trigger PSIRT applicability scan in background ──────────────────
        #
        # Now that advisory + device data is stored in PostgreSQL, kick off
        # the background applicability check.  Pass the DNAC client so the
        # worker can obtain a token and run Command Runner / SSH.
        #
        # dnac_id is not available inside store_advisory_data() directly,
        # so the caller (tools/endpoints.py) should pass it as a kwarg.
        # For backward compatibility we default to None here.
        try:
            _dnac_id = kwargs.get("dnac_id") if "kwargs" in dir() else None
            trigger_applicability_scan(dnac, dnac_id=_dnac_id)
        except Exception as scan_exc:
            logger.warning(
                "[PSIRT] Could not trigger background scan: %s", scan_exc
            )

───────────────────────────────────────────────────────────────────────────────
ALTERNATIVELY — if you don't want to modify store_advisory_data() itself,
call trigger_applicability_scan() directly from tools/endpoints.py right
after store_advisory_data() and store_device_data() return, e.g.:

    # In impacted_advisories_endpoint() / enhanced_advisories_endpoint():
    store_impacted_advisories(advisories_response, dnac_id=dnac_id)
    from psirt.background_scanner import trigger_applicability_scan
    trigger_applicability_scan(dnac, dnac_id=dnac_id)

This is the recommended approach — keep store_advisory_data clean.
───────────────────────────────────────────────────────────────────────────────
"""
