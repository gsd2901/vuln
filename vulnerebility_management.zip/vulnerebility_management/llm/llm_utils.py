from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
from langchain_core.output_parsers import StrOutputParser
from langchain_core.messages import SystemMessage, HumanMessage
from langchain_openai import ChatOpenAI
from langchain_openai import AzureChatOpenAI
import httpx
import os,sys
from config import BASE_DIR
# try:
#     from rag_agent_project.config import MODEL_NAME, OPENAI_API_URL, OPENROUTER_API_KEY
# except Exception:
#     from config import MODEL_NAME, OPENAI_API_URL, OPENROUTER_API_KEY

# System prompt preserved as-is
SYSTEM_PROMPT = """You are an AI named "**Security Advisory Helper**." Your main focus is on DNA Center (DNAC) security advisories. Whenever a user asks for information, you will provide guidance, explanations, or solutions related to these advisories.

1. Introduce yourself as "**Security Advisory Helper**" at the start of every conversation.
2. Help the user by giving step-by-step instructions on addressing specific advisories, including troubleshooting or applying patches.
3. Offer recommendations for keeping the DNA Center secure and up-to-date.
4. The bot has following options in default in DNAC (impacted devices, impacted advisories, advisory discovery, latest discovery report and execute cmds) and in ServiceNow (List Incidents and Resolve Incidents)
    1) If the user requests anything related to devices in DNAC - you should reply only the word "impacted_devices"
    2) If the user requests anything related to advisories in DNAC - you should reply only the word "impacted_advisories"
    3) If the user requests anything related to advisory discovery in DNAC - you should reply only the word "advisory_discovery"
    4) If the user requests anything related to discovery report in DNAC - you should reply only the word "latest_discovery_report"
    5) If the user requests anything related to executing commands on the devices in DNAC - you should reply only the word "execute_commands"
    6) If the user requests anything related to listing incidents in ServiceNow - you should reply only the word "list_incidents"
    7) If the user requests anything related to resolving incidents in ServiceNow - you should reply only the word "resolve_incident"
    8) If the user requests anything related to other than above and other than about yourself or what you can do - you should reply only the word "rag_questions" 

Start every interaction with a greeting and then assist the user with any queries related to DNA Center security advisories.
"""

# Initialize the LLM
# llm = ChatOpenAI(
#     model=MODEL_NAME,
#     temperature=0,
#     openai_api_key=OPENROUTER_API_KEY,
#     base_url=OPENAI_API_URL,
# )

llm = AzureChatOpenAI(azure_deployment="gpt-4.1",
    api_version="2025-01-01-preview",
    azure_endpoint="https://git-nw-openai-llm-prod.openai.azure.com/",
    http_client=httpx.Client(verify=False),
    api_key=os.getenv("AZURE_OPENAI_API_KEY"))

# Full chat history retained
chat_history = []

# Core dochat handler
def dochat(message):
    global chat_history
    chat_history.append(HumanMessage(content=message))
    prompt = ChatPromptTemplate.from_messages([
        SystemMessage(content=SYSTEM_PROMPT),
        MessagesPlaceholder(variable_name="chat_history"),
        HumanMessage(content="{input}")
    ])
    chain = prompt | llm | StrOutputParser()
    response = chain.invoke({"input": message, "chat_history": chat_history})
    return response

# Alias for default assistant
def advisory_helper_chat(message):
    return dochat(message)

def generate_advisory_questions(uuid, title, content):
    """
    Generates a list of questions based on a Cisco PSIRT advisory using a structured ChatPromptTemplate.

    Args:
        uuid (str): The UUID of the advisory.
        title (str): The title of the advisory.
        content (str): The detailed content of the advisory.
        llm (BaseChatModel): The language model instance to use for generation.

    Returns:
        str: A comma-separated string of questions, advisory title, and UUID.
    """
    chat_prompt = ChatPromptTemplate.from_messages([
        SystemMessage(content="""You are an expert in cybersecurity and network advisories. Your task is to generate a clean, unordered list of questions based on a given Cisco PSIRT advisory.
        Each question must start with an asterisk (*). Avoid any introductory statements, explanations, or additional formatting.
        Each question should be concise, logically structured, and cover key aspects such as affected products, vulnerability details, impact, exploitation risks, mitigation steps, and references.
        Ensure that questions mention the advisory ID, title, or CVE when relevant to make them unique. Generate more than 20 questions."""),
        HumanMessage(content=f"""Below is a detailed Cisco PSIRT advisory (Advisory ID: {uuid}, Title: {title}). Generate a list of questions based on this information.
        
        PSIRT Advisory Content:
        {content}
        """)
    ])
    
    chain = chat_prompt | llm | StrOutputParser()
    
    # Invoke the chain to get the generated questions
    generated_questions_raw = chain.invoke({"uuid": uuid, "title": title, "content": content})
    
    # Process the raw output to format it as required
    # Split by lines, remove leading '* ', then join with commas
    questions_list = [q.strip() for q in generated_questions_raw.strip().splitlines() if q.strip().startswith('*')]
    questions_cleaned = [q[1:].strip() for q in questions_list] # Remove the leading '*'
    
    # Add title and uuid to the end
    final_output_parts = questions_cleaned + [title, uuid]
    
    return ",".join(final_output_parts)

# # Extract CLI show commands only
# def cli_commands_collector(advisory_data):
#     chat_prompt = ChatPromptTemplate.from_messages([
#         SystemMessage(content="what are the cisco show commands mentioned if any. If no show commands are mentioned, say 'No show commands mentioned'. Do not include anything else. Only reply from the given advisory."),
#         # SystemMessage(content="Extract only the Cisco CLI commands based on the advisory data. Don't include any explanation."),
#         HumanMessage(content="{input}")
#     ])
#     chain = chat_prompt | llm | StrOutputParser()
#     response = chain.invoke({"input": advisory_data})
#     print(response)
#     # Filter lines starting with 'show' and remove duplicates
#     commands = list({line.strip() for line in response.splitlines() if line.strip().lower().startswith("show")})
#     print(f"Collected Cmds: {commands}")
#     return "\n".join(commands) if commands else "No show commands mentioned"


def cli_commands_collector(advisory_data):
    # More specific system message and structured prompt
    chat_prompt = ChatPromptTemplate.from_messages([
        SystemMessage(content="""You are a network security specialist analyzing Cisco advisories. 
                        Extract ONLY Cisco CLI 'show' commands exactly as they appear in the text. 
                        Return each command on a separate line with no additional text or explanation.
                        If no show commands are found, return exactly: 'No show commands mentioned'."""),
        HumanMessage(content=f"""Analyze this Cisco security advisory and extract all CLI commands that:
                        1. Begin with 'show'
                        2. Are complete commands (include all parts like pipes/filters)
                        3. Appear exactly as shown in the text
                        
                        Advisory Content:
                        {advisory_data}  # Limit to avoid token overflow
                        """)
    ])
    
    chain = chat_prompt | llm | StrOutputParser()
    
    try:
        response = chain.invoke({"input": advisory_data})
        print(f"LLM Response: {response}")
        # Enhanced command filtering
        commands = []
        for line in response.splitlines():
            line = line.strip()
            # More rigorous command validation
            if (line.lower().startswith('show') 
                and len(line.split()) > 1  # Must have more than just "show"
                and not line.endswith(':')  # Exclude section headers
                and not any(x in line for x in ['http', 'www'])  # Exclude URLs
                and '...' not in line):  # Exclude truncated commands
                commands.append(line)
        
        # Remove duplicates while preserving order
        seen = set()
        unique_commands = [cmd for cmd in commands if not (cmd in seen or seen.add(cmd))]
        
        print(f"Collected Commands: {unique_commands}")
        return unique_commands if unique_commands else []
        
    except Exception as e:
        print(f"Error processing advisory: {e}")
        return "Error extracting commands"