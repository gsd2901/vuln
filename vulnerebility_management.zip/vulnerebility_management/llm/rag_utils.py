import chromadb
from langchain_chroma import Chroma
from langchain_core.output_parsers import StrOutputParser
from langchain_core.prompts import PromptTemplate
from langchain_core.runnables import RunnablePassthrough
from langchain_openai import AzureChatOpenAI, OpenAIEmbeddings
from langchain_openai import AzureOpenAIEmbeddings
from langchain_chroma import Chroma
# from config import BASE_DIR
import os,sys,httpx

try:
    from ..config import AZURE_OPENAI_API_KEY
    #EMBEDDING_MODEL, MODEL_NAME, OPENAI_API_URL, OPENROUTER_API_KEY
    from ..db.database_postgresql import PostgreSQLConnector
except Exception:
    from ..config import AZURE_OPENAI_API_KEY

    # from config import EMBEDDING_MODEL, MODEL_NAME, OPENAI_API_URL, OPENROUTER_API_KEY
    from ..db.database_postgresql import PostgreSQLConnector


llm=AzureChatOpenAI(azure_deployment="gpt-4.1",
    api_version="2025-01-01-preview",
    azure_endpoint="https://git-nw-openai-llm-prod.openai.azure.com/",
    http_client=httpx.Client(verify=False),
    api_key=AZURE_OPENAI_API_KEY)#os.getenv("AZURE_OPENAI_API_KEY"))

# https://git-nw-openai-llm-prod.openai.azure.com/openai/deployments/
# text-embedding-3-small/embeddings?api-version=2023-05-15
# embeddings = OpenAIEmbeddings(
#     model=EMBEDDING_MODEL,
#     openai_api_key=OPENROUTER_API_KEY,
#     base_url=OPENAI_API_URL,
# )
 
# Your Azure OpenAI embedding config
embeddings = AzureOpenAIEmbeddings(
    azure_deployment="text-embedding-3-small",
    azure_endpoint="https://git-nw-openai-llm-prod.openai.azure.com/",
    api_key=AZURE_OPENAI_API_KEY,#os.getenv("AZURE_OPENAI_API_KEY"),  # click the eye icon to reveal it
    api_version="2023-05-15"
)

PROMPT_TEMPLATE = """
Human: You are an AI assistant, and provides answers to questions by using fact based and statistical information when possible.
Use the following pieces of information to provide a concise answer to the question enclosed in <question> tags.
If you don't know the answer, just say that you don't know, don't try to make up an answer.
<context>
{context}
</context>

<question>
{question}
</question>

The response should be specific and use statistics or numbers when possible.

Assistant:"""

prompt = PromptTemplate(
    template=PROMPT_TEMPLATE,
    input_variables=["context", "question"],
)


def format_docs(docs):
    db = PostgreSQLConnector("RAGDatabase")
    uuids = [doc.metadata.get("uuid") for doc in docs if "uuid" in doc.metadata and doc.metadata.get("uuid")]
    if not uuids:
        db.close()
        return ""

    try:
        # Primary path: schema with explicit uuid/content columns.
        with db.conn.cursor() as cur:
            cur.execute(
                """
                SELECT uuid, content
                FROM advisory_rag
                WHERE uuid = ANY(%s)
                """,
                [uuids],
            )
            rows = cur.fetchall()

        content_by_uuid = {row[0]: row[1] for row in rows}
        ordered_content = [content_by_uuid[uid] for uid in uuids if uid in content_by_uuid]
        if ordered_content:
            return "\n\n".join(ordered_content)

        # Fallback path: legacy JSONB-wrapper table format.
        try:
            advisory_rag_collection = db.collection("advisory_rag")
            adv_docs = advisory_rag_collection.find({"uuid": {"$in": uuids}}, {"content": 1, "_id": 0})
            return "\n\n".join(doc["content"] for doc in adv_docs if "content" in doc)
        except Exception:
            return ""
    finally:
        db.close()


def get_vectorstore(persist_directory="./chroma_db", collection_name="advisory_rag"):
    chroma_settings = chromadb.config.Settings(
        anonymized_telemetry=False,
        allow_reset=False,
    )
    return Chroma(
        collection_name=collection_name,
        embedding_function=embeddings,
        persist_directory=persist_directory,
        client_settings=chroma_settings,
    )


def rag_retrival(vectorstore, query):
    retriever = vectorstore.as_retriever()
    rag_chain = (
        {"context": retriever | format_docs, "question": RunnablePassthrough()}
        | prompt
        | llm
        | StrOutputParser()
    )
    return rag_chain.invoke(query)
