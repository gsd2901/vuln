import logging
import re
from typing import Optional

from langchain.agents import create_agent
from langchain_core.tools import tool
from langchain_openai import ChatOpenAI
from langchain_openai import AzureChatOpenAI
import sys
import os
import httpx
# from .config import BASE_DIR
from dotenv import load_dotenv
load_dotenv()
# Set the base directory (root of the project)
# base_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '.'))
# sys.path.insert(0, base_dir)
# print(base_dir)

# Now you can import the modules


try:
    # from rag_agent_project.config import MODEL_NAME, OPENAI_API_URL, OPENROUTER_API_KEY
    from .llm.rag_utils import get_vectorstore, rag_retrival
except Exception:
    # from config import MODEL_NAME, OPENAI_API_URL, OPENROUTER_API_KEY
    from .llm.rag_utils import get_vectorstore, rag_retrival

try:
    from vulnerebility_management.db.quries_postgresql import (
        collect_impacted_advisories,
        collect_impacted_devices,
        latest_scan_report,
    )
except Exception:
    try:
        from db.quries_postgresql import (
            collect_impacted_advisories,
            collect_impacted_devices,
            latest_scan_report,
        )
    except Exception:
        collect_impacted_advisories = None
        collect_impacted_devices = None
        latest_scan_report = None

logger = logging.getLogger(__name__)
file_handler = logging.FileHandler("app_19_may_rag_agent.log")
logger.addHandler(file_handler)


def _extract_dnac_id_from_query(query: str) -> Optional[str]:
    if not query:
        return None
    q = query.strip().lower()
    patterns = (
        r"\bfor\s+dnac\s+(\S+)",
        r"\bdnac_id\s*=\s*(\S+)",
        r"\bdnac_id\s*:\s*(\S+)",
        r"\busing\s+dnac\s+(\S+)",
    )
    for pat in patterns:
        match = re.search(pat, q)
        if match:
            return match.group(1).strip().strip("\"'.,);")
    return None


def _extract_advisory_id_from_query(query: str) -> Optional[str]:
    if not query:
        return None
    match = re.search(r"(cisco-sa-[A-Za-z0-9\-]+)", query, flags=re.IGNORECASE)
    if match:
        return match.group(1)
    return None


def _row_dnac_value(row: dict) -> Optional[str]:
    for key in ("dnac_id", "dnacId", "dnac", "dnac_name", "dnac_host", "dnacHost"):
        value = row.get(key)
        if value is not None:
            return str(value).strip().lower()
    return None


def _filter_rows_for_dnac(rows, dnac_id: Optional[str]):
    if not dnac_id:
        return rows
    target = dnac_id.strip().lower()
    filtered = [row for row in rows if _row_dnac_value(row) == target]
    return filtered


class RAGLangChainAgent:
    """Standalone LangChain-based RAG agent for advisory Q&A."""

    def __init__(self, model_name: Optional[str] = None, auto_load_data: bool = True):
        try: 
            self.model_name = model_name #or MODEL_NAME
            self._vector_store = get_vectorstore()
            self._auto_load_data = auto_load_data
            self._data_checked = False
            # self._llm = ChatOpenAI(
            #     temperature=0,
            #     model=self.model_name,
            #     openai_api_key=OPENROUTER_API_KEY,
            #     base_url=OPENAI_API_URL,
            # )
            self._llm=AzureChatOpenAI(azure_deployment="gpt-4.1",
                api_version="2025-01-01-preview",
                azure_endpoint="https://git-nw-openai-llm-prod.openai.azure.com/",
                http_client=httpx.Client(verify=False),
                api_key=os.getenv("AZURE_OPENAI_API_KEY"))

            if self._auto_load_data:
                self._ensure_rag_data_loaded()
            self._agent = self._build_agent()
        except Exception as load_exc:
            logger.error("RAGLangChainAgent Init Failed ")

    def _vectorstore_count(self) -> int:
        """Return current number of indexed documents in Chroma."""
        try:
            return int(self._vector_store._collection.count())
        except Exception:
            try:
                data = self._vector_store.get(limit=1)
                return len(data.get("ids", []))
            except Exception:
                return 0

    def _ensure_rag_data_loaded(self, force_reload: bool = False) -> None:
        """Load RAG source data into vector store when empty or when forced."""
        if self._data_checked and not force_reload:
            return

        indexed_count = self._vectorstore_count()
        if indexed_count > 0 and not force_reload:
            self._data_checked = True
            return

        try:
            from rag_agent_project.local_loader import load_default_data
        except Exception:
            try:
                from .rag.local_loader import load_default_data
            except Exception as local_exc:
                logger.warning("Local RAG loader import failed: %s", local_exc)
                self._data_checked = True
                return

        logger.info("Vector store is empty. Loading bundled local advisory data into Chroma.")
        try:
            inserted = load_default_data(self._vector_store)
            logger.info("Local loader inserted %s records.", inserted)
        except Exception as load_exc:
            logger.warning("Local RAG loader failed: %s", load_exc)
        self._data_checked = True

    def _build_tools(self):
        vector_store = self._vector_store
        auto_load = self._auto_load_data
        ensure_loaded = self._ensure_rag_data_loaded

        @tool
        def rag_response_tool(query: str) -> str:
            """Use this for Cisco advisory, CVE, workaround, mitigation, and fixed-software questions. Input must be a user question string."""
            if auto_load:
                ensure_loaded()
            return rag_retrival(vector_store, query)

        @tool
        def impacted_devices_db_tool(query: str) -> str:
            """Use this for impacted devices from PostgresDB. Supports optional filters like advisory id (cisco-sa-...) and DNAC id (for dnac <id>)."""
            if collect_impacted_devices is None:
                return "Postgres impacted devices query function is unavailable in this runtime."

            try:
                rows = list(collect_impacted_devices())
                dnac_id = _extract_dnac_id_from_query(query)
                advisory_id = _extract_advisory_id_from_query(query)

                rows = _filter_rows_for_dnac(rows, dnac_id)
                if advisory_id:
                    target = advisory_id.lower()
                    rows = [
                        row for row in rows
                        if any(str(a).lower() == target for a in (row.get("advisoryIds") or []))
                    ]

                if not rows:
                    if dnac_id and advisory_id:
                        return f"No impacted devices found in PostgresDB for DNAC '{dnac_id}' and advisory '{advisory_id}'."
                    if dnac_id:
                        return f"No impacted devices found in PostgresDB for DNAC '{dnac_id}'."
                    if advisory_id:
                        return f"No impacted devices found in PostgresDB for advisory '{advisory_id}'."
                    return "No impacted devices found in PostgresDB."

                # Keep payload compact for tool responses.
                compact = [
                    {
                        "hostname": row.get("hostname"),
                        "managementIpAddress": row.get("managementIpAddress"),
                        "advisoryIds": row.get("advisoryIds", []),
                        "softwareVersion": row.get("softwareVersion"),
                        "reachabilityStatus": row.get("reachabilityStatus"),
                        "dnac_id": row.get("dnac_id") or row.get("dnacId") or row.get("dnac"),
                    }
                    for row in rows
                ]
                return str(compact)
            except Exception as exc:
                logger.warning("Postgres impacted devices query failed: %s", exc)
                return f"Failed to fetch impacted devices from PostgresDB: {exc}"

        @tool
        def impacted_advisories_db_tool(query: str) -> str:
            """Use this for impacted advisories from PostgresDB. Supports optional advisory id filter (cisco-sa-...)."""
            if collect_impacted_advisories is None:
                return "Postgres impacted advisories query function is unavailable in this runtime."

            try:
                rows = list(collect_impacted_advisories())
                advisory_id = _extract_advisory_id_from_query(query)
                if advisory_id:
                    target = advisory_id.lower()
                    rows = [row for row in rows if str(row.get("advisoryId", "")).lower() == target]

                if not rows:
                    if advisory_id:
                        return f"No impacted advisories found in PostgresDB for '{advisory_id}'."
                    return "No impacted advisories found in PostgresDB."

                return str(rows)
            except Exception as exc:
                logger.warning("Postgres impacted advisories query failed: %s", exc)
                return f"Failed to fetch impacted advisories from PostgresDB: {exc}"

        @tool
        def latest_discovery_report_db_tool(query: str) -> str:
            """Use this for latest discovery report from PostgresDB."""
            if latest_scan_report is None:
                return "Postgres latest discovery query function is unavailable in this runtime."

            try:
                rows = list(latest_scan_report())
                if not rows:
                    return "No discovery report found in PostgresDB."
                return str(rows)
            except Exception as exc:
                logger.warning("Postgres latest discovery report query failed: %s", exc)
                return f"Failed to fetch latest discovery report from PostgresDB: {exc}"

        @tool
        def introductory_tool(query: str) -> str:
            """Use this for greeting/capabilities questions."""
            return (
                "I am the RAG Advisory Agent. I answer Cisco security advisory, CVE, "
                "mitigation, and fix-related questions using the advisory knowledge base."
            )

        @tool
        def reload_rag_data_tool(query: str) -> str:
            """Use this to force refresh advisory data in the vector store when user asks to reload/sync/update the RAG knowledge base."""
            ensure_loaded(force_reload=True)
            return "RAG advisory data reload completed."

        return [
            rag_response_tool,
            impacted_devices_db_tool,
            impacted_advisories_db_tool,
            latest_discovery_report_db_tool,
            introductory_tool,
            reload_rag_data_tool,
        ]

    def _build_agent(self):
        tools = self._build_tools()
        return create_agent(model=self._llm, tools=tools)

    def ask(self, query: str) -> str:
        result = self._agent.invoke({"messages": [{"role": "user", "content": query}]})
        messages = result.get("messages", [])
        return str(messages[-1].content) if messages else str(result)


def run_rag_langchain_agent(
    query: str,
    model_name: Optional[str] = None,
    auto_load_data: bool = True,
) -> str:
    logger.info(f"model_name={model_name}, auto_load_data={auto_load_data}")
    agent = RAGLangChainAgent(model_name=model_name, auto_load_data=auto_load_data)
    return agent.ask(query)


if __name__ == "__main__":
    # user_query = "Which Cisco products are affected by cisco-sa-wlc-file-uplpd-rHZG9UfC?"
    user_query = "get me the device names which are affected by cisco-sa-cat9k-PtmD7bgy?"
    user_query = "show impacted devices for dnac default"
    # "Is there a workaround for cisco-sa-wlc-file-uplpd-rHZG9UfC?"
    print(run_rag_langchain_agent(user_query))
