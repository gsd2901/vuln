"""
psirt_chatbot.py
────────────────
Drop this file into your rag_agent_project/ root and run:

    python psirt_chatbot.py

That's it. No other setup needed — it reads your existing config.py,
connects to the same PostgreSQL DB, ChromaDB, and Azure OpenAI that the
Django app uses.

Requirements (all already in your project's venv):
    flask, langchain, langchain-openai, langchain-chroma,
    chromadb, httpx, psycopg2

Port: 5050 (change PORT below if needed)
"""

import json
import logging
import os
import re
import sys
import uuid
from datetime import datetime

from flask import Flask, jsonify, render_template_string, request, session

# ── Make project root importable ─────────────────────────────────────────────
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
if BASE_DIR not in sys.path:
    sys.path.insert(0, BASE_DIR)

PARENT_DIR = os.path.dirname(BASE_DIR)
if PARENT_DIR not in sys.path:
    sys.path.insert(0, PARENT_DIR)

# ── Logging ───────────────────────────────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)
logger = logging.getLogger("psirt_chatbot")

# ── Config ────────────────────────────────────────────────────────────────────
PORT = 5050
SECRET_KEY = os.environ.get("FLASK_SECRET_KEY", "psirt-chatbot-secret-2025")

# ── Flask app ─────────────────────────────────────────────────────────────────
app = Flask(__name__)
app.secret_key = SECRET_KEY

# ── Load the RAG agent (lazy — loaded once on first request) ──────────────────
_agent = None


def get_agent():
    global _agent
    if _agent is None:
        try:
            from rag_langchain_agent import RAGLangChainAgent
        except Exception:
            try:
                from vulnerebility_management.rag_langchain_agent import RAGLangChainAgent
            except Exception as exc:
                logger.error("Could not import RAGLangChainAgent: %s", exc)
                return None
        try:
            _agent = RAGLangChainAgent(auto_load_data=True)
            logger.info("RAGLangChainAgent loaded successfully.")
        except Exception as exc:
            logger.error("RAGLangChainAgent init failed: %s", exc)
    return _agent


# ── PSIRT applicability helpers (optional — graceful if psirt/ not present) ───
def _get_applicability_summary(dnac_id=None):
    try:
        from psirt.db_queries import get_summary_counts, get_applicable_advisories_for_dnac
        counts = get_summary_counts(dnac_id=dnac_id)
        applicable = get_applicable_advisories_for_dnac(
            dnac_id=dnac_id, verdicts=["APPLICABLE", "NEEDS_REVIEW"]
        )
        return {"counts": counts, "applicable": applicable}
    except Exception as exc:
        logger.debug("Applicability summary unavailable: %s", exc)
        return None


def _get_device_advisories(device_id, dnac_id=None):
    try:
        from psirt.db_queries import get_applicable_advisories_for_device
        return get_applicable_advisories_for_device(device_id, dnac_id)
    except Exception:
        return []


# ── Chat session helpers ──────────────────────────────────────────────────────

def _session_history():
    if "history" not in session:
        session["history"] = []
    return session["history"]


def _append_history(role, content):
    hist = _session_history()
    hist.append({"role": role, "content": content, "ts": datetime.utcnow().isoformat()})
    # Keep last 40 messages to avoid session bloat
    session["history"] = hist[-40:]


# ── Routes ────────────────────────────────────────────────────────────────────

@app.route("/")
def index():
    return render_template_string(HTML_TEMPLATE)


@app.route("/api/chat", methods=["POST"])
def chat():
    data = request.get_json(force=True)
    user_msg = (data.get("message") or "").strip()
    if not user_msg:
        return jsonify({"error": "Empty message"}), 400

    _append_history("user", user_msg)

    agent = get_agent()
    if agent is None:
        reply = "⚠️ Agent could not be initialised. Check server logs."
    else:
        try:
            reply = agent.ask(user_msg)
        except Exception as exc:
            logger.error("Agent error: %s", exc, exc_info=True)
            reply = f"⚠️ Error processing your request: {exc}"

    _append_history("assistant", reply)
    return jsonify({"reply": reply})


@app.route("/api/history", methods=["GET"])
def history():
    return jsonify(_session_history())


@app.route("/api/clear", methods=["POST"])
def clear():
    session.pop("history", None)
    return jsonify({"status": "cleared"})


@app.route("/api/applicability_summary")
def applicability_summary():
    dnac_id = request.args.get("dnac_id") or None
    summary = _get_applicability_summary(dnac_id)
    if summary is None:
        return jsonify({"error": "PSIRT module unavailable"}), 503
    return jsonify(summary)


@app.route("/api/device_advisories")
def device_advisories():
    device_id = request.args.get("device_id", "").strip()
    dnac_id = request.args.get("dnac_id") or None
    if not device_id:
        return jsonify({"error": "device_id required"}), 400
    rows = _get_device_advisories(device_id, dnac_id)
    return jsonify({"device_id": device_id, "dnac_id": dnac_id, "advisories": rows})


@app.route("/api/status")
def status():
    agent = get_agent()
    return jsonify({
        "agent_ready": agent is not None,
        "psirt_module": _psirt_available(),
        "timestamp": datetime.utcnow().isoformat(),
    })


def _psirt_available():
    try:
        import psirt.db_queries  # noqa
        return True
    except Exception:
        return False


# ── HTML + JS (single-file, no external CDN needed for core chat) ─────────────

HTML_TEMPLATE = r"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>PSIRT Advisory Assistant</title>
<style>
  :root {
    --bg:       #0d1117;
    --surface:  #161b22;
    --border:   #30363d;
    --accent:   #1f6feb;
    --accent2:  #388bfd;
    --warn:     #d29922;
    --danger:   #da3633;
    --ok:       #3fb950;
    --text:     #e6edf3;
    --muted:    #8b949e;
    --user-bg:  #1f3358;
    --bot-bg:   #1c2128;
    --radius:   10px;
    --font:     'Segoe UI', system-ui, sans-serif;
    --mono:     'Cascadia Code', 'Fira Code', monospace;
  }
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body {
    background: var(--bg); color: var(--text);
    font-family: var(--font); height: 100vh;
    display: flex; flex-direction: column; overflow: hidden;
  }

  /* ── Header ── */
  header {
    background: var(--surface); border-bottom: 1px solid var(--border);
    padding: 12px 20px; display: flex; align-items: center; gap: 12px;
    flex-shrink: 0;
  }
  .logo { font-size: 22px; }
  .header-title { font-size: 15px; font-weight: 600; letter-spacing: .3px; }
  .header-sub   { font-size: 11px; color: var(--muted); }
  .status-dot {
    width: 8px; height: 8px; border-radius: 50%;
    background: var(--muted); margin-left: auto; flex-shrink: 0;
    transition: background .3s;
  }
  .status-dot.ready { background: var(--ok); }

  /* ── Layout ── */
  .layout {
    display: flex; flex: 1; overflow: hidden;
  }

  /* ── Sidebar ── */
  .sidebar {
    width: 260px; background: var(--surface);
    border-right: 1px solid var(--border);
    display: flex; flex-direction: column; flex-shrink: 0;
    overflow: hidden;
  }
  .sidebar-header {
    padding: 14px 16px 10px; font-size: 11px;
    font-weight: 700; text-transform: uppercase;
    letter-spacing: 1px; color: var(--muted);
    border-bottom: 1px solid var(--border);
  }
  .quick-btns {
    padding: 10px; display: flex; flex-direction: column; gap: 6px;
  }
  .qbtn {
    background: var(--bg); border: 1px solid var(--border);
    color: var(--text); padding: 8px 12px; border-radius: var(--radius);
    font-size: 12px; cursor: pointer; text-align: left;
    transition: border-color .2s, background .2s;
  }
  .qbtn:hover { border-color: var(--accent); background: #1a2233; }
  .qbtn .qbtn-icon { margin-right: 6px; }

  .sidebar-section {
    padding: 10px 16px 6px; font-size: 11px;
    font-weight: 700; text-transform: uppercase;
    letter-spacing: 1px; color: var(--muted);
    border-top: 1px solid var(--border); margin-top: 4px;
  }
  .dnac-selector {
    padding: 0 10px 10px; display: flex; flex-direction: column; gap: 6px;
  }
  .dnac-btn {
    background: var(--bg); border: 1px solid var(--border);
    color: var(--muted); padding: 7px 12px; border-radius: var(--radius);
    font-size: 12px; cursor: pointer; text-align: left;
    transition: all .2s;
  }
  .dnac-btn.active { border-color: var(--accent); color: var(--text); background: #1a2233; }
  .dnac-btn:hover  { border-color: var(--accent2); color: var(--text); }

  .summary-panel {
    flex: 1; overflow-y: auto; padding: 10px;
  }
  .verdict-card {
    background: var(--bg); border: 1px solid var(--border);
    border-radius: var(--radius); padding: 10px 12px; margin-bottom: 8px;
  }
  .verdict-card .vc-title { font-size: 11px; color: var(--muted); margin-bottom: 6px; }
  .verdict-row {
    display: flex; justify-content: space-between;
    font-size: 12px; padding: 2px 0;
  }
  .badge {
    padding: 1px 7px; border-radius: 20px; font-size: 10px;
    font-weight: 700; letter-spacing: .4px;
  }
  .badge.APPLICABLE     { background: #1a3a1a; color: var(--ok);    border: 1px solid #2ea043; }
  .badge.NOT_APPLICABLE { background: #2a1a1a; color: var(--danger); border: 1px solid #da3633; }
  .badge.NEEDS_REVIEW   { background: #2a2200; color: var(--warn);  border: 1px solid #d29922; }
  .badge.PENDING        { background: #1a1f2e; color: var(--muted); border: 1px solid var(--border); }
  .badge.MITIGATED      { background: #1a2a3a; color: var(--accent2); border: 1px solid var(--accent); }

  /* ── Chat area ── */
  .chat-area {
    flex: 1; display: flex; flex-direction: column; overflow: hidden;
    min-width: 0;
  }
  .messages {
    flex: 1; overflow-y: auto; padding: 20px;
    display: flex; flex-direction: column; gap: 14px;
  }
  .messages::-webkit-scrollbar { width: 5px; }
  .messages::-webkit-scrollbar-track { background: var(--bg); }
  .messages::-webkit-scrollbar-thumb { background: var(--border); border-radius: 3px; }

  .msg { display: flex; gap: 10px; max-width: 86%; }
  .msg.user  { align-self: flex-end;  flex-direction: row-reverse; }
  .msg.bot   { align-self: flex-start; }

  .avatar {
    width: 32px; height: 32px; border-radius: 50%;
    display: flex; align-items: center; justify-content: center;
    font-size: 14px; flex-shrink: 0;
  }
  .msg.user .avatar  { background: var(--accent);  color: #fff; }
  .msg.bot  .avatar  { background: #2d333b;         color: var(--text); }

  .bubble {
    padding: 10px 14px; border-radius: var(--radius);
    font-size: 13.5px; line-height: 1.6; white-space: pre-wrap;
    word-break: break-word;
  }
  .msg.user .bubble { background: var(--user-bg); border-bottom-right-radius: 3px; }
  .msg.bot  .bubble { background: var(--bot-bg);  border-bottom-left-radius: 3px;
                      border: 1px solid var(--border); }

  .bubble code {
    font-family: var(--mono); background: #0d1117;
    padding: 1px 5px; border-radius: 4px; font-size: 12px;
  }
  .bubble pre {
    background: #0d1117; border: 1px solid var(--border);
    border-radius: 6px; padding: 10px 12px; margin: 8px 0;
    overflow-x: auto; font-family: var(--mono); font-size: 12px;
  }

  .ts { font-size: 10px; color: var(--muted); margin-top: 3px; text-align: right; }
  .msg.bot .ts { text-align: left; }

  .typing {
    display: flex; gap: 4px; align-items: center;
    padding: 10px 14px;
  }
  .dot {
    width: 7px; height: 7px; border-radius: 50%;
    background: var(--muted); animation: bounce .9s infinite;
  }
  .dot:nth-child(2) { animation-delay: .15s; }
  .dot:nth-child(3) { animation-delay: .30s; }
  @keyframes bounce {
    0%,80%,100% { transform: translateY(0); }
    40%          { transform: translateY(-6px); }
  }

  /* ── Input bar ── */
  .input-bar {
    background: var(--surface); border-top: 1px solid var(--border);
    padding: 12px 16px; display: flex; gap: 10px; align-items: flex-end;
  }
  .input-wrap { flex: 1; position: relative; }
  textarea {
    width: 100%; background: var(--bg); border: 1px solid var(--border);
    border-radius: var(--radius); color: var(--text);
    font-family: var(--font); font-size: 13.5px;
    padding: 10px 12px; resize: none; min-height: 44px; max-height: 140px;
    line-height: 1.5; outline: none; transition: border-color .2s;
  }
  textarea:focus { border-color: var(--accent); }
  textarea::placeholder { color: var(--muted); }

  .send-btn {
    background: var(--accent); border: none; border-radius: var(--radius);
    color: #fff; cursor: pointer; padding: 10px 16px;
    font-size: 15px; transition: background .2s; flex-shrink: 0;
    height: 44px;
  }
  .send-btn:hover    { background: var(--accent2); }
  .send-btn:disabled { background: var(--border); cursor: not-allowed; }

  .clear-btn {
    background: none; border: 1px solid var(--border);
    border-radius: var(--radius); color: var(--muted);
    cursor: pointer; padding: 10px 12px; font-size: 13px;
    height: 44px; transition: all .2s;
  }
  .clear-btn:hover { border-color: var(--danger); color: var(--danger); }

  /* ── Welcome ── */
  .welcome {
    margin: auto; text-align: center; padding: 40px 20px;
    max-width: 480px;
  }
  .welcome-icon { font-size: 48px; margin-bottom: 16px; }
  .welcome h2  { font-size: 20px; margin-bottom: 8px; font-weight: 600; }
  .welcome p   { font-size: 13px; color: var(--muted); line-height: 1.7; }

  /* ── Responsive ── */
  @media (max-width: 700px) {
    .sidebar { display: none; }
  }
</style>
</head>
<body>

<header>
  <div class="logo">🛡️</div>
  <div>
    <div class="header-title">PSIRT Advisory Assistant</div>
    <div class="header-sub">Cisco Security Advisory · DNAC · Applicability Engine</div>
  </div>
  <div class="status-dot" id="statusDot" title="Agent status"></div>
</header>

<div class="layout">

  <!-- Sidebar -->
  <aside class="sidebar">
    <div class="sidebar-header">Quick Actions</div>
    <div class="quick-btns">
      <button class="qbtn" onclick="quickSend('Show me impacted advisories')">
        <span class="qbtn-icon">📋</span>Impacted Advisories
      </button>
      <button class="qbtn" onclick="quickSend('Show me impacted devices')">
        <span class="qbtn-icon">🖥️</span>Impacted Devices
      </button>
      <button class="qbtn" onclick="quickSend('Show latest discovery report')">
        <span class="qbtn-icon">🔍</span>Discovery Report
      </button>
      <button class="qbtn" onclick="quickSend('What can you do?')">
        <span class="qbtn-icon">❓</span>Capabilities
      </button>
    </div>

    <div class="sidebar-section">DNAC Instance</div>
    <div class="dnac-selector">
      <button class="dnac-btn" data-dnac="us"    onclick="selectDnac(this)">🌐 US</button>
      <button class="dnac-btn" data-dnac="noida" onclick="selectDnac(this)">🌐 Noida</button>
      <button class="dnac-btn" data-dnac="vj"    onclick="selectDnac(this)">🌐 VJ</button>
    </div>

    <div class="sidebar-section">Applicability Summary</div>
    <div class="summary-panel" id="summaryPanel">
      <div style="font-size:11px;color:var(--muted);padding:4px 2px">
        Select a DNAC instance to load summary.
      </div>
    </div>
  </aside>

  <!-- Chat -->
  <main class="chat-area">
    <div class="messages" id="messages">
      <div class="welcome" id="welcome">
        <div class="welcome-icon">🛡️</div>
        <h2>Security Advisory Assistant</h2>
        <p>Ask me about Cisco PSIRT advisories, affected devices,<br>
           CVEs, workarounds, and applicability verdicts.</p>
      </div>
    </div>

    <div class="input-bar">
      <button class="clear-btn" onclick="clearChat()" title="Clear chat">🗑️</button>
      <div class="input-wrap">
        <textarea id="msgInput"
          placeholder="Ask about advisories, CVEs, devices…"
          rows="1"
          onkeydown="handleKey(event)"
          oninput="autoResize(this)"></textarea>
      </div>
      <button class="send-btn" id="sendBtn" onclick="sendMessage()">➤</button>
    </div>
  </main>

</div>

<script>
let activeDnac = null;

// ── Status check ──────────────────────────────────────────────────────────────
async function checkStatus() {
  try {
    const r = await fetch('/api/status');
    const d = await r.json();
    const dot = document.getElementById('statusDot');
    if (d.agent_ready) { dot.classList.add('ready'); dot.title = 'Agent ready'; }
    else               { dot.title = 'Agent initialising…'; }
  } catch(e) {}
}
checkStatus();

// ── DNAC selector ─────────────────────────────────────────────────────────────
function selectDnac(btn) {
  document.querySelectorAll('.dnac-btn').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  activeDnac = btn.dataset.dnac;
  loadSummary(activeDnac);
}

async function loadSummary(dnac_id) {
  const panel = document.getElementById('summaryPanel');
  panel.innerHTML = '<div style="font-size:11px;color:var(--muted);padding:4px">Loading…</div>';
  try {
    const r = await fetch(`/api/applicability_summary?dnac_id=${dnac_id}`);
    if (!r.ok) { panel.innerHTML = '<div style="font-size:11px;color:var(--muted);padding:4px">PSIRT module not available.</div>'; return; }
    const d = await r.json();
    const c = d.counts || {};
    panel.innerHTML = `
      <div class="verdict-card">
        <div class="vc-title">Verdict Counts — ${dnac_id.toUpperCase()}</div>
        ${verdictRow('Applicable',     c.APPLICABLE     || 0, 'APPLICABLE')}
        ${verdictRow('Not Applicable', c.NOT_APPLICABLE  || 0, 'NOT_APPLICABLE')}
        ${verdictRow('Needs Review',   c.NEEDS_REVIEW   || 0, 'NEEDS_REVIEW')}
        ${verdictRow('Mitigated',      c.MITIGATED      || 0, 'MITIGATED')}
        ${verdictRow('Pending',        c.PENDING        || 0, 'PENDING')}
      </div>
    `;
  } catch(e) {
    panel.innerHTML = '<div style="font-size:11px;color:var(--muted);padding:4px">Could not load summary.</div>';
  }
}

function verdictRow(label, count, cls) {
  return `<div class="verdict-row">
    <span>${label}</span>
    <span class="badge ${cls}">${count}</span>
  </div>`;
}

// ── Chat ──────────────────────────────────────────────────────────────────────
function autoResize(el) {
  el.style.height = 'auto';
  el.style.height = Math.min(el.scrollHeight, 140) + 'px';
}

function handleKey(e) {
  if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendMessage(); }
}

function quickSend(msg) {
  if (activeDnac) msg += ` for dnac ${activeDnac}`;
  document.getElementById('msgInput').value = msg;
  sendMessage();
}

function formatTime(isoStr) {
  if (!isoStr) return '';
  try {
    return new Date(isoStr + 'Z').toLocaleTimeString([], {hour:'2-digit', minute:'2-digit'});
  } catch { return ''; }
}

function escapeHtml(str) {
  return str.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
}

function renderBubble(text) {
  // Convert ```code blocks```, inline `code`, and **bold**
  let html = escapeHtml(text);
  html = html.replace(/```([\s\S]*?)```/g, '<pre>$1</pre>');
  html = html.replace(/`([^`]+)`/g, '<code>$1</code>');
  html = html.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
  return html;
}

function appendMessage(role, content, ts) {
  const welcome = document.getElementById('welcome');
  if (welcome) welcome.remove();

  const msgs = document.getElementById('messages');
  const div = document.createElement('div');
  div.className = `msg ${role === 'user' ? 'user' : 'bot'}`;

  const avatar = role === 'user' ? '👤' : '🛡️';
  const time   = ts ? formatTime(ts) : formatTime(new Date().toISOString().slice(0,-1));

  div.innerHTML = `
    <div class="avatar">${avatar}</div>
    <div>
      <div class="bubble">${renderBubble(content)}</div>
      <div class="ts">${time}</div>
    </div>`;
  msgs.appendChild(div);
  msgs.scrollTop = msgs.scrollHeight;
  return div;
}

function showTyping() {
  const msgs = document.getElementById('messages');
  const div = document.createElement('div');
  div.className = 'msg bot'; div.id = 'typing';
  div.innerHTML = `
    <div class="avatar">🛡️</div>
    <div class="bubble typing">
      <div class="dot"></div><div class="dot"></div><div class="dot"></div>
    </div>`;
  msgs.appendChild(div);
  msgs.scrollTop = msgs.scrollHeight;
}

function removeTyping() {
  const t = document.getElementById('typing');
  if (t) t.remove();
}

async function sendMessage() {
  const input = document.getElementById('msgInput');
  const btn   = document.getElementById('sendBtn');
  let msg     = input.value.trim();
  if (!msg) return;

  // Auto-append active DNAC if message doesn't already mention it
  if (activeDnac && !msg.toLowerCase().includes(activeDnac)) {
    msg += ` (dnac: ${activeDnac})`;
  }

  appendMessage('user', msg);
  input.value = ''; input.style.height = 'auto';
  btn.disabled = true;
  showTyping();

  try {
    const r = await fetch('/api/chat', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({message: msg})
    });
    const d = await r.json();
    removeTyping();
    appendMessage('bot', d.reply || d.error || 'No response.');
  } catch(e) {
    removeTyping();
    appendMessage('bot', `⚠️ Network error: ${e}`);
  } finally {
    btn.disabled = false;
    input.focus();
  }
}

async function clearChat() {
  await fetch('/api/clear', {method:'POST'});
  const msgs = document.getElementById('messages');
  msgs.innerHTML = `
    <div class="welcome" id="welcome">
      <div class="welcome-icon">🛡️</div>
      <h2>Security Advisory Assistant</h2>
      <p>Ask me about Cisco PSIRT advisories, affected devices,<br>
         CVEs, workarounds, and applicability verdicts.</p>
    </div>`;
}

// Load chat history on page open
(async () => {
  try {
    const r = await fetch('/api/history');
    const hist = await r.json();
    if (hist && hist.length > 0) {
      hist.forEach(m => appendMessage(m.role === 'user' ? 'user' : 'bot', m.content, m.ts));
    }
  } catch(e) {}
})();
</script>
</body>
</html>
"""

# ── Entrypoint ────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    logger.info("Starting PSIRT Chatbot on http://0.0.0.0:%d", PORT)
    # Pre-warm the agent so the first user request isn't slow
    get_agent()
    app.run(host="0.0.0.0", port=PORT, debug=False, threaded=True)
