"""
Script to test vulnerability management functions directly (without HTTP calls).
 
This script calls backend functions directly from tools/endpoints.py and related modules,
useful for testing business logic without running the FastAPI server.
"""
 
import json
from typing import Optional
from datetime import datetime
import os,sys
import pandas
import urllib3
urllib3.disable_warnings()
# from urllib3.exceptions import InsecureRequestWarning
# urllib3.disable_warnings(InsecureRequestWarning)
# Set the base directory (root of the project)
from config import BASE_DIR
print("BASE_DIR:::::",BASE_DIR)
try:
    from vulnerebility_management.config import DNAC_INSTANCES
    from vulnerebility_management.tools.endpoints import (
        impacted_devices_endpoint,
        impacted_advisories_endpoint,
        advisory_discovery_endpoint,
        discovery_result_from_db,
        latest_dicovery_report_endpoint,
        creating_snow_tickets_endpoint,
        commands_execution_endpoint,
    )
except Exception:
    from config import DNAC_INSTANCES
    from tools.endpoints import (
        impacted_devices_endpoint,
        impacted_advisories_endpoint,
        advisory_discovery_endpoint,
        discovery_result_from_db,
        latest_dicovery_report_endpoint,
        creating_snow_tickets_endpoint,
        commands_execution_endpoint,
    )
 
 
class VulnerabilityManagementClient:
    """Direct client to call vulnerability management backend functions."""
 
    def list_dnac_instances(self):
        """List available DNAC instances from configuration.
        
        Returns:
            list: List of DNAC instances with id, host, and port
        """
        print("\n========== LIST DNAC INSTANCES ==========")
        try:
            instances = [
                {
                    "id": key,
                    "host": cfg.get("host"),
                    "port": cfg.get("port", 443),
                }
                for key, cfg in DNAC_INSTANCES.items()
            ]
            print(f"Available DNAC Instances:")
            for instance in instances:
                print(f"  - {instance['id']}: {instance['host']}:{instance['port']}")
            return instances
        except Exception as e:
            print(f"Error fetching DNAC instances: {e}")
            return []
 
    def get_impacted_devices(self, dnac_id: Optional[str] = None):
        """Get impacted devices for a specific DNAC instance.
        
        Args:
            dnac_id: Optional DNAC instance ID (e.g., 'lab1', 'prod', 'default')
            
        Returns:
            list: List of impacted devices
        """
        print(f"\n========== GET IMPACTED DEVICES (dnac_id={dnac_id or 'default'}) ==========")
        try:
            devices = impacted_devices_endpoint(dnac_id=dnac_id)
            print(f"Impacted Devices ({len(devices) if isinstance(devices, list) else 'N/A'} found):")
            print(json.dumps(devices, indent=2, default=str))
            return devices
        except Exception as e:
            print(f"Error getting impacted devices: {e}")
            import traceback
            traceback.print_exc()
            return []
 
    def get_impacted_advisories(self, dnac_id: Optional[str] = None):
        """Get impacted advisories for a specific DNAC instance.
        
        Args:
            dnac_id: Optional DNAC instance ID (e.g., 'lab1', 'prod', 'default')
            
        Returns:
            list: List of impacted advisories
        """
        print(f"\n========== GET IMPACTED ADVISORIES (dnac_id={dnac_id or 'default'}) ==========")
        try:
            advisories = impacted_advisories_endpoint(dnac_id=dnac_id)
            print(f"Impacted Advisories ({len(advisories) if isinstance(advisories, list) else 'N/A'} found):")
            print(json.dumps(advisories, indent=2, default=str))
            return advisories
        except Exception as e:
            print(f"Error getting impacted advisories: {e}")
            import traceback
            traceback.print_exc()
            return []
 
    def trigger_advisory_discovery(self, dnac_id: Optional[str] = None):
        """Trigger advisory discovery for a specific DNAC instance.
        
        Args:
            dnac_id: Optional DNAC instance ID
            
        Returns:
            dict: Discovery results
        """
        print(f"\n========== TRIGGER ADVISORY DISCOVERY (dnac_id={dnac_id or 'default'}) ==========")
        try:
            discovery = advisory_discovery_endpoint(dnac_id=dnac_id)
            print(f"Advisory Discovery Results:")
            print(json.dumps(discovery, indent=2, default=str))
            return discovery
        except Exception as e:
            print(f"Error triggering advisory discovery: {e}")
            import traceback
            traceback.print_exc()
            return None
 
    def get_latest_discovery_report(self):
        """Get the latest discovery report.
        
        Returns:
            list: Latest discovery report data
        """
        print("\n========== GET LATEST DISCOVERY REPORT ==========")
        try:
            report = latest_dicovery_report_endpoint()
            print(f"Latest Discovery Report:")
            print(json.dumps(report, indent=2, default=str))
            return report
        except Exception as e:
            print(f"Error getting latest discovery report: {e}")
            import traceback
            traceback.print_exc()
            return None
 
    def get_discovery_result(self):
        """Get discovery result from database.
        
        Returns:
            list: Discovery result data
        """
        print("\n========== GET DISCOVERY RESULT ==========")
        try:
            result = discovery_result_from_db()
            print(f"Discovery Result:")
            print(json.dumps(result, indent=2, default=str))
            return result
        except Exception as e:
            print(f"Error getting discovery result: {e}")
            import traceback
            traceback.print_exc()
            return None
 
    def execute_commands(self, device_ips: str, commands: str):
        """Execute commands on devices.
        
        Args:
            device_ips: Comma-separated list of device IPs
            commands: Comma-separated list of commands to execute
            
        Returns:
            dict: Command execution results
        """
        print(f"\n========== EXECUTE COMMANDS ==========")
        print(f"Device IPs: {device_ips}")
        print(f"Commands: {commands}")
        try:
            result = commands_execution_endpoint(device_ips, commands)
            print(f"Command Execution Results:")
            print(json.dumps(result, indent=2, default=str))
            return result
        except Exception as e:
            print(f"Error executing commands: {e}")
            import traceback
            traceback.print_exc()
            return None
 
    def create_snow_tickets(self, scan_initiated_at: str, ticket_options: dict):
        """Create ServiceNow tickets for advisories.
        
        Args:
            scan_initiated_at: Scan initiation timestamp
            ticket_options: Dict mapping advisoryId to ticket type ('incident', 'change_request', 'no')
            
        Returns:
            tuple: (tool_msg, ai_msg) - Ticket creation response
        """
        print("\n========== CREATE SERVICENOW TICKETS ==========")
        print(f"Scan Time: {scan_initiated_at}")
        print(f"Ticket Options: {json.dumps(ticket_options, indent=2)}")
        try:
            tool_msg, ai_msg = creating_snow_tickets_endpoint(scan_initiated_at, ticket_options)
            print(f"ServiceNow Ticket Creation Results:")
            print(f"Tool Message: {json.dumps(tool_msg, indent=2, default=str)}")
            print(f"AI Message: {ai_msg}")
            return tool_msg, ai_msg
        except Exception as e:
            print(f"Error creating ServiceNow tickets: {e}")
            import traceback
            traceback.print_exc()
            return None, None
 
 
def main():
    """Main function demonstrating direct function calls."""
    
    print("=" * 60)
    print("VULNERABILITY MANAGEMENT DIRECT FUNCTION TEST SCRIPT")
    print("=" * 60)
    
    client = VulnerabilityManagementClient()
    
    # Step 1: List available DNAC instances
    instances = client.list_dnac_instances()
    
    if not instances:
        print("\nNo DNAC instances configured.")
        return
    
    # # Step 2: Get impacted devices for each DNAC instance
    # print("\n" + "=" * 60)
    # print("TESTING IMPACTED DEVICES FOR EACH DNAC")
    # print("=" * 60)
    # for instance in instances:
    #     client.get_impacted_devices(dnac_id=instance['id'])
    
    # # Step 3: Get impacted advisories for each DNAC instance
    # print("\n" + "=" * 60)
    # print("TESTING IMPACTED ADVISORIES FOR EACH DNAC")
    # print("=" * 60)
    # for instance in instances:
    #     client.get_impacted_advisories(dnac_id=instance['id'])
    
    # Step 4: Trigger advisory discovery (example with first DNAC)
    if instances:
        for instance in instances:
            client.trigger_advisory_discovery(dnac_id=instance['id'])
    
    # # Step 5: Get latest discovery report
    # client.get_latest_discovery_report()
    
    # # Step 6: Get discovery result
    # client.get_discovery_result()
    
    # Step 7: Execute commands (example)
    # NOTE: Modify these values according to your actual device IPs and commands
    # client.execute_commands(device_ips="192.168.1.1,192.168.1.2", commands="show version,show interfaces")
    
    # Step 8: Create ServiceNow tickets (example)
    # NOTE: Modify these values according to your actual advisory IDs
    example_ticket_options = {
        "cisco-sa-example-1": "incident",    # 1 = incident
        "cisco-sa-example-2": "change_request",  # 2 = change_request
        "cisco-sa-example-3": "no"  # 3 = no ticket
    }
    scan_time = datetime.utcnow().isoformat()
    # client.create_snow_tickets(scan_time, example_ticket_options)
    
    print("\n" + "=" * 60)
    print("TEST SCRIPT COMPLETED")
    print("=" * 60)
 
 
if __name__ == "__main__":
    main()
 
 