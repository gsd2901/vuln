import os
from dotenv import load_dotenv
# from config import BASE_DIR
load_dotenv(override=True)

DB_DETAILS = {
    "NAME": os.getenv("DB_NAME", "RAGDatabase"),
    "USER": os.getenv("DB_USER", "nautobot"),
    "PASSWORD": os.getenv("DB_PASSWORD", "git@HCL$2025"),
    "HOST": os.getenv("DB_HOST", "localhost"),
    "PORT": os.getenv("DB_PORT", "5432"),
}