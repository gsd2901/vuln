import logging
import re
from typing import Optional


from langchain.agents import create_agent
from langchain_core.tools import tool
from langchain_openai import ChatOpenAI
from langchain_openai import AzureChatOpenAI
import sys
import os
import httpx
from dotenv import load_dotenv
load_dotenv()

sys.path.insert(0, os.path.dirname(__file__))
cwd = os.getcwd()

logger = logging.getLogger(__name__)
file_handler = logging.FileHandler("app_20_may_rag_agent.log")
logger.addHandler(file_handler)
logger.info(f"Current working directory {cwd} file is {__file__} SYS PATH is {sys.path}")

import sqlite3
logger.info(f"SQLite version:{sqlite3.sqlite_version}")

# --- rag_utils import ---
try:
    from vulnerebility_management.llm.rag_utils import get_vectorstore, rag_retrival
    logger.info("Imported rag_utils via 'vulnerebility_management.llm.rag_utils'")
except Exception as e:
    logger.error(f"Import Failed [vulnerebility_management.llm.rag_utils]: {e}")
    try:
        from .llm.rag_utils import get_vectorstore, rag_retrival
        logger.info("Imported rag_utils via relative '.llm.rag_utils'")
    except Exception as e2:
        logger.error(f"Import Failed [.llm.rag_utils]: {e2}")
        try:
            from llm.rag_utils import get_vectorstore, rag_retrival
            logger.info("Imported rag_utils via 'llm.rag_utils'")
        except Exception as e3:
            logger.error(f"Import Failed [llm.rag_utils] — all rag_utils attempts exhausted: {e3}")
            raise ImportError(f"Cannot import rag_utils. Tried 3 paths. Last error: {e3}")

# --- PostgreSQL query functions ---
try:
    from db.quries_postgresql import (
        collect_impacted_advisories,
        collect_impacted_devices,
        latest_scan_report,
    )
    logger.info("Imported db queries via 'db.quries_postgresql'")
except Exception as e:
    logger.error(f"Import Failed [db.quries_postgresql]: {e}")
    collect_impacted_advisories = None
    collect_impacted_devices = None
    latest_scan_report = None

# --- PSIRT applicability query functions (filtered: AFFECTED/NEEDS_REVIEW only) ---
try:
    from psirt.db_queries import (
        get_applicable_advisories_for_device,
        get_applicable_advisories_for_dnac,
        get_applicable_advisories_for_hostname_or_ip,
    )
    logger.info("Imported psirt.db_queries applicable query functions")
except Exception as _psirt_e1:
    logger.error(f"Import Failed [psirt.db_queries]: {_psirt_e1}")
    get_applicable_advisories_for_device = None
    get_applicable_advisories_for_dnac = None
    get_applicable_advisories_for_hostname_or_ip = None

# --- DNAC_INSTANCES config ---
# FIX 2: removed 'custom_chatbot.rag_agent_project' prefix — you're already inside rag_agent_project
try:
    from vulnerebility_management.config import DNAC_INSTANCES
    _KNOWN_DNAC_IDS = set(DNAC_INSTANCES.keys()) - {"default"}
    logger.info("Imported DNAC_INSTANCES via 'vulnerebility_management.config'")
except Exception as e:
    logger.error(f"Import Failed [vulnerebility_management.config] DNAC_INSTANCES: {e}")
    try:
        from config import DNAC_INSTANCES
        _KNOWN_DNAC_IDS = set(DNAC_INSTANCES.keys()) - {"default"}
        logger.info("Imported DNAC_INSTANCES via 'config'")
    except Exception as e2:
        logger.error(f"Import Failed [config] DNAC_INSTANCES — using hardcoded fallback: {e2}")
        _KNOWN_DNAC_IDS = {"us", "noida", "vj"}


def _extract_dnac_id_from_query(query: str) -> Optional[str]:
    if not query:
        return None
    q = query.strip().lower()

    for name in _KNOWN_DNAC_IDS:
        if re.search(rf"\b{re.escape(name)}\b", q):
            return name

    patterns = (
        r"\bfor\s+dnac\s+(\S+)",
        r"\bdnac_id\s*=\s*(\S+)",
        r"\bdnac_id\s*:\s*(\S+)",
        r"\busing\s+dnac\s+(\S+)",
        r"\bdnac\s+(\S+)",
    )
    for pat in patterns:
        match = re.search(pat, q)
        if match:
            return match.group(1).strip().strip("\"'.,);")
    return None


def _extract_advisory_id_from_query(query: str) -> Optional[str]:
    if not query:
        return None
    match = re.search(r"(cisco-sa-[A-Za-z0-9\-]+)", query, flags=re.IGNORECASE)
    if match:
        return match.group(1)
    return None


def _extract_device_ip_from_query(query: str) -> Optional[str]:
    if not query:
        return None
    match = re.search(r"\b(?:\d{1,3}\.){3}\d{1,3}\b", query)
    if match:
        return match.group(0)
    return None


def _extract_device_token_from_query(query: str) -> Optional[str]:
    if not query:
        return None
    q = query.strip()
    patterns = (
        r"\bfor\s+device\s+([\w.-]+)",
        r"\bdevice\s+([\w.-]+)",
        r"\bhostname\s+([\w.-]+)",
    )
    for pat in patterns:
        match = re.search(pat, q, flags=re.IGNORECASE)
        if match:
            return match.group(1).strip().strip("\"'.,);")
    return None


def _row_dnac_value(row: dict) -> Optional[str]:
    for key in ("dnac_id", "dnacId", "dnac", "dnac_name", "dnac_host", "dnacHost"):
        value = row.get(key)
        if value is not None:
            return str(value).strip().lower()
    return None


def _filter_rows_for_dnac(rows, dnac_id: Optional[str]):
    if not dnac_id:
        return rows
    target = dnac_id.strip().lower()
    filtered = [row for row in rows if _row_dnac_value(row) == target]
    return filtered


def _match_rows_for_device(rows, query: str):
    device_ip = _extract_device_ip_from_query(query)
    device_token = _extract_device_token_from_query(query)

    if device_ip:
        return [row for row in rows if str(row.get("managementIpAddress", "")).strip() == device_ip]

    if device_token:
        token = device_token.lower()
        matched = []
        for row in rows:
            hostname = str(row.get("hostname", "")).lower()
            device_id = str(row.get("id", "")).lower()
            mgmt_ip = str(row.get("managementIpAddress", "")).lower()
            if token == hostname or token == device_id or token == mgmt_ip:
                matched.append(row)
        if matched:
            return matched
        return [row for row in rows if token in str(row.get("hostname", "")).lower()]

    return []


class RAGLangChainAgent:
    """Standalone LangChain-based RAG agent for advisory Q&A."""

    def __init__(self, model_name: Optional[str] = None, auto_load_data: bool = True):
        try:
            self.model_name = model_name
            self._vector_store = get_vectorstore()
            self._auto_load_data = auto_load_data
            self._data_checked = False
            self._llm = AzureChatOpenAI(
                azure_deployment="gpt-4.1",
                api_version="2025-01-01-preview",
                azure_endpoint="https://git-nw-openai-llm-prod.openai.azure.com/",
                http_client=httpx.Client(verify=False),
                api_key=os.getenv("AZURE_OPENAI_API_KEY"),
            )
            if self._auto_load_data:
                self._ensure_rag_data_loaded()
            self._agent = self._build_agent()
            logger.info("RAGLangChainAgent Init Done")
        except Exception as load_exc:
            logger.error(f"RAGLangChainAgent Init Failed: {load_exc}", exc_info=True)
            raise

    def _vectorstore_count(self) -> int:
        try:
            return int(self._vector_store._collection.count())
        except Exception:
            try:
                data = self._vector_store.get(limit=1)
                return len(data.get("ids", []))
            except Exception:
                return 0

    def _ensure_rag_data_loaded(self, force_reload: bool = False) -> None:
        if self._data_checked and not force_reload:
            return

        indexed_count = self._vectorstore_count()
        if indexed_count > 0 and not force_reload:
            self._data_checked = True
            return

        # FIX 3: added bare 'rag.local_loader' as third fallback
        try:
            from vulnerebility_management.rag.local_loader import load_default_data
            logger.info("Imported local_loader via 'vulnerebility_management.rag.local_loader'")
        except Exception as e:
            logger.error(f"Import Failed [vulnerebility_management.rag.local_loader]: {e}")
            try:
                from .rag.local_loader import load_default_data
                logger.info("Imported local_loader via '.rag.local_loader'")
            except Exception as e2:
                logger.error(f"Import Failed [.rag.local_loader]: {e2}")
                try:
                    from rag.local_loader import load_default_data
                    logger.info("Imported local_loader via 'rag.local_loader'")
                except Exception as e3:
                    logger.error(f"Import Failed [rag.local_loader] — all local_loader attempts exhausted: {e3}")
                    self._data_checked = True
                    return

        logger.info("Vector store is empty. Loading bundled local advisory data into Chroma.")
        try:
            inserted = load_default_data(self._vector_store)
            logger.info("Local loader inserted %s records.", inserted)
        except Exception as load_exc:
            logger.warning("Local RAG loader failed: %s", load_exc)
        self._data_checked = True

    def _build_tools(self):
        vector_store = self._vector_store
        auto_load = self._auto_load_data
        ensure_loaded = self._ensure_rag_data_loaded

        @tool
        def rag_response_tool(query: str) -> str:
            """Use this for Cisco advisory, CVE, workaround, mitigation, and fixed-software questions."""
            if auto_load:
                ensure_loaded()
            return rag_retrival(vector_store, query)

        @tool
        def fetch_and_store_impacted_devices_tool(query: str) -> str:
            """Use this to fetch fresh impacted devices data from DNAC and store it in the database.
            Call this when user asks to sync, refresh, or load device data from DNAC.
            Supports optional DNAC id filter (for dnac <id>)."""

            # FIX 4: removed 'custom_chatbot.' prefix from both attempts
            impacted_devices_endpoint = None
            try:
                from vulnerebility_management.tools.endpoints import impacted_devices_endpoint
                logger.info("Imported impacted_devices_endpoint via 'vulnerebility_management.tools.endpoints'")
            except Exception as e:
                logger.error(f"Import Failed [vulnerebility_management.tools.endpoints] impacted_devices_endpoint: {e}")
                try:
                    from tools.endpoints import impacted_devices_endpoint
                    logger.info("Imported impacted_devices_endpoint via 'tools.endpoints'")
                except Exception as e2:
                    logger.error(f"Import Failed [tools.endpoints] impacted_devices_endpoint: {e2}")
                    return f"Failed to import impacted_devices_endpoint. Tried 2 paths. Last error: {e2}"

            try:
                dnac_id = _extract_dnac_id_from_query(query)
                logger.info(f"fetch_and_store_impacted_devices_tool called with dnac_id='{dnac_id}'")
                result = impacted_devices_endpoint(dnac_id=dnac_id)
                if not result:
                    return "No impacted devices found from DNAC."
                logger.info(f"fetch_and_store_impacted_devices_tool fetched {len(result)} devices")
                compact = [
                    {
                        "hostname": item.get("hostname"),
                        "managementIpAddress": item.get("managementIpAddress"),
                        "softwareVersion": item.get("softwareVersion"),
                        "reachabilityStatus": item.get("reachabilityStatus"),
                        "advisoryIds": item.get("advisoryIds", []),
                        "severity": item.get("severity"),
                    }
                    for item in result
                ]
                return (
                    f"Successfully fetched and stored {len(compact)} impacted devices from DNAC"
                    f" (dnac_id='{dnac_id}').\nSample: {str(compact[:3])}"
                )
            except Exception as exc:
                logger.error(f"fetch_and_store_impacted_devices_tool failed: {exc}", exc_info=True)
                return f"Failed to fetch impacted devices from DNAC: {exc}"

        @tool
        def fetch_and_store_impacted_advisories_tool(query: str) -> str:
            """Use this to fetch fresh impacted advisories data from DNAC and store it in the database.
            Call this when user asks to sync, refresh, or load advisory data from DNAC.
            Supports optional DNAC id filter (for dnac <id>)."""

            # FIX 5: removed 'custom_chatbot.' prefix from both attempts
            impacted_advisories_endpoint = None
            try:
                from vulnerebility_management.tools.endpoints import impacted_advisories_endpoint
                logger.info("Imported impacted_advisories_endpoint via 'vulnerebility_management.tools.endpoints'")
            except Exception as e:
                logger.error(f"Import Failed [vulnerebility_management.tools.endpoints] impacted_advisories_endpoint: {e}")
                try:
                    from tools.endpoints import impacted_advisories_endpoint
                    logger.info("Imported impacted_advisories_endpoint via 'tools.endpoints'")
                except Exception as e2:
                    logger.error(f"Import Failed [tools.endpoints] impacted_advisories_endpoint: {e2}")
                    return f"Failed to import impacted_advisories_endpoint. Tried 2 paths. Last error: {e2}"

            try:
                dnac_id = _extract_dnac_id_from_query(query)
                logger.info(f"fetch_and_store_impacted_advisories_tool called with dnac_id='{dnac_id}'")
                result = impacted_advisories_endpoint(dnac_id=dnac_id)
                if not result:
                    return "No impacted advisories found from DNAC."
                logger.info(f"fetch_and_store_impacted_advisories_tool fetched {len(result)} advisories")
                return (
                    f"Successfully fetched and stored {len(result)} impacted advisories from DNAC"
                    f" (dnac_id='{dnac_id}').\nAdvisories: {str(result[:3])}"
                )
            except Exception as exc:
                logger.error(f"fetch_and_store_impacted_advisories_tool failed: {exc}", exc_info=True)
                return f"Failed to fetch impacted advisories from DNAC: {exc}"

        @tool
        def impacted_devices_db_tool(query: str) -> str:
            """Use this for impacted devices from PostgresDB. Supports optional filters like advisory id (cisco-sa-...) and DNAC id (for dnac <id>)."""
            if collect_impacted_devices is None:
                return "Postgres impacted devices query function is unavailable in this runtime."

            try:
                dnac_id = _extract_dnac_id_from_query(query)
                advisory_id = _extract_advisory_id_from_query(query)
                rows = list(collect_impacted_devices(dnac_id))
                logger.info(f"impacted_devices_db_tool dnac_id={dnac_id} count={len(rows)}")
                rows = _filter_rows_for_dnac(rows, dnac_id)
                if advisory_id:
                    target = advisory_id.lower()
                    rows = [
                        row for row in rows
                        if any(str(a).lower() == target for a in (row.get("advisoryIds") or []))
                    ]

                if not rows:
                    if dnac_id and advisory_id:
                        return f"No impacted devices found in PostgresDB for DNAC '{dnac_id}' and advisory '{advisory_id}'."
                    if dnac_id:
                        return f"No impacted devices found in PostgresDB for DNAC '{dnac_id}'."
                    if advisory_id:
                        return f"No impacted devices found in PostgresDB for advisory '{advisory_id}'."
                    return "No impacted devices found in PostgresDB."

                compact = [
                    {
                        "hostname": row.get("hostname"),
                        "managementIpAddress": row.get("managementIpAddress"),
                        "advisoryIds": row.get("advisoryIds", []),
                        "softwareVersion": row.get("softwareVersion"),
                        "reachabilityStatus": row.get("reachabilityStatus"),
                        "dnac_id": row.get("dnac_id") or row.get("dnacId") or row.get("dnac"),
                    }
                    for row in rows
                ]
                return str(compact)
            except Exception as exc:
                logger.warning(f"Postgres impacted devices query failed: {exc}", exc_info=True)
                return f"Failed to fetch impacted devices from PostgresDB: {exc}"

        @tool
        def advisories_per_device_tool(query: str) -> str:
            """Use this for advisories affecting a specific device. Returns only AFFECTED and NEEDS_REVIEW results — NOT_AFFECTED advisories are excluded. Input should include device hostname, id, or management IP."""

            # Step 1: resolve device row from DNAC DB (to get device id, hostname, IP)
            device_row = None
            matched = []
            if collect_impacted_devices is not None:
                try:
                    rows = list(collect_impacted_devices())
                    matched = _match_rows_for_device(rows, query)
                    if matched:
                        device_row = matched[0]
                except Exception as exc:
                    logger.warning(f"DNAC device lookup failed: {exc}")

            # Step 2: query applicability DB (AFFECTED + NEEDS_REVIEW only, NOT_AFFECTED excluded)
            if get_applicable_advisories_for_device is not None and device_row is not None:
                try:
                    device_id = device_row.get("id") or device_row.get("instanceUuid") or ""
                    dnac_id = device_row.get("dnac_id") or device_row.get("dnacId") or None
                    if device_id:
                        appl_rows = get_applicable_advisories_for_device(device_id=device_id, dnac_id=dnac_id)
                        if appl_rows:
                            compact = [
                                {
                                    "advisoryId":        r.get("advisoryId"),
                                    "verdict":           r.get("verdict"),
                                    "summary":           r.get("summary"),
                                    "softwareVersion":   r.get("softwareVersion"),
                                    "collection_method": r.get("collection_method"),
                                    "action":            r.get("action"),
                                    "remediation":       r.get("remediation"),
                                }
                                for r in appl_rows
                            ]
                            return str({
                                "source":              "applicability_db",
                                "filter":              "AFFECTED and NEEDS_REVIEW only (NOT_AFFECTED excluded)",
                                "hostname":            device_row.get("hostname"),
                                "managementIpAddress": device_row.get("managementIpAddress"),
                                "advisoryCount":       len(compact),
                                "advisories":          compact,
                            })
                        else:
                            return (
                                f"No AFFECTED advisories found for device "
                                f"'{device_row.get('hostname', device_id)}'. "
                                "The device has no applicable advisories, or the applicability scan has not run yet for this device."
                            )
                except Exception as exc:
                    logger.warning(f"Applicability DB advisories-per-device failed: {exc}", exc_info=True)

            # Step 2b: the Postgres 'impacted_devices' lookup above (Step 1) can miss a
            # device that was only ever discovered through the PSIRT background scanner's
            # per-advisory affected-device fetch (never through the separate "fetch
            # impacted devices" action) -- so before giving up, try resolving the same
            # device directly against the PSIRT applicability results by hostname/IP,
            # with no Postgres deviceId required.
            if not matched and get_applicable_advisories_for_hostname_or_ip is not None:
                # Try a cleanly-extracted token first, then fall back to the raw
                # query string itself -- the LangChain agent decides what string
                # to pass as 'query' (it may be a bare hostname with no "device"/
                # "hostname" keyword, which the regex extractors above would miss
                # entirely), and get_applicable_advisories_for_hostname_or_ip()
                # can match either form.
                extracted = _extract_device_ip_from_query(query) or _extract_device_token_from_query(query)
                candidates = [c for c in (extracted, query) if c]
                if candidates:
                    try:
                        dnac_id_hint = _extract_dnac_id_from_query(query)
                        fallback_rows = []
                        for cand in candidates:
                            fallback_rows = get_applicable_advisories_for_hostname_or_ip(cand, dnac_id=dnac_id_hint)
                            if fallback_rows:
                                break
                        if fallback_rows:
                            compact = [
                                {
                                    "advisoryId":        r.get("advisoryId"),
                                    "verdict":           r.get("verdict"),
                                    "summary":           r.get("summary"),
                                    "softwareVersion":   r.get("softwareVersion"),
                                    "collection_method": r.get("collection_method"),
                                    "action":            r.get("action"),
                                    "remediation":       r.get("remediation"),
                                }
                                for r in fallback_rows
                            ]
                            return str({
                                "source":              "applicability_db (matched by hostname/IP, not in impacted_devices table)",
                                "filter":              "AFFECTED and NEEDS_REVIEW only (NOT_AFFECTED excluded)",
                                "hostname":            fallback_rows[0].get("hostname"),
                                "managementIpAddress": fallback_rows[0].get("managementIpAddress"),
                                "advisoryCount":       len(compact),
                                "advisories":          compact,
                            })
                    except Exception as exc:
                        logger.warning(f"PSIRT hostname/IP fallback lookup failed: {exc}", exc_info=True)

            # Step 3: no device found anywhere
            if not matched:
                if collect_impacted_devices is None:
                    return "Postgres impacted devices query function is unavailable in this runtime."
                return (
                    "No device matched your query. Include exact hostname, device id, or management IP "
                    "(for example: 'advisories for device sw1' or 'advisories for 10.10.10.10')."
                )

            # Step 4: fallback — DNAC advisoryIds (applicability scan not yet run)
            compact = [
                {
                    "hostname":            row.get("hostname"),
                    "managementIpAddress": row.get("managementIpAddress"),
                    "id":                  row.get("id"),
                    "advisoryIds":         row.get("advisoryIds", []),
                    "advisoryCount":       len(row.get("advisoryIds") or []),
                }
                for row in matched
            ]
            return str({
                "source": "dnac_db",
                "note":   "Applicability analysis not yet run — showing all DNAC-reported advisories (includes NOT_AFFECTED)",
                "data":   compact,
            })

        @tool
        def devices_per_advisory_tool(query: str) -> str:
            """Use this for devices affected by a specific advisory. Returns only devices where verdict is AFFECTED or NEEDS_REVIEW — NOT_AFFECTED devices are excluded. Input should include advisory id like cisco-sa-xxxx."""

            advisory_id = _extract_advisory_id_from_query(query)
            if not advisory_id:
                return "Please provide an advisory id like cisco-sa-xxxx."

            dnac_id = _extract_dnac_id_from_query(query)

            # Step 1: query applicability DB (AFFECTED + NEEDS_REVIEW only, NOT_AFFECTED excluded)
            if get_applicable_advisories_for_dnac is not None:
                try:
                    all_applicable = get_applicable_advisories_for_dnac(
                        dnac_id=dnac_id,
                        verdicts=["AFFECTED", "NEEDS_REVIEW"],
                    )
                    target = advisory_id.lower()
                    filtered = [
                        r for r in all_applicable
                        if str(r.get("advisoryId", "")).lower() == target
                    ]
                    if filtered:
                        compact = [
                            {
                                "hostname":            r.get("hostname"),
                                "managementIpAddress": r.get("managementIpAddress"),
                                "deviceId":            r.get("deviceId"),
                                "softwareVersion":     r.get("softwareVersion"),
                                "verdict":             r.get("verdict"),
                                "summary":             r.get("summary"),
                                "dnac_id":             r.get("dnac_id"),
                            }
                            for r in filtered
                        ]
                        return str({
                            "source":      "applicability_db",
                            "filter":      "AFFECTED and NEEDS_REVIEW only (NOT_AFFECTED excluded)",
                            "advisoryId":  advisory_id,
                            "deviceCount": len(compact),
                            "devices":     compact,
                        })
                    else:
                        return (
                            f"No AFFECTED devices found for advisory '{advisory_id}'"
                            + (f" on DNAC '{dnac_id}'" if dnac_id else "")
                            + ". Either no devices are affected or the applicability scan has not run yet."
                        )
                except Exception as exc:
                    logger.warning(f"Applicability DB devices-per-advisory failed: {exc}", exc_info=True)

            # Step 2: fallback — DNAC device list (applicability scan not yet run)
            if collect_impacted_devices is None:
                return "Postgres impacted devices query function is unavailable in this runtime."
            try:
                target = advisory_id.lower()
                rows = [
                    row
                    for row in list(collect_impacted_devices())
                    if any(str(a).lower() == target for a in (row.get("advisoryIds") or []))
                ]
                if not rows:
                    return f"No impacted devices found in PostgresDB for advisory '{advisory_id}'."
                compact = [
                    {
                        "hostname":            row.get("hostname"),
                        "managementIpAddress": row.get("managementIpAddress"),
                        "id":                  row.get("id"),
                        "softwareVersion":     row.get("softwareVersion"),
                        "reachabilityStatus":  row.get("reachabilityStatus"),
                    }
                    for row in rows
                ]
                return str({
                    "source":      "dnac_db",
                    "note":        "Applicability analysis not yet run — showing all DNAC-reported devices (includes NOT_AFFECTED)",
                    "advisoryId":  advisory_id,
                    "deviceCount": len(compact),
                    "devices":     compact,
                })
            except Exception as exc:
                logger.warning(f"Devices-per-advisory lookup failed: {exc}", exc_info=True)
                return f"Failed to fetch devices per advisory: {exc}"

        @tool
        def impacted_advisories_db_tool(query: str) -> str:
            """Use this for impacted advisories from PostgresDB. Supports optional advisory id filter (cisco-sa-...) and optional DNAC instance filter (e.g. 'for dnac noida')."""
            if collect_impacted_advisories is None:
                return "Postgres impacted advisories query function is unavailable in this runtime."

            try:
                dnac_id = _extract_dnac_id_from_query(query)
                rows = list(collect_impacted_advisories(dnac_id=dnac_id))
                advisory_id = _extract_advisory_id_from_query(query)
                if advisory_id:
                    target = advisory_id.lower()
                    rows = [row for row in rows if str(row.get("advisoryId", "")).lower() == target]
                if not rows:
                    if advisory_id and dnac_id:
                        return f"No impacted advisories found in PostgresDB for '{advisory_id}' on DNAC '{dnac_id}'."
                    if advisory_id:
                        return f"No impacted advisories found in PostgresDB for '{advisory_id}'."
                    if dnac_id:
                        return f"No impacted advisories found in PostgresDB for DNAC '{dnac_id}'."
                    return "No impacted advisories found in PostgresDB."
                return str(rows)
            except Exception as exc:
                logger.warning(f"Postgres impacted advisories query failed: {exc}", exc_info=True)
                return f"Failed to fetch impacted advisories from PostgresDB: {exc}"

        @tool
        def latest_discovery_report_db_tool(query: str) -> str:
            """Use this for latest discovery report from PostgresDB."""
            if latest_scan_report is None:
                return "Postgres latest discovery query function is unavailable in this runtime."

            try:
                rows = list(latest_scan_report())
                if not rows:
                    return "No discovery report found in PostgresDB."
                return str(rows)
            except Exception as exc:
                logger.warning(f"Postgres latest discovery report query failed: {exc}", exc_info=True)
                return f"Failed to fetch latest discovery report from PostgresDB: {exc}"

        @tool
        def introductory_tool(query: str) -> str:
            """Use this for greeting/capabilities questions."""
            return (
                "I am the RAG Advisory Agent. I answer Cisco security advisory, CVE, "
                "mitigation, and fix-related questions using the advisory knowledge base."
            )

        @tool
        def reload_rag_data_tool(query: str) -> str:
            """Use this to force refresh advisory data in the vector store when user asks to reload/sync/update the RAG knowledge base."""
            ensure_loaded(force_reload=True)
            return "RAG advisory data reload completed."

        return [
            rag_response_tool,
            impacted_devices_db_tool,
            advisories_per_device_tool,
            devices_per_advisory_tool,
            impacted_advisories_db_tool,
            latest_discovery_report_db_tool,
            introductory_tool,
            reload_rag_data_tool,
            fetch_and_store_impacted_advisories_tool,
            fetch_and_store_impacted_devices_tool,
        ]

    def _build_agent(self):
        tools = self._build_tools()
        logger.info("RAGLangChainAgent building tools")
        system_prompt = """You are a Cisco Security Advisory RAG Agent. You help network engineers and security teams 
analyze Cisco security advisories, CVEs, and their impact on network devices.

You have access to the following tools:
- rag_response_tool: For questions about Cisco advisories, CVEs, workarounds, mitigations, and fixed software versions
- impacted_devices_db_tool: For fetching impacted devices from the database, optionally filtered by advisory id or DNAC id
- advisories_per_device_tool: For fetching AFFECTED advisories for a specific device (by hostname, IP, or device id). Only returns AFFECTED and NEEDS_REVIEW results — NOT_AFFECTED is excluded.
- devices_per_advisory_tool: For fetching devices where a specific advisory (cisco-sa-...) is AFFECTED or NEEDS_REVIEW. NOT_AFFECTED devices are excluded.
- impacted_advisories_db_tool: For fetching impacted advisories from the database
- latest_discovery_report_db_tool: For fetching the latest network discovery/scan report
- reload_rag_data_tool: For reloading/refreshing the RAG knowledge base when asked
- introductory_tool: For greeting or capability questions

Guidelines:
- ALWAYS ask the user which DNAC instance to use if not specified. Available instances: us, noida, vj.
- When fetching devices or advisories, always pass the DNAC id explicitly (e.g. 'for dnac us').
- Always use the most specific tool for the query
- For advisory details (CVE, workaround, fix): use rag_response_tool
- For database queries about devices or advisories: use the appropriate db tool
- If a query mentions a specific advisory id (cisco-sa-...), extract and pass it to the tool
- If a query mentions a DNAC id, extract and pass it to the tool
- Be concise and accurate in your responses
- If no data is found, clearly say so and suggest what information the user could provide
"""
        # FIX 1 (continued): create_react_agent signature — model, tools, prompt
        return create_agent(model=self._llm, tools=tools, system_prompt=system_prompt)

    def ask(self, query: str) -> str:
        result = self._agent.invoke({"messages": [{"role": "user", "content": query}]})
        messages = result.get("messages", [])
        logger.info(f"RAGLangChainAgent messages {messages}")
        return str(messages[-1].content) if messages else str(result)


def run_rag_langchain_agent(
    query: str,
    model_name: Optional[str] = None,
    auto_load_data: bool = True,
) -> str:
    logger.info(f"model_name={model_name}, auto_load_data={auto_load_data}")
    agent = RAGLangChainAgent(model_name=model_name, auto_load_data=auto_load_data)
    return agent.ask(query)


if __name__ == "__main__":
    user_query = "get me the device names which are affected by cisco-sa-cat9k-PtmD7bgy?"
    print(run_rag_langchain_agent(user_query))