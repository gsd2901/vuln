import chromadb, json

client = chromadb.PersistentClient(path="./psirt_chroma_db")
col = client.get_collection("advisory_profiles")

for adv_id in [
    "cisco-sa-asr903-rsp3-arp-dos-WmfzdvJZ",
    "cisco-sa-20190327-evss",
    "cisco-sa-ios-http-dos-sbv8XRpL",
    "cisco-sa-xe-secureboot-bypass-B6uYxYSZ",
    "cisco-sa-iosxe-tls-dos-TVgLDEZL",
    "cisco-sa-cat9k-PtmD7bgy",
]:
    try:
        r = col.get(ids=[adv_id], include=["metadatas"])
        if r["ids"]:
            profile = json.loads(r["metadatas"][0]["profile_json"])
            print(f"{adv_id}")
            print(f"  fixed_releases : {profile.get('fixed_releases')}")
            print(f"  affected_versions: {profile.get('affected_versions')}")
        else:
            print(f"{adv_id} → NOT IN CACHE")
    except Exception as e:
        print(f"{adv_id} → ERROR: {e}")