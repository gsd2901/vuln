import os
from openai import AzureOpenAI
from langchain_openai import AzureChatOpenAI
import httpx 
endpoint = "https://git-nw-openai-llm-prod.openai.azure.com/"
model_name = "gpt-4.1"
deployment = "gpt-4.1"
 
#https://git-nw-openai-llm-prod.openai.azure.com/openai/deployments/gpt-4.1/chat/completions?api-version=2025-01-01-preview
 
subscription_key = "5kRpMIyDt06ImaRoayI76KuQuO9Cdt9s32YEh7lCZ9BK5sEIqZDbJQQJ99CAAC77bzfXJ3w3AAABACOGLOOn"
api_version = "2025-01-01-preview"

# llm = AzureChatOpenAI(
#     azure_deployment="gpt-4.1",  # <-- your deployment name
#     api_version="2025-01-01-preview",
#     azure_endpoint="https://git-nw-openai-llm-prod.openai.azure.com/",
#     http_client=httpx.Client(verify=False),  # Not recommended for production
#     api_key="5kRpMIyDt06ImaRoayI76KuQuO9Cdt9s32YEh7lCZ9BK5sEIqZDbJQQJ99CAAC77bzfXJ3w3AAABACOGLOOn",
# ) 
client = AzureOpenAI(
  api_version=api_version,
  azure_endpoint="https://git-nw-openai-llm-prod.openai.azure.com",
  api_key=subscription_key,
)
 
response = client.chat.completions.create(
   messages=[
       {
          "role": "system",
          "content": "You are a helpful assistant.",
       },
       {
          "role": "user",
          "content": "HOw many continents and countries are there what are their capitals?",
       }
   ],
  max_completion_tokens=13107,
   temperature=1.0,
   top_p=1.0,
  frequency_penalty=0.0,
  presence_penalty=0.0,
   model=deployment
)
 
print(response.choices[0].message.content)