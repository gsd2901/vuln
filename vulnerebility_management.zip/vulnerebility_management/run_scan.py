"""
run_scan.py
───────────
Standalone script to:
  1. Fetch advisories + devices from DNAC
  2. Store them into PostgreSQL
  3. Trigger the background applicability engine

Run from the rag_agent_project/ root:

    # Scan a specific DNAC instance (key from config.DNAC_INSTANCES):
    python run_scan.py --dnac noida

    # Scan all configured DNAC instances one by one:
    python run_scan.py --all

    # Scan the legacy single-DNAC (DNAC_HOST in config.py):
    python run_scan.py

    # Block until the scan finishes (instead of exiting immediately):
    python run_scan.py --dnac noida --wait

Also importable — call run_scan(dnac_id) from psirt_chatbot.py or anywhere else.
"""

import argparse
import logging
import os
import sys
import threading
import time

# ── Make project root importable ─────────────────────────────────────────────
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
if BASE_DIR not in sys.path:
    sys.path.insert(0, BASE_DIR)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)
logger = logging.getLogger("run_scan")


# ── Main scan function ────────────────────────────────────────────────────────

def run_scan(
    dnac_id: str | None = None,
    wait: bool = False,
    ssh_username: str = "",
    ssh_password: str = "",
    ssh_port: int = 22,
) -> dict:
    """
    Full scan pipeline for one DNAC instance:
      Step 1 — Authenticate + fetch advisories and devices from DNAC
      Step 2 — Store them into PostgreSQL (impactedadvisories + devices collections)
      Step 3 — Trigger background applicability engine (non-blocking thread)

    Parameters
    ----------
    dnac_id      : key from config.DNAC_INSTANCES, or None for the legacy single-DNAC
    wait         : if True, block until the background thread finishes
    ssh_username : SSH username for device command collection fallback
    ssh_password : SSH password for device command collection fallback
    ssh_port     : SSH port (default 22)

    Returns a status dict:
    {
        "dnac_id":              str | None,
        "advisories_fetched":   int,
        "devices_fetched":      int,
        "scan_triggered_at":    str (ISO-8601),
        "status":               "ok" | "error",
        "error":                str | None
    }
    """
    result = {
        "dnac_id": dnac_id,
        "advisories_fetched": 0,
        "devices_fetched": 0,
        "scan_triggered_at": None,
        "status": "ok",
        "error": None,
        "ssh_fallback_enabled": bool(ssh_username),
    }

    # ── Step 0: resolve DNAC config ───────────────────────────────────────────
    try:
        from config import DNAC_INSTANCES, DNAC_HOST, DNAC_USERNAME, DNAC_PASSWORD
    except Exception as exc:
        result["status"] = "error"
        result["error"] = f"Cannot import config: {exc}"
        return result

    if dnac_id and dnac_id in DNAC_INSTANCES:
        cfg = DNAC_INSTANCES[dnac_id]
        host     = cfg["host"]
        username = cfg["username"]
        password = cfg["password"]
        port     = cfg.get("port", 443)
    elif dnac_id:
        result["status"] = "error"
        result["error"] = (
            f"dnac_id '{dnac_id}' not found in config.DNAC_INSTANCES. "
            f"Available: {list(DNAC_INSTANCES.keys())}"
        )
        return result
    else:
        # Legacy single-DNAC fallback
        host, username, password, port = DNAC_HOST, DNAC_USERNAME, DNAC_PASSWORD, 443

    logger.info("[SCAN] DNAC host=%s  dnac_id=%s", host, dnac_id or "(legacy)")

    # ── Step 1: authenticate ──────────────────────────────────────────────────
    try:
        from dnac.dnacenter import DNAC
        dnac = DNAC(host=host, username=username, password=password, port=port)
        dnac.login()
        token = dnac.header.get("x-auth-token", "")
        if not token:
            raise RuntimeError("Empty token after login()")
        logger.info("[SCAN] Authenticated to DNAC successfully.")
    except Exception as exc:
        result["status"] = "error"
        result["error"] = f"DNAC auth failed: {exc}"
        logger.error("[SCAN] %s", result["error"])
        return result

    # ── Step 2a: fetch + store advisories ─────────────────────────────────────
    try:
        from db.quries_postgresql import store_impacted_advisories
        advisories_raw = dnac.get_advisories_list()["response"]
        store_impacted_advisories(advisories_raw, dnac_id=dnac_id)
        result["advisories_fetched"] = len(advisories_raw)
        logger.info("[SCAN] Advisories fetched and stored: %d", len(advisories_raw))
    except Exception as exc:
        result["status"] = "error"
        result["error"] = f"Advisory fetch/store failed: {exc}"
        logger.error("[SCAN] %s", result["error"])
        return result

    # ── Step 2b: fetch + store devices ────────────────────────────────────────
    try:
        from db.quries_postgresql import store_impacted_devices
        # get_all_devices() paginates through offset/limit until every page is
        # collected — get_device_list() alone only returns the first page
        # (commonly capped at 500), which silently truncated larger sites.
        devices_raw = dnac.get_all_devices()
        store_impacted_devices(devices_raw, dnac_id=dnac_id)
        result["devices_fetched"] = len(devices_raw)
        logger.info("[SCAN] Devices fetched and stored: %d", len(devices_raw))
    except Exception as exc:
        # Non-fatal — advisories are already stored, scan can still run
        logger.warning("[SCAN] Device fetch/store failed: %s — continuing.", exc)

    # ── Step 2c: clear ChromaDB advisory cache (always start fresh) ──────────
    try:
        from psirt.applicability_engine import clear_advisory_profile_cache
        deleted = clear_advisory_profile_cache()
        logger.info("[SCAN] ChromaDB advisory cache cleared (%d profiles removed).", deleted)
    except Exception as exc:
        logger.warning("[SCAN] ChromaDB cache clear failed (non-fatal): %s", exc)

    # ── Step 3: trigger background applicability engine ───────────────────────
    try:
        from psirt.background_scanner import trigger_applicability_scan
        scan_triggered_at = trigger_applicability_scan(
            dnac,
            dnac_id=dnac_id,
            ssh_username=ssh_username,
            ssh_password=ssh_password,
        )
        result["scan_triggered_at"] = scan_triggered_at
        logger.info("[SCAN] Applicability engine triggered at %s", scan_triggered_at)
    except Exception as exc:
        result["status"] = "error"
        result["error"] = f"Could not trigger applicability engine: {exc}"
        logger.error("[SCAN] %s", result["error"])
        return result

    # ── Optional: wait for background thread to finish ────────────────────────
    if wait:
        logger.info("[SCAN] --wait mode: blocking until scan thread finishes…")
        _wait_for_scan_thread(dnac_id, scan_triggered_at)
        logger.info("[SCAN] Scan thread finished.")

    return result


def _wait_for_scan_thread(dnac_id: str | None, scan_triggered_at: str) -> None:
    """Poll active threads until the psirt-scan thread for this run exits."""
    thread_prefix = f"psirt-scan-{dnac_id or 'default'}"
    while True:
        alive = [
            t for t in threading.enumerate()
            if t.name.startswith(thread_prefix)
            and scan_triggered_at[:19] in t.name
        ]
        if not alive:
            break
        time.sleep(5)


# ── Scan all DNAC instances ───────────────────────────────────────────────────

def run_scan_all(
    wait: bool = False,
    ssh_username: str = "",
    ssh_password: str = "",
    ssh_port: int = 22,
) -> list[dict]:
    """Run run_scan() for every key in config.DNAC_INSTANCES."""
    try:
        from config import DNAC_INSTANCES
    except Exception as exc:
        logger.error("Cannot import config: %s", exc)
        return []

    results = []
    for dnac_id in DNAC_INSTANCES:
        logger.info("[SCAN] ── Starting scan for dnac_id=%s ──", dnac_id)
        r = run_scan(
            dnac_id=dnac_id,
            wait=wait,
            ssh_username=ssh_username,
            ssh_password=ssh_password,
            ssh_port=ssh_port,
        )
        results.append(r)
        _log_result(r)
    return results


def _log_result(r: dict) -> None:
    if r["status"] == "ok":
        logger.info(
            "[SCAN] ✓ dnac_id=%-12s | advisories=%-4d | devices=%-4d | triggered_at=%s",
            r["dnac_id"] or "legacy",
            r["advisories_fetched"],
            r["devices_fetched"],
            r["scan_triggered_at"],
        )
    else:
        logger.error(
            "[SCAN] ✗ dnac_id=%-12s | ERROR: %s",
            r["dnac_id"] or "legacy",
            r["error"],
        )


# ── CLI ───────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="Fetch DNAC advisories/devices and run PSIRT applicability engine."
    )
    parser.add_argument(
        "--dnac",
        metavar="DNAC_ID",
        help="DNAC instance key from config.DNAC_INSTANCES (e.g. noida, us, vj)",
    )
    parser.add_argument(
        "--all",
        action="store_true",
        help="Scan ALL DNAC instances configured in config.DNAC_INSTANCES",
    )
    parser.add_argument(
        "--wait",
        action="store_true",
        help="Block until the background applicability thread finishes",
    )
    parser.add_argument(
        "--ssh-user",
        metavar="USERNAME",
        default="",
        help="SSH username for device command collection fallback",
    )
    parser.add_argument(
        "--ssh-pass",
        metavar="PASSWORD",
        default="",
        help="SSH password for device command collection fallback",
    )
    parser.add_argument(
        "--ssh-port",
        metavar="PORT",
        type=int,
        default=22,
        help="SSH port (default 22)",
    )
    args = parser.parse_args()

    if args.all:
        results = run_scan_all(
            wait=args.wait,
            ssh_username=args.ssh_user,
            ssh_password=args.ssh_pass,
            ssh_port=args.ssh_port,
        )
        failed = [r for r in results if r["status"] == "error"]
        if failed:
            sys.exit(1)
    else:
        result = run_scan(
            dnac_id=args.dnac,
            wait=args.wait,
            ssh_username=args.ssh_user,
            ssh_password=args.ssh_pass,
            ssh_port=args.ssh_port,
        )
        _log_result(result)
        if result["status"] == "error":
            sys.exit(1)