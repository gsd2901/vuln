"""
rag_agent_project/tools/endpoints.py  (updated)
────────────────────────────────────────────────
Changes vs the original:
  1. trigger_applicability_scan() called after every advisory + device store.
  2. New helper  get_device_advisories_filtered()  — returns only AFFECTED
     advisories for a device when applicability_checked=True; falls back to
     the full impactedadvisories list when the check hasn't run yet.
  3. New endpoint helper  applicability_summary_endpoint()  for dashboards.
"""

import logging

try:
    from rag_agent_project.config import DNAC_INSTANCES
except Exception:
    from config import DNAC_INSTANCES

try:
    from rag_agent_project.dnac.dnacenter import DNAC
except Exception:
    from dnac.dnacenter import DNAC

try:
    from rag_agent_project.db.functions_postgresql import get_cmd_response_text, get_workaround_from_advisory
except Exception:
    from db.functions_postgresql import get_cmd_response_text, get_workaround_from_advisory

try:
    from rag_agent_project.db.quries_postgresql import (
        collect_before_scan_status,
        collect_scan_advisory_report_by_time,
        collect_scan_report_by_time,
        filter_instanceUuid_by_managementIpAddress,
        get_latest_scantime,
        latest_scan_report,
        store_impacted_advisories,
        store_impacted_devices,
    )
except Exception:
    from db.quries_postgresql import (
        collect_before_scan_status,
        collect_scan_advisory_report_by_time,
        collect_scan_report_by_time,
        filter_instanceUuid_by_managementIpAddress,
        get_latest_scantime,
        latest_scan_report,
        store_impacted_advisories,
        store_impacted_devices,
    )

try:
    from rag_agent_project.tools.utils import (
        advisory_device_discovery_manual_ticket,
        create_ticket_update_advisory_scan_collection,
        dnac_device_commands_executor,
        store_advisory_data,
        store_device_data,
    )
except Exception:
    from tools.utils import (
        advisory_device_discovery_manual_ticket,
        create_ticket_update_advisory_scan_collection,
        dnac_device_commands_executor,
        store_advisory_data,
        store_device_data,
    )

# ── PSIRT applicability integration ──────────────────────────────────────────
try:
    from psirt.background_scanner import trigger_applicability_scan
    from psirt.db_queries import (
        get_applicable_advisories_for_device,
        get_applicable_advisories_for_dnac,
        get_summary_counts,
        is_applicability_checked,
    )
    PSIRT_ENABLED = True
except Exception as _psirt_err:
    PSIRT_ENABLED = False
    logging.getLogger(__name__).warning(
        "PSIRT applicability module not available: %s", _psirt_err
    )

logger = logging.getLogger(__name__)


# ── DNAC client factory (unchanged) ──────────────────────────────────────────

def _get_dnac_client(dnac_id: str | None = None) -> DNAC:
    """
    Return a DNAC client for the requested instance.
    Falls back to the legacy single-DNAC configuration when dnac_id is
    absent or not found in DNAC_INSTANCES.
    """
    if dnac_id and dnac_id in DNAC_INSTANCES:
        cfg = DNAC_INSTANCES[dnac_id]
        return DNAC(
            host=cfg["host"],
            username=cfg["username"],
            password=cfg["password"],
            port=cfg.get("port", 443),
        )
    # Legacy fallback
    try:
        from rag_agent_project.config import DNAC_HOST, DNAC_USERNAME, DNAC_PASSWORD
    except Exception:
        from config import DNAC_HOST, DNAC_USERNAME, DNAC_PASSWORD
    return DNAC(host=DNAC_HOST, username=DNAC_USERNAME, password=DNAC_PASSWORD)


# ── Existing helpers (unchanged logic, applicability trigger added) ────────────

def discovery_result_from_db():
    scanInitiatedTime = get_latest_scantime()[0]["scanInitiatedTime"]
    discovery_report = list(collect_scan_report_by_time(scanInitiatedTime))[0]

    discovery_report_response = []
    reports_dict = {
        report["advisoryId"]: report for report in discovery_report["reports"]
    }

    for advisory in discovery_report["advisories"]:
        advisoryId = advisory.get("advisoryId", "")
        report = reports_dict.get(advisoryId)
        advisory_url = (
            f"https://sec.cloudapps.cisco.com/security/center/content/"
            f"CiscoSecurityAdvisory/{advisoryId}"
        )
        workaround_text = get_workaround_from_advisory(advisory_url)

        advisory_data = {
            "advisoryId": advisoryId,
            "advisoryTitle": advisory.get("title", ""),
            "advisoryUrl": advisory_url,
            "workaround": workaround_text,
            "cves": advisory.get("cves", []),
            "sir": advisory.get("sir", ""),
            "commands": advisory.get("cmds", []),
            "affected_devices": advisory.get("affected_devices", []),
            "affected_device_count": len(advisory.get("affected_devices", [])),
        }
        discovery_report_response.append(advisory_data)

    return scanInitiatedTime, discovery_report_response


def impacted_advisories_endpoint(dnac_id: str | None = None):
    dnac = _get_dnac_client(dnac_id)
    advisories_response = dnac.get_advisories_list()["response"]
    store_impacted_advisories(advisories_response, dnac_id=dnac_id)

    # ── Trigger background applicability scan ─────────────────────────────
    if PSIRT_ENABLED:
        try:
            trigger_applicability_scan(dnac, dnac_id=dnac_id)
            logger.info(
                "[PSIRT] Applicability scan triggered for dnac_id=%s", dnac_id
            )
        except Exception as exc:
            logger.warning("[PSIRT] Could not trigger scan: %s", exc)

    result = [
        {"advisoryId": item["advisoryId"], "deviceCount": item["deviceCount"]}
        for item in advisories_response
    ]
    return result


def enhanced_advisories_endpoint(dnac_id: str | None = None):
    """Get enhanced advisory details with discovery data integration."""
    dnac = _get_dnac_client(dnac_id)
    advisories_response = dnac.get_advisories_list()["response"]
    store_impacted_advisories(advisories_response, dnac_id=dnac_id)

    # ── Trigger background applicability scan ─────────────────────────────
    if PSIRT_ENABLED:
        try:
            trigger_applicability_scan(dnac, dnac_id=dnac_id)
            logger.info(
                "[PSIRT] Applicability scan triggered for dnac_id=%s", dnac_id
            )
        except Exception as exc:
            logger.warning("[PSIRT] Could not trigger scan: %s", exc)

    enhanced_advisories = []
    try:
        scanInitiatedTime, discovery_report_response = discovery_result_from_db()
        discovery_advisories = {
            adv["advisoryId"]: adv for adv in discovery_report_response
        }

        for item in advisories_response:
            advisory_id = item["advisoryId"]
            advisory_url = (
                f"https://sec.cloudapps.cisco.com/security/center/content/"
                f"CiscoSecurityAdvisory/{advisory_id}"
            )
            enhanced_data = discovery_advisories.get(advisory_id, {})
            advisory_data = {
                "advisoryId": advisory_id,
                "deviceCount": item["deviceCount"],
                "advisoryUrl": advisory_url,
                "advisoryTitle": enhanced_data.get("advisoryTitle", ""),
                "workaround": enhanced_data.get("workaround", ""),
                "cves": enhanced_data.get("cves", item.get("cves", [])),
                "sir": enhanced_data.get("sir", item.get("sir", "")),
                "commands": enhanced_data.get("commands", []),
                "affected_devices": enhanced_data.get("affected_devices", []),
                "affected_device_count": enhanced_data.get("affected_device_count", 0),
            }
            enhanced_advisories.append(advisory_data)
    except Exception as exc:
        logger.warning("Could not enhance advisories with discovery data: %s", exc)
        enhanced_advisories = [
            {"advisoryId": item["advisoryId"], "deviceCount": item["deviceCount"]}
            for item in advisories_response
        ]

    return enhanced_advisories


def impacted_devices_endpoint(dnac_id: str | None = None):
    logger.info("impacted_devices_endpoint called with dnac_id='%s'", dnac_id)
    try:
        dnac = _get_dnac_client(dnac_id)
        # get_all_devices() paginates through offset/limit — get_device_list()
        # alone only returns the first page (commonly capped at 500).
        devices_response = dnac.get_all_devices()
        store_impacted_devices(devices_response, dnac_id=dnac_id)

        # Store advisory data too, then trigger scan
        try:
            from rag_agent_project.db.database_postgresql import PostgreSQLConnector
        except Exception:
            from db.database_postgresql import PostgreSQLConnector

        db = PostgreSQLConnector("AdvisoryDatabase")
        advisory_col = db.collection("advisories")
        device_col = db.collection("devices")
        store_advisory_data(dnac, advisory_col, dnac_id=dnac_id)
        store_device_data(dnac, device_col, dnac_id=dnac_id)
        db.close()

        # ── Trigger background applicability scan ─────────────────────────
        if PSIRT_ENABLED:
            try:
                trigger_applicability_scan(dnac, dnac_id=dnac_id)
                logger.info(
                    "[PSIRT] Applicability scan triggered for dnac_id=%s", dnac_id
                )
            except Exception as exc:
                logger.warning("[PSIRT] Could not trigger scan: %s", exc)

        return devices_response
    except Exception as exc:
        logger.error("impacted_devices_endpoint failed: %s", exc, exc_info=True)
        raise


def creating_snow_tickets_endpoint(scanInitiatedAt, ticket_options):
    """Unchanged — kept for backward compatibility."""
    try:
        from rag_agent_project.db.database_postgresql import PostgreSQLConnector
    except Exception:
        from db.database_postgresql import PostgreSQLConnector

    db = PostgreSQLConnector("AdvisoryDatabase")
    advisory_scan_col = db.collection("advisory_scan")

    from rag_agent_project.db.quries_postgresql import collect_scan_advisory_report_by_time
    advisories = list(collect_scan_advisory_report_by_time(scanInitiatedAt))

    from rag_agent_project.llm.llm_utils import dochat
    tool_msg, ai_msg = create_ticket_update_advisory_scan_collection(
        advisories, advisory_scan_col, ticket_options, advisories
    )
    db.close()
    return tool_msg, ai_msg


def message_update_database(input_data, ai_msg, tool_msg):
    """Unchanged — kept for backward compatibility."""
    pass


# ── NEW: Filtered advisory query for a device ─────────────────────────────────

def get_device_advisories_filtered(
    device_id: str,
    dnac_id: str | None = None,
) -> dict:
    """
    Return advisories for a device, respecting the applicability flag.

    Logic:
      - If applicability_checked = True exists for this device → return only
        AFFECTED / NEEDS_REVIEW rows (NOT_AFFECTED are excluded).
      - If no check has run yet → return the raw impactedadvisories from DB
        (the full DNAC list) so the caller is never left with an empty result.

    Response shape:
    {
        "device_id":            str,
        "dnac_id":              str | null,
        "applicability_source": "checked" | "raw_dnac",
        "advisories":           [ { advisoryId, verdict, summary, ... } ]
    }
    """
    if not PSIRT_ENABLED:
        return {
            "device_id": device_id,
            "dnac_id": dnac_id,
            "applicability_source": "psirt_disabled",
            "advisories": [],
        }

    checked_rows = get_applicable_advisories_for_device(device_id, dnac_id)

    if checked_rows:
        return {
            "device_id": device_id,
            "dnac_id": dnac_id,
            "applicability_source": "checked",
            "advisories": checked_rows,
        }

    # Fallback: return raw DNAC advisories (check not yet complete)
    from db.quries_postgresql import collect_impacted_advisories

    raw = collect_impacted_advisories(dnac_id=dnac_id)
    return {
        "device_id": device_id,
        "dnac_id": dnac_id,
        "applicability_source": "raw_dnac",
        "advisories": raw,
    }


# ── NEW: Applicability summary for dashboards ─────────────────────────────────

def applicability_summary_endpoint(dnac_id: str | None = None) -> dict:
    """
    Return a summary of applicability verdicts for a DNAC instance.

    Response shape:
    {
        "dnac_id": str | null,
        "counts": {
            "AFFECTED":     int,
            "NOT_AFFECTED": int,
            "NEEDS_REVIEW":   int,
            "MITIGATED":      int,
            "PENDING":        int
        },
        "applicable_advisories": [ { advisoryId, hostname, verdict, summary } ]
    }
    """
    if not PSIRT_ENABLED:
        return {
            "dnac_id": dnac_id,
            "counts": {},
            "applicable_advisories": [],
            "error": "PSIRT module not enabled",
        }

    counts = get_summary_counts(dnac_id=dnac_id)
    applicable_rows = get_applicable_advisories_for_dnac(
        dnac_id=dnac_id,
        verdicts=["AFFECTED", "NEEDS_REVIEW"],
    )

    return {
        "dnac_id": dnac_id,
        "counts": counts,
        "applicable_advisories": [
            {
                "advisoryId": r.get("advisoryId"),
                "hostname": r.get("hostname"),
                "managementIpAddress": r.get("managementIpAddress"),
                "verdict": r.get("verdict"),
                "summary": r.get("summary"),
                "checked_at": r.get("checked_at"),
                "collection_method": r.get("collection_method"),
            }
            for r in applicable_rows
        ],
    }
