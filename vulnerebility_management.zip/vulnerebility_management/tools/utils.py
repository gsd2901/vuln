import json
import logging
import requests
from bs4 import BeautifulSoup
from datetime import datetime
from time import sleep
from config import BASE_DIR 
from pprint import pprint
 
CLI_COMMANDS_COLLECTOR_IMPORT_ERROR = None
 
try:
    from rag_agent_project.config import SERVICENOW_INSTANCE_URL, SERVICENOW_BOT_USERNAME, SERVICENOW_BOT_PASSWORD
except Exception:
    from config import SERVICENOW_INSTANCE_URL, SERVICENOW_BOT_USERNAME, SERVICENOW_BOT_PASSWORD
 
try:
    from rag_agent_project.servicenow import ServiceNowAPI
except Exception:
    try:
        from servicenow import ServiceNowAPI
    except Exception:
        ServiceNowAPI = None
 
try:
    from llm.llm_utils import cli_commands_collector
except Exception as exc:
    CLI_COMMANDS_COLLECTOR_IMPORT_ERROR = exc
    try:
        from llm.llm_utils import cli_commands_collector
    except Exception as fallback_exc:
        CLI_COMMANDS_COLLECTOR_IMPORT_ERROR = fallback_exc
        cli_commands_collector = None
 
try:
    from rag_agent_project.quries_postgresql import collect_before_scan_records, update_scan_data, collect_scan_report_by_time, all_devices
except Exception:
    try:
        from db.quries_postgresql import collect_before_scan_records, update_scan_data, collect_scan_report_by_time, all_devices
    except Exception:
        collect_before_scan_records = None
        update_scan_data = None
        collect_scan_report_by_time = None
        all_devices = None
 
logger = logging.getLogger(__name__)
logger.addHandler(logging.StreamHandler())
logger.setLevel(logging.INFO)
 
 
def store_advisory_data(dnac, advisory_collection, dnac_id: str | None = None):
    try:
        print("[store_advisory_data] start")
        print(f"[store_advisory_data] cli_commands_collector available: {cli_commands_collector is not None}")
        if CLI_COMMANDS_COLLECTOR_IMPORT_ERROR is not None:
            print(
                f"[store_advisory_data] cli_commands_collector import error: "
                f"{type(CLI_COMMANDS_COLLECTOR_IMPORT_ERROR).__name__}: {CLI_COMMANDS_COLLECTOR_IMPORT_ERROR}"
            )
        # Scope the active-flag reset and the existing-record lookup to this
        # DNAC instance so scanning one DNAC doesn't clobber another DNAC's
        # rows or mix their devices together (legacy 'advisories'/'devices'
        # collections previously had no dnac_id at all).
        active_reset_filter = {"dnac_id": dnac_id} if dnac_id is not None else {}
        advisory_collection.update_many(active_reset_filter, {"$set": {"active": False}})
        all_uuids = [device["instanceUuid"] for device in all_devices(dnac_id=dnac_id)]
        # To get Security Advisory
        advisory = dnac.get_advisories_list()
        print("[store_advisory_data] raw advisories keys:", advisory.keys())
        filtered_advisories = [adv for adv in advisory.get('response', []) if adv.get('sir') in ["CRITICAL", "HIGH"]]
        print("[store_advisory_data] filtered advisories count:", len(filtered_advisories))
        for advisory in filtered_advisories:
            advisory_id = advisory["advisoryId"]
            print(f"\n[store_advisory_data] --- processing: {advisory_id} ---")
            lookup_filter = {"advisoryId": advisory_id}
            if dnac_id is not None:
                lookup_filter["dnac_id"] = dnac_id
            existing_advisory = advisory_collection.find_one(lookup_filter)
            if existing_advisory:
                print(f"[store_advisory_data] existing record found. current cmds={repr(existing_advisory.get('cmds'))[:80]}, data present={bool(existing_advisory.get('data'))}")
                affected_devices = dnac.get_all_devices_per_advisory(advisory_id)
                affected_devices = [d for d in affected_devices if d in all_uuids]
                update_fields = {"affected_devices": affected_devices, "active": True}
                if dnac_id is not None:
                    update_fields["dnac_id"] = dnac_id

                if cli_commands_collector is not None and not existing_advisory.get("cmds"):
                    print(f"[store_advisory_data] backfilling cmds for {advisory_id}")
                    title = existing_advisory.get("title")
                    data = existing_advisory.get("data")
                    if not data:
                        print(f"[store_advisory_data] no data in DB, fetching from URL: {_sanitize_url(advisory['publicationUrl'])}")
                        title, data = extract_content_from_url(_sanitize_url(advisory["publicationUrl"]))
                        print(f"[store_advisory_data] fetched data length: {len(data) if data else 0}")
                        update_fields["title"] = title
                        update_fields["data"] = data
                    else:
                        print(f"[store_advisory_data] using existing data (length={len(data)})")
                    logger.info(f"Backfilling cmds for advisory {advisory_id}")
                    cmds_result = cli_commands_collector(data)
                    print(f"[store_advisory_data] cmds_result={repr(cmds_result)[:120]}")
                    update_fields["cmds"] = cmds_result
                elif existing_advisory.get("cmds"):
                    print(f"[store_advisory_data] cmds already present, skipping backfill")
                else:
                    print(f"[store_advisory_data] cli_commands_collector is None, cannot backfill cmds")

                advisory_collection.update_one(
                    lookup_filter,
                    {
                        "$set": update_fields
                    }
                )
                print(f"[store_advisory_data] updated existing advisory {advisory_id}")
            else:
                print(f"[store_advisory_data] new advisory, fetching URL: {_sanitize_url(advisory['publicationUrl'])}")
                title, data = extract_content_from_url(advisory["publicationUrl"])
                print(f"[store_advisory_data] fetched title={repr(title)}, data length={len(data) if data else 0}")
                affected_devices = dnac.get_all_devices_per_advisory(advisory_id)
                affected_devices = [d for d in affected_devices if d in all_uuids]
                json_wrapper = {
                    "title": title,
                    "advisoryId": advisory_id,
                    "publicationUrl": advisory["publicationUrl"],
                    "sir": advisory["sir"],
                    "cves": advisory["cves"],
                    "data": data,
                    "cmds": None,
                    "affected_devices": affected_devices,
                    "active": True
                }
                if dnac_id is not None:
                    json_wrapper["dnac_id"] = dnac_id

                # Enrich with CLI commands only if the collector is available
                if cli_commands_collector is not None:
                    logger.info(f"Prompt generation for {advisory_id}")
                    chat_data = cli_commands_collector(data)
                    print(f"[store_advisory_data] new advisory cmds_result={repr(chat_data)[:120]}")
                    logger.info(f"Collect cmds {advisory_id}")
                    json_wrapper['cmds'] = chat_data
                else:
                    print(f"[store_advisory_data] cli_commands_collector is None — inserting without cmds")
                    logger.info(
                        f"cli_commands_collector is not available; storing advisory {advisory_id} without cmds"
                    )

                advisory_collection.insert_one(json_wrapper)
                logger.info(f"Inserted advisory: {advisory_id}")
    except Exception as e:
        print("[store_advisory_data] error:", repr(e))
        import traceback
        traceback.print_exc()


def store_device_data(dnac, device_collection, dnac_id: str | None = None):
    try:
        # To get Device List
        # get_all_devices() paginates through offset/limit — get_device_list()
        # alone only returns the first page (commonly capped at 500).
        devices = dnac.get_all_devices()

        if dnac_id is not None:
            # Scoped clear + insert (same pattern as store_impacted_devices()
            # in db/quries_postgresql.py): removes this DNAC's stale rows
            # first, then tags every inserted device with dnac_id. Prevents
            # devices from different DNAC instances being mixed together or
            # silently overwritten via instanceUuid collisions.
            device_collection.delete_many({"dnac_id": dnac_id})
            tagged_devices = []
            for device in devices:
                if isinstance(device, dict):
                    tagged = dict(device)
                    tagged["dnac_id"] = dnac_id
                    tagged_devices.append(tagged)
            if tagged_devices:
                device_collection.insert_many(tagged_devices)
            logger.info(f"Stored {len(tagged_devices)} devices for dnac_id='{dnac_id}'")
        else:
            # Legacy behavior for callers that don't pass dnac_id: upsert by
            # instanceUuid with no dnac_id tagging.
            for device in devices:
                if not device_collection.find_one({"instanceUuid": device["instanceUuid"]}):
                    device_collection.insert_one(device)
                    logger.info(f"Inserted device: {device['instanceUuid']}")
                else:
                    device_collection.update_one({"instanceUuid": device["instanceUuid"]},{"$set":device})
                    logger.info(f"Updated device: {device['instanceUuid']}")
    except Exception as e:
        logger.debug(e)
 
 
def dnac_device_commands_executor(dnac, cmds, affected_devices):
    print(f"Executing commands:{cmds}, on devices: {affected_devices}")
    payload = {"commands": cmds, "deviceUuids": affected_devices}
    cli_execution = dnac.post(path="network-device-poller/cli/read-request", payload=payload)['response']
    print(cli_execution)
    task_info = get_task_result(dnac, cli_execution)
    if 'fileId' in task_info['progress']:
        return dnac.get(path=f"file/{json.loads(task_info['progress'])['fileId']}")
 
 
def servicenow_ticket_creator(new_devices, advisory, cmds_response, ticket_type, scanInitiatedTime):
    if ticket_type == "no":
        return {"sys_id": "No Ticket", "number": "No Ticket", "devices": list(new_devices), "scanInitiatedTime": scanInitiatedTime}
    else:
        snow_api = ServiceNowAPI(SERVICENOW_INSTANCE_URL, SERVICENOW_BOT_USERNAME, SERVICENOW_BOT_PASSWORD)
        priorities = {1: "1 - Critical", 2: "2 - High", 3: "3 - Moderate", 4: "4 - Low", 5: "5 - Planning"}
        urgencies = {1: "1 - High", 2: "2 - Medium", 3: "3 - Low"}
        if ticket_type == "incident":
            status = {1: "New", 2: "In Progress", 3: "On Hold", 6: "Resolved", 7: "Closed", 8: "Canceled"}
        else:
            status = {-5: "New", -4: "Assess", -3: "Authorize", -2: "Scheduled", -1: "Implement", 0: "Review",
                      3: "Closed",
                      4: "Canceled"}
        ticket_response = snow_api.create_advisory_device_servicenow_tickets(advisory, cmds_response, ticket_type)
        pprint(ticket_response)
        new_ticket = {
            "sys_id": ticket_response['sys_id'],
            "number": ticket_response['number'],
            "tickettype": ticket_type,
            "category": ticket_response['category'],
            "short_description": ticket_response['short_description'],
            "description": ticket_response['description'],
            "sys_created_on": ticket_response['sys_created_on'],
            "sys_created_by": ticket_response['sys_created_by'],
            "sys_updated_on": ticket_response['sys_updated_on'],
            "sys_updated_by": ticket_response['sys_updated_by'],
            "impact": urgencies[int(ticket_response["impact"])],
            "urgency": urgencies[int(ticket_response["urgency"])],
            "priority": priorities[int(ticket_response["priority"])],
            "status": status[int(ticket_response["state"])],
            "devices": list(new_devices),
            "scanInitiatedTime": scanInitiatedTime
        }
        return new_ticket
 
 
def advisory_device_discovery(dnac, advisory_scan_collection, scanType):
    # Fetch the current mapping entry
    scanInitiatedTime = datetime.utcnow().isoformat()
    advisories = collect_before_scan_records()
    all_uuids = [device["instanceUuid"] for device in all_devices()]
    ticket_deatils = list()
    print(advisories)
    for advisory in advisories:
        print(advisory)
        advisory_cmds = advisory.get("cmds")
        new_devices = advisory['new_devices']
        existing_devices = advisory['scanned_devices']
        unchanged_devices = advisory['unchanged_devices']
        affected_devices = advisory['affected_devices']
        ticket_type = "incident"
        if not advisory_cmds:
            logger.info(f"No cmds found for advisory {advisory.get('advisoryId')}; skipping command execution.")
            continue
        if new_devices or unchanged_devices:
            print("Entered")
            # Scenario 1: No new devices; no action required
            if not new_devices and set(unchanged_devices) == set(existing_devices):
                print("Scenario 1")
                logger.info(f"Scenario 1: No new devices. No action needed for advisory {advisory['advisoryId']}.")
                # TODO if alert should trigger implement
                # send_raw_response(WAR_ROOM_ID, "No new devices found")
            # Scenario 2: Existing devices impacted and new devices impacted
            elif new_devices and set(unchanged_devices) == set(existing_devices):
                print("Scenario 2")
                new_devices = [d for d in new_devices if d in all_uuids]
                if new_devices:
                    logger.info(f"Scenario 2: New devices impacted: {new_devices}. Creating a new ticket for new devices.")
                    cmds_response = dnac_device_commands_executor(dnac, advisory_cmds, new_devices)
                    new_ticket = servicenow_ticket_creator(new_devices, advisory, cmds_response, ticket_type, scanInitiatedTime)
                    # Update mapping with new ticket and affected devices
                    advisory_scan_collection.update_one(
                        {"advisoryId": advisory['advisoryId']},
                        {
                            "$push": {"tickets": new_ticket},
                            "$set": {"devices": list(set(existing_devices + new_devices))}
                        }
                    )
                    report = {
                        "advisoryId": advisory['advisoryId'],
                        "devices": new_devices,
                        "number": new_ticket["number"],
                        "sys_id": new_ticket["sys_id"],
                        "cmds_response": cmds_response
                    }
                    update_scan_data(scanInitiatedTime, scanType, report)
                    ticket_deatils.append({**new_ticket, **{'advisoryId': advisory['advisoryId'], 'advisoryTitle': advisory['title']}})
            # Scenario 3: Only new devices impacted this week
            elif new_devices and not unchanged_devices:
                print("Scenario 3")
                new_devices = [d for d in new_devices if d in all_uuids]
                if new_devices:
                    logger.info(f"Scenario 3: Only new devices affected: {new_devices}. Creating tickets for new devices.")
                    # Update mapping with the new ticket and only new affected devices
                    cmds_response = dnac_device_commands_executor(dnac, advisory_cmds, new_devices)
                    new_ticket = servicenow_ticket_creator(new_devices, advisory, cmds_response, ticket_type, scanInitiatedTime)
                    advisory_scan_collection.update_one(
                        {"advisory_id": advisory['advisoryId']},
                        {
                            "$push": {"tickets": new_ticket},
                            "$set": {"devices": list(new_devices)}
                        }
                    )
                    report = {
                        "advisoryId": advisory['advisoryId'],
                        "devices": new_devices,
                        "number": new_ticket["number"],
                        "sys_id": new_ticket["sys_id"],
                        "cmds_response": cmds_response
                    }
                    update_scan_data(scanInitiatedTime, scanType, report)
                    ticket_deatils.append({**new_ticket, **{'advisoryId': advisory['advisoryId'], 'advisoryTitle': advisory['title']}})
            print("No Scenario")
        else:
            affected_devices = [d for d in affected_devices if d in all_uuids]
            if affected_devices:
                cmds_response = dnac_device_commands_executor(dnac, advisory_cmds, affected_devices)
                new_ticket = servicenow_ticket_creator(affected_devices, advisory, cmds_response, ticket_type, scanInitiatedTime)
                new_entry = {
                    "advisoryId": advisory['advisoryId'],
                    "devices": affected_devices,
                    "tickets": [
                        new_ticket
                    ]
                }
                advisory_scan_collection.insert_one(new_entry)
                report = {
                    "advisoryId": advisory['advisoryId'],
                    "devices": affected_devices,
                    "number": new_ticket["number"],
                    "sys_id": new_ticket["sys_id"],
                    "cmds_response": cmds_response
                }
                update_scan_data(scanInitiatedTime, scanType, report)
                ticket_deatils.append({**new_ticket, **{'advisoryId': advisory['advisoryId'], 'advisoryTitle': advisory['title']}})
    return ticket_deatils
 
 
def advisory_device_discovery_manual_ticket(dnac, scanType):
    # Fetch the current mapping entry
    scanInitiatedTime = datetime.utcnow().isoformat()
    advisories = collect_before_scan_records()
    all_uuids = [device["instanceUuid"] for device in all_devices()]
    for advisory in advisories:
        print(advisory)
        advisory_cmds = advisory.get("cmds")
        new_devices = advisory['new_devices']
        existing_devices = advisory['scanned_devices']
        unchanged_devices = advisory['unchanged_devices']
        affected_devices = advisory['affected_devices']
        if advisory_cmds:
            if new_devices or unchanged_devices:
                print("Entered")
                # Scenario 1: No new devices; no action required
                if not new_devices and set(unchanged_devices) == set(existing_devices):
                    print("Scenario 1")
                    logger.info(f"Scenario 1: No new devices. No action needed for advisory {advisory['advisoryId']}.")
                # Scenario 2: Existing devices impacted and new devices impacted
                elif new_devices and set(unchanged_devices) == set(existing_devices):
                    print("Scenario 2")
                    new_devices = [d for d in new_devices if d in all_uuids]
                    if new_devices:
                        logger.info(f"Scenario 2: New devices impacted: {new_devices}. Creating a new ticket for new devices.")
                        cmds_response = dnac_device_commands_executor(dnac, advisory_cmds, new_devices)
                        report = {
                            "advisoryId": advisory['advisoryId'],
                            "devices": new_devices,
                            "cmds_response": cmds_response
                        }
                        update_scan_data(scanInitiatedTime, scanType, report)
                # Scenario 3: Only new devices impacted this week
                elif new_devices and not unchanged_devices:
                    print("Scenario 3")
                    new_devices = [d for d in new_devices if d in all_uuids]
                    if new_devices:
                        logger.info(f"Scenario 3: Only new devices affected: {new_devices}. Creating tickets for new devices.")
                        # Update mapping with the new ticket and only new affected devices
                        cmds_response = dnac_device_commands_executor(dnac, advisory_cmds, new_devices)
                        report = {
                            "advisoryId": advisory['advisoryId'],
                            "devices": new_devices,
                            "cmds_response": cmds_response
                        }
                        update_scan_data(scanInitiatedTime, scanType, report)
                print("No Scenario")
            else:
                affected_devices = [d for d in affected_devices if d in all_uuids]
                if affected_devices:
                    cmds_response = dnac_device_commands_executor(dnac, advisory_cmds, affected_devices)
                    report = {
                        "advisoryId": advisory['advisoryId'],
                        "devices": affected_devices,
                        "cmds_response": cmds_response
                    }
                    update_scan_data(scanInitiatedTime, scanType, report)
        else:
            # Scenario : If no commands were found in the advisory
            no_cmd_devices = [d for d in new_devices if d in all_uuids]
            if not no_cmd_devices:
                continue
            command_reponses = []
            for new_device in no_cmd_devices:
                command_reponses.append({ "deviceUuid": new_device,
                                        "commandResponses": {
                                            "SUCCESS":{"No Commands":"No commands were found in advisory. Please update the IOS on the devices"}
                                            }
                                            })
            report = {
                "advisoryId": advisory['advisoryId'],
                "devices": no_cmd_devices,
                "cmds_response": command_reponses
            }
            update_scan_data(scanInitiatedTime, scanType, report)
        # Replace this fucntion with chat response to UI
    return list(collect_scan_report_by_time(scanInitiatedTime))[0]
 
 
def create_ticket_update_advisory_scan_collection(advisories, advisory_scan_collection, message, reports):
    ticket_detail, aiticket_detail = list(), list()
    for advisory in advisories:
        print(advisory)
        new_devices = advisory['new_devices']
        existing_devices = advisory['scanned_devices']
        unchanged_devices = advisory['unchanged_devices']
        affected_devices = advisory['affected_devices']
        cmds_response = [x for x in reports if x['advisoryId'] == advisory["advisoryId"]][0]['cmds_response']
        scanInitiatedTime = advisory['scanInitiatedTime']
        scanType = advisory['scanType']
        ticket_type = message.get(advisory["advisoryId"])
        
        if new_devices or unchanged_devices:
            # Scenario 1: No new devices; no action required
            if not new_devices and set(unchanged_devices) == set(existing_devices):
                print("Scenario 1")
                logger.info(f"Scenario 1: No new devices. No action needed for advisory {advisory['advisoryId']}.")
            elif new_devices and set(unchanged_devices) == set(existing_devices):
                new_ticket = servicenow_ticket_creator(new_devices, advisory, cmds_response, ticket_type, scanInitiatedTime)
                ticket_detail.append({**new_ticket,**{"advisoryId": advisory['advisoryId'],"advisoryTitle": advisory['title']}})
                aiticket_detail.append({"Ticket No": new_ticket["number"], 'advisoryId': advisory['advisoryId']})
                # Update mapping with new ticket and affected devices
                advisory_scan_collection.update_one(
                    {"advisoryId": advisory['advisoryId']},
                    {
                        "$push": {"tickets": new_ticket},
                        "$set": {"devices": list(set(existing_devices + new_devices))}
                    }
                )
                report = {
                    "advisoryId": advisory['advisoryId'],
                    "devices": new_devices,
                    "number": new_ticket["number"],
                    "sys_id": new_ticket["sys_id"]
                }
                # update_scan_data(scanInitiatedTime, scanType, report, report_only=True)
            elif new_devices and not unchanged_devices:
                new_ticket = servicenow_ticket_creator(new_devices, advisory, cmds_response, ticket_type, scanInitiatedTime)
                ticket_detail.append({**new_ticket,**{"advisoryId": advisory['advisoryId'],"advisoryTitle": advisory['title']}})
                aiticket_detail.append({"Ticket No": new_ticket["number"], 'advisoryId': advisory['advisoryId']})
                advisory_scan_collection.update_one(
                    {"advisory_id": advisory['advisoryId']},
                    {
                        "$push": {"tickets": new_ticket},
                        "$set": {"devices": list(new_devices)}
                    }
                )
                report = {
                    "advisoryId": advisory['advisoryId'],
                    "devices": new_devices,
                    "number": new_ticket["number"],
                    "sys_id": new_ticket["sys_id"]
                }
                # update_scan_data(scanInitiatedTime, scanType, report, report_only=True)
        else:
            new_ticket = servicenow_ticket_creator(affected_devices, advisory, cmds_response, ticket_type, scanInitiatedTime)
            ticket_detail.append({**new_ticket,**{"advisoryId": advisory['advisoryId'],"advisoryTitle": advisory['title']}})
            aiticket_detail.append({"Ticket No": new_ticket["number"], 'advisoryId': advisory['advisoryId']})
            new_entry = {
                "advisoryId": advisory['advisoryId'],
                "devices": affected_devices,
                "tickets": [
                    new_ticket
                ]
            }
            advisory_scan_collection.insert_one(new_entry)
            report = {
                "advisoryId": advisory['advisoryId'],
                "devices": affected_devices,
                "number": new_ticket["number"],
                "sys_id": new_ticket["sys_id"]
            }
            # update_scan_data(scanInitiatedTime, scanType, report, report_only=True)
    return ticket_detail, aiticket_detail
 
 
def _sanitize_url(url: str) -> str:
    """Strip URL-encoded trailing artifacts (e.g. %27 single-quote) from advisory URLs."""
    import urllib.parse
    decoded = urllib.parse.unquote(url)
    # Remove any trailing quotes or whitespace introduced by encoding artifacts
    return decoded.rstrip("'\" ").rstrip()
 
 
def extract_content_from_url(page_url):
    page_url = _sanitize_url(page_url)
    response = requests.get(page_url)
    response.raise_for_status()  # Ensure the request was successful
    soup = BeautifulSoup(response.text, 'html.parser')
    page_content = soup.get_text(separator='\n', strip=True)
    # Find all elements with the class "item"
    items = soup.find_all(class_='headline')[0]
 
    return items.text, page_content
 
def get_task_result(dnac,cli_execution):
    while True:
        task_info = dnac.get(path=f"task/{cli_execution['taskId']}/")["response"]
        if 'fileId' in task_info['progress']:
            break
        else:
            sleep(30)
    return task_info