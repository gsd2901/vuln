from config import BASE_DIR
# from app.utils.vulnerability_manager.llm.rag_utils import get_vectorstore, rag_retrival
from llm.rag_utils import get_vectorstore, rag_retrival
from tools.endpoints import advisory_discovery_endpoint, commands_execution_endpoint, impacted_advisories_endpoint, impacted_devices_endpoint, latest_dicovery_report_endpoint
from langchain_core.tools import tool


@tool("introductory_tool")
def introductory_tool():
    """
    Tool: introductory_tool
    Purpose:
        This tool is used to introduce the agent to the user when the user asks basic, greeting, or capability-related questions.

    Usage:
        Use this tool when the user asks any of the following types of questions:
        - General greetings or casual intros:
            - "Hi", "Hello", "Hey", "Hi buddy", "What's up?"
        - Questions about the agent:
            - "Who are you?", "What can you do?", "What is your purpose?", "Tell me about yourself."
        - Capability inquiries:
            - "What are your features?", "What tasks can you perform?", "How can you help me?"
        - Introduction prompts:
            - "Introduce yourself", "Give me a quick overview", "What are you built for?"

    Notes:
        Trigger this tool if the user's intent seems to be to understand the agent, start a conversation, or explore the bot’s purpose and abilities. Give the response as it is.
    """
    return "This is agent intro"


# @tool("advisory_discovery")
# def advisory_discovery():
#     """
#     Advisory Discovery Tool collects the devices data and advisory data from the DNA Center. 
#     Using these data this method acomplish the advisory discovery and return back the results to agent.
#     """
#     result = advisory_discovery_endpoint()

#     # Initiate a scheduler which runs discovery and we should supply meta data from the db to agent instaed of entire discovery report - Future modification
#     # Convert discovery_report_response as json response and send it to UI 

#     return result


@tool("get_impacted_advisories")
def impacted_advisories():
    """
    Get Impacted Advisories tool collects the impacted advisories from DNA Center and return back the results to agent.
    Display results will be return in the table format. 
    """
    result = impacted_advisories_endpoint()
    return result


@tool("get_impacted_devices")
def impacted_devices():
    """
    Get Impacted devices tool collects the impacted devices from DNA Center and return back the results to agent.
    Display results will be return in the table format.
    """

    result = impacted_devices_endpoint()
    return result


@tool("commands_execution_tool")
def commands_execution(device_ips: str, command: str):
    """
    Commands Execution Tool executes commands on devices from DNA Center and return back the results to agent. 
    Input should be a comma-separated list of device IP addresses and the command to execute.
    args:
        device_ips: str = Field(
            description="Comma-separated list of device IP addresses to execute commands on"
        )
        command: str = Field(
            description="CLI command to execute on the devices"
        )
    Example input: "192.168.1.1,192.168.1.2", "show interfaces"
    """
    result = commands_execution_endpoint(device_ips, command)
    return result


@tool("latest_discovery_report_tool")
def latest_dicovery_report():
    """
    Latest discovery report tool fetches latest discovery record from DB and return back the results to agent.
    """
    # Latest discovery report
    scan_response = latest_dicovery_report_endpoint()
    # print(scan_response)
    return scan_response


@tool("rag_response_tool")
def rag_response(query:str):
    """
    For any queries related to advisories, cves and advisory fix, agent should look into this tool.
    RAG Tool retrive data based on the user query from the rag database and return back the results to agent.
    args:
        query: str = Field(
            description="User query"
        )
    Example input: "How to fix Multiple Vulnerabilities in Cisco IOS XE Software Web UI Feature"
    """
    print("RAG Tools executes")
    vector_store = get_vectorstore()
    return rag_retrival(vector_store, query)