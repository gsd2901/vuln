from config import BASE_DIR
try:
    from vulnerebility_management.db.quries_postgresql import all_devices, collect_impacted_advisories, collect_impacted_devices
except Exception:
    from db.quries_postgresql import all_devices, collect_impacted_advisories, collect_impacted_devices


def devices_input_list():
    return [{ "label": f"{device['hostname']} ({device['managementIpAddress']})", "value": f"{device['managementIpAddress']}" } for device in all_devices()]


intro_card = {
    "overallTitle": "Security & Operations Assistant Dashboard",
    "type": "INTROCARD",
    "cards": [
        {
            "title": "Hello, I am Security Advisory Helper. How can I assist you with your DNA Center security advisory questions today?",
            "cardTitle": "I Can help with below actions",
            "buttons": [
                {
                "id": "impacted_devices",
                "label": "Impacted Devices",
                "type": "button",
                "api": "/api/v1/vmapi/impacted_devices"
                },
                {
                "id": "impacted_advisories",
                "label": "Impacted Advisories",
                "type": "button",
                "api": "/api/v1/vmapi/impacted_advisories"
                },
                {
                "id": "advisory_discovery",
                "label": "Advisory Discovery",
                "type": "button",
                "api": "/api/v1/vmapi/advisory_discovery"
                },
                {
                "id": "latest_discovery_report",
                "label": "Latest Discovery Report",
                "type": "button",
                "api": "/api/v1/vmapi/latest_discovery_report"
                },
                {
                "id": "execute_cmds",
                "label": "Execute Cmds",
                "type": "popup",
                "popup": {
                    "title": "Run CLI Commands",
                    "description": "Choose a device and enter commands to run.",
                    "formFields": [
                    {
                        "name": "deviceId",
                        "label": "Select Device",
                        "type": "multiselect",
                        # "options": [
                        # { "label": "Device A (192.168.1.1)", "value": "device_a" },
                        # { "label": "Device B (192.168.1.2)", "value": "device_b" },
                        # { "label": "Device C (192.168.1.3)", "value": "device_c" }
                        # ],
                        "options": devices_input_list(),
                        "validation": {
                        "type": "array",
                        "required": "True",
                        "message": "Please select a device."
                        }
                    },
                    {
                        "name": "commands",
                        "label": "CLI Commands",
                        "type": "textarea",
                        "placeholder": "Enter one or more CLI commands...",
                        "rows": 6,
                        "validation": {
                        "type": "string",
                        "required": "True",
                        "message": "Command input is required."
                        }
                    }
                    ],
                    "submit": {
                    "label": "Run Commands",
                    "variant": "contained",
                    "color": "primary",
                    "apiEndpoint": "/api/v1/skills/playground",
                    "method": "POST",
                    "successMessage": "Commands executed successfully!",
                    "errorMessage": "Failed to run commands. Please try again."
                    }
                }
                }
            ]
        }
    ]
}

def snow_ticket_creation_card():
    from app.utils.vulnerability_manager.tools.endpoints import discovery_result_from_db
    scanInitiatedTime, response = discovery_result_from_db()
    snow_ticket_card_body = list()
    for result in response:
        snow_ticket_card_body.append(
            {
                "id": result['advisoryId'],
                "title": result['advisoryTitle'],
                "externalLink": {
                    "label": "View Advisory",
                    "url": result['advisoryUrl']
                },
                "accordion": [
                    {
                        "title": "View Result",
                        "content": result['cmd_response_text']
                    },
                    {
                        "title": "Workarounds",
                        "content": result['workaround_text']
                    }
                ],
                "formFields": [
                    {
                        "name":  result['advisoryId'],
                        "label": "Ticket Type",
                        "type": "select",
                        "options": [
                            { "label": "Incident", "value": "1" },
                            { "label": "Change", "value": "2" },
                            { "label": "No Ticket", "value": "3" }
                        ],
                        "validation": {
                            "type": "string",
                            "required": "True",
                            "message": "Ticket type is required"
                        }
                    }
                ]
            }
        )
    snow_ticket_card = {
        "type": "ADVISORY_LIST",
        "title": "Service Now Ticket Creation",
        "subtitle": "Here is a list of advisories. Please choose option(s) to create the ticket.",
        "advisories": snow_ticket_card_body,
        "formFields": [
            {
                "name":  result['advisoryId'],
                "label": "Scan Initiated Time",
                "type": "hidden",
                "value": scanInitiatedTime
            }
        ],
        "submit": {
            "label": "Create Ticket",
            "variant": "contained",
            "color": "primary",
            "apiEndpoint": "/vmapi/snow_ticket_creation",
            "method": "POST",
            "successMessage": "Ticket created successfully!",
            "errorMessage": "Something went wrong. Please try again."
        }
    }

    return snow_ticket_card
 
def snow_ticket_creation_response_card(response):
    snow_ticket_response_card_body = list()
    for result in response:
        if result['sys_id'] != "No Ticket":
            snow_ticket_response_card_body.append(
                {
                    "id": result['advisoryId'],
                    "title": result['advisoryTitle'],
                    "viewTicket": {
                        "label": result["number"],
                        "url": f"https://hclpocm1.service-now.com/api/now/table/{result['number']}"
                    },
                    "ticketNo": result["number"],
                    "ticketType": result["tickettype"],
                    "description": result["short_description"],
                    "category": result["category"],
                    "priority": result["priority"],
                    "urgency": result["urgency"],
                    "impact": result["impact"],
                    "status":  result["status"],
                    "createdBy":  result["sys_created_by"]
                }
            )
    snow_ticket_response_card = {
        "type": "DISCOVERY_SUBMISSION",
        "title": "Discovery Submission",
        "subtitle": "Thanks for submitting the ServiceNow Ticket Creation card. Based on your response, the ticket will be generated and notified in this form.",
        "advisories": snow_ticket_response_card_body
    }
    return snow_ticket_response_card
 

def impacted_advisories_card():
    impacted_advisories = collect_impacted_advisories()
    impacted_advisories_response_card = {
        "type": "IMPACTED_ADVISORIES",
        "title": "Impacted Advisories",
        "impacted_advisories": impacted_advisories
    }
    return impacted_advisories_response_card


def impacted_devices_card():
    impacted_devices = collect_impacted_devices()
    impacted_devices_response_card = {
        "type": "IMPACTED_DEVICES",
        "title": "Impacted Devices",
        "impacted_devices": impacted_devices
    }
    return impacted_devices_response_card
