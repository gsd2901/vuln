import json
import logging
import os

import requests
from bs4 import BeautifulSoup
from config import BASE_DIR
try:
    from rag_agent_project.quries_postgresql import get_instanceUuid_managementIpAddress_dict
except Exception:
    from db.quries_postgresql import get_instanceUuid_managementIpAddress_dict

logger = logging.getLogger(__name__)
logger.addHandler(logging.StreamHandler())
logger.setLevel(logging.INFO)


def create_or_append_file(file_name, content, datatype, directory="New Folder"):
    file_path = os.path.join(directory, file_name)

    if not os.path.exists(directory):
        os.makedirs(directory)

    with open(file_path, "a", encoding="utf-8") as file:
        if datatype == "json":
            json.dump(content, file, indent=4)
        else:
            file.write(content + "\n")


def read_json_file(file_path):
    """Read and parse a specific JSON file."""
    try:
        with open(file_path, "r", encoding="utf-8") as file:
            data = json.load(file)
            return data
    except json.JSONDecodeError as e:
        logger.debug(f"Error decoding JSON from file {file_path}: {e}")
        print(f"Error decoding JSON from file {file_path}: {e}")
    except FileNotFoundError:
        logger.debug(f"File not found: {file_path}")
        print(f"File not found: {file_path}")
    except Exception as e:
        logger.debug(f"An error occurred while reading file {file_path}: {e}")
        print(f"An error occurred while reading file {file_path}: {e}")
    return None


def read_all_json_files(directory):
    """Read and parse all JSON files in the directory."""
    json_data = []
    for filename in os.listdir(directory):
        if filename.endswith(".json"):
            file_path = os.path.join(directory, filename)
            data = read_json_file(file_path)
            if data is not None:
                json_data.append({filename: data})
    return json_data


def get_cmd_response_text(cmd_responses, form_list=False):
    cmd_response_text = ""
    uuid_ip = get_instanceUuid_managementIpAddress_dict()
    if form_list:
        cmd_list_response = list()
    for cmd_response in cmd_responses:
        device_uuid = cmd_response["deviceUuid"]
        cmd_response_text += f"Device UUID: {cmd_response['deviceUuid']} \n"
        cmd_response_text += f"Device IpAddress: {uuid_ip.get(device_uuid, 'N/A')} \n"
        for cmd, result in cmd_response["commandResponses"]["SUCCESS"].items():
            cmd_response_text += f"Command: {cmd}\n"
            cmd_response_text += f"{result}\n"
        if form_list:
            cmd_list_response.append(cmd_response_text)
            cmd_response_text = ""
    return cmd_list_response if form_list else cmd_response_text


def get_workaround_from_advisory(url):
    response = requests.get(url)
    response.raise_for_status()
    soup = BeautifulSoup(response.text, "html.parser")
    heading = soup.find_all(class_="ud-section-heading")
    paragraph = soup.find_all(class_="ud-section-ul")
    content = ""
    for head in range(0, len(heading)):
        title = heading[head].get_text(separator="\n", strip=True)
        if title == "Workarounds":
            content += title + "\n" + paragraph[head].get_text(separator="\n", strip=True)
            break
        continue
    return content


def get_affected_products_and_workaround_from_advisory(url):
    response = requests.get(url)
    response.raise_for_status()
    soup = BeautifulSoup(response.text, "html.parser")
    heading = soup.find_all(class_="ud-section-heading")
    paragraph = soup.find_all(class_="ud-section-ul")
    content = ""
    logger.info("Parsing Affected Products and Workarounds from the advisory")
    for head in range(0, len(heading)):
        title = heading[head].get_text(separator="\n", strip=True)
        if title == "Affected Products":
            content += title + "\n" + paragraph[head].get_text(separator="\n", strip=True)
        if title == "Workarounds":
            content += title + "\n" + paragraph[head].get_text(separator="\n", strip=True)
            break
        continue
    return content
