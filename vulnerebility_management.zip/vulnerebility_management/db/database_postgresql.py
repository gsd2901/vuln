import os
import json
from datetime import date, datetime
from copy import deepcopy

import psycopg2
from psycopg2 import sql
from psycopg2.extras import Json, RealDictCursor
# from config import BASE_DIR

import logging
# logging.basicConfig(
#     filename="application.log",
#     level=logging.INFO,
#     format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
# )
logger = logging.getLogger(__name__)
file_handler = logging.FileHandler("app_db.log")
logger.addHandler(file_handler)

def _is_safe_identifier(name):
    return name.replace("_", "").isalnum()


def _split_path(path):
    if path.startswith("$"):
        path = path[1:]
    return [part for part in path.split(".") if part]


def _get_path_value(document, path, default=None):
    current = document
    for part in _split_path(path):
        if isinstance(current, dict) and part in current:
            current = current[part]
        else:
            return default
    return current


def _set_path_value(document, path, value):
    keys = _split_path(path)
    if not keys:
        return
    current = document
    for key in keys[:-1]:
        if key not in current or not isinstance(current[key], dict):
            current[key] = {}
        current = current[key]
    current[keys[-1]] = value


def _extract_values(document, path):
    keys = _split_path(path)
    values = [document]
    for key in keys:
        next_values = []
        for value in values:
            if isinstance(value, list):
                for item in value:
                    if isinstance(item, dict) and key in item:
                        next_values.append(item[key])
            elif isinstance(value, dict) and key in value:
                next_values.append(value[key])
        values = next_values
    flattened = []
    for value in values:
        if isinstance(value, list):
            flattened.extend(value)
        else:
            flattened.append(value)
    return flattened


def _match_condition(value, expected):
    if isinstance(expected, dict):
        if "$in" in expected:
            return value in expected["$in"]
        if "$regex" in expected:
            regex = expected["$regex"]
            if value is None:
                return False
            return str(value).startswith(regex.replace("^", "")) if regex.startswith("^") else regex in str(value)
        return value == expected
    return value == expected


def _match_document(document, filter_doc):
    if not filter_doc:
        return True

    for key, expected in filter_doc.items():
        if key == "$and":
            if not all(_match_document(document, clause) for clause in expected):
                return False
            continue
        if key == "$or":
            if not any(_match_document(document, clause) for clause in expected):
                return False
            continue

        values = _extract_values(document, key)
        if not values:
            values = [_get_path_value(document, key)]

        if not any(_match_condition(value, expected) for value in values):
            return False

    return True


def _evaluate_expression(document, expr):
    if isinstance(expr, str):
        if expr.startswith("$"):
            return _get_path_value(document, expr[1:])
        return expr
    if isinstance(expr, (int, float, bool)) or expr is None:
        return expr
    if isinstance(expr, list):
        return [_evaluate_expression(document, item) for item in expr]
    if isinstance(expr, dict):
        if "$ifNull" in expr:
            first, fallback = expr["$ifNull"]
            value = _evaluate_expression(document, first)
            return value if value is not None else _evaluate_expression(document, fallback)
        if "$setDifference" in expr:
            left, right = expr["$setDifference"]
            left_values = _evaluate_expression(document, left) or []
            right_values = _evaluate_expression(document, right) or []
            return [item for item in left_values if item not in right_values]
        if "$setIntersection" in expr:
            left, right = expr["$setIntersection"]
            left_values = _evaluate_expression(document, left) or []
            right_values = _evaluate_expression(document, right) or []
            return [item for item in left_values if item in right_values]
        if "$size" in expr:
            value = _evaluate_expression(document, expr["$size"])
            return len(value or [])
    return expr


class PostgreCollection:
    def __init__(self, connector, name):
        if not _is_safe_identifier(name):
            raise ValueError(f"Unsafe collection name: {name}")
        self.connector = connector
        self.name = name
        self._ensure_table()

    def _ensure_table(self):
        with self.connector.conn.cursor() as cur:
            cur.execute(
                sql.SQL(
                    """
                    CREATE TABLE IF NOT EXISTS {} (
                        id BIGSERIAL PRIMARY KEY,
                        data JSONB NOT NULL,
                        created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
                    )
                    """
                ).format(sql.Identifier(self.name))
            )
            cur.execute(
                sql.SQL(
                    "CREATE INDEX IF NOT EXISTS {} ON {} USING GIN (data)"
                ).format(
                    sql.Identifier(f"idx_{self.name}_data_gin"),
                    sql.Identifier(self.name),
                )
            )
        self.connector.conn.commit()

    def _load_rows(self):
        with self.connector.conn.cursor(cursor_factory=RealDictCursor) as cur:
            cur.execute(sql.SQL("SELECT id, data FROM {} ORDER BY id").format(sql.Identifier(self.name)))
            return cur.fetchall()

    def find(self, filter_doc=None, projection=None):
        rows = self._load_rows()
        docs = [row["data"] for row in rows if _match_document(row["data"], filter_doc or {})]

        if not projection:
            return docs

        include_fields = [field for field, enabled in projection.items() if enabled == 1 and field != "_id"]
        if not include_fields:
            return docs

        projected = []
        for doc in docs:
            out = {}
            for field in include_fields:
                value = _get_path_value(doc, field)
                if value is not None:
                    _set_path_value(out, field, value)
            projected.append(out)
        return projected

    def find_one(self, filter_doc=None, projection=None):
        docs = self.find(filter_doc, projection)
        return docs[0] if docs else None

    def insert_one(self, document):
        with self.connector.conn.cursor() as cur:
            cur.execute(
                sql.SQL("INSERT INTO {} (data) VALUES (%s)").format(sql.Identifier(self.name)),
                [Json(document)],
            )
        self.connector.conn.commit()

    def insert_many(self, documents):
        if not documents:
            return
        with self.connector.conn.cursor() as cur:
            cur.executemany(
                sql.SQL("INSERT INTO {} (data) VALUES (%s)").format(sql.Identifier(self.name)),
                [(Json(document),) for document in documents],
            )
        self.connector.conn.commit()

    def delete_many(self, filter_doc=None):
        if not filter_doc:
            with self.connector.conn.cursor() as cur:
                cur.execute(sql.SQL("DELETE FROM {}").format(sql.Identifier(self.name)))
            self.connector.conn.commit()
            return

        rows = self._load_rows()
        ids_to_delete = [row["id"] for row in rows if _match_document(row["data"], filter_doc)]
        if not ids_to_delete:
            return
        with self.connector.conn.cursor() as cur:
            cur.execute(
                sql.SQL("DELETE FROM {} WHERE id = ANY(%s)").format(sql.Identifier(self.name)),
                [ids_to_delete],
            )
        self.connector.conn.commit()

    def update_one(self, filter_doc, update_doc):
        rows = self._load_rows()
        selected = None
        for row in rows:
            if _match_document(row["data"], filter_doc):
                selected = row
                break
        if not selected:
            return

        document = deepcopy(selected["data"])

        if "$set" in update_doc:
            for key, value in update_doc["$set"].items():
                if ".$." in key:
                    array_name, nested_key = key.split(".$.", 1)
                    filter_key = f"{array_name}.advisoryId"
                    advisory_id = filter_doc.get(filter_key)
                    target = document.get(array_name, [])
                    if isinstance(target, list):
                        for item in target:
                            if isinstance(item, dict) and item.get("advisoryId") == advisory_id:
                                _set_path_value(item, nested_key, value)
                                break
                else:
                    _set_path_value(document, key, value)

        if "$push" in update_doc:
            for key, value in update_doc["$push"].items():
                current = _get_path_value(document, key)
                if not isinstance(current, list):
                    _set_path_value(document, key, [value])
                else:
                    current.append(value)

        with self.connector.conn.cursor() as cur:
            cur.execute(
                sql.SQL("UPDATE {} SET data = %s WHERE id = %s").format(sql.Identifier(self.name)),
                [Json(document), selected["id"]],
            )
        self.connector.conn.commit()

    def update_many(self, filter_doc, update_doc):
        """Apply a Mongo-style update document to all matching rows.

        Currently supports the same subset of operators as update_one: $set and $push.
        """
        rows = self._load_rows()
        updates = []

        for row in rows:
            if not _match_document(row["data"], filter_doc):
                continue

            document = deepcopy(row["data"])

            if "$set" in update_doc:
                for key, value in update_doc["$set"].items():
                    if ".$." in key:
                        array_name, nested_key = key.split(".$.", 1)
                        filter_key = f"{array_name}.advisoryId"
                        advisory_id = filter_doc.get(filter_key)
                        target = document.get(array_name, [])
                        if isinstance(target, list):
                            for item in target:
                                if isinstance(item, dict) and item.get("advisoryId") == advisory_id:
                                    _set_path_value(item, nested_key, value)
                                    break
                    else:
                        _set_path_value(document, key, value)

            if "$push" in update_doc:
                for key, value in update_doc["$push"].items():
                    current = _get_path_value(document, key)
                    if not isinstance(current, list):
                        _set_path_value(document, key, [value])
                    else:
                        current.append(value)

            updates.append((Json(document), row["id"]))

        if not updates:
            return

        with self.connector.conn.cursor() as cur:
            cur.executemany(
                sql.SQL("UPDATE {} SET data = %s WHERE id = %s").format(sql.Identifier(self.name)),
                updates,
            )
        self.connector.conn.commit()

    def aggregate(self, pipeline):
        docs = self.find({})

        for stage in pipeline:
            if "$match" in stage:
                docs = [doc for doc in docs if _match_document(doc, stage["$match"])]
                continue

            if "$lookup" in stage:
                cfg = stage["$lookup"]
                foreign_docs = self.connector.collection(cfg["from"]).find({})
                joined = []
                for doc in docs:
                    local_values = _extract_values(doc, cfg["localField"])
                    matches = [
                        foreign_doc
                        for foreign_doc in foreign_docs
                        if _get_path_value(foreign_doc, cfg["foreignField"]) in local_values
                    ]
                    merged = deepcopy(doc)
                    merged[cfg["as"]] = matches
                    joined.append(merged)
                docs = joined
                continue

            if "$unwind" in stage:
                cfg = stage["$unwind"]
                path = cfg["path"].lstrip("$")
                preserve = cfg.get("preserveNullAndEmptyArrays", False)
                unwound = []
                for doc in docs:
                    values = _get_path_value(doc, path)
                    if isinstance(values, list) and values:
                        for value in values:
                            expanded = deepcopy(doc)
                            _set_path_value(expanded, path, value)
                            unwound.append(expanded)
                    elif preserve:
                        expanded = deepcopy(doc)
                        _set_path_value(expanded, path, None)
                        unwound.append(expanded)
                docs = unwound
                continue

            if "$project" in stage:
                projected = []
                for doc in docs:
                    out = {}
                    for key, value in stage["$project"].items():
                        if value == 1:
                            source = _get_path_value(doc, key)
                            if source is not None:
                                out[key] = source
                        elif key == "_id" and value == 0:
                            continue
                        else:
                            out[key] = _evaluate_expression(doc, value)
                    projected.append(out)
                docs = projected
                continue

            if "$group" in stage:
                cfg = stage["$group"]
                grouped = {}
                id_expr = cfg.get("_id")
                for doc in docs:
                    group_id = _evaluate_expression(doc, id_expr)
                    if group_id not in grouped:
                        grouped[group_id] = {"_id": group_id}
                        for field, expr in cfg.items():
                            if field == "_id":
                                continue
                            if isinstance(expr, dict) and "$first" in expr:
                                grouped[group_id][field] = _evaluate_expression(doc, expr["$first"])
                    else:
                        continue
                docs = list(grouped.values())
                continue

            if "$sort" in stage:
                sort_fields = list(stage["$sort"].items())
                for field, direction in reversed(sort_fields):
                    docs = sorted(
                        docs,
                        key=lambda item: _get_path_value(item, field),
                        reverse=(direction == -1),
                    )
                continue

            if "$limit" in stage:
                docs = docs[: stage["$limit"]]
                continue

        return docs


class PostgreSQLConnector:
    """
    PostgreSQL-backed compatibility layer that mimics the legacy PostgreSQLConnector API.
    """

    def __init__(self, database):
        
        try:
            from ..db.db_details import DB_DETAILS
        except Exception:
            
            try:
                from db_details import DB_DETAILS
            except Exception:
                DB_DETAILS = {}
            logger.info(f"DB_DETAILS are :::{DB_DETAILS}")
        db_name = os.getenv("PGDATABASE") or database or DB_DETAILS.get("NAME", "postgres")
        db_host = os.getenv("PGHOST") or os.getenv("DB_HOST") or DB_DETAILS.get("HOST", "localhost")
        db_port = int(os.getenv("PGPORT") or os.getenv("DB_PORT") or DB_DETAILS.get("PORT", "5432"))
        db_user = os.getenv("PGUSER") or os.getenv("DB_USER") or DB_DETAILS.get("USER", "postgres")
        db_password = os.getenv("PGPASSWORD") or os.getenv("DB_PASSWORD") or DB_DETAILS.get("PASSWORD", "postgres")
        print("Inside Connector::")
        logger.info(f"Postgres Connection {os.getenv('PGDATABASE')},{os.getenv('PGPORT')},{os.getenv('PGUSER')},{os.getenv('PGPASSWORD')},{os.getenv('PGHOST')}")
        logger.info(f"Postgres Connection {db_host},{db_port},{db_user},{db_password},{db_name}")

        self.conn = psycopg2.connect(
            host=db_host,
            port=db_port,
            user=db_user,
            password=db_password,
            dbname=db_name,
        )
        self.conn.autocommit = False

    def collection(self, name):
        return PostgreCollection(self, name)

    def print_tables(self, schema="public"):
        """
        Print all table names for a schema in the current database connection.
        Returns the table names as a list.
        """
        with self.conn.cursor() as cur:
            cur.execute(
                """
                SELECT table_name
                FROM information_schema.tables
                WHERE table_schema = %s
                  AND table_type = 'BASE TABLE'
                ORDER BY table_name
                """,
                [schema],
            )
            tables = [row[0] for row in cur.fetchall()]

        print(f"Tables in schema '{schema}':")
        if not tables:
            print("(none)")
        else:
            for table in tables:
                print(f"- {table}")

        return tables

    def export_table_to_json(self, table_name, output_file, schema="public", order_by="id"):
        """
        Export all rows from a table to a JSON file.
        Returns the number of exported rows.
        """
        if not _is_safe_identifier(table_name):
            raise ValueError(f"Unsafe table name: {table_name}")
        if not _is_safe_identifier(schema):
            raise ValueError(f"Unsafe schema name: {schema}")
        if not _is_safe_identifier(order_by):
            raise ValueError(f"Unsafe order_by column: {order_by}")

        with self.conn.cursor(cursor_factory=RealDictCursor) as cur:
            cur.execute(
                sql.SQL("SELECT * FROM {}.{} ORDER BY {}")
                .format(sql.Identifier(schema), sql.Identifier(table_name), sql.Identifier(order_by))
            )
            rows = cur.fetchall()

        def _default_serializer(value):
            if isinstance(value, (datetime, date)):
                return value.isoformat()
            return str(value)

        with open(output_file, "w", encoding="utf-8") as handle:
            json.dump(rows, handle, indent=2, ensure_ascii=False, default=_default_serializer)

        print(f"Exported {len(rows)} rows from {schema}.{table_name} to {output_file}")
        return len(rows)

    def export_advisory_rag_to_json(self, output_file="RAGDatabase.advisory_rag.current.json"):
        """Export advisory_rag table contents to JSON for snapshot comparison."""
        return self.export_table_to_json("advisory_rag", output_file)

    def close(self):
        self.conn.close()

if __name__ == "__main__":
    connector = PostgreSQLConnector("RAGDatabase")
    connector.print_tables()