from contextlib import contextmanager
# from config import BASE_DIR
try:
    from vulnerebility_management.db.database_postgresql import PostgreSQLConnector
except Exception:
    from db.database_postgresql import PostgreSQLConnector
import os
import logging 
logger = logging.getLogger(__name__)


@contextmanager
def _collection(name):
    db = PostgreSQLConnector("AdvisoryDatabase")

    try:
        yield db.collection(name)
    finally:
        db.close()


def all_devices(dnac_id: str | None = None):
    """Legacy 'devices' collection lookup, optionally scoped to a DNAC instance.

    dnac_id defaults to None for backward compatibility with existing callers
    that don't yet pass one — in that case every DNAC's rows are returned,
    same as before.
    """
    with _collection("devices") as device_collection:
        base_filter = {"family": "Switches and Hubs", "reachabilityStatus": "Reachable"}
        if dnac_id is not None:
            base_filter["dnac_id"] = dnac_id
        return list(device_collection.find(base_filter))


def all_advisories(dnac_id: str | None = None):
    with _collection("advisories") as advisory_collection:
        base_filter = {"dnac_id": dnac_id} if dnac_id is not None else {}
        return list(advisory_collection.find(base_filter))


def store_impacted_devices(impacteddevices, dnac_id: str | None = None):
    """Store impacted devices, optionally scoped to a specific DNAC instance.

    When dnac_id is provided, existing rows for that dnac_id are cleared and
    all inserted documents are tagged with the same dnac_id. When omitted,
    behavior matches the legacy implementation (collection-wide replace
    without a dnac_id field).
    """

    with _collection("impacteddevices") as impacteddevices_collection:
        if dnac_id is not None:
            # Clear only documents for this DNAC instance
            impacteddevices_collection.delete_many({"dnac_id": dnac_id})
            documents = []
            for doc in impacteddevices:
                if isinstance(doc, dict):
                    new_doc = dict(doc)
                    new_doc["dnac_id"] = dnac_id
                    documents.append(new_doc)
            if documents:
                impacteddevices_collection.insert_many(documents)
        else:
            # Backwards-compatible behavior: wipe and insert as-is
            impacteddevices_collection.delete_many({})
            if impacteddevices:
                impacteddevices_collection.insert_many(impacteddevices)


# def collect_impacted_devices(dnac_id: str | None = None):
#     """Collect impacted devices, optionally filtered by DNAC instance."""
#     dnac_id = "us"
#     logger.info(f"collect_impacted_devices dnac_id {dnac_id}")


#     with _collection("impacteddevices") as device_collection:
#         pipeline = [
#             *( [{"$match": {"dnac_id": dnac_id}}] if dnac_id is not None else [] ),
#             {
#                 "$project": {
#                     "advisoryIds": 1,
#                     "hostname": 1,
#                     "managementIpAddress": 1,
#                     "reachabilityStatus": 1,
#                     "softwareVersion": 1,
#                     "_id": 0,
#                     "id": "$deviceId",
#                 }
#             }
#         ]

#         return list(device_collection.aggregate(pipeline))
def collect_impacted_devices(dnac_id: str | None = None):
    """Collect impacted devices, optionally filtered by DNAC instance."""
    # dnac_id = "noida"
    logger.info(f"collect_impacted_devices called with dnac_id='{dnac_id}'")

    # Run this as a standalone script to bypass the agent
    # from db.database_postgresql import PostgreSQLConnector

    db = PostgreSQLConnector("AdvisoryDatabase")
    collection = db.collection("impacteddevices")

    # 1. Total count - no filter
    total = list(collection.aggregate([{"$count": "total"}]))
    logger.info(f"Total docs: {total}")

    # 2. What dnac_id values exist
    distinct_dnac = list(collection.aggregate([
        {"$group": {"_id": "$dnac_id"}},
    ]))
    logger.info(f"Distinct dnac_ids: {distinct_dnac}")

    # 3. Fetch first 3 raw docs with NO filter
    sample = list(collection.aggregate([{"$limit": 3}]))
    logger.info(f"Raw sample docs: {sample}")

    db.close()

    try:
        db = PostgreSQLConnector("AdvisoryDatabase")
        logger.info(f"DB connection successful: {db}")
        db.close()
    except Exception as conn_exc:
        logger.error(f"DB connection FAILED: {conn_exc}", exc_info=True)
        return []

    with _collection("impacteddevices") as device_collection:
        logger.info(f"Collection 'impacteddevices' acquired successfully")

        pipeline = [
            *( [{"$match": {"dnac_id": dnac_id}}] if dnac_id is not None else [] ),
            {
                "$project": {
                    "advisoryIds": 1,
                    "hostname": 1,
                    "managementIpAddress": 1,
                    "reachabilityStatus": 1,
                    "softwareVersion": 1,
                    "dnac_id": 1,
                    "_id": 0,
                    "id": "$deviceId",
                }
            }
        ]

        logger.info(f"Executing pipeline: {pipeline}")

        try:
            results = list(device_collection.aggregate(pipeline))
            logger.info(f"Query returned {len(results)} records")

            if results:
                logger.info(f"First record sample: {results[0]}")
                logger.info(f"All records: {results}")
            else:
                logger.warning(f"No records found for dnac_id='{dnac_id}' — check if 'impacteddevices' collection has data with this dnac_id")

                # Extra debug: check total docs in collection without filter
                try:
                    total = list(device_collection.aggregate([{"$count": "total"}]))
                    logger.info(f"Total docs in 'impacteddevices' (no filter): {total}")

                    # Check what dnac_id values actually exist
                    distinct_dnac = list(device_collection.aggregate([
                        {"$group": {"_id": "$dnac_id"}},
                        {"$project": {"_id": 0, "dnac_id": "$_id"}}
                    ]))
                    logger.info(f"Distinct dnac_id values in collection: {distinct_dnac}")
                except Exception as count_exc:
                    logger.error(f"Failed to fetch collection stats: {count_exc}")

            return results

        except Exception as query_exc:
            logger.error(f"Aggregation pipeline FAILED: {query_exc}", exc_info=True)
            return []

def store_impacted_advisories(impactedadvisories, dnac_id: str | None = None):
    """Store impacted advisories, optionally scoped to a DNAC instance.

    When dnac_id is provided, existing rows for that dnac_id are cleared and
    all inserted documents are tagged with the same dnac_id. When omitted,
    behavior matches the legacy implementation (collection-wide replace
    without a dnac_id field).
    """

    with _collection("impactedadvisories") as impactedadvisories_collection:
        if dnac_id is not None:
            impactedadvisories_collection.delete_many({"dnac_id": dnac_id})
            documents = []
            for doc in impactedadvisories:
                if isinstance(doc, dict):
                    new_doc = dict(doc)
                    new_doc["dnac_id"] = dnac_id
                    documents.append(new_doc)
            if documents:
                impactedadvisories_collection.insert_many(documents)
        else:
            impactedadvisories_collection.delete_many({})
            if impactedadvisories:
                impactedadvisories_collection.insert_many(impactedadvisories)


def collect_impacted_advisories(dnac_id: str | None = None):
    """Collect impacted advisories, optionally filtered by DNAC instance."""

    with _collection("impactedadvisories") as advisory_collection:
        pipeline = [
            *( [{"$match": {"dnac_id": dnac_id}}] if dnac_id is not None else [] ),
            {
                "$project": {
                    "advisoryId": 1,
                    "publicationUrl": 1,
                    "sir": 1,
                    "cves": 1,
                    "deviceCount": 1,
                    "dnac_id": 1,
                    "_id": 0,
                    "id": "$advisoryId",
                }
            }
        ]
        return list(advisory_collection.aggregate(pipeline))


def collect_advisories_needing_tickets_by_dnac(dnac_id: str):
    """Simple query path: list impacted advisories for a specific DNAC.

    This returns the advisories currently stored for the given dnac_id in the
    impactedadvisories collection. These are the advisories that would
    typically require tickets for that DNAC instance.
    """

    return collect_impacted_advisories(dnac_id=dnac_id)


def collect_before_scan_records():
    with _collection("advisories") as advisory_collection:
        pipeline = [
            {"$match": {"active": True}},
            {
                "$lookup": {
                    "from": "advisory_scan",
                    "localField": "advisoryId",
                    "foreignField": "advisoryId",
                    "as": "scan_data",
                }
            },
            {"$unwind": {"path": "$scan_data", "preserveNullAndEmptyArrays": True}},
            {
                "$project": {
                    "advisoryId": 1,
                    "cves": 1,
                    "sir": 1,
                    "title": 1,
                    "publicationUrl": 1,
                    "cmds": 1,
                    "scanned_devices": {"$ifNull": ["$scan_data.devices", []]},
                    "affected_devices": 1,
                    "new_devices": {"$setDifference": ["$affected_devices", {"$ifNull": ["$scan_data.devices", []]}]},
                    "unchanged_devices": {"$setIntersection": ["$affected_devices", {"$ifNull": ["$scan_data.devices", []]}]},
                }
            },
        ]
        return advisory_collection.aggregate(pipeline)


def collect_before_scan_status():
    with _collection("advisories") as advisory_collection:
        pipeline = [
            {"$match": {"active": True}},
            {
                "$lookup": {
                    "from": "advisory_scan",
                    "localField": "advisoryId",
                    "foreignField": "advisoryId",
                    "as": "scan_data",
                }
            },
            {"$unwind": {"path": "$scan_data", "preserveNullAndEmptyArrays": True}},
            {
                "$project": {
                    "advisoryId": 1,
                    "_id": 0,
                    "scanned_device_count": {"$size": {"$ifNull": ["$scan_data.devices", []]}},
                    "affected_device_count": {"$size": {"$ifNull": ["$affected_devices", []]}},
                    "new_device_count": {
                        "$size": {"$ifNull": [{"$setDifference": ["$affected_devices", {"$ifNull": ["$scan_data.devices", []]}]}, []]}
                    },
                    "unchanged_device_count": {
                        "$size": {"$ifNull": [{"$setIntersection": ["$affected_devices", {"$ifNull": ["$scan_data.devices", []]}]}, []]}
                    },
                }
            },
        ]
        return advisory_collection.aggregate(pipeline)


# def update_scan_data(scanInitiatedTime, scanType, report, report_only=False):
#     with _collection("scan_report") as scan_report_collection:
#         if scan_report_collection.find_one({"scanInitiatedTime": scanInitiatedTime}):
#             if report_only:
#                 scan_report_collection.update_one(
#                     {"scanInitiatedTime": scanInitiatedTime, "reports.advisoryId": report["advisoryId"]},
#                     {
#                         "$set": {
#                             "reports.$.number": report["number"],
#                             "reports.$.sys_id": report["sys_id"],
#                         }
#                     },
#                 )
#             else:
#                 scan_report_collection.update_one(
#                     {"scanInitiatedTime": scanInitiatedTime},
#                     {
#                         "$push": {"reports": report},
#                     },
#                 )
#         else:
#             new_entry = {
#                 "scanInitiatedTime": scanInitiatedTime,
#                 "scanType": scanType,
#                 "reports": [report],
#             }
#             scan_report_collection.insert_one(new_entry)

def update_scan_data(scanInitiatedTime, scanType, report, report_only=False):
    with _collection("scan_report") as scan_report_collection:
        if scan_report_collection.find_one({"scanInitiatedTime": scanInitiatedTime}):
            if report_only:
                scan_report_collection.update_one(
                    {"scanInitiatedTime": scanInitiatedTime, "reports.advisoryId": report["advisoryId"]},
                    {
                        "$set": {
                            "reports.$.number": report["number"],
                            "reports.$.sys_id": report["sys_id"],
                        }
                    },
                )
            else:
                # Keep one report entry per advisory within a scan. If an entry
                # already exists for this advisory, replace it; otherwise append.
                update_result = scan_report_collection.update_one(
                    {
                        "scanInitiatedTime": scanInitiatedTime,
                        "reports.advisoryId": report["advisoryId"],
                    },
                    {
                        "$set": {"reports.$": report},
                    },
                )
                if getattr(update_result, "matched_count", 0) == 0:
                    scan_report_collection.update_one(
                        {"scanInitiatedTime": scanInitiatedTime},
                        {
                            "$push": {"reports": report},
                        },
                    )
        else:
            new_entry = {
                "scanInitiatedTime": scanInitiatedTime,
                "scanType": scanType,
                "reports": [report],
            }
            scan_report_collection.insert_one(new_entry)

def latest_scan_report():
    with _collection("scan_report") as scan_report_collection:
        pipeline = [
            {"$sort": {"scanInitiatedTime": -1}},
            {"$limit": 1},
            {"$unwind": {"path": "$reports"}},
            {
                "$project": {
                    "advisoryId": "$reports.advisoryId",
                    "device_count": {"$size": "$reports.devices"},
                    "number": "$reports.number",
                    "scanType": 1,
                    "scanInitiatedTime": 1,
                    "_id": 0,
                }
            },
        ]
        return scan_report_collection.aggregate(pipeline)


def collect_scan_report_by_time(scanInitiatedTime):
    with _collection("scan_report") as scan_report_collection:
        pipeline = [
            {
                "$lookup": {
                    "as": "advisories",
                    "from": "advisories",
                    "foreignField": "advisoryId",
                    "localField": "reports.advisoryId",
                }
            },
            {"$match": {"scanInitiatedTime": f"{scanInitiatedTime}"}},
        ]
        return scan_report_collection.aggregate(pipeline)


def collect_scan_report_by_time_and_advisoryID(scanInitiatedTime, advisoryID):
    with _collection("scan_report") as scan_report_collection:
        pipeline = [
            {
                "$lookup": {
                    "as": "advisories",
                    "from": "advisories",
                    "foreignField": "advisoryId",
                    "localField": "reports.advisoryId",
                }
            },
            {"$match": {"scanInitiatedTime": f"{scanInitiatedTime}"}},
            {"$unwind": {"path": "$reports"}},
            {"$match": {"reports.advisoryId": f"{advisoryID}"}},
        ]
        return scan_report_collection.aggregate(pipeline)


def collect_scan_advisory_report_by_time(scanInitiatedTime):
    with _collection("scan_report") as scan_report_collection:
        pipeline = [
            {
                "$lookup": {
                    "as": "advisories",
                    "from": "advisories",
                    "foreignField": "advisoryId",
                    "localField": "reports.advisoryId",
                }
            },
            {"$match": {"scanInitiatedTime": f"{scanInitiatedTime}"}},
            {"$unwind": {"path": "$advisories", "preserveNullAndEmptyArrays": True}},
            {
                "$lookup": {
                    "from": "advisory_scan",
                    "localField": "advisories.advisoryId",
                    "foreignField": "advisoryId",
                    "as": "scan_data",
                }
            },
            {"$unwind": {"path": "$scan_data", "preserveNullAndEmptyArrays": True}},
            {
                "$project": {
                    "scanInitiatedTime": 1,
                    "scanType": 1,
                    "advisoryId": "$advisories.advisoryId",
                    "title": "$advisories.title",
                    "cves": "$advisories.cves",
                    "sir": "$advisories.sir",
                    "publicationUrl": "$advisories.publicationUrl",
                    "cmds": "$advisories.cmds",
                    "scanned_devices": {"$ifNull": ["$scan_data.devices", []]},
                    "affected_devices": "$advisories.affected_devices",
                    "new_devices": {"$ifNull": [{"$setDifference": ["$advisories.affected_devices", "$scan_data.devices"]}, []]},
                    "unchanged_devices": {"$ifNull": [{"$setIntersection": ["$advisories.affected_devices", "$scan_data.devices"]}, []]},
                }
            },
        ]
        return scan_report_collection.aggregate(pipeline)


def filter_instanceUuid_by_managementIpAddress(managementIpAddress):
    with _collection("devices") as device_collection:
        results = list(
            device_collection.find(
                {
                    "managementIpAddress": {
                        "$in": managementIpAddress,
                    }
                },
                {"instanceUuid": 1, "_id": 0},
            )
        )
        return [device["instanceUuid"] for device in results]


def filter_instanceUuid_by_instanceUuid(instanceUuid):
    with _collection("devices") as device_collection:
        results = list(
            device_collection.find(
                {
                    "instanceUuid": {
                        "$in": instanceUuid,
                    }
                },
                {"instanceUuid": 1, "_id": 0},
            )
        )
        return [device["instanceUuid"] for device in results]


def get_instanceUuid_managementIpAddress_dict():
    with _collection("devices") as device_collection:
        pipeline = [
            {"$group": {"_id": "$instanceUuid", "managementIpAddress": {"$first": "$managementIpAddress"}}},
            {"$project": {"_id": 0, "instanceUuid": "$_id", "managementIpAddress": 1}},
        ]
        result = list(device_collection.aggregate(pipeline))
        return {doc["instanceUuid"]: doc["managementIpAddress"] for doc in result}


def collect_new_change_request_scan_report():
    with _collection("advisory_scan") as advisory_scan_collection:
        return list(
            advisory_scan_collection.aggregate(
                [
                    {"$unwind": {"path": "$tickets"}},
                    {
                        "$match": {
                            "tickets.status": "New",
                            "tickets.number": {"$regex": "^CHG"},
                        }
                    },
                    {
                        "$project": {
                            "_id": 0,
                            "advisoryId": 1,
                            "number": "$tickets.number",
                            "status": "$tickets.status",
                            "devices": "$tickets.devices",
                        }
                    },
                ]
            )
        )


def collect_change_request_scan_data(ticket_no):
    with _collection("advisory_scan") as advisory_scan_collection:
        return list(
            advisory_scan_collection.aggregate(
                [
                    {"$unwind": {"path": "$tickets"}},
                    {
                        "$match": {
                            "tickets.status": "New",
                            "tickets.number": f"{ticket_no}",
                        }
                    },
                    {
                        "$project": {
                            "_id": 0,
                            "advisoryId": 1,
                            "number": "$tickets.number",
                            "status": "$tickets.status",
                            "devices": "$tickets.devices",
                            "scanInitiatedTime": "$tickets.scanInitiatedTime",
                        }
                    },
                ]
            )
        )


def get_latest_scantime():
    with _collection("scan_report") as advisory_scan_collection:
        return list(
            advisory_scan_collection.aggregate(
                [
                    {
                        "$sort": {
                            "scanInitiatedTime": -1,
                        }
                    },
                    {"$limit": 1},
                ]
            )
        )


def flush_all_documents():
    with _collection("advisories") as advisory_collection:
        advisory_collection.delete_many({})
    with _collection("devices") as device_collection:
        device_collection.delete_many({})
    with _collection("advisory_scan") as advisory_scan_collection:
        advisory_scan_collection.delete_many({})
    with _collection("scan_report") as scan_report_collection:
        scan_report_collection.delete_many({})
    print("All documents deleted")


if __name__ == "__main__":
    scanInitiatedTime = "2024-11-06T21:50:20.412212"
    scan_report = list(collect_scan_report_by_time(scanInitiatedTime))[0]
    reports_dict = {report["advisoryId"]: report for report in scan_report["reports"]}
    for advisory in scan_report["advisories"]:
        advisory_id = advisory["advisoryId"]
        print(advisory_id)
        report = reports_dict.get(advisory_id)
        print(report)
        cmd_response_text = ""
        for cmd_response in report["cmds_response"]:
            cmd_response_text += f"Device UUID: {cmd_response['deviceUuid']} \n"
            for cmd, result in cmd_response["commandResponses"]["SUCCESS"].items():
                cmd_response_text += f"Command: {cmd}\n"
                cmd_response_text += f"{result}\n"
        print(cmd_response_text)
