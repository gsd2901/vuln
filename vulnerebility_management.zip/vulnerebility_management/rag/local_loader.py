"""Self-contained loader for RAG data ingestion into Chroma.

This module intentionally avoids project-specific imports outside
`rag_agent_project` so it can run independently.
"""

import argparse
import json
import logging
import re
from html.parser import HTMLParser
from typing import Callable, Dict, Iterable, List, Optional
from urllib.request import Request, urlopen
from config import BASE_DIR
import chromadb
from langchain_chroma import Chroma
from langchain_core.documents import Document
from langchain_openai import AzureOpenAIEmbeddings

try:
    from rag_agent_project.cisco_advisory_apis import ADVISORY
    from rag_agent_project.database_postgresql import PostgreSQLConnector
    from rag_agent_project.llm_utils import generate_advisory_questions
    from rag_agent_project.utils import extract_content_from_url
except Exception:
    from rag.cisco_advisory_apis import ADVISORY
    from db.database_postgresql import PostgreSQLConnector
    from llm.llm_utils import generate_advisory_questions
    from tools.utils import extract_content_from_url


logger = logging.getLogger(__name__)
logger.addHandler(logging.StreamHandler())
logger.setLevel(logging.INFO)


class _HTMLTextExtractor(HTMLParser):
    """Extract visible text from HTML using Python stdlib only."""

    def __init__(self) -> None:
        super().__init__()
        self._chunks: List[str] = []

    def handle_data(self, data: str) -> None:
        text = data.strip()
        if text:
            self._chunks.append(text)

    def text(self) -> str:
        return " ".join(self._chunks)


def _clean_text(value: str) -> str:
    value = re.sub(r"\s+", " ", value or "").strip()
    return value


def fetch_url_text(url: str, timeout: int = 30) -> str:
    """Fetch text content from a URL without third-party HTML parsers."""
    request = Request(
        url,
        headers={
            "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) RAGLoader/1.0",
            "Accept": "text/html,application/xhtml+xml",
        },
    )
    with urlopen(request, timeout=timeout) as response:
        html = response.read().decode("utf-8", errors="ignore")

    parser = _HTMLTextExtractor()
    parser.feed(html)
    return _clean_text(parser.text())


def build_vectorstore(
    persist_directory: str = "./chroma_db",
    collection_name: str = "advisory_rag",
    embedding_model: str = "",
) -> Chroma:
    """Create a persistent Chroma vectorstore using OpenAI embeddings."""

    embeddings = AzureOpenAIEmbeddings(
    azure_deployment="text-embedding-3-small",
    azure_endpoint="https://git-nw-openai-llm-prod.openai.azure.com/",
    api_key=AZURE_OPENAI_API_KEY,#os.getenv("AZURE_OPENAI_API_KEY"),  # click the eye icon to reveal it
    api_version="2023-05-15"
)
    settings = chromadb.config.Settings(anonymized_telemetry=False, allow_reset=False)

    return Chroma(
        collection_name=collection_name,
        embedding_function=embeddings,
        persist_directory=persist_directory,
        client_settings=settings,
    )


def load_data_local(vectorstore: Chroma, records: Iterable[Dict[str, str]]) -> int:
    """Load records into Chroma and return number of records inserted."""
    docs: List[Document] = []

    for index, record in enumerate(records):
        uuid = str(record.get("uuid") or f"local-{index}")
        title = _clean_text(record.get("title", ""))
        content = _clean_text(record.get("content", ""))
        questions = _clean_text(record.get("questions", ""))
        source = record.get("source", "local_loader")

        if not content:
            continue

        page_content = f"title:{title}\ncontent:{content}\nquestion:{questions}".strip()
        docs.append(Document(page_content=page_content, metadata={"uuid": uuid, "source": source}))

    if not docs:
        return 0

    vectorstore.add_documents(docs)
    return len(docs)


def load_from_json_file(json_file: str) -> List[Dict[str, str]]:
    """Load records from JSON list file."""
    with open(json_file, "r", encoding="utf-8") as handle:
        payload = json.load(handle)

    if not isinstance(payload, list):
        raise ValueError("JSON file must contain a list of records.")

    normalized: List[Dict[str, str]] = []
    for item in payload:
        if not isinstance(item, dict):
            continue
        normalized.append({
            "uuid": str(item.get("uuid", "")),
            "title": str(item.get("title", "")),
            "content": str(item.get("content", "")),
            "questions": str(item.get("questions", "")),
            "source": str(item.get("source", "json_file")),
        })
    return normalized


def load_from_urls(urls: Iterable[str]) -> List[Dict[str, str]]:
    """Create records from a list of URLs."""
    records: List[Dict[str, str]] = []
    for idx, url in enumerate(urls):
        text = fetch_url_text(url)
        records.append(
            {
                "uuid": f"url-{idx}",
                "title": url,
                "content": text,
                "questions": "",
                "source": "url_loader",
            }
        )
    return records


def load_data_chromadb(
    vectorstore: Chroma,
    advisories: Iterable[Dict[str, str]],
    content_fetcher: Optional[Callable[[str], str]] = None,
    question_generator: Optional[Callable[[str, str, str], str]] = None,
    is_existing_uuid: Optional[Callable[[str], bool]] = None,
    store_record: Optional[Callable[[Dict[str, str]], None]] = None,
) -> int:
    """Load advisory records into Chroma similar to the original loader flow.

    This function keeps the high-level behavior of `load_data_chromadb`:
    - filter to critical/high advisories
    - skip already-ingested uuids when a checker is provided
    - fetch advisory content
    - generate advisory questions
    - add document to Chroma
    - optionally persist the canonical advisory payload externally
    """
    inserted = 0
    fetcher = content_fetcher or fetch_url_text

    for advisory in advisories:
        severity = str(advisory.get("sir", "")).strip().upper()
        if severity not in {"CRITICAL", "HIGH"}:
            continue

        uuid = str(advisory.get("advisoryId") or advisory.get("uuid") or "")
        if not uuid:
            continue

        if is_existing_uuid and is_existing_uuid(uuid):
            continue

        source_url = str(advisory.get("publicationUrl") or advisory.get("source", "")).strip()
        title = _clean_text(str(advisory.get("title") or uuid))

        try:
            content = _clean_text(fetcher(source_url) if source_url else str(advisory.get("content", "")))
            if not content:
                continue

            questions = ""
            if question_generator:
                questions = _clean_text(question_generator(uuid, title, content))
            else:
                questions = _clean_text(str(advisory.get("questions", "")))

            payload = {
                "uuid": uuid,
                "title": title,
                "content": content,
                "questions": questions,
                "source": str(advisory.get("source", source_url or "advisory_loader")),
            }

            load_data_local(vectorstore, [payload])
            inserted += 1

            if store_record:
                store_record(payload)
        except Exception:
            continue

    return inserted


def _default_question_generator(uuid: str, title: str, content: str) -> str:
    """Generate baseline retrieval questions when no LLM question generator is provided."""
    return " | ".join(
        [
            f"What is the issue in advisory {uuid}?",
            f"Which products are impacted by {uuid}?",
            f"What is the mitigation for {uuid}?",
            f"What fixed software versions are listed for {uuid}?",
            f"Summarize advisory {uuid}: {title}",
        ]
    )


def _extract_advisory_title_and_content(source_url: str, fallback_title: str) -> tuple[str, str]:
    """Use the old extraction helper to preserve clean title/content when available."""
    if not source_url:
        return fallback_title, ""

    try:
        title, content = extract_content_from_url(source_url)
        return _clean_text(title) or fallback_title, _clean_text(content)
    except Exception as exc:
        logger.warning("Falling back to basic extractor for %s due to error: %s", source_url, exc)
        return fallback_title, _clean_text(fetch_url_text(source_url))


def collect_advisory_details(
    product: str = "cisco ios xe software",
    page_index: int = 1,
    page_size: int = 10,
    max_pages: int = 100,
) -> List[Dict[str, str]]:
    """Fetch advisory metadata from Cisco advisory API with pagination."""
    advisory_api = ADVISORY()
    advisory_api.login()
    next_item = f"/product?product={product}&pageIndex={page_index}&pageSize={page_size}"

    advisories_out: List[Dict[str, str]] = []
    pages_processed = 0
    while next_item and next_item != "NA" and pages_processed < max_pages:
        path = next_item.split("/product?product=")[-1]
        response = advisory_api.get_advisories_by_product(path)

        if not isinstance(response, dict):
            logger.warning("Cisco advisory API returned non-dict response; stopping pagination")
            break

        advisories_out.extend(response.get("advisories", []))
        paging = response.get("paging") or {}
        next_item = paging.get("next", "NA")
        pages_processed += 1

    logger.info("Fetched %s advisories from Cisco API", len(advisories_out))
    return advisories_out


def _is_existing_uuid(connector: PostgreSQLConnector, uuid: str) -> bool:
    with connector.conn.cursor() as cur:
        cur.execute("SELECT 1 FROM advisory_rag WHERE uuid = %s LIMIT 1", [uuid])
        return cur.fetchone() is not None


def _store_advisory_record(connector: PostgreSQLConnector, payload: Dict[str, str], vector_ids: List[str]) -> None:
    with connector.conn.cursor() as cur:
        cur.execute(
            """
            INSERT INTO advisory_rag (uuid, title, content, questions, vector_id)
            VALUES (%s, %s, %s, %s, %s)
            ON CONFLICT (uuid)
            DO UPDATE SET
                title = EXCLUDED.title,
                content = EXCLUDED.content,
                questions = EXCLUDED.questions,
                vector_id = EXCLUDED.vector_id,
                updated_at = NOW()
            """,
            [
                payload.get("uuid", ""),
                payload.get("title", ""),
                payload.get("content", ""),
                payload.get("questions", ""),
                vector_ids,
            ],
        )
    connector.conn.commit()


def load_cisco_advisories(
    vectorstore: Chroma,
    product: str = "cisco ios xe software",
    page_size: int = 10,
    max_pages: int = 100,
    question_generator: Optional[Callable[[str, str, str], str]] = None,
    persist_to_postgres: bool = True,
) -> int:
    """Load Cisco advisories into Chroma and optionally upsert into advisory_rag table."""
    advisories = collect_advisory_details(product=product, page_size=page_size, max_pages=max_pages)
    inserted = 0

    db = PostgreSQLConnector("RAGDatabase") if persist_to_postgres else None
    qgen = question_generator or generate_advisory_questions

    try:
        for advisory in advisories:
            severity = str(advisory.get("sir", "")).strip().upper()
            if severity not in {"CRITICAL", "HIGH"}:
                continue

            uuid = str(advisory.get("advisoryId") or "").strip()
            if not uuid:
                continue

            if db and _is_existing_uuid(db, uuid):
                continue

            title = _clean_text(str(advisory.get("title") or uuid))
            source_url = str(advisory.get("publicationUrl") or "").strip()

            try:
                title, content = _extract_advisory_title_and_content(source_url, title)
                if not content:
                    continue

                questions = _clean_text(qgen(uuid, title, content))
                doc = Document(
                    page_content=f"title:{title}\ncontent:{content}\nquestion:{questions}",
                    metadata={"uuid": uuid, "source": source_url or "cisco_advisory_api"},
                )
                vector_ids = vectorstore.add_documents([doc])

                if db:
                    payload = {
                        "uuid": uuid,
                        "title": title,
                        "content": content,
                        "questions": questions,
                    }
                    _store_advisory_record(db, payload, vector_ids)

                inserted += 1
                logger.info("Ingested advisory %s with vector ids: %s", uuid, vector_ids)
            except Exception as exc:
                logger.warning("Skipping advisory %s due to error: %s", uuid, exc)
                continue
    finally:
        if db:
            db.close()

    return inserted


def _sample_records() -> List[Dict[str, str]]:
    return [
        {
            "uuid": "sample-1",
            "title": "Sample Advisory",
            "content": "This is a sample advisory record for local testing.",
            "questions": "What products are impacted?",
            "source": "sample",
        }
    ]


def load_default_data(vectorstore: Chroma) -> int:
    """Load bundled sample records into Chroma."""
    return load_data_local(vectorstore, _sample_records())


def main() -> None:
    parser = argparse.ArgumentParser(description="Self-contained RAG loader")
    parser.add_argument("--json-file", default="", help="Path to JSON file containing records")
    parser.add_argument("--url", action="append", default=[], help="URL to ingest (repeatable)")
    parser.add_argument("--load-cisco", action="store_true", help="Load Cisco advisories from API")
    parser.add_argument("--product", default="cisco ios xe software", help="Cisco product filter")
    parser.add_argument("--page-size", type=int, default=10, help="Page size for Cisco advisory API")
    parser.add_argument("--max-pages", type=int, default=100, help="Maximum pages to fetch from Cisco advisory API")
    parser.add_argument("--persist-directory", default="./chroma_db")
    parser.add_argument("--collection-name", default="advisory_rag")
    args = parser.parse_args()

    vectorstore = build_vectorstore(
        persist_directory=args.persist_directory,
        collection_name=args.collection_name,
        embedding_model=args.embedding_model,
    )

    if args.load_cisco:
        inserted = load_cisco_advisories(
            vectorstore=vectorstore,
            product=args.product,
            page_size=args.page_size,
            max_pages=args.max_pages,
            persist_to_postgres=True,
        )
    elif args.json_file:
        records = load_from_json_file(args.json_file)
        inserted = load_data_local(vectorstore, records)
    elif args.url:
        records = load_from_urls(args.url)
        inserted = load_data_local(vectorstore, records)
    else:
        records = _sample_records()
        inserted = load_data_local(vectorstore, records)

    print(f"Inserted records: {inserted}")


if __name__ == "__main__":
    main()
