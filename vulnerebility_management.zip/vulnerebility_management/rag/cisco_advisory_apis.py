import logging

import requests
import urllib3
from config import BASE_DIR
try:
    from vulnerebility_management.config import API_CLIENT_ID, API_CLIENT_SECRET, API_GRANT_TYPE
except Exception:
    from config import API_CLIENT_ID, API_CLIENT_SECRET, API_GRANT_TYPE


urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

logger = logging.getLogger(__name__)
logger.addHandler(logging.StreamHandler())
logger.setLevel(logging.INFO)

class ADVISORY:
    def __init__(self):
        """
        Initialize with Cisco Advisory API defaults.
        """
        self.base_url = "https://apix.cisco.com/security/advisories/v2/"
        self.header = {'content-type': 'application/json'}

    def login(self):
        """
        Authenticate and generate a token for subsequent API calls.
        """
        url = "https://id.cisco.com/oauth2/default/v1/token"
        # Data for the POST request
        data = {
            "client_id": API_CLIENT_ID,
            "client_secret": API_CLIENT_SECRET,
            "grant_type": API_GRANT_TYPE,
        }

        # Set headers with content type
        headers = {"Content-Type": "application/x-www-form-urlencoded"}
        req = requests.post(url=url, verify=False, headers=headers, data=data)

        # Check for successful response (200 OK)
        if req.status_code == 200:
            # Get access token from JSON response
            access_token = req.json()["access_token"]
            self.header["Authorization"] = f"Bearer {access_token}"
            print("Access Token:", access_token)
            logger.info(f"Cisco Oauth Login token generated")
            # print(f"Generated Token: {token}")
        else:
            logger.debug(f"Login failed: {req.status_code}, {req.text}")
            print(f"Login failed: {req.status_code}, {req.text}")

    def get(self, path, params=None):
        """
        Make a GET request to a Security Advisories API.
        :param path: API endpoint (e.g., '/all')
        :param params: Optional query parameters for GET request
        :return: Response as JSON or error message.
        """
        url = f"{self.base_url}{path}"
        response = requests.get(url=url, headers=self.header, params=params, verify=False)
        logger.info(f"GET request - Debug Security Advisory url: {url}")

        if response.status_code == 200:
            response_data = response.json()
            # logger.info(f"GET request - Debug DNAC response: {response_data}")
            return response_data
        else:
            logger.debug(f"GET request failed: {response.status_code}, {response.text}")
            return f"GET request failed: {response.status_code}, {response.text}"

    def get_advisories_by_product(self,product):
        url = f"product?product={product}"
        return self.get(url)

    def get_all_advisories(self):
        # URL for retrieving security advisories
        url = "all"
        return self.get(url)


if __name__ == "__main__":
    from pprint import pprint

    adv = ADVISORY()
    adv.login()
    nextitem = "/product?product=cisco&pageIndex=16&pageSize=10"
    advs = adv.get_advisories_by_product(nextitem)
    print(advs)
    # while nextitem != 'NA':
    #     nextitem = nextitem.split('/product?product=')[-1]
    #     advs  = adv.get_advisories_by_product(nextitem)
    #     advsd = [{"advisoryIdx":x["advisoryId"],"sir": x["sir"]} for x in advs["advisories"]]
    #     nextitem = advs['paging']['next']
    #     print(advs)
    #     pprint(advsd)
    #     print(len(advsd))