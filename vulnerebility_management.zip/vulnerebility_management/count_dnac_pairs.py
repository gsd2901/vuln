"""
count_dnac_pairs.py
────────────────────
Ground-truth check: how many (advisory, device) pairs does DNAC itself report
right now for a given dnac_id, straight from the same DNAC class and config
credentials run_scan.py already uses successfully.

Run from the vulnerebility_management/ directory (same place run_scan.py lives):

    cd nautobot-latest/NaC/custom_chatbot/vulnerebility_management/
    source ../../../snaap310/bin/activate
    python count_dnac_pairs.py --dnac noida
"""

import argparse
import sys

parser = argparse.ArgumentParser()
parser.add_argument("--dnac", required=True, help="DNAC instance key from config.DNAC_INSTANCES, e.g. noida")
args = parser.parse_args()

from config import DNAC_INSTANCES  # noqa: E402
from dnac.dnacenter import DNAC    # noqa: E402

if args.dnac not in DNAC_INSTANCES:
    print(f"'{args.dnac}' not found in config.DNAC_INSTANCES. Available: {list(DNAC_INSTANCES.keys())}")
    sys.exit(1)

cfg = DNAC_INSTANCES[args.dnac]
dnac = DNAC(host=cfg["host"], username=cfg["username"], password=cfg["password"], port=cfg.get("port", 443))
dnac.login()

if "x-auth-token" not in dnac.header:
    print("Login failed — no token in dnac.header. Check the earlier 'Login failed: ...' log line above for the real reason.")
    sys.exit(1)

print("Login OK.\n")

advisories = dnac.get_advisories_list().get("response", [])
print(f"{len(advisories)} advisories found.\n")

total = 0
for adv in advisories:
    aid = adv.get("advisoryId", "")
    # Paginated — the plain single-page call silently caps at ~500 devices,
    # which is exactly what produced the 500-vs-1791 mismatch against the UI
    # for cisco-sa-hardening-iosxe-V8NMuMZJ.
    devices = dnac.get_all_devices_per_advisory(aid)
    n = len(devices)
    total += n
    print(f"{aid}: {n} device(s) affected")

print(f"\n--- total pairs: {total} ---")
