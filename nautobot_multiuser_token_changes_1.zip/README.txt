Files in this package and where they go relative to the Nautobot project root:

  custom_chatbot/nautobot_mcp_server.py         (modified)
  custom_chatbot/nautobot_request_token.py      (NEW file)
  custom_chatbot/views.py                       (modified)
  custom_chatbot/tools/nautobot_tools/tools/nautobot_relation_utils.py  (modified)
  custom_helpers.py                             (modified)

Plus ENV_CHANGE_INSTRUCTIONS.txt — a one-line manual edit to prod's .env
(no file to copy for that one).

What changed, in one line each:
  nautobot_mcp_server.py       - per-user Nautobot token (X-Nautobot-Token
                                  header) instead of one shared api client;
                                  removed print(NAUTOBOT_TOKEN) log leak;
                                  bound to 127.0.0.1 instead of 0.0.0.0.
  nautobot_request_token.py    - NEW. Shared token-resolution helper used
                                  by both nautobot_mcp_server.py and
                                  nautobot_relation_utils.py, with no
                                  dependency on Django/custom_helpers.py.
  views.py                     - resolves the calling Nautobot user's own
                                  API token and sends it to the MCP server
                                  as the X-Nautobot-Token header.
  nautobot_relation_utils.py   - relation lookups now prefer the per-user
                                  api client's own token; its fallback now
                                  goes through nautobot_request_token.py
                                  instead of custom_helpers.py.
  custom_helpers.py            - get_logged_in_user_token() simplified to
                                  a plain os.getenv("NAUTOBOT_TOKEN") read;
                                  dropped the getpass/user_karnataka
                                  special case and the unused getpass import.

Before deploying:
  1. Diff each file against prod's current copy first, in case prod has
     drifted from this dev checkout independently.
  2. Confirm the fastmcp version installed in prod supports
     fastmcp.server.dependencies.get_http_headers() (nautobot_mcp_server.py
     and nautobot_request_token.py depend on it for per-user token routing).
  3. Restart BOTH processes after deploying:
       - Nautobot itself (views.py, custom_helpers.py, and
         nautobot_relation_utils.py's token fallback are all loaded there):
             sudo systemctl restart nautobot nautobot-worker
       - the Nautobot MCP server (nautobot_mcp_server.py,
         nautobot_request_token.py, nautobot_relation_utils.py) — restart
         however you currently run/manage that separate process.
  4. If you'd also like the now-unused NAUTOBOT_TOKEN_TEST token revoked,
     that's a step in Nautobot itself (Profile -> API Tokens), not a file
     change.
