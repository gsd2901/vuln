"""
views.py – AI Chatbot API views for ServiceNow, Nautobot, SolarWinds and RAG pipelines.

All sensitive values (credentials, tokens, URLs) must be supplied via environment
variables.  See the inline ENV comments for the full list.
"""

# ---------------------------------------------------------------------------
# Standard library
# ---------------------------------------------------------------------------
import asyncio
import json
import logging
import os
import time
import re
import sys
import time
import urllib.parse
import tabulate as tabulate_lib
import uuid
from typing import Any, Dict, List, Optional, TypedDict

# ---------------------------------------------------------------------------
# Third-party – environment
# ---------------------------------------------------------------------------
from dotenv import load_dotenv

load_dotenv()  # Must be called before any os.getenv/os.environ access

# ---------------------------------------------------------------------------
# Third-party – Django
# ---------------------------------------------------------------------------
from django.conf import settings
from django.core.cache import cache
from django.db.models import Q
from django.http import HttpResponse, JsonResponse, StreamingHttpResponse
from django.utils import timezone
from django.views.decorators.csrf import csrf_exempt

# Nautobot's own per-user API token model (Profile -> API Tokens). Used so
# each chat request runs against Nautobot under the calling user's own
# identity/permissions instead of one shared service-account token.
try:
    from nautobot.users.models import Token as NautobotToken
except ImportError:
    NautobotToken = None

# ---------------------------------------------------------------------------
# Third-party – DRF
# ---------------------------------------------------------------------------
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView

# ---------------------------------------------------------------------------
# Third-party – LangChain / LangGraph
# ---------------------------------------------------------------------------
from langchain_core.messages import AIMessage, HumanMessage, SystemMessage, ToolMessage
from langchain_core.output_parsers import StrOutputParser
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.tools import tool
from langchain_openai import ChatOpenAI
from langgraph.graph import END, StateGraph
from pydantic import BaseModel, Field, SecretStr
from langchain_openai import AzureChatOpenAI
import httpx

# ---------------------------------------------------------------------------
# Third-party – MCP adapters (optional – degrade gracefully if absent)
# ---------------------------------------------------------------------------
try:
    from langchain_mcp_adapters.tools import load_mcp_tools
except ImportError:
    load_mcp_tools = None

try:
    from mcp import ClientSession, StdioServerParameters
    from mcp.client.stdio import stdio_client
except ImportError:
    ClientSession = None
    StdioServerParameters = None
    stdio_client = None

try:
    from mcp.client.streamable_http import streamablehttp_client
except ImportError:
    streamablehttp_client = None

# ---------------------------------------------------------------------------
# Third-party – misc
# ---------------------------------------------------------------------------
import numpy as np
import orionsdk
import urllib.parse
from langchain_community.vectorstores.pgvector import PGVector

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Local
# ---------------------------------------------------------------------------
from .models import Conversation
from .nautobot_prompt import build_nautobot_system_prompt
# from .servicenow_prompt import build_servicenow_system_prompt
try:
    from vulnerebility_management.rag_langchain_agent import run_rag_langchain_agent
    VM_RAG_AVAILABLE = True
    logger.info("run_rag_langchain_agent imported successfully")
except Exception as _vm_import_err:
    logger.error("Could not import run_rag_langchain_agent: %s", _vm_import_err)
    VM_RAG_AVAILABLE = False
    def run_rag_langchain_agent(query: str) -> str:  # type: ignore[misc]
        return "Vulnerability management service is currently unavailable."
from .ssh_connect import async_run_ssh_command
from custom_helpers import get_logged_in_user_token

NAUTOBOT_TOKEN = get_logged_in_user_token()

# DNAC instances config — used by DnacInstancesView
try:
    from vulnerebility_management.config import DNAC_INSTANCES as _VM_DNAC_INSTANCES
except Exception as _dnac_cfg_err:
    logger.warning("Could not import DNAC_INSTANCES from VM config: %s", _dnac_cfg_err)
    _VM_DNAC_INSTANCES = {}

# ---------------------------------------------------------------------------
# Logging
# ---------------------------------------------------------------------------
logging.basicConfig(
    filename="application.log",
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)
logger = logging.getLogger(__name__)
file_handler = logging.FileHandler("app_25_may_3.log")
logger.addHandler(file_handler)

DB_URL = (
    "postgresql+psycopg2://"
    f"{os.getenv('DB_USER')}:{os.getenv('DB_PASSWORD')}"
    f"@{os.getenv('DB_HOST')}:{os.getenv('DB_PORT')}"
    f"/{os.getenv('DB_NAME')}"
)

# ---------------------------------------------------------------------------
# LLM client (module-level singleton)
# ---------------------------------------------------------------------------
# llm = ChatOpenAI(
#     model="openai/gpt-4.1",
#     base_url="https://openrouter.ai/api/v1",
#     api_key=os.environ.get("OPENROUTER_API_KEY"),
# )
llm = AzureChatOpenAI(azure_deployment="gpt-5.4",
    api_version="2025-04-01-preview",
    azure_endpoint="https://git-nw-openai-llm-prod.openai.azure.com/",
    http_client=httpx.Client(verify=False),
    temperature=0,
    api_key=os.getenv("AZURE_OPENAI_API_KEY"))


# ---------------------------------------------------------------------------
# ServiceNow MCP server parameters
# ---------------------------------------------------------------------------
if StdioServerParameters is None:
    servicenow_server_params = None
else:
    servicenow_server_params = StdioServerParameters(
        command="python",
        args=["custom_chatbot/servicenow_server.py","token",NAUTOBOT_TOKEN],
    )


@csrf_exempt
def chat_status(request):
    """SSE endpoint that streams the current chatbot processing status."""
    start_time = time.time()
    # logger.info("chat_status stream initiated")

    def event_stream():
        duration = 20  # seconds
        interval = 0.3
        check_status = "Ready"

        try:
            for _ in range(int(duration / interval) + 1):
                elapsed = time.time() - start_time
                if elapsed >= duration or check_status == "Done":
                    break

                active_statuses = {
                    "Retriving Results from API",
                    "Querying ServiceNow",
                    "Querying API",
                    "Retriving ServiceNow results",
                    "Processing Data",
                    "Retriving Result",
                    "Updating Response",
                }
                if check_status not in active_statuses:
                    check_status = "Ready"

                yield f"data: {json.dumps({'status': check_status})}\n\n"
                time.sleep(interval)

            if check_status == "Done":
                yield "event: complete\ndata: {}\n\n"

        except GeneratorExit:
            logger.info("chat_status: client disconnected")
        except Exception:
            logger.exception("chat_status stream error")

    response = StreamingHttpResponse(event_stream(), content_type="text/event-stream")
    response["Cache-Control"] = "no-cache"
    return response


# ---------------------------------------------------------------------------
# ServiceNow helpers
# ---------------------------------------------------------------------------

def classify_tool(query: str) -> str:
    """Route a query to the appropriate ServiceNow tool name."""
    q = query.lower()
    if any(kw in q for kw in ["resolve", "close", "fix", "reopened", "resolved", "get", "show", "status", "details", "incident"]):
        return "get_incident"
    if "list" in q:
        return "list_incidents"
    if "update" in q:
        return "add_comment"
    return "unknown"

# ---------------------------------------------------------------------------
# Nautobot MCP helpers
# ---------------------------------------------------------------------------

async def _wait_for_mcp_http(url: str, timeout: float = 20.0) -> bool:
    """
    Poll the MCP HTTP endpoint until it accepts TCP connections.

    Any valid HTTP response (including 4xx) signals the server is ready.
    Returns False if the timeout expires without a successful connection.
    """
    parsed = urllib.parse.urlparse(url)
    probe_url = f"{parsed.scheme}://{parsed.netloc}/"
    loop = asyncio.get_event_loop()
    deadline = loop.time() + timeout

    while loop.time() < deadline:
        try:
            reader, writer = await asyncio.open_connection(
                parsed.hostname, parsed.port or 3001
            )
            request = f"GET {probe_url} HTTP/1.0\r\nHost: {parsed.netloc}\r\n\r\n"
            writer.write(request.encode())
            await writer.drain()
            response_line = await asyncio.wait_for(reader.readline(), timeout=3.0)
            writer.close()
            await writer.wait_closed()
            if response_line.startswith(b"HTTP/"):
                return True
        except (ConnectionRefusedError, OSError):
            pass
        except Exception:
            return True  # Partial/malformed response still means the server is alive
        await asyncio.sleep(0.5)

    return False


def _unwrap_exception_group(exc: BaseException) -> BaseException:
    """Extract the first real exception from a Python 3.11+ ExceptionGroup."""
    if hasattr(exc, "exceptions") and exc.exceptions:
        return exc.exceptions[0]
    return exc


def _extract_final_message(agent_response: Dict) -> str:
    """Normalise the final LangGraph agent message to a plain string."""
    content = agent_response["messages"][-1].content
    if isinstance(content, list):
        content = "".join(
            block.get("text", "") if isinstance(block, dict) else str(block)
            for block in content
        ).strip()
    return content


def _create_agent(llm_instance, tools_list, system_prompt: str, **kwargs):
    """
    Thin wrapper around the project's create_agent import so that
    the import lives in one place and is easy to swap.
    """
    
    from langchain.agents import create_agent  # local import avoids circular issues
    return create_agent(llm_instance, tools_list, system_prompt=system_prompt, **kwargs)

# ---------------------------------------------------------------------------
# Nautobot MCP helpers
# ---------------------------------------------------------------------------
def markdown_table_to_ascii(text: str) -> str:
    """
    Finds markdown tables in agent response and converts them
    to plain ASCII tables safe for any text-based frontend.
    """
    # Match a markdown table block (header + divider + rows)
    table_pattern = re.compile(
        r'(\|.+\|\n\|[-| :]+\|\n(?:\|.+\|\n?)+)',
        re.MULTILINE
    )

    def convert_table(match):
        raw = match.group(1).strip()
        lines = [line.strip() for line in raw.splitlines()]

        # Parse header
        headers = [h.strip() for h in lines[0].strip('|').split('|')]

        # Parse rows (skip the divider line at index 1)
        rows = []
        for line in lines[2:]:
            row = [cell.strip() for cell in line.strip('|').split('|')]
            rows.append(row)

        return tabulate_lib.tabulate(rows, headers=headers, tablefmt="grid")

    return table_pattern.sub(convert_table, text)

async def _check_mcp_server_running(url: str, timeout: float = 3.0) -> bool:
    """
    Perform a single quick TCP probe to check if the MCP server is already
    running at the given URL.
 
    Unlike _wait_for_mcp_http (which polls for up to N seconds while waiting
    for a server to start), this function makes ONE attempt with a short
    timeout and returns immediately.
 
    Returns True if the server responds to an HTTP request, False otherwise.
    """
    parsed = urllib.parse.urlparse(url)
    host = parsed.hostname
    port = parsed.port or 3001
 
    try:
        reader, writer = await asyncio.wait_for(
            asyncio.open_connection(host, port),
            timeout=timeout,
        )
        # Send a minimal HTTP/1.0 request so the server has something to respond to
        probe_url = f"{parsed.scheme}://{parsed.netloc}/"
        request = f"GET {probe_url} HTTP/1.0\r\nHost: {parsed.netloc}\r\n\r\n"
        writer.write(request.encode())
        await writer.drain()
 
        response_line = await asyncio.wait_for(reader.readline(), timeout=timeout)
        writer.close()
        await writer.wait_closed()
 
        # Any valid HTTP response (even 4xx) means the server is up
        return response_line.startswith(b"HTTP/")
 
    except (ConnectionRefusedError, OSError):
        # Port is closed — server is definitely not running
        return False
    except asyncio.TimeoutError:
        # Server did not respond in time — treat as not running
        return False
    except Exception:
        # A partial / malformed response still means something is listening
        return True


 
async def run_nautobot_agent(
    query: str,
    lc_messages: Optional[List] = None,
    nautobot_token: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Connect to an already-running Nautobot FastMCP server over HTTP transport
    and run a ReAct agent against the query.
 
    The MCP server is expected to be running independently before this
    function is called.  If the server is not reachable, the function logs
    a clear message and returns an error result immediately.

    nautobot_token, when provided, is the calling user's own personal
    Nautobot API token. It is sent as an HTTP header on the MCP connection
    so every Nautobot tool call the agent makes runs under that user's own
    identity/permissions rather than a single shared service-account token.
    When omitted, the MCP server falls back to its own shared default token.
    """
    if lc_messages is None:
        lc_messages = []

    mcp_headers: Optional[Dict[str, str]] = (
        {"X-Nautobot-Token": nautobot_token} if nautobot_token else None
    )
 
    # ------------------------------------------------------------------
    # 1. Guard: make sure the required MCP Python libraries are installed
    # ------------------------------------------------------------------
    if not all([load_mcp_tools, ClientSession, streamablehttp_client]):
        logger.error("Nautobot MCP dependencies are not fully available")
        return {"result": "Nautobot MCP tools are not configured in this runtime."}
 
    # ------------------------------------------------------------------
    # 2. Resolve the MCP server URL and build the list of fallback URLs
    # ------------------------------------------------------------------
    configured_mcp_url = os.getenv("NAUTOBOT_MCP_URL", "http://127.0.0.1:3001/mcp")
 
    mcp_url_candidates = [configured_mcp_url]
    if not configured_mcp_url.endswith("/mcp"):
        mcp_url_candidates.append(configured_mcp_url.rstrip("/") + "/mcp")
    # for fallback in ("http://127.0.0.1:3001/mcp", "http://127.0.0.1:3002/mcp"):
    #     if fallback not in mcp_url_candidates:
    #         mcp_url_candidates.append(fallback)
 
    # ------------------------------------------------------------------
    # 3. Pre-flight check: verify the MCP server is actually reachable
    #    before we attempt any MCP client operations.
    # ------------------------------------------------------------------
    server_is_up = await _check_mcp_server_running(configured_mcp_url)
    logger.info(f"MCP URL is ::: {server_is_up}")
    if not server_is_up:
        message = (
            f"Nautobot MCP server is not running at {configured_mcp_url}. "
            "Please start the MCP server before sending queries."
        )
        logger.error(message)
        print(message)   # visible in stdout / container logs as well
        return {"result": "Nautobot MCP server is not running. Please start the server and try again."}
 
    logger.info("Nautobot MCP server confirmed running at %s", configured_mcp_url)
 
    # ------------------------------------------------------------------
    # 4. Connect the MCP client, load tools, build the agent, run it
    # ------------------------------------------------------------------
    errors_by_url: Dict[str, str] = {}
 
    for mcp_url in mcp_url_candidates:
        last_error = None
 
        for attempt in range(3):
            try:
                async with streamablehttp_client(mcp_url, headers=mcp_headers) as (read, write, _):
                    async with ClientSession(read, write) as session:
                        await session.initialize()
 
                        # --- Load tools exposed by the MCP server ---
                        tools = await load_mcp_tools(session)
                        available_tool_names = [t.name for t in tools]
                        logger.info(
                            "Loaded Nautobot MCP tools from %s: %s",
                            mcp_url,
                            available_tool_names,
                        )
 
                        # --- Build the ReAct agent with a Nautobot-aware prompt ---
                        system_prompt = build_nautobot_system_prompt(available_tool_names)
                        logger.info(f"System prompt is {system_prompt}")
                        agent = _create_agent(llm, tools, system_prompt=system_prompt,debug=True)
                        trimmed_history=lc_messages[-4:]
 
                        # --- Prepend conversation history and invoke ---
                        messages_with_history = trimmed_history + [HumanMessage(content=query)]
                        logger.info(
                            "Invoking Nautobot agent with %d  trimmed history message(s)",
                            len(trimmed_history),
                        )
                        start_time = time.time()
                        agent_response = await agent.ainvoke(
                            {"messages": messages_with_history}
                        )
                        end_time = time.time()
                        # ⏱️ Calculate total time in seconds
                        time_taken = end_time - start_time
                        # print(f"total time taken for response is {time_taken}")
                        logger.info("Agent execution time: %.4f seconds", time_taken)
                        for msg in agent_response["messages"]:
                            logger.info("Message type: %s",type(msg).__name__)
                            logger.info("Message Content: %s",getattr(msg, "content",None))
 
                        # --- Extract the final text reply ---
                        final_message = _extract_final_message(agent_response)
                        final_response = markdown_table_to_ascii(final_message)
 
                        # --- Log which MCP tools were actually called ---
                        called_tools = [
                            msg.name
                            for msg in agent_response["messages"]
                            if isinstance(msg, ToolMessage) and getattr(msg, "name", None)
                        ]
                        logger.info("Nautobot tools called: %s", called_tools)
                        return {"result": final_response}
 
            except Exception as conn_err:
                real_err = _unwrap_exception_group(conn_err)
                last_error = real_err
                logger.warning(
                    "Attempt %d/3 failed for %s: %s: %s. Retrying in 2 s …",
                    attempt + 1,
                    mcp_url,
                    type(real_err).__name__,
                    real_err,
                )
                await asyncio.sleep(2)
 
        errors_by_url[mcp_url] = f"{type(last_error).__name__}: {last_error}"
 
    # All URL candidates and all retries exhausted
    logger.error(
        "Unable to connect to Nautobot MCP after trying all URL candidates: %s",
        errors_by_url,
    )
    return {"result": "error"}

# ---------------------------------------------------------------------------
# LangGraph state & nodes
# ---------------------------------------------------------------------------

class NautobotState(TypedDict):
    query: str
    parsed_query: Optional[Dict[str, str]]
    result: Optional[Any]
    error: Optional[str]
    current_tool: Optional[str]
    tool_choice: Optional[str]
    session_id: Optional[str]
    requested_tool: Optional[str]  # explicit tool selection from frontend ("nautobot" | "vulnerability_management")
    nautobot_token: Optional[str]  # calling user's own Nautobot API token, if any


# NOTE: These module-level lists are used by service_now_tools to carry
# transient conversation state.  In a multi-worker production deployment
# consider moving this to a per-session cache (e.g. Redis).
_incident_history: List = []
_needs_resolution_confirmation: bool = False

def _extract_dnac_id_from_query(query: str) -> Optional[str]:
    """Parse optional DNAC logical id from free text (e.g. VM wizard: 'impacted devices for dnac default')."""
    if not query or not isinstance(query, str):
        return None
    q = query.strip().lower()
    patterns = (
        r"\bfor\s+dnac\s+(\S+)",
        r"\bdnac_id\s*=\s*(\S+)",
        r"\bdnac_id\s*:\s*(\S+)",
        r"\busing\s+dnac\s+(\S+)",
    )
    for pat in patterns:
        m = re.search(pat, q)
        if m:
            token = m.group(1).strip().strip("\"'.,);")
            return token or None
    return None


def route_query(query: str) -> str:
    """Map a user query to one of the registered LangGraph route labels."""
    q = query.lower()
    return_val = ""
    if any(kw in q for kw in ["incident", "priority"]):
        return_val = "servicenow"
    elif any(kw in q for kw in ["vulnerability", "advisory", "dnac", "cisco", "security", "cve", "patch", "psirt"]):
        return_val = "vulnerability_management"
    elif any(kw in q for kw in ["nautobot", "device", "interface", "vlan", "prefix", "rack", "location"]):
        return_val =  "nautobot"
    elif any(kw in q for kw in ["alert", "solarwinds", "node"]):
        return_val =  "solarwinds"
    elif "engineer" in q:
        return_val =  "engineer_console"
    else :
        return_val =  "nautobot"
    # return_val =  "vulnerability_management"

    logger.info(f"Router val is {return_val} query is {q}")
    return return_val


def router(state: NautobotState) -> str:
    """Conditional edge: determine the next node and optionally clear history.

    Priority:
      1. requested_tool from frontend (explicit user selection)
      2. keyword-based route_query fallback
    """
    current_tool = state.get("current_tool")

    # Honour explicit tool selection from the frontend
    requested = (state.get("requested_tool") or "").strip().lower()
    _TOOL_ALIASES = {
        "vulnerability_management": "vulnerability_management",
        "vulnerability": "vulnerability_management",
        "nautobot": "nautobot",
    }
    if requested in _TOOL_ALIASES:
        new_route = _TOOL_ALIASES[requested]
    else:
        new_route = route_query(state["query"])

    if current_tool and current_tool != new_route:
        logger.info(
            "Tool switch detected (session=%s): %s → %s – clearing history",
            state["session_id"],
            current_tool,
            new_route,
        )
        Conversation.objects.filter(session_id=state["session_id"]).delete()

    logger.info("Router resolved: requested_tool=%s → route=%s", requested or "none", new_route)
    return new_route


# ---------------------------------------------------------------------------
# NautobotLangGraphTool
# ---------------------------------------------------------------------------

_TOOL_USED_TO_ROUTE: Dict[str, str] = {
    "nautobot":               "nautobot",
    "nautobot_mcp":           "nautobot",   # legacy DB values
    # "servicenow":             "servicenow",
    # "solarwinds":             "solarwinds",
    # "engineer_console":       "engineer_console",
    "vulnerability_management": "vulnerability_management",
}


class NautobotLangGraphTool:
    """
    Orchestrates multi-agent routing across ServiceNow, Nautobot, SolarWinds
    and a local RAG pipeline using a LangGraph StateGraph.
    """

    def __init__(self, llm_instance):
        self._llm = llm_instance
        self.workflow = self._build_workflow()

    # ------------------------------------------------------------------
    # Workflow construction
    # ------------------------------------------------------------------

    def _build_workflow(self):
        workflow = StateGraph(NautobotState)
        workflow.add_node("start", self._start_node)
        workflow.add_node("parse", self._parse_node)
        # workflow.add_node("service_now_callback", service_now_tools)
        workflow.add_node("nautobot_callback", self._nautobot_node)
        # workflow.add_node("solarwinds_callback", self._solarwinds_node)
        # workflow.add_node("engineer_console_callback", self._engineer_console_node)
        workflow.add_node("vulnerability_management_callback", self._vulnerability_management_node)
        workflow.add_node("history_updater", self._update_history_node)

        workflow.set_entry_point("start")
        workflow.add_conditional_edges(
            "start",
            router,
            {
                "chatbot":                "parse",
                # "servicenow":             "service_now_callback",
                "nautobot":               "nautobot_callback",
                # "solarwinds":             "solarwinds_callback",
                # "engineer_console":       "engineer_console_callback",
                "vulnerability_management": "vulnerability_management_callback",
            },
        )
        for node in (
            "parse",
            # "service_now_callback",
            "nautobot_callback",
            # "solarwinds_callback",
            # "engineer_console_callback",
            "vulnerability_management_callback",
        ):
            workflow.add_edge(node, "history_updater")
        workflow.add_edge("history_updater", END)
        return workflow.compile()

    # ------------------------------------------------------------------
    # History helpers
    # ------------------------------------------------------------------

    def _get_chat_history(self, session_id: str) -> List[Dict]:
        return [
            {"role": m.role, "content": m.content, "tool_used": m.tool_used}
            for m in Conversation.objects.filter(session_id=session_id).order_by("created_at")
        ]

    def _save_to_history(
        self,
        session_id: str,
        role: str,
        content: Any,
        tool_used: Optional[str] = None,
    ) -> None:
        if not isinstance(content, str):
            content = json.dumps(content, default=str)
        Conversation.objects.create(
            session_id=session_id,
            role=role,
            content=content,
            tool_used=tool_used,
        )

    def _convert_to_lc_messages(
        self, history: List[Dict], tool_filter: Optional[str] = None
    ) -> List:
        lc_messages = []
        for msg in history:
            role = msg["role"]
            if role == "system":
                lc_messages.append(SystemMessage(content=msg["content"]))
                continue
            if tool_filter and msg.get("tool_used") and msg["tool_used"] != tool_filter:
                continue
            if role == "user":
                lc_messages.append(HumanMessage(content=msg["content"]))
            elif role == "assistant":
                lc_messages.append(AIMessage(content=msg["content"]))
        return lc_messages

    # ------------------------------------------------------------------
    # Graph nodes
    # ------------------------------------------------------------------

    def _start_node(self, state: NautobotState) -> Dict:
        session_id = state.get("session_id") or str(uuid.uuid4())
        last_msg = (
            Conversation.objects.filter(session_id=session_id, role="assistant")
            .order_by("-created_at")
            .first()
        )
        raw_tool = last_msg.tool_used if last_msg else None
        last_tool = _TOOL_USED_TO_ROUTE.get(raw_tool) if raw_tool else None

        logger.info(
            "_start_node: session=%s raw_tool=%s resolved_route=%s",
            session_id,
            raw_tool,
            last_tool,
        )
        return {
            "query": state["query"],
            "session_id": session_id,
            "tool_choice": None,
            "current_tool": last_tool,
            "requested_tool": state.get("requested_tool"),
        }

    def _parse_node(self, state: NautobotState) -> Dict:
        """Chatbot fallback: run a local Nautobot query tool."""
        try:
            history = self._get_chat_history(state["session_id"])
            lc_messages = self._convert_to_lc_messages(history)

            from .nautobot_querytool import nautobot_query_tool  # local import

            agent = _create_agent(
                self._llm,
                [nautobot_query_tool],
                system_prompt="You are a network inventory specialist. Use tools to query Nautobot.",
            )
            result = agent.invoke(
                {"messages": lc_messages + [HumanMessage(content=state["query"])]}
            )
            return {"result": _extract_final_message(result), "tool_choice": None}

        except Exception:
            logger.exception("Error in _parse_node")
            return {"result": "Sorry, I encountered an error processing your Nautobot query.", "tool_choice": None}

    def _nautobot_node(self, state: NautobotState) -> Dict:
        """LangGraph node: run the Nautobot MCP agent."""
        session_id = state["session_id"]
        history = self._get_chat_history(session_id)
        lc_messages = self._convert_to_lc_messages(history, tool_filter="nautobot")
        logger.info(
            "_nautobot_node: session=%s history_len=%d lc_messages=%d",
            session_id,
            len(history),
            len(lc_messages),
        )

        # contextualized_query = self._contextualize_query(state["query"], lc_messages)
        # logger.info("_nautobot_node: final query='%s'", contextualized_query)

        # result = asyncio.run(run_nautobot_agent(contextualized_query, lc_messages=lc_messages))
        result = asyncio.run(
            run_nautobot_agent(
                state["query"],
                lc_messages=lc_messages,
                nautobot_token=state.get("nautobot_token"),
            )
        )
        return {"result": result["result"], "current_tool": "nautobot", "tool_choice": "nautobot"}



    def _vulnerability_management_node(self, state: NautobotState) -> Dict:
        """LangGraph node: handle vulnerability management queries with direct calls (no HTTP)."""
        session_id = state["session_id"]
        query = state["query"].lower()
        raw_query = state.get("query") or ""
        logger.info(f"_vulnerability_management_node query is {query}")
        # Route Cisco advisory/CVE/workaround questions to the standalone RAG advisory agent.
        logger.info(
                "_vulnerability_management_node: session=%s action=rag_advisory_query",
                session_id,
            )
        try:
            rag_response = run_rag_langchain_agent(raw_query)
            return {
                "result": rag_response,
                "current_tool": "vulnerability_management",
                "tool_choice": "vulnerability_management",
            }
        except Exception as rag_exc:
            logger.error(
                "_vulnerability_management_node: RAG advisory query failed for session=%s error=%s",
                session_id,
                rag_exc,
            )
            return {
                "result": {
                    "type": "service_error",
                    "message": "Advisory knowledge-base query failed. Please retry.",
                    "error_type": "rag_query_error",
                    "action": "show_service_error",
                    "retry_available": True,
                },
                "current_tool": "vulnerability_management",
                "tool_choice": "vulnerability_management",
            }

    def _update_history_node(self, state: NautobotState) -> Dict:
        """Persist user + assistant turns to the Conversation model."""
        try:
            # logger.info(
            #     "_update_history_node: session=%s tool_choice=%s result_type=%s",
            #     state["session_id"],
            #     state.get("tool_choice"),
            #     type(state.get("result")).__name__,
            # )
            self._save_to_history(state["session_id"], "user", state["query"], tool_used=None)
            self._save_to_history(
                state["session_id"], "assistant", state["result"], tool_used=state.get("tool_choice")
            )

            message_count = Conversation.objects.filter(session_id=state["session_id"]).count()
            if message_count > 30:
                self._summarize_history(state["session_id"])

            return {
                "result": state["result"],
                "session_id": state["session_id"],
                "status": "history_updated",
            }

        except Exception:
            logger.exception(
                "_update_history_node FAILED for session=%s", state.get("session_id")
            )
            return {
                "result": state["result"],
                "session_id": state["session_id"],
                "status": "history_update_failed",
            }

    def _summarize_history(self, session_id: str) -> bool:
        """
        Condense long conversation histories into a system-message summary.

        Keeps the 4 most recent messages (2 full turns) intact for immediate
        context continuity.  Returns True on success.
        """
        try:
            messages = Conversation.objects.filter(session_id=session_id).order_by("created_at")
            if messages.count() <= 30:
                return False

            history_text = "\n".join(
                f"{m.role.upper()}: {m.content}"
                for m in messages
                if m.role in ("user", "assistant")
            )
            summary_prompt = ChatPromptTemplate.from_messages([
                (
                    "system",
                    "You are a conversation summarizer for a network management chatbot. "
                    "Create a concise technical summary preserving ALL of the following:\n"
                    "- Every location/site name mentioned (e.g. AMS01, AMER, LON01)\n"
                    "- Every device name or hostname\n"
                    "- Every count or number referenced (e.g. '15 devices')\n"
                    "- Every VLAN, prefix, rack, or circuit ID\n"
                    "- The outcome of each user request\n"
                    "Do NOT paraphrase entity names — copy them exactly.",
                ),
                ("human", "Conversation History:\n{history}\n\nSummary (3-5 bullet points):"),
            ])
            summary = (summary_prompt | self._llm | StrOutputParser()).invoke(
                {"history": history_text}
            )

            last_four_ids = [
                m.id for m in messages.order_by("-created_at")[:4]
            ]
            Conversation.objects.filter(session_id=session_id).exclude(
                id__in=last_four_ids
            ).delete()
            Conversation.objects.create(
                session_id=session_id,
                role="system",
                content=f"### Conversation Summary ###\n{summary}",
                tool_used="history_summarizer",
            )
            logger.info("History summarized for session: %s", session_id)
            return True

        except Exception:
            logger.exception("Failed to summarize history for session: %s", session_id)
            return False

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def query(
        self,
        query: str,
        session_id: Optional[str] = None,
        requested_tool: Optional[str] = None,
        nautobot_token: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Execute a user query through the full LangGraph workflow.

        Args:
            query: The user's message.
            session_id: Optional session identifier for conversation history.
            requested_tool: Explicit tool selection from the frontend.
                            Accepted values: "nautobot", "vulnerability_management".
                            When provided, overrides keyword-based routing.
            nautobot_token: The calling user's own Nautobot API token, if
                            one could be resolved. Threaded through to the
                            Nautobot MCP node so calls run under that
                            user's own identity/permissions.
        """
        _session_id = session_id or str(uuid.uuid4())
        try:
            result = self.workflow.invoke({
                "query": query,
                "session_id": _session_id,
                "requested_tool": requested_tool,
                "nautobot_token": nautobot_token,
            })
            return {
                "result": result["result"],
                "session_id": result["session_id"],
                "tool_used": result.get("tool_choice", "unknown"),
            }
        except Exception:
            logger.exception("Error in NautobotLangGraphTool.query")
            return {
                "result": "Sorry, I encountered an error processing your request.",
                "session_id": _session_id,
                "tool_used": "error",
            }

# ---------------------------------------------------------------------------
# Module-level tool instance
# ---------------------------------------------------------------------------
langgraph_tool = NautobotLangGraphTool(llm)


# ---------------------------------------------------------------------------
# DnacInstancesView — returns DNAC list from config for the chatbot frontend
# ---------------------------------------------------------------------------

class DnacInstancesView(APIView):
    """
    GET /chatbot/dnac-instances/

    Returns the configured DNAC instances so the chat widget can show
    a selection chip for each one when Vulnerability Management is chosen.
    """
    permission_classes = [IsAuthenticated]

    def get(self, request):
        instances = []
        for dnac_id, cfg in _VM_DNAC_INSTANCES.items():
            if dnac_id == "default":
                continue
            instances.append({
                "id":   dnac_id,
                "host": cfg.get("host", ""),
                "port": cfg.get("port", 443),
            })
        return Response({"dnac_instances": instances})


# ---------------------------------------------------------------------------
# ChatbotView (main DRF endpoint)
# ---------------------------------------------------------------------------

def _resolve_nautobot_token(user) -> Optional[str]:
    """
    Look up this Nautobot user's own personal API token (Profile -> API
    Tokens) so their chat queries run against Nautobot under their own
    identity/permissions instead of one shared service-account token.

    Returns None if the user has no (non-expired) personal token, or if
    the Token model couldn't be imported — in either case the Nautobot MCP
    server falls back to its own configured shared default token.
    """
    if NautobotToken is None or user is None or not getattr(user, "is_authenticated", False):
        return None

    try:
        token_obj = (
            NautobotToken.objects.filter(user=user)
            .filter(Q(expires__isnull=True) | Q(expires__gt=timezone.now()))
            .order_by("-created")
            .first()
        )
    except Exception:
        logger.exception("Failed to look up personal Nautobot token for user=%s", getattr(user, "username", user))
        return None

    if not token_obj:
        logger.info(
            "No personal Nautobot API token found for user=%s — MCP calls will use the shared fallback token.",
            getattr(user, "username", user),
        )
        return None

    return token_obj.key


class ChatbotView(APIView):
    """
    POST /chatbot/

    Accepts a JSON body with 'message' and optional 'session_id'.
    Returns the agent response, session_id, tool_used, and processing_time.
    """

    permission_classes = [IsAuthenticated]

    def post(self, request):
        global _needs_resolution_confirmation

        start_time = time.time()
        session_id = request.data.get("session_id") or str(uuid.uuid4())

        try:
            user_message = request.data.get("message", "").strip()
            # Optional explicit tool selection: "nautobot" | "vulnerability_management"
            requested_tool = (request.data.get("tool") or "").strip().lower() or None
            # Optional DNAC id pre-selected by the user in the chat widget
            dnac_id = (request.data.get("dnac_id") or "").strip().lower() or None
            logger.info(
                "Received message for session %s | requested_tool=%s | dnac_id=%s",
                session_id,
                requested_tool or "none",
                dnac_id or "none",
            )

            # If the VM tool is active and a DNAC was pre-selected, inject it into the
            # query so the RAG agent doesn't have to ask the user which DNAC to use.
            if requested_tool == "vulnerability_management" and dnac_id:
                if f"dnac {dnac_id}" not in user_message.lower():
                    user_message = f"{user_message} for dnac {dnac_id}"
                    logger.info("Injected dnac_id into query: '%s'", user_message)

            if not user_message:
                logger.warning("Empty message received for session %s", session_id)
                return Response(
                    {"error": "Message cannot be empty", "session_id": session_id},
                    status=400,
                )

            # Intercept resolution confirmation flow
            if _needs_resolution_confirmation:
                if "yes" in user_message.lower():
                    user_message = "yes , please provide resolution for incident"
                elif "no" in user_message.lower():
                    _needs_resolution_confirmation = False
                    return Response({"response": "Okay, please ask your next query.", "session_id": session_id})

            nautobot_token = _resolve_nautobot_token(request.user)

            try:
                response = langgraph_tool.query(
                    query=user_message,
                    session_id=session_id,
                    requested_tool=requested_tool,
                    nautobot_token=nautobot_token,
                )
                # logger.info(
                #     "Request processed in %.2f s | session=%s | tool=%s",
                #     time.time() - start_time,
                #     session_id,
                #     response.get("tool_used", "unknown"),
                # )
                return Response({
                    "response": response["result"],
                    "session_id": response["session_id"],
                    "tool_used": response.get("tool_used", "unknown"),
                    "processing_time": f"{time.time() - start_time:.2f}s",
                })

            except Exception:
                logger.exception(
                    "AI processing error | session=%s", session_id
                )
                return Response(
                    {
                        "response": "Please retry your query. If the problem persists, contact support.",
                        "session_id": session_id,
                    },
                    status=500,
                )

        except Exception:
            logger.exception("System error in ChatbotView.post")
            return Response(
                {
                    "error": "Our system encountered an unexpected error.",
                    "session_id": session_id,
                    "support_reference": f"ERR-{uuid.uuid4().hex[:8]}",
                },
                status=500,
            )