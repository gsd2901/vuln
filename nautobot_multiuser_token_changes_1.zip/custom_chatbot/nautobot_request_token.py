"""
Shared per-request Nautobot token resolution.

Used by both the Nautobot MCP server (nautobot_mcp_server.py) and the MCP
tool helpers (tools/nautobot_tools/tools/nautobot_relation_utils.py) to
resolve which Nautobot API token a tool call should run under.

Deliberately has no dependency on Django, custom_helpers.py, or anything
else outside the MCP server's own process — this module used to only live
inside nautobot_mcp_server.py, and nautobot_relation_utils.py separately
depended on custom_helpers.get_logged_in_user_token() for its own fallback.
That meant the MCP server process was (accidentally) coupled to a Django
helper module — editing custom_helpers.py forced an MCP server restart for
no real reason. Extracting the shared piece here removes that coupling and
gives both call sites one single source of truth for "what token should
this call use."
"""

from __future__ import annotations

import os
from typing import Optional

from dotenv import load_dotenv

load_dotenv()

# Shared fallback token — used only when a request does not carry its own
# per-user Nautobot token. Kept for backward compatibility / local testing
# outside the chatbot's Django app.
NAUTOBOT_TOKEN = os.getenv("NAUTOBOT_TOKEN")

# Header the chatbot's Django views set on each MCP request, carrying the
# Nautobot user's own personal API token.
NAUTOBOT_TOKEN_HEADER = "x-nautobot-token"


def current_request_token() -> Optional[str]:
    """Best-effort lookup of the per-user Nautobot token on the active MCP request."""
    try:
        from fastmcp.server.dependencies import get_http_headers
    except ImportError:
        return None

    try:
        headers = get_http_headers()
    except Exception:
        # Not inside an active HTTP request (e.g. local/direct invocation).
        return None

    if not headers:
        return None

    # get_http_headers() normalises header names to lowercase, and by
    # default strips the `authorization` header entirely — so we rely on
    # our own custom header, not an Authorization fallback.
    return headers.get(NAUTOBOT_TOKEN_HEADER) or None


def resolve_token() -> Optional[str]:
    """
    The token to use right now: the calling user's own token if this call
    is happening inside a request that carried one, else the shared
    NAUTOBOT_TOKEN fallback.

    Note this is a *value* fallback, not a header fallback: the shared
    token never travels through the X-Nautobot-Token header (the Django
    side only ever sends that header when it resolved a real per-user
    token — see views.py's mcp_headers). When no header is present at all,
    this function is what supplies the shared token instead, read directly
    from NAUTOBOT_TOKEN above.
    """
    return current_request_token() or NAUTOBOT_TOKEN
