import bleach
import jwt
import json
import smtplib
import logging
import os
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from django.template import loader
from naas import constants
import socket

logger = logging.getLogger(__name__)

def sanitize_html(input_text, tags=None, attrs=None):
    """
    Sanitize HTML input using bleach.

    Args:
        input_text (str): Raw HTML input.
        tags (list): Allowed HTML tags.
        attrs (dict): Allowed HTML attributes.

    Returns:
        str: Cleaned/sanitized HTML.
    """
    allowed_tags = tags or ['p', 'b', 'i', 'u']
    allowed_attrs = attrs or {}

    return bleach.clean(input_text, tags=allowed_tags, attributes=allowed_attrs, strip=True)


def sanitize_csv_value(value):
    
    if isinstance(value, str):
        # Prevent CSV injection by prefixing dangerous characters with a single quote
        if value.startswith(('=', '+', '-', '@')):
            value = "'" + value
        # Remove any unwanted characters if needed
        value = value.strip()
    return value

def send_email(to_email: str, subject: str, template_name: str, context: dict, action_name:str) -> bool:
    """
    Send an HTML email using a Django template.

    Args:
        to_email (str): Recipient's email address.
        subject (str): Email subject.
        template_name (str): Django template path for the email body.
        context (dict): Template context dictionary.

    Returns:
        bool: True if sent successfully, False otherwise.
    """

    try:
        # Render the HTML template
        html_message = loader.render_to_string(template_name, context)

        # Construct email
        msg = MIMEMultipart("alternative")
        msg["From"] = constants.sender_email
        msg["To"] = to_email
        msg["Subject"] = subject
        msg.attach(MIMEText(html_message, "html"))

        # Connect and send
        server = smtplib.SMTP(constants.smtp_lib_server, constants.smtp_port)
        server.starttls()
        server.login(constants.sender_email, constants.sender_password)
        server.sendmail(constants.sender_email, [to_email], msg.as_string())
        server.quit()

        logger.info(f"{action_name} Email sent to {to_email}")
        return True

    except Exception as e:
        logger.error(f"{action_name} Failed to send email to {to_email}: {e}")
        return False

def get_logged_in_user_token():
    """
    Shared fallback Nautobot token, read once from the environment.

    This is NOT per-user — it's the same value for every caller. It exists
    only as a last-resort fallback for code paths that don't have a
    request-scoped, per-user pynautobot client available (see get_api() in
    nautobot_mcp_server.py, and _get_token()/resolve_relation_name() in
    nautobot_relation_utils.py, which prefer the calling user's own token
    and only fall back to this when that isn't available).
    """
    return os.getenv("NAUTOBOT_TOKEN")


def assign_groups(strategy, details, user=None, *args, **kwargs):
    from django.contrib.auth.models import Group
    if not user:
        logger.info("[SSO] No user found, skipping group assignment")
        return

    response = kwargs.get("response", {})

    # ✅ Try both locations
    id_token = kwargs.get("id_token") or response.get("id_token")

    logger.info(
        "[SSO][instance=%s][user=%s] Raw response: %s",
        socket.gethostname(),
        user.username,
        response
    )

    decoded_token = {}
    sso_groups = []

    # ✅ Decode ID Token
    if id_token:
        try:
            decoded_token = jwt.decode(
                id_token,
                options={"verify_signature": False}
            )

            logger.info(
                "[SSO][user=%s] Decoded ID token: %s",
                user.username,
                json.dumps(decoded_token, indent=2)
            )

            # ✅ Extract groups
            sso_groups = decoded_token.get("groups", [])

            # ✅ Handle large group case
            if not sso_groups and "_claim_names" in decoded_token:
                logger.warning(
                    "[SSO][user=%s] Groups missing in token (likely too many groups). "
                    "Graph API required.",
                    user.username
                )

        except Exception as e:
            logger.error(
                "[SSO][user=%s] Failed to decode ID token: %s",
                user.username,
                str(e)
            )
    else:
        logger.warning("[SSO][user=%s] id_token not found", user.username)

    # ✅ Final groups log
    logger.info(
        "[SSO][user=%s] Extracted SSO groups: %s",
        user.username,
        sso_groups
    )

    # # 🔁 Mapping
    # target_group = "238385ca-835a-4e17-a1c6-2023444b13b3" #GIT-SNAAP-Readonly group objectid on Azure
    # nautobot_group_name = "GIT_SNAAP_READONLY"

    # try:
    #     group = Group.objects.get(name=nautobot_group_name)
    # except Group.DoesNotExist:
    #     logger.error("[SSO] Nautobot group not found: %s", nautobot_group_name)
    #     return

    # if target_group in sso_groups:
    #     if group not in user.groups.all():
    #         user.groups.add(group)
    #         logger.info("[SSO] Added user %s to group %s", user.username, nautobot_group_name)
    # else:
    #     if group in user.groups.all():
    #         user.groups.remove(group)
    #         logger.info("[SSO] Removed user %s from group %s", user.username, nautobot_group_name)

    # user.save()

    logger.info("[SSO] Starting group sync for user: %s", user.username)

    # 🔁 Azure → Nautobot group mapping
    GROUP_MAPPING = {
        "c85aa481-668f-4573-9069-334f5153bf1a": "GIT_SNAAP_ADMIN", #GIT-SNAAP-Admin group objectid on Azure
        "238385ca-835a-4e17-a1c6-2023444b13b3": "GIT_SNAAP_READONLY", #GIT-SNAAP-Readonly group objectid on Azure
        "7bcd12ec-89c2-482a-b4b0-8eda1f384fcf": "GIT_SNAAP_FIELDTEAM", #GIT-SNAAP-FieldTeam group objectid on Azure
        "6819e591-a94b-4357-842d-4a0af2252ba6": "GIT_SNAAP_RW", #GIT-SNAAP-RW group objectid on Azure
    }

    # ✅ Step 1: Fetch all Nautobot groups in ONE query
    group_names = list(GROUP_MAPPING.values())
    nautobot_groups = {
        g.name: g for g in Group.objects.filter(name__in=group_names)
    }

    logger.debug("[SSO] Fetched Nautobot groups: %s", list(nautobot_groups.keys()))

    # ✅ Step 2: Filter relevant Azure groups
    mapped_ids = set(GROUP_MAPPING)
    incoming_ids = set(sso_groups)

    logger.debug("[SSO] Incoming Azure groups: %s", list(incoming_ids))

    valid_ids = incoming_ids & mapped_ids
    logger.debug("[SSO] Valid Azure groups (mapped): %s", list(valid_ids))

    # ✅ Step 3: Build expected group set
    expected_groups = {
        nautobot_groups[GROUP_MAPPING[g_id]]
        for g_id in valid_ids
        if GROUP_MAPPING[g_id] in nautobot_groups
    }

    logger.debug(
        "[SSO] Expected Nautobot groups: %s",
        [g.name for g in expected_groups],
    )

    # ✅ Step 4: Current groups (single query)
    current_groups = set(
        user.groups.filter(name__in=group_names)
    )

    logger.debug(
        "[SSO] Current Nautobot groups: %s",
        [g.name for g in current_groups],
    )

    # ✅ Step 5: Diff calculation
    to_add = expected_groups - current_groups
    to_remove = current_groups - expected_groups

    logger.debug("[SSO] Groups to ADD: %s", [g.name for g in to_add])
    logger.debug("[SSO] Groups to REMOVE: %s", [g.name for g in to_remove])

    # ✅ Step 6: Apply changes (only if needed)
    if to_add:
        user.groups.add(*to_add)
        logger.info(
            "[SSO] Added %s to: %s",
            user.username,
            [g.name for g in to_add],
        )

    if to_remove:
        user.groups.remove(*to_remove)
        logger.info(
            "[SSO] Removed %s from: %s",
            user.username,
            [g.name for g in to_remove],
        )

    if not to_add and not to_remove:
        logger.info("[SSO] No group changes required for %s", user.username)

    logger.info("[SSO] Completed group sync for user: %s", user.username)



